------------------------------------------------------------
-- Export file for user DEVELOPER@BI_RACDB1_111.13.20.109 --
-- Created by Administrator on 2015/5/25, 11:09:48 ---------
------------------------------------------------------------

set define off
spool --�ڶ�����FACT���ṹ�ļ�3.log

prompt
prompt Creating table FACT_100197_OPERATOR
prompt ===================================
prompt
create table FACT_100197_OPERATOR
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  dvid_operator VARCHAR2(50),
  conncount     NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100197_OPERATOR
  is '��Ӫ�̷�����';
comment on column FACT_100197_OPERATOR.statdate
  is 'ͳ������';
comment on column FACT_100197_OPERATOR.channelid
  is '����';
comment on column FACT_100197_OPERATOR.serverid
  is '����';
comment on column FACT_100197_OPERATOR.appid
  is '��Ʒid';
comment on column FACT_100197_OPERATOR.versionid
  is '��Ʒ�汾';
comment on column FACT_100197_OPERATOR.dvid_operator
  is '������ʽ';
comment on column FACT_100197_OPERATOR.conncount
  is '������';
comment on column FACT_100197_OPERATOR.data_source
  is '������Դ';
create index IDX76_100197 on FACT_100197_OPERATOR (CHANNELID);
create index IDX77_100197 on FACT_100197_OPERATOR (SERVERID);
create index IDX78_100197 on FACT_100197_OPERATOR (STATDATE);

prompt
prompt Creating table FACT_100197_ORDER
prompt ================================
prompt
create table FACT_100197_ORDER
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100197_ORDER
  is '����������';
comment on column FACT_100197_ORDER.statdate
  is 'ͳ������';
comment on column FACT_100197_ORDER.channelid
  is '����';
comment on column FACT_100197_ORDER.serverid
  is '����';
comment on column FACT_100197_ORDER.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100197_ORDER.appid
  is '��Ʒid';
comment on column FACT_100197_ORDER.versionid
  is '��Ʒ�汾';
comment on column FACT_100197_ORDER.paysucccount
  is '�ɹ�������';
comment on column FACT_100197_ORDER.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100197_ORDER.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100197_ORDER.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100197_ORDER.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100197_ORDER.payfailnum
  is '����ʧ������';
comment on column FACT_100197_ORDER.data_source
  is '������Դ';
create index IDX79_100197 on FACT_100197_ORDER (CHANNELID);
create index IDX80_100197 on FACT_100197_ORDER (SERVERID);
create index IDX81_100197 on FACT_100197_ORDER (STATDATE);

prompt
prompt Creating table FACT_100197_ORDER_HOUR
prompt =====================================
prompt
create table FACT_100197_ORDER_HOUR
(
  statdate      VARCHAR2(20),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100197_ORDER_HOUR
  is '����Сʱ������';
comment on column FACT_100197_ORDER_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100197_ORDER_HOUR.channelid
  is '����';
comment on column FACT_100197_ORDER_HOUR.serverid
  is '����';
comment on column FACT_100197_ORDER_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100197_ORDER_HOUR.appid
  is '��Ʒid';
comment on column FACT_100197_ORDER_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100197_ORDER_HOUR.paysucccount
  is '�ɹ�������';
comment on column FACT_100197_ORDER_HOUR.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100197_ORDER_HOUR.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100197_ORDER_HOUR.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100197_ORDER_HOUR.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100197_ORDER_HOUR.payfailnum
  is '����ʧ������';
comment on column FACT_100197_ORDER_HOUR.data_source
  is '������Դ';
create index IDX177_100197 on FACT_100197_ORDER_HOUR (CHANNELID);
create index IDX178_100197 on FACT_100197_ORDER_HOUR (SERVERID);
create index IDX179_100197 on FACT_100197_ORDER_HOUR (STATDATE);

prompt
prompt Creating table FACT_100197_ORDER_MONTH
prompt ======================================
prompt
create table FACT_100197_ORDER_MONTH
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100197_ORDER_MONTH
  is '�¶���������';
comment on column FACT_100197_ORDER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100197_ORDER_MONTH.channelid
  is '����';
comment on column FACT_100197_ORDER_MONTH.serverid
  is '����';
comment on column FACT_100197_ORDER_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100197_ORDER_MONTH.appid
  is '��Ʒid';
comment on column FACT_100197_ORDER_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100197_ORDER_MONTH.paysucccount
  is '�ɹ�������';
comment on column FACT_100197_ORDER_MONTH.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100197_ORDER_MONTH.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100197_ORDER_MONTH.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100197_ORDER_MONTH.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100197_ORDER_MONTH.payfailnum
  is '����ʧ������';
comment on column FACT_100197_ORDER_MONTH.data_source
  is '������Դ';
create index IDX191_100197 on FACT_100197_ORDER_MONTH (CHANNELID);
create index IDX192_100197 on FACT_100197_ORDER_MONTH (SERVERID);
create index IDX193_100197 on FACT_100197_ORDER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100197_ORDER_WEEK
prompt =====================================
prompt
create table FACT_100197_ORDER_WEEK
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100197_ORDER_WEEK
  is '�ܶ���������';
comment on column FACT_100197_ORDER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100197_ORDER_WEEK.channelid
  is '����';
comment on column FACT_100197_ORDER_WEEK.serverid
  is '����';
comment on column FACT_100197_ORDER_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100197_ORDER_WEEK.appid
  is '��Ʒid';
comment on column FACT_100197_ORDER_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100197_ORDER_WEEK.paysucccount
  is '�ɹ�������';
comment on column FACT_100197_ORDER_WEEK.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100197_ORDER_WEEK.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100197_ORDER_WEEK.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100197_ORDER_WEEK.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100197_ORDER_WEEK.payfailnum
  is '����ʧ������';
comment on column FACT_100197_ORDER_WEEK.data_source
  is '������Դ';
create index IDX188_100197 on FACT_100197_ORDER_WEEK (CHANNELID);
create index IDX189_100197 on FACT_100197_ORDER_WEEK (SERVERID);
create index IDX190_100197 on FACT_100197_ORDER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100197_PAYAMOUNT_DAY
prompt ========================================
prompt
create table FACT_100197_PAYAMOUNT_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100197_PAYAMOUNT_DAY
  is '�ճ�ֵ��������';
comment on column FACT_100197_PAYAMOUNT_DAY.statdate
  is 'ͳ������';
comment on column FACT_100197_PAYAMOUNT_DAY.channelid
  is '����';
comment on column FACT_100197_PAYAMOUNT_DAY.serverid
  is '����';
comment on column FACT_100197_PAYAMOUNT_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100197_PAYAMOUNT_DAY.appid
  is '��Ʒid';
comment on column FACT_100197_PAYAMOUNT_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100197_PAYAMOUNT_DAY.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100197_PAYAMOUNT_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100197_PAYAMOUNT_DAY.data_source
  is '������Դ';
create index IDX82_100197 on FACT_100197_PAYAMOUNT_DAY (CHANNELID);
create index IDX83_100197 on FACT_100197_PAYAMOUNT_DAY (SERVERID);
create index IDX84_100197 on FACT_100197_PAYAMOUNT_DAY (STATDATE);

prompt
prompt Creating table FACT_100197_PAYAMOUNT_MONTH
prompt ==========================================
prompt
create table FACT_100197_PAYAMOUNT_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100197_PAYAMOUNT_MONTH
  is '�³�ֵ��������';
comment on column FACT_100197_PAYAMOUNT_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100197_PAYAMOUNT_MONTH.channelid
  is '����';
comment on column FACT_100197_PAYAMOUNT_MONTH.serverid
  is '����';
comment on column FACT_100197_PAYAMOUNT_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100197_PAYAMOUNT_MONTH.appid
  is '��Ʒid';
comment on column FACT_100197_PAYAMOUNT_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100197_PAYAMOUNT_MONTH.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100197_PAYAMOUNT_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100197_PAYAMOUNT_MONTH.data_source
  is '������Դ';
create index IDX88_100197 on FACT_100197_PAYAMOUNT_MONTH (CHANNELID);
create index IDX89_100197 on FACT_100197_PAYAMOUNT_MONTH (SERVERID);
create index IDX90_100197 on FACT_100197_PAYAMOUNT_MONTH (STATDATE);

prompt
prompt Creating table FACT_100197_PAYAMOUNT_WEEK
prompt =========================================
prompt
create table FACT_100197_PAYAMOUNT_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100197_PAYAMOUNT_WEEK
  is '�ܳ�ֵ��������';
comment on column FACT_100197_PAYAMOUNT_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100197_PAYAMOUNT_WEEK.channelid
  is '����';
comment on column FACT_100197_PAYAMOUNT_WEEK.serverid
  is '����';
comment on column FACT_100197_PAYAMOUNT_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100197_PAYAMOUNT_WEEK.appid
  is '��Ʒid';
comment on column FACT_100197_PAYAMOUNT_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100197_PAYAMOUNT_WEEK.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100197_PAYAMOUNT_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100197_PAYAMOUNT_WEEK.data_source
  is '������Դ';
create index IDX85_100197 on FACT_100197_PAYAMOUNT_WEEK (CHANNELID);
create index IDX86_100197 on FACT_100197_PAYAMOUNT_WEEK (SERVERID);
create index IDX87_100197 on FACT_100197_PAYAMOUNT_WEEK (STATDATE);

prompt
prompt Creating table FACT_100197_PAYNUM_DAY
prompt =====================================
prompt
create table FACT_100197_PAYNUM_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100197_PAYNUM_DAY
  is '�ճ�ֵ����������';
comment on column FACT_100197_PAYNUM_DAY.statdate
  is 'ͳ������';
comment on column FACT_100197_PAYNUM_DAY.channelid
  is '����';
comment on column FACT_100197_PAYNUM_DAY.serverid
  is '����';
comment on column FACT_100197_PAYNUM_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100197_PAYNUM_DAY.appid
  is '��Ʒid';
comment on column FACT_100197_PAYNUM_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100197_PAYNUM_DAY.paynum
  is '��ֵ����';
comment on column FACT_100197_PAYNUM_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100197_PAYNUM_DAY.data_source
  is '������Դ';
create index IDX97_100197 on FACT_100197_PAYNUM_DAY (CHANNELID);
create index IDX98_100197 on FACT_100197_PAYNUM_DAY (SERVERID);
create index IDX99_100197 on FACT_100197_PAYNUM_DAY (STATDATE);

prompt
prompt Creating table FACT_100197_PAYNUM_MONTH
prompt =======================================
prompt
create table FACT_100197_PAYNUM_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100197_PAYNUM_MONTH
  is '�³�ֵ����������';
comment on column FACT_100197_PAYNUM_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100197_PAYNUM_MONTH.channelid
  is '����';
comment on column FACT_100197_PAYNUM_MONTH.serverid
  is '����';
comment on column FACT_100197_PAYNUM_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100197_PAYNUM_MONTH.appid
  is '��Ʒid';
comment on column FACT_100197_PAYNUM_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100197_PAYNUM_MONTH.paynum
  is '��ֵ����';
comment on column FACT_100197_PAYNUM_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100197_PAYNUM_MONTH.data_source
  is '������Դ';
create index IDX91_100197 on FACT_100197_PAYNUM_MONTH (CHANNELID);
create index IDX92_100197 on FACT_100197_PAYNUM_MONTH (SERVERID);
create index IDX93_100197 on FACT_100197_PAYNUM_MONTH (STATDATE);

prompt
prompt Creating table FACT_100197_PAYNUM_WEEK
prompt ======================================
prompt
create table FACT_100197_PAYNUM_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100197_PAYNUM_WEEK
  is '�ܳ�ֵ����������';
comment on column FACT_100197_PAYNUM_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100197_PAYNUM_WEEK.channelid
  is '����';
comment on column FACT_100197_PAYNUM_WEEK.serverid
  is '����';
comment on column FACT_100197_PAYNUM_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100197_PAYNUM_WEEK.appid
  is '��Ʒid';
comment on column FACT_100197_PAYNUM_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100197_PAYNUM_WEEK.paynum
  is '��ֵ����';
comment on column FACT_100197_PAYNUM_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100197_PAYNUM_WEEK.data_source
  is '������Դ';
create index IDX94_100197 on FACT_100197_PAYNUM_WEEK (CHANNELID);
create index IDX95_100197 on FACT_100197_PAYNUM_WEEK (SERVERID);
create index IDX96_100197 on FACT_100197_PAYNUM_WEEK (STATDATE);

prompt
prompt Creating table FACT_100197_PAYTYPE
prompt ==================================
prompt
create table FACT_100197_PAYTYPE
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paytypeid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100197_PAYTYPE
  is '��ֵ���ͷ�����';
comment on column FACT_100197_PAYTYPE.statdate
  is 'ͳ������';
comment on column FACT_100197_PAYTYPE.channelid
  is '����';
comment on column FACT_100197_PAYTYPE.serverid
  is '����';
comment on column FACT_100197_PAYTYPE.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100197_PAYTYPE.appid
  is '��Ʒid';
comment on column FACT_100197_PAYTYPE.versionid
  is '��Ʒ�汾';
comment on column FACT_100197_PAYTYPE.paytypeid
  is '��ֵ����';
comment on column FACT_100197_PAYTYPE.payamount
  is '��ֵ���';
comment on column FACT_100197_PAYTYPE.paycount
  is '��ֵ����';
comment on column FACT_100197_PAYTYPE.paynum
  is '��ֵ����';
comment on column FACT_100197_PAYTYPE.data_source
  is '������Դ';
create index IDX100_100197 on FACT_100197_PAYTYPE (CHANNELID);
create index IDX101_100197 on FACT_100197_PAYTYPE (SERVERID);
create index IDX102_100197 on FACT_100197_PAYTYPE (STATDATE);

prompt
prompt Creating table FACT_100197_PAYWAY
prompt =================================
prompt
create table FACT_100197_PAYWAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paywayid    VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100197_PAYWAY
  is '��ֵ��ʽ������';
comment on column FACT_100197_PAYWAY.statdate
  is 'ͳ������';
comment on column FACT_100197_PAYWAY.channelid
  is '����';
comment on column FACT_100197_PAYWAY.serverid
  is '����';
comment on column FACT_100197_PAYWAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100197_PAYWAY.appid
  is '��Ʒid';
comment on column FACT_100197_PAYWAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100197_PAYWAY.paywayid
  is '��ֵ��ʽ';
comment on column FACT_100197_PAYWAY.payamount
  is '��ֵ���';
comment on column FACT_100197_PAYWAY.paycount
  is '��ֵ����';
comment on column FACT_100197_PAYWAY.paynum
  is '��ֵ����';
comment on column FACT_100197_PAYWAY.data_source
  is '������Դ';
create index IDX103_100197 on FACT_100197_PAYWAY (CHANNELID);
create index IDX104_100197 on FACT_100197_PAYWAY (SERVERID);
create index IDX105_100197 on FACT_100197_PAYWAY (STATDATE);

prompt
prompt Creating table FACT_100197_REGION
prompt =================================
prompt
create table FACT_100197_REGION
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  country     VARCHAR2(50),
  province    VARCHAR2(50),
  city        VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100197_REGION
  is '���������';
comment on column FACT_100197_REGION.statdate
  is 'ͳ������';
comment on column FACT_100197_REGION.channelid
  is '����';
comment on column FACT_100197_REGION.serverid
  is '����';
comment on column FACT_100197_REGION.appid
  is '��Ʒid';
comment on column FACT_100197_REGION.versionid
  is '��Ʒ�汾';
comment on column FACT_100197_REGION.country
  is '����';
comment on column FACT_100197_REGION.province
  is 'ʡ';
comment on column FACT_100197_REGION.city
  is '��';
comment on column FACT_100197_REGION.newcount
  is '������';
comment on column FACT_100197_REGION.conncount
  is '������';
comment on column FACT_100197_REGION.paycount
  is '������';
comment on column FACT_100197_REGION.payamount
  is '���ѽ��';
comment on column FACT_100197_REGION.data_source
  is '������Դ';
create index IDX106_100197 on FACT_100197_REGION (CHANNELID);
create index IDX107_100197 on FACT_100197_REGION (SERVERID);
create index IDX108_100197 on FACT_100197_REGION (STATDATE);

prompt
prompt Creating table FACT_100197_REMAIN_MAC
prompt =====================================
prompt
create table FACT_100197_REMAIN_MAC
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100197_REMAIN_MAC
  is '�豸�����';
comment on column FACT_100197_REMAIN_MAC.statdate
  is 'ͳ������';
comment on column FACT_100197_REMAIN_MAC.conndate
  is '��������';
comment on column FACT_100197_REMAIN_MAC.channelid
  is '����ID';
comment on column FACT_100197_REMAIN_MAC.serverid
  is '����ID';
comment on column FACT_100197_REMAIN_MAC.appid
  is '��ƷID';
comment on column FACT_100197_REMAIN_MAC.remain_days
  is '��������';
comment on column FACT_100197_REMAIN_MAC.new_remain
  is '��������';
comment on column FACT_100197_REMAIN_MAC.conn_remain
  is '��������';
comment on column FACT_100197_REMAIN_MAC.pay_remain
  is '��������';
comment on column FACT_100197_REMAIN_MAC.data_source
  is '����Դ';
create index IDX109_100197 on FACT_100197_REMAIN_MAC (CHANNELID);
create index IDX110_100197 on FACT_100197_REMAIN_MAC (SERVERID);
create index IDX111_100197 on FACT_100197_REMAIN_MAC (STATDATE);

prompt
prompt Creating table FACT_100197_REMAIN_USER
prompt ======================================
prompt
create table FACT_100197_REMAIN_USER
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100197_REMAIN_USER
  is '�û������';
comment on column FACT_100197_REMAIN_USER.statdate
  is 'ͳ������';
comment on column FACT_100197_REMAIN_USER.conndate
  is '��������';
comment on column FACT_100197_REMAIN_USER.channelid
  is '����ID';
comment on column FACT_100197_REMAIN_USER.serverid
  is '����ID';
comment on column FACT_100197_REMAIN_USER.appid
  is '��ƷID';
comment on column FACT_100197_REMAIN_USER.remain_days
  is '��������';
comment on column FACT_100197_REMAIN_USER.new_remain
  is '��������';
comment on column FACT_100197_REMAIN_USER.conn_remain
  is '��������';
comment on column FACT_100197_REMAIN_USER.pay_remain
  is '��������';
comment on column FACT_100197_REMAIN_USER.data_source
  is '����Դ';
create index IDX112_100197 on FACT_100197_REMAIN_USER (CHANNELID);
create index IDX113_100197 on FACT_100197_REMAIN_USER (SERVERID);
create index IDX114_100197 on FACT_100197_REMAIN_USER (STATDATE);

prompt
prompt Creating table FACT_100197_VC
prompt =============================
prompt
create table FACT_100197_VC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcamount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100197_VC
  is '������ҷ�����';
comment on column FACT_100197_VC.statdate
  is 'ͳ������';
comment on column FACT_100197_VC.channelid
  is '����';
comment on column FACT_100197_VC.serverid
  is '����';
comment on column FACT_100197_VC.appid
  is '��Ʒid';
comment on column FACT_100197_VC.versionid
  is '��Ʒ�汾';
comment on column FACT_100197_VC.vctype
  is '�����������';
comment on column FACT_100197_VC.vcusetype
  is '�������ʹ������';
comment on column FACT_100197_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column FACT_100197_VC.vcamount
  is '������ҽ��';
comment on column FACT_100197_VC.data_source
  is '������Դ';
create index IDX115_100197 on FACT_100197_VC (CHANNELID);
create index IDX116_100197 on FACT_100197_VC (SERVERID);
create index IDX117_100197 on FACT_100197_VC (STATDATE);

prompt
prompt Creating table FACT_100198_BACK_MAC
prompt ===================================
prompt
create table FACT_100198_BACK_MAC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_BACK_MAC
  is '�豸����������';
comment on column FACT_100198_BACK_MAC.statdate
  is 'ͳ������';
comment on column FACT_100198_BACK_MAC.channelid
  is '����ID';
comment on column FACT_100198_BACK_MAC.serverid
  is '����ID';
comment on column FACT_100198_BACK_MAC.appid
  is '��ƷID';
comment on column FACT_100198_BACK_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100198_BACK_MAC.back_conn
  is '��Ծ�豸������';
comment on column FACT_100198_BACK_MAC.back_pay
  is '�����豸������';
comment on column FACT_100198_BACK_MAC.data_source
  is '����Դ';
create index IDX1_100198 on FACT_100198_BACK_MAC (CHANNELID);
create index IDX2_100198 on FACT_100198_BACK_MAC (SERVERID);
create index IDX3_100198 on FACT_100198_BACK_MAC (STATDATE);

prompt
prompt Creating table FACT_100198_BACK_MAC_MONTH
prompt =========================================
prompt
create table FACT_100198_BACK_MAC_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_BACK_MAC_MONTH
  is '�豸����������';
comment on column FACT_100198_BACK_MAC_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100198_BACK_MAC_MONTH.channelid
  is '����ID';
comment on column FACT_100198_BACK_MAC_MONTH.serverid
  is '����ID';
comment on column FACT_100198_BACK_MAC_MONTH.appid
  is '��ƷID';
comment on column FACT_100198_BACK_MAC_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100198_BACK_MAC_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100198_BACK_MAC_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100198_BACK_MAC_MONTH.data_source
  is '����Դ';
create index IDX4_100198 on FACT_100198_BACK_MAC_MONTH (CHANNELID);
create index IDX5_100198 on FACT_100198_BACK_MAC_MONTH (SERVERID);
create index IDX6_100198 on FACT_100198_BACK_MAC_MONTH (STATDATE);

prompt
prompt Creating table FACT_100198_BACK_MAC_WEEK
prompt ========================================
prompt
create table FACT_100198_BACK_MAC_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_BACK_MAC_WEEK
  is '�豸����������';
comment on column FACT_100198_BACK_MAC_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100198_BACK_MAC_WEEK.channelid
  is '����ID';
comment on column FACT_100198_BACK_MAC_WEEK.serverid
  is '����ID';
comment on column FACT_100198_BACK_MAC_WEEK.appid
  is '��ƷID';
comment on column FACT_100198_BACK_MAC_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100198_BACK_MAC_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100198_BACK_MAC_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100198_BACK_MAC_WEEK.data_source
  is '����Դ';
create index IDX7_100198 on FACT_100198_BACK_MAC_WEEK (CHANNELID);
create index IDX8_100198 on FACT_100198_BACK_MAC_WEEK (SERVERID);
create index IDX9_100198 on FACT_100198_BACK_MAC_WEEK (STATDATE);

prompt
prompt Creating table FACT_100198_BACK_USER
prompt ====================================
prompt
create table FACT_100198_BACK_USER
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_BACK_USER
  is '�û�����������';
comment on column FACT_100198_BACK_USER.statdate
  is 'ͳ������';
comment on column FACT_100198_BACK_USER.channelid
  is '����ID';
comment on column FACT_100198_BACK_USER.serverid
  is '����ID';
comment on column FACT_100198_BACK_USER.appid
  is '��ƷID';
comment on column FACT_100198_BACK_USER.lost_days
  is '��ʧ����';
comment on column FACT_100198_BACK_USER.back_conn
  is '��Ծ�û�������';
comment on column FACT_100198_BACK_USER.back_pay
  is '�����û�������';
comment on column FACT_100198_BACK_USER.data_source
  is '����Դ';
create index IDX16_100198 on FACT_100198_BACK_USER (CHANNELID);
create index IDX17_100198 on FACT_100198_BACK_USER (SERVERID);
create index IDX18_100198 on FACT_100198_BACK_USER (STATDATE);

prompt
prompt Creating table FACT_100198_BACK_USER_MONTH
prompt ==========================================
prompt
create table FACT_100198_BACK_USER_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_BACK_USER_MONTH
  is '�豸����������';
comment on column FACT_100198_BACK_USER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100198_BACK_USER_MONTH.channelid
  is '����ID';
comment on column FACT_100198_BACK_USER_MONTH.serverid
  is '����ID';
comment on column FACT_100198_BACK_USER_MONTH.appid
  is '��ƷID';
comment on column FACT_100198_BACK_USER_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100198_BACK_USER_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100198_BACK_USER_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100198_BACK_USER_MONTH.data_source
  is '����Դ';
create index IDX13_100198 on FACT_100198_BACK_USER_MONTH (CHANNELID);
create index IDX14_100198 on FACT_100198_BACK_USER_MONTH (SERVERID);
create index IDX15_100198 on FACT_100198_BACK_USER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100198_BACK_USER_WEEK
prompt =========================================
prompt
create table FACT_100198_BACK_USER_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_BACK_USER_WEEK
  is '�豸����������';
comment on column FACT_100198_BACK_USER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100198_BACK_USER_WEEK.channelid
  is '����ID';
comment on column FACT_100198_BACK_USER_WEEK.serverid
  is '����ID';
comment on column FACT_100198_BACK_USER_WEEK.appid
  is '��ƷID';
comment on column FACT_100198_BACK_USER_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100198_BACK_USER_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100198_BACK_USER_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100198_BACK_USER_WEEK.data_source
  is '����Դ';
create index IDX10_100198 on FACT_100198_BACK_USER_WEEK (CHANNELID);
create index IDX11_100198 on FACT_100198_BACK_USER_WEEK (SERVERID);
create index IDX12_100198 on FACT_100198_BACK_USER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100198_CEVENT
prompt =================================
prompt
create table FACT_100198_CEVENT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  eventkey    VARCHAR2(50),
  eventcount  NUMBER,
  eventnum    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_CEVENT
  is '�Զ��������';
comment on column FACT_100198_CEVENT.statdate
  is 'ͳ������';
comment on column FACT_100198_CEVENT.channelid
  is '����';
comment on column FACT_100198_CEVENT.serverid
  is '����';
comment on column FACT_100198_CEVENT.appid
  is '��Ʒid';
comment on column FACT_100198_CEVENT.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100198_CEVENT.eventcount
  is '�¼��û���';
comment on column FACT_100198_CEVENT.eventnum
  is '�¼�����';
comment on column FACT_100198_CEVENT.data_source
  is '������Դ';
create index IDX181_100198 on FACT_100198_CEVENT (CHANNELID);
create index IDX182_100198 on FACT_100198_CEVENT (SERVERID);
create index IDX183_100198 on FACT_100198_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100198_CEVENT_PAR
prompt =====================================
prompt
create table FACT_100198_CEVENT_PAR
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  ilevel         NUMBER,
  eventkey       VARCHAR2(100),
  eventpar_key   VARCHAR2(100),
  eventpar_value VARCHAR2(100),
  eventcount     NUMBER,
  eventnum       NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100198_CEVENT_PAR
  is '�Զ������������';
comment on column FACT_100198_CEVENT_PAR.statdate
  is 'ͳ������';
comment on column FACT_100198_CEVENT_PAR.channelid
  is '����';
comment on column FACT_100198_CEVENT_PAR.serverid
  is '����';
comment on column FACT_100198_CEVENT_PAR.appid
  is '��Ʒid';
comment on column FACT_100198_CEVENT_PAR.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_CEVENT_PAR.ilevel
  is '��ɫ�ȼ�';
comment on column FACT_100198_CEVENT_PAR.eventkey
  is '�¼�����';
comment on column FACT_100198_CEVENT_PAR.eventpar_key
  is '�¼�����';
comment on column FACT_100198_CEVENT_PAR.eventpar_value
  is '�¼�����ֵ';
comment on column FACT_100198_CEVENT_PAR.eventcount
  is '�¼��û���';
comment on column FACT_100198_CEVENT_PAR.eventnum
  is '�¼�����';
comment on column FACT_100198_CEVENT_PAR.data_source
  is '������Դ';
create index IDX185_100198 on FACT_100198_CEVENT_PAR (CHANNELID);
create index IDX186_100198 on FACT_100198_CEVENT_PAR (SERVERID);
create index IDX187_100198 on FACT_100198_CEVENT_PAR (STATDATE);

prompt
prompt Creating table FACT_100198_COMP_CEVENT
prompt ======================================
prompt
create table FACT_100198_COMP_CEVENT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(10),
  channelid   VARCHAR2(50),
  gameversion VARCHAR2(50),
  serverid    VARCHAR2(50),
  ilevel      NUMBER,
  eventkey    VARCHAR2(100),
  compid      VARCHAR2(50),
  caltype     VARCHAR2(50),
  dimpars     VARCHAR2(2000),
  comp_data   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_COMP_CEVENT
  is '�Զ����¼���Ϸ�����';
comment on column FACT_100198_COMP_CEVENT.statdate
  is '����';
comment on column FACT_100198_COMP_CEVENT.appid
  is '��Ϸ�� appid';
comment on column FACT_100198_COMP_CEVENT.channelid
  is '���� ID';
comment on column FACT_100198_COMP_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column FACT_100198_COMP_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column FACT_100198_COMP_CEVENT.ilevel
  is '��ҵȼ�';
comment on column FACT_100198_COMP_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100198_COMP_CEVENT.compid
  is '��ϼ����¼�ID';
comment on column FACT_100198_COMP_CEVENT.caltype
  is '��ϼ����¼���������';
comment on column FACT_100198_COMP_CEVENT.dimpars
  is '��ϲ���';
comment on column FACT_100198_COMP_CEVENT.comp_data
  is '��ϼ�����';
create index IDX184_100198 on FACT_100198_COMP_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100198_DAILY_REPORT
prompt =======================================
prompt
create table FACT_100198_DAILY_REPORT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_DAILY_REPORT
  is '�ձ�����';
comment on column FACT_100198_DAILY_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100198_DAILY_REPORT.appid
  is '��ƷID';
comment on column FACT_100198_DAILY_REPORT.channelid
  is '����';
comment on column FACT_100198_DAILY_REPORT.serverid
  is '����';
comment on column FACT_100198_DAILY_REPORT.indexid
  is 'ָ��';
comment on column FACT_100198_DAILY_REPORT.indtype
  is 'ָ������';
comment on column FACT_100198_DAILY_REPORT.rpt_data
  is '����';
create index IDX176_100198 on FACT_100198_DAILY_REPORT (STATDATE);

prompt
prompt Creating table FACT_100198_DVID
prompt ===============================
prompt
create table FACT_100198_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_model  VARCHAR2(200),
  dvid_res    VARCHAR2(50),
  dvid_os     VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_DVID
  is '�豸������';
comment on column FACT_100198_DVID.statdate
  is 'ͳ������';
comment on column FACT_100198_DVID.channelid
  is '����';
comment on column FACT_100198_DVID.serverid
  is '����';
comment on column FACT_100198_DVID.appid
  is '��Ʒid';
comment on column FACT_100198_DVID.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_DVID.dvid_model
  is '����';
comment on column FACT_100198_DVID.dvid_res
  is '�豸�ֱ���';
comment on column FACT_100198_DVID.dvid_os
  is '�豸����ϵͳ';
comment on column FACT_100198_DVID.newcount
  is '�����û���';
comment on column FACT_100198_DVID.conncount
  is '�����û���';
comment on column FACT_100198_DVID.data_source
  is '������Դ';
create index IDX19_100198 on FACT_100198_DVID (CHANNELID);
create index IDX20_100198 on FACT_100198_DVID (SERVERID);
create index IDX21_100198 on FACT_100198_DVID (STATDATE);

prompt
prompt Creating table FACT_100198_FIRSTPAY
prompt ===================================
prompt
create table FACT_100198_FIRSTPAY
(
  statdate         VARCHAR2(10),
  firstpaydate     VARCHAR2(10),
  channelid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  datatype         VARCHAR2(50),
  appid            VARCHAR2(50),
  first_payfromreg NUMBER,
  first_paycount   NUMBER,
  payamount        NUMBER,
  loaddate         DATE default SYSDATE,
  data_source      VARCHAR2(100)
)
;
comment on table FACT_100198_FIRSTPAY
  is '�����û��״γ�ֵ������';
comment on column FACT_100198_FIRSTPAY.statdate
  is 'ͳ������';
comment on column FACT_100198_FIRSTPAY.firstpaydate
  is '�״θ�������';
comment on column FACT_100198_FIRSTPAY.channelid
  is '����';
comment on column FACT_100198_FIRSTPAY.serverid
  is '����';
comment on column FACT_100198_FIRSTPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100198_FIRSTPAY.appid
  is '��Ʒid';
comment on column FACT_100198_FIRSTPAY.first_payfromreg
  is 'ע���ڼ��쿪ʼ��ֵ(1��2��..7..30..)';
comment on column FACT_100198_FIRSTPAY.first_paycount
  is '���������û���';
comment on column FACT_100198_FIRSTPAY.payamount
  is '�ۼƵ��ڼ���ĳ�ֵ�ܶ�';
comment on column FACT_100198_FIRSTPAY.data_source
  is '������Դ';
create index IDX22_100198 on FACT_100198_FIRSTPAY (CHANNELID);
create index IDX23_100198 on FACT_100198_FIRSTPAY (SERVERID);
create index IDX24_100198 on FACT_100198_FIRSTPAY (STATDATE);

prompt
prompt Creating table FACT_100198_FIRSTPAY_AMOUNT
prompt ==========================================
prompt
create table FACT_100198_FIRSTPAY_AMOUNT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_FIRSTPAY_AMOUNT
  is '�״θ��ѽ�������';
comment on column FACT_100198_FIRSTPAY_AMOUNT.statdate
  is 'ͳ������';
comment on column FACT_100198_FIRSTPAY_AMOUNT.channelid
  is '����';
comment on column FACT_100198_FIRSTPAY_AMOUNT.serverid
  is '��������';
comment on column FACT_100198_FIRSTPAY_AMOUNT.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100198_FIRSTPAY_AMOUNT.appid
  is '��Ʒid';
comment on column FACT_100198_FIRSTPAY_AMOUNT.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_FIRSTPAY_AMOUNT.payamount
  is '�״θ��ѽ��';
comment on column FACT_100198_FIRSTPAY_AMOUNT.paycount
  is '�״θ��ѽ���Ӧ������';
create index IDX25_100198 on FACT_100198_FIRSTPAY_AMOUNT (CHANNELID);
create index IDX26_100198 on FACT_100198_FIRSTPAY_AMOUNT (SERVERID);
create index IDX27_100198 on FACT_100198_FIRSTPAY_AMOUNT (STATDATE);

prompt
prompt Creating table FACT_100198_GENERAL_DAY
prompt ======================================
prompt
create table FACT_100198_GENERAL_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_GENERAL_DAY
  is '�ջ���������';
comment on column FACT_100198_GENERAL_DAY.statdate
  is 'ͳ������';
comment on column FACT_100198_GENERAL_DAY.channelid
  is '����';
comment on column FACT_100198_GENERAL_DAY.serverid
  is '����';
comment on column FACT_100198_GENERAL_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100198_GENERAL_DAY.appid
  is '��Ʒid';
comment on column FACT_100198_GENERAL_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_GENERAL_DAY.newcount
  is '������';
comment on column FACT_100198_GENERAL_DAY.conncount
  is '������';
comment on column FACT_100198_GENERAL_DAY.paycount
  is '������';
comment on column FACT_100198_GENERAL_DAY.payamount
  is '���ѽ��';
comment on column FACT_100198_GENERAL_DAY.data_source
  is '������Դ';
create index IDX28_100198 on FACT_100198_GENERAL_DAY (CHANNELID);
create index IDX29_100198 on FACT_100198_GENERAL_DAY (SERVERID);
create index IDX30_100198 on FACT_100198_GENERAL_DAY (STATDATE);

prompt
prompt Creating table FACT_100198_GENERAL_DAY_DVID
prompt ===========================================
prompt
create table FACT_100198_GENERAL_DAY_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_GENERAL_DAY_DVID
  is '���豸����������';
comment on column FACT_100198_GENERAL_DAY_DVID.statdate
  is 'ͳ������';
comment on column FACT_100198_GENERAL_DAY_DVID.channelid
  is '����';
comment on column FACT_100198_GENERAL_DAY_DVID.appid
  is '��Ʒid';
comment on column FACT_100198_GENERAL_DAY_DVID.newcount
  is '������';
comment on column FACT_100198_GENERAL_DAY_DVID.conncount
  is '������';
comment on column FACT_100198_GENERAL_DAY_DVID.data_source
  is '������Դ';
create index IDX31_100198 on FACT_100198_GENERAL_DAY_DVID (CHANNELID);
create index IDX33_100198 on FACT_100198_GENERAL_DAY_DVID (STATDATE);

prompt
prompt Creating table FACT_100198_GENERAL_HOUR
prompt =======================================
prompt
create table FACT_100198_GENERAL_HOUR
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_GENERAL_HOUR
  is 'Сʱ����������';
comment on column FACT_100198_GENERAL_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100198_GENERAL_HOUR.channelid
  is '����';
comment on column FACT_100198_GENERAL_HOUR.serverid
  is '����';
comment on column FACT_100198_GENERAL_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100198_GENERAL_HOUR.appid
  is '��Ʒid';
comment on column FACT_100198_GENERAL_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_GENERAL_HOUR.newcount
  is '������';
comment on column FACT_100198_GENERAL_HOUR.conncount
  is '������';
comment on column FACT_100198_GENERAL_HOUR.paycount
  is '������';
comment on column FACT_100198_GENERAL_HOUR.payamount
  is '���ѽ��';
comment on column FACT_100198_GENERAL_HOUR.data_source
  is '������Դ';
create index IDX34_100198 on FACT_100198_GENERAL_HOUR (CHANNELID);
create index IDX35_100198 on FACT_100198_GENERAL_HOUR (SERVERID);
create index IDX36_100198 on FACT_100198_GENERAL_HOUR (STATDATE);

prompt
prompt Creating table FACT_100198_GENERAL_HOUR_DVID
prompt ============================================
prompt
create table FACT_100198_GENERAL_HOUR_DVID
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_GENERAL_HOUR_DVID
  is 'Сʱ�豸����������';
comment on column FACT_100198_GENERAL_HOUR_DVID.statdate
  is 'ͳ������';
comment on column FACT_100198_GENERAL_HOUR_DVID.channelid
  is '����';
comment on column FACT_100198_GENERAL_HOUR_DVID.appid
  is '��Ʒid';
comment on column FACT_100198_GENERAL_HOUR_DVID.newcount
  is '������';
comment on column FACT_100198_GENERAL_HOUR_DVID.conncount
  is '������';
comment on column FACT_100198_GENERAL_HOUR_DVID.data_source
  is '������Դ';
create index IDX37_100198 on FACT_100198_GENERAL_HOUR_DVID (CHANNELID);
create index IDX39_100198 on FACT_100198_GENERAL_HOUR_DVID (STATDATE);

prompt
prompt Creating table FACT_100198_GENERAL_LEVEL
prompt ========================================
prompt
create table FACT_100198_GENERAL_LEVEL
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  rolelevel   NUMBER,
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_GENERAL_LEVEL
  is '�û��ȼ�������';
comment on column FACT_100198_GENERAL_LEVEL.statdate
  is 'ͳ������';
comment on column FACT_100198_GENERAL_LEVEL.channelid
  is '����';
comment on column FACT_100198_GENERAL_LEVEL.serverid
  is '����';
comment on column FACT_100198_GENERAL_LEVEL.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100198_GENERAL_LEVEL.appid
  is '��Ʒid';
comment on column FACT_100198_GENERAL_LEVEL.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_GENERAL_LEVEL.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100198_GENERAL_LEVEL.newcount
  is '������';
comment on column FACT_100198_GENERAL_LEVEL.conncount
  is '������';
comment on column FACT_100198_GENERAL_LEVEL.paycount
  is '������';
comment on column FACT_100198_GENERAL_LEVEL.payamount
  is '���ѽ��';
comment on column FACT_100198_GENERAL_LEVEL.data_source
  is '������Դ';
create index IDX40_100198 on FACT_100198_GENERAL_LEVEL (CHANNELID);
create index IDX41_100198 on FACT_100198_GENERAL_LEVEL (SERVERID);
create index IDX42_100198 on FACT_100198_GENERAL_LEVEL (STATDATE);

prompt
prompt Creating table FACT_100198_GENERAL_MONTH
prompt ========================================
prompt
create table FACT_100198_GENERAL_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_GENERAL_MONTH
  is '�»���������';
comment on column FACT_100198_GENERAL_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100198_GENERAL_MONTH.channelid
  is '����';
comment on column FACT_100198_GENERAL_MONTH.serverid
  is '����';
comment on column FACT_100198_GENERAL_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100198_GENERAL_MONTH.appid
  is '��Ʒid';
comment on column FACT_100198_GENERAL_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_GENERAL_MONTH.newcount
  is '������';
comment on column FACT_100198_GENERAL_MONTH.conncount
  is '������';
comment on column FACT_100198_GENERAL_MONTH.paycount
  is '������';
comment on column FACT_100198_GENERAL_MONTH.payamount
  is '���ѽ��';
comment on column FACT_100198_GENERAL_MONTH.data_source
  is '������Դ';
create index IDX43_100198 on FACT_100198_GENERAL_MONTH (CHANNELID);
create index IDX44_100198 on FACT_100198_GENERAL_MONTH (SERVERID);
create index IDX45_100198 on FACT_100198_GENERAL_MONTH (STATDATE);

prompt
prompt Creating table FACT_100198_GENERAL_MONTH_DVID
prompt =============================================
prompt
create table FACT_100198_GENERAL_MONTH_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_GENERAL_MONTH_DVID
  is '���豸����������';
comment on column FACT_100198_GENERAL_MONTH_DVID.statdate
  is 'ͳ������';
comment on column FACT_100198_GENERAL_MONTH_DVID.channelid
  is '����';
comment on column FACT_100198_GENERAL_MONTH_DVID.appid
  is '��Ʒid';
comment on column FACT_100198_GENERAL_MONTH_DVID.newcount
  is '������';
comment on column FACT_100198_GENERAL_MONTH_DVID.conncount
  is '������';
comment on column FACT_100198_GENERAL_MONTH_DVID.data_source
  is '������Դ';
create index IDX46_100198 on FACT_100198_GENERAL_MONTH_DVID (CHANNELID);
create index IDX48_100198 on FACT_100198_GENERAL_MONTH_DVID (STATDATE);

prompt
prompt Creating table FACT_100198_GENERAL_WEEK
prompt =======================================
prompt
create table FACT_100198_GENERAL_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_GENERAL_WEEK
  is '�ܻ���������';
comment on column FACT_100198_GENERAL_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100198_GENERAL_WEEK.channelid
  is '����';
comment on column FACT_100198_GENERAL_WEEK.serverid
  is '����';
comment on column FACT_100198_GENERAL_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100198_GENERAL_WEEK.appid
  is '��Ʒid';
comment on column FACT_100198_GENERAL_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_GENERAL_WEEK.newcount
  is '������';
comment on column FACT_100198_GENERAL_WEEK.conncount
  is '������';
comment on column FACT_100198_GENERAL_WEEK.paycount
  is '������';
comment on column FACT_100198_GENERAL_WEEK.payamount
  is '���ѽ��';
comment on column FACT_100198_GENERAL_WEEK.data_source
  is '������Դ';
create index IDX52_100198 on FACT_100198_GENERAL_WEEK (CHANNELID);
create index IDX53_100198 on FACT_100198_GENERAL_WEEK (SERVERID);
create index IDX54_100198 on FACT_100198_GENERAL_WEEK (STATDATE);

prompt
prompt Creating table FACT_100198_GENERAL_WEEK_DVID
prompt ============================================
prompt
create table FACT_100198_GENERAL_WEEK_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_GENERAL_WEEK_DVID
  is '���豸����������';
comment on column FACT_100198_GENERAL_WEEK_DVID.statdate
  is 'ͳ������';
comment on column FACT_100198_GENERAL_WEEK_DVID.channelid
  is '����';
comment on column FACT_100198_GENERAL_WEEK_DVID.appid
  is '��Ʒid';
comment on column FACT_100198_GENERAL_WEEK_DVID.newcount
  is '������';
comment on column FACT_100198_GENERAL_WEEK_DVID.conncount
  is '������';
comment on column FACT_100198_GENERAL_WEEK_DVID.data_source
  is '������Դ';
create index IDX49_100198 on FACT_100198_GENERAL_WEEK_DVID (CHANNELID);
create index IDX51_100198 on FACT_100198_GENERAL_WEEK_DVID (STATDATE);

prompt
prompt Creating table FACT_100198_HOUR_REPORT
prompt ======================================
prompt
create table FACT_100198_HOUR_REPORT
(
  statdate    VARCHAR2(20),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_HOUR_REPORT
  is '�ձ�Сʱ����';
comment on column FACT_100198_HOUR_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100198_HOUR_REPORT.appid
  is '��ƷID';
comment on column FACT_100198_HOUR_REPORT.channelid
  is '����';
comment on column FACT_100198_HOUR_REPORT.serverid
  is '����';
comment on column FACT_100198_HOUR_REPORT.indexid
  is 'ָ��';
comment on column FACT_100198_HOUR_REPORT.indtype
  is 'ָ������';
comment on column FACT_100198_HOUR_REPORT.rpt_data
  is '����';

prompt
prompt Creating table FACT_100198_LEVELPAY
prompt ===================================
prompt
create table FACT_100198_LEVELPAY
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  datatype       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  rolelevel      NUMBER,
  paycount       NUMBER,
  first_paycount NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100198_LEVELPAY
  is '�û���ɫ�ȼ����ѷ�����';
comment on column FACT_100198_LEVELPAY.statdate
  is 'ͳ������';
comment on column FACT_100198_LEVELPAY.channelid
  is '����';
comment on column FACT_100198_LEVELPAY.serverid
  is '����';
comment on column FACT_100198_LEVELPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100198_LEVELPAY.appid
  is '��Ʒid';
comment on column FACT_100198_LEVELPAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_LEVELPAY.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100198_LEVELPAY.paycount
  is '�����û���';
comment on column FACT_100198_LEVELPAY.first_paycount
  is '���������û������״θ����û���';
comment on column FACT_100198_LEVELPAY.data_source
  is '������Դ';
create index IDX55_100198 on FACT_100198_LEVELPAY (CHANNELID);
create index IDX56_100198 on FACT_100198_LEVELPAY (SERVERID);
create index IDX57_100198 on FACT_100198_LEVELPAY (STATDATE);

prompt
prompt Creating table FACT_100198_LOST_MAC
prompt ===================================
prompt
create table FACT_100198_LOST_MAC
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_LOST_MAC
  is '�豸��ʧ������';
comment on column FACT_100198_LOST_MAC.statdate
  is 'ͳ������';
comment on column FACT_100198_LOST_MAC.lostdate
  is '��ʧ����';
comment on column FACT_100198_LOST_MAC.channelid
  is '����ID';
comment on column FACT_100198_LOST_MAC.serverid
  is '����ID';
comment on column FACT_100198_LOST_MAC.appid
  is '��ƷID';
comment on column FACT_100198_LOST_MAC.rolelevel
  is '��ʧʱ�ȼ�';
comment on column FACT_100198_LOST_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100198_LOST_MAC.lost_conn
  is '��Ծ�豸��ʧ';
comment on column FACT_100198_LOST_MAC.lost_pay
  is '�����豸��ʧ';
comment on column FACT_100198_LOST_MAC.data_source
  is '����Դ';
create index IDX58_100198 on FACT_100198_LOST_MAC (CHANNELID);
create index IDX59_100198 on FACT_100198_LOST_MAC (SERVERID);
create index IDX60_100198 on FACT_100198_LOST_MAC (STATDATE);

prompt
prompt Creating table FACT_100198_LOST_USER
prompt ====================================
prompt
create table FACT_100198_LOST_USER
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_LOST_USER
  is '�û���ʧ������';
comment on column FACT_100198_LOST_USER.statdate
  is 'ͳ������';
comment on column FACT_100198_LOST_USER.lostdate
  is '��ʧ����';
comment on column FACT_100198_LOST_USER.channelid
  is '����ID';
comment on column FACT_100198_LOST_USER.serverid
  is '����ID';
comment on column FACT_100198_LOST_USER.appid
  is '��ƷID';
comment on column FACT_100198_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column FACT_100198_LOST_USER.lost_days
  is '��ʧ����';
comment on column FACT_100198_LOST_USER.lost_conn
  is '��Ծ�û���ʧ';
comment on column FACT_100198_LOST_USER.lost_pay
  is '�����û���ʧ';
comment on column FACT_100198_LOST_USER.data_source
  is '����Դ';
create index IDX61_100198 on FACT_100198_LOST_USER (CHANNELID);
create index IDX62_100198 on FACT_100198_LOST_USER (SERVERID);
create index IDX63_100198 on FACT_100198_LOST_USER (STATDATE);

prompt
prompt Creating table FACT_100198_LTV_MAC
prompt ==================================
prompt
create table FACT_100198_LTV_MAC
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_LTV_MAC
  is '�豸LTV������';
comment on column FACT_100198_LTV_MAC.statdate
  is 'ͳ������';
comment on column FACT_100198_LTV_MAC.ltvdate
  is '��ֵ����';
comment on column FACT_100198_LTV_MAC.channelid
  is '����';
comment on column FACT_100198_LTV_MAC.serverid
  is '����';
comment on column FACT_100198_LTV_MAC.appid
  is '��Ʒid';
comment on column FACT_100198_LTV_MAC.ltv_days
  is 'ltv��';
comment on column FACT_100198_LTV_MAC.payamount
  is '���ѽ��';
comment on column FACT_100198_LTV_MAC.data_source
  is '������Դ';
create index IDX64_100198 on FACT_100198_LTV_MAC (CHANNELID);
create index IDX65_100198 on FACT_100198_LTV_MAC (SERVERID);
create index IDX66_100198 on FACT_100198_LTV_MAC (STATDATE);

prompt
prompt Creating table FACT_100198_LTV_USER
prompt ===================================
prompt
create table FACT_100198_LTV_USER
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_LTV_USER
  is '�û�LTV������';
comment on column FACT_100198_LTV_USER.statdate
  is 'ͳ������';
comment on column FACT_100198_LTV_USER.ltvdate
  is '��ֵ����';
comment on column FACT_100198_LTV_USER.channelid
  is '����';
comment on column FACT_100198_LTV_USER.serverid
  is '����';
comment on column FACT_100198_LTV_USER.appid
  is '��Ʒid';
comment on column FACT_100198_LTV_USER.ltv_days
  is 'ltv��';
comment on column FACT_100198_LTV_USER.payamount
  is '���ѽ��';
comment on column FACT_100198_LTV_USER.data_source
  is '������Դ';
create index IDX67_100198 on FACT_100198_LTV_USER (CHANNELID);
create index IDX68_100198 on FACT_100198_LTV_USER (SERVERID);
create index IDX69_100198 on FACT_100198_LTV_USER (STATDATE);

prompt
prompt Creating table FACT_100198_MISS_FIRST
prompt =====================================
prompt
create table FACT_100198_MISS_FIRST
(
  statdate        VARCHAR2(10),
  channelid       VARCHAR2(50),
  serverid        VARCHAR2(50),
  appid           VARCHAR2(50),
  versionid       VARCHAR2(50),
  missionid       VARCHAR2(50),
  rolelevel       NUMBER,
  rolejob         VARCHAR2(50) default '0',
  firstenter_succ NUMBER,
  firstenter_fail NUMBER,
  loaddate        DATE,
  data_source     VARCHAR2(100)
)
;
comment on table FACT_100198_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column FACT_100198_MISS_FIRST.statdate
  is 'ͳ������';
comment on column FACT_100198_MISS_FIRST.channelid
  is '����';
comment on column FACT_100198_MISS_FIRST.serverid
  is '����';
comment on column FACT_100198_MISS_FIRST.appid
  is '��ƷID';
comment on column FACT_100198_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_MISS_FIRST.missionid
  is '�ؿ�ID';
comment on column FACT_100198_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column FACT_100198_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column FACT_100198_MISS_FIRST.firstenter_succ
  is '��һ�ν���ؿ��ɹ���';
comment on column FACT_100198_MISS_FIRST.firstenter_fail
  is '��һ�ν���ؿ�ʧ����';
comment on column FACT_100198_MISS_FIRST.data_source
  is '������Դ';
create index IDX70_100198 on FACT_100198_MISS_FIRST (CHANNELID);
create index IDX71_100198 on FACT_100198_MISS_FIRST (SERVERID);
create index IDX72_100198 on FACT_100198_MISS_FIRST (STATDATE);

prompt
prompt Creating table FACT_100198_NET
prompt ==============================
prompt
create table FACT_100198_NET
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_net    VARCHAR2(50),
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_NET
  is '������ʽ������';
comment on column FACT_100198_NET.statdate
  is 'ͳ������';
comment on column FACT_100198_NET.channelid
  is '����';
comment on column FACT_100198_NET.serverid
  is '����';
comment on column FACT_100198_NET.appid
  is '��Ʒid';
comment on column FACT_100198_NET.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_NET.dvid_net
  is '������ʽ';
comment on column FACT_100198_NET.conncount
  is '������';
comment on column FACT_100198_NET.data_source
  is '������Դ';
create index IDX73_100198 on FACT_100198_NET (CHANNELID);
create index IDX74_100198 on FACT_100198_NET (SERVERID);
create index IDX75_100198 on FACT_100198_NET (STATDATE);

prompt
prompt Creating table FACT_100198_OPERATOR
prompt ===================================
prompt
create table FACT_100198_OPERATOR
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  dvid_operator VARCHAR2(50),
  conncount     NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100198_OPERATOR
  is '��Ӫ�̷�����';
comment on column FACT_100198_OPERATOR.statdate
  is 'ͳ������';
comment on column FACT_100198_OPERATOR.channelid
  is '����';
comment on column FACT_100198_OPERATOR.serverid
  is '����';
comment on column FACT_100198_OPERATOR.appid
  is '��Ʒid';
comment on column FACT_100198_OPERATOR.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_OPERATOR.dvid_operator
  is '������ʽ';
comment on column FACT_100198_OPERATOR.conncount
  is '������';
comment on column FACT_100198_OPERATOR.data_source
  is '������Դ';
create index IDX76_100198 on FACT_100198_OPERATOR (CHANNELID);
create index IDX77_100198 on FACT_100198_OPERATOR (SERVERID);
create index IDX78_100198 on FACT_100198_OPERATOR (STATDATE);

prompt
prompt Creating table FACT_100198_ORDER
prompt ================================
prompt
create table FACT_100198_ORDER
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100198_ORDER
  is '����������';
comment on column FACT_100198_ORDER.statdate
  is 'ͳ������';
comment on column FACT_100198_ORDER.channelid
  is '����';
comment on column FACT_100198_ORDER.serverid
  is '����';
comment on column FACT_100198_ORDER.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100198_ORDER.appid
  is '��Ʒid';
comment on column FACT_100198_ORDER.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_ORDER.paysucccount
  is '�ɹ�������';
comment on column FACT_100198_ORDER.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100198_ORDER.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100198_ORDER.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100198_ORDER.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100198_ORDER.payfailnum
  is '����ʧ������';
comment on column FACT_100198_ORDER.data_source
  is '������Դ';
create index IDX79_100198 on FACT_100198_ORDER (CHANNELID);
create index IDX80_100198 on FACT_100198_ORDER (SERVERID);
create index IDX81_100198 on FACT_100198_ORDER (STATDATE);

prompt
prompt Creating table FACT_100198_ORDER_HOUR
prompt =====================================
prompt
create table FACT_100198_ORDER_HOUR
(
  statdate      VARCHAR2(20),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100198_ORDER_HOUR
  is '����Сʱ������';
comment on column FACT_100198_ORDER_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100198_ORDER_HOUR.channelid
  is '����';
comment on column FACT_100198_ORDER_HOUR.serverid
  is '����';
comment on column FACT_100198_ORDER_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100198_ORDER_HOUR.appid
  is '��Ʒid';
comment on column FACT_100198_ORDER_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_ORDER_HOUR.paysucccount
  is '�ɹ�������';
comment on column FACT_100198_ORDER_HOUR.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100198_ORDER_HOUR.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100198_ORDER_HOUR.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100198_ORDER_HOUR.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100198_ORDER_HOUR.payfailnum
  is '����ʧ������';
comment on column FACT_100198_ORDER_HOUR.data_source
  is '������Դ';
create index IDX177_100198 on FACT_100198_ORDER_HOUR (CHANNELID);
create index IDX178_100198 on FACT_100198_ORDER_HOUR (SERVERID);
create index IDX179_100198 on FACT_100198_ORDER_HOUR (STATDATE);

prompt
prompt Creating table FACT_100198_ORDER_MONTH
prompt ======================================
prompt
create table FACT_100198_ORDER_MONTH
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100198_ORDER_MONTH
  is '�¶���������';
comment on column FACT_100198_ORDER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100198_ORDER_MONTH.channelid
  is '����';
comment on column FACT_100198_ORDER_MONTH.serverid
  is '����';
comment on column FACT_100198_ORDER_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100198_ORDER_MONTH.appid
  is '��Ʒid';
comment on column FACT_100198_ORDER_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_ORDER_MONTH.paysucccount
  is '�ɹ�������';
comment on column FACT_100198_ORDER_MONTH.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100198_ORDER_MONTH.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100198_ORDER_MONTH.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100198_ORDER_MONTH.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100198_ORDER_MONTH.payfailnum
  is '����ʧ������';
comment on column FACT_100198_ORDER_MONTH.data_source
  is '������Դ';
create index IDX191_100198 on FACT_100198_ORDER_MONTH (CHANNELID);
create index IDX192_100198 on FACT_100198_ORDER_MONTH (SERVERID);
create index IDX193_100198 on FACT_100198_ORDER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100198_ORDER_WEEK
prompt =====================================
prompt
create table FACT_100198_ORDER_WEEK
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100198_ORDER_WEEK
  is '�ܶ���������';
comment on column FACT_100198_ORDER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100198_ORDER_WEEK.channelid
  is '����';
comment on column FACT_100198_ORDER_WEEK.serverid
  is '����';
comment on column FACT_100198_ORDER_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100198_ORDER_WEEK.appid
  is '��Ʒid';
comment on column FACT_100198_ORDER_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_ORDER_WEEK.paysucccount
  is '�ɹ�������';
comment on column FACT_100198_ORDER_WEEK.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100198_ORDER_WEEK.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100198_ORDER_WEEK.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100198_ORDER_WEEK.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100198_ORDER_WEEK.payfailnum
  is '����ʧ������';
comment on column FACT_100198_ORDER_WEEK.data_source
  is '������Դ';
create index IDX188_100198 on FACT_100198_ORDER_WEEK (CHANNELID);
create index IDX189_100198 on FACT_100198_ORDER_WEEK (SERVERID);
create index IDX190_100198 on FACT_100198_ORDER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100198_PAYAMOUNT_DAY
prompt ========================================
prompt
create table FACT_100198_PAYAMOUNT_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_PAYAMOUNT_DAY
  is '�ճ�ֵ��������';
comment on column FACT_100198_PAYAMOUNT_DAY.statdate
  is 'ͳ������';
comment on column FACT_100198_PAYAMOUNT_DAY.channelid
  is '����';
comment on column FACT_100198_PAYAMOUNT_DAY.serverid
  is '����';
comment on column FACT_100198_PAYAMOUNT_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100198_PAYAMOUNT_DAY.appid
  is '��Ʒid';
comment on column FACT_100198_PAYAMOUNT_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_PAYAMOUNT_DAY.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100198_PAYAMOUNT_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100198_PAYAMOUNT_DAY.data_source
  is '������Դ';
create index IDX82_100198 on FACT_100198_PAYAMOUNT_DAY (CHANNELID);
create index IDX83_100198 on FACT_100198_PAYAMOUNT_DAY (SERVERID);
create index IDX84_100198 on FACT_100198_PAYAMOUNT_DAY (STATDATE);

prompt
prompt Creating table FACT_100198_PAYAMOUNT_MONTH
prompt ==========================================
prompt
create table FACT_100198_PAYAMOUNT_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_PAYAMOUNT_MONTH
  is '�³�ֵ��������';
comment on column FACT_100198_PAYAMOUNT_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100198_PAYAMOUNT_MONTH.channelid
  is '����';
comment on column FACT_100198_PAYAMOUNT_MONTH.serverid
  is '����';
comment on column FACT_100198_PAYAMOUNT_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100198_PAYAMOUNT_MONTH.appid
  is '��Ʒid';
comment on column FACT_100198_PAYAMOUNT_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_PAYAMOUNT_MONTH.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100198_PAYAMOUNT_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100198_PAYAMOUNT_MONTH.data_source
  is '������Դ';
create index IDX88_100198 on FACT_100198_PAYAMOUNT_MONTH (CHANNELID);
create index IDX89_100198 on FACT_100198_PAYAMOUNT_MONTH (SERVERID);
create index IDX90_100198 on FACT_100198_PAYAMOUNT_MONTH (STATDATE);

prompt
prompt Creating table FACT_100198_PAYAMOUNT_WEEK
prompt =========================================
prompt
create table FACT_100198_PAYAMOUNT_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_PAYAMOUNT_WEEK
  is '�ܳ�ֵ��������';
comment on column FACT_100198_PAYAMOUNT_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100198_PAYAMOUNT_WEEK.channelid
  is '����';
comment on column FACT_100198_PAYAMOUNT_WEEK.serverid
  is '����';
comment on column FACT_100198_PAYAMOUNT_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100198_PAYAMOUNT_WEEK.appid
  is '��Ʒid';
comment on column FACT_100198_PAYAMOUNT_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_PAYAMOUNT_WEEK.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100198_PAYAMOUNT_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100198_PAYAMOUNT_WEEK.data_source
  is '������Դ';
create index IDX85_100198 on FACT_100198_PAYAMOUNT_WEEK (CHANNELID);
create index IDX86_100198 on FACT_100198_PAYAMOUNT_WEEK (SERVERID);
create index IDX87_100198 on FACT_100198_PAYAMOUNT_WEEK (STATDATE);

prompt
prompt Creating table FACT_100198_PAYNUM_DAY
prompt =====================================
prompt
create table FACT_100198_PAYNUM_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_PAYNUM_DAY
  is '�ճ�ֵ����������';
comment on column FACT_100198_PAYNUM_DAY.statdate
  is 'ͳ������';
comment on column FACT_100198_PAYNUM_DAY.channelid
  is '����';
comment on column FACT_100198_PAYNUM_DAY.serverid
  is '����';
comment on column FACT_100198_PAYNUM_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100198_PAYNUM_DAY.appid
  is '��Ʒid';
comment on column FACT_100198_PAYNUM_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_PAYNUM_DAY.paynum
  is '��ֵ����';
comment on column FACT_100198_PAYNUM_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100198_PAYNUM_DAY.data_source
  is '������Դ';
create index IDX97_100198 on FACT_100198_PAYNUM_DAY (CHANNELID);
create index IDX98_100198 on FACT_100198_PAYNUM_DAY (SERVERID);
create index IDX99_100198 on FACT_100198_PAYNUM_DAY (STATDATE);

prompt
prompt Creating table FACT_100198_PAYNUM_MONTH
prompt =======================================
prompt
create table FACT_100198_PAYNUM_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_PAYNUM_MONTH
  is '�³�ֵ����������';
comment on column FACT_100198_PAYNUM_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100198_PAYNUM_MONTH.channelid
  is '����';
comment on column FACT_100198_PAYNUM_MONTH.serverid
  is '����';
comment on column FACT_100198_PAYNUM_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100198_PAYNUM_MONTH.appid
  is '��Ʒid';
comment on column FACT_100198_PAYNUM_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_PAYNUM_MONTH.paynum
  is '��ֵ����';
comment on column FACT_100198_PAYNUM_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100198_PAYNUM_MONTH.data_source
  is '������Դ';
create index IDX91_100198 on FACT_100198_PAYNUM_MONTH (CHANNELID);
create index IDX92_100198 on FACT_100198_PAYNUM_MONTH (SERVERID);
create index IDX93_100198 on FACT_100198_PAYNUM_MONTH (STATDATE);

prompt
prompt Creating table FACT_100198_PAYNUM_WEEK
prompt ======================================
prompt
create table FACT_100198_PAYNUM_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_PAYNUM_WEEK
  is '�ܳ�ֵ����������';
comment on column FACT_100198_PAYNUM_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100198_PAYNUM_WEEK.channelid
  is '����';
comment on column FACT_100198_PAYNUM_WEEK.serverid
  is '����';
comment on column FACT_100198_PAYNUM_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100198_PAYNUM_WEEK.appid
  is '��Ʒid';
comment on column FACT_100198_PAYNUM_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_PAYNUM_WEEK.paynum
  is '��ֵ����';
comment on column FACT_100198_PAYNUM_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100198_PAYNUM_WEEK.data_source
  is '������Դ';
create index IDX94_100198 on FACT_100198_PAYNUM_WEEK (CHANNELID);
create index IDX95_100198 on FACT_100198_PAYNUM_WEEK (SERVERID);
create index IDX96_100198 on FACT_100198_PAYNUM_WEEK (STATDATE);

prompt
prompt Creating table FACT_100198_PAYTYPE
prompt ==================================
prompt
create table FACT_100198_PAYTYPE
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paytypeid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_PAYTYPE
  is '��ֵ���ͷ�����';
comment on column FACT_100198_PAYTYPE.statdate
  is 'ͳ������';
comment on column FACT_100198_PAYTYPE.channelid
  is '����';
comment on column FACT_100198_PAYTYPE.serverid
  is '����';
comment on column FACT_100198_PAYTYPE.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100198_PAYTYPE.appid
  is '��Ʒid';
comment on column FACT_100198_PAYTYPE.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_PAYTYPE.paytypeid
  is '��ֵ����';
comment on column FACT_100198_PAYTYPE.payamount
  is '��ֵ���';
comment on column FACT_100198_PAYTYPE.paycount
  is '��ֵ����';
comment on column FACT_100198_PAYTYPE.paynum
  is '��ֵ����';
comment on column FACT_100198_PAYTYPE.data_source
  is '������Դ';
create index IDX100_100198 on FACT_100198_PAYTYPE (CHANNELID);
create index IDX101_100198 on FACT_100198_PAYTYPE (SERVERID);
create index IDX102_100198 on FACT_100198_PAYTYPE (STATDATE);

prompt
prompt Creating table FACT_100198_PAYWAY
prompt =================================
prompt
create table FACT_100198_PAYWAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paywayid    VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_PAYWAY
  is '��ֵ��ʽ������';
comment on column FACT_100198_PAYWAY.statdate
  is 'ͳ������';
comment on column FACT_100198_PAYWAY.channelid
  is '����';
comment on column FACT_100198_PAYWAY.serverid
  is '����';
comment on column FACT_100198_PAYWAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100198_PAYWAY.appid
  is '��Ʒid';
comment on column FACT_100198_PAYWAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_PAYWAY.paywayid
  is '��ֵ��ʽ';
comment on column FACT_100198_PAYWAY.payamount
  is '��ֵ���';
comment on column FACT_100198_PAYWAY.paycount
  is '��ֵ����';
comment on column FACT_100198_PAYWAY.paynum
  is '��ֵ����';
comment on column FACT_100198_PAYWAY.data_source
  is '������Դ';
create index IDX103_100198 on FACT_100198_PAYWAY (CHANNELID);
create index IDX104_100198 on FACT_100198_PAYWAY (SERVERID);
create index IDX105_100198 on FACT_100198_PAYWAY (STATDATE);

prompt
prompt Creating table FACT_100198_REGION
prompt =================================
prompt
create table FACT_100198_REGION
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  country     VARCHAR2(50),
  province    VARCHAR2(50),
  city        VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_REGION
  is '���������';
comment on column FACT_100198_REGION.statdate
  is 'ͳ������';
comment on column FACT_100198_REGION.channelid
  is '����';
comment on column FACT_100198_REGION.serverid
  is '����';
comment on column FACT_100198_REGION.appid
  is '��Ʒid';
comment on column FACT_100198_REGION.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_REGION.country
  is '����';
comment on column FACT_100198_REGION.province
  is 'ʡ';
comment on column FACT_100198_REGION.city
  is '��';
comment on column FACT_100198_REGION.newcount
  is '������';
comment on column FACT_100198_REGION.conncount
  is '������';
comment on column FACT_100198_REGION.paycount
  is '������';
comment on column FACT_100198_REGION.payamount
  is '���ѽ��';
comment on column FACT_100198_REGION.data_source
  is '������Դ';
create index IDX106_100198 on FACT_100198_REGION (CHANNELID);
create index IDX107_100198 on FACT_100198_REGION (SERVERID);
create index IDX108_100198 on FACT_100198_REGION (STATDATE);

prompt
prompt Creating table FACT_100198_REMAIN_MAC
prompt =====================================
prompt
create table FACT_100198_REMAIN_MAC
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_REMAIN_MAC
  is '�豸�����';
comment on column FACT_100198_REMAIN_MAC.statdate
  is 'ͳ������';
comment on column FACT_100198_REMAIN_MAC.conndate
  is '��������';
comment on column FACT_100198_REMAIN_MAC.channelid
  is '����ID';
comment on column FACT_100198_REMAIN_MAC.serverid
  is '����ID';
comment on column FACT_100198_REMAIN_MAC.appid
  is '��ƷID';
comment on column FACT_100198_REMAIN_MAC.remain_days
  is '��������';
comment on column FACT_100198_REMAIN_MAC.new_remain
  is '��������';
comment on column FACT_100198_REMAIN_MAC.conn_remain
  is '��������';
comment on column FACT_100198_REMAIN_MAC.pay_remain
  is '��������';
comment on column FACT_100198_REMAIN_MAC.data_source
  is '����Դ';
create index IDX109_100198 on FACT_100198_REMAIN_MAC (CHANNELID);
create index IDX110_100198 on FACT_100198_REMAIN_MAC (SERVERID);
create index IDX111_100198 on FACT_100198_REMAIN_MAC (STATDATE);

prompt
prompt Creating table FACT_100198_REMAIN_USER
prompt ======================================
prompt
create table FACT_100198_REMAIN_USER
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_REMAIN_USER
  is '�û������';
comment on column FACT_100198_REMAIN_USER.statdate
  is 'ͳ������';
comment on column FACT_100198_REMAIN_USER.conndate
  is '��������';
comment on column FACT_100198_REMAIN_USER.channelid
  is '����ID';
comment on column FACT_100198_REMAIN_USER.serverid
  is '����ID';
comment on column FACT_100198_REMAIN_USER.appid
  is '��ƷID';
comment on column FACT_100198_REMAIN_USER.remain_days
  is '��������';
comment on column FACT_100198_REMAIN_USER.new_remain
  is '��������';
comment on column FACT_100198_REMAIN_USER.conn_remain
  is '��������';
comment on column FACT_100198_REMAIN_USER.pay_remain
  is '��������';
comment on column FACT_100198_REMAIN_USER.data_source
  is '����Դ';
create index IDX112_100198 on FACT_100198_REMAIN_USER (CHANNELID);
create index IDX113_100198 on FACT_100198_REMAIN_USER (SERVERID);
create index IDX114_100198 on FACT_100198_REMAIN_USER (STATDATE);

prompt
prompt Creating table FACT_100198_VC
prompt =============================
prompt
create table FACT_100198_VC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcamount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100198_VC
  is '������ҷ�����';
comment on column FACT_100198_VC.statdate
  is 'ͳ������';
comment on column FACT_100198_VC.channelid
  is '����';
comment on column FACT_100198_VC.serverid
  is '����';
comment on column FACT_100198_VC.appid
  is '��Ʒid';
comment on column FACT_100198_VC.versionid
  is '��Ʒ�汾';
comment on column FACT_100198_VC.vctype
  is '�����������';
comment on column FACT_100198_VC.vcusetype
  is '�������ʹ������';
comment on column FACT_100198_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column FACT_100198_VC.vcamount
  is '������ҽ��';
comment on column FACT_100198_VC.data_source
  is '������Դ';
create index IDX115_100198 on FACT_100198_VC (CHANNELID);
create index IDX116_100198 on FACT_100198_VC (SERVERID);
create index IDX117_100198 on FACT_100198_VC (STATDATE);

prompt
prompt Creating table FACT_100201_BACK_MAC
prompt ===================================
prompt
create table FACT_100201_BACK_MAC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_BACK_MAC
  is '�豸����������';
comment on column FACT_100201_BACK_MAC.statdate
  is 'ͳ������';
comment on column FACT_100201_BACK_MAC.channelid
  is '����ID';
comment on column FACT_100201_BACK_MAC.serverid
  is '����ID';
comment on column FACT_100201_BACK_MAC.appid
  is '��ƷID';
comment on column FACT_100201_BACK_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100201_BACK_MAC.back_conn
  is '��Ծ�豸������';
comment on column FACT_100201_BACK_MAC.back_pay
  is '�����豸������';
comment on column FACT_100201_BACK_MAC.data_source
  is '����Դ';
create index IDX1_100201 on FACT_100201_BACK_MAC (CHANNELID);
create index IDX2_100201 on FACT_100201_BACK_MAC (SERVERID);
create index IDX3_100201 on FACT_100201_BACK_MAC (STATDATE);

prompt
prompt Creating table FACT_100201_BACK_MAC_MONTH
prompt =========================================
prompt
create table FACT_100201_BACK_MAC_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_BACK_MAC_MONTH
  is '�豸����������';
comment on column FACT_100201_BACK_MAC_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100201_BACK_MAC_MONTH.channelid
  is '����ID';
comment on column FACT_100201_BACK_MAC_MONTH.serverid
  is '����ID';
comment on column FACT_100201_BACK_MAC_MONTH.appid
  is '��ƷID';
comment on column FACT_100201_BACK_MAC_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100201_BACK_MAC_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100201_BACK_MAC_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100201_BACK_MAC_MONTH.data_source
  is '����Դ';
create index IDX4_100201 on FACT_100201_BACK_MAC_MONTH (CHANNELID);
create index IDX5_100201 on FACT_100201_BACK_MAC_MONTH (SERVERID);
create index IDX6_100201 on FACT_100201_BACK_MAC_MONTH (STATDATE);

prompt
prompt Creating table FACT_100201_BACK_MAC_WEEK
prompt ========================================
prompt
create table FACT_100201_BACK_MAC_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_BACK_MAC_WEEK
  is '�豸����������';
comment on column FACT_100201_BACK_MAC_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100201_BACK_MAC_WEEK.channelid
  is '����ID';
comment on column FACT_100201_BACK_MAC_WEEK.serverid
  is '����ID';
comment on column FACT_100201_BACK_MAC_WEEK.appid
  is '��ƷID';
comment on column FACT_100201_BACK_MAC_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100201_BACK_MAC_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100201_BACK_MAC_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100201_BACK_MAC_WEEK.data_source
  is '����Դ';
create index IDX7_100201 on FACT_100201_BACK_MAC_WEEK (CHANNELID);
create index IDX8_100201 on FACT_100201_BACK_MAC_WEEK (SERVERID);
create index IDX9_100201 on FACT_100201_BACK_MAC_WEEK (STATDATE);

prompt
prompt Creating table FACT_100201_BACK_USER
prompt ====================================
prompt
create table FACT_100201_BACK_USER
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_BACK_USER
  is '�û�����������';
comment on column FACT_100201_BACK_USER.statdate
  is 'ͳ������';
comment on column FACT_100201_BACK_USER.channelid
  is '����ID';
comment on column FACT_100201_BACK_USER.serverid
  is '����ID';
comment on column FACT_100201_BACK_USER.appid
  is '��ƷID';
comment on column FACT_100201_BACK_USER.lost_days
  is '��ʧ����';
comment on column FACT_100201_BACK_USER.back_conn
  is '��Ծ�û�������';
comment on column FACT_100201_BACK_USER.back_pay
  is '�����û�������';
comment on column FACT_100201_BACK_USER.data_source
  is '����Դ';
create index IDX16_100201 on FACT_100201_BACK_USER (CHANNELID);
create index IDX17_100201 on FACT_100201_BACK_USER (SERVERID);
create index IDX18_100201 on FACT_100201_BACK_USER (STATDATE);

prompt
prompt Creating table FACT_100201_BACK_USER_MONTH
prompt ==========================================
prompt
create table FACT_100201_BACK_USER_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_BACK_USER_MONTH
  is '�豸����������';
comment on column FACT_100201_BACK_USER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100201_BACK_USER_MONTH.channelid
  is '����ID';
comment on column FACT_100201_BACK_USER_MONTH.serverid
  is '����ID';
comment on column FACT_100201_BACK_USER_MONTH.appid
  is '��ƷID';
comment on column FACT_100201_BACK_USER_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100201_BACK_USER_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100201_BACK_USER_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100201_BACK_USER_MONTH.data_source
  is '����Դ';
create index IDX13_100201 on FACT_100201_BACK_USER_MONTH (CHANNELID);
create index IDX14_100201 on FACT_100201_BACK_USER_MONTH (SERVERID);
create index IDX15_100201 on FACT_100201_BACK_USER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100201_BACK_USER_WEEK
prompt =========================================
prompt
create table FACT_100201_BACK_USER_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_BACK_USER_WEEK
  is '�豸����������';
comment on column FACT_100201_BACK_USER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100201_BACK_USER_WEEK.channelid
  is '����ID';
comment on column FACT_100201_BACK_USER_WEEK.serverid
  is '����ID';
comment on column FACT_100201_BACK_USER_WEEK.appid
  is '��ƷID';
comment on column FACT_100201_BACK_USER_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100201_BACK_USER_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100201_BACK_USER_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100201_BACK_USER_WEEK.data_source
  is '����Դ';
create index IDX10_100201 on FACT_100201_BACK_USER_WEEK (CHANNELID);
create index IDX11_100201 on FACT_100201_BACK_USER_WEEK (SERVERID);
create index IDX12_100201 on FACT_100201_BACK_USER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100201_CEVENT
prompt =================================
prompt
create table FACT_100201_CEVENT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  eventkey    VARCHAR2(50),
  eventcount  NUMBER,
  eventnum    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_CEVENT
  is '�Զ��������';
comment on column FACT_100201_CEVENT.statdate
  is 'ͳ������';
comment on column FACT_100201_CEVENT.channelid
  is '����';
comment on column FACT_100201_CEVENT.serverid
  is '����';
comment on column FACT_100201_CEVENT.appid
  is '��Ʒid';
comment on column FACT_100201_CEVENT.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100201_CEVENT.eventcount
  is '�¼��û���';
comment on column FACT_100201_CEVENT.eventnum
  is '�¼�����';
comment on column FACT_100201_CEVENT.data_source
  is '������Դ';
create index IDX181_100201 on FACT_100201_CEVENT (CHANNELID);
create index IDX182_100201 on FACT_100201_CEVENT (SERVERID);
create index IDX183_100201 on FACT_100201_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100201_CEVENT_PAR
prompt =====================================
prompt
create table FACT_100201_CEVENT_PAR
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  ilevel         NUMBER,
  eventkey       VARCHAR2(100),
  eventpar_key   VARCHAR2(100),
  eventpar_value VARCHAR2(100),
  eventcount     NUMBER,
  eventnum       NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100201_CEVENT_PAR
  is '�Զ������������';
comment on column FACT_100201_CEVENT_PAR.statdate
  is 'ͳ������';
comment on column FACT_100201_CEVENT_PAR.channelid
  is '����';
comment on column FACT_100201_CEVENT_PAR.serverid
  is '����';
comment on column FACT_100201_CEVENT_PAR.appid
  is '��Ʒid';
comment on column FACT_100201_CEVENT_PAR.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_CEVENT_PAR.ilevel
  is '��ɫ�ȼ�';
comment on column FACT_100201_CEVENT_PAR.eventkey
  is '�¼�����';
comment on column FACT_100201_CEVENT_PAR.eventpar_key
  is '�¼�����';
comment on column FACT_100201_CEVENT_PAR.eventpar_value
  is '�¼�����ֵ';
comment on column FACT_100201_CEVENT_PAR.eventcount
  is '�¼��û���';
comment on column FACT_100201_CEVENT_PAR.eventnum
  is '�¼�����';
comment on column FACT_100201_CEVENT_PAR.data_source
  is '������Դ';
create index IDX185_100201 on FACT_100201_CEVENT_PAR (CHANNELID);
create index IDX186_100201 on FACT_100201_CEVENT_PAR (SERVERID);
create index IDX187_100201 on FACT_100201_CEVENT_PAR (STATDATE);

prompt
prompt Creating table FACT_100201_COMP_CEVENT
prompt ======================================
prompt
create table FACT_100201_COMP_CEVENT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(10),
  channelid   VARCHAR2(50),
  gameversion VARCHAR2(50),
  serverid    VARCHAR2(50),
  ilevel      NUMBER,
  eventkey    VARCHAR2(100),
  compid      VARCHAR2(50),
  caltype     VARCHAR2(50),
  dimpars     VARCHAR2(2000),
  comp_data   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_COMP_CEVENT
  is '�Զ����¼���Ϸ�����';
comment on column FACT_100201_COMP_CEVENT.statdate
  is '����';
comment on column FACT_100201_COMP_CEVENT.appid
  is '��Ϸ�� appid';
comment on column FACT_100201_COMP_CEVENT.channelid
  is '���� ID';
comment on column FACT_100201_COMP_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column FACT_100201_COMP_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column FACT_100201_COMP_CEVENT.ilevel
  is '��ҵȼ�';
comment on column FACT_100201_COMP_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100201_COMP_CEVENT.compid
  is '��ϼ����¼�ID';
comment on column FACT_100201_COMP_CEVENT.caltype
  is '��ϼ����¼���������';
comment on column FACT_100201_COMP_CEVENT.dimpars
  is '��ϲ���';
comment on column FACT_100201_COMP_CEVENT.comp_data
  is '��ϼ�����';
create index IDX184_100201 on FACT_100201_COMP_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100201_DAILY_REPORT
prompt =======================================
prompt
create table FACT_100201_DAILY_REPORT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_DAILY_REPORT
  is '�ձ�����';
comment on column FACT_100201_DAILY_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100201_DAILY_REPORT.appid
  is '��ƷID';
comment on column FACT_100201_DAILY_REPORT.channelid
  is '����';
comment on column FACT_100201_DAILY_REPORT.serverid
  is '����';
comment on column FACT_100201_DAILY_REPORT.indexid
  is 'ָ��';
comment on column FACT_100201_DAILY_REPORT.indtype
  is 'ָ������';
comment on column FACT_100201_DAILY_REPORT.rpt_data
  is '����';
create index IDX176_100201 on FACT_100201_DAILY_REPORT (STATDATE);

prompt
prompt Creating table FACT_100201_DVID
prompt ===============================
prompt
create table FACT_100201_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_model  VARCHAR2(200),
  dvid_res    VARCHAR2(50),
  dvid_os     VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_DVID
  is '�豸������';
comment on column FACT_100201_DVID.statdate
  is 'ͳ������';
comment on column FACT_100201_DVID.channelid
  is '����';
comment on column FACT_100201_DVID.serverid
  is '����';
comment on column FACT_100201_DVID.appid
  is '��Ʒid';
comment on column FACT_100201_DVID.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_DVID.dvid_model
  is '����';
comment on column FACT_100201_DVID.dvid_res
  is '�豸�ֱ���';
comment on column FACT_100201_DVID.dvid_os
  is '�豸����ϵͳ';
comment on column FACT_100201_DVID.newcount
  is '�����û���';
comment on column FACT_100201_DVID.conncount
  is '�����û���';
comment on column FACT_100201_DVID.data_source
  is '������Դ';
create index IDX19_100201 on FACT_100201_DVID (CHANNELID);
create index IDX20_100201 on FACT_100201_DVID (SERVERID);
create index IDX21_100201 on FACT_100201_DVID (STATDATE);

prompt
prompt Creating table FACT_100201_FIRSTPAY
prompt ===================================
prompt
create table FACT_100201_FIRSTPAY
(
  statdate         VARCHAR2(10),
  firstpaydate     VARCHAR2(10),
  channelid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  datatype         VARCHAR2(50),
  appid            VARCHAR2(50),
  first_payfromreg NUMBER,
  first_paycount   NUMBER,
  payamount        NUMBER,
  loaddate         DATE default SYSDATE,
  data_source      VARCHAR2(100)
)
;
comment on table FACT_100201_FIRSTPAY
  is '�����û��״γ�ֵ������';
comment on column FACT_100201_FIRSTPAY.statdate
  is 'ͳ������';
comment on column FACT_100201_FIRSTPAY.firstpaydate
  is '�״θ�������';
comment on column FACT_100201_FIRSTPAY.channelid
  is '����';
comment on column FACT_100201_FIRSTPAY.serverid
  is '����';
comment on column FACT_100201_FIRSTPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100201_FIRSTPAY.appid
  is '��Ʒid';
comment on column FACT_100201_FIRSTPAY.first_payfromreg
  is 'ע���ڼ��쿪ʼ��ֵ(1��2��..7..30..)';
comment on column FACT_100201_FIRSTPAY.first_paycount
  is '���������û���';
comment on column FACT_100201_FIRSTPAY.payamount
  is '�ۼƵ��ڼ���ĳ�ֵ�ܶ�';
comment on column FACT_100201_FIRSTPAY.data_source
  is '������Դ';
create index IDX22_100201 on FACT_100201_FIRSTPAY (CHANNELID);
create index IDX23_100201 on FACT_100201_FIRSTPAY (SERVERID);
create index IDX24_100201 on FACT_100201_FIRSTPAY (STATDATE);

prompt
prompt Creating table FACT_100201_FIRSTPAY_AMOUNT
prompt ==========================================
prompt
create table FACT_100201_FIRSTPAY_AMOUNT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_FIRSTPAY_AMOUNT
  is '�״θ��ѽ�������';
comment on column FACT_100201_FIRSTPAY_AMOUNT.statdate
  is 'ͳ������';
comment on column FACT_100201_FIRSTPAY_AMOUNT.channelid
  is '����';
comment on column FACT_100201_FIRSTPAY_AMOUNT.serverid
  is '��������';
comment on column FACT_100201_FIRSTPAY_AMOUNT.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100201_FIRSTPAY_AMOUNT.appid
  is '��Ʒid';
comment on column FACT_100201_FIRSTPAY_AMOUNT.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_FIRSTPAY_AMOUNT.payamount
  is '�״θ��ѽ��';
comment on column FACT_100201_FIRSTPAY_AMOUNT.paycount
  is '�״θ��ѽ���Ӧ������';
create index IDX25_100201 on FACT_100201_FIRSTPAY_AMOUNT (CHANNELID);
create index IDX26_100201 on FACT_100201_FIRSTPAY_AMOUNT (SERVERID);
create index IDX27_100201 on FACT_100201_FIRSTPAY_AMOUNT (STATDATE);

prompt
prompt Creating table FACT_100201_GENERAL_DAY
prompt ======================================
prompt
create table FACT_100201_GENERAL_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_GENERAL_DAY
  is '�ջ���������';
comment on column FACT_100201_GENERAL_DAY.statdate
  is 'ͳ������';
comment on column FACT_100201_GENERAL_DAY.channelid
  is '����';
comment on column FACT_100201_GENERAL_DAY.serverid
  is '����';
comment on column FACT_100201_GENERAL_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100201_GENERAL_DAY.appid
  is '��Ʒid';
comment on column FACT_100201_GENERAL_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_GENERAL_DAY.newcount
  is '������';
comment on column FACT_100201_GENERAL_DAY.conncount
  is '������';
comment on column FACT_100201_GENERAL_DAY.paycount
  is '������';
comment on column FACT_100201_GENERAL_DAY.payamount
  is '���ѽ��';
comment on column FACT_100201_GENERAL_DAY.data_source
  is '������Դ';
create index IDX28_100201 on FACT_100201_GENERAL_DAY (CHANNELID);
create index IDX29_100201 on FACT_100201_GENERAL_DAY (SERVERID);
create index IDX30_100201 on FACT_100201_GENERAL_DAY (STATDATE);

prompt
prompt Creating table FACT_100201_GENERAL_DAY_DVID
prompt ===========================================
prompt
create table FACT_100201_GENERAL_DAY_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_GENERAL_DAY_DVID
  is '���豸����������';
comment on column FACT_100201_GENERAL_DAY_DVID.statdate
  is 'ͳ������';
comment on column FACT_100201_GENERAL_DAY_DVID.channelid
  is '����';
comment on column FACT_100201_GENERAL_DAY_DVID.appid
  is '��Ʒid';
comment on column FACT_100201_GENERAL_DAY_DVID.newcount
  is '������';
comment on column FACT_100201_GENERAL_DAY_DVID.conncount
  is '������';
comment on column FACT_100201_GENERAL_DAY_DVID.data_source
  is '������Դ';
create index IDX31_100201 on FACT_100201_GENERAL_DAY_DVID (CHANNELID);
create index IDX33_100201 on FACT_100201_GENERAL_DAY_DVID (STATDATE);

prompt
prompt Creating table FACT_100201_GENERAL_HOUR
prompt =======================================
prompt
create table FACT_100201_GENERAL_HOUR
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_GENERAL_HOUR
  is 'Сʱ����������';
comment on column FACT_100201_GENERAL_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100201_GENERAL_HOUR.channelid
  is '����';
comment on column FACT_100201_GENERAL_HOUR.serverid
  is '����';
comment on column FACT_100201_GENERAL_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100201_GENERAL_HOUR.appid
  is '��Ʒid';
comment on column FACT_100201_GENERAL_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_GENERAL_HOUR.newcount
  is '������';
comment on column FACT_100201_GENERAL_HOUR.conncount
  is '������';
comment on column FACT_100201_GENERAL_HOUR.paycount
  is '������';
comment on column FACT_100201_GENERAL_HOUR.payamount
  is '���ѽ��';
comment on column FACT_100201_GENERAL_HOUR.data_source
  is '������Դ';
create index IDX34_100201 on FACT_100201_GENERAL_HOUR (CHANNELID);
create index IDX35_100201 on FACT_100201_GENERAL_HOUR (SERVERID);
create index IDX36_100201 on FACT_100201_GENERAL_HOUR (STATDATE);

prompt
prompt Creating table FACT_100201_GENERAL_HOUR_DVID
prompt ============================================
prompt
create table FACT_100201_GENERAL_HOUR_DVID
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_GENERAL_HOUR_DVID
  is 'Сʱ�豸����������';
comment on column FACT_100201_GENERAL_HOUR_DVID.statdate
  is 'ͳ������';
comment on column FACT_100201_GENERAL_HOUR_DVID.channelid
  is '����';
comment on column FACT_100201_GENERAL_HOUR_DVID.appid
  is '��Ʒid';
comment on column FACT_100201_GENERAL_HOUR_DVID.newcount
  is '������';
comment on column FACT_100201_GENERAL_HOUR_DVID.conncount
  is '������';
comment on column FACT_100201_GENERAL_HOUR_DVID.data_source
  is '������Դ';
create index IDX37_100201 on FACT_100201_GENERAL_HOUR_DVID (CHANNELID);
create index IDX39_100201 on FACT_100201_GENERAL_HOUR_DVID (STATDATE);

prompt
prompt Creating table FACT_100201_GENERAL_LEVEL
prompt ========================================
prompt
create table FACT_100201_GENERAL_LEVEL
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  rolelevel   NUMBER,
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_GENERAL_LEVEL
  is '�û��ȼ�������';
comment on column FACT_100201_GENERAL_LEVEL.statdate
  is 'ͳ������';
comment on column FACT_100201_GENERAL_LEVEL.channelid
  is '����';
comment on column FACT_100201_GENERAL_LEVEL.serverid
  is '����';
comment on column FACT_100201_GENERAL_LEVEL.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100201_GENERAL_LEVEL.appid
  is '��Ʒid';
comment on column FACT_100201_GENERAL_LEVEL.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_GENERAL_LEVEL.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100201_GENERAL_LEVEL.newcount
  is '������';
comment on column FACT_100201_GENERAL_LEVEL.conncount
  is '������';
comment on column FACT_100201_GENERAL_LEVEL.paycount
  is '������';
comment on column FACT_100201_GENERAL_LEVEL.payamount
  is '���ѽ��';
comment on column FACT_100201_GENERAL_LEVEL.data_source
  is '������Դ';
create index IDX40_100201 on FACT_100201_GENERAL_LEVEL (CHANNELID);
create index IDX41_100201 on FACT_100201_GENERAL_LEVEL (SERVERID);
create index IDX42_100201 on FACT_100201_GENERAL_LEVEL (STATDATE);

prompt
prompt Creating table FACT_100201_GENERAL_MONTH
prompt ========================================
prompt
create table FACT_100201_GENERAL_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_GENERAL_MONTH
  is '�»���������';
comment on column FACT_100201_GENERAL_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100201_GENERAL_MONTH.channelid
  is '����';
comment on column FACT_100201_GENERAL_MONTH.serverid
  is '����';
comment on column FACT_100201_GENERAL_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100201_GENERAL_MONTH.appid
  is '��Ʒid';
comment on column FACT_100201_GENERAL_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_GENERAL_MONTH.newcount
  is '������';
comment on column FACT_100201_GENERAL_MONTH.conncount
  is '������';
comment on column FACT_100201_GENERAL_MONTH.paycount
  is '������';
comment on column FACT_100201_GENERAL_MONTH.payamount
  is '���ѽ��';
comment on column FACT_100201_GENERAL_MONTH.data_source
  is '������Դ';
create index IDX43_100201 on FACT_100201_GENERAL_MONTH (CHANNELID);
create index IDX44_100201 on FACT_100201_GENERAL_MONTH (SERVERID);
create index IDX45_100201 on FACT_100201_GENERAL_MONTH (STATDATE);

prompt
prompt Creating table FACT_100201_GENERAL_MONTH_DVID
prompt =============================================
prompt
create table FACT_100201_GENERAL_MONTH_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_GENERAL_MONTH_DVID
  is '���豸����������';
comment on column FACT_100201_GENERAL_MONTH_DVID.statdate
  is 'ͳ������';
comment on column FACT_100201_GENERAL_MONTH_DVID.channelid
  is '����';
comment on column FACT_100201_GENERAL_MONTH_DVID.appid
  is '��Ʒid';
comment on column FACT_100201_GENERAL_MONTH_DVID.newcount
  is '������';
comment on column FACT_100201_GENERAL_MONTH_DVID.conncount
  is '������';
comment on column FACT_100201_GENERAL_MONTH_DVID.data_source
  is '������Դ';
create index IDX46_100201 on FACT_100201_GENERAL_MONTH_DVID (CHANNELID);
create index IDX48_100201 on FACT_100201_GENERAL_MONTH_DVID (STATDATE);

prompt
prompt Creating table FACT_100201_GENERAL_WEEK
prompt =======================================
prompt
create table FACT_100201_GENERAL_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_GENERAL_WEEK
  is '�ܻ���������';
comment on column FACT_100201_GENERAL_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100201_GENERAL_WEEK.channelid
  is '����';
comment on column FACT_100201_GENERAL_WEEK.serverid
  is '����';
comment on column FACT_100201_GENERAL_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100201_GENERAL_WEEK.appid
  is '��Ʒid';
comment on column FACT_100201_GENERAL_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_GENERAL_WEEK.newcount
  is '������';
comment on column FACT_100201_GENERAL_WEEK.conncount
  is '������';
comment on column FACT_100201_GENERAL_WEEK.paycount
  is '������';
comment on column FACT_100201_GENERAL_WEEK.payamount
  is '���ѽ��';
comment on column FACT_100201_GENERAL_WEEK.data_source
  is '������Դ';
create index IDX52_100201 on FACT_100201_GENERAL_WEEK (CHANNELID);
create index IDX53_100201 on FACT_100201_GENERAL_WEEK (SERVERID);
create index IDX54_100201 on FACT_100201_GENERAL_WEEK (STATDATE);

prompt
prompt Creating table FACT_100201_GENERAL_WEEK_DVID
prompt ============================================
prompt
create table FACT_100201_GENERAL_WEEK_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_GENERAL_WEEK_DVID
  is '���豸����������';
comment on column FACT_100201_GENERAL_WEEK_DVID.statdate
  is 'ͳ������';
comment on column FACT_100201_GENERAL_WEEK_DVID.channelid
  is '����';
comment on column FACT_100201_GENERAL_WEEK_DVID.appid
  is '��Ʒid';
comment on column FACT_100201_GENERAL_WEEK_DVID.newcount
  is '������';
comment on column FACT_100201_GENERAL_WEEK_DVID.conncount
  is '������';
comment on column FACT_100201_GENERAL_WEEK_DVID.data_source
  is '������Դ';
create index IDX49_100201 on FACT_100201_GENERAL_WEEK_DVID (CHANNELID);
create index IDX51_100201 on FACT_100201_GENERAL_WEEK_DVID (STATDATE);

prompt
prompt Creating table FACT_100201_HOUR_REPORT
prompt ======================================
prompt
create table FACT_100201_HOUR_REPORT
(
  statdate    VARCHAR2(20),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_HOUR_REPORT
  is '�ձ�Сʱ����';
comment on column FACT_100201_HOUR_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100201_HOUR_REPORT.appid
  is '��ƷID';
comment on column FACT_100201_HOUR_REPORT.channelid
  is '����';
comment on column FACT_100201_HOUR_REPORT.serverid
  is '����';
comment on column FACT_100201_HOUR_REPORT.indexid
  is 'ָ��';
comment on column FACT_100201_HOUR_REPORT.indtype
  is 'ָ������';
comment on column FACT_100201_HOUR_REPORT.rpt_data
  is '����';

prompt
prompt Creating table FACT_100201_LEVELPAY
prompt ===================================
prompt
create table FACT_100201_LEVELPAY
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  datatype       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  rolelevel      NUMBER,
  paycount       NUMBER,
  first_paycount NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100201_LEVELPAY
  is '�û���ɫ�ȼ����ѷ�����';
comment on column FACT_100201_LEVELPAY.statdate
  is 'ͳ������';
comment on column FACT_100201_LEVELPAY.channelid
  is '����';
comment on column FACT_100201_LEVELPAY.serverid
  is '����';
comment on column FACT_100201_LEVELPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100201_LEVELPAY.appid
  is '��Ʒid';
comment on column FACT_100201_LEVELPAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_LEVELPAY.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100201_LEVELPAY.paycount
  is '�����û���';
comment on column FACT_100201_LEVELPAY.first_paycount
  is '���������û������״θ����û���';
comment on column FACT_100201_LEVELPAY.data_source
  is '������Դ';
create index IDX55_100201 on FACT_100201_LEVELPAY (CHANNELID);
create index IDX56_100201 on FACT_100201_LEVELPAY (SERVERID);
create index IDX57_100201 on FACT_100201_LEVELPAY (STATDATE);

prompt
prompt Creating table FACT_100201_LOST_MAC
prompt ===================================
prompt
create table FACT_100201_LOST_MAC
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_LOST_MAC
  is '�豸��ʧ������';
comment on column FACT_100201_LOST_MAC.statdate
  is 'ͳ������';
comment on column FACT_100201_LOST_MAC.lostdate
  is '��ʧ����';
comment on column FACT_100201_LOST_MAC.channelid
  is '����ID';
comment on column FACT_100201_LOST_MAC.serverid
  is '����ID';
comment on column FACT_100201_LOST_MAC.appid
  is '��ƷID';
comment on column FACT_100201_LOST_MAC.rolelevel
  is '��ʧʱ�ȼ�';
comment on column FACT_100201_LOST_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100201_LOST_MAC.lost_conn
  is '��Ծ�豸��ʧ';
comment on column FACT_100201_LOST_MAC.lost_pay
  is '�����豸��ʧ';
comment on column FACT_100201_LOST_MAC.data_source
  is '����Դ';
create index IDX58_100201 on FACT_100201_LOST_MAC (CHANNELID);
create index IDX59_100201 on FACT_100201_LOST_MAC (SERVERID);
create index IDX60_100201 on FACT_100201_LOST_MAC (STATDATE);

prompt
prompt Creating table FACT_100201_LOST_USER
prompt ====================================
prompt
create table FACT_100201_LOST_USER
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_LOST_USER
  is '�û���ʧ������';
comment on column FACT_100201_LOST_USER.statdate
  is 'ͳ������';
comment on column FACT_100201_LOST_USER.lostdate
  is '��ʧ����';
comment on column FACT_100201_LOST_USER.channelid
  is '����ID';
comment on column FACT_100201_LOST_USER.serverid
  is '����ID';
comment on column FACT_100201_LOST_USER.appid
  is '��ƷID';
comment on column FACT_100201_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column FACT_100201_LOST_USER.lost_days
  is '��ʧ����';
comment on column FACT_100201_LOST_USER.lost_conn
  is '��Ծ�û���ʧ';
comment on column FACT_100201_LOST_USER.lost_pay
  is '�����û���ʧ';
comment on column FACT_100201_LOST_USER.data_source
  is '����Դ';
create index IDX61_100201 on FACT_100201_LOST_USER (CHANNELID);
create index IDX62_100201 on FACT_100201_LOST_USER (SERVERID);
create index IDX63_100201 on FACT_100201_LOST_USER (STATDATE);

prompt
prompt Creating table FACT_100201_LTV_MAC
prompt ==================================
prompt
create table FACT_100201_LTV_MAC
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_LTV_MAC
  is '�豸LTV������';
comment on column FACT_100201_LTV_MAC.statdate
  is 'ͳ������';
comment on column FACT_100201_LTV_MAC.ltvdate
  is '��ֵ����';
comment on column FACT_100201_LTV_MAC.channelid
  is '����';
comment on column FACT_100201_LTV_MAC.serverid
  is '����';
comment on column FACT_100201_LTV_MAC.appid
  is '��Ʒid';
comment on column FACT_100201_LTV_MAC.ltv_days
  is 'ltv��';
comment on column FACT_100201_LTV_MAC.payamount
  is '���ѽ��';
comment on column FACT_100201_LTV_MAC.data_source
  is '������Դ';
create index IDX64_100201 on FACT_100201_LTV_MAC (CHANNELID);
create index IDX65_100201 on FACT_100201_LTV_MAC (SERVERID);
create index IDX66_100201 on FACT_100201_LTV_MAC (STATDATE);

prompt
prompt Creating table FACT_100201_LTV_USER
prompt ===================================
prompt
create table FACT_100201_LTV_USER
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_LTV_USER
  is '�û�LTV������';
comment on column FACT_100201_LTV_USER.statdate
  is 'ͳ������';
comment on column FACT_100201_LTV_USER.ltvdate
  is '��ֵ����';
comment on column FACT_100201_LTV_USER.channelid
  is '����';
comment on column FACT_100201_LTV_USER.serverid
  is '����';
comment on column FACT_100201_LTV_USER.appid
  is '��Ʒid';
comment on column FACT_100201_LTV_USER.ltv_days
  is 'ltv��';
comment on column FACT_100201_LTV_USER.payamount
  is '���ѽ��';
comment on column FACT_100201_LTV_USER.data_source
  is '������Դ';
create index IDX67_100201 on FACT_100201_LTV_USER (CHANNELID);
create index IDX68_100201 on FACT_100201_LTV_USER (SERVERID);
create index IDX69_100201 on FACT_100201_LTV_USER (STATDATE);

prompt
prompt Creating table FACT_100201_MISS_FIRST
prompt =====================================
prompt
create table FACT_100201_MISS_FIRST
(
  statdate        VARCHAR2(10),
  channelid       VARCHAR2(50),
  serverid        VARCHAR2(50),
  appid           VARCHAR2(50),
  versionid       VARCHAR2(50),
  missionid       VARCHAR2(50),
  rolelevel       NUMBER,
  rolejob         VARCHAR2(50) default '0',
  firstenter_succ NUMBER,
  firstenter_fail NUMBER,
  loaddate        DATE,
  data_source     VARCHAR2(100)
)
;
comment on table FACT_100201_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column FACT_100201_MISS_FIRST.statdate
  is 'ͳ������';
comment on column FACT_100201_MISS_FIRST.channelid
  is '����';
comment on column FACT_100201_MISS_FIRST.serverid
  is '����';
comment on column FACT_100201_MISS_FIRST.appid
  is '��ƷID';
comment on column FACT_100201_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_MISS_FIRST.missionid
  is '�ؿ�ID';
comment on column FACT_100201_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column FACT_100201_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column FACT_100201_MISS_FIRST.firstenter_succ
  is '��һ�ν���ؿ��ɹ���';
comment on column FACT_100201_MISS_FIRST.firstenter_fail
  is '��һ�ν���ؿ�ʧ����';
comment on column FACT_100201_MISS_FIRST.data_source
  is '������Դ';
create index IDX70_100201 on FACT_100201_MISS_FIRST (CHANNELID);
create index IDX71_100201 on FACT_100201_MISS_FIRST (SERVERID);
create index IDX72_100201 on FACT_100201_MISS_FIRST (STATDATE);

prompt
prompt Creating table FACT_100201_NET
prompt ==============================
prompt
create table FACT_100201_NET
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_net    VARCHAR2(50),
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_NET
  is '������ʽ������';
comment on column FACT_100201_NET.statdate
  is 'ͳ������';
comment on column FACT_100201_NET.channelid
  is '����';
comment on column FACT_100201_NET.serverid
  is '����';
comment on column FACT_100201_NET.appid
  is '��Ʒid';
comment on column FACT_100201_NET.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_NET.dvid_net
  is '������ʽ';
comment on column FACT_100201_NET.conncount
  is '������';
comment on column FACT_100201_NET.data_source
  is '������Դ';
create index IDX73_100201 on FACT_100201_NET (CHANNELID);
create index IDX74_100201 on FACT_100201_NET (SERVERID);
create index IDX75_100201 on FACT_100201_NET (STATDATE);

prompt
prompt Creating table FACT_100201_OPERATOR
prompt ===================================
prompt
create table FACT_100201_OPERATOR
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  dvid_operator VARCHAR2(50),
  conncount     NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100201_OPERATOR
  is '��Ӫ�̷�����';
comment on column FACT_100201_OPERATOR.statdate
  is 'ͳ������';
comment on column FACT_100201_OPERATOR.channelid
  is '����';
comment on column FACT_100201_OPERATOR.serverid
  is '����';
comment on column FACT_100201_OPERATOR.appid
  is '��Ʒid';
comment on column FACT_100201_OPERATOR.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_OPERATOR.dvid_operator
  is '������ʽ';
comment on column FACT_100201_OPERATOR.conncount
  is '������';
comment on column FACT_100201_OPERATOR.data_source
  is '������Դ';
create index IDX76_100201 on FACT_100201_OPERATOR (CHANNELID);
create index IDX77_100201 on FACT_100201_OPERATOR (SERVERID);
create index IDX78_100201 on FACT_100201_OPERATOR (STATDATE);

prompt
prompt Creating table FACT_100201_ORDER
prompt ================================
prompt
create table FACT_100201_ORDER
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100201_ORDER
  is '����������';
comment on column FACT_100201_ORDER.statdate
  is 'ͳ������';
comment on column FACT_100201_ORDER.channelid
  is '����';
comment on column FACT_100201_ORDER.serverid
  is '����';
comment on column FACT_100201_ORDER.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100201_ORDER.appid
  is '��Ʒid';
comment on column FACT_100201_ORDER.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_ORDER.paysucccount
  is '�ɹ�������';
comment on column FACT_100201_ORDER.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100201_ORDER.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100201_ORDER.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100201_ORDER.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100201_ORDER.payfailnum
  is '����ʧ������';
comment on column FACT_100201_ORDER.data_source
  is '������Դ';
create index IDX79_100201 on FACT_100201_ORDER (CHANNELID);
create index IDX80_100201 on FACT_100201_ORDER (SERVERID);
create index IDX81_100201 on FACT_100201_ORDER (STATDATE);

prompt
prompt Creating table FACT_100201_ORDER_HOUR
prompt =====================================
prompt
create table FACT_100201_ORDER_HOUR
(
  statdate      VARCHAR2(20),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100201_ORDER_HOUR
  is '����Сʱ������';
comment on column FACT_100201_ORDER_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100201_ORDER_HOUR.channelid
  is '����';
comment on column FACT_100201_ORDER_HOUR.serverid
  is '����';
comment on column FACT_100201_ORDER_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100201_ORDER_HOUR.appid
  is '��Ʒid';
comment on column FACT_100201_ORDER_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_ORDER_HOUR.paysucccount
  is '�ɹ�������';
comment on column FACT_100201_ORDER_HOUR.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100201_ORDER_HOUR.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100201_ORDER_HOUR.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100201_ORDER_HOUR.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100201_ORDER_HOUR.payfailnum
  is '����ʧ������';
comment on column FACT_100201_ORDER_HOUR.data_source
  is '������Դ';
create index IDX177_100201 on FACT_100201_ORDER_HOUR (CHANNELID);
create index IDX178_100201 on FACT_100201_ORDER_HOUR (SERVERID);
create index IDX179_100201 on FACT_100201_ORDER_HOUR (STATDATE);

prompt
prompt Creating table FACT_100201_ORDER_MONTH
prompt ======================================
prompt
create table FACT_100201_ORDER_MONTH
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100201_ORDER_MONTH
  is '�¶���������';
comment on column FACT_100201_ORDER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100201_ORDER_MONTH.channelid
  is '����';
comment on column FACT_100201_ORDER_MONTH.serverid
  is '����';
comment on column FACT_100201_ORDER_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100201_ORDER_MONTH.appid
  is '��Ʒid';
comment on column FACT_100201_ORDER_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_ORDER_MONTH.paysucccount
  is '�ɹ�������';
comment on column FACT_100201_ORDER_MONTH.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100201_ORDER_MONTH.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100201_ORDER_MONTH.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100201_ORDER_MONTH.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100201_ORDER_MONTH.payfailnum
  is '����ʧ������';
comment on column FACT_100201_ORDER_MONTH.data_source
  is '������Դ';
create index IDX191_100201 on FACT_100201_ORDER_MONTH (CHANNELID);
create index IDX192_100201 on FACT_100201_ORDER_MONTH (SERVERID);
create index IDX193_100201 on FACT_100201_ORDER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100201_ORDER_WEEK
prompt =====================================
prompt
create table FACT_100201_ORDER_WEEK
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100201_ORDER_WEEK
  is '�ܶ���������';
comment on column FACT_100201_ORDER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100201_ORDER_WEEK.channelid
  is '����';
comment on column FACT_100201_ORDER_WEEK.serverid
  is '����';
comment on column FACT_100201_ORDER_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100201_ORDER_WEEK.appid
  is '��Ʒid';
comment on column FACT_100201_ORDER_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_ORDER_WEEK.paysucccount
  is '�ɹ�������';
comment on column FACT_100201_ORDER_WEEK.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100201_ORDER_WEEK.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100201_ORDER_WEEK.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100201_ORDER_WEEK.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100201_ORDER_WEEK.payfailnum
  is '����ʧ������';
comment on column FACT_100201_ORDER_WEEK.data_source
  is '������Դ';
create index IDX188_100201 on FACT_100201_ORDER_WEEK (CHANNELID);
create index IDX189_100201 on FACT_100201_ORDER_WEEK (SERVERID);
create index IDX190_100201 on FACT_100201_ORDER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100201_PAYAMOUNT_DAY
prompt ========================================
prompt
create table FACT_100201_PAYAMOUNT_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_PAYAMOUNT_DAY
  is '�ճ�ֵ��������';
comment on column FACT_100201_PAYAMOUNT_DAY.statdate
  is 'ͳ������';
comment on column FACT_100201_PAYAMOUNT_DAY.channelid
  is '����';
comment on column FACT_100201_PAYAMOUNT_DAY.serverid
  is '����';
comment on column FACT_100201_PAYAMOUNT_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100201_PAYAMOUNT_DAY.appid
  is '��Ʒid';
comment on column FACT_100201_PAYAMOUNT_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_PAYAMOUNT_DAY.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100201_PAYAMOUNT_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100201_PAYAMOUNT_DAY.data_source
  is '������Դ';
create index IDX82_100201 on FACT_100201_PAYAMOUNT_DAY (CHANNELID);
create index IDX83_100201 on FACT_100201_PAYAMOUNT_DAY (SERVERID);
create index IDX84_100201 on FACT_100201_PAYAMOUNT_DAY (STATDATE);

prompt
prompt Creating table FACT_100201_PAYAMOUNT_MONTH
prompt ==========================================
prompt
create table FACT_100201_PAYAMOUNT_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_PAYAMOUNT_MONTH
  is '�³�ֵ��������';
comment on column FACT_100201_PAYAMOUNT_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100201_PAYAMOUNT_MONTH.channelid
  is '����';
comment on column FACT_100201_PAYAMOUNT_MONTH.serverid
  is '����';
comment on column FACT_100201_PAYAMOUNT_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100201_PAYAMOUNT_MONTH.appid
  is '��Ʒid';
comment on column FACT_100201_PAYAMOUNT_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_PAYAMOUNT_MONTH.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100201_PAYAMOUNT_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100201_PAYAMOUNT_MONTH.data_source
  is '������Դ';
create index IDX88_100201 on FACT_100201_PAYAMOUNT_MONTH (CHANNELID);
create index IDX89_100201 on FACT_100201_PAYAMOUNT_MONTH (SERVERID);
create index IDX90_100201 on FACT_100201_PAYAMOUNT_MONTH (STATDATE);

prompt
prompt Creating table FACT_100201_PAYAMOUNT_WEEK
prompt =========================================
prompt
create table FACT_100201_PAYAMOUNT_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_PAYAMOUNT_WEEK
  is '�ܳ�ֵ��������';
comment on column FACT_100201_PAYAMOUNT_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100201_PAYAMOUNT_WEEK.channelid
  is '����';
comment on column FACT_100201_PAYAMOUNT_WEEK.serverid
  is '����';
comment on column FACT_100201_PAYAMOUNT_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100201_PAYAMOUNT_WEEK.appid
  is '��Ʒid';
comment on column FACT_100201_PAYAMOUNT_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_PAYAMOUNT_WEEK.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100201_PAYAMOUNT_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100201_PAYAMOUNT_WEEK.data_source
  is '������Դ';
create index IDX85_100201 on FACT_100201_PAYAMOUNT_WEEK (CHANNELID);
create index IDX86_100201 on FACT_100201_PAYAMOUNT_WEEK (SERVERID);
create index IDX87_100201 on FACT_100201_PAYAMOUNT_WEEK (STATDATE);

prompt
prompt Creating table FACT_100201_PAYNUM_DAY
prompt =====================================
prompt
create table FACT_100201_PAYNUM_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_PAYNUM_DAY
  is '�ճ�ֵ����������';
comment on column FACT_100201_PAYNUM_DAY.statdate
  is 'ͳ������';
comment on column FACT_100201_PAYNUM_DAY.channelid
  is '����';
comment on column FACT_100201_PAYNUM_DAY.serverid
  is '����';
comment on column FACT_100201_PAYNUM_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100201_PAYNUM_DAY.appid
  is '��Ʒid';
comment on column FACT_100201_PAYNUM_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_PAYNUM_DAY.paynum
  is '��ֵ����';
comment on column FACT_100201_PAYNUM_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100201_PAYNUM_DAY.data_source
  is '������Դ';
create index IDX97_100201 on FACT_100201_PAYNUM_DAY (CHANNELID);
create index IDX98_100201 on FACT_100201_PAYNUM_DAY (SERVERID);
create index IDX99_100201 on FACT_100201_PAYNUM_DAY (STATDATE);

prompt
prompt Creating table FACT_100201_PAYNUM_MONTH
prompt =======================================
prompt
create table FACT_100201_PAYNUM_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_PAYNUM_MONTH
  is '�³�ֵ����������';
comment on column FACT_100201_PAYNUM_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100201_PAYNUM_MONTH.channelid
  is '����';
comment on column FACT_100201_PAYNUM_MONTH.serverid
  is '����';
comment on column FACT_100201_PAYNUM_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100201_PAYNUM_MONTH.appid
  is '��Ʒid';
comment on column FACT_100201_PAYNUM_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_PAYNUM_MONTH.paynum
  is '��ֵ����';
comment on column FACT_100201_PAYNUM_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100201_PAYNUM_MONTH.data_source
  is '������Դ';
create index IDX91_100201 on FACT_100201_PAYNUM_MONTH (CHANNELID);
create index IDX92_100201 on FACT_100201_PAYNUM_MONTH (SERVERID);
create index IDX93_100201 on FACT_100201_PAYNUM_MONTH (STATDATE);

prompt
prompt Creating table FACT_100201_PAYNUM_WEEK
prompt ======================================
prompt
create table FACT_100201_PAYNUM_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_PAYNUM_WEEK
  is '�ܳ�ֵ����������';
comment on column FACT_100201_PAYNUM_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100201_PAYNUM_WEEK.channelid
  is '����';
comment on column FACT_100201_PAYNUM_WEEK.serverid
  is '����';
comment on column FACT_100201_PAYNUM_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100201_PAYNUM_WEEK.appid
  is '��Ʒid';
comment on column FACT_100201_PAYNUM_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_PAYNUM_WEEK.paynum
  is '��ֵ����';
comment on column FACT_100201_PAYNUM_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100201_PAYNUM_WEEK.data_source
  is '������Դ';
create index IDX94_100201 on FACT_100201_PAYNUM_WEEK (CHANNELID);
create index IDX95_100201 on FACT_100201_PAYNUM_WEEK (SERVERID);
create index IDX96_100201 on FACT_100201_PAYNUM_WEEK (STATDATE);

prompt
prompt Creating table FACT_100201_PAYTYPE
prompt ==================================
prompt
create table FACT_100201_PAYTYPE
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paytypeid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_PAYTYPE
  is '��ֵ���ͷ�����';
comment on column FACT_100201_PAYTYPE.statdate
  is 'ͳ������';
comment on column FACT_100201_PAYTYPE.channelid
  is '����';
comment on column FACT_100201_PAYTYPE.serverid
  is '����';
comment on column FACT_100201_PAYTYPE.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100201_PAYTYPE.appid
  is '��Ʒid';
comment on column FACT_100201_PAYTYPE.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_PAYTYPE.paytypeid
  is '��ֵ����';
comment on column FACT_100201_PAYTYPE.payamount
  is '��ֵ���';
comment on column FACT_100201_PAYTYPE.paycount
  is '��ֵ����';
comment on column FACT_100201_PAYTYPE.paynum
  is '��ֵ����';
comment on column FACT_100201_PAYTYPE.data_source
  is '������Դ';
create index IDX100_100201 on FACT_100201_PAYTYPE (CHANNELID);
create index IDX101_100201 on FACT_100201_PAYTYPE (SERVERID);
create index IDX102_100201 on FACT_100201_PAYTYPE (STATDATE);

prompt
prompt Creating table FACT_100201_PAYWAY
prompt =================================
prompt
create table FACT_100201_PAYWAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paywayid    VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_PAYWAY
  is '��ֵ��ʽ������';
comment on column FACT_100201_PAYWAY.statdate
  is 'ͳ������';
comment on column FACT_100201_PAYWAY.channelid
  is '����';
comment on column FACT_100201_PAYWAY.serverid
  is '����';
comment on column FACT_100201_PAYWAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100201_PAYWAY.appid
  is '��Ʒid';
comment on column FACT_100201_PAYWAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_PAYWAY.paywayid
  is '��ֵ��ʽ';
comment on column FACT_100201_PAYWAY.payamount
  is '��ֵ���';
comment on column FACT_100201_PAYWAY.paycount
  is '��ֵ����';
comment on column FACT_100201_PAYWAY.paynum
  is '��ֵ����';
comment on column FACT_100201_PAYWAY.data_source
  is '������Դ';
create index IDX103_100201 on FACT_100201_PAYWAY (CHANNELID);
create index IDX104_100201 on FACT_100201_PAYWAY (SERVERID);
create index IDX105_100201 on FACT_100201_PAYWAY (STATDATE);

prompt
prompt Creating table FACT_100201_REGION
prompt =================================
prompt
create table FACT_100201_REGION
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  country     VARCHAR2(50),
  province    VARCHAR2(50),
  city        VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_REGION
  is '���������';
comment on column FACT_100201_REGION.statdate
  is 'ͳ������';
comment on column FACT_100201_REGION.channelid
  is '����';
comment on column FACT_100201_REGION.serverid
  is '����';
comment on column FACT_100201_REGION.appid
  is '��Ʒid';
comment on column FACT_100201_REGION.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_REGION.country
  is '����';
comment on column FACT_100201_REGION.province
  is 'ʡ';
comment on column FACT_100201_REGION.city
  is '��';
comment on column FACT_100201_REGION.newcount
  is '������';
comment on column FACT_100201_REGION.conncount
  is '������';
comment on column FACT_100201_REGION.paycount
  is '������';
comment on column FACT_100201_REGION.payamount
  is '���ѽ��';
comment on column FACT_100201_REGION.data_source
  is '������Դ';
create index IDX106_100201 on FACT_100201_REGION (CHANNELID);
create index IDX107_100201 on FACT_100201_REGION (SERVERID);
create index IDX108_100201 on FACT_100201_REGION (STATDATE);

prompt
prompt Creating table FACT_100201_REMAIN_MAC
prompt =====================================
prompt
create table FACT_100201_REMAIN_MAC
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_REMAIN_MAC
  is '�豸�����';
comment on column FACT_100201_REMAIN_MAC.statdate
  is 'ͳ������';
comment on column FACT_100201_REMAIN_MAC.conndate
  is '��������';
comment on column FACT_100201_REMAIN_MAC.channelid
  is '����ID';
comment on column FACT_100201_REMAIN_MAC.serverid
  is '����ID';
comment on column FACT_100201_REMAIN_MAC.appid
  is '��ƷID';
comment on column FACT_100201_REMAIN_MAC.remain_days
  is '��������';
comment on column FACT_100201_REMAIN_MAC.new_remain
  is '��������';
comment on column FACT_100201_REMAIN_MAC.conn_remain
  is '��������';
comment on column FACT_100201_REMAIN_MAC.pay_remain
  is '��������';
comment on column FACT_100201_REMAIN_MAC.data_source
  is '����Դ';
create index IDX109_100201 on FACT_100201_REMAIN_MAC (CHANNELID);
create index IDX110_100201 on FACT_100201_REMAIN_MAC (SERVERID);
create index IDX111_100201 on FACT_100201_REMAIN_MAC (STATDATE);

prompt
prompt Creating table FACT_100201_REMAIN_USER
prompt ======================================
prompt
create table FACT_100201_REMAIN_USER
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_REMAIN_USER
  is '�û������';
comment on column FACT_100201_REMAIN_USER.statdate
  is 'ͳ������';
comment on column FACT_100201_REMAIN_USER.conndate
  is '��������';
comment on column FACT_100201_REMAIN_USER.channelid
  is '����ID';
comment on column FACT_100201_REMAIN_USER.serverid
  is '����ID';
comment on column FACT_100201_REMAIN_USER.appid
  is '��ƷID';
comment on column FACT_100201_REMAIN_USER.remain_days
  is '��������';
comment on column FACT_100201_REMAIN_USER.new_remain
  is '��������';
comment on column FACT_100201_REMAIN_USER.conn_remain
  is '��������';
comment on column FACT_100201_REMAIN_USER.pay_remain
  is '��������';
comment on column FACT_100201_REMAIN_USER.data_source
  is '����Դ';
create index IDX112_100201 on FACT_100201_REMAIN_USER (CHANNELID);
create index IDX113_100201 on FACT_100201_REMAIN_USER (SERVERID);
create index IDX114_100201 on FACT_100201_REMAIN_USER (STATDATE);

prompt
prompt Creating table FACT_100201_VC
prompt =============================
prompt
create table FACT_100201_VC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcamount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100201_VC
  is '������ҷ�����';
comment on column FACT_100201_VC.statdate
  is 'ͳ������';
comment on column FACT_100201_VC.channelid
  is '����';
comment on column FACT_100201_VC.serverid
  is '����';
comment on column FACT_100201_VC.appid
  is '��Ʒid';
comment on column FACT_100201_VC.versionid
  is '��Ʒ�汾';
comment on column FACT_100201_VC.vctype
  is '�����������';
comment on column FACT_100201_VC.vcusetype
  is '�������ʹ������';
comment on column FACT_100201_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column FACT_100201_VC.vcamount
  is '������ҽ��';
comment on column FACT_100201_VC.data_source
  is '������Դ';
create index IDX115_100201 on FACT_100201_VC (CHANNELID);
create index IDX116_100201 on FACT_100201_VC (SERVERID);
create index IDX117_100201 on FACT_100201_VC (STATDATE);

prompt
prompt Creating table FACT_100202_BACK_MAC
prompt ===================================
prompt
create table FACT_100202_BACK_MAC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_BACK_MAC
  is '�豸����������';
comment on column FACT_100202_BACK_MAC.statdate
  is 'ͳ������';
comment on column FACT_100202_BACK_MAC.channelid
  is '����ID';
comment on column FACT_100202_BACK_MAC.serverid
  is '����ID';
comment on column FACT_100202_BACK_MAC.appid
  is '��ƷID';
comment on column FACT_100202_BACK_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100202_BACK_MAC.back_conn
  is '��Ծ�豸������';
comment on column FACT_100202_BACK_MAC.back_pay
  is '�����豸������';
comment on column FACT_100202_BACK_MAC.data_source
  is '����Դ';
create index IDX1_100202 on FACT_100202_BACK_MAC (CHANNELID);
create index IDX2_100202 on FACT_100202_BACK_MAC (SERVERID);
create index IDX3_100202 on FACT_100202_BACK_MAC (STATDATE);

prompt
prompt Creating table FACT_100202_BACK_MAC_MONTH
prompt =========================================
prompt
create table FACT_100202_BACK_MAC_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_BACK_MAC_MONTH
  is '�豸����������';
comment on column FACT_100202_BACK_MAC_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100202_BACK_MAC_MONTH.channelid
  is '����ID';
comment on column FACT_100202_BACK_MAC_MONTH.serverid
  is '����ID';
comment on column FACT_100202_BACK_MAC_MONTH.appid
  is '��ƷID';
comment on column FACT_100202_BACK_MAC_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100202_BACK_MAC_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100202_BACK_MAC_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100202_BACK_MAC_MONTH.data_source
  is '����Դ';
create index IDX4_100202 on FACT_100202_BACK_MAC_MONTH (CHANNELID);
create index IDX5_100202 on FACT_100202_BACK_MAC_MONTH (SERVERID);
create index IDX6_100202 on FACT_100202_BACK_MAC_MONTH (STATDATE);

prompt
prompt Creating table FACT_100202_BACK_MAC_WEEK
prompt ========================================
prompt
create table FACT_100202_BACK_MAC_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_BACK_MAC_WEEK
  is '�豸����������';
comment on column FACT_100202_BACK_MAC_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100202_BACK_MAC_WEEK.channelid
  is '����ID';
comment on column FACT_100202_BACK_MAC_WEEK.serverid
  is '����ID';
comment on column FACT_100202_BACK_MAC_WEEK.appid
  is '��ƷID';
comment on column FACT_100202_BACK_MAC_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100202_BACK_MAC_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100202_BACK_MAC_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100202_BACK_MAC_WEEK.data_source
  is '����Դ';
create index IDX7_100202 on FACT_100202_BACK_MAC_WEEK (CHANNELID);
create index IDX8_100202 on FACT_100202_BACK_MAC_WEEK (SERVERID);
create index IDX9_100202 on FACT_100202_BACK_MAC_WEEK (STATDATE);

prompt
prompt Creating table FACT_100202_BACK_USER
prompt ====================================
prompt
create table FACT_100202_BACK_USER
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_BACK_USER
  is '�û�����������';
comment on column FACT_100202_BACK_USER.statdate
  is 'ͳ������';
comment on column FACT_100202_BACK_USER.channelid
  is '����ID';
comment on column FACT_100202_BACK_USER.serverid
  is '����ID';
comment on column FACT_100202_BACK_USER.appid
  is '��ƷID';
comment on column FACT_100202_BACK_USER.lost_days
  is '��ʧ����';
comment on column FACT_100202_BACK_USER.back_conn
  is '��Ծ�û�������';
comment on column FACT_100202_BACK_USER.back_pay
  is '�����û�������';
comment on column FACT_100202_BACK_USER.data_source
  is '����Դ';
create index IDX16_100202 on FACT_100202_BACK_USER (CHANNELID);
create index IDX17_100202 on FACT_100202_BACK_USER (SERVERID);
create index IDX18_100202 on FACT_100202_BACK_USER (STATDATE);

prompt
prompt Creating table FACT_100202_BACK_USER_MONTH
prompt ==========================================
prompt
create table FACT_100202_BACK_USER_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_BACK_USER_MONTH
  is '�豸����������';
comment on column FACT_100202_BACK_USER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100202_BACK_USER_MONTH.channelid
  is '����ID';
comment on column FACT_100202_BACK_USER_MONTH.serverid
  is '����ID';
comment on column FACT_100202_BACK_USER_MONTH.appid
  is '��ƷID';
comment on column FACT_100202_BACK_USER_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100202_BACK_USER_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100202_BACK_USER_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100202_BACK_USER_MONTH.data_source
  is '����Դ';
create index IDX13_100202 on FACT_100202_BACK_USER_MONTH (CHANNELID);
create index IDX14_100202 on FACT_100202_BACK_USER_MONTH (SERVERID);
create index IDX15_100202 on FACT_100202_BACK_USER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100202_BACK_USER_WEEK
prompt =========================================
prompt
create table FACT_100202_BACK_USER_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_BACK_USER_WEEK
  is '�豸����������';
comment on column FACT_100202_BACK_USER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100202_BACK_USER_WEEK.channelid
  is '����ID';
comment on column FACT_100202_BACK_USER_WEEK.serverid
  is '����ID';
comment on column FACT_100202_BACK_USER_WEEK.appid
  is '��ƷID';
comment on column FACT_100202_BACK_USER_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100202_BACK_USER_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100202_BACK_USER_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100202_BACK_USER_WEEK.data_source
  is '����Դ';
create index IDX10_100202 on FACT_100202_BACK_USER_WEEK (CHANNELID);
create index IDX11_100202 on FACT_100202_BACK_USER_WEEK (SERVERID);
create index IDX12_100202 on FACT_100202_BACK_USER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100202_CEVENT
prompt =================================
prompt
create table FACT_100202_CEVENT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  eventkey    VARCHAR2(50),
  eventcount  NUMBER,
  eventnum    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_CEVENT
  is '�Զ��������';
comment on column FACT_100202_CEVENT.statdate
  is 'ͳ������';
comment on column FACT_100202_CEVENT.channelid
  is '����';
comment on column FACT_100202_CEVENT.serverid
  is '����';
comment on column FACT_100202_CEVENT.appid
  is '��Ʒid';
comment on column FACT_100202_CEVENT.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100202_CEVENT.eventcount
  is '�¼��û���';
comment on column FACT_100202_CEVENT.eventnum
  is '�¼�����';
comment on column FACT_100202_CEVENT.data_source
  is '������Դ';
create index IDX181_100202 on FACT_100202_CEVENT (CHANNELID);
create index IDX182_100202 on FACT_100202_CEVENT (SERVERID);
create index IDX183_100202 on FACT_100202_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100202_CEVENT_PAR
prompt =====================================
prompt
create table FACT_100202_CEVENT_PAR
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  ilevel         NUMBER,
  eventkey       VARCHAR2(100),
  eventpar_key   VARCHAR2(100),
  eventpar_value VARCHAR2(100),
  eventcount     NUMBER,
  eventnum       NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100202_CEVENT_PAR
  is '�Զ������������';
comment on column FACT_100202_CEVENT_PAR.statdate
  is 'ͳ������';
comment on column FACT_100202_CEVENT_PAR.channelid
  is '����';
comment on column FACT_100202_CEVENT_PAR.serverid
  is '����';
comment on column FACT_100202_CEVENT_PAR.appid
  is '��Ʒid';
comment on column FACT_100202_CEVENT_PAR.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_CEVENT_PAR.ilevel
  is '��ɫ�ȼ�';
comment on column FACT_100202_CEVENT_PAR.eventkey
  is '�¼�����';
comment on column FACT_100202_CEVENT_PAR.eventpar_key
  is '�¼�����';
comment on column FACT_100202_CEVENT_PAR.eventpar_value
  is '�¼�����ֵ';
comment on column FACT_100202_CEVENT_PAR.eventcount
  is '�¼��û���';
comment on column FACT_100202_CEVENT_PAR.eventnum
  is '�¼�����';
comment on column FACT_100202_CEVENT_PAR.data_source
  is '������Դ';
create index IDX185_100202 on FACT_100202_CEVENT_PAR (CHANNELID);
create index IDX186_100202 on FACT_100202_CEVENT_PAR (SERVERID);
create index IDX187_100202 on FACT_100202_CEVENT_PAR (STATDATE);

prompt
prompt Creating table FACT_100202_COMP_CEVENT
prompt ======================================
prompt
create table FACT_100202_COMP_CEVENT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(10),
  channelid   VARCHAR2(50),
  gameversion VARCHAR2(50),
  serverid    VARCHAR2(50),
  ilevel      NUMBER,
  eventkey    VARCHAR2(100),
  compid      VARCHAR2(50),
  caltype     VARCHAR2(50),
  dimpars     VARCHAR2(2000),
  comp_data   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_COMP_CEVENT
  is '�Զ����¼���Ϸ�����';
comment on column FACT_100202_COMP_CEVENT.statdate
  is '����';
comment on column FACT_100202_COMP_CEVENT.appid
  is '��Ϸ�� appid';
comment on column FACT_100202_COMP_CEVENT.channelid
  is '���� ID';
comment on column FACT_100202_COMP_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column FACT_100202_COMP_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column FACT_100202_COMP_CEVENT.ilevel
  is '��ҵȼ�';
comment on column FACT_100202_COMP_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100202_COMP_CEVENT.compid
  is '��ϼ����¼�ID';
comment on column FACT_100202_COMP_CEVENT.caltype
  is '��ϼ����¼���������';
comment on column FACT_100202_COMP_CEVENT.dimpars
  is '��ϲ���';
comment on column FACT_100202_COMP_CEVENT.comp_data
  is '��ϼ�����';
create index IDX184_100202 on FACT_100202_COMP_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100202_DAILY_REPORT
prompt =======================================
prompt
create table FACT_100202_DAILY_REPORT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_DAILY_REPORT
  is '�ձ�����';
comment on column FACT_100202_DAILY_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100202_DAILY_REPORT.appid
  is '��ƷID';
comment on column FACT_100202_DAILY_REPORT.channelid
  is '����';
comment on column FACT_100202_DAILY_REPORT.serverid
  is '����';
comment on column FACT_100202_DAILY_REPORT.indexid
  is 'ָ��';
comment on column FACT_100202_DAILY_REPORT.indtype
  is 'ָ������';
comment on column FACT_100202_DAILY_REPORT.rpt_data
  is '����';
create index IDX176_100202 on FACT_100202_DAILY_REPORT (STATDATE);

prompt
prompt Creating table FACT_100202_DVID
prompt ===============================
prompt
create table FACT_100202_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_model  VARCHAR2(200),
  dvid_res    VARCHAR2(50),
  dvid_os     VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_DVID
  is '�豸������';
comment on column FACT_100202_DVID.statdate
  is 'ͳ������';
comment on column FACT_100202_DVID.channelid
  is '����';
comment on column FACT_100202_DVID.serverid
  is '����';
comment on column FACT_100202_DVID.appid
  is '��Ʒid';
comment on column FACT_100202_DVID.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_DVID.dvid_model
  is '����';
comment on column FACT_100202_DVID.dvid_res
  is '�豸�ֱ���';
comment on column FACT_100202_DVID.dvid_os
  is '�豸����ϵͳ';
comment on column FACT_100202_DVID.newcount
  is '�����û���';
comment on column FACT_100202_DVID.conncount
  is '�����û���';
comment on column FACT_100202_DVID.data_source
  is '������Դ';
create index IDX19_100202 on FACT_100202_DVID (CHANNELID);
create index IDX20_100202 on FACT_100202_DVID (SERVERID);
create index IDX21_100202 on FACT_100202_DVID (STATDATE);

prompt
prompt Creating table FACT_100202_FIRSTPAY
prompt ===================================
prompt
create table FACT_100202_FIRSTPAY
(
  statdate         VARCHAR2(10),
  firstpaydate     VARCHAR2(10),
  channelid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  datatype         VARCHAR2(50),
  appid            VARCHAR2(50),
  first_payfromreg NUMBER,
  first_paycount   NUMBER,
  payamount        NUMBER,
  loaddate         DATE default SYSDATE,
  data_source      VARCHAR2(100)
)
;
comment on table FACT_100202_FIRSTPAY
  is '�����û��״γ�ֵ������';
comment on column FACT_100202_FIRSTPAY.statdate
  is 'ͳ������';
comment on column FACT_100202_FIRSTPAY.firstpaydate
  is '�״θ�������';
comment on column FACT_100202_FIRSTPAY.channelid
  is '����';
comment on column FACT_100202_FIRSTPAY.serverid
  is '����';
comment on column FACT_100202_FIRSTPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100202_FIRSTPAY.appid
  is '��Ʒid';
comment on column FACT_100202_FIRSTPAY.first_payfromreg
  is 'ע���ڼ��쿪ʼ��ֵ(1��2��..7..30..)';
comment on column FACT_100202_FIRSTPAY.first_paycount
  is '���������û���';
comment on column FACT_100202_FIRSTPAY.payamount
  is '�ۼƵ��ڼ���ĳ�ֵ�ܶ�';
comment on column FACT_100202_FIRSTPAY.data_source
  is '������Դ';
create index IDX22_100202 on FACT_100202_FIRSTPAY (CHANNELID);
create index IDX23_100202 on FACT_100202_FIRSTPAY (SERVERID);
create index IDX24_100202 on FACT_100202_FIRSTPAY (STATDATE);

prompt
prompt Creating table FACT_100202_FIRSTPAY_AMOUNT
prompt ==========================================
prompt
create table FACT_100202_FIRSTPAY_AMOUNT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_FIRSTPAY_AMOUNT
  is '�״θ��ѽ�������';
comment on column FACT_100202_FIRSTPAY_AMOUNT.statdate
  is 'ͳ������';
comment on column FACT_100202_FIRSTPAY_AMOUNT.channelid
  is '����';
comment on column FACT_100202_FIRSTPAY_AMOUNT.serverid
  is '��������';
comment on column FACT_100202_FIRSTPAY_AMOUNT.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100202_FIRSTPAY_AMOUNT.appid
  is '��Ʒid';
comment on column FACT_100202_FIRSTPAY_AMOUNT.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_FIRSTPAY_AMOUNT.payamount
  is '�״θ��ѽ��';
comment on column FACT_100202_FIRSTPAY_AMOUNT.paycount
  is '�״θ��ѽ���Ӧ������';
create index IDX25_100202 on FACT_100202_FIRSTPAY_AMOUNT (CHANNELID);
create index IDX26_100202 on FACT_100202_FIRSTPAY_AMOUNT (SERVERID);
create index IDX27_100202 on FACT_100202_FIRSTPAY_AMOUNT (STATDATE);

prompt
prompt Creating table FACT_100202_GENERAL_DAY
prompt ======================================
prompt
create table FACT_100202_GENERAL_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_GENERAL_DAY
  is '�ջ���������';
comment on column FACT_100202_GENERAL_DAY.statdate
  is 'ͳ������';
comment on column FACT_100202_GENERAL_DAY.channelid
  is '����';
comment on column FACT_100202_GENERAL_DAY.serverid
  is '����';
comment on column FACT_100202_GENERAL_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100202_GENERAL_DAY.appid
  is '��Ʒid';
comment on column FACT_100202_GENERAL_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_GENERAL_DAY.newcount
  is '������';
comment on column FACT_100202_GENERAL_DAY.conncount
  is '������';
comment on column FACT_100202_GENERAL_DAY.paycount
  is '������';
comment on column FACT_100202_GENERAL_DAY.payamount
  is '���ѽ��';
comment on column FACT_100202_GENERAL_DAY.data_source
  is '������Դ';
create index IDX28_100202 on FACT_100202_GENERAL_DAY (CHANNELID);
create index IDX29_100202 on FACT_100202_GENERAL_DAY (SERVERID);
create index IDX30_100202 on FACT_100202_GENERAL_DAY (STATDATE);

prompt
prompt Creating table FACT_100202_GENERAL_DAY_DVID
prompt ===========================================
prompt
create table FACT_100202_GENERAL_DAY_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_GENERAL_DAY_DVID
  is '���豸����������';
comment on column FACT_100202_GENERAL_DAY_DVID.statdate
  is 'ͳ������';
comment on column FACT_100202_GENERAL_DAY_DVID.channelid
  is '����';
comment on column FACT_100202_GENERAL_DAY_DVID.appid
  is '��Ʒid';
comment on column FACT_100202_GENERAL_DAY_DVID.newcount
  is '������';
comment on column FACT_100202_GENERAL_DAY_DVID.conncount
  is '������';
comment on column FACT_100202_GENERAL_DAY_DVID.data_source
  is '������Դ';
create index IDX31_100202 on FACT_100202_GENERAL_DAY_DVID (CHANNELID);
create index IDX33_100202 on FACT_100202_GENERAL_DAY_DVID (STATDATE);

prompt
prompt Creating table FACT_100202_GENERAL_HOUR
prompt =======================================
prompt
create table FACT_100202_GENERAL_HOUR
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_GENERAL_HOUR
  is 'Сʱ����������';
comment on column FACT_100202_GENERAL_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100202_GENERAL_HOUR.channelid
  is '����';
comment on column FACT_100202_GENERAL_HOUR.serverid
  is '����';
comment on column FACT_100202_GENERAL_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100202_GENERAL_HOUR.appid
  is '��Ʒid';
comment on column FACT_100202_GENERAL_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_GENERAL_HOUR.newcount
  is '������';
comment on column FACT_100202_GENERAL_HOUR.conncount
  is '������';
comment on column FACT_100202_GENERAL_HOUR.paycount
  is '������';
comment on column FACT_100202_GENERAL_HOUR.payamount
  is '���ѽ��';
comment on column FACT_100202_GENERAL_HOUR.data_source
  is '������Դ';
create index IDX34_100202 on FACT_100202_GENERAL_HOUR (CHANNELID);
create index IDX35_100202 on FACT_100202_GENERAL_HOUR (SERVERID);
create index IDX36_100202 on FACT_100202_GENERAL_HOUR (STATDATE);

prompt
prompt Creating table FACT_100202_GENERAL_HOUR_DVID
prompt ============================================
prompt
create table FACT_100202_GENERAL_HOUR_DVID
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_GENERAL_HOUR_DVID
  is 'Сʱ�豸����������';
comment on column FACT_100202_GENERAL_HOUR_DVID.statdate
  is 'ͳ������';
comment on column FACT_100202_GENERAL_HOUR_DVID.channelid
  is '����';
comment on column FACT_100202_GENERAL_HOUR_DVID.appid
  is '��Ʒid';
comment on column FACT_100202_GENERAL_HOUR_DVID.newcount
  is '������';
comment on column FACT_100202_GENERAL_HOUR_DVID.conncount
  is '������';
comment on column FACT_100202_GENERAL_HOUR_DVID.data_source
  is '������Դ';
create index IDX37_100202 on FACT_100202_GENERAL_HOUR_DVID (CHANNELID);
create index IDX39_100202 on FACT_100202_GENERAL_HOUR_DVID (STATDATE);

prompt
prompt Creating table FACT_100202_GENERAL_LEVEL
prompt ========================================
prompt
create table FACT_100202_GENERAL_LEVEL
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  rolelevel   NUMBER,
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_GENERAL_LEVEL
  is '�û��ȼ�������';
comment on column FACT_100202_GENERAL_LEVEL.statdate
  is 'ͳ������';
comment on column FACT_100202_GENERAL_LEVEL.channelid
  is '����';
comment on column FACT_100202_GENERAL_LEVEL.serverid
  is '����';
comment on column FACT_100202_GENERAL_LEVEL.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100202_GENERAL_LEVEL.appid
  is '��Ʒid';
comment on column FACT_100202_GENERAL_LEVEL.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_GENERAL_LEVEL.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100202_GENERAL_LEVEL.newcount
  is '������';
comment on column FACT_100202_GENERAL_LEVEL.conncount
  is '������';
comment on column FACT_100202_GENERAL_LEVEL.paycount
  is '������';
comment on column FACT_100202_GENERAL_LEVEL.payamount
  is '���ѽ��';
comment on column FACT_100202_GENERAL_LEVEL.data_source
  is '������Դ';
create index IDX40_100202 on FACT_100202_GENERAL_LEVEL (CHANNELID);
create index IDX41_100202 on FACT_100202_GENERAL_LEVEL (SERVERID);
create index IDX42_100202 on FACT_100202_GENERAL_LEVEL (STATDATE);

prompt
prompt Creating table FACT_100202_GENERAL_MONTH
prompt ========================================
prompt
create table FACT_100202_GENERAL_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_GENERAL_MONTH
  is '�»���������';
comment on column FACT_100202_GENERAL_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100202_GENERAL_MONTH.channelid
  is '����';
comment on column FACT_100202_GENERAL_MONTH.serverid
  is '����';
comment on column FACT_100202_GENERAL_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100202_GENERAL_MONTH.appid
  is '��Ʒid';
comment on column FACT_100202_GENERAL_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_GENERAL_MONTH.newcount
  is '������';
comment on column FACT_100202_GENERAL_MONTH.conncount
  is '������';
comment on column FACT_100202_GENERAL_MONTH.paycount
  is '������';
comment on column FACT_100202_GENERAL_MONTH.payamount
  is '���ѽ��';
comment on column FACT_100202_GENERAL_MONTH.data_source
  is '������Դ';
create index IDX43_100202 on FACT_100202_GENERAL_MONTH (CHANNELID);
create index IDX44_100202 on FACT_100202_GENERAL_MONTH (SERVERID);
create index IDX45_100202 on FACT_100202_GENERAL_MONTH (STATDATE);

prompt
prompt Creating table FACT_100202_GENERAL_MONTH_DVID
prompt =============================================
prompt
create table FACT_100202_GENERAL_MONTH_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_GENERAL_MONTH_DVID
  is '���豸����������';
comment on column FACT_100202_GENERAL_MONTH_DVID.statdate
  is 'ͳ������';
comment on column FACT_100202_GENERAL_MONTH_DVID.channelid
  is '����';
comment on column FACT_100202_GENERAL_MONTH_DVID.appid
  is '��Ʒid';
comment on column FACT_100202_GENERAL_MONTH_DVID.newcount
  is '������';
comment on column FACT_100202_GENERAL_MONTH_DVID.conncount
  is '������';
comment on column FACT_100202_GENERAL_MONTH_DVID.data_source
  is '������Դ';
create index IDX46_100202 on FACT_100202_GENERAL_MONTH_DVID (CHANNELID);
create index IDX48_100202 on FACT_100202_GENERAL_MONTH_DVID (STATDATE);

prompt
prompt Creating table FACT_100202_GENERAL_WEEK
prompt =======================================
prompt
create table FACT_100202_GENERAL_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_GENERAL_WEEK
  is '�ܻ���������';
comment on column FACT_100202_GENERAL_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100202_GENERAL_WEEK.channelid
  is '����';
comment on column FACT_100202_GENERAL_WEEK.serverid
  is '����';
comment on column FACT_100202_GENERAL_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100202_GENERAL_WEEK.appid
  is '��Ʒid';
comment on column FACT_100202_GENERAL_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_GENERAL_WEEK.newcount
  is '������';
comment on column FACT_100202_GENERAL_WEEK.conncount
  is '������';
comment on column FACT_100202_GENERAL_WEEK.paycount
  is '������';
comment on column FACT_100202_GENERAL_WEEK.payamount
  is '���ѽ��';
comment on column FACT_100202_GENERAL_WEEK.data_source
  is '������Դ';
create index IDX52_100202 on FACT_100202_GENERAL_WEEK (CHANNELID);
create index IDX53_100202 on FACT_100202_GENERAL_WEEK (SERVERID);
create index IDX54_100202 on FACT_100202_GENERAL_WEEK (STATDATE);

prompt
prompt Creating table FACT_100202_GENERAL_WEEK_DVID
prompt ============================================
prompt
create table FACT_100202_GENERAL_WEEK_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_GENERAL_WEEK_DVID
  is '���豸����������';
comment on column FACT_100202_GENERAL_WEEK_DVID.statdate
  is 'ͳ������';
comment on column FACT_100202_GENERAL_WEEK_DVID.channelid
  is '����';
comment on column FACT_100202_GENERAL_WEEK_DVID.appid
  is '��Ʒid';
comment on column FACT_100202_GENERAL_WEEK_DVID.newcount
  is '������';
comment on column FACT_100202_GENERAL_WEEK_DVID.conncount
  is '������';
comment on column FACT_100202_GENERAL_WEEK_DVID.data_source
  is '������Դ';
create index IDX49_100202 on FACT_100202_GENERAL_WEEK_DVID (CHANNELID);
create index IDX51_100202 on FACT_100202_GENERAL_WEEK_DVID (STATDATE);

prompt
prompt Creating table FACT_100202_HOUR_REPORT
prompt ======================================
prompt
create table FACT_100202_HOUR_REPORT
(
  statdate    VARCHAR2(20),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_HOUR_REPORT
  is '�ձ�Сʱ����';
comment on column FACT_100202_HOUR_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100202_HOUR_REPORT.appid
  is '��ƷID';
comment on column FACT_100202_HOUR_REPORT.channelid
  is '����';
comment on column FACT_100202_HOUR_REPORT.serverid
  is '����';
comment on column FACT_100202_HOUR_REPORT.indexid
  is 'ָ��';
comment on column FACT_100202_HOUR_REPORT.indtype
  is 'ָ������';
comment on column FACT_100202_HOUR_REPORT.rpt_data
  is '����';

prompt
prompt Creating table FACT_100202_LEVELPAY
prompt ===================================
prompt
create table FACT_100202_LEVELPAY
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  datatype       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  rolelevel      NUMBER,
  paycount       NUMBER,
  first_paycount NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100202_LEVELPAY
  is '�û���ɫ�ȼ����ѷ�����';
comment on column FACT_100202_LEVELPAY.statdate
  is 'ͳ������';
comment on column FACT_100202_LEVELPAY.channelid
  is '����';
comment on column FACT_100202_LEVELPAY.serverid
  is '����';
comment on column FACT_100202_LEVELPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100202_LEVELPAY.appid
  is '��Ʒid';
comment on column FACT_100202_LEVELPAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_LEVELPAY.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100202_LEVELPAY.paycount
  is '�����û���';
comment on column FACT_100202_LEVELPAY.first_paycount
  is '���������û������״θ����û���';
comment on column FACT_100202_LEVELPAY.data_source
  is '������Դ';
create index IDX55_100202 on FACT_100202_LEVELPAY (CHANNELID);
create index IDX56_100202 on FACT_100202_LEVELPAY (SERVERID);
create index IDX57_100202 on FACT_100202_LEVELPAY (STATDATE);

prompt
prompt Creating table FACT_100202_LOST_MAC
prompt ===================================
prompt
create table FACT_100202_LOST_MAC
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_LOST_MAC
  is '�豸��ʧ������';
comment on column FACT_100202_LOST_MAC.statdate
  is 'ͳ������';
comment on column FACT_100202_LOST_MAC.lostdate
  is '��ʧ����';
comment on column FACT_100202_LOST_MAC.channelid
  is '����ID';
comment on column FACT_100202_LOST_MAC.serverid
  is '����ID';
comment on column FACT_100202_LOST_MAC.appid
  is '��ƷID';
comment on column FACT_100202_LOST_MAC.rolelevel
  is '��ʧʱ�ȼ�';
comment on column FACT_100202_LOST_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100202_LOST_MAC.lost_conn
  is '��Ծ�豸��ʧ';
comment on column FACT_100202_LOST_MAC.lost_pay
  is '�����豸��ʧ';
comment on column FACT_100202_LOST_MAC.data_source
  is '����Դ';
create index IDX58_100202 on FACT_100202_LOST_MAC (CHANNELID);
create index IDX59_100202 on FACT_100202_LOST_MAC (SERVERID);
create index IDX60_100202 on FACT_100202_LOST_MAC (STATDATE);

prompt
prompt Creating table FACT_100202_LOST_USER
prompt ====================================
prompt
create table FACT_100202_LOST_USER
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_LOST_USER
  is '�û���ʧ������';
comment on column FACT_100202_LOST_USER.statdate
  is 'ͳ������';
comment on column FACT_100202_LOST_USER.lostdate
  is '��ʧ����';
comment on column FACT_100202_LOST_USER.channelid
  is '����ID';
comment on column FACT_100202_LOST_USER.serverid
  is '����ID';
comment on column FACT_100202_LOST_USER.appid
  is '��ƷID';
comment on column FACT_100202_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column FACT_100202_LOST_USER.lost_days
  is '��ʧ����';
comment on column FACT_100202_LOST_USER.lost_conn
  is '��Ծ�û���ʧ';
comment on column FACT_100202_LOST_USER.lost_pay
  is '�����û���ʧ';
comment on column FACT_100202_LOST_USER.data_source
  is '����Դ';
create index IDX61_100202 on FACT_100202_LOST_USER (CHANNELID);
create index IDX62_100202 on FACT_100202_LOST_USER (SERVERID);
create index IDX63_100202 on FACT_100202_LOST_USER (STATDATE);

prompt
prompt Creating table FACT_100202_LTV_MAC
prompt ==================================
prompt
create table FACT_100202_LTV_MAC
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_LTV_MAC
  is '�豸LTV������';
comment on column FACT_100202_LTV_MAC.statdate
  is 'ͳ������';
comment on column FACT_100202_LTV_MAC.ltvdate
  is '��ֵ����';
comment on column FACT_100202_LTV_MAC.channelid
  is '����';
comment on column FACT_100202_LTV_MAC.serverid
  is '����';
comment on column FACT_100202_LTV_MAC.appid
  is '��Ʒid';
comment on column FACT_100202_LTV_MAC.ltv_days
  is 'ltv��';
comment on column FACT_100202_LTV_MAC.payamount
  is '���ѽ��';
comment on column FACT_100202_LTV_MAC.data_source
  is '������Դ';
create index IDX64_100202 on FACT_100202_LTV_MAC (CHANNELID);
create index IDX65_100202 on FACT_100202_LTV_MAC (SERVERID);
create index IDX66_100202 on FACT_100202_LTV_MAC (STATDATE);

prompt
prompt Creating table FACT_100202_LTV_USER
prompt ===================================
prompt
create table FACT_100202_LTV_USER
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_LTV_USER
  is '�û�LTV������';
comment on column FACT_100202_LTV_USER.statdate
  is 'ͳ������';
comment on column FACT_100202_LTV_USER.ltvdate
  is '��ֵ����';
comment on column FACT_100202_LTV_USER.channelid
  is '����';
comment on column FACT_100202_LTV_USER.serverid
  is '����';
comment on column FACT_100202_LTV_USER.appid
  is '��Ʒid';
comment on column FACT_100202_LTV_USER.ltv_days
  is 'ltv��';
comment on column FACT_100202_LTV_USER.payamount
  is '���ѽ��';
comment on column FACT_100202_LTV_USER.data_source
  is '������Դ';
create index IDX67_100202 on FACT_100202_LTV_USER (CHANNELID);
create index IDX68_100202 on FACT_100202_LTV_USER (SERVERID);
create index IDX69_100202 on FACT_100202_LTV_USER (STATDATE);

prompt
prompt Creating table FACT_100202_MISS_FIRST
prompt =====================================
prompt
create table FACT_100202_MISS_FIRST
(
  statdate        VARCHAR2(10),
  channelid       VARCHAR2(50),
  serverid        VARCHAR2(50),
  appid           VARCHAR2(50),
  versionid       VARCHAR2(50),
  missionid       VARCHAR2(50),
  rolelevel       NUMBER,
  rolejob         VARCHAR2(50) default '0',
  firstenter_succ NUMBER,
  firstenter_fail NUMBER,
  loaddate        DATE,
  data_source     VARCHAR2(100)
)
;
comment on table FACT_100202_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column FACT_100202_MISS_FIRST.statdate
  is 'ͳ������';
comment on column FACT_100202_MISS_FIRST.channelid
  is '����';
comment on column FACT_100202_MISS_FIRST.serverid
  is '����';
comment on column FACT_100202_MISS_FIRST.appid
  is '��ƷID';
comment on column FACT_100202_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_MISS_FIRST.missionid
  is '�ؿ�ID';
comment on column FACT_100202_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column FACT_100202_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column FACT_100202_MISS_FIRST.firstenter_succ
  is '��һ�ν���ؿ��ɹ���';
comment on column FACT_100202_MISS_FIRST.firstenter_fail
  is '��һ�ν���ؿ�ʧ����';
comment on column FACT_100202_MISS_FIRST.data_source
  is '������Դ';
create index IDX70_100202 on FACT_100202_MISS_FIRST (CHANNELID);
create index IDX71_100202 on FACT_100202_MISS_FIRST (SERVERID);
create index IDX72_100202 on FACT_100202_MISS_FIRST (STATDATE);

prompt
prompt Creating table FACT_100202_NET
prompt ==============================
prompt
create table FACT_100202_NET
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_net    VARCHAR2(50),
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_NET
  is '������ʽ������';
comment on column FACT_100202_NET.statdate
  is 'ͳ������';
comment on column FACT_100202_NET.channelid
  is '����';
comment on column FACT_100202_NET.serverid
  is '����';
comment on column FACT_100202_NET.appid
  is '��Ʒid';
comment on column FACT_100202_NET.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_NET.dvid_net
  is '������ʽ';
comment on column FACT_100202_NET.conncount
  is '������';
comment on column FACT_100202_NET.data_source
  is '������Դ';
create index IDX73_100202 on FACT_100202_NET (CHANNELID);
create index IDX74_100202 on FACT_100202_NET (SERVERID);
create index IDX75_100202 on FACT_100202_NET (STATDATE);

prompt
prompt Creating table FACT_100202_OPERATOR
prompt ===================================
prompt
create table FACT_100202_OPERATOR
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  dvid_operator VARCHAR2(50),
  conncount     NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100202_OPERATOR
  is '��Ӫ�̷�����';
comment on column FACT_100202_OPERATOR.statdate
  is 'ͳ������';
comment on column FACT_100202_OPERATOR.channelid
  is '����';
comment on column FACT_100202_OPERATOR.serverid
  is '����';
comment on column FACT_100202_OPERATOR.appid
  is '��Ʒid';
comment on column FACT_100202_OPERATOR.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_OPERATOR.dvid_operator
  is '������ʽ';
comment on column FACT_100202_OPERATOR.conncount
  is '������';
comment on column FACT_100202_OPERATOR.data_source
  is '������Դ';
create index IDX76_100202 on FACT_100202_OPERATOR (CHANNELID);
create index IDX77_100202 on FACT_100202_OPERATOR (SERVERID);
create index IDX78_100202 on FACT_100202_OPERATOR (STATDATE);

prompt
prompt Creating table FACT_100202_ORDER
prompt ================================
prompt
create table FACT_100202_ORDER
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100202_ORDER
  is '����������';
comment on column FACT_100202_ORDER.statdate
  is 'ͳ������';
comment on column FACT_100202_ORDER.channelid
  is '����';
comment on column FACT_100202_ORDER.serverid
  is '����';
comment on column FACT_100202_ORDER.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100202_ORDER.appid
  is '��Ʒid';
comment on column FACT_100202_ORDER.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_ORDER.paysucccount
  is '�ɹ�������';
comment on column FACT_100202_ORDER.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100202_ORDER.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100202_ORDER.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100202_ORDER.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100202_ORDER.payfailnum
  is '����ʧ������';
comment on column FACT_100202_ORDER.data_source
  is '������Դ';
create index IDX79_100202 on FACT_100202_ORDER (CHANNELID);
create index IDX80_100202 on FACT_100202_ORDER (SERVERID);
create index IDX81_100202 on FACT_100202_ORDER (STATDATE);

prompt
prompt Creating table FACT_100202_ORDER_HOUR
prompt =====================================
prompt
create table FACT_100202_ORDER_HOUR
(
  statdate      VARCHAR2(20),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100202_ORDER_HOUR
  is '����Сʱ������';
comment on column FACT_100202_ORDER_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100202_ORDER_HOUR.channelid
  is '����';
comment on column FACT_100202_ORDER_HOUR.serverid
  is '����';
comment on column FACT_100202_ORDER_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100202_ORDER_HOUR.appid
  is '��Ʒid';
comment on column FACT_100202_ORDER_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_ORDER_HOUR.paysucccount
  is '�ɹ�������';
comment on column FACT_100202_ORDER_HOUR.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100202_ORDER_HOUR.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100202_ORDER_HOUR.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100202_ORDER_HOUR.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100202_ORDER_HOUR.payfailnum
  is '����ʧ������';
comment on column FACT_100202_ORDER_HOUR.data_source
  is '������Դ';
create index IDX177_100202 on FACT_100202_ORDER_HOUR (CHANNELID);
create index IDX178_100202 on FACT_100202_ORDER_HOUR (SERVERID);
create index IDX179_100202 on FACT_100202_ORDER_HOUR (STATDATE);

prompt
prompt Creating table FACT_100202_ORDER_MONTH
prompt ======================================
prompt
create table FACT_100202_ORDER_MONTH
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100202_ORDER_MONTH
  is '�¶���������';
comment on column FACT_100202_ORDER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100202_ORDER_MONTH.channelid
  is '����';
comment on column FACT_100202_ORDER_MONTH.serverid
  is '����';
comment on column FACT_100202_ORDER_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100202_ORDER_MONTH.appid
  is '��Ʒid';
comment on column FACT_100202_ORDER_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_ORDER_MONTH.paysucccount
  is '�ɹ�������';
comment on column FACT_100202_ORDER_MONTH.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100202_ORDER_MONTH.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100202_ORDER_MONTH.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100202_ORDER_MONTH.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100202_ORDER_MONTH.payfailnum
  is '����ʧ������';
comment on column FACT_100202_ORDER_MONTH.data_source
  is '������Դ';
create index IDX191_100202 on FACT_100202_ORDER_MONTH (CHANNELID);
create index IDX192_100202 on FACT_100202_ORDER_MONTH (SERVERID);
create index IDX193_100202 on FACT_100202_ORDER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100202_ORDER_WEEK
prompt =====================================
prompt
create table FACT_100202_ORDER_WEEK
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100202_ORDER_WEEK
  is '�ܶ���������';
comment on column FACT_100202_ORDER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100202_ORDER_WEEK.channelid
  is '����';
comment on column FACT_100202_ORDER_WEEK.serverid
  is '����';
comment on column FACT_100202_ORDER_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100202_ORDER_WEEK.appid
  is '��Ʒid';
comment on column FACT_100202_ORDER_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_ORDER_WEEK.paysucccount
  is '�ɹ�������';
comment on column FACT_100202_ORDER_WEEK.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100202_ORDER_WEEK.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100202_ORDER_WEEK.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100202_ORDER_WEEK.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100202_ORDER_WEEK.payfailnum
  is '����ʧ������';
comment on column FACT_100202_ORDER_WEEK.data_source
  is '������Դ';
create index IDX188_100202 on FACT_100202_ORDER_WEEK (CHANNELID);
create index IDX189_100202 on FACT_100202_ORDER_WEEK (SERVERID);
create index IDX190_100202 on FACT_100202_ORDER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100202_PAYAMOUNT_DAY
prompt ========================================
prompt
create table FACT_100202_PAYAMOUNT_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_PAYAMOUNT_DAY
  is '�ճ�ֵ��������';
comment on column FACT_100202_PAYAMOUNT_DAY.statdate
  is 'ͳ������';
comment on column FACT_100202_PAYAMOUNT_DAY.channelid
  is '����';
comment on column FACT_100202_PAYAMOUNT_DAY.serverid
  is '����';
comment on column FACT_100202_PAYAMOUNT_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100202_PAYAMOUNT_DAY.appid
  is '��Ʒid';
comment on column FACT_100202_PAYAMOUNT_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_PAYAMOUNT_DAY.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100202_PAYAMOUNT_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100202_PAYAMOUNT_DAY.data_source
  is '������Դ';
create index IDX82_100202 on FACT_100202_PAYAMOUNT_DAY (CHANNELID);
create index IDX83_100202 on FACT_100202_PAYAMOUNT_DAY (SERVERID);
create index IDX84_100202 on FACT_100202_PAYAMOUNT_DAY (STATDATE);

prompt
prompt Creating table FACT_100202_PAYAMOUNT_MONTH
prompt ==========================================
prompt
create table FACT_100202_PAYAMOUNT_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_PAYAMOUNT_MONTH
  is '�³�ֵ��������';
comment on column FACT_100202_PAYAMOUNT_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100202_PAYAMOUNT_MONTH.channelid
  is '����';
comment on column FACT_100202_PAYAMOUNT_MONTH.serverid
  is '����';
comment on column FACT_100202_PAYAMOUNT_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100202_PAYAMOUNT_MONTH.appid
  is '��Ʒid';
comment on column FACT_100202_PAYAMOUNT_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_PAYAMOUNT_MONTH.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100202_PAYAMOUNT_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100202_PAYAMOUNT_MONTH.data_source
  is '������Դ';
create index IDX88_100202 on FACT_100202_PAYAMOUNT_MONTH (CHANNELID);
create index IDX89_100202 on FACT_100202_PAYAMOUNT_MONTH (SERVERID);
create index IDX90_100202 on FACT_100202_PAYAMOUNT_MONTH (STATDATE);

prompt
prompt Creating table FACT_100202_PAYAMOUNT_WEEK
prompt =========================================
prompt
create table FACT_100202_PAYAMOUNT_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_PAYAMOUNT_WEEK
  is '�ܳ�ֵ��������';
comment on column FACT_100202_PAYAMOUNT_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100202_PAYAMOUNT_WEEK.channelid
  is '����';
comment on column FACT_100202_PAYAMOUNT_WEEK.serverid
  is '����';
comment on column FACT_100202_PAYAMOUNT_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100202_PAYAMOUNT_WEEK.appid
  is '��Ʒid';
comment on column FACT_100202_PAYAMOUNT_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_PAYAMOUNT_WEEK.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100202_PAYAMOUNT_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100202_PAYAMOUNT_WEEK.data_source
  is '������Դ';
create index IDX85_100202 on FACT_100202_PAYAMOUNT_WEEK (CHANNELID);
create index IDX86_100202 on FACT_100202_PAYAMOUNT_WEEK (SERVERID);
create index IDX87_100202 on FACT_100202_PAYAMOUNT_WEEK (STATDATE);

prompt
prompt Creating table FACT_100202_PAYNUM_DAY
prompt =====================================
prompt
create table FACT_100202_PAYNUM_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_PAYNUM_DAY
  is '�ճ�ֵ����������';
comment on column FACT_100202_PAYNUM_DAY.statdate
  is 'ͳ������';
comment on column FACT_100202_PAYNUM_DAY.channelid
  is '����';
comment on column FACT_100202_PAYNUM_DAY.serverid
  is '����';
comment on column FACT_100202_PAYNUM_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100202_PAYNUM_DAY.appid
  is '��Ʒid';
comment on column FACT_100202_PAYNUM_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_PAYNUM_DAY.paynum
  is '��ֵ����';
comment on column FACT_100202_PAYNUM_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100202_PAYNUM_DAY.data_source
  is '������Դ';
create index IDX97_100202 on FACT_100202_PAYNUM_DAY (CHANNELID);
create index IDX98_100202 on FACT_100202_PAYNUM_DAY (SERVERID);
create index IDX99_100202 on FACT_100202_PAYNUM_DAY (STATDATE);

prompt
prompt Creating table FACT_100202_PAYNUM_MONTH
prompt =======================================
prompt
create table FACT_100202_PAYNUM_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_PAYNUM_MONTH
  is '�³�ֵ����������';
comment on column FACT_100202_PAYNUM_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100202_PAYNUM_MONTH.channelid
  is '����';
comment on column FACT_100202_PAYNUM_MONTH.serverid
  is '����';
comment on column FACT_100202_PAYNUM_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100202_PAYNUM_MONTH.appid
  is '��Ʒid';
comment on column FACT_100202_PAYNUM_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_PAYNUM_MONTH.paynum
  is '��ֵ����';
comment on column FACT_100202_PAYNUM_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100202_PAYNUM_MONTH.data_source
  is '������Դ';
create index IDX91_100202 on FACT_100202_PAYNUM_MONTH (CHANNELID);
create index IDX92_100202 on FACT_100202_PAYNUM_MONTH (SERVERID);
create index IDX93_100202 on FACT_100202_PAYNUM_MONTH (STATDATE);

prompt
prompt Creating table FACT_100202_PAYNUM_WEEK
prompt ======================================
prompt
create table FACT_100202_PAYNUM_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_PAYNUM_WEEK
  is '�ܳ�ֵ����������';
comment on column FACT_100202_PAYNUM_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100202_PAYNUM_WEEK.channelid
  is '����';
comment on column FACT_100202_PAYNUM_WEEK.serverid
  is '����';
comment on column FACT_100202_PAYNUM_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100202_PAYNUM_WEEK.appid
  is '��Ʒid';
comment on column FACT_100202_PAYNUM_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_PAYNUM_WEEK.paynum
  is '��ֵ����';
comment on column FACT_100202_PAYNUM_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100202_PAYNUM_WEEK.data_source
  is '������Դ';
create index IDX94_100202 on FACT_100202_PAYNUM_WEEK (CHANNELID);
create index IDX95_100202 on FACT_100202_PAYNUM_WEEK (SERVERID);
create index IDX96_100202 on FACT_100202_PAYNUM_WEEK (STATDATE);

prompt
prompt Creating table FACT_100202_PAYTYPE
prompt ==================================
prompt
create table FACT_100202_PAYTYPE
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paytypeid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_PAYTYPE
  is '��ֵ���ͷ�����';
comment on column FACT_100202_PAYTYPE.statdate
  is 'ͳ������';
comment on column FACT_100202_PAYTYPE.channelid
  is '����';
comment on column FACT_100202_PAYTYPE.serverid
  is '����';
comment on column FACT_100202_PAYTYPE.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100202_PAYTYPE.appid
  is '��Ʒid';
comment on column FACT_100202_PAYTYPE.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_PAYTYPE.paytypeid
  is '��ֵ����';
comment on column FACT_100202_PAYTYPE.payamount
  is '��ֵ���';
comment on column FACT_100202_PAYTYPE.paycount
  is '��ֵ����';
comment on column FACT_100202_PAYTYPE.paynum
  is '��ֵ����';
comment on column FACT_100202_PAYTYPE.data_source
  is '������Դ';
create index IDX100_100202 on FACT_100202_PAYTYPE (CHANNELID);
create index IDX101_100202 on FACT_100202_PAYTYPE (SERVERID);
create index IDX102_100202 on FACT_100202_PAYTYPE (STATDATE);

prompt
prompt Creating table FACT_100202_PAYWAY
prompt =================================
prompt
create table FACT_100202_PAYWAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paywayid    VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_PAYWAY
  is '��ֵ��ʽ������';
comment on column FACT_100202_PAYWAY.statdate
  is 'ͳ������';
comment on column FACT_100202_PAYWAY.channelid
  is '����';
comment on column FACT_100202_PAYWAY.serverid
  is '����';
comment on column FACT_100202_PAYWAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100202_PAYWAY.appid
  is '��Ʒid';
comment on column FACT_100202_PAYWAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_PAYWAY.paywayid
  is '��ֵ��ʽ';
comment on column FACT_100202_PAYWAY.payamount
  is '��ֵ���';
comment on column FACT_100202_PAYWAY.paycount
  is '��ֵ����';
comment on column FACT_100202_PAYWAY.paynum
  is '��ֵ����';
comment on column FACT_100202_PAYWAY.data_source
  is '������Դ';
create index IDX103_100202 on FACT_100202_PAYWAY (CHANNELID);
create index IDX104_100202 on FACT_100202_PAYWAY (SERVERID);
create index IDX105_100202 on FACT_100202_PAYWAY (STATDATE);

prompt
prompt Creating table FACT_100202_REGION
prompt =================================
prompt
create table FACT_100202_REGION
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  country     VARCHAR2(50),
  province    VARCHAR2(50),
  city        VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_REGION
  is '���������';
comment on column FACT_100202_REGION.statdate
  is 'ͳ������';
comment on column FACT_100202_REGION.channelid
  is '����';
comment on column FACT_100202_REGION.serverid
  is '����';
comment on column FACT_100202_REGION.appid
  is '��Ʒid';
comment on column FACT_100202_REGION.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_REGION.country
  is '����';
comment on column FACT_100202_REGION.province
  is 'ʡ';
comment on column FACT_100202_REGION.city
  is '��';
comment on column FACT_100202_REGION.newcount
  is '������';
comment on column FACT_100202_REGION.conncount
  is '������';
comment on column FACT_100202_REGION.paycount
  is '������';
comment on column FACT_100202_REGION.payamount
  is '���ѽ��';
comment on column FACT_100202_REGION.data_source
  is '������Դ';
create index IDX106_100202 on FACT_100202_REGION (CHANNELID);
create index IDX107_100202 on FACT_100202_REGION (SERVERID);
create index IDX108_100202 on FACT_100202_REGION (STATDATE);

prompt
prompt Creating table FACT_100202_REMAIN_MAC
prompt =====================================
prompt
create table FACT_100202_REMAIN_MAC
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_REMAIN_MAC
  is '�豸�����';
comment on column FACT_100202_REMAIN_MAC.statdate
  is 'ͳ������';
comment on column FACT_100202_REMAIN_MAC.conndate
  is '��������';
comment on column FACT_100202_REMAIN_MAC.channelid
  is '����ID';
comment on column FACT_100202_REMAIN_MAC.serverid
  is '����ID';
comment on column FACT_100202_REMAIN_MAC.appid
  is '��ƷID';
comment on column FACT_100202_REMAIN_MAC.remain_days
  is '��������';
comment on column FACT_100202_REMAIN_MAC.new_remain
  is '��������';
comment on column FACT_100202_REMAIN_MAC.conn_remain
  is '��������';
comment on column FACT_100202_REMAIN_MAC.pay_remain
  is '��������';
comment on column FACT_100202_REMAIN_MAC.data_source
  is '����Դ';
create index IDX109_100202 on FACT_100202_REMAIN_MAC (CHANNELID);
create index IDX110_100202 on FACT_100202_REMAIN_MAC (SERVERID);
create index IDX111_100202 on FACT_100202_REMAIN_MAC (STATDATE);

prompt
prompt Creating table FACT_100202_REMAIN_USER
prompt ======================================
prompt
create table FACT_100202_REMAIN_USER
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_REMAIN_USER
  is '�û������';
comment on column FACT_100202_REMAIN_USER.statdate
  is 'ͳ������';
comment on column FACT_100202_REMAIN_USER.conndate
  is '��������';
comment on column FACT_100202_REMAIN_USER.channelid
  is '����ID';
comment on column FACT_100202_REMAIN_USER.serverid
  is '����ID';
comment on column FACT_100202_REMAIN_USER.appid
  is '��ƷID';
comment on column FACT_100202_REMAIN_USER.remain_days
  is '��������';
comment on column FACT_100202_REMAIN_USER.new_remain
  is '��������';
comment on column FACT_100202_REMAIN_USER.conn_remain
  is '��������';
comment on column FACT_100202_REMAIN_USER.pay_remain
  is '��������';
comment on column FACT_100202_REMAIN_USER.data_source
  is '����Դ';
create index IDX112_100202 on FACT_100202_REMAIN_USER (CHANNELID);
create index IDX113_100202 on FACT_100202_REMAIN_USER (SERVERID);
create index IDX114_100202 on FACT_100202_REMAIN_USER (STATDATE);

prompt
prompt Creating table FACT_100202_VC
prompt =============================
prompt
create table FACT_100202_VC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcamount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100202_VC
  is '������ҷ�����';
comment on column FACT_100202_VC.statdate
  is 'ͳ������';
comment on column FACT_100202_VC.channelid
  is '����';
comment on column FACT_100202_VC.serverid
  is '����';
comment on column FACT_100202_VC.appid
  is '��Ʒid';
comment on column FACT_100202_VC.versionid
  is '��Ʒ�汾';
comment on column FACT_100202_VC.vctype
  is '�����������';
comment on column FACT_100202_VC.vcusetype
  is '�������ʹ������';
comment on column FACT_100202_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column FACT_100202_VC.vcamount
  is '������ҽ��';
comment on column FACT_100202_VC.data_source
  is '������Դ';
create index IDX115_100202 on FACT_100202_VC (CHANNELID);
create index IDX116_100202 on FACT_100202_VC (SERVERID);
create index IDX117_100202 on FACT_100202_VC (STATDATE);

prompt
prompt Creating table FACT_100209_BACK_MAC
prompt ===================================
prompt
create table FACT_100209_BACK_MAC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_BACK_MAC
  is '�豸����������';
comment on column FACT_100209_BACK_MAC.statdate
  is 'ͳ������';
comment on column FACT_100209_BACK_MAC.channelid
  is '����ID';
comment on column FACT_100209_BACK_MAC.serverid
  is '����ID';
comment on column FACT_100209_BACK_MAC.appid
  is '��ƷID';
comment on column FACT_100209_BACK_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100209_BACK_MAC.back_conn
  is '��Ծ�豸������';
comment on column FACT_100209_BACK_MAC.back_pay
  is '�����豸������';
comment on column FACT_100209_BACK_MAC.data_source
  is '����Դ';
create index IDX1_100209 on FACT_100209_BACK_MAC (CHANNELID);
create index IDX2_100209 on FACT_100209_BACK_MAC (SERVERID);
create index IDX3_100209 on FACT_100209_BACK_MAC (STATDATE);

prompt
prompt Creating table FACT_100209_BACK_MAC_MONTH
prompt =========================================
prompt
create table FACT_100209_BACK_MAC_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_BACK_MAC_MONTH
  is '�豸����������';
comment on column FACT_100209_BACK_MAC_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100209_BACK_MAC_MONTH.channelid
  is '����ID';
comment on column FACT_100209_BACK_MAC_MONTH.serverid
  is '����ID';
comment on column FACT_100209_BACK_MAC_MONTH.appid
  is '��ƷID';
comment on column FACT_100209_BACK_MAC_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100209_BACK_MAC_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100209_BACK_MAC_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100209_BACK_MAC_MONTH.data_source
  is '����Դ';
create index IDX4_100209 on FACT_100209_BACK_MAC_MONTH (CHANNELID);
create index IDX5_100209 on FACT_100209_BACK_MAC_MONTH (SERVERID);
create index IDX6_100209 on FACT_100209_BACK_MAC_MONTH (STATDATE);

prompt
prompt Creating table FACT_100209_BACK_MAC_WEEK
prompt ========================================
prompt
create table FACT_100209_BACK_MAC_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_BACK_MAC_WEEK
  is '�豸����������';
comment on column FACT_100209_BACK_MAC_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100209_BACK_MAC_WEEK.channelid
  is '����ID';
comment on column FACT_100209_BACK_MAC_WEEK.serverid
  is '����ID';
comment on column FACT_100209_BACK_MAC_WEEK.appid
  is '��ƷID';
comment on column FACT_100209_BACK_MAC_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100209_BACK_MAC_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100209_BACK_MAC_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100209_BACK_MAC_WEEK.data_source
  is '����Դ';
create index IDX7_100209 on FACT_100209_BACK_MAC_WEEK (CHANNELID);
create index IDX8_100209 on FACT_100209_BACK_MAC_WEEK (SERVERID);
create index IDX9_100209 on FACT_100209_BACK_MAC_WEEK (STATDATE);

prompt
prompt Creating table FACT_100209_BACK_USER
prompt ====================================
prompt
create table FACT_100209_BACK_USER
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_BACK_USER
  is '�û�����������';
comment on column FACT_100209_BACK_USER.statdate
  is 'ͳ������';
comment on column FACT_100209_BACK_USER.channelid
  is '����ID';
comment on column FACT_100209_BACK_USER.serverid
  is '����ID';
comment on column FACT_100209_BACK_USER.appid
  is '��ƷID';
comment on column FACT_100209_BACK_USER.lost_days
  is '��ʧ����';
comment on column FACT_100209_BACK_USER.back_conn
  is '��Ծ�û�������';
comment on column FACT_100209_BACK_USER.back_pay
  is '�����û�������';
comment on column FACT_100209_BACK_USER.data_source
  is '����Դ';
create index IDX16_100209 on FACT_100209_BACK_USER (CHANNELID);
create index IDX17_100209 on FACT_100209_BACK_USER (SERVERID);
create index IDX18_100209 on FACT_100209_BACK_USER (STATDATE);

prompt
prompt Creating table FACT_100209_BACK_USER_MONTH
prompt ==========================================
prompt
create table FACT_100209_BACK_USER_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_BACK_USER_MONTH
  is '�豸����������';
comment on column FACT_100209_BACK_USER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100209_BACK_USER_MONTH.channelid
  is '����ID';
comment on column FACT_100209_BACK_USER_MONTH.serverid
  is '����ID';
comment on column FACT_100209_BACK_USER_MONTH.appid
  is '��ƷID';
comment on column FACT_100209_BACK_USER_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100209_BACK_USER_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100209_BACK_USER_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100209_BACK_USER_MONTH.data_source
  is '����Դ';
create index IDX13_100209 on FACT_100209_BACK_USER_MONTH (CHANNELID);
create index IDX14_100209 on FACT_100209_BACK_USER_MONTH (SERVERID);
create index IDX15_100209 on FACT_100209_BACK_USER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100209_BACK_USER_WEEK
prompt =========================================
prompt
create table FACT_100209_BACK_USER_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_BACK_USER_WEEK
  is '�豸����������';
comment on column FACT_100209_BACK_USER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100209_BACK_USER_WEEK.channelid
  is '����ID';
comment on column FACT_100209_BACK_USER_WEEK.serverid
  is '����ID';
comment on column FACT_100209_BACK_USER_WEEK.appid
  is '��ƷID';
comment on column FACT_100209_BACK_USER_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100209_BACK_USER_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100209_BACK_USER_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100209_BACK_USER_WEEK.data_source
  is '����Դ';
create index IDX10_100209 on FACT_100209_BACK_USER_WEEK (CHANNELID);
create index IDX11_100209 on FACT_100209_BACK_USER_WEEK (SERVERID);
create index IDX12_100209 on FACT_100209_BACK_USER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100209_CEVENT
prompt =================================
prompt
create table FACT_100209_CEVENT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  eventkey    VARCHAR2(50),
  eventcount  NUMBER,
  eventnum    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_CEVENT
  is '�Զ��������';
comment on column FACT_100209_CEVENT.statdate
  is 'ͳ������';
comment on column FACT_100209_CEVENT.channelid
  is '����';
comment on column FACT_100209_CEVENT.serverid
  is '����';
comment on column FACT_100209_CEVENT.appid
  is '��Ʒid';
comment on column FACT_100209_CEVENT.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100209_CEVENT.eventcount
  is '�¼��û���';
comment on column FACT_100209_CEVENT.eventnum
  is '�¼�����';
comment on column FACT_100209_CEVENT.data_source
  is '������Դ';
create index IDX181_100209 on FACT_100209_CEVENT (CHANNELID);
create index IDX182_100209 on FACT_100209_CEVENT (SERVERID);
create index IDX183_100209 on FACT_100209_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100209_CEVENT_PAR
prompt =====================================
prompt
create table FACT_100209_CEVENT_PAR
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  ilevel         NUMBER,
  eventkey       VARCHAR2(100),
  eventpar_key   VARCHAR2(100),
  eventpar_value VARCHAR2(100),
  eventcount     NUMBER,
  eventnum       NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100209_CEVENT_PAR
  is '�Զ������������';
comment on column FACT_100209_CEVENT_PAR.statdate
  is 'ͳ������';
comment on column FACT_100209_CEVENT_PAR.channelid
  is '����';
comment on column FACT_100209_CEVENT_PAR.serverid
  is '����';
comment on column FACT_100209_CEVENT_PAR.appid
  is '��Ʒid';
comment on column FACT_100209_CEVENT_PAR.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_CEVENT_PAR.ilevel
  is '��ɫ�ȼ�';
comment on column FACT_100209_CEVENT_PAR.eventkey
  is '�¼�����';
comment on column FACT_100209_CEVENT_PAR.eventpar_key
  is '�¼�����';
comment on column FACT_100209_CEVENT_PAR.eventpar_value
  is '�¼�����ֵ';
comment on column FACT_100209_CEVENT_PAR.eventcount
  is '�¼��û���';
comment on column FACT_100209_CEVENT_PAR.eventnum
  is '�¼�����';
comment on column FACT_100209_CEVENT_PAR.data_source
  is '������Դ';
create index IDX185_100209 on FACT_100209_CEVENT_PAR (CHANNELID);
create index IDX186_100209 on FACT_100209_CEVENT_PAR (SERVERID);
create index IDX187_100209 on FACT_100209_CEVENT_PAR (STATDATE);

prompt
prompt Creating table FACT_100209_COMP_CEVENT
prompt ======================================
prompt
create table FACT_100209_COMP_CEVENT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(10),
  channelid   VARCHAR2(50),
  gameversion VARCHAR2(50),
  serverid    VARCHAR2(50),
  ilevel      NUMBER,
  eventkey    VARCHAR2(100),
  compid      VARCHAR2(50),
  caltype     VARCHAR2(50),
  dimpars     VARCHAR2(2000),
  comp_data   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_COMP_CEVENT
  is '�Զ����¼���Ϸ�����';
comment on column FACT_100209_COMP_CEVENT.statdate
  is '����';
comment on column FACT_100209_COMP_CEVENT.appid
  is '��Ϸ�� appid';
comment on column FACT_100209_COMP_CEVENT.channelid
  is '���� ID';
comment on column FACT_100209_COMP_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column FACT_100209_COMP_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column FACT_100209_COMP_CEVENT.ilevel
  is '��ҵȼ�';
comment on column FACT_100209_COMP_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100209_COMP_CEVENT.compid
  is '��ϼ����¼�ID';
comment on column FACT_100209_COMP_CEVENT.caltype
  is '��ϼ����¼���������';
comment on column FACT_100209_COMP_CEVENT.dimpars
  is '��ϲ���';
comment on column FACT_100209_COMP_CEVENT.comp_data
  is '��ϼ�����';
create index IDX184_100209 on FACT_100209_COMP_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100209_DAILY_REPORT
prompt =======================================
prompt
create table FACT_100209_DAILY_REPORT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_DAILY_REPORT
  is '�ձ�����';
comment on column FACT_100209_DAILY_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100209_DAILY_REPORT.appid
  is '��ƷID';
comment on column FACT_100209_DAILY_REPORT.channelid
  is '����';
comment on column FACT_100209_DAILY_REPORT.serverid
  is '����';
comment on column FACT_100209_DAILY_REPORT.indexid
  is 'ָ��';
comment on column FACT_100209_DAILY_REPORT.indtype
  is 'ָ������';
comment on column FACT_100209_DAILY_REPORT.rpt_data
  is '����';
create index IDX176_100209 on FACT_100209_DAILY_REPORT (STATDATE);

prompt
prompt Creating table FACT_100209_DVID
prompt ===============================
prompt
create table FACT_100209_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_model  VARCHAR2(200),
  dvid_res    VARCHAR2(50),
  dvid_os     VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_DVID
  is '�豸������';
comment on column FACT_100209_DVID.statdate
  is 'ͳ������';
comment on column FACT_100209_DVID.channelid
  is '����';
comment on column FACT_100209_DVID.serverid
  is '����';
comment on column FACT_100209_DVID.appid
  is '��Ʒid';
comment on column FACT_100209_DVID.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_DVID.dvid_model
  is '����';
comment on column FACT_100209_DVID.dvid_res
  is '�豸�ֱ���';
comment on column FACT_100209_DVID.dvid_os
  is '�豸����ϵͳ';
comment on column FACT_100209_DVID.newcount
  is '�����û���';
comment on column FACT_100209_DVID.conncount
  is '�����û���';
comment on column FACT_100209_DVID.data_source
  is '������Դ';
create index IDX19_100209 on FACT_100209_DVID (CHANNELID);
create index IDX20_100209 on FACT_100209_DVID (SERVERID);
create index IDX21_100209 on FACT_100209_DVID (STATDATE);

prompt
prompt Creating table FACT_100209_FIRSTPAY
prompt ===================================
prompt
create table FACT_100209_FIRSTPAY
(
  statdate         VARCHAR2(10),
  firstpaydate     VARCHAR2(10),
  channelid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  datatype         VARCHAR2(50),
  appid            VARCHAR2(50),
  first_payfromreg NUMBER,
  first_paycount   NUMBER,
  payamount        NUMBER,
  loaddate         DATE default SYSDATE,
  data_source      VARCHAR2(100)
)
;
comment on table FACT_100209_FIRSTPAY
  is '�����û��״γ�ֵ������';
comment on column FACT_100209_FIRSTPAY.statdate
  is 'ͳ������';
comment on column FACT_100209_FIRSTPAY.firstpaydate
  is '�״θ�������';
comment on column FACT_100209_FIRSTPAY.channelid
  is '����';
comment on column FACT_100209_FIRSTPAY.serverid
  is '����';
comment on column FACT_100209_FIRSTPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100209_FIRSTPAY.appid
  is '��Ʒid';
comment on column FACT_100209_FIRSTPAY.first_payfromreg
  is 'ע���ڼ��쿪ʼ��ֵ(1��2��..7..30..)';
comment on column FACT_100209_FIRSTPAY.first_paycount
  is '���������û���';
comment on column FACT_100209_FIRSTPAY.payamount
  is '�ۼƵ��ڼ���ĳ�ֵ�ܶ�';
comment on column FACT_100209_FIRSTPAY.data_source
  is '������Դ';
create index IDX22_100209 on FACT_100209_FIRSTPAY (CHANNELID);
create index IDX23_100209 on FACT_100209_FIRSTPAY (SERVERID);
create index IDX24_100209 on FACT_100209_FIRSTPAY (STATDATE);

prompt
prompt Creating table FACT_100209_FIRSTPAY_AMOUNT
prompt ==========================================
prompt
create table FACT_100209_FIRSTPAY_AMOUNT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_FIRSTPAY_AMOUNT
  is '�״θ��ѽ�������';
comment on column FACT_100209_FIRSTPAY_AMOUNT.statdate
  is 'ͳ������';
comment on column FACT_100209_FIRSTPAY_AMOUNT.channelid
  is '����';
comment on column FACT_100209_FIRSTPAY_AMOUNT.serverid
  is '��������';
comment on column FACT_100209_FIRSTPAY_AMOUNT.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100209_FIRSTPAY_AMOUNT.appid
  is '��Ʒid';
comment on column FACT_100209_FIRSTPAY_AMOUNT.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_FIRSTPAY_AMOUNT.payamount
  is '�״θ��ѽ��';
comment on column FACT_100209_FIRSTPAY_AMOUNT.paycount
  is '�״θ��ѽ���Ӧ������';
create index IDX25_100209 on FACT_100209_FIRSTPAY_AMOUNT (CHANNELID);
create index IDX26_100209 on FACT_100209_FIRSTPAY_AMOUNT (SERVERID);
create index IDX27_100209 on FACT_100209_FIRSTPAY_AMOUNT (STATDATE);

prompt
prompt Creating table FACT_100209_GENERAL_DAY
prompt ======================================
prompt
create table FACT_100209_GENERAL_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_GENERAL_DAY
  is '�ջ���������';
comment on column FACT_100209_GENERAL_DAY.statdate
  is 'ͳ������';
comment on column FACT_100209_GENERAL_DAY.channelid
  is '����';
comment on column FACT_100209_GENERAL_DAY.serverid
  is '����';
comment on column FACT_100209_GENERAL_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100209_GENERAL_DAY.appid
  is '��Ʒid';
comment on column FACT_100209_GENERAL_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_GENERAL_DAY.newcount
  is '������';
comment on column FACT_100209_GENERAL_DAY.conncount
  is '������';
comment on column FACT_100209_GENERAL_DAY.paycount
  is '������';
comment on column FACT_100209_GENERAL_DAY.payamount
  is '���ѽ��';
comment on column FACT_100209_GENERAL_DAY.data_source
  is '������Դ';
create index IDX28_100209 on FACT_100209_GENERAL_DAY (CHANNELID);
create index IDX29_100209 on FACT_100209_GENERAL_DAY (SERVERID);
create index IDX30_100209 on FACT_100209_GENERAL_DAY (STATDATE);

prompt
prompt Creating table FACT_100209_GENERAL_DAY_DVID
prompt ===========================================
prompt
create table FACT_100209_GENERAL_DAY_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_GENERAL_DAY_DVID
  is '���豸����������';
comment on column FACT_100209_GENERAL_DAY_DVID.statdate
  is 'ͳ������';
comment on column FACT_100209_GENERAL_DAY_DVID.channelid
  is '����';
comment on column FACT_100209_GENERAL_DAY_DVID.appid
  is '��Ʒid';
comment on column FACT_100209_GENERAL_DAY_DVID.newcount
  is '������';
comment on column FACT_100209_GENERAL_DAY_DVID.conncount
  is '������';
comment on column FACT_100209_GENERAL_DAY_DVID.data_source
  is '������Դ';
create index IDX31_100209 on FACT_100209_GENERAL_DAY_DVID (CHANNELID);
create index IDX33_100209 on FACT_100209_GENERAL_DAY_DVID (STATDATE);

prompt
prompt Creating table FACT_100209_GENERAL_HOUR
prompt =======================================
prompt
create table FACT_100209_GENERAL_HOUR
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_GENERAL_HOUR
  is 'Сʱ����������';
comment on column FACT_100209_GENERAL_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100209_GENERAL_HOUR.channelid
  is '����';
comment on column FACT_100209_GENERAL_HOUR.serverid
  is '����';
comment on column FACT_100209_GENERAL_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100209_GENERAL_HOUR.appid
  is '��Ʒid';
comment on column FACT_100209_GENERAL_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_GENERAL_HOUR.newcount
  is '������';
comment on column FACT_100209_GENERAL_HOUR.conncount
  is '������';
comment on column FACT_100209_GENERAL_HOUR.paycount
  is '������';
comment on column FACT_100209_GENERAL_HOUR.payamount
  is '���ѽ��';
comment on column FACT_100209_GENERAL_HOUR.data_source
  is '������Դ';
create index IDX34_100209 on FACT_100209_GENERAL_HOUR (CHANNELID);
create index IDX35_100209 on FACT_100209_GENERAL_HOUR (SERVERID);
create index IDX36_100209 on FACT_100209_GENERAL_HOUR (STATDATE);

prompt
prompt Creating table FACT_100209_GENERAL_HOUR_DVID
prompt ============================================
prompt
create table FACT_100209_GENERAL_HOUR_DVID
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_GENERAL_HOUR_DVID
  is 'Сʱ�豸����������';
comment on column FACT_100209_GENERAL_HOUR_DVID.statdate
  is 'ͳ������';
comment on column FACT_100209_GENERAL_HOUR_DVID.channelid
  is '����';
comment on column FACT_100209_GENERAL_HOUR_DVID.appid
  is '��Ʒid';
comment on column FACT_100209_GENERAL_HOUR_DVID.newcount
  is '������';
comment on column FACT_100209_GENERAL_HOUR_DVID.conncount
  is '������';
comment on column FACT_100209_GENERAL_HOUR_DVID.data_source
  is '������Դ';
create index IDX37_100209 on FACT_100209_GENERAL_HOUR_DVID (CHANNELID);
create index IDX39_100209 on FACT_100209_GENERAL_HOUR_DVID (STATDATE);

prompt
prompt Creating table FACT_100209_GENERAL_LEVEL
prompt ========================================
prompt
create table FACT_100209_GENERAL_LEVEL
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  rolelevel   NUMBER,
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_GENERAL_LEVEL
  is '�û��ȼ�������';
comment on column FACT_100209_GENERAL_LEVEL.statdate
  is 'ͳ������';
comment on column FACT_100209_GENERAL_LEVEL.channelid
  is '����';
comment on column FACT_100209_GENERAL_LEVEL.serverid
  is '����';
comment on column FACT_100209_GENERAL_LEVEL.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100209_GENERAL_LEVEL.appid
  is '��Ʒid';
comment on column FACT_100209_GENERAL_LEVEL.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_GENERAL_LEVEL.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100209_GENERAL_LEVEL.newcount
  is '������';
comment on column FACT_100209_GENERAL_LEVEL.conncount
  is '������';
comment on column FACT_100209_GENERAL_LEVEL.paycount
  is '������';
comment on column FACT_100209_GENERAL_LEVEL.payamount
  is '���ѽ��';
comment on column FACT_100209_GENERAL_LEVEL.data_source
  is '������Դ';
create index IDX40_100209 on FACT_100209_GENERAL_LEVEL (CHANNELID);
create index IDX41_100209 on FACT_100209_GENERAL_LEVEL (SERVERID);
create index IDX42_100209 on FACT_100209_GENERAL_LEVEL (STATDATE);

prompt
prompt Creating table FACT_100209_GENERAL_MONTH
prompt ========================================
prompt
create table FACT_100209_GENERAL_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_GENERAL_MONTH
  is '�»���������';
comment on column FACT_100209_GENERAL_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100209_GENERAL_MONTH.channelid
  is '����';
comment on column FACT_100209_GENERAL_MONTH.serverid
  is '����';
comment on column FACT_100209_GENERAL_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100209_GENERAL_MONTH.appid
  is '��Ʒid';
comment on column FACT_100209_GENERAL_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_GENERAL_MONTH.newcount
  is '������';
comment on column FACT_100209_GENERAL_MONTH.conncount
  is '������';
comment on column FACT_100209_GENERAL_MONTH.paycount
  is '������';
comment on column FACT_100209_GENERAL_MONTH.payamount
  is '���ѽ��';
comment on column FACT_100209_GENERAL_MONTH.data_source
  is '������Դ';
create index IDX43_100209 on FACT_100209_GENERAL_MONTH (CHANNELID);
create index IDX44_100209 on FACT_100209_GENERAL_MONTH (SERVERID);
create index IDX45_100209 on FACT_100209_GENERAL_MONTH (STATDATE);

prompt
prompt Creating table FACT_100209_GENERAL_MONTH_DVID
prompt =============================================
prompt
create table FACT_100209_GENERAL_MONTH_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_GENERAL_MONTH_DVID
  is '���豸����������';
comment on column FACT_100209_GENERAL_MONTH_DVID.statdate
  is 'ͳ������';
comment on column FACT_100209_GENERAL_MONTH_DVID.channelid
  is '����';
comment on column FACT_100209_GENERAL_MONTH_DVID.appid
  is '��Ʒid';
comment on column FACT_100209_GENERAL_MONTH_DVID.newcount
  is '������';
comment on column FACT_100209_GENERAL_MONTH_DVID.conncount
  is '������';
comment on column FACT_100209_GENERAL_MONTH_DVID.data_source
  is '������Դ';
create index IDX46_100209 on FACT_100209_GENERAL_MONTH_DVID (CHANNELID);
create index IDX48_100209 on FACT_100209_GENERAL_MONTH_DVID (STATDATE);

prompt
prompt Creating table FACT_100209_GENERAL_WEEK
prompt =======================================
prompt
create table FACT_100209_GENERAL_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_GENERAL_WEEK
  is '�ܻ���������';
comment on column FACT_100209_GENERAL_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100209_GENERAL_WEEK.channelid
  is '����';
comment on column FACT_100209_GENERAL_WEEK.serverid
  is '����';
comment on column FACT_100209_GENERAL_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100209_GENERAL_WEEK.appid
  is '��Ʒid';
comment on column FACT_100209_GENERAL_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_GENERAL_WEEK.newcount
  is '������';
comment on column FACT_100209_GENERAL_WEEK.conncount
  is '������';
comment on column FACT_100209_GENERAL_WEEK.paycount
  is '������';
comment on column FACT_100209_GENERAL_WEEK.payamount
  is '���ѽ��';
comment on column FACT_100209_GENERAL_WEEK.data_source
  is '������Դ';
create index IDX52_100209 on FACT_100209_GENERAL_WEEK (CHANNELID);
create index IDX53_100209 on FACT_100209_GENERAL_WEEK (SERVERID);
create index IDX54_100209 on FACT_100209_GENERAL_WEEK (STATDATE);

prompt
prompt Creating table FACT_100209_GENERAL_WEEK_DVID
prompt ============================================
prompt
create table FACT_100209_GENERAL_WEEK_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_GENERAL_WEEK_DVID
  is '���豸����������';
comment on column FACT_100209_GENERAL_WEEK_DVID.statdate
  is 'ͳ������';
comment on column FACT_100209_GENERAL_WEEK_DVID.channelid
  is '����';
comment on column FACT_100209_GENERAL_WEEK_DVID.appid
  is '��Ʒid';
comment on column FACT_100209_GENERAL_WEEK_DVID.newcount
  is '������';
comment on column FACT_100209_GENERAL_WEEK_DVID.conncount
  is '������';
comment on column FACT_100209_GENERAL_WEEK_DVID.data_source
  is '������Դ';
create index IDX49_100209 on FACT_100209_GENERAL_WEEK_DVID (CHANNELID);
create index IDX51_100209 on FACT_100209_GENERAL_WEEK_DVID (STATDATE);

prompt
prompt Creating table FACT_100209_HOUR_REPORT
prompt ======================================
prompt
create table FACT_100209_HOUR_REPORT
(
  statdate    VARCHAR2(20),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_HOUR_REPORT
  is '�ձ�Сʱ����';
comment on column FACT_100209_HOUR_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100209_HOUR_REPORT.appid
  is '��ƷID';
comment on column FACT_100209_HOUR_REPORT.channelid
  is '����';
comment on column FACT_100209_HOUR_REPORT.serverid
  is '����';
comment on column FACT_100209_HOUR_REPORT.indexid
  is 'ָ��';
comment on column FACT_100209_HOUR_REPORT.indtype
  is 'ָ������';
comment on column FACT_100209_HOUR_REPORT.rpt_data
  is '����';

prompt
prompt Creating table FACT_100209_LEVELPAY
prompt ===================================
prompt
create table FACT_100209_LEVELPAY
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  datatype       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  rolelevel      NUMBER,
  paycount       NUMBER,
  first_paycount NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100209_LEVELPAY
  is '�û���ɫ�ȼ����ѷ�����';
comment on column FACT_100209_LEVELPAY.statdate
  is 'ͳ������';
comment on column FACT_100209_LEVELPAY.channelid
  is '����';
comment on column FACT_100209_LEVELPAY.serverid
  is '����';
comment on column FACT_100209_LEVELPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100209_LEVELPAY.appid
  is '��Ʒid';
comment on column FACT_100209_LEVELPAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_LEVELPAY.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100209_LEVELPAY.paycount
  is '�����û���';
comment on column FACT_100209_LEVELPAY.first_paycount
  is '���������û������״θ����û���';
comment on column FACT_100209_LEVELPAY.data_source
  is '������Դ';
create index IDX55_100209 on FACT_100209_LEVELPAY (CHANNELID);
create index IDX56_100209 on FACT_100209_LEVELPAY (SERVERID);
create index IDX57_100209 on FACT_100209_LEVELPAY (STATDATE);

prompt
prompt Creating table FACT_100209_LOST_MAC
prompt ===================================
prompt
create table FACT_100209_LOST_MAC
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_LOST_MAC
  is '�豸��ʧ������';
comment on column FACT_100209_LOST_MAC.statdate
  is 'ͳ������';
comment on column FACT_100209_LOST_MAC.lostdate
  is '��ʧ����';
comment on column FACT_100209_LOST_MAC.channelid
  is '����ID';
comment on column FACT_100209_LOST_MAC.serverid
  is '����ID';
comment on column FACT_100209_LOST_MAC.appid
  is '��ƷID';
comment on column FACT_100209_LOST_MAC.rolelevel
  is '��ʧʱ�ȼ�';
comment on column FACT_100209_LOST_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100209_LOST_MAC.lost_conn
  is '��Ծ�豸��ʧ';
comment on column FACT_100209_LOST_MAC.lost_pay
  is '�����豸��ʧ';
comment on column FACT_100209_LOST_MAC.data_source
  is '����Դ';
create index IDX58_100209 on FACT_100209_LOST_MAC (CHANNELID);
create index IDX59_100209 on FACT_100209_LOST_MAC (SERVERID);
create index IDX60_100209 on FACT_100209_LOST_MAC (STATDATE);

prompt
prompt Creating table FACT_100209_LOST_USER
prompt ====================================
prompt
create table FACT_100209_LOST_USER
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_LOST_USER
  is '�û���ʧ������';
comment on column FACT_100209_LOST_USER.statdate
  is 'ͳ������';
comment on column FACT_100209_LOST_USER.lostdate
  is '��ʧ����';
comment on column FACT_100209_LOST_USER.channelid
  is '����ID';
comment on column FACT_100209_LOST_USER.serverid
  is '����ID';
comment on column FACT_100209_LOST_USER.appid
  is '��ƷID';
comment on column FACT_100209_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column FACT_100209_LOST_USER.lost_days
  is '��ʧ����';
comment on column FACT_100209_LOST_USER.lost_conn
  is '��Ծ�û���ʧ';
comment on column FACT_100209_LOST_USER.lost_pay
  is '�����û���ʧ';
comment on column FACT_100209_LOST_USER.data_source
  is '����Դ';
create index IDX61_100209 on FACT_100209_LOST_USER (CHANNELID);
create index IDX62_100209 on FACT_100209_LOST_USER (SERVERID);
create index IDX63_100209 on FACT_100209_LOST_USER (STATDATE);

prompt
prompt Creating table FACT_100209_LTV_MAC
prompt ==================================
prompt
create table FACT_100209_LTV_MAC
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_LTV_MAC
  is '�豸LTV������';
comment on column FACT_100209_LTV_MAC.statdate
  is 'ͳ������';
comment on column FACT_100209_LTV_MAC.ltvdate
  is '��ֵ����';
comment on column FACT_100209_LTV_MAC.channelid
  is '����';
comment on column FACT_100209_LTV_MAC.serverid
  is '����';
comment on column FACT_100209_LTV_MAC.appid
  is '��Ʒid';
comment on column FACT_100209_LTV_MAC.ltv_days
  is 'ltv��';
comment on column FACT_100209_LTV_MAC.payamount
  is '���ѽ��';
comment on column FACT_100209_LTV_MAC.data_source
  is '������Դ';
create index IDX64_100209 on FACT_100209_LTV_MAC (CHANNELID);
create index IDX65_100209 on FACT_100209_LTV_MAC (SERVERID);
create index IDX66_100209 on FACT_100209_LTV_MAC (STATDATE);

prompt
prompt Creating table FACT_100209_LTV_USER
prompt ===================================
prompt
create table FACT_100209_LTV_USER
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_LTV_USER
  is '�û�LTV������';
comment on column FACT_100209_LTV_USER.statdate
  is 'ͳ������';
comment on column FACT_100209_LTV_USER.ltvdate
  is '��ֵ����';
comment on column FACT_100209_LTV_USER.channelid
  is '����';
comment on column FACT_100209_LTV_USER.serverid
  is '����';
comment on column FACT_100209_LTV_USER.appid
  is '��Ʒid';
comment on column FACT_100209_LTV_USER.ltv_days
  is 'ltv��';
comment on column FACT_100209_LTV_USER.payamount
  is '���ѽ��';
comment on column FACT_100209_LTV_USER.data_source
  is '������Դ';
create index IDX67_100209 on FACT_100209_LTV_USER (CHANNELID);
create index IDX68_100209 on FACT_100209_LTV_USER (SERVERID);
create index IDX69_100209 on FACT_100209_LTV_USER (STATDATE);

prompt
prompt Creating table FACT_100209_MISS_FIRST
prompt =====================================
prompt
create table FACT_100209_MISS_FIRST
(
  statdate        VARCHAR2(10),
  channelid       VARCHAR2(50),
  serverid        VARCHAR2(50),
  appid           VARCHAR2(50),
  versionid       VARCHAR2(50),
  missionid       VARCHAR2(50),
  rolelevel       NUMBER,
  rolejob         VARCHAR2(50) default '0',
  firstenter_succ NUMBER,
  firstenter_fail NUMBER,
  loaddate        DATE,
  data_source     VARCHAR2(100)
)
;
comment on table FACT_100209_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column FACT_100209_MISS_FIRST.statdate
  is 'ͳ������';
comment on column FACT_100209_MISS_FIRST.channelid
  is '����';
comment on column FACT_100209_MISS_FIRST.serverid
  is '����';
comment on column FACT_100209_MISS_FIRST.appid
  is '��ƷID';
comment on column FACT_100209_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_MISS_FIRST.missionid
  is '�ؿ�ID';
comment on column FACT_100209_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column FACT_100209_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column FACT_100209_MISS_FIRST.firstenter_succ
  is '��һ�ν���ؿ��ɹ���';
comment on column FACT_100209_MISS_FIRST.firstenter_fail
  is '��һ�ν���ؿ�ʧ����';
comment on column FACT_100209_MISS_FIRST.data_source
  is '������Դ';
create index IDX70_100209 on FACT_100209_MISS_FIRST (CHANNELID);
create index IDX71_100209 on FACT_100209_MISS_FIRST (SERVERID);
create index IDX72_100209 on FACT_100209_MISS_FIRST (STATDATE);

prompt
prompt Creating table FACT_100209_NET
prompt ==============================
prompt
create table FACT_100209_NET
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_net    VARCHAR2(50),
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_NET
  is '������ʽ������';
comment on column FACT_100209_NET.statdate
  is 'ͳ������';
comment on column FACT_100209_NET.channelid
  is '����';
comment on column FACT_100209_NET.serverid
  is '����';
comment on column FACT_100209_NET.appid
  is '��Ʒid';
comment on column FACT_100209_NET.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_NET.dvid_net
  is '������ʽ';
comment on column FACT_100209_NET.conncount
  is '������';
comment on column FACT_100209_NET.data_source
  is '������Դ';
create index IDX73_100209 on FACT_100209_NET (CHANNELID);
create index IDX74_100209 on FACT_100209_NET (SERVERID);
create index IDX75_100209 on FACT_100209_NET (STATDATE);

prompt
prompt Creating table FACT_100209_OPERATOR
prompt ===================================
prompt
create table FACT_100209_OPERATOR
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  dvid_operator VARCHAR2(50),
  conncount     NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100209_OPERATOR
  is '��Ӫ�̷�����';
comment on column FACT_100209_OPERATOR.statdate
  is 'ͳ������';
comment on column FACT_100209_OPERATOR.channelid
  is '����';
comment on column FACT_100209_OPERATOR.serverid
  is '����';
comment on column FACT_100209_OPERATOR.appid
  is '��Ʒid';
comment on column FACT_100209_OPERATOR.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_OPERATOR.dvid_operator
  is '������ʽ';
comment on column FACT_100209_OPERATOR.conncount
  is '������';
comment on column FACT_100209_OPERATOR.data_source
  is '������Դ';
create index IDX76_100209 on FACT_100209_OPERATOR (CHANNELID);
create index IDX77_100209 on FACT_100209_OPERATOR (SERVERID);
create index IDX78_100209 on FACT_100209_OPERATOR (STATDATE);

prompt
prompt Creating table FACT_100209_ORDER
prompt ================================
prompt
create table FACT_100209_ORDER
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100209_ORDER
  is '����������';
comment on column FACT_100209_ORDER.statdate
  is 'ͳ������';
comment on column FACT_100209_ORDER.channelid
  is '����';
comment on column FACT_100209_ORDER.serverid
  is '����';
comment on column FACT_100209_ORDER.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100209_ORDER.appid
  is '��Ʒid';
comment on column FACT_100209_ORDER.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_ORDER.paysucccount
  is '�ɹ�������';
comment on column FACT_100209_ORDER.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100209_ORDER.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100209_ORDER.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100209_ORDER.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100209_ORDER.payfailnum
  is '����ʧ������';
comment on column FACT_100209_ORDER.data_source
  is '������Դ';
create index IDX79_100209 on FACT_100209_ORDER (CHANNELID);
create index IDX80_100209 on FACT_100209_ORDER (SERVERID);
create index IDX81_100209 on FACT_100209_ORDER (STATDATE);

prompt
prompt Creating table FACT_100209_ORDER_HOUR
prompt =====================================
prompt
create table FACT_100209_ORDER_HOUR
(
  statdate      VARCHAR2(20),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100209_ORDER_HOUR
  is '����Сʱ������';
comment on column FACT_100209_ORDER_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100209_ORDER_HOUR.channelid
  is '����';
comment on column FACT_100209_ORDER_HOUR.serverid
  is '����';
comment on column FACT_100209_ORDER_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100209_ORDER_HOUR.appid
  is '��Ʒid';
comment on column FACT_100209_ORDER_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_ORDER_HOUR.paysucccount
  is '�ɹ�������';
comment on column FACT_100209_ORDER_HOUR.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100209_ORDER_HOUR.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100209_ORDER_HOUR.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100209_ORDER_HOUR.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100209_ORDER_HOUR.payfailnum
  is '����ʧ������';
comment on column FACT_100209_ORDER_HOUR.data_source
  is '������Դ';
create index IDX177_100209 on FACT_100209_ORDER_HOUR (CHANNELID);
create index IDX178_100209 on FACT_100209_ORDER_HOUR (SERVERID);
create index IDX179_100209 on FACT_100209_ORDER_HOUR (STATDATE);

prompt
prompt Creating table FACT_100209_ORDER_MONTH
prompt ======================================
prompt
create table FACT_100209_ORDER_MONTH
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100209_ORDER_MONTH
  is '�¶���������';
comment on column FACT_100209_ORDER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100209_ORDER_MONTH.channelid
  is '����';
comment on column FACT_100209_ORDER_MONTH.serverid
  is '����';
comment on column FACT_100209_ORDER_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100209_ORDER_MONTH.appid
  is '��Ʒid';
comment on column FACT_100209_ORDER_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_ORDER_MONTH.paysucccount
  is '�ɹ�������';
comment on column FACT_100209_ORDER_MONTH.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100209_ORDER_MONTH.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100209_ORDER_MONTH.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100209_ORDER_MONTH.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100209_ORDER_MONTH.payfailnum
  is '����ʧ������';
comment on column FACT_100209_ORDER_MONTH.data_source
  is '������Դ';
create index IDX191_100209 on FACT_100209_ORDER_MONTH (CHANNELID);
create index IDX192_100209 on FACT_100209_ORDER_MONTH (SERVERID);
create index IDX193_100209 on FACT_100209_ORDER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100209_ORDER_WEEK
prompt =====================================
prompt
create table FACT_100209_ORDER_WEEK
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100209_ORDER_WEEK
  is '�ܶ���������';
comment on column FACT_100209_ORDER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100209_ORDER_WEEK.channelid
  is '����';
comment on column FACT_100209_ORDER_WEEK.serverid
  is '����';
comment on column FACT_100209_ORDER_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100209_ORDER_WEEK.appid
  is '��Ʒid';
comment on column FACT_100209_ORDER_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_ORDER_WEEK.paysucccount
  is '�ɹ�������';
comment on column FACT_100209_ORDER_WEEK.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100209_ORDER_WEEK.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100209_ORDER_WEEK.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100209_ORDER_WEEK.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100209_ORDER_WEEK.payfailnum
  is '����ʧ������';
comment on column FACT_100209_ORDER_WEEK.data_source
  is '������Դ';
create index IDX188_100209 on FACT_100209_ORDER_WEEK (CHANNELID);
create index IDX189_100209 on FACT_100209_ORDER_WEEK (SERVERID);
create index IDX190_100209 on FACT_100209_ORDER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100209_PAYAMOUNT_DAY
prompt ========================================
prompt
create table FACT_100209_PAYAMOUNT_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_PAYAMOUNT_DAY
  is '�ճ�ֵ��������';
comment on column FACT_100209_PAYAMOUNT_DAY.statdate
  is 'ͳ������';
comment on column FACT_100209_PAYAMOUNT_DAY.channelid
  is '����';
comment on column FACT_100209_PAYAMOUNT_DAY.serverid
  is '����';
comment on column FACT_100209_PAYAMOUNT_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100209_PAYAMOUNT_DAY.appid
  is '��Ʒid';
comment on column FACT_100209_PAYAMOUNT_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_PAYAMOUNT_DAY.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100209_PAYAMOUNT_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100209_PAYAMOUNT_DAY.data_source
  is '������Դ';
create index IDX82_100209 on FACT_100209_PAYAMOUNT_DAY (CHANNELID);
create index IDX83_100209 on FACT_100209_PAYAMOUNT_DAY (SERVERID);
create index IDX84_100209 on FACT_100209_PAYAMOUNT_DAY (STATDATE);

prompt
prompt Creating table FACT_100209_PAYAMOUNT_MONTH
prompt ==========================================
prompt
create table FACT_100209_PAYAMOUNT_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_PAYAMOUNT_MONTH
  is '�³�ֵ��������';
comment on column FACT_100209_PAYAMOUNT_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100209_PAYAMOUNT_MONTH.channelid
  is '����';
comment on column FACT_100209_PAYAMOUNT_MONTH.serverid
  is '����';
comment on column FACT_100209_PAYAMOUNT_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100209_PAYAMOUNT_MONTH.appid
  is '��Ʒid';
comment on column FACT_100209_PAYAMOUNT_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_PAYAMOUNT_MONTH.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100209_PAYAMOUNT_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100209_PAYAMOUNT_MONTH.data_source
  is '������Դ';
create index IDX88_100209 on FACT_100209_PAYAMOUNT_MONTH (CHANNELID);
create index IDX89_100209 on FACT_100209_PAYAMOUNT_MONTH (SERVERID);
create index IDX90_100209 on FACT_100209_PAYAMOUNT_MONTH (STATDATE);

prompt
prompt Creating table FACT_100209_PAYAMOUNT_WEEK
prompt =========================================
prompt
create table FACT_100209_PAYAMOUNT_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_PAYAMOUNT_WEEK
  is '�ܳ�ֵ��������';
comment on column FACT_100209_PAYAMOUNT_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100209_PAYAMOUNT_WEEK.channelid
  is '����';
comment on column FACT_100209_PAYAMOUNT_WEEK.serverid
  is '����';
comment on column FACT_100209_PAYAMOUNT_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100209_PAYAMOUNT_WEEK.appid
  is '��Ʒid';
comment on column FACT_100209_PAYAMOUNT_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_PAYAMOUNT_WEEK.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100209_PAYAMOUNT_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100209_PAYAMOUNT_WEEK.data_source
  is '������Դ';
create index IDX85_100209 on FACT_100209_PAYAMOUNT_WEEK (CHANNELID);
create index IDX86_100209 on FACT_100209_PAYAMOUNT_WEEK (SERVERID);
create index IDX87_100209 on FACT_100209_PAYAMOUNT_WEEK (STATDATE);

prompt
prompt Creating table FACT_100209_PAYNUM_DAY
prompt =====================================
prompt
create table FACT_100209_PAYNUM_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_PAYNUM_DAY
  is '�ճ�ֵ����������';
comment on column FACT_100209_PAYNUM_DAY.statdate
  is 'ͳ������';
comment on column FACT_100209_PAYNUM_DAY.channelid
  is '����';
comment on column FACT_100209_PAYNUM_DAY.serverid
  is '����';
comment on column FACT_100209_PAYNUM_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100209_PAYNUM_DAY.appid
  is '��Ʒid';
comment on column FACT_100209_PAYNUM_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_PAYNUM_DAY.paynum
  is '��ֵ����';
comment on column FACT_100209_PAYNUM_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100209_PAYNUM_DAY.data_source
  is '������Դ';
create index IDX97_100209 on FACT_100209_PAYNUM_DAY (CHANNELID);
create index IDX98_100209 on FACT_100209_PAYNUM_DAY (SERVERID);
create index IDX99_100209 on FACT_100209_PAYNUM_DAY (STATDATE);

prompt
prompt Creating table FACT_100209_PAYNUM_MONTH
prompt =======================================
prompt
create table FACT_100209_PAYNUM_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_PAYNUM_MONTH
  is '�³�ֵ����������';
comment on column FACT_100209_PAYNUM_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100209_PAYNUM_MONTH.channelid
  is '����';
comment on column FACT_100209_PAYNUM_MONTH.serverid
  is '����';
comment on column FACT_100209_PAYNUM_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100209_PAYNUM_MONTH.appid
  is '��Ʒid';
comment on column FACT_100209_PAYNUM_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_PAYNUM_MONTH.paynum
  is '��ֵ����';
comment on column FACT_100209_PAYNUM_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100209_PAYNUM_MONTH.data_source
  is '������Դ';
create index IDX91_100209 on FACT_100209_PAYNUM_MONTH (CHANNELID);
create index IDX92_100209 on FACT_100209_PAYNUM_MONTH (SERVERID);
create index IDX93_100209 on FACT_100209_PAYNUM_MONTH (STATDATE);

prompt
prompt Creating table FACT_100209_PAYNUM_WEEK
prompt ======================================
prompt
create table FACT_100209_PAYNUM_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_PAYNUM_WEEK
  is '�ܳ�ֵ����������';
comment on column FACT_100209_PAYNUM_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100209_PAYNUM_WEEK.channelid
  is '����';
comment on column FACT_100209_PAYNUM_WEEK.serverid
  is '����';
comment on column FACT_100209_PAYNUM_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100209_PAYNUM_WEEK.appid
  is '��Ʒid';
comment on column FACT_100209_PAYNUM_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_PAYNUM_WEEK.paynum
  is '��ֵ����';
comment on column FACT_100209_PAYNUM_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100209_PAYNUM_WEEK.data_source
  is '������Դ';
create index IDX94_100209 on FACT_100209_PAYNUM_WEEK (CHANNELID);
create index IDX95_100209 on FACT_100209_PAYNUM_WEEK (SERVERID);
create index IDX96_100209 on FACT_100209_PAYNUM_WEEK (STATDATE);

prompt
prompt Creating table FACT_100209_PAYTYPE
prompt ==================================
prompt
create table FACT_100209_PAYTYPE
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paytypeid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_PAYTYPE
  is '��ֵ���ͷ�����';
comment on column FACT_100209_PAYTYPE.statdate
  is 'ͳ������';
comment on column FACT_100209_PAYTYPE.channelid
  is '����';
comment on column FACT_100209_PAYTYPE.serverid
  is '����';
comment on column FACT_100209_PAYTYPE.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100209_PAYTYPE.appid
  is '��Ʒid';
comment on column FACT_100209_PAYTYPE.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_PAYTYPE.paytypeid
  is '��ֵ����';
comment on column FACT_100209_PAYTYPE.payamount
  is '��ֵ���';
comment on column FACT_100209_PAYTYPE.paycount
  is '��ֵ����';
comment on column FACT_100209_PAYTYPE.paynum
  is '��ֵ����';
comment on column FACT_100209_PAYTYPE.data_source
  is '������Դ';
create index IDX100_100209 on FACT_100209_PAYTYPE (CHANNELID);
create index IDX101_100209 on FACT_100209_PAYTYPE (SERVERID);
create index IDX102_100209 on FACT_100209_PAYTYPE (STATDATE);

prompt
prompt Creating table FACT_100209_PAYWAY
prompt =================================
prompt
create table FACT_100209_PAYWAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paywayid    VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_PAYWAY
  is '��ֵ��ʽ������';
comment on column FACT_100209_PAYWAY.statdate
  is 'ͳ������';
comment on column FACT_100209_PAYWAY.channelid
  is '����';
comment on column FACT_100209_PAYWAY.serverid
  is '����';
comment on column FACT_100209_PAYWAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100209_PAYWAY.appid
  is '��Ʒid';
comment on column FACT_100209_PAYWAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_PAYWAY.paywayid
  is '��ֵ��ʽ';
comment on column FACT_100209_PAYWAY.payamount
  is '��ֵ���';
comment on column FACT_100209_PAYWAY.paycount
  is '��ֵ����';
comment on column FACT_100209_PAYWAY.paynum
  is '��ֵ����';
comment on column FACT_100209_PAYWAY.data_source
  is '������Դ';
create index IDX103_100209 on FACT_100209_PAYWAY (CHANNELID);
create index IDX104_100209 on FACT_100209_PAYWAY (SERVERID);
create index IDX105_100209 on FACT_100209_PAYWAY (STATDATE);

prompt
prompt Creating table FACT_100209_REGION
prompt =================================
prompt
create table FACT_100209_REGION
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  country     VARCHAR2(50),
  province    VARCHAR2(50),
  city        VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_REGION
  is '���������';
comment on column FACT_100209_REGION.statdate
  is 'ͳ������';
comment on column FACT_100209_REGION.channelid
  is '����';
comment on column FACT_100209_REGION.serverid
  is '����';
comment on column FACT_100209_REGION.appid
  is '��Ʒid';
comment on column FACT_100209_REGION.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_REGION.country
  is '����';
comment on column FACT_100209_REGION.province
  is 'ʡ';
comment on column FACT_100209_REGION.city
  is '��';
comment on column FACT_100209_REGION.newcount
  is '������';
comment on column FACT_100209_REGION.conncount
  is '������';
comment on column FACT_100209_REGION.paycount
  is '������';
comment on column FACT_100209_REGION.payamount
  is '���ѽ��';
comment on column FACT_100209_REGION.data_source
  is '������Դ';
create index IDX106_100209 on FACT_100209_REGION (CHANNELID);
create index IDX107_100209 on FACT_100209_REGION (SERVERID);
create index IDX108_100209 on FACT_100209_REGION (STATDATE);

prompt
prompt Creating table FACT_100209_REMAIN_MAC
prompt =====================================
prompt
create table FACT_100209_REMAIN_MAC
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_REMAIN_MAC
  is '�豸�����';
comment on column FACT_100209_REMAIN_MAC.statdate
  is 'ͳ������';
comment on column FACT_100209_REMAIN_MAC.conndate
  is '��������';
comment on column FACT_100209_REMAIN_MAC.channelid
  is '����ID';
comment on column FACT_100209_REMAIN_MAC.serverid
  is '����ID';
comment on column FACT_100209_REMAIN_MAC.appid
  is '��ƷID';
comment on column FACT_100209_REMAIN_MAC.remain_days
  is '��������';
comment on column FACT_100209_REMAIN_MAC.new_remain
  is '��������';
comment on column FACT_100209_REMAIN_MAC.conn_remain
  is '��������';
comment on column FACT_100209_REMAIN_MAC.pay_remain
  is '��������';
comment on column FACT_100209_REMAIN_MAC.data_source
  is '����Դ';
create index IDX109_100209 on FACT_100209_REMAIN_MAC (CHANNELID);
create index IDX110_100209 on FACT_100209_REMAIN_MAC (SERVERID);
create index IDX111_100209 on FACT_100209_REMAIN_MAC (STATDATE);

prompt
prompt Creating table FACT_100209_REMAIN_USER
prompt ======================================
prompt
create table FACT_100209_REMAIN_USER
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_REMAIN_USER
  is '�û������';
comment on column FACT_100209_REMAIN_USER.statdate
  is 'ͳ������';
comment on column FACT_100209_REMAIN_USER.conndate
  is '��������';
comment on column FACT_100209_REMAIN_USER.channelid
  is '����ID';
comment on column FACT_100209_REMAIN_USER.serverid
  is '����ID';
comment on column FACT_100209_REMAIN_USER.appid
  is '��ƷID';
comment on column FACT_100209_REMAIN_USER.remain_days
  is '��������';
comment on column FACT_100209_REMAIN_USER.new_remain
  is '��������';
comment on column FACT_100209_REMAIN_USER.conn_remain
  is '��������';
comment on column FACT_100209_REMAIN_USER.pay_remain
  is '��������';
comment on column FACT_100209_REMAIN_USER.data_source
  is '����Դ';
create index IDX112_100209 on FACT_100209_REMAIN_USER (CHANNELID);
create index IDX113_100209 on FACT_100209_REMAIN_USER (SERVERID);
create index IDX114_100209 on FACT_100209_REMAIN_USER (STATDATE);

prompt
prompt Creating table FACT_100209_VC
prompt =============================
prompt
create table FACT_100209_VC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcamount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100209_VC
  is '������ҷ�����';
comment on column FACT_100209_VC.statdate
  is 'ͳ������';
comment on column FACT_100209_VC.channelid
  is '����';
comment on column FACT_100209_VC.serverid
  is '����';
comment on column FACT_100209_VC.appid
  is '��Ʒid';
comment on column FACT_100209_VC.versionid
  is '��Ʒ�汾';
comment on column FACT_100209_VC.vctype
  is '�����������';
comment on column FACT_100209_VC.vcusetype
  is '�������ʹ������';
comment on column FACT_100209_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column FACT_100209_VC.vcamount
  is '������ҽ��';
comment on column FACT_100209_VC.data_source
  is '������Դ';
create index IDX115_100209 on FACT_100209_VC (CHANNELID);
create index IDX116_100209 on FACT_100209_VC (SERVERID);
create index IDX117_100209 on FACT_100209_VC (STATDATE);

prompt
prompt Creating table FACT_100228_BACK_MAC
prompt ===================================
prompt
create table FACT_100228_BACK_MAC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_BACK_MAC
  is '�豸����������';
comment on column FACT_100228_BACK_MAC.statdate
  is 'ͳ������';
comment on column FACT_100228_BACK_MAC.channelid
  is '����ID';
comment on column FACT_100228_BACK_MAC.serverid
  is '����ID';
comment on column FACT_100228_BACK_MAC.appid
  is '��ƷID';
comment on column FACT_100228_BACK_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100228_BACK_MAC.back_conn
  is '��Ծ�豸������';
comment on column FACT_100228_BACK_MAC.back_pay
  is '�����豸������';
comment on column FACT_100228_BACK_MAC.data_source
  is '����Դ';
create index IDX1_100228 on FACT_100228_BACK_MAC (CHANNELID);
create index IDX2_100228 on FACT_100228_BACK_MAC (SERVERID);
create index IDX3_100228 on FACT_100228_BACK_MAC (STATDATE);

prompt
prompt Creating table FACT_100228_BACK_MAC_MONTH
prompt =========================================
prompt
create table FACT_100228_BACK_MAC_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_BACK_MAC_MONTH
  is '�豸����������';
comment on column FACT_100228_BACK_MAC_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100228_BACK_MAC_MONTH.channelid
  is '����ID';
comment on column FACT_100228_BACK_MAC_MONTH.serverid
  is '����ID';
comment on column FACT_100228_BACK_MAC_MONTH.appid
  is '��ƷID';
comment on column FACT_100228_BACK_MAC_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100228_BACK_MAC_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100228_BACK_MAC_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100228_BACK_MAC_MONTH.data_source
  is '����Դ';
create index IDX4_100228 on FACT_100228_BACK_MAC_MONTH (CHANNELID);
create index IDX5_100228 on FACT_100228_BACK_MAC_MONTH (SERVERID);
create index IDX6_100228 on FACT_100228_BACK_MAC_MONTH (STATDATE);

prompt
prompt Creating table FACT_100228_BACK_MAC_WEEK
prompt ========================================
prompt
create table FACT_100228_BACK_MAC_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_BACK_MAC_WEEK
  is '�豸����������';
comment on column FACT_100228_BACK_MAC_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100228_BACK_MAC_WEEK.channelid
  is '����ID';
comment on column FACT_100228_BACK_MAC_WEEK.serverid
  is '����ID';
comment on column FACT_100228_BACK_MAC_WEEK.appid
  is '��ƷID';
comment on column FACT_100228_BACK_MAC_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100228_BACK_MAC_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100228_BACK_MAC_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100228_BACK_MAC_WEEK.data_source
  is '����Դ';
create index IDX7_100228 on FACT_100228_BACK_MAC_WEEK (CHANNELID);
create index IDX8_100228 on FACT_100228_BACK_MAC_WEEK (SERVERID);
create index IDX9_100228 on FACT_100228_BACK_MAC_WEEK (STATDATE);

prompt
prompt Creating table FACT_100228_BACK_USER
prompt ====================================
prompt
create table FACT_100228_BACK_USER
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_BACK_USER
  is '�û�����������';
comment on column FACT_100228_BACK_USER.statdate
  is 'ͳ������';
comment on column FACT_100228_BACK_USER.channelid
  is '����ID';
comment on column FACT_100228_BACK_USER.serverid
  is '����ID';
comment on column FACT_100228_BACK_USER.appid
  is '��ƷID';
comment on column FACT_100228_BACK_USER.lost_days
  is '��ʧ����';
comment on column FACT_100228_BACK_USER.back_conn
  is '��Ծ�û�������';
comment on column FACT_100228_BACK_USER.back_pay
  is '�����û�������';
comment on column FACT_100228_BACK_USER.data_source
  is '����Դ';
create index IDX16_100228 on FACT_100228_BACK_USER (CHANNELID);
create index IDX17_100228 on FACT_100228_BACK_USER (SERVERID);
create index IDX18_100228 on FACT_100228_BACK_USER (STATDATE);

prompt
prompt Creating table FACT_100228_BACK_USER_MONTH
prompt ==========================================
prompt
create table FACT_100228_BACK_USER_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_BACK_USER_MONTH
  is '�豸����������';
comment on column FACT_100228_BACK_USER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100228_BACK_USER_MONTH.channelid
  is '����ID';
comment on column FACT_100228_BACK_USER_MONTH.serverid
  is '����ID';
comment on column FACT_100228_BACK_USER_MONTH.appid
  is '��ƷID';
comment on column FACT_100228_BACK_USER_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100228_BACK_USER_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100228_BACK_USER_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100228_BACK_USER_MONTH.data_source
  is '����Դ';
create index IDX13_100228 on FACT_100228_BACK_USER_MONTH (CHANNELID);
create index IDX14_100228 on FACT_100228_BACK_USER_MONTH (SERVERID);
create index IDX15_100228 on FACT_100228_BACK_USER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100228_BACK_USER_WEEK
prompt =========================================
prompt
create table FACT_100228_BACK_USER_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_BACK_USER_WEEK
  is '�豸����������';
comment on column FACT_100228_BACK_USER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100228_BACK_USER_WEEK.channelid
  is '����ID';
comment on column FACT_100228_BACK_USER_WEEK.serverid
  is '����ID';
comment on column FACT_100228_BACK_USER_WEEK.appid
  is '��ƷID';
comment on column FACT_100228_BACK_USER_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100228_BACK_USER_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100228_BACK_USER_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100228_BACK_USER_WEEK.data_source
  is '����Դ';
create index IDX10_100228 on FACT_100228_BACK_USER_WEEK (CHANNELID);
create index IDX11_100228 on FACT_100228_BACK_USER_WEEK (SERVERID);
create index IDX12_100228 on FACT_100228_BACK_USER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100228_CEVENT
prompt =================================
prompt
create table FACT_100228_CEVENT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  eventkey    VARCHAR2(50),
  eventcount  NUMBER,
  eventnum    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_CEVENT
  is '�Զ��������';
comment on column FACT_100228_CEVENT.statdate
  is 'ͳ������';
comment on column FACT_100228_CEVENT.channelid
  is '����';
comment on column FACT_100228_CEVENT.serverid
  is '����';
comment on column FACT_100228_CEVENT.appid
  is '��Ʒid';
comment on column FACT_100228_CEVENT.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100228_CEVENT.eventcount
  is '�¼��û���';
comment on column FACT_100228_CEVENT.eventnum
  is '�¼�����';
comment on column FACT_100228_CEVENT.data_source
  is '������Դ';
create index IDX181_100228 on FACT_100228_CEVENT (CHANNELID);
create index IDX182_100228 on FACT_100228_CEVENT (SERVERID);
create index IDX183_100228 on FACT_100228_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100228_CEVENT_PAR
prompt =====================================
prompt
create table FACT_100228_CEVENT_PAR
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  ilevel         NUMBER,
  eventkey       VARCHAR2(100),
  eventpar_key   VARCHAR2(100),
  eventpar_value VARCHAR2(100),
  eventcount     NUMBER,
  eventnum       NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100228_CEVENT_PAR
  is '�Զ������������';
comment on column FACT_100228_CEVENT_PAR.statdate
  is 'ͳ������';
comment on column FACT_100228_CEVENT_PAR.channelid
  is '����';
comment on column FACT_100228_CEVENT_PAR.serverid
  is '����';
comment on column FACT_100228_CEVENT_PAR.appid
  is '��Ʒid';
comment on column FACT_100228_CEVENT_PAR.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_CEVENT_PAR.ilevel
  is '��ɫ�ȼ�';
comment on column FACT_100228_CEVENT_PAR.eventkey
  is '�¼�����';
comment on column FACT_100228_CEVENT_PAR.eventpar_key
  is '�¼�����';
comment on column FACT_100228_CEVENT_PAR.eventpar_value
  is '�¼�����ֵ';
comment on column FACT_100228_CEVENT_PAR.eventcount
  is '�¼��û���';
comment on column FACT_100228_CEVENT_PAR.eventnum
  is '�¼�����';
comment on column FACT_100228_CEVENT_PAR.data_source
  is '������Դ';
create index IDX185_100228 on FACT_100228_CEVENT_PAR (CHANNELID);
create index IDX186_100228 on FACT_100228_CEVENT_PAR (SERVERID);
create index IDX187_100228 on FACT_100228_CEVENT_PAR (STATDATE);

prompt
prompt Creating table FACT_100228_COMP_CEVENT
prompt ======================================
prompt
create table FACT_100228_COMP_CEVENT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(10),
  channelid   VARCHAR2(50),
  gameversion VARCHAR2(50),
  serverid    VARCHAR2(50),
  ilevel      NUMBER,
  eventkey    VARCHAR2(100),
  compid      VARCHAR2(50),
  caltype     VARCHAR2(50),
  dimpars     VARCHAR2(2000),
  comp_data   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_COMP_CEVENT
  is '�Զ����¼���Ϸ�����';
comment on column FACT_100228_COMP_CEVENT.statdate
  is '����';
comment on column FACT_100228_COMP_CEVENT.appid
  is '��Ϸ�� appid';
comment on column FACT_100228_COMP_CEVENT.channelid
  is '���� ID';
comment on column FACT_100228_COMP_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column FACT_100228_COMP_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column FACT_100228_COMP_CEVENT.ilevel
  is '��ҵȼ�';
comment on column FACT_100228_COMP_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100228_COMP_CEVENT.compid
  is '��ϼ����¼�ID';
comment on column FACT_100228_COMP_CEVENT.caltype
  is '��ϼ����¼���������';
comment on column FACT_100228_COMP_CEVENT.dimpars
  is '��ϲ���';
comment on column FACT_100228_COMP_CEVENT.comp_data
  is '��ϼ�����';
create index IDX184_100228 on FACT_100228_COMP_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100228_DAILY_REPORT
prompt =======================================
prompt
create table FACT_100228_DAILY_REPORT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_DAILY_REPORT
  is '�ձ�����';
comment on column FACT_100228_DAILY_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100228_DAILY_REPORT.appid
  is '��ƷID';
comment on column FACT_100228_DAILY_REPORT.channelid
  is '����';
comment on column FACT_100228_DAILY_REPORT.serverid
  is '����';
comment on column FACT_100228_DAILY_REPORT.indexid
  is 'ָ��';
comment on column FACT_100228_DAILY_REPORT.indtype
  is 'ָ������';
comment on column FACT_100228_DAILY_REPORT.rpt_data
  is '����';
create index IDX176_100228 on FACT_100228_DAILY_REPORT (STATDATE);

prompt
prompt Creating table FACT_100228_DVID
prompt ===============================
prompt
create table FACT_100228_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_model  VARCHAR2(200),
  dvid_res    VARCHAR2(50),
  dvid_os     VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_DVID
  is '�豸������';
comment on column FACT_100228_DVID.statdate
  is 'ͳ������';
comment on column FACT_100228_DVID.channelid
  is '����';
comment on column FACT_100228_DVID.serverid
  is '����';
comment on column FACT_100228_DVID.appid
  is '��Ʒid';
comment on column FACT_100228_DVID.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_DVID.dvid_model
  is '����';
comment on column FACT_100228_DVID.dvid_res
  is '�豸�ֱ���';
comment on column FACT_100228_DVID.dvid_os
  is '�豸����ϵͳ';
comment on column FACT_100228_DVID.newcount
  is '�����û���';
comment on column FACT_100228_DVID.conncount
  is '�����û���';
comment on column FACT_100228_DVID.data_source
  is '������Դ';
create index IDX19_100228 on FACT_100228_DVID (CHANNELID);
create index IDX20_100228 on FACT_100228_DVID (SERVERID);
create index IDX21_100228 on FACT_100228_DVID (STATDATE);

prompt
prompt Creating table FACT_100228_FIRSTPAY
prompt ===================================
prompt
create table FACT_100228_FIRSTPAY
(
  statdate         VARCHAR2(10),
  firstpaydate     VARCHAR2(10),
  channelid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  datatype         VARCHAR2(50),
  appid            VARCHAR2(50),
  first_payfromreg NUMBER,
  first_paycount   NUMBER,
  payamount        NUMBER,
  loaddate         DATE default SYSDATE,
  data_source      VARCHAR2(100)
)
;
comment on table FACT_100228_FIRSTPAY
  is '�����û��״γ�ֵ������';
comment on column FACT_100228_FIRSTPAY.statdate
  is 'ͳ������';
comment on column FACT_100228_FIRSTPAY.firstpaydate
  is '�״θ�������';
comment on column FACT_100228_FIRSTPAY.channelid
  is '����';
comment on column FACT_100228_FIRSTPAY.serverid
  is '����';
comment on column FACT_100228_FIRSTPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100228_FIRSTPAY.appid
  is '��Ʒid';
comment on column FACT_100228_FIRSTPAY.first_payfromreg
  is 'ע���ڼ��쿪ʼ��ֵ(1��2��..7..30..)';
comment on column FACT_100228_FIRSTPAY.first_paycount
  is '���������û���';
comment on column FACT_100228_FIRSTPAY.payamount
  is '�ۼƵ��ڼ���ĳ�ֵ�ܶ�';
comment on column FACT_100228_FIRSTPAY.data_source
  is '������Դ';
create index IDX22_100228 on FACT_100228_FIRSTPAY (CHANNELID);
create index IDX23_100228 on FACT_100228_FIRSTPAY (SERVERID);
create index IDX24_100228 on FACT_100228_FIRSTPAY (STATDATE);

prompt
prompt Creating table FACT_100228_FIRSTPAY_AMOUNT
prompt ==========================================
prompt
create table FACT_100228_FIRSTPAY_AMOUNT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_FIRSTPAY_AMOUNT
  is '�״θ��ѽ�������';
comment on column FACT_100228_FIRSTPAY_AMOUNT.statdate
  is 'ͳ������';
comment on column FACT_100228_FIRSTPAY_AMOUNT.channelid
  is '����';
comment on column FACT_100228_FIRSTPAY_AMOUNT.serverid
  is '��������';
comment on column FACT_100228_FIRSTPAY_AMOUNT.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100228_FIRSTPAY_AMOUNT.appid
  is '��Ʒid';
comment on column FACT_100228_FIRSTPAY_AMOUNT.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_FIRSTPAY_AMOUNT.payamount
  is '�״θ��ѽ��';
comment on column FACT_100228_FIRSTPAY_AMOUNT.paycount
  is '�״θ��ѽ���Ӧ������';
create index IDX25_100228 on FACT_100228_FIRSTPAY_AMOUNT (CHANNELID);
create index IDX26_100228 on FACT_100228_FIRSTPAY_AMOUNT (SERVERID);
create index IDX27_100228 on FACT_100228_FIRSTPAY_AMOUNT (STATDATE);

prompt
prompt Creating table FACT_100228_GENERAL_DAY
prompt ======================================
prompt
create table FACT_100228_GENERAL_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_GENERAL_DAY
  is '�ջ���������';
comment on column FACT_100228_GENERAL_DAY.statdate
  is 'ͳ������';
comment on column FACT_100228_GENERAL_DAY.channelid
  is '����';
comment on column FACT_100228_GENERAL_DAY.serverid
  is '����';
comment on column FACT_100228_GENERAL_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100228_GENERAL_DAY.appid
  is '��Ʒid';
comment on column FACT_100228_GENERAL_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_GENERAL_DAY.newcount
  is '������';
comment on column FACT_100228_GENERAL_DAY.conncount
  is '������';
comment on column FACT_100228_GENERAL_DAY.paycount
  is '������';
comment on column FACT_100228_GENERAL_DAY.payamount
  is '���ѽ��';
comment on column FACT_100228_GENERAL_DAY.data_source
  is '������Դ';
create index IDX28_100228 on FACT_100228_GENERAL_DAY (CHANNELID);
create index IDX29_100228 on FACT_100228_GENERAL_DAY (SERVERID);
create index IDX30_100228 on FACT_100228_GENERAL_DAY (STATDATE);

prompt
prompt Creating table FACT_100228_GENERAL_DAY_DVID
prompt ===========================================
prompt
create table FACT_100228_GENERAL_DAY_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_GENERAL_DAY_DVID
  is '���豸����������';
comment on column FACT_100228_GENERAL_DAY_DVID.statdate
  is 'ͳ������';
comment on column FACT_100228_GENERAL_DAY_DVID.channelid
  is '����';
comment on column FACT_100228_GENERAL_DAY_DVID.appid
  is '��Ʒid';
comment on column FACT_100228_GENERAL_DAY_DVID.newcount
  is '������';
comment on column FACT_100228_GENERAL_DAY_DVID.conncount
  is '������';
comment on column FACT_100228_GENERAL_DAY_DVID.data_source
  is '������Դ';
create index IDX31_100228 on FACT_100228_GENERAL_DAY_DVID (CHANNELID);
create index IDX33_100228 on FACT_100228_GENERAL_DAY_DVID (STATDATE);

prompt
prompt Creating table FACT_100228_GENERAL_HOUR
prompt =======================================
prompt
create table FACT_100228_GENERAL_HOUR
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_GENERAL_HOUR
  is 'Сʱ����������';
comment on column FACT_100228_GENERAL_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100228_GENERAL_HOUR.channelid
  is '����';
comment on column FACT_100228_GENERAL_HOUR.serverid
  is '����';
comment on column FACT_100228_GENERAL_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100228_GENERAL_HOUR.appid
  is '��Ʒid';
comment on column FACT_100228_GENERAL_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_GENERAL_HOUR.newcount
  is '������';
comment on column FACT_100228_GENERAL_HOUR.conncount
  is '������';
comment on column FACT_100228_GENERAL_HOUR.paycount
  is '������';
comment on column FACT_100228_GENERAL_HOUR.payamount
  is '���ѽ��';
comment on column FACT_100228_GENERAL_HOUR.data_source
  is '������Դ';
create index IDX34_100228 on FACT_100228_GENERAL_HOUR (CHANNELID);
create index IDX35_100228 on FACT_100228_GENERAL_HOUR (SERVERID);
create index IDX36_100228 on FACT_100228_GENERAL_HOUR (STATDATE);

prompt
prompt Creating table FACT_100228_GENERAL_HOUR_DVID
prompt ============================================
prompt
create table FACT_100228_GENERAL_HOUR_DVID
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_GENERAL_HOUR_DVID
  is 'Сʱ�豸����������';
comment on column FACT_100228_GENERAL_HOUR_DVID.statdate
  is 'ͳ������';
comment on column FACT_100228_GENERAL_HOUR_DVID.channelid
  is '����';
comment on column FACT_100228_GENERAL_HOUR_DVID.appid
  is '��Ʒid';
comment on column FACT_100228_GENERAL_HOUR_DVID.newcount
  is '������';
comment on column FACT_100228_GENERAL_HOUR_DVID.conncount
  is '������';
comment on column FACT_100228_GENERAL_HOUR_DVID.data_source
  is '������Դ';
create index IDX37_100228 on FACT_100228_GENERAL_HOUR_DVID (CHANNELID);
create index IDX39_100228 on FACT_100228_GENERAL_HOUR_DVID (STATDATE);

prompt
prompt Creating table FACT_100228_GENERAL_LEVEL
prompt ========================================
prompt
create table FACT_100228_GENERAL_LEVEL
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  rolelevel   NUMBER,
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_GENERAL_LEVEL
  is '�û��ȼ�������';
comment on column FACT_100228_GENERAL_LEVEL.statdate
  is 'ͳ������';
comment on column FACT_100228_GENERAL_LEVEL.channelid
  is '����';
comment on column FACT_100228_GENERAL_LEVEL.serverid
  is '����';
comment on column FACT_100228_GENERAL_LEVEL.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100228_GENERAL_LEVEL.appid
  is '��Ʒid';
comment on column FACT_100228_GENERAL_LEVEL.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_GENERAL_LEVEL.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100228_GENERAL_LEVEL.newcount
  is '������';
comment on column FACT_100228_GENERAL_LEVEL.conncount
  is '������';
comment on column FACT_100228_GENERAL_LEVEL.paycount
  is '������';
comment on column FACT_100228_GENERAL_LEVEL.payamount
  is '���ѽ��';
comment on column FACT_100228_GENERAL_LEVEL.data_source
  is '������Դ';
create index IDX40_100228 on FACT_100228_GENERAL_LEVEL (CHANNELID);
create index IDX41_100228 on FACT_100228_GENERAL_LEVEL (SERVERID);
create index IDX42_100228 on FACT_100228_GENERAL_LEVEL (STATDATE);

prompt
prompt Creating table FACT_100228_GENERAL_MONTH
prompt ========================================
prompt
create table FACT_100228_GENERAL_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_GENERAL_MONTH
  is '�»���������';
comment on column FACT_100228_GENERAL_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100228_GENERAL_MONTH.channelid
  is '����';
comment on column FACT_100228_GENERAL_MONTH.serverid
  is '����';
comment on column FACT_100228_GENERAL_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100228_GENERAL_MONTH.appid
  is '��Ʒid';
comment on column FACT_100228_GENERAL_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_GENERAL_MONTH.newcount
  is '������';
comment on column FACT_100228_GENERAL_MONTH.conncount
  is '������';
comment on column FACT_100228_GENERAL_MONTH.paycount
  is '������';
comment on column FACT_100228_GENERAL_MONTH.payamount
  is '���ѽ��';
comment on column FACT_100228_GENERAL_MONTH.data_source
  is '������Դ';
create index IDX43_100228 on FACT_100228_GENERAL_MONTH (CHANNELID);
create index IDX44_100228 on FACT_100228_GENERAL_MONTH (SERVERID);
create index IDX45_100228 on FACT_100228_GENERAL_MONTH (STATDATE);

prompt
prompt Creating table FACT_100228_GENERAL_MONTH_DVID
prompt =============================================
prompt
create table FACT_100228_GENERAL_MONTH_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_GENERAL_MONTH_DVID
  is '���豸����������';
comment on column FACT_100228_GENERAL_MONTH_DVID.statdate
  is 'ͳ������';
comment on column FACT_100228_GENERAL_MONTH_DVID.channelid
  is '����';
comment on column FACT_100228_GENERAL_MONTH_DVID.appid
  is '��Ʒid';
comment on column FACT_100228_GENERAL_MONTH_DVID.newcount
  is '������';
comment on column FACT_100228_GENERAL_MONTH_DVID.conncount
  is '������';
comment on column FACT_100228_GENERAL_MONTH_DVID.data_source
  is '������Դ';
create index IDX46_100228 on FACT_100228_GENERAL_MONTH_DVID (CHANNELID);
create index IDX48_100228 on FACT_100228_GENERAL_MONTH_DVID (STATDATE);

prompt
prompt Creating table FACT_100228_GENERAL_WEEK
prompt =======================================
prompt
create table FACT_100228_GENERAL_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_GENERAL_WEEK
  is '�ܻ���������';
comment on column FACT_100228_GENERAL_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100228_GENERAL_WEEK.channelid
  is '����';
comment on column FACT_100228_GENERAL_WEEK.serverid
  is '����';
comment on column FACT_100228_GENERAL_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100228_GENERAL_WEEK.appid
  is '��Ʒid';
comment on column FACT_100228_GENERAL_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_GENERAL_WEEK.newcount
  is '������';
comment on column FACT_100228_GENERAL_WEEK.conncount
  is '������';
comment on column FACT_100228_GENERAL_WEEK.paycount
  is '������';
comment on column FACT_100228_GENERAL_WEEK.payamount
  is '���ѽ��';
comment on column FACT_100228_GENERAL_WEEK.data_source
  is '������Դ';
create index IDX52_100228 on FACT_100228_GENERAL_WEEK (CHANNELID);
create index IDX53_100228 on FACT_100228_GENERAL_WEEK (SERVERID);
create index IDX54_100228 on FACT_100228_GENERAL_WEEK (STATDATE);

prompt
prompt Creating table FACT_100228_GENERAL_WEEK_DVID
prompt ============================================
prompt
create table FACT_100228_GENERAL_WEEK_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_GENERAL_WEEK_DVID
  is '���豸����������';
comment on column FACT_100228_GENERAL_WEEK_DVID.statdate
  is 'ͳ������';
comment on column FACT_100228_GENERAL_WEEK_DVID.channelid
  is '����';
comment on column FACT_100228_GENERAL_WEEK_DVID.appid
  is '��Ʒid';
comment on column FACT_100228_GENERAL_WEEK_DVID.newcount
  is '������';
comment on column FACT_100228_GENERAL_WEEK_DVID.conncount
  is '������';
comment on column FACT_100228_GENERAL_WEEK_DVID.data_source
  is '������Դ';
create index IDX49_100228 on FACT_100228_GENERAL_WEEK_DVID (CHANNELID);
create index IDX51_100228 on FACT_100228_GENERAL_WEEK_DVID (STATDATE);

prompt
prompt Creating table FACT_100228_HOUR_REPORT
prompt ======================================
prompt
create table FACT_100228_HOUR_REPORT
(
  statdate    VARCHAR2(20),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_HOUR_REPORT
  is '�ձ�Сʱ����';
comment on column FACT_100228_HOUR_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100228_HOUR_REPORT.appid
  is '��ƷID';
comment on column FACT_100228_HOUR_REPORT.channelid
  is '����';
comment on column FACT_100228_HOUR_REPORT.serverid
  is '����';
comment on column FACT_100228_HOUR_REPORT.indexid
  is 'ָ��';
comment on column FACT_100228_HOUR_REPORT.indtype
  is 'ָ������';
comment on column FACT_100228_HOUR_REPORT.rpt_data
  is '����';

prompt
prompt Creating table FACT_100228_LEVELPAY
prompt ===================================
prompt
create table FACT_100228_LEVELPAY
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  datatype       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  rolelevel      NUMBER,
  paycount       NUMBER,
  first_paycount NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100228_LEVELPAY
  is '�û���ɫ�ȼ����ѷ�����';
comment on column FACT_100228_LEVELPAY.statdate
  is 'ͳ������';
comment on column FACT_100228_LEVELPAY.channelid
  is '����';
comment on column FACT_100228_LEVELPAY.serverid
  is '����';
comment on column FACT_100228_LEVELPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100228_LEVELPAY.appid
  is '��Ʒid';
comment on column FACT_100228_LEVELPAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_LEVELPAY.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100228_LEVELPAY.paycount
  is '�����û���';
comment on column FACT_100228_LEVELPAY.first_paycount
  is '���������û������״θ����û���';
comment on column FACT_100228_LEVELPAY.data_source
  is '������Դ';
create index IDX55_100228 on FACT_100228_LEVELPAY (CHANNELID);
create index IDX56_100228 on FACT_100228_LEVELPAY (SERVERID);
create index IDX57_100228 on FACT_100228_LEVELPAY (STATDATE);

prompt
prompt Creating table FACT_100228_LOST_MAC
prompt ===================================
prompt
create table FACT_100228_LOST_MAC
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_LOST_MAC
  is '�豸��ʧ������';
comment on column FACT_100228_LOST_MAC.statdate
  is 'ͳ������';
comment on column FACT_100228_LOST_MAC.lostdate
  is '��ʧ����';
comment on column FACT_100228_LOST_MAC.channelid
  is '����ID';
comment on column FACT_100228_LOST_MAC.serverid
  is '����ID';
comment on column FACT_100228_LOST_MAC.appid
  is '��ƷID';
comment on column FACT_100228_LOST_MAC.rolelevel
  is '��ʧʱ�ȼ�';
comment on column FACT_100228_LOST_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100228_LOST_MAC.lost_conn
  is '��Ծ�豸��ʧ';
comment on column FACT_100228_LOST_MAC.lost_pay
  is '�����豸��ʧ';
comment on column FACT_100228_LOST_MAC.data_source
  is '����Դ';
create index IDX58_100228 on FACT_100228_LOST_MAC (CHANNELID);
create index IDX59_100228 on FACT_100228_LOST_MAC (SERVERID);
create index IDX60_100228 on FACT_100228_LOST_MAC (STATDATE);

prompt
prompt Creating table FACT_100228_LOST_USER
prompt ====================================
prompt
create table FACT_100228_LOST_USER
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_LOST_USER
  is '�û���ʧ������';
comment on column FACT_100228_LOST_USER.statdate
  is 'ͳ������';
comment on column FACT_100228_LOST_USER.lostdate
  is '��ʧ����';
comment on column FACT_100228_LOST_USER.channelid
  is '����ID';
comment on column FACT_100228_LOST_USER.serverid
  is '����ID';
comment on column FACT_100228_LOST_USER.appid
  is '��ƷID';
comment on column FACT_100228_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column FACT_100228_LOST_USER.lost_days
  is '��ʧ����';
comment on column FACT_100228_LOST_USER.lost_conn
  is '��Ծ�û���ʧ';
comment on column FACT_100228_LOST_USER.lost_pay
  is '�����û���ʧ';
comment on column FACT_100228_LOST_USER.data_source
  is '����Դ';
create index IDX61_100228 on FACT_100228_LOST_USER (CHANNELID);
create index IDX62_100228 on FACT_100228_LOST_USER (SERVERID);
create index IDX63_100228 on FACT_100228_LOST_USER (STATDATE);

prompt
prompt Creating table FACT_100228_LTV_MAC
prompt ==================================
prompt
create table FACT_100228_LTV_MAC
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_LTV_MAC
  is '�豸LTV������';
comment on column FACT_100228_LTV_MAC.statdate
  is 'ͳ������';
comment on column FACT_100228_LTV_MAC.ltvdate
  is '��ֵ����';
comment on column FACT_100228_LTV_MAC.channelid
  is '����';
comment on column FACT_100228_LTV_MAC.serverid
  is '����';
comment on column FACT_100228_LTV_MAC.appid
  is '��Ʒid';
comment on column FACT_100228_LTV_MAC.ltv_days
  is 'ltv��';
comment on column FACT_100228_LTV_MAC.payamount
  is '���ѽ��';
comment on column FACT_100228_LTV_MAC.data_source
  is '������Դ';
create index IDX64_100228 on FACT_100228_LTV_MAC (CHANNELID);
create index IDX65_100228 on FACT_100228_LTV_MAC (SERVERID);
create index IDX66_100228 on FACT_100228_LTV_MAC (STATDATE);

prompt
prompt Creating table FACT_100228_LTV_USER
prompt ===================================
prompt
create table FACT_100228_LTV_USER
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_LTV_USER
  is '�û�LTV������';
comment on column FACT_100228_LTV_USER.statdate
  is 'ͳ������';
comment on column FACT_100228_LTV_USER.ltvdate
  is '��ֵ����';
comment on column FACT_100228_LTV_USER.channelid
  is '����';
comment on column FACT_100228_LTV_USER.serverid
  is '����';
comment on column FACT_100228_LTV_USER.appid
  is '��Ʒid';
comment on column FACT_100228_LTV_USER.ltv_days
  is 'ltv��';
comment on column FACT_100228_LTV_USER.payamount
  is '���ѽ��';
comment on column FACT_100228_LTV_USER.data_source
  is '������Դ';
create index IDX67_100228 on FACT_100228_LTV_USER (CHANNELID);
create index IDX68_100228 on FACT_100228_LTV_USER (SERVERID);
create index IDX69_100228 on FACT_100228_LTV_USER (STATDATE);

prompt
prompt Creating table FACT_100228_MISS_FIRST
prompt =====================================
prompt
create table FACT_100228_MISS_FIRST
(
  statdate        VARCHAR2(10),
  channelid       VARCHAR2(50),
  serverid        VARCHAR2(50),
  appid           VARCHAR2(50),
  versionid       VARCHAR2(50),
  missionid       VARCHAR2(50),
  rolelevel       NUMBER,
  rolejob         VARCHAR2(50) default '0',
  firstenter_succ NUMBER,
  firstenter_fail NUMBER,
  loaddate        DATE,
  data_source     VARCHAR2(100)
)
;
comment on table FACT_100228_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column FACT_100228_MISS_FIRST.statdate
  is 'ͳ������';
comment on column FACT_100228_MISS_FIRST.channelid
  is '����';
comment on column FACT_100228_MISS_FIRST.serverid
  is '����';
comment on column FACT_100228_MISS_FIRST.appid
  is '��ƷID';
comment on column FACT_100228_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_MISS_FIRST.missionid
  is '�ؿ�ID';
comment on column FACT_100228_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column FACT_100228_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column FACT_100228_MISS_FIRST.firstenter_succ
  is '��һ�ν���ؿ��ɹ���';
comment on column FACT_100228_MISS_FIRST.firstenter_fail
  is '��һ�ν���ؿ�ʧ����';
comment on column FACT_100228_MISS_FIRST.data_source
  is '������Դ';
create index IDX70_100228 on FACT_100228_MISS_FIRST (CHANNELID);
create index IDX71_100228 on FACT_100228_MISS_FIRST (SERVERID);
create index IDX72_100228 on FACT_100228_MISS_FIRST (STATDATE);

prompt
prompt Creating table FACT_100228_NET
prompt ==============================
prompt
create table FACT_100228_NET
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_net    VARCHAR2(50),
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_NET
  is '������ʽ������';
comment on column FACT_100228_NET.statdate
  is 'ͳ������';
comment on column FACT_100228_NET.channelid
  is '����';
comment on column FACT_100228_NET.serverid
  is '����';
comment on column FACT_100228_NET.appid
  is '��Ʒid';
comment on column FACT_100228_NET.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_NET.dvid_net
  is '������ʽ';
comment on column FACT_100228_NET.conncount
  is '������';
comment on column FACT_100228_NET.data_source
  is '������Դ';
create index IDX73_100228 on FACT_100228_NET (CHANNELID);
create index IDX74_100228 on FACT_100228_NET (SERVERID);
create index IDX75_100228 on FACT_100228_NET (STATDATE);

prompt
prompt Creating table FACT_100228_OPERATOR
prompt ===================================
prompt
create table FACT_100228_OPERATOR
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  dvid_operator VARCHAR2(50),
  conncount     NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100228_OPERATOR
  is '��Ӫ�̷�����';
comment on column FACT_100228_OPERATOR.statdate
  is 'ͳ������';
comment on column FACT_100228_OPERATOR.channelid
  is '����';
comment on column FACT_100228_OPERATOR.serverid
  is '����';
comment on column FACT_100228_OPERATOR.appid
  is '��Ʒid';
comment on column FACT_100228_OPERATOR.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_OPERATOR.dvid_operator
  is '������ʽ';
comment on column FACT_100228_OPERATOR.conncount
  is '������';
comment on column FACT_100228_OPERATOR.data_source
  is '������Դ';
create index IDX76_100228 on FACT_100228_OPERATOR (CHANNELID);
create index IDX77_100228 on FACT_100228_OPERATOR (SERVERID);
create index IDX78_100228 on FACT_100228_OPERATOR (STATDATE);

prompt
prompt Creating table FACT_100228_ORDER
prompt ================================
prompt
create table FACT_100228_ORDER
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100228_ORDER
  is '����������';
comment on column FACT_100228_ORDER.statdate
  is 'ͳ������';
comment on column FACT_100228_ORDER.channelid
  is '����';
comment on column FACT_100228_ORDER.serverid
  is '����';
comment on column FACT_100228_ORDER.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100228_ORDER.appid
  is '��Ʒid';
comment on column FACT_100228_ORDER.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_ORDER.paysucccount
  is '�ɹ�������';
comment on column FACT_100228_ORDER.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100228_ORDER.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100228_ORDER.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100228_ORDER.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100228_ORDER.payfailnum
  is '����ʧ������';
comment on column FACT_100228_ORDER.data_source
  is '������Դ';
create index IDX79_100228 on FACT_100228_ORDER (CHANNELID);
create index IDX80_100228 on FACT_100228_ORDER (SERVERID);
create index IDX81_100228 on FACT_100228_ORDER (STATDATE);

prompt
prompt Creating table FACT_100228_ORDER_HOUR
prompt =====================================
prompt
create table FACT_100228_ORDER_HOUR
(
  statdate      VARCHAR2(20),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100228_ORDER_HOUR
  is '����Сʱ������';
comment on column FACT_100228_ORDER_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100228_ORDER_HOUR.channelid
  is '����';
comment on column FACT_100228_ORDER_HOUR.serverid
  is '����';
comment on column FACT_100228_ORDER_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100228_ORDER_HOUR.appid
  is '��Ʒid';
comment on column FACT_100228_ORDER_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_ORDER_HOUR.paysucccount
  is '�ɹ�������';
comment on column FACT_100228_ORDER_HOUR.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100228_ORDER_HOUR.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100228_ORDER_HOUR.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100228_ORDER_HOUR.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100228_ORDER_HOUR.payfailnum
  is '����ʧ������';
comment on column FACT_100228_ORDER_HOUR.data_source
  is '������Դ';
create index IDX177_100228 on FACT_100228_ORDER_HOUR (CHANNELID);
create index IDX178_100228 on FACT_100228_ORDER_HOUR (SERVERID);
create index IDX179_100228 on FACT_100228_ORDER_HOUR (STATDATE);

prompt
prompt Creating table FACT_100228_ORDER_MONTH
prompt ======================================
prompt
create table FACT_100228_ORDER_MONTH
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100228_ORDER_MONTH
  is '�¶���������';
comment on column FACT_100228_ORDER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100228_ORDER_MONTH.channelid
  is '����';
comment on column FACT_100228_ORDER_MONTH.serverid
  is '����';
comment on column FACT_100228_ORDER_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100228_ORDER_MONTH.appid
  is '��Ʒid';
comment on column FACT_100228_ORDER_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_ORDER_MONTH.paysucccount
  is '�ɹ�������';
comment on column FACT_100228_ORDER_MONTH.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100228_ORDER_MONTH.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100228_ORDER_MONTH.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100228_ORDER_MONTH.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100228_ORDER_MONTH.payfailnum
  is '����ʧ������';
comment on column FACT_100228_ORDER_MONTH.data_source
  is '������Դ';
create index IDX191_100228 on FACT_100228_ORDER_MONTH (CHANNELID);
create index IDX192_100228 on FACT_100228_ORDER_MONTH (SERVERID);
create index IDX193_100228 on FACT_100228_ORDER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100228_ORDER_WEEK
prompt =====================================
prompt
create table FACT_100228_ORDER_WEEK
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100228_ORDER_WEEK
  is '�ܶ���������';
comment on column FACT_100228_ORDER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100228_ORDER_WEEK.channelid
  is '����';
comment on column FACT_100228_ORDER_WEEK.serverid
  is '����';
comment on column FACT_100228_ORDER_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100228_ORDER_WEEK.appid
  is '��Ʒid';
comment on column FACT_100228_ORDER_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_ORDER_WEEK.paysucccount
  is '�ɹ�������';
comment on column FACT_100228_ORDER_WEEK.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100228_ORDER_WEEK.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100228_ORDER_WEEK.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100228_ORDER_WEEK.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100228_ORDER_WEEK.payfailnum
  is '����ʧ������';
comment on column FACT_100228_ORDER_WEEK.data_source
  is '������Դ';
create index IDX188_100228 on FACT_100228_ORDER_WEEK (CHANNELID);
create index IDX189_100228 on FACT_100228_ORDER_WEEK (SERVERID);
create index IDX190_100228 on FACT_100228_ORDER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100228_PAYAMOUNT_DAY
prompt ========================================
prompt
create table FACT_100228_PAYAMOUNT_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_PAYAMOUNT_DAY
  is '�ճ�ֵ��������';
comment on column FACT_100228_PAYAMOUNT_DAY.statdate
  is 'ͳ������';
comment on column FACT_100228_PAYAMOUNT_DAY.channelid
  is '����';
comment on column FACT_100228_PAYAMOUNT_DAY.serverid
  is '����';
comment on column FACT_100228_PAYAMOUNT_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100228_PAYAMOUNT_DAY.appid
  is '��Ʒid';
comment on column FACT_100228_PAYAMOUNT_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_PAYAMOUNT_DAY.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100228_PAYAMOUNT_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100228_PAYAMOUNT_DAY.data_source
  is '������Դ';
create index IDX82_100228 on FACT_100228_PAYAMOUNT_DAY (CHANNELID);
create index IDX83_100228 on FACT_100228_PAYAMOUNT_DAY (SERVERID);
create index IDX84_100228 on FACT_100228_PAYAMOUNT_DAY (STATDATE);

prompt
prompt Creating table FACT_100228_PAYAMOUNT_MONTH
prompt ==========================================
prompt
create table FACT_100228_PAYAMOUNT_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_PAYAMOUNT_MONTH
  is '�³�ֵ��������';
comment on column FACT_100228_PAYAMOUNT_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100228_PAYAMOUNT_MONTH.channelid
  is '����';
comment on column FACT_100228_PAYAMOUNT_MONTH.serverid
  is '����';
comment on column FACT_100228_PAYAMOUNT_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100228_PAYAMOUNT_MONTH.appid
  is '��Ʒid';
comment on column FACT_100228_PAYAMOUNT_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_PAYAMOUNT_MONTH.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100228_PAYAMOUNT_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100228_PAYAMOUNT_MONTH.data_source
  is '������Դ';
create index IDX88_100228 on FACT_100228_PAYAMOUNT_MONTH (CHANNELID);
create index IDX89_100228 on FACT_100228_PAYAMOUNT_MONTH (SERVERID);
create index IDX90_100228 on FACT_100228_PAYAMOUNT_MONTH (STATDATE);

prompt
prompt Creating table FACT_100228_PAYAMOUNT_WEEK
prompt =========================================
prompt
create table FACT_100228_PAYAMOUNT_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_PAYAMOUNT_WEEK
  is '�ܳ�ֵ��������';
comment on column FACT_100228_PAYAMOUNT_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100228_PAYAMOUNT_WEEK.channelid
  is '����';
comment on column FACT_100228_PAYAMOUNT_WEEK.serverid
  is '����';
comment on column FACT_100228_PAYAMOUNT_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100228_PAYAMOUNT_WEEK.appid
  is '��Ʒid';
comment on column FACT_100228_PAYAMOUNT_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_PAYAMOUNT_WEEK.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100228_PAYAMOUNT_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100228_PAYAMOUNT_WEEK.data_source
  is '������Դ';
create index IDX85_100228 on FACT_100228_PAYAMOUNT_WEEK (CHANNELID);
create index IDX86_100228 on FACT_100228_PAYAMOUNT_WEEK (SERVERID);
create index IDX87_100228 on FACT_100228_PAYAMOUNT_WEEK (STATDATE);

prompt
prompt Creating table FACT_100228_PAYNUM_DAY
prompt =====================================
prompt
create table FACT_100228_PAYNUM_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_PAYNUM_DAY
  is '�ճ�ֵ����������';
comment on column FACT_100228_PAYNUM_DAY.statdate
  is 'ͳ������';
comment on column FACT_100228_PAYNUM_DAY.channelid
  is '����';
comment on column FACT_100228_PAYNUM_DAY.serverid
  is '����';
comment on column FACT_100228_PAYNUM_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100228_PAYNUM_DAY.appid
  is '��Ʒid';
comment on column FACT_100228_PAYNUM_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_PAYNUM_DAY.paynum
  is '��ֵ����';
comment on column FACT_100228_PAYNUM_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100228_PAYNUM_DAY.data_source
  is '������Դ';
create index IDX97_100228 on FACT_100228_PAYNUM_DAY (CHANNELID);
create index IDX98_100228 on FACT_100228_PAYNUM_DAY (SERVERID);
create index IDX99_100228 on FACT_100228_PAYNUM_DAY (STATDATE);

prompt
prompt Creating table FACT_100228_PAYNUM_MONTH
prompt =======================================
prompt
create table FACT_100228_PAYNUM_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_PAYNUM_MONTH
  is '�³�ֵ����������';
comment on column FACT_100228_PAYNUM_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100228_PAYNUM_MONTH.channelid
  is '����';
comment on column FACT_100228_PAYNUM_MONTH.serverid
  is '����';
comment on column FACT_100228_PAYNUM_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100228_PAYNUM_MONTH.appid
  is '��Ʒid';
comment on column FACT_100228_PAYNUM_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_PAYNUM_MONTH.paynum
  is '��ֵ����';
comment on column FACT_100228_PAYNUM_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100228_PAYNUM_MONTH.data_source
  is '������Դ';
create index IDX91_100228 on FACT_100228_PAYNUM_MONTH (CHANNELID);
create index IDX92_100228 on FACT_100228_PAYNUM_MONTH (SERVERID);
create index IDX93_100228 on FACT_100228_PAYNUM_MONTH (STATDATE);

prompt
prompt Creating table FACT_100228_PAYNUM_WEEK
prompt ======================================
prompt
create table FACT_100228_PAYNUM_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_PAYNUM_WEEK
  is '�ܳ�ֵ����������';
comment on column FACT_100228_PAYNUM_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100228_PAYNUM_WEEK.channelid
  is '����';
comment on column FACT_100228_PAYNUM_WEEK.serverid
  is '����';
comment on column FACT_100228_PAYNUM_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100228_PAYNUM_WEEK.appid
  is '��Ʒid';
comment on column FACT_100228_PAYNUM_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_PAYNUM_WEEK.paynum
  is '��ֵ����';
comment on column FACT_100228_PAYNUM_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100228_PAYNUM_WEEK.data_source
  is '������Դ';
create index IDX94_100228 on FACT_100228_PAYNUM_WEEK (CHANNELID);
create index IDX95_100228 on FACT_100228_PAYNUM_WEEK (SERVERID);
create index IDX96_100228 on FACT_100228_PAYNUM_WEEK (STATDATE);

prompt
prompt Creating table FACT_100228_PAYTYPE
prompt ==================================
prompt
create table FACT_100228_PAYTYPE
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paytypeid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_PAYTYPE
  is '��ֵ���ͷ�����';
comment on column FACT_100228_PAYTYPE.statdate
  is 'ͳ������';
comment on column FACT_100228_PAYTYPE.channelid
  is '����';
comment on column FACT_100228_PAYTYPE.serverid
  is '����';
comment on column FACT_100228_PAYTYPE.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100228_PAYTYPE.appid
  is '��Ʒid';
comment on column FACT_100228_PAYTYPE.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_PAYTYPE.paytypeid
  is '��ֵ����';
comment on column FACT_100228_PAYTYPE.payamount
  is '��ֵ���';
comment on column FACT_100228_PAYTYPE.paycount
  is '��ֵ����';
comment on column FACT_100228_PAYTYPE.paynum
  is '��ֵ����';
comment on column FACT_100228_PAYTYPE.data_source
  is '������Դ';
create index IDX100_100228 on FACT_100228_PAYTYPE (CHANNELID);
create index IDX101_100228 on FACT_100228_PAYTYPE (SERVERID);
create index IDX102_100228 on FACT_100228_PAYTYPE (STATDATE);

prompt
prompt Creating table FACT_100228_PAYWAY
prompt =================================
prompt
create table FACT_100228_PAYWAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paywayid    VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_PAYWAY
  is '��ֵ��ʽ������';
comment on column FACT_100228_PAYWAY.statdate
  is 'ͳ������';
comment on column FACT_100228_PAYWAY.channelid
  is '����';
comment on column FACT_100228_PAYWAY.serverid
  is '����';
comment on column FACT_100228_PAYWAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100228_PAYWAY.appid
  is '��Ʒid';
comment on column FACT_100228_PAYWAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_PAYWAY.paywayid
  is '��ֵ��ʽ';
comment on column FACT_100228_PAYWAY.payamount
  is '��ֵ���';
comment on column FACT_100228_PAYWAY.paycount
  is '��ֵ����';
comment on column FACT_100228_PAYWAY.paynum
  is '��ֵ����';
comment on column FACT_100228_PAYWAY.data_source
  is '������Դ';
create index IDX103_100228 on FACT_100228_PAYWAY (CHANNELID);
create index IDX104_100228 on FACT_100228_PAYWAY (SERVERID);
create index IDX105_100228 on FACT_100228_PAYWAY (STATDATE);

prompt
prompt Creating table FACT_100228_REGION
prompt =================================
prompt
create table FACT_100228_REGION
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  country     VARCHAR2(50),
  province    VARCHAR2(50),
  city        VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_REGION
  is '���������';
comment on column FACT_100228_REGION.statdate
  is 'ͳ������';
comment on column FACT_100228_REGION.channelid
  is '����';
comment on column FACT_100228_REGION.serverid
  is '����';
comment on column FACT_100228_REGION.appid
  is '��Ʒid';
comment on column FACT_100228_REGION.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_REGION.country
  is '����';
comment on column FACT_100228_REGION.province
  is 'ʡ';
comment on column FACT_100228_REGION.city
  is '��';
comment on column FACT_100228_REGION.newcount
  is '������';
comment on column FACT_100228_REGION.conncount
  is '������';
comment on column FACT_100228_REGION.paycount
  is '������';
comment on column FACT_100228_REGION.payamount
  is '���ѽ��';
comment on column FACT_100228_REGION.data_source
  is '������Դ';
create index IDX106_100228 on FACT_100228_REGION (CHANNELID);
create index IDX107_100228 on FACT_100228_REGION (SERVERID);
create index IDX108_100228 on FACT_100228_REGION (STATDATE);

prompt
prompt Creating table FACT_100228_REMAIN_MAC
prompt =====================================
prompt
create table FACT_100228_REMAIN_MAC
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_REMAIN_MAC
  is '�豸�����';
comment on column FACT_100228_REMAIN_MAC.statdate
  is 'ͳ������';
comment on column FACT_100228_REMAIN_MAC.conndate
  is '��������';
comment on column FACT_100228_REMAIN_MAC.channelid
  is '����ID';
comment on column FACT_100228_REMAIN_MAC.serverid
  is '����ID';
comment on column FACT_100228_REMAIN_MAC.appid
  is '��ƷID';
comment on column FACT_100228_REMAIN_MAC.remain_days
  is '��������';
comment on column FACT_100228_REMAIN_MAC.new_remain
  is '��������';
comment on column FACT_100228_REMAIN_MAC.conn_remain
  is '��������';
comment on column FACT_100228_REMAIN_MAC.pay_remain
  is '��������';
comment on column FACT_100228_REMAIN_MAC.data_source
  is '����Դ';
create index IDX109_100228 on FACT_100228_REMAIN_MAC (CHANNELID);
create index IDX110_100228 on FACT_100228_REMAIN_MAC (SERVERID);
create index IDX111_100228 on FACT_100228_REMAIN_MAC (STATDATE);

prompt
prompt Creating table FACT_100228_REMAIN_USER
prompt ======================================
prompt
create table FACT_100228_REMAIN_USER
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_REMAIN_USER
  is '�û������';
comment on column FACT_100228_REMAIN_USER.statdate
  is 'ͳ������';
comment on column FACT_100228_REMAIN_USER.conndate
  is '��������';
comment on column FACT_100228_REMAIN_USER.channelid
  is '����ID';
comment on column FACT_100228_REMAIN_USER.serverid
  is '����ID';
comment on column FACT_100228_REMAIN_USER.appid
  is '��ƷID';
comment on column FACT_100228_REMAIN_USER.remain_days
  is '��������';
comment on column FACT_100228_REMAIN_USER.new_remain
  is '��������';
comment on column FACT_100228_REMAIN_USER.conn_remain
  is '��������';
comment on column FACT_100228_REMAIN_USER.pay_remain
  is '��������';
comment on column FACT_100228_REMAIN_USER.data_source
  is '����Դ';
create index IDX112_100228 on FACT_100228_REMAIN_USER (CHANNELID);
create index IDX113_100228 on FACT_100228_REMAIN_USER (SERVERID);
create index IDX114_100228 on FACT_100228_REMAIN_USER (STATDATE);

prompt
prompt Creating table FACT_100228_VC
prompt =============================
prompt
create table FACT_100228_VC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcamount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100228_VC
  is '������ҷ�����';
comment on column FACT_100228_VC.statdate
  is 'ͳ������';
comment on column FACT_100228_VC.channelid
  is '����';
comment on column FACT_100228_VC.serverid
  is '����';
comment on column FACT_100228_VC.appid
  is '��Ʒid';
comment on column FACT_100228_VC.versionid
  is '��Ʒ�汾';
comment on column FACT_100228_VC.vctype
  is '�����������';
comment on column FACT_100228_VC.vcusetype
  is '�������ʹ������';
comment on column FACT_100228_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column FACT_100228_VC.vcamount
  is '������ҽ��';
comment on column FACT_100228_VC.data_source
  is '������Դ';
create index IDX115_100228 on FACT_100228_VC (CHANNELID);
create index IDX116_100228 on FACT_100228_VC (SERVERID);
create index IDX117_100228 on FACT_100228_VC (STATDATE);

prompt
prompt Creating table FACT_100230_BACK_MAC
prompt ===================================
prompt
create table FACT_100230_BACK_MAC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_BACK_MAC
  is '�豸����������';
comment on column FACT_100230_BACK_MAC.statdate
  is 'ͳ������';
comment on column FACT_100230_BACK_MAC.channelid
  is '����ID';
comment on column FACT_100230_BACK_MAC.serverid
  is '����ID';
comment on column FACT_100230_BACK_MAC.appid
  is '��ƷID';
comment on column FACT_100230_BACK_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100230_BACK_MAC.back_conn
  is '��Ծ�豸������';
comment on column FACT_100230_BACK_MAC.back_pay
  is '�����豸������';
comment on column FACT_100230_BACK_MAC.data_source
  is '����Դ';
create index IDX1_100230 on FACT_100230_BACK_MAC (CHANNELID);
create index IDX2_100230 on FACT_100230_BACK_MAC (SERVERID);
create index IDX3_100230 on FACT_100230_BACK_MAC (STATDATE);

prompt
prompt Creating table FACT_100230_BACK_MAC_MONTH
prompt =========================================
prompt
create table FACT_100230_BACK_MAC_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_BACK_MAC_MONTH
  is '�豸����������';
comment on column FACT_100230_BACK_MAC_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100230_BACK_MAC_MONTH.channelid
  is '����ID';
comment on column FACT_100230_BACK_MAC_MONTH.serverid
  is '����ID';
comment on column FACT_100230_BACK_MAC_MONTH.appid
  is '��ƷID';
comment on column FACT_100230_BACK_MAC_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100230_BACK_MAC_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100230_BACK_MAC_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100230_BACK_MAC_MONTH.data_source
  is '����Դ';
create index IDX4_100230 on FACT_100230_BACK_MAC_MONTH (CHANNELID);
create index IDX5_100230 on FACT_100230_BACK_MAC_MONTH (SERVERID);
create index IDX6_100230 on FACT_100230_BACK_MAC_MONTH (STATDATE);

prompt
prompt Creating table FACT_100230_BACK_MAC_WEEK
prompt ========================================
prompt
create table FACT_100230_BACK_MAC_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_BACK_MAC_WEEK
  is '�豸����������';
comment on column FACT_100230_BACK_MAC_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100230_BACK_MAC_WEEK.channelid
  is '����ID';
comment on column FACT_100230_BACK_MAC_WEEK.serverid
  is '����ID';
comment on column FACT_100230_BACK_MAC_WEEK.appid
  is '��ƷID';
comment on column FACT_100230_BACK_MAC_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100230_BACK_MAC_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100230_BACK_MAC_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100230_BACK_MAC_WEEK.data_source
  is '����Դ';
create index IDX7_100230 on FACT_100230_BACK_MAC_WEEK (CHANNELID);
create index IDX8_100230 on FACT_100230_BACK_MAC_WEEK (SERVERID);
create index IDX9_100230 on FACT_100230_BACK_MAC_WEEK (STATDATE);

prompt
prompt Creating table FACT_100230_BACK_USER
prompt ====================================
prompt
create table FACT_100230_BACK_USER
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_BACK_USER
  is '�û�����������';
comment on column FACT_100230_BACK_USER.statdate
  is 'ͳ������';
comment on column FACT_100230_BACK_USER.channelid
  is '����ID';
comment on column FACT_100230_BACK_USER.serverid
  is '����ID';
comment on column FACT_100230_BACK_USER.appid
  is '��ƷID';
comment on column FACT_100230_BACK_USER.lost_days
  is '��ʧ����';
comment on column FACT_100230_BACK_USER.back_conn
  is '��Ծ�û�������';
comment on column FACT_100230_BACK_USER.back_pay
  is '�����û�������';
comment on column FACT_100230_BACK_USER.data_source
  is '����Դ';
create index IDX16_100230 on FACT_100230_BACK_USER (CHANNELID);
create index IDX17_100230 on FACT_100230_BACK_USER (SERVERID);
create index IDX18_100230 on FACT_100230_BACK_USER (STATDATE);

prompt
prompt Creating table FACT_100230_BACK_USER_MONTH
prompt ==========================================
prompt
create table FACT_100230_BACK_USER_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_BACK_USER_MONTH
  is '�豸����������';
comment on column FACT_100230_BACK_USER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100230_BACK_USER_MONTH.channelid
  is '����ID';
comment on column FACT_100230_BACK_USER_MONTH.serverid
  is '����ID';
comment on column FACT_100230_BACK_USER_MONTH.appid
  is '��ƷID';
comment on column FACT_100230_BACK_USER_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100230_BACK_USER_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100230_BACK_USER_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100230_BACK_USER_MONTH.data_source
  is '����Դ';
create index IDX13_100230 on FACT_100230_BACK_USER_MONTH (CHANNELID);
create index IDX14_100230 on FACT_100230_BACK_USER_MONTH (SERVERID);
create index IDX15_100230 on FACT_100230_BACK_USER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100230_BACK_USER_WEEK
prompt =========================================
prompt
create table FACT_100230_BACK_USER_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_BACK_USER_WEEK
  is '�豸����������';
comment on column FACT_100230_BACK_USER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100230_BACK_USER_WEEK.channelid
  is '����ID';
comment on column FACT_100230_BACK_USER_WEEK.serverid
  is '����ID';
comment on column FACT_100230_BACK_USER_WEEK.appid
  is '��ƷID';
comment on column FACT_100230_BACK_USER_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100230_BACK_USER_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100230_BACK_USER_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100230_BACK_USER_WEEK.data_source
  is '����Դ';
create index IDX10_100230 on FACT_100230_BACK_USER_WEEK (CHANNELID);
create index IDX11_100230 on FACT_100230_BACK_USER_WEEK (SERVERID);
create index IDX12_100230 on FACT_100230_BACK_USER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100230_CEVENT
prompt =================================
prompt
create table FACT_100230_CEVENT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  eventkey    VARCHAR2(50),
  eventcount  NUMBER,
  eventnum    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_CEVENT
  is '�Զ��������';
comment on column FACT_100230_CEVENT.statdate
  is 'ͳ������';
comment on column FACT_100230_CEVENT.channelid
  is '����';
comment on column FACT_100230_CEVENT.serverid
  is '����';
comment on column FACT_100230_CEVENT.appid
  is '��Ʒid';
comment on column FACT_100230_CEVENT.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100230_CEVENT.eventcount
  is '�¼��û���';
comment on column FACT_100230_CEVENT.eventnum
  is '�¼�����';
comment on column FACT_100230_CEVENT.data_source
  is '������Դ';
create index IDX181_100230 on FACT_100230_CEVENT (CHANNELID);
create index IDX182_100230 on FACT_100230_CEVENT (SERVERID);
create index IDX183_100230 on FACT_100230_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100230_CEVENT_PAR
prompt =====================================
prompt
create table FACT_100230_CEVENT_PAR
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  ilevel         NUMBER,
  eventkey       VARCHAR2(100),
  eventpar_key   VARCHAR2(100),
  eventpar_value VARCHAR2(100),
  eventcount     NUMBER,
  eventnum       NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100230_CEVENT_PAR
  is '�Զ������������';
comment on column FACT_100230_CEVENT_PAR.statdate
  is 'ͳ������';
comment on column FACT_100230_CEVENT_PAR.channelid
  is '����';
comment on column FACT_100230_CEVENT_PAR.serverid
  is '����';
comment on column FACT_100230_CEVENT_PAR.appid
  is '��Ʒid';
comment on column FACT_100230_CEVENT_PAR.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_CEVENT_PAR.ilevel
  is '��ɫ�ȼ�';
comment on column FACT_100230_CEVENT_PAR.eventkey
  is '�¼�����';
comment on column FACT_100230_CEVENT_PAR.eventpar_key
  is '�¼�����';
comment on column FACT_100230_CEVENT_PAR.eventpar_value
  is '�¼�����ֵ';
comment on column FACT_100230_CEVENT_PAR.eventcount
  is '�¼��û���';
comment on column FACT_100230_CEVENT_PAR.eventnum
  is '�¼�����';
comment on column FACT_100230_CEVENT_PAR.data_source
  is '������Դ';
create index IDX185_100230 on FACT_100230_CEVENT_PAR (CHANNELID);
create index IDX186_100230 on FACT_100230_CEVENT_PAR (SERVERID);
create index IDX187_100230 on FACT_100230_CEVENT_PAR (STATDATE);

prompt
prompt Creating table FACT_100230_COMP_CEVENT
prompt ======================================
prompt
create table FACT_100230_COMP_CEVENT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(10),
  channelid   VARCHAR2(50),
  gameversion VARCHAR2(50),
  serverid    VARCHAR2(50),
  ilevel      NUMBER,
  eventkey    VARCHAR2(100),
  compid      VARCHAR2(50),
  caltype     VARCHAR2(50),
  dimpars     VARCHAR2(2000),
  comp_data   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_COMP_CEVENT
  is '�Զ����¼���Ϸ�����';
comment on column FACT_100230_COMP_CEVENT.statdate
  is '����';
comment on column FACT_100230_COMP_CEVENT.appid
  is '��Ϸ�� appid';
comment on column FACT_100230_COMP_CEVENT.channelid
  is '���� ID';
comment on column FACT_100230_COMP_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column FACT_100230_COMP_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column FACT_100230_COMP_CEVENT.ilevel
  is '��ҵȼ�';
comment on column FACT_100230_COMP_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100230_COMP_CEVENT.compid
  is '��ϼ����¼�ID';
comment on column FACT_100230_COMP_CEVENT.caltype
  is '��ϼ����¼���������';
comment on column FACT_100230_COMP_CEVENT.dimpars
  is '��ϲ���';
comment on column FACT_100230_COMP_CEVENT.comp_data
  is '��ϼ�����';
create index IDX184_100230 on FACT_100230_COMP_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100230_DAILY_REPORT
prompt =======================================
prompt
create table FACT_100230_DAILY_REPORT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_DAILY_REPORT
  is '�ձ�����';
comment on column FACT_100230_DAILY_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100230_DAILY_REPORT.appid
  is '��ƷID';
comment on column FACT_100230_DAILY_REPORT.channelid
  is '����';
comment on column FACT_100230_DAILY_REPORT.serverid
  is '����';
comment on column FACT_100230_DAILY_REPORT.indexid
  is 'ָ��';
comment on column FACT_100230_DAILY_REPORT.indtype
  is 'ָ������';
comment on column FACT_100230_DAILY_REPORT.rpt_data
  is '����';
create index IDX176_100230 on FACT_100230_DAILY_REPORT (STATDATE);

prompt
prompt Creating table FACT_100230_DVID
prompt ===============================
prompt
create table FACT_100230_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_model  VARCHAR2(200),
  dvid_res    VARCHAR2(50),
  dvid_os     VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_DVID
  is '�豸������';
comment on column FACT_100230_DVID.statdate
  is 'ͳ������';
comment on column FACT_100230_DVID.channelid
  is '����';
comment on column FACT_100230_DVID.serverid
  is '����';
comment on column FACT_100230_DVID.appid
  is '��Ʒid';
comment on column FACT_100230_DVID.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_DVID.dvid_model
  is '����';
comment on column FACT_100230_DVID.dvid_res
  is '�豸�ֱ���';
comment on column FACT_100230_DVID.dvid_os
  is '�豸����ϵͳ';
comment on column FACT_100230_DVID.newcount
  is '�����û���';
comment on column FACT_100230_DVID.conncount
  is '�����û���';
comment on column FACT_100230_DVID.data_source
  is '������Դ';
create index IDX19_100230 on FACT_100230_DVID (CHANNELID);
create index IDX20_100230 on FACT_100230_DVID (SERVERID);
create index IDX21_100230 on FACT_100230_DVID (STATDATE);

prompt
prompt Creating table FACT_100230_FIRSTPAY
prompt ===================================
prompt
create table FACT_100230_FIRSTPAY
(
  statdate         VARCHAR2(10),
  firstpaydate     VARCHAR2(10),
  channelid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  datatype         VARCHAR2(50),
  appid            VARCHAR2(50),
  first_payfromreg NUMBER,
  first_paycount   NUMBER,
  payamount        NUMBER,
  loaddate         DATE default SYSDATE,
  data_source      VARCHAR2(100)
)
;
comment on table FACT_100230_FIRSTPAY
  is '�����û��״γ�ֵ������';
comment on column FACT_100230_FIRSTPAY.statdate
  is 'ͳ������';
comment on column FACT_100230_FIRSTPAY.firstpaydate
  is '�״θ�������';
comment on column FACT_100230_FIRSTPAY.channelid
  is '����';
comment on column FACT_100230_FIRSTPAY.serverid
  is '����';
comment on column FACT_100230_FIRSTPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100230_FIRSTPAY.appid
  is '��Ʒid';
comment on column FACT_100230_FIRSTPAY.first_payfromreg
  is 'ע���ڼ��쿪ʼ��ֵ(1��2��..7..30..)';
comment on column FACT_100230_FIRSTPAY.first_paycount
  is '���������û���';
comment on column FACT_100230_FIRSTPAY.payamount
  is '�ۼƵ��ڼ���ĳ�ֵ�ܶ�';
comment on column FACT_100230_FIRSTPAY.data_source
  is '������Դ';
create index IDX22_100230 on FACT_100230_FIRSTPAY (CHANNELID);
create index IDX23_100230 on FACT_100230_FIRSTPAY (SERVERID);
create index IDX24_100230 on FACT_100230_FIRSTPAY (STATDATE);

prompt
prompt Creating table FACT_100230_FIRSTPAY_AMOUNT
prompt ==========================================
prompt
create table FACT_100230_FIRSTPAY_AMOUNT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_FIRSTPAY_AMOUNT
  is '�״θ��ѽ�������';
comment on column FACT_100230_FIRSTPAY_AMOUNT.statdate
  is 'ͳ������';
comment on column FACT_100230_FIRSTPAY_AMOUNT.channelid
  is '����';
comment on column FACT_100230_FIRSTPAY_AMOUNT.serverid
  is '��������';
comment on column FACT_100230_FIRSTPAY_AMOUNT.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100230_FIRSTPAY_AMOUNT.appid
  is '��Ʒid';
comment on column FACT_100230_FIRSTPAY_AMOUNT.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_FIRSTPAY_AMOUNT.payamount
  is '�״θ��ѽ��';
comment on column FACT_100230_FIRSTPAY_AMOUNT.paycount
  is '�״θ��ѽ���Ӧ������';
create index IDX25_100230 on FACT_100230_FIRSTPAY_AMOUNT (CHANNELID);
create index IDX26_100230 on FACT_100230_FIRSTPAY_AMOUNT (SERVERID);
create index IDX27_100230 on FACT_100230_FIRSTPAY_AMOUNT (STATDATE);

prompt
prompt Creating table FACT_100230_GENERAL_DAY
prompt ======================================
prompt
create table FACT_100230_GENERAL_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_GENERAL_DAY
  is '�ջ���������';
comment on column FACT_100230_GENERAL_DAY.statdate
  is 'ͳ������';
comment on column FACT_100230_GENERAL_DAY.channelid
  is '����';
comment on column FACT_100230_GENERAL_DAY.serverid
  is '����';
comment on column FACT_100230_GENERAL_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100230_GENERAL_DAY.appid
  is '��Ʒid';
comment on column FACT_100230_GENERAL_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_GENERAL_DAY.newcount
  is '������';
comment on column FACT_100230_GENERAL_DAY.conncount
  is '������';
comment on column FACT_100230_GENERAL_DAY.paycount
  is '������';
comment on column FACT_100230_GENERAL_DAY.payamount
  is '���ѽ��';
comment on column FACT_100230_GENERAL_DAY.data_source
  is '������Դ';
create index IDX28_100230 on FACT_100230_GENERAL_DAY (CHANNELID);
create index IDX29_100230 on FACT_100230_GENERAL_DAY (SERVERID);
create index IDX30_100230 on FACT_100230_GENERAL_DAY (STATDATE);

prompt
prompt Creating table FACT_100230_GENERAL_DAY_DVID
prompt ===========================================
prompt
create table FACT_100230_GENERAL_DAY_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_GENERAL_DAY_DVID
  is '���豸����������';
comment on column FACT_100230_GENERAL_DAY_DVID.statdate
  is 'ͳ������';
comment on column FACT_100230_GENERAL_DAY_DVID.channelid
  is '����';
comment on column FACT_100230_GENERAL_DAY_DVID.appid
  is '��Ʒid';
comment on column FACT_100230_GENERAL_DAY_DVID.newcount
  is '������';
comment on column FACT_100230_GENERAL_DAY_DVID.conncount
  is '������';
comment on column FACT_100230_GENERAL_DAY_DVID.data_source
  is '������Դ';
create index IDX31_100230 on FACT_100230_GENERAL_DAY_DVID (CHANNELID);
create index IDX33_100230 on FACT_100230_GENERAL_DAY_DVID (STATDATE);

prompt
prompt Creating table FACT_100230_GENERAL_HOUR
prompt =======================================
prompt
create table FACT_100230_GENERAL_HOUR
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_GENERAL_HOUR
  is 'Сʱ����������';
comment on column FACT_100230_GENERAL_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100230_GENERAL_HOUR.channelid
  is '����';
comment on column FACT_100230_GENERAL_HOUR.serverid
  is '����';
comment on column FACT_100230_GENERAL_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100230_GENERAL_HOUR.appid
  is '��Ʒid';
comment on column FACT_100230_GENERAL_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_GENERAL_HOUR.newcount
  is '������';
comment on column FACT_100230_GENERAL_HOUR.conncount
  is '������';
comment on column FACT_100230_GENERAL_HOUR.paycount
  is '������';
comment on column FACT_100230_GENERAL_HOUR.payamount
  is '���ѽ��';
comment on column FACT_100230_GENERAL_HOUR.data_source
  is '������Դ';
create index IDX34_100230 on FACT_100230_GENERAL_HOUR (CHANNELID);
create index IDX35_100230 on FACT_100230_GENERAL_HOUR (SERVERID);
create index IDX36_100230 on FACT_100230_GENERAL_HOUR (STATDATE);

prompt
prompt Creating table FACT_100230_GENERAL_HOUR_DVID
prompt ============================================
prompt
create table FACT_100230_GENERAL_HOUR_DVID
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_GENERAL_HOUR_DVID
  is 'Сʱ�豸����������';
comment on column FACT_100230_GENERAL_HOUR_DVID.statdate
  is 'ͳ������';
comment on column FACT_100230_GENERAL_HOUR_DVID.channelid
  is '����';
comment on column FACT_100230_GENERAL_HOUR_DVID.appid
  is '��Ʒid';
comment on column FACT_100230_GENERAL_HOUR_DVID.newcount
  is '������';
comment on column FACT_100230_GENERAL_HOUR_DVID.conncount
  is '������';
comment on column FACT_100230_GENERAL_HOUR_DVID.data_source
  is '������Դ';
create index IDX37_100230 on FACT_100230_GENERAL_HOUR_DVID (CHANNELID);
create index IDX39_100230 on FACT_100230_GENERAL_HOUR_DVID (STATDATE);

prompt
prompt Creating table FACT_100230_GENERAL_LEVEL
prompt ========================================
prompt
create table FACT_100230_GENERAL_LEVEL
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  rolelevel   NUMBER,
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_GENERAL_LEVEL
  is '�û��ȼ�������';
comment on column FACT_100230_GENERAL_LEVEL.statdate
  is 'ͳ������';
comment on column FACT_100230_GENERAL_LEVEL.channelid
  is '����';
comment on column FACT_100230_GENERAL_LEVEL.serverid
  is '����';
comment on column FACT_100230_GENERAL_LEVEL.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100230_GENERAL_LEVEL.appid
  is '��Ʒid';
comment on column FACT_100230_GENERAL_LEVEL.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_GENERAL_LEVEL.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100230_GENERAL_LEVEL.newcount
  is '������';
comment on column FACT_100230_GENERAL_LEVEL.conncount
  is '������';
comment on column FACT_100230_GENERAL_LEVEL.paycount
  is '������';
comment on column FACT_100230_GENERAL_LEVEL.payamount
  is '���ѽ��';
comment on column FACT_100230_GENERAL_LEVEL.data_source
  is '������Դ';
create index IDX40_100230 on FACT_100230_GENERAL_LEVEL (CHANNELID);
create index IDX41_100230 on FACT_100230_GENERAL_LEVEL (SERVERID);
create index IDX42_100230 on FACT_100230_GENERAL_LEVEL (STATDATE);

prompt
prompt Creating table FACT_100230_GENERAL_MONTH
prompt ========================================
prompt
create table FACT_100230_GENERAL_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_GENERAL_MONTH
  is '�»���������';
comment on column FACT_100230_GENERAL_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100230_GENERAL_MONTH.channelid
  is '����';
comment on column FACT_100230_GENERAL_MONTH.serverid
  is '����';
comment on column FACT_100230_GENERAL_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100230_GENERAL_MONTH.appid
  is '��Ʒid';
comment on column FACT_100230_GENERAL_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_GENERAL_MONTH.newcount
  is '������';
comment on column FACT_100230_GENERAL_MONTH.conncount
  is '������';
comment on column FACT_100230_GENERAL_MONTH.paycount
  is '������';
comment on column FACT_100230_GENERAL_MONTH.payamount
  is '���ѽ��';
comment on column FACT_100230_GENERAL_MONTH.data_source
  is '������Դ';
create index IDX43_100230 on FACT_100230_GENERAL_MONTH (CHANNELID);
create index IDX44_100230 on FACT_100230_GENERAL_MONTH (SERVERID);
create index IDX45_100230 on FACT_100230_GENERAL_MONTH (STATDATE);

prompt
prompt Creating table FACT_100230_GENERAL_MONTH_DVID
prompt =============================================
prompt
create table FACT_100230_GENERAL_MONTH_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_GENERAL_MONTH_DVID
  is '���豸����������';
comment on column FACT_100230_GENERAL_MONTH_DVID.statdate
  is 'ͳ������';
comment on column FACT_100230_GENERAL_MONTH_DVID.channelid
  is '����';
comment on column FACT_100230_GENERAL_MONTH_DVID.appid
  is '��Ʒid';
comment on column FACT_100230_GENERAL_MONTH_DVID.newcount
  is '������';
comment on column FACT_100230_GENERAL_MONTH_DVID.conncount
  is '������';
comment on column FACT_100230_GENERAL_MONTH_DVID.data_source
  is '������Դ';
create index IDX46_100230 on FACT_100230_GENERAL_MONTH_DVID (CHANNELID);
create index IDX48_100230 on FACT_100230_GENERAL_MONTH_DVID (STATDATE);

prompt
prompt Creating table FACT_100230_GENERAL_WEEK
prompt =======================================
prompt
create table FACT_100230_GENERAL_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_GENERAL_WEEK
  is '�ܻ���������';
comment on column FACT_100230_GENERAL_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100230_GENERAL_WEEK.channelid
  is '����';
comment on column FACT_100230_GENERAL_WEEK.serverid
  is '����';
comment on column FACT_100230_GENERAL_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100230_GENERAL_WEEK.appid
  is '��Ʒid';
comment on column FACT_100230_GENERAL_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_GENERAL_WEEK.newcount
  is '������';
comment on column FACT_100230_GENERAL_WEEK.conncount
  is '������';
comment on column FACT_100230_GENERAL_WEEK.paycount
  is '������';
comment on column FACT_100230_GENERAL_WEEK.payamount
  is '���ѽ��';
comment on column FACT_100230_GENERAL_WEEK.data_source
  is '������Դ';
create index IDX52_100230 on FACT_100230_GENERAL_WEEK (CHANNELID);
create index IDX53_100230 on FACT_100230_GENERAL_WEEK (SERVERID);
create index IDX54_100230 on FACT_100230_GENERAL_WEEK (STATDATE);

prompt
prompt Creating table FACT_100230_GENERAL_WEEK_DVID
prompt ============================================
prompt
create table FACT_100230_GENERAL_WEEK_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_GENERAL_WEEK_DVID
  is '���豸����������';
comment on column FACT_100230_GENERAL_WEEK_DVID.statdate
  is 'ͳ������';
comment on column FACT_100230_GENERAL_WEEK_DVID.channelid
  is '����';
comment on column FACT_100230_GENERAL_WEEK_DVID.appid
  is '��Ʒid';
comment on column FACT_100230_GENERAL_WEEK_DVID.newcount
  is '������';
comment on column FACT_100230_GENERAL_WEEK_DVID.conncount
  is '������';
comment on column FACT_100230_GENERAL_WEEK_DVID.data_source
  is '������Դ';
create index IDX49_100230 on FACT_100230_GENERAL_WEEK_DVID (CHANNELID);
create index IDX51_100230 on FACT_100230_GENERAL_WEEK_DVID (STATDATE);

prompt
prompt Creating table FACT_100230_HOUR_REPORT
prompt ======================================
prompt
create table FACT_100230_HOUR_REPORT
(
  statdate    VARCHAR2(20),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_HOUR_REPORT
  is '�ձ�Сʱ����';
comment on column FACT_100230_HOUR_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100230_HOUR_REPORT.appid
  is '��ƷID';
comment on column FACT_100230_HOUR_REPORT.channelid
  is '����';
comment on column FACT_100230_HOUR_REPORT.serverid
  is '����';
comment on column FACT_100230_HOUR_REPORT.indexid
  is 'ָ��';
comment on column FACT_100230_HOUR_REPORT.indtype
  is 'ָ������';
comment on column FACT_100230_HOUR_REPORT.rpt_data
  is '����';

prompt
prompt Creating table FACT_100230_LEVELPAY
prompt ===================================
prompt
create table FACT_100230_LEVELPAY
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  datatype       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  rolelevel      NUMBER,
  paycount       NUMBER,
  first_paycount NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100230_LEVELPAY
  is '�û���ɫ�ȼ����ѷ�����';
comment on column FACT_100230_LEVELPAY.statdate
  is 'ͳ������';
comment on column FACT_100230_LEVELPAY.channelid
  is '����';
comment on column FACT_100230_LEVELPAY.serverid
  is '����';
comment on column FACT_100230_LEVELPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100230_LEVELPAY.appid
  is '��Ʒid';
comment on column FACT_100230_LEVELPAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_LEVELPAY.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100230_LEVELPAY.paycount
  is '�����û���';
comment on column FACT_100230_LEVELPAY.first_paycount
  is '���������û������״θ����û���';
comment on column FACT_100230_LEVELPAY.data_source
  is '������Դ';
create index IDX55_100230 on FACT_100230_LEVELPAY (CHANNELID);
create index IDX56_100230 on FACT_100230_LEVELPAY (SERVERID);
create index IDX57_100230 on FACT_100230_LEVELPAY (STATDATE);

prompt
prompt Creating table FACT_100230_LOST_MAC
prompt ===================================
prompt
create table FACT_100230_LOST_MAC
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_LOST_MAC
  is '�豸��ʧ������';
comment on column FACT_100230_LOST_MAC.statdate
  is 'ͳ������';
comment on column FACT_100230_LOST_MAC.lostdate
  is '��ʧ����';
comment on column FACT_100230_LOST_MAC.channelid
  is '����ID';
comment on column FACT_100230_LOST_MAC.serverid
  is '����ID';
comment on column FACT_100230_LOST_MAC.appid
  is '��ƷID';
comment on column FACT_100230_LOST_MAC.rolelevel
  is '��ʧʱ�ȼ�';
comment on column FACT_100230_LOST_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100230_LOST_MAC.lost_conn
  is '��Ծ�豸��ʧ';
comment on column FACT_100230_LOST_MAC.lost_pay
  is '�����豸��ʧ';
comment on column FACT_100230_LOST_MAC.data_source
  is '����Դ';
create index IDX58_100230 on FACT_100230_LOST_MAC (CHANNELID);
create index IDX59_100230 on FACT_100230_LOST_MAC (SERVERID);
create index IDX60_100230 on FACT_100230_LOST_MAC (STATDATE);

prompt
prompt Creating table FACT_100230_LOST_USER
prompt ====================================
prompt
create table FACT_100230_LOST_USER
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_LOST_USER
  is '�û���ʧ������';
comment on column FACT_100230_LOST_USER.statdate
  is 'ͳ������';
comment on column FACT_100230_LOST_USER.lostdate
  is '��ʧ����';
comment on column FACT_100230_LOST_USER.channelid
  is '����ID';
comment on column FACT_100230_LOST_USER.serverid
  is '����ID';
comment on column FACT_100230_LOST_USER.appid
  is '��ƷID';
comment on column FACT_100230_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column FACT_100230_LOST_USER.lost_days
  is '��ʧ����';
comment on column FACT_100230_LOST_USER.lost_conn
  is '��Ծ�û���ʧ';
comment on column FACT_100230_LOST_USER.lost_pay
  is '�����û���ʧ';
comment on column FACT_100230_LOST_USER.data_source
  is '����Դ';
create index IDX61_100230 on FACT_100230_LOST_USER (CHANNELID);
create index IDX62_100230 on FACT_100230_LOST_USER (SERVERID);
create index IDX63_100230 on FACT_100230_LOST_USER (STATDATE);

prompt
prompt Creating table FACT_100230_LTV_MAC
prompt ==================================
prompt
create table FACT_100230_LTV_MAC
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_LTV_MAC
  is '�豸LTV������';
comment on column FACT_100230_LTV_MAC.statdate
  is 'ͳ������';
comment on column FACT_100230_LTV_MAC.ltvdate
  is '��ֵ����';
comment on column FACT_100230_LTV_MAC.channelid
  is '����';
comment on column FACT_100230_LTV_MAC.serverid
  is '����';
comment on column FACT_100230_LTV_MAC.appid
  is '��Ʒid';
comment on column FACT_100230_LTV_MAC.ltv_days
  is 'ltv��';
comment on column FACT_100230_LTV_MAC.payamount
  is '���ѽ��';
comment on column FACT_100230_LTV_MAC.data_source
  is '������Դ';
create index IDX64_100230 on FACT_100230_LTV_MAC (CHANNELID);
create index IDX65_100230 on FACT_100230_LTV_MAC (SERVERID);
create index IDX66_100230 on FACT_100230_LTV_MAC (STATDATE);

prompt
prompt Creating table FACT_100230_LTV_USER
prompt ===================================
prompt
create table FACT_100230_LTV_USER
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_LTV_USER
  is '�û�LTV������';
comment on column FACT_100230_LTV_USER.statdate
  is 'ͳ������';
comment on column FACT_100230_LTV_USER.ltvdate
  is '��ֵ����';
comment on column FACT_100230_LTV_USER.channelid
  is '����';
comment on column FACT_100230_LTV_USER.serverid
  is '����';
comment on column FACT_100230_LTV_USER.appid
  is '��Ʒid';
comment on column FACT_100230_LTV_USER.ltv_days
  is 'ltv��';
comment on column FACT_100230_LTV_USER.payamount
  is '���ѽ��';
comment on column FACT_100230_LTV_USER.data_source
  is '������Դ';
create index IDX67_100230 on FACT_100230_LTV_USER (CHANNELID);
create index IDX68_100230 on FACT_100230_LTV_USER (SERVERID);
create index IDX69_100230 on FACT_100230_LTV_USER (STATDATE);

prompt
prompt Creating table FACT_100230_MISS_FIRST
prompt =====================================
prompt
create table FACT_100230_MISS_FIRST
(
  statdate        VARCHAR2(10),
  channelid       VARCHAR2(50),
  serverid        VARCHAR2(50),
  appid           VARCHAR2(50),
  versionid       VARCHAR2(50),
  missionid       VARCHAR2(50),
  rolelevel       NUMBER,
  rolejob         VARCHAR2(50) default '0',
  firstenter_succ NUMBER,
  firstenter_fail NUMBER,
  loaddate        DATE,
  data_source     VARCHAR2(100)
)
;
comment on table FACT_100230_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column FACT_100230_MISS_FIRST.statdate
  is 'ͳ������';
comment on column FACT_100230_MISS_FIRST.channelid
  is '����';
comment on column FACT_100230_MISS_FIRST.serverid
  is '����';
comment on column FACT_100230_MISS_FIRST.appid
  is '��ƷID';
comment on column FACT_100230_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_MISS_FIRST.missionid
  is '�ؿ�ID';
comment on column FACT_100230_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column FACT_100230_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column FACT_100230_MISS_FIRST.firstenter_succ
  is '��һ�ν���ؿ��ɹ���';
comment on column FACT_100230_MISS_FIRST.firstenter_fail
  is '��һ�ν���ؿ�ʧ����';
comment on column FACT_100230_MISS_FIRST.data_source
  is '������Դ';
create index IDX70_100230 on FACT_100230_MISS_FIRST (CHANNELID);
create index IDX71_100230 on FACT_100230_MISS_FIRST (SERVERID);
create index IDX72_100230 on FACT_100230_MISS_FIRST (STATDATE);

prompt
prompt Creating table FACT_100230_NET
prompt ==============================
prompt
create table FACT_100230_NET
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_net    VARCHAR2(50),
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_NET
  is '������ʽ������';
comment on column FACT_100230_NET.statdate
  is 'ͳ������';
comment on column FACT_100230_NET.channelid
  is '����';
comment on column FACT_100230_NET.serverid
  is '����';
comment on column FACT_100230_NET.appid
  is '��Ʒid';
comment on column FACT_100230_NET.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_NET.dvid_net
  is '������ʽ';
comment on column FACT_100230_NET.conncount
  is '������';
comment on column FACT_100230_NET.data_source
  is '������Դ';
create index IDX73_100230 on FACT_100230_NET (CHANNELID);
create index IDX74_100230 on FACT_100230_NET (SERVERID);
create index IDX75_100230 on FACT_100230_NET (STATDATE);

prompt
prompt Creating table FACT_100230_OPERATOR
prompt ===================================
prompt
create table FACT_100230_OPERATOR
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  dvid_operator VARCHAR2(50),
  conncount     NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100230_OPERATOR
  is '��Ӫ�̷�����';
comment on column FACT_100230_OPERATOR.statdate
  is 'ͳ������';
comment on column FACT_100230_OPERATOR.channelid
  is '����';
comment on column FACT_100230_OPERATOR.serverid
  is '����';
comment on column FACT_100230_OPERATOR.appid
  is '��Ʒid';
comment on column FACT_100230_OPERATOR.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_OPERATOR.dvid_operator
  is '������ʽ';
comment on column FACT_100230_OPERATOR.conncount
  is '������';
comment on column FACT_100230_OPERATOR.data_source
  is '������Դ';
create index IDX76_100230 on FACT_100230_OPERATOR (CHANNELID);
create index IDX77_100230 on FACT_100230_OPERATOR (SERVERID);
create index IDX78_100230 on FACT_100230_OPERATOR (STATDATE);

prompt
prompt Creating table FACT_100230_ORDER
prompt ================================
prompt
create table FACT_100230_ORDER
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100230_ORDER
  is '����������';
comment on column FACT_100230_ORDER.statdate
  is 'ͳ������';
comment on column FACT_100230_ORDER.channelid
  is '����';
comment on column FACT_100230_ORDER.serverid
  is '����';
comment on column FACT_100230_ORDER.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100230_ORDER.appid
  is '��Ʒid';
comment on column FACT_100230_ORDER.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_ORDER.paysucccount
  is '�ɹ�������';
comment on column FACT_100230_ORDER.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100230_ORDER.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100230_ORDER.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100230_ORDER.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100230_ORDER.payfailnum
  is '����ʧ������';
comment on column FACT_100230_ORDER.data_source
  is '������Դ';
create index IDX79_100230 on FACT_100230_ORDER (CHANNELID);
create index IDX80_100230 on FACT_100230_ORDER (SERVERID);
create index IDX81_100230 on FACT_100230_ORDER (STATDATE);

prompt
prompt Creating table FACT_100230_ORDER_HOUR
prompt =====================================
prompt
create table FACT_100230_ORDER_HOUR
(
  statdate      VARCHAR2(20),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100230_ORDER_HOUR
  is '����Сʱ������';
comment on column FACT_100230_ORDER_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100230_ORDER_HOUR.channelid
  is '����';
comment on column FACT_100230_ORDER_HOUR.serverid
  is '����';
comment on column FACT_100230_ORDER_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100230_ORDER_HOUR.appid
  is '��Ʒid';
comment on column FACT_100230_ORDER_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_ORDER_HOUR.paysucccount
  is '�ɹ�������';
comment on column FACT_100230_ORDER_HOUR.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100230_ORDER_HOUR.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100230_ORDER_HOUR.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100230_ORDER_HOUR.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100230_ORDER_HOUR.payfailnum
  is '����ʧ������';
comment on column FACT_100230_ORDER_HOUR.data_source
  is '������Դ';
create index IDX177_100230 on FACT_100230_ORDER_HOUR (CHANNELID);
create index IDX178_100230 on FACT_100230_ORDER_HOUR (SERVERID);
create index IDX179_100230 on FACT_100230_ORDER_HOUR (STATDATE);

prompt
prompt Creating table FACT_100230_ORDER_MONTH
prompt ======================================
prompt
create table FACT_100230_ORDER_MONTH
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100230_ORDER_MONTH
  is '�¶���������';
comment on column FACT_100230_ORDER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100230_ORDER_MONTH.channelid
  is '����';
comment on column FACT_100230_ORDER_MONTH.serverid
  is '����';
comment on column FACT_100230_ORDER_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100230_ORDER_MONTH.appid
  is '��Ʒid';
comment on column FACT_100230_ORDER_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_ORDER_MONTH.paysucccount
  is '�ɹ�������';
comment on column FACT_100230_ORDER_MONTH.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100230_ORDER_MONTH.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100230_ORDER_MONTH.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100230_ORDER_MONTH.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100230_ORDER_MONTH.payfailnum
  is '����ʧ������';
comment on column FACT_100230_ORDER_MONTH.data_source
  is '������Դ';
create index IDX191_100230 on FACT_100230_ORDER_MONTH (CHANNELID);
create index IDX192_100230 on FACT_100230_ORDER_MONTH (SERVERID);
create index IDX193_100230 on FACT_100230_ORDER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100230_ORDER_WEEK
prompt =====================================
prompt
create table FACT_100230_ORDER_WEEK
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100230_ORDER_WEEK
  is '�ܶ���������';
comment on column FACT_100230_ORDER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100230_ORDER_WEEK.channelid
  is '����';
comment on column FACT_100230_ORDER_WEEK.serverid
  is '����';
comment on column FACT_100230_ORDER_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100230_ORDER_WEEK.appid
  is '��Ʒid';
comment on column FACT_100230_ORDER_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_ORDER_WEEK.paysucccount
  is '�ɹ�������';
comment on column FACT_100230_ORDER_WEEK.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100230_ORDER_WEEK.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100230_ORDER_WEEK.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100230_ORDER_WEEK.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100230_ORDER_WEEK.payfailnum
  is '����ʧ������';
comment on column FACT_100230_ORDER_WEEK.data_source
  is '������Դ';
create index IDX188_100230 on FACT_100230_ORDER_WEEK (CHANNELID);
create index IDX189_100230 on FACT_100230_ORDER_WEEK (SERVERID);
create index IDX190_100230 on FACT_100230_ORDER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100230_PAYAMOUNT_DAY
prompt ========================================
prompt
create table FACT_100230_PAYAMOUNT_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_PAYAMOUNT_DAY
  is '�ճ�ֵ��������';
comment on column FACT_100230_PAYAMOUNT_DAY.statdate
  is 'ͳ������';
comment on column FACT_100230_PAYAMOUNT_DAY.channelid
  is '����';
comment on column FACT_100230_PAYAMOUNT_DAY.serverid
  is '����';
comment on column FACT_100230_PAYAMOUNT_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100230_PAYAMOUNT_DAY.appid
  is '��Ʒid';
comment on column FACT_100230_PAYAMOUNT_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_PAYAMOUNT_DAY.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100230_PAYAMOUNT_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100230_PAYAMOUNT_DAY.data_source
  is '������Դ';
create index IDX82_100230 on FACT_100230_PAYAMOUNT_DAY (CHANNELID);
create index IDX83_100230 on FACT_100230_PAYAMOUNT_DAY (SERVERID);
create index IDX84_100230 on FACT_100230_PAYAMOUNT_DAY (STATDATE);

prompt
prompt Creating table FACT_100230_PAYAMOUNT_MONTH
prompt ==========================================
prompt
create table FACT_100230_PAYAMOUNT_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_PAYAMOUNT_MONTH
  is '�³�ֵ��������';
comment on column FACT_100230_PAYAMOUNT_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100230_PAYAMOUNT_MONTH.channelid
  is '����';
comment on column FACT_100230_PAYAMOUNT_MONTH.serverid
  is '����';
comment on column FACT_100230_PAYAMOUNT_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100230_PAYAMOUNT_MONTH.appid
  is '��Ʒid';
comment on column FACT_100230_PAYAMOUNT_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_PAYAMOUNT_MONTH.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100230_PAYAMOUNT_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100230_PAYAMOUNT_MONTH.data_source
  is '������Դ';
create index IDX88_100230 on FACT_100230_PAYAMOUNT_MONTH (CHANNELID);
create index IDX89_100230 on FACT_100230_PAYAMOUNT_MONTH (SERVERID);
create index IDX90_100230 on FACT_100230_PAYAMOUNT_MONTH (STATDATE);

prompt
prompt Creating table FACT_100230_PAYAMOUNT_WEEK
prompt =========================================
prompt
create table FACT_100230_PAYAMOUNT_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_PAYAMOUNT_WEEK
  is '�ܳ�ֵ��������';
comment on column FACT_100230_PAYAMOUNT_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100230_PAYAMOUNT_WEEK.channelid
  is '����';
comment on column FACT_100230_PAYAMOUNT_WEEK.serverid
  is '����';
comment on column FACT_100230_PAYAMOUNT_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100230_PAYAMOUNT_WEEK.appid
  is '��Ʒid';
comment on column FACT_100230_PAYAMOUNT_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_PAYAMOUNT_WEEK.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100230_PAYAMOUNT_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100230_PAYAMOUNT_WEEK.data_source
  is '������Դ';
create index IDX85_100230 on FACT_100230_PAYAMOUNT_WEEK (CHANNELID);
create index IDX86_100230 on FACT_100230_PAYAMOUNT_WEEK (SERVERID);
create index IDX87_100230 on FACT_100230_PAYAMOUNT_WEEK (STATDATE);

prompt
prompt Creating table FACT_100230_PAYNUM_DAY
prompt =====================================
prompt
create table FACT_100230_PAYNUM_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_PAYNUM_DAY
  is '�ճ�ֵ����������';
comment on column FACT_100230_PAYNUM_DAY.statdate
  is 'ͳ������';
comment on column FACT_100230_PAYNUM_DAY.channelid
  is '����';
comment on column FACT_100230_PAYNUM_DAY.serverid
  is '����';
comment on column FACT_100230_PAYNUM_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100230_PAYNUM_DAY.appid
  is '��Ʒid';
comment on column FACT_100230_PAYNUM_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_PAYNUM_DAY.paynum
  is '��ֵ����';
comment on column FACT_100230_PAYNUM_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100230_PAYNUM_DAY.data_source
  is '������Դ';
create index IDX97_100230 on FACT_100230_PAYNUM_DAY (CHANNELID);
create index IDX98_100230 on FACT_100230_PAYNUM_DAY (SERVERID);
create index IDX99_100230 on FACT_100230_PAYNUM_DAY (STATDATE);

prompt
prompt Creating table FACT_100230_PAYNUM_MONTH
prompt =======================================
prompt
create table FACT_100230_PAYNUM_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_PAYNUM_MONTH
  is '�³�ֵ����������';
comment on column FACT_100230_PAYNUM_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100230_PAYNUM_MONTH.channelid
  is '����';
comment on column FACT_100230_PAYNUM_MONTH.serverid
  is '����';
comment on column FACT_100230_PAYNUM_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100230_PAYNUM_MONTH.appid
  is '��Ʒid';
comment on column FACT_100230_PAYNUM_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_PAYNUM_MONTH.paynum
  is '��ֵ����';
comment on column FACT_100230_PAYNUM_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100230_PAYNUM_MONTH.data_source
  is '������Դ';
create index IDX91_100230 on FACT_100230_PAYNUM_MONTH (CHANNELID);
create index IDX92_100230 on FACT_100230_PAYNUM_MONTH (SERVERID);
create index IDX93_100230 on FACT_100230_PAYNUM_MONTH (STATDATE);

prompt
prompt Creating table FACT_100230_PAYNUM_WEEK
prompt ======================================
prompt
create table FACT_100230_PAYNUM_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_PAYNUM_WEEK
  is '�ܳ�ֵ����������';
comment on column FACT_100230_PAYNUM_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100230_PAYNUM_WEEK.channelid
  is '����';
comment on column FACT_100230_PAYNUM_WEEK.serverid
  is '����';
comment on column FACT_100230_PAYNUM_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100230_PAYNUM_WEEK.appid
  is '��Ʒid';
comment on column FACT_100230_PAYNUM_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_PAYNUM_WEEK.paynum
  is '��ֵ����';
comment on column FACT_100230_PAYNUM_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100230_PAYNUM_WEEK.data_source
  is '������Դ';
create index IDX94_100230 on FACT_100230_PAYNUM_WEEK (CHANNELID);
create index IDX95_100230 on FACT_100230_PAYNUM_WEEK (SERVERID);
create index IDX96_100230 on FACT_100230_PAYNUM_WEEK (STATDATE);

prompt
prompt Creating table FACT_100230_PAYTYPE
prompt ==================================
prompt
create table FACT_100230_PAYTYPE
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paytypeid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_PAYTYPE
  is '��ֵ���ͷ�����';
comment on column FACT_100230_PAYTYPE.statdate
  is 'ͳ������';
comment on column FACT_100230_PAYTYPE.channelid
  is '����';
comment on column FACT_100230_PAYTYPE.serverid
  is '����';
comment on column FACT_100230_PAYTYPE.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100230_PAYTYPE.appid
  is '��Ʒid';
comment on column FACT_100230_PAYTYPE.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_PAYTYPE.paytypeid
  is '��ֵ����';
comment on column FACT_100230_PAYTYPE.payamount
  is '��ֵ���';
comment on column FACT_100230_PAYTYPE.paycount
  is '��ֵ����';
comment on column FACT_100230_PAYTYPE.paynum
  is '��ֵ����';
comment on column FACT_100230_PAYTYPE.data_source
  is '������Դ';
create index IDX100_100230 on FACT_100230_PAYTYPE (CHANNELID);
create index IDX101_100230 on FACT_100230_PAYTYPE (SERVERID);
create index IDX102_100230 on FACT_100230_PAYTYPE (STATDATE);

prompt
prompt Creating table FACT_100230_PAYWAY
prompt =================================
prompt
create table FACT_100230_PAYWAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paywayid    VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_PAYWAY
  is '��ֵ��ʽ������';
comment on column FACT_100230_PAYWAY.statdate
  is 'ͳ������';
comment on column FACT_100230_PAYWAY.channelid
  is '����';
comment on column FACT_100230_PAYWAY.serverid
  is '����';
comment on column FACT_100230_PAYWAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100230_PAYWAY.appid
  is '��Ʒid';
comment on column FACT_100230_PAYWAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_PAYWAY.paywayid
  is '��ֵ��ʽ';
comment on column FACT_100230_PAYWAY.payamount
  is '��ֵ���';
comment on column FACT_100230_PAYWAY.paycount
  is '��ֵ����';
comment on column FACT_100230_PAYWAY.paynum
  is '��ֵ����';
comment on column FACT_100230_PAYWAY.data_source
  is '������Դ';
create index IDX103_100230 on FACT_100230_PAYWAY (CHANNELID);
create index IDX104_100230 on FACT_100230_PAYWAY (SERVERID);
create index IDX105_100230 on FACT_100230_PAYWAY (STATDATE);

prompt
prompt Creating table FACT_100230_REGION
prompt =================================
prompt
create table FACT_100230_REGION
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  country     VARCHAR2(50),
  province    VARCHAR2(50),
  city        VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_REGION
  is '���������';
comment on column FACT_100230_REGION.statdate
  is 'ͳ������';
comment on column FACT_100230_REGION.channelid
  is '����';
comment on column FACT_100230_REGION.serverid
  is '����';
comment on column FACT_100230_REGION.appid
  is '��Ʒid';
comment on column FACT_100230_REGION.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_REGION.country
  is '����';
comment on column FACT_100230_REGION.province
  is 'ʡ';
comment on column FACT_100230_REGION.city
  is '��';
comment on column FACT_100230_REGION.newcount
  is '������';
comment on column FACT_100230_REGION.conncount
  is '������';
comment on column FACT_100230_REGION.paycount
  is '������';
comment on column FACT_100230_REGION.payamount
  is '���ѽ��';
comment on column FACT_100230_REGION.data_source
  is '������Դ';
create index IDX106_100230 on FACT_100230_REGION (CHANNELID);
create index IDX107_100230 on FACT_100230_REGION (SERVERID);
create index IDX108_100230 on FACT_100230_REGION (STATDATE);

prompt
prompt Creating table FACT_100230_REMAIN_MAC
prompt =====================================
prompt
create table FACT_100230_REMAIN_MAC
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_REMAIN_MAC
  is '�豸�����';
comment on column FACT_100230_REMAIN_MAC.statdate
  is 'ͳ������';
comment on column FACT_100230_REMAIN_MAC.conndate
  is '��������';
comment on column FACT_100230_REMAIN_MAC.channelid
  is '����ID';
comment on column FACT_100230_REMAIN_MAC.serverid
  is '����ID';
comment on column FACT_100230_REMAIN_MAC.appid
  is '��ƷID';
comment on column FACT_100230_REMAIN_MAC.remain_days
  is '��������';
comment on column FACT_100230_REMAIN_MAC.new_remain
  is '��������';
comment on column FACT_100230_REMAIN_MAC.conn_remain
  is '��������';
comment on column FACT_100230_REMAIN_MAC.pay_remain
  is '��������';
comment on column FACT_100230_REMAIN_MAC.data_source
  is '����Դ';
create index IDX109_100230 on FACT_100230_REMAIN_MAC (CHANNELID);
create index IDX110_100230 on FACT_100230_REMAIN_MAC (SERVERID);
create index IDX111_100230 on FACT_100230_REMAIN_MAC (STATDATE);

prompt
prompt Creating table FACT_100230_REMAIN_USER
prompt ======================================
prompt
create table FACT_100230_REMAIN_USER
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_REMAIN_USER
  is '�û������';
comment on column FACT_100230_REMAIN_USER.statdate
  is 'ͳ������';
comment on column FACT_100230_REMAIN_USER.conndate
  is '��������';
comment on column FACT_100230_REMAIN_USER.channelid
  is '����ID';
comment on column FACT_100230_REMAIN_USER.serverid
  is '����ID';
comment on column FACT_100230_REMAIN_USER.appid
  is '��ƷID';
comment on column FACT_100230_REMAIN_USER.remain_days
  is '��������';
comment on column FACT_100230_REMAIN_USER.new_remain
  is '��������';
comment on column FACT_100230_REMAIN_USER.conn_remain
  is '��������';
comment on column FACT_100230_REMAIN_USER.pay_remain
  is '��������';
comment on column FACT_100230_REMAIN_USER.data_source
  is '����Դ';
create index IDX112_100230 on FACT_100230_REMAIN_USER (CHANNELID);
create index IDX113_100230 on FACT_100230_REMAIN_USER (SERVERID);
create index IDX114_100230 on FACT_100230_REMAIN_USER (STATDATE);

prompt
prompt Creating table FACT_100230_VC
prompt =============================
prompt
create table FACT_100230_VC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcamount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100230_VC
  is '������ҷ�����';
comment on column FACT_100230_VC.statdate
  is 'ͳ������';
comment on column FACT_100230_VC.channelid
  is '����';
comment on column FACT_100230_VC.serverid
  is '����';
comment on column FACT_100230_VC.appid
  is '��Ʒid';
comment on column FACT_100230_VC.versionid
  is '��Ʒ�汾';
comment on column FACT_100230_VC.vctype
  is '�����������';
comment on column FACT_100230_VC.vcusetype
  is '�������ʹ������';
comment on column FACT_100230_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column FACT_100230_VC.vcamount
  is '������ҽ��';
comment on column FACT_100230_VC.data_source
  is '������Դ';
create index IDX115_100230 on FACT_100230_VC (CHANNELID);
create index IDX116_100230 on FACT_100230_VC (SERVERID);
create index IDX117_100230 on FACT_100230_VC (STATDATE);

prompt
prompt Creating table FACT_100231_BACK_MAC
prompt ===================================
prompt
create table FACT_100231_BACK_MAC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_BACK_MAC
  is '�豸����������';
comment on column FACT_100231_BACK_MAC.statdate
  is 'ͳ������';
comment on column FACT_100231_BACK_MAC.channelid
  is '����ID';
comment on column FACT_100231_BACK_MAC.serverid
  is '����ID';
comment on column FACT_100231_BACK_MAC.appid
  is '��ƷID';
comment on column FACT_100231_BACK_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100231_BACK_MAC.back_conn
  is '��Ծ�豸������';
comment on column FACT_100231_BACK_MAC.back_pay
  is '�����豸������';
comment on column FACT_100231_BACK_MAC.data_source
  is '����Դ';
create index IDX1_100231 on FACT_100231_BACK_MAC (CHANNELID);
create index IDX2_100231 on FACT_100231_BACK_MAC (SERVERID);
create index IDX3_100231 on FACT_100231_BACK_MAC (STATDATE);

prompt
prompt Creating table FACT_100231_BACK_MAC_MONTH
prompt =========================================
prompt
create table FACT_100231_BACK_MAC_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_BACK_MAC_MONTH
  is '�豸����������';
comment on column FACT_100231_BACK_MAC_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100231_BACK_MAC_MONTH.channelid
  is '����ID';
comment on column FACT_100231_BACK_MAC_MONTH.serverid
  is '����ID';
comment on column FACT_100231_BACK_MAC_MONTH.appid
  is '��ƷID';
comment on column FACT_100231_BACK_MAC_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100231_BACK_MAC_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100231_BACK_MAC_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100231_BACK_MAC_MONTH.data_source
  is '����Դ';
create index IDX4_100231 on FACT_100231_BACK_MAC_MONTH (CHANNELID);
create index IDX5_100231 on FACT_100231_BACK_MAC_MONTH (SERVERID);
create index IDX6_100231 on FACT_100231_BACK_MAC_MONTH (STATDATE);

prompt
prompt Creating table FACT_100231_BACK_MAC_WEEK
prompt ========================================
prompt
create table FACT_100231_BACK_MAC_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_BACK_MAC_WEEK
  is '�豸����������';
comment on column FACT_100231_BACK_MAC_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100231_BACK_MAC_WEEK.channelid
  is '����ID';
comment on column FACT_100231_BACK_MAC_WEEK.serverid
  is '����ID';
comment on column FACT_100231_BACK_MAC_WEEK.appid
  is '��ƷID';
comment on column FACT_100231_BACK_MAC_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100231_BACK_MAC_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100231_BACK_MAC_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100231_BACK_MAC_WEEK.data_source
  is '����Դ';
create index IDX7_100231 on FACT_100231_BACK_MAC_WEEK (CHANNELID);
create index IDX8_100231 on FACT_100231_BACK_MAC_WEEK (SERVERID);
create index IDX9_100231 on FACT_100231_BACK_MAC_WEEK (STATDATE);

prompt
prompt Creating table FACT_100231_BACK_USER
prompt ====================================
prompt
create table FACT_100231_BACK_USER
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_BACK_USER
  is '�û�����������';
comment on column FACT_100231_BACK_USER.statdate
  is 'ͳ������';
comment on column FACT_100231_BACK_USER.channelid
  is '����ID';
comment on column FACT_100231_BACK_USER.serverid
  is '����ID';
comment on column FACT_100231_BACK_USER.appid
  is '��ƷID';
comment on column FACT_100231_BACK_USER.lost_days
  is '��ʧ����';
comment on column FACT_100231_BACK_USER.back_conn
  is '��Ծ�û�������';
comment on column FACT_100231_BACK_USER.back_pay
  is '�����û�������';
comment on column FACT_100231_BACK_USER.data_source
  is '����Դ';
create index IDX16_100231 on FACT_100231_BACK_USER (CHANNELID);
create index IDX17_100231 on FACT_100231_BACK_USER (SERVERID);
create index IDX18_100231 on FACT_100231_BACK_USER (STATDATE);

prompt
prompt Creating table FACT_100231_BACK_USER_MONTH
prompt ==========================================
prompt
create table FACT_100231_BACK_USER_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_BACK_USER_MONTH
  is '�豸����������';
comment on column FACT_100231_BACK_USER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100231_BACK_USER_MONTH.channelid
  is '����ID';
comment on column FACT_100231_BACK_USER_MONTH.serverid
  is '����ID';
comment on column FACT_100231_BACK_USER_MONTH.appid
  is '��ƷID';
comment on column FACT_100231_BACK_USER_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100231_BACK_USER_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100231_BACK_USER_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100231_BACK_USER_MONTH.data_source
  is '����Դ';
create index IDX13_100231 on FACT_100231_BACK_USER_MONTH (CHANNELID);
create index IDX14_100231 on FACT_100231_BACK_USER_MONTH (SERVERID);
create index IDX15_100231 on FACT_100231_BACK_USER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100231_BACK_USER_WEEK
prompt =========================================
prompt
create table FACT_100231_BACK_USER_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_BACK_USER_WEEK
  is '�豸����������';
comment on column FACT_100231_BACK_USER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100231_BACK_USER_WEEK.channelid
  is '����ID';
comment on column FACT_100231_BACK_USER_WEEK.serverid
  is '����ID';
comment on column FACT_100231_BACK_USER_WEEK.appid
  is '��ƷID';
comment on column FACT_100231_BACK_USER_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100231_BACK_USER_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100231_BACK_USER_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100231_BACK_USER_WEEK.data_source
  is '����Դ';
create index IDX10_100231 on FACT_100231_BACK_USER_WEEK (CHANNELID);
create index IDX11_100231 on FACT_100231_BACK_USER_WEEK (SERVERID);
create index IDX12_100231 on FACT_100231_BACK_USER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100231_CEVENT
prompt =================================
prompt
create table FACT_100231_CEVENT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  eventkey    VARCHAR2(50),
  eventcount  NUMBER,
  eventnum    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_CEVENT
  is '�Զ��������';
comment on column FACT_100231_CEVENT.statdate
  is 'ͳ������';
comment on column FACT_100231_CEVENT.channelid
  is '����';
comment on column FACT_100231_CEVENT.serverid
  is '����';
comment on column FACT_100231_CEVENT.appid
  is '��Ʒid';
comment on column FACT_100231_CEVENT.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100231_CEVENT.eventcount
  is '�¼��û���';
comment on column FACT_100231_CEVENT.eventnum
  is '�¼�����';
comment on column FACT_100231_CEVENT.data_source
  is '������Դ';
create index IDX181_100231 on FACT_100231_CEVENT (CHANNELID);
create index IDX182_100231 on FACT_100231_CEVENT (SERVERID);
create index IDX183_100231 on FACT_100231_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100231_CEVENT_PAR
prompt =====================================
prompt
create table FACT_100231_CEVENT_PAR
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  ilevel         NUMBER,
  eventkey       VARCHAR2(100),
  eventpar_key   VARCHAR2(100),
  eventpar_value VARCHAR2(100),
  eventcount     NUMBER,
  eventnum       NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100231_CEVENT_PAR
  is '�Զ������������';
comment on column FACT_100231_CEVENT_PAR.statdate
  is 'ͳ������';
comment on column FACT_100231_CEVENT_PAR.channelid
  is '����';
comment on column FACT_100231_CEVENT_PAR.serverid
  is '����';
comment on column FACT_100231_CEVENT_PAR.appid
  is '��Ʒid';
comment on column FACT_100231_CEVENT_PAR.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_CEVENT_PAR.ilevel
  is '��ɫ�ȼ�';
comment on column FACT_100231_CEVENT_PAR.eventkey
  is '�¼�����';
comment on column FACT_100231_CEVENT_PAR.eventpar_key
  is '�¼�����';
comment on column FACT_100231_CEVENT_PAR.eventpar_value
  is '�¼�����ֵ';
comment on column FACT_100231_CEVENT_PAR.eventcount
  is '�¼��û���';
comment on column FACT_100231_CEVENT_PAR.eventnum
  is '�¼�����';
comment on column FACT_100231_CEVENT_PAR.data_source
  is '������Դ';
create index IDX185_100231 on FACT_100231_CEVENT_PAR (CHANNELID);
create index IDX186_100231 on FACT_100231_CEVENT_PAR (SERVERID);
create index IDX187_100231 on FACT_100231_CEVENT_PAR (STATDATE);

prompt
prompt Creating table FACT_100231_COMP_CEVENT
prompt ======================================
prompt
create table FACT_100231_COMP_CEVENT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(10),
  channelid   VARCHAR2(50),
  gameversion VARCHAR2(50),
  serverid    VARCHAR2(50),
  ilevel      NUMBER,
  eventkey    VARCHAR2(100),
  compid      VARCHAR2(50),
  caltype     VARCHAR2(50),
  dimpars     VARCHAR2(2000),
  comp_data   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_COMP_CEVENT
  is '�Զ����¼���Ϸ�����';
comment on column FACT_100231_COMP_CEVENT.statdate
  is '����';
comment on column FACT_100231_COMP_CEVENT.appid
  is '��Ϸ�� appid';
comment on column FACT_100231_COMP_CEVENT.channelid
  is '���� ID';
comment on column FACT_100231_COMP_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column FACT_100231_COMP_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column FACT_100231_COMP_CEVENT.ilevel
  is '��ҵȼ�';
comment on column FACT_100231_COMP_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100231_COMP_CEVENT.compid
  is '��ϼ����¼�ID';
comment on column FACT_100231_COMP_CEVENT.caltype
  is '��ϼ����¼���������';
comment on column FACT_100231_COMP_CEVENT.dimpars
  is '��ϲ���';
comment on column FACT_100231_COMP_CEVENT.comp_data
  is '��ϼ�����';
create index IDX184_100231 on FACT_100231_COMP_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100231_DAILY_REPORT
prompt =======================================
prompt
create table FACT_100231_DAILY_REPORT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_DAILY_REPORT
  is '�ձ�����';
comment on column FACT_100231_DAILY_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100231_DAILY_REPORT.appid
  is '��ƷID';
comment on column FACT_100231_DAILY_REPORT.channelid
  is '����';
comment on column FACT_100231_DAILY_REPORT.serverid
  is '����';
comment on column FACT_100231_DAILY_REPORT.indexid
  is 'ָ��';
comment on column FACT_100231_DAILY_REPORT.indtype
  is 'ָ������';
comment on column FACT_100231_DAILY_REPORT.rpt_data
  is '����';
create index IDX176_100231 on FACT_100231_DAILY_REPORT (STATDATE);

prompt
prompt Creating table FACT_100231_DVID
prompt ===============================
prompt
create table FACT_100231_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_model  VARCHAR2(200),
  dvid_res    VARCHAR2(50),
  dvid_os     VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_DVID
  is '�豸������';
comment on column FACT_100231_DVID.statdate
  is 'ͳ������';
comment on column FACT_100231_DVID.channelid
  is '����';
comment on column FACT_100231_DVID.serverid
  is '����';
comment on column FACT_100231_DVID.appid
  is '��Ʒid';
comment on column FACT_100231_DVID.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_DVID.dvid_model
  is '����';
comment on column FACT_100231_DVID.dvid_res
  is '�豸�ֱ���';
comment on column FACT_100231_DVID.dvid_os
  is '�豸����ϵͳ';
comment on column FACT_100231_DVID.newcount
  is '�����û���';
comment on column FACT_100231_DVID.conncount
  is '�����û���';
comment on column FACT_100231_DVID.data_source
  is '������Դ';
create index IDX19_100231 on FACT_100231_DVID (CHANNELID);
create index IDX20_100231 on FACT_100231_DVID (SERVERID);
create index IDX21_100231 on FACT_100231_DVID (STATDATE);

prompt
prompt Creating table FACT_100231_FIRSTPAY
prompt ===================================
prompt
create table FACT_100231_FIRSTPAY
(
  statdate         VARCHAR2(10),
  firstpaydate     VARCHAR2(10),
  channelid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  datatype         VARCHAR2(50),
  appid            VARCHAR2(50),
  first_payfromreg NUMBER,
  first_paycount   NUMBER,
  payamount        NUMBER,
  loaddate         DATE default SYSDATE,
  data_source      VARCHAR2(100)
)
;
comment on table FACT_100231_FIRSTPAY
  is '�����û��״γ�ֵ������';
comment on column FACT_100231_FIRSTPAY.statdate
  is 'ͳ������';
comment on column FACT_100231_FIRSTPAY.firstpaydate
  is '�״θ�������';
comment on column FACT_100231_FIRSTPAY.channelid
  is '����';
comment on column FACT_100231_FIRSTPAY.serverid
  is '����';
comment on column FACT_100231_FIRSTPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100231_FIRSTPAY.appid
  is '��Ʒid';
comment on column FACT_100231_FIRSTPAY.first_payfromreg
  is 'ע���ڼ��쿪ʼ��ֵ(1��2��..7..30..)';
comment on column FACT_100231_FIRSTPAY.first_paycount
  is '���������û���';
comment on column FACT_100231_FIRSTPAY.payamount
  is '�ۼƵ��ڼ���ĳ�ֵ�ܶ�';
comment on column FACT_100231_FIRSTPAY.data_source
  is '������Դ';
create index IDX22_100231 on FACT_100231_FIRSTPAY (CHANNELID);
create index IDX23_100231 on FACT_100231_FIRSTPAY (SERVERID);
create index IDX24_100231 on FACT_100231_FIRSTPAY (STATDATE);

prompt
prompt Creating table FACT_100231_FIRSTPAY_AMOUNT
prompt ==========================================
prompt
create table FACT_100231_FIRSTPAY_AMOUNT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_FIRSTPAY_AMOUNT
  is '�״θ��ѽ�������';
comment on column FACT_100231_FIRSTPAY_AMOUNT.statdate
  is 'ͳ������';
comment on column FACT_100231_FIRSTPAY_AMOUNT.channelid
  is '����';
comment on column FACT_100231_FIRSTPAY_AMOUNT.serverid
  is '��������';
comment on column FACT_100231_FIRSTPAY_AMOUNT.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100231_FIRSTPAY_AMOUNT.appid
  is '��Ʒid';
comment on column FACT_100231_FIRSTPAY_AMOUNT.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_FIRSTPAY_AMOUNT.payamount
  is '�״θ��ѽ��';
comment on column FACT_100231_FIRSTPAY_AMOUNT.paycount
  is '�״θ��ѽ���Ӧ������';
create index IDX25_100231 on FACT_100231_FIRSTPAY_AMOUNT (CHANNELID);
create index IDX26_100231 on FACT_100231_FIRSTPAY_AMOUNT (SERVERID);
create index IDX27_100231 on FACT_100231_FIRSTPAY_AMOUNT (STATDATE);

prompt
prompt Creating table FACT_100231_GENERAL_DAY
prompt ======================================
prompt
create table FACT_100231_GENERAL_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_GENERAL_DAY
  is '�ջ���������';
comment on column FACT_100231_GENERAL_DAY.statdate
  is 'ͳ������';
comment on column FACT_100231_GENERAL_DAY.channelid
  is '����';
comment on column FACT_100231_GENERAL_DAY.serverid
  is '����';
comment on column FACT_100231_GENERAL_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100231_GENERAL_DAY.appid
  is '��Ʒid';
comment on column FACT_100231_GENERAL_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_GENERAL_DAY.newcount
  is '������';
comment on column FACT_100231_GENERAL_DAY.conncount
  is '������';
comment on column FACT_100231_GENERAL_DAY.paycount
  is '������';
comment on column FACT_100231_GENERAL_DAY.payamount
  is '���ѽ��';
comment on column FACT_100231_GENERAL_DAY.data_source
  is '������Դ';
create index IDX28_100231 on FACT_100231_GENERAL_DAY (CHANNELID);
create index IDX29_100231 on FACT_100231_GENERAL_DAY (SERVERID);
create index IDX30_100231 on FACT_100231_GENERAL_DAY (STATDATE);

prompt
prompt Creating table FACT_100231_GENERAL_DAY_DVID
prompt ===========================================
prompt
create table FACT_100231_GENERAL_DAY_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_GENERAL_DAY_DVID
  is '���豸����������';
comment on column FACT_100231_GENERAL_DAY_DVID.statdate
  is 'ͳ������';
comment on column FACT_100231_GENERAL_DAY_DVID.channelid
  is '����';
comment on column FACT_100231_GENERAL_DAY_DVID.appid
  is '��Ʒid';
comment on column FACT_100231_GENERAL_DAY_DVID.newcount
  is '������';
comment on column FACT_100231_GENERAL_DAY_DVID.conncount
  is '������';
comment on column FACT_100231_GENERAL_DAY_DVID.data_source
  is '������Դ';
create index IDX31_100231 on FACT_100231_GENERAL_DAY_DVID (CHANNELID);
create index IDX33_100231 on FACT_100231_GENERAL_DAY_DVID (STATDATE);

prompt
prompt Creating table FACT_100231_GENERAL_HOUR
prompt =======================================
prompt
create table FACT_100231_GENERAL_HOUR
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_GENERAL_HOUR
  is 'Сʱ����������';
comment on column FACT_100231_GENERAL_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100231_GENERAL_HOUR.channelid
  is '����';
comment on column FACT_100231_GENERAL_HOUR.serverid
  is '����';
comment on column FACT_100231_GENERAL_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100231_GENERAL_HOUR.appid
  is '��Ʒid';
comment on column FACT_100231_GENERAL_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_GENERAL_HOUR.newcount
  is '������';
comment on column FACT_100231_GENERAL_HOUR.conncount
  is '������';
comment on column FACT_100231_GENERAL_HOUR.paycount
  is '������';
comment on column FACT_100231_GENERAL_HOUR.payamount
  is '���ѽ��';
comment on column FACT_100231_GENERAL_HOUR.data_source
  is '������Դ';
create index IDX34_100231 on FACT_100231_GENERAL_HOUR (CHANNELID);
create index IDX35_100231 on FACT_100231_GENERAL_HOUR (SERVERID);
create index IDX36_100231 on FACT_100231_GENERAL_HOUR (STATDATE);

prompt
prompt Creating table FACT_100231_GENERAL_HOUR_DVID
prompt ============================================
prompt
create table FACT_100231_GENERAL_HOUR_DVID
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_GENERAL_HOUR_DVID
  is 'Сʱ�豸����������';
comment on column FACT_100231_GENERAL_HOUR_DVID.statdate
  is 'ͳ������';
comment on column FACT_100231_GENERAL_HOUR_DVID.channelid
  is '����';
comment on column FACT_100231_GENERAL_HOUR_DVID.appid
  is '��Ʒid';
comment on column FACT_100231_GENERAL_HOUR_DVID.newcount
  is '������';
comment on column FACT_100231_GENERAL_HOUR_DVID.conncount
  is '������';
comment on column FACT_100231_GENERAL_HOUR_DVID.data_source
  is '������Դ';
create index IDX37_100231 on FACT_100231_GENERAL_HOUR_DVID (CHANNELID);
create index IDX39_100231 on FACT_100231_GENERAL_HOUR_DVID (STATDATE);

prompt
prompt Creating table FACT_100231_GENERAL_LEVEL
prompt ========================================
prompt
create table FACT_100231_GENERAL_LEVEL
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  rolelevel   NUMBER,
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_GENERAL_LEVEL
  is '�û��ȼ�������';
comment on column FACT_100231_GENERAL_LEVEL.statdate
  is 'ͳ������';
comment on column FACT_100231_GENERAL_LEVEL.channelid
  is '����';
comment on column FACT_100231_GENERAL_LEVEL.serverid
  is '����';
comment on column FACT_100231_GENERAL_LEVEL.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100231_GENERAL_LEVEL.appid
  is '��Ʒid';
comment on column FACT_100231_GENERAL_LEVEL.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_GENERAL_LEVEL.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100231_GENERAL_LEVEL.newcount
  is '������';
comment on column FACT_100231_GENERAL_LEVEL.conncount
  is '������';
comment on column FACT_100231_GENERAL_LEVEL.paycount
  is '������';
comment on column FACT_100231_GENERAL_LEVEL.payamount
  is '���ѽ��';
comment on column FACT_100231_GENERAL_LEVEL.data_source
  is '������Դ';
create index IDX40_100231 on FACT_100231_GENERAL_LEVEL (CHANNELID);
create index IDX41_100231 on FACT_100231_GENERAL_LEVEL (SERVERID);
create index IDX42_100231 on FACT_100231_GENERAL_LEVEL (STATDATE);

prompt
prompt Creating table FACT_100231_GENERAL_MONTH
prompt ========================================
prompt
create table FACT_100231_GENERAL_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_GENERAL_MONTH
  is '�»���������';
comment on column FACT_100231_GENERAL_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100231_GENERAL_MONTH.channelid
  is '����';
comment on column FACT_100231_GENERAL_MONTH.serverid
  is '����';
comment on column FACT_100231_GENERAL_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100231_GENERAL_MONTH.appid
  is '��Ʒid';
comment on column FACT_100231_GENERAL_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_GENERAL_MONTH.newcount
  is '������';
comment on column FACT_100231_GENERAL_MONTH.conncount
  is '������';
comment on column FACT_100231_GENERAL_MONTH.paycount
  is '������';
comment on column FACT_100231_GENERAL_MONTH.payamount
  is '���ѽ��';
comment on column FACT_100231_GENERAL_MONTH.data_source
  is '������Դ';
create index IDX43_100231 on FACT_100231_GENERAL_MONTH (CHANNELID);
create index IDX44_100231 on FACT_100231_GENERAL_MONTH (SERVERID);
create index IDX45_100231 on FACT_100231_GENERAL_MONTH (STATDATE);

prompt
prompt Creating table FACT_100231_GENERAL_MONTH_DVID
prompt =============================================
prompt
create table FACT_100231_GENERAL_MONTH_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_GENERAL_MONTH_DVID
  is '���豸����������';
comment on column FACT_100231_GENERAL_MONTH_DVID.statdate
  is 'ͳ������';
comment on column FACT_100231_GENERAL_MONTH_DVID.channelid
  is '����';
comment on column FACT_100231_GENERAL_MONTH_DVID.appid
  is '��Ʒid';
comment on column FACT_100231_GENERAL_MONTH_DVID.newcount
  is '������';
comment on column FACT_100231_GENERAL_MONTH_DVID.conncount
  is '������';
comment on column FACT_100231_GENERAL_MONTH_DVID.data_source
  is '������Դ';
create index IDX46_100231 on FACT_100231_GENERAL_MONTH_DVID (CHANNELID);
create index IDX48_100231 on FACT_100231_GENERAL_MONTH_DVID (STATDATE);

prompt
prompt Creating table FACT_100231_GENERAL_WEEK
prompt =======================================
prompt
create table FACT_100231_GENERAL_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_GENERAL_WEEK
  is '�ܻ���������';
comment on column FACT_100231_GENERAL_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100231_GENERAL_WEEK.channelid
  is '����';
comment on column FACT_100231_GENERAL_WEEK.serverid
  is '����';
comment on column FACT_100231_GENERAL_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100231_GENERAL_WEEK.appid
  is '��Ʒid';
comment on column FACT_100231_GENERAL_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_GENERAL_WEEK.newcount
  is '������';
comment on column FACT_100231_GENERAL_WEEK.conncount
  is '������';
comment on column FACT_100231_GENERAL_WEEK.paycount
  is '������';
comment on column FACT_100231_GENERAL_WEEK.payamount
  is '���ѽ��';
comment on column FACT_100231_GENERAL_WEEK.data_source
  is '������Դ';
create index IDX52_100231 on FACT_100231_GENERAL_WEEK (CHANNELID);
create index IDX53_100231 on FACT_100231_GENERAL_WEEK (SERVERID);
create index IDX54_100231 on FACT_100231_GENERAL_WEEK (STATDATE);

prompt
prompt Creating table FACT_100231_GENERAL_WEEK_DVID
prompt ============================================
prompt
create table FACT_100231_GENERAL_WEEK_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_GENERAL_WEEK_DVID
  is '���豸����������';
comment on column FACT_100231_GENERAL_WEEK_DVID.statdate
  is 'ͳ������';
comment on column FACT_100231_GENERAL_WEEK_DVID.channelid
  is '����';
comment on column FACT_100231_GENERAL_WEEK_DVID.appid
  is '��Ʒid';
comment on column FACT_100231_GENERAL_WEEK_DVID.newcount
  is '������';
comment on column FACT_100231_GENERAL_WEEK_DVID.conncount
  is '������';
comment on column FACT_100231_GENERAL_WEEK_DVID.data_source
  is '������Դ';
create index IDX49_100231 on FACT_100231_GENERAL_WEEK_DVID (CHANNELID);
create index IDX51_100231 on FACT_100231_GENERAL_WEEK_DVID (STATDATE);

prompt
prompt Creating table FACT_100231_HOUR_REPORT
prompt ======================================
prompt
create table FACT_100231_HOUR_REPORT
(
  statdate    VARCHAR2(20),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_HOUR_REPORT
  is '�ձ�Сʱ����';
comment on column FACT_100231_HOUR_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100231_HOUR_REPORT.appid
  is '��ƷID';
comment on column FACT_100231_HOUR_REPORT.channelid
  is '����';
comment on column FACT_100231_HOUR_REPORT.serverid
  is '����';
comment on column FACT_100231_HOUR_REPORT.indexid
  is 'ָ��';
comment on column FACT_100231_HOUR_REPORT.indtype
  is 'ָ������';
comment on column FACT_100231_HOUR_REPORT.rpt_data
  is '����';

prompt
prompt Creating table FACT_100231_LEVELPAY
prompt ===================================
prompt
create table FACT_100231_LEVELPAY
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  datatype       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  rolelevel      NUMBER,
  paycount       NUMBER,
  first_paycount NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100231_LEVELPAY
  is '�û���ɫ�ȼ����ѷ�����';
comment on column FACT_100231_LEVELPAY.statdate
  is 'ͳ������';
comment on column FACT_100231_LEVELPAY.channelid
  is '����';
comment on column FACT_100231_LEVELPAY.serverid
  is '����';
comment on column FACT_100231_LEVELPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100231_LEVELPAY.appid
  is '��Ʒid';
comment on column FACT_100231_LEVELPAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_LEVELPAY.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100231_LEVELPAY.paycount
  is '�����û���';
comment on column FACT_100231_LEVELPAY.first_paycount
  is '���������û������״θ����û���';
comment on column FACT_100231_LEVELPAY.data_source
  is '������Դ';
create index IDX55_100231 on FACT_100231_LEVELPAY (CHANNELID);
create index IDX56_100231 on FACT_100231_LEVELPAY (SERVERID);
create index IDX57_100231 on FACT_100231_LEVELPAY (STATDATE);

prompt
prompt Creating table FACT_100231_LOST_MAC
prompt ===================================
prompt
create table FACT_100231_LOST_MAC
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_LOST_MAC
  is '�豸��ʧ������';
comment on column FACT_100231_LOST_MAC.statdate
  is 'ͳ������';
comment on column FACT_100231_LOST_MAC.lostdate
  is '��ʧ����';
comment on column FACT_100231_LOST_MAC.channelid
  is '����ID';
comment on column FACT_100231_LOST_MAC.serverid
  is '����ID';
comment on column FACT_100231_LOST_MAC.appid
  is '��ƷID';
comment on column FACT_100231_LOST_MAC.rolelevel
  is '��ʧʱ�ȼ�';
comment on column FACT_100231_LOST_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100231_LOST_MAC.lost_conn
  is '��Ծ�豸��ʧ';
comment on column FACT_100231_LOST_MAC.lost_pay
  is '�����豸��ʧ';
comment on column FACT_100231_LOST_MAC.data_source
  is '����Դ';
create index IDX58_100231 on FACT_100231_LOST_MAC (CHANNELID);
create index IDX59_100231 on FACT_100231_LOST_MAC (SERVERID);
create index IDX60_100231 on FACT_100231_LOST_MAC (STATDATE);

prompt
prompt Creating table FACT_100231_LOST_USER
prompt ====================================
prompt
create table FACT_100231_LOST_USER
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_LOST_USER
  is '�û���ʧ������';
comment on column FACT_100231_LOST_USER.statdate
  is 'ͳ������';
comment on column FACT_100231_LOST_USER.lostdate
  is '��ʧ����';
comment on column FACT_100231_LOST_USER.channelid
  is '����ID';
comment on column FACT_100231_LOST_USER.serverid
  is '����ID';
comment on column FACT_100231_LOST_USER.appid
  is '��ƷID';
comment on column FACT_100231_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column FACT_100231_LOST_USER.lost_days
  is '��ʧ����';
comment on column FACT_100231_LOST_USER.lost_conn
  is '��Ծ�û���ʧ';
comment on column FACT_100231_LOST_USER.lost_pay
  is '�����û���ʧ';
comment on column FACT_100231_LOST_USER.data_source
  is '����Դ';
create index IDX61_100231 on FACT_100231_LOST_USER (CHANNELID);
create index IDX62_100231 on FACT_100231_LOST_USER (SERVERID);
create index IDX63_100231 on FACT_100231_LOST_USER (STATDATE);

prompt
prompt Creating table FACT_100231_LTV_MAC
prompt ==================================
prompt
create table FACT_100231_LTV_MAC
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_LTV_MAC
  is '�豸LTV������';
comment on column FACT_100231_LTV_MAC.statdate
  is 'ͳ������';
comment on column FACT_100231_LTV_MAC.ltvdate
  is '��ֵ����';
comment on column FACT_100231_LTV_MAC.channelid
  is '����';
comment on column FACT_100231_LTV_MAC.serverid
  is '����';
comment on column FACT_100231_LTV_MAC.appid
  is '��Ʒid';
comment on column FACT_100231_LTV_MAC.ltv_days
  is 'ltv��';
comment on column FACT_100231_LTV_MAC.payamount
  is '���ѽ��';
comment on column FACT_100231_LTV_MAC.data_source
  is '������Դ';
create index IDX64_100231 on FACT_100231_LTV_MAC (CHANNELID);
create index IDX65_100231 on FACT_100231_LTV_MAC (SERVERID);
create index IDX66_100231 on FACT_100231_LTV_MAC (STATDATE);

prompt
prompt Creating table FACT_100231_LTV_USER
prompt ===================================
prompt
create table FACT_100231_LTV_USER
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_LTV_USER
  is '�û�LTV������';
comment on column FACT_100231_LTV_USER.statdate
  is 'ͳ������';
comment on column FACT_100231_LTV_USER.ltvdate
  is '��ֵ����';
comment on column FACT_100231_LTV_USER.channelid
  is '����';
comment on column FACT_100231_LTV_USER.serverid
  is '����';
comment on column FACT_100231_LTV_USER.appid
  is '��Ʒid';
comment on column FACT_100231_LTV_USER.ltv_days
  is 'ltv��';
comment on column FACT_100231_LTV_USER.payamount
  is '���ѽ��';
comment on column FACT_100231_LTV_USER.data_source
  is '������Դ';
create index IDX67_100231 on FACT_100231_LTV_USER (CHANNELID);
create index IDX68_100231 on FACT_100231_LTV_USER (SERVERID);
create index IDX69_100231 on FACT_100231_LTV_USER (STATDATE);

prompt
prompt Creating table FACT_100231_MISS_FIRST
prompt =====================================
prompt
create table FACT_100231_MISS_FIRST
(
  statdate        VARCHAR2(10),
  channelid       VARCHAR2(50),
  serverid        VARCHAR2(50),
  appid           VARCHAR2(50),
  versionid       VARCHAR2(50),
  missionid       VARCHAR2(50),
  rolelevel       NUMBER,
  rolejob         VARCHAR2(50) default '0',
  firstenter_succ NUMBER,
  firstenter_fail NUMBER,
  loaddate        DATE,
  data_source     VARCHAR2(100)
)
;
comment on table FACT_100231_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column FACT_100231_MISS_FIRST.statdate
  is 'ͳ������';
comment on column FACT_100231_MISS_FIRST.channelid
  is '����';
comment on column FACT_100231_MISS_FIRST.serverid
  is '����';
comment on column FACT_100231_MISS_FIRST.appid
  is '��ƷID';
comment on column FACT_100231_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_MISS_FIRST.missionid
  is '�ؿ�ID';
comment on column FACT_100231_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column FACT_100231_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column FACT_100231_MISS_FIRST.firstenter_succ
  is '��һ�ν���ؿ��ɹ���';
comment on column FACT_100231_MISS_FIRST.firstenter_fail
  is '��һ�ν���ؿ�ʧ����';
comment on column FACT_100231_MISS_FIRST.data_source
  is '������Դ';
create index IDX70_100231 on FACT_100231_MISS_FIRST (CHANNELID);
create index IDX71_100231 on FACT_100231_MISS_FIRST (SERVERID);
create index IDX72_100231 on FACT_100231_MISS_FIRST (STATDATE);

prompt
prompt Creating table FACT_100231_NET
prompt ==============================
prompt
create table FACT_100231_NET
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_net    VARCHAR2(50),
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_NET
  is '������ʽ������';
comment on column FACT_100231_NET.statdate
  is 'ͳ������';
comment on column FACT_100231_NET.channelid
  is '����';
comment on column FACT_100231_NET.serverid
  is '����';
comment on column FACT_100231_NET.appid
  is '��Ʒid';
comment on column FACT_100231_NET.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_NET.dvid_net
  is '������ʽ';
comment on column FACT_100231_NET.conncount
  is '������';
comment on column FACT_100231_NET.data_source
  is '������Դ';
create index IDX73_100231 on FACT_100231_NET (CHANNELID);
create index IDX74_100231 on FACT_100231_NET (SERVERID);
create index IDX75_100231 on FACT_100231_NET (STATDATE);

prompt
prompt Creating table FACT_100231_OPERATOR
prompt ===================================
prompt
create table FACT_100231_OPERATOR
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  dvid_operator VARCHAR2(50),
  conncount     NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100231_OPERATOR
  is '��Ӫ�̷�����';
comment on column FACT_100231_OPERATOR.statdate
  is 'ͳ������';
comment on column FACT_100231_OPERATOR.channelid
  is '����';
comment on column FACT_100231_OPERATOR.serverid
  is '����';
comment on column FACT_100231_OPERATOR.appid
  is '��Ʒid';
comment on column FACT_100231_OPERATOR.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_OPERATOR.dvid_operator
  is '������ʽ';
comment on column FACT_100231_OPERATOR.conncount
  is '������';
comment on column FACT_100231_OPERATOR.data_source
  is '������Դ';
create index IDX76_100231 on FACT_100231_OPERATOR (CHANNELID);
create index IDX77_100231 on FACT_100231_OPERATOR (SERVERID);
create index IDX78_100231 on FACT_100231_OPERATOR (STATDATE);

prompt
prompt Creating table FACT_100231_ORDER
prompt ================================
prompt
create table FACT_100231_ORDER
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100231_ORDER
  is '����������';
comment on column FACT_100231_ORDER.statdate
  is 'ͳ������';
comment on column FACT_100231_ORDER.channelid
  is '����';
comment on column FACT_100231_ORDER.serverid
  is '����';
comment on column FACT_100231_ORDER.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100231_ORDER.appid
  is '��Ʒid';
comment on column FACT_100231_ORDER.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_ORDER.paysucccount
  is '�ɹ�������';
comment on column FACT_100231_ORDER.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100231_ORDER.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100231_ORDER.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100231_ORDER.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100231_ORDER.payfailnum
  is '����ʧ������';
comment on column FACT_100231_ORDER.data_source
  is '������Դ';
create index IDX79_100231 on FACT_100231_ORDER (CHANNELID);
create index IDX80_100231 on FACT_100231_ORDER (SERVERID);
create index IDX81_100231 on FACT_100231_ORDER (STATDATE);

prompt
prompt Creating table FACT_100231_ORDER_HOUR
prompt =====================================
prompt
create table FACT_100231_ORDER_HOUR
(
  statdate      VARCHAR2(20),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100231_ORDER_HOUR
  is '����Сʱ������';
comment on column FACT_100231_ORDER_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100231_ORDER_HOUR.channelid
  is '����';
comment on column FACT_100231_ORDER_HOUR.serverid
  is '����';
comment on column FACT_100231_ORDER_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100231_ORDER_HOUR.appid
  is '��Ʒid';
comment on column FACT_100231_ORDER_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_ORDER_HOUR.paysucccount
  is '�ɹ�������';
comment on column FACT_100231_ORDER_HOUR.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100231_ORDER_HOUR.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100231_ORDER_HOUR.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100231_ORDER_HOUR.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100231_ORDER_HOUR.payfailnum
  is '����ʧ������';
comment on column FACT_100231_ORDER_HOUR.data_source
  is '������Դ';
create index IDX177_100231 on FACT_100231_ORDER_HOUR (CHANNELID);
create index IDX178_100231 on FACT_100231_ORDER_HOUR (SERVERID);
create index IDX179_100231 on FACT_100231_ORDER_HOUR (STATDATE);

prompt
prompt Creating table FACT_100231_ORDER_MONTH
prompt ======================================
prompt
create table FACT_100231_ORDER_MONTH
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100231_ORDER_MONTH
  is '�¶���������';
comment on column FACT_100231_ORDER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100231_ORDER_MONTH.channelid
  is '����';
comment on column FACT_100231_ORDER_MONTH.serverid
  is '����';
comment on column FACT_100231_ORDER_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100231_ORDER_MONTH.appid
  is '��Ʒid';
comment on column FACT_100231_ORDER_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_ORDER_MONTH.paysucccount
  is '�ɹ�������';
comment on column FACT_100231_ORDER_MONTH.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100231_ORDER_MONTH.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100231_ORDER_MONTH.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100231_ORDER_MONTH.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100231_ORDER_MONTH.payfailnum
  is '����ʧ������';
comment on column FACT_100231_ORDER_MONTH.data_source
  is '������Դ';
create index IDX191_100231 on FACT_100231_ORDER_MONTH (CHANNELID);
create index IDX192_100231 on FACT_100231_ORDER_MONTH (SERVERID);
create index IDX193_100231 on FACT_100231_ORDER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100231_ORDER_WEEK
prompt =====================================
prompt
create table FACT_100231_ORDER_WEEK
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100231_ORDER_WEEK
  is '�ܶ���������';
comment on column FACT_100231_ORDER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100231_ORDER_WEEK.channelid
  is '����';
comment on column FACT_100231_ORDER_WEEK.serverid
  is '����';
comment on column FACT_100231_ORDER_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100231_ORDER_WEEK.appid
  is '��Ʒid';
comment on column FACT_100231_ORDER_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_ORDER_WEEK.paysucccount
  is '�ɹ�������';
comment on column FACT_100231_ORDER_WEEK.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100231_ORDER_WEEK.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100231_ORDER_WEEK.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100231_ORDER_WEEK.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100231_ORDER_WEEK.payfailnum
  is '����ʧ������';
comment on column FACT_100231_ORDER_WEEK.data_source
  is '������Դ';
create index IDX188_100231 on FACT_100231_ORDER_WEEK (CHANNELID);
create index IDX189_100231 on FACT_100231_ORDER_WEEK (SERVERID);
create index IDX190_100231 on FACT_100231_ORDER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100231_PAYAMOUNT_DAY
prompt ========================================
prompt
create table FACT_100231_PAYAMOUNT_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_PAYAMOUNT_DAY
  is '�ճ�ֵ��������';
comment on column FACT_100231_PAYAMOUNT_DAY.statdate
  is 'ͳ������';
comment on column FACT_100231_PAYAMOUNT_DAY.channelid
  is '����';
comment on column FACT_100231_PAYAMOUNT_DAY.serverid
  is '����';
comment on column FACT_100231_PAYAMOUNT_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100231_PAYAMOUNT_DAY.appid
  is '��Ʒid';
comment on column FACT_100231_PAYAMOUNT_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_PAYAMOUNT_DAY.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100231_PAYAMOUNT_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100231_PAYAMOUNT_DAY.data_source
  is '������Դ';
create index IDX82_100231 on FACT_100231_PAYAMOUNT_DAY (CHANNELID);
create index IDX83_100231 on FACT_100231_PAYAMOUNT_DAY (SERVERID);
create index IDX84_100231 on FACT_100231_PAYAMOUNT_DAY (STATDATE);

prompt
prompt Creating table FACT_100231_PAYAMOUNT_MONTH
prompt ==========================================
prompt
create table FACT_100231_PAYAMOUNT_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_PAYAMOUNT_MONTH
  is '�³�ֵ��������';
comment on column FACT_100231_PAYAMOUNT_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100231_PAYAMOUNT_MONTH.channelid
  is '����';
comment on column FACT_100231_PAYAMOUNT_MONTH.serverid
  is '����';
comment on column FACT_100231_PAYAMOUNT_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100231_PAYAMOUNT_MONTH.appid
  is '��Ʒid';
comment on column FACT_100231_PAYAMOUNT_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_PAYAMOUNT_MONTH.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100231_PAYAMOUNT_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100231_PAYAMOUNT_MONTH.data_source
  is '������Դ';
create index IDX88_100231 on FACT_100231_PAYAMOUNT_MONTH (CHANNELID);
create index IDX89_100231 on FACT_100231_PAYAMOUNT_MONTH (SERVERID);
create index IDX90_100231 on FACT_100231_PAYAMOUNT_MONTH (STATDATE);

prompt
prompt Creating table FACT_100231_PAYAMOUNT_WEEK
prompt =========================================
prompt
create table FACT_100231_PAYAMOUNT_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_PAYAMOUNT_WEEK
  is '�ܳ�ֵ��������';
comment on column FACT_100231_PAYAMOUNT_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100231_PAYAMOUNT_WEEK.channelid
  is '����';
comment on column FACT_100231_PAYAMOUNT_WEEK.serverid
  is '����';
comment on column FACT_100231_PAYAMOUNT_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100231_PAYAMOUNT_WEEK.appid
  is '��Ʒid';
comment on column FACT_100231_PAYAMOUNT_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_PAYAMOUNT_WEEK.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100231_PAYAMOUNT_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100231_PAYAMOUNT_WEEK.data_source
  is '������Դ';
create index IDX85_100231 on FACT_100231_PAYAMOUNT_WEEK (CHANNELID);
create index IDX86_100231 on FACT_100231_PAYAMOUNT_WEEK (SERVERID);
create index IDX87_100231 on FACT_100231_PAYAMOUNT_WEEK (STATDATE);

prompt
prompt Creating table FACT_100231_PAYNUM_DAY
prompt =====================================
prompt
create table FACT_100231_PAYNUM_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_PAYNUM_DAY
  is '�ճ�ֵ����������';
comment on column FACT_100231_PAYNUM_DAY.statdate
  is 'ͳ������';
comment on column FACT_100231_PAYNUM_DAY.channelid
  is '����';
comment on column FACT_100231_PAYNUM_DAY.serverid
  is '����';
comment on column FACT_100231_PAYNUM_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100231_PAYNUM_DAY.appid
  is '��Ʒid';
comment on column FACT_100231_PAYNUM_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_PAYNUM_DAY.paynum
  is '��ֵ����';
comment on column FACT_100231_PAYNUM_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100231_PAYNUM_DAY.data_source
  is '������Դ';
create index IDX97_100231 on FACT_100231_PAYNUM_DAY (CHANNELID);
create index IDX98_100231 on FACT_100231_PAYNUM_DAY (SERVERID);
create index IDX99_100231 on FACT_100231_PAYNUM_DAY (STATDATE);

prompt
prompt Creating table FACT_100231_PAYNUM_MONTH
prompt =======================================
prompt
create table FACT_100231_PAYNUM_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_PAYNUM_MONTH
  is '�³�ֵ����������';
comment on column FACT_100231_PAYNUM_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100231_PAYNUM_MONTH.channelid
  is '����';
comment on column FACT_100231_PAYNUM_MONTH.serverid
  is '����';
comment on column FACT_100231_PAYNUM_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100231_PAYNUM_MONTH.appid
  is '��Ʒid';
comment on column FACT_100231_PAYNUM_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_PAYNUM_MONTH.paynum
  is '��ֵ����';
comment on column FACT_100231_PAYNUM_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100231_PAYNUM_MONTH.data_source
  is '������Դ';
create index IDX91_100231 on FACT_100231_PAYNUM_MONTH (CHANNELID);
create index IDX92_100231 on FACT_100231_PAYNUM_MONTH (SERVERID);
create index IDX93_100231 on FACT_100231_PAYNUM_MONTH (STATDATE);

prompt
prompt Creating table FACT_100231_PAYNUM_WEEK
prompt ======================================
prompt
create table FACT_100231_PAYNUM_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_PAYNUM_WEEK
  is '�ܳ�ֵ����������';
comment on column FACT_100231_PAYNUM_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100231_PAYNUM_WEEK.channelid
  is '����';
comment on column FACT_100231_PAYNUM_WEEK.serverid
  is '����';
comment on column FACT_100231_PAYNUM_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100231_PAYNUM_WEEK.appid
  is '��Ʒid';
comment on column FACT_100231_PAYNUM_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_PAYNUM_WEEK.paynum
  is '��ֵ����';
comment on column FACT_100231_PAYNUM_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100231_PAYNUM_WEEK.data_source
  is '������Դ';
create index IDX94_100231 on FACT_100231_PAYNUM_WEEK (CHANNELID);
create index IDX95_100231 on FACT_100231_PAYNUM_WEEK (SERVERID);
create index IDX96_100231 on FACT_100231_PAYNUM_WEEK (STATDATE);

prompt
prompt Creating table FACT_100231_PAYTYPE
prompt ==================================
prompt
create table FACT_100231_PAYTYPE
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paytypeid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_PAYTYPE
  is '��ֵ���ͷ�����';
comment on column FACT_100231_PAYTYPE.statdate
  is 'ͳ������';
comment on column FACT_100231_PAYTYPE.channelid
  is '����';
comment on column FACT_100231_PAYTYPE.serverid
  is '����';
comment on column FACT_100231_PAYTYPE.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100231_PAYTYPE.appid
  is '��Ʒid';
comment on column FACT_100231_PAYTYPE.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_PAYTYPE.paytypeid
  is '��ֵ����';
comment on column FACT_100231_PAYTYPE.payamount
  is '��ֵ���';
comment on column FACT_100231_PAYTYPE.paycount
  is '��ֵ����';
comment on column FACT_100231_PAYTYPE.paynum
  is '��ֵ����';
comment on column FACT_100231_PAYTYPE.data_source
  is '������Դ';
create index IDX100_100231 on FACT_100231_PAYTYPE (CHANNELID);
create index IDX101_100231 on FACT_100231_PAYTYPE (SERVERID);
create index IDX102_100231 on FACT_100231_PAYTYPE (STATDATE);

prompt
prompt Creating table FACT_100231_PAYWAY
prompt =================================
prompt
create table FACT_100231_PAYWAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paywayid    VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_PAYWAY
  is '��ֵ��ʽ������';
comment on column FACT_100231_PAYWAY.statdate
  is 'ͳ������';
comment on column FACT_100231_PAYWAY.channelid
  is '����';
comment on column FACT_100231_PAYWAY.serverid
  is '����';
comment on column FACT_100231_PAYWAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100231_PAYWAY.appid
  is '��Ʒid';
comment on column FACT_100231_PAYWAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_PAYWAY.paywayid
  is '��ֵ��ʽ';
comment on column FACT_100231_PAYWAY.payamount
  is '��ֵ���';
comment on column FACT_100231_PAYWAY.paycount
  is '��ֵ����';
comment on column FACT_100231_PAYWAY.paynum
  is '��ֵ����';
comment on column FACT_100231_PAYWAY.data_source
  is '������Դ';
create index IDX103_100231 on FACT_100231_PAYWAY (CHANNELID);
create index IDX104_100231 on FACT_100231_PAYWAY (SERVERID);
create index IDX105_100231 on FACT_100231_PAYWAY (STATDATE);

prompt
prompt Creating table FACT_100231_REGION
prompt =================================
prompt
create table FACT_100231_REGION
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  country     VARCHAR2(50),
  province    VARCHAR2(50),
  city        VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_REGION
  is '���������';
comment on column FACT_100231_REGION.statdate
  is 'ͳ������';
comment on column FACT_100231_REGION.channelid
  is '����';
comment on column FACT_100231_REGION.serverid
  is '����';
comment on column FACT_100231_REGION.appid
  is '��Ʒid';
comment on column FACT_100231_REGION.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_REGION.country
  is '����';
comment on column FACT_100231_REGION.province
  is 'ʡ';
comment on column FACT_100231_REGION.city
  is '��';
comment on column FACT_100231_REGION.newcount
  is '������';
comment on column FACT_100231_REGION.conncount
  is '������';
comment on column FACT_100231_REGION.paycount
  is '������';
comment on column FACT_100231_REGION.payamount
  is '���ѽ��';
comment on column FACT_100231_REGION.data_source
  is '������Դ';
create index IDX106_100231 on FACT_100231_REGION (CHANNELID);
create index IDX107_100231 on FACT_100231_REGION (SERVERID);
create index IDX108_100231 on FACT_100231_REGION (STATDATE);

prompt
prompt Creating table FACT_100231_REMAIN_MAC
prompt =====================================
prompt
create table FACT_100231_REMAIN_MAC
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_REMAIN_MAC
  is '�豸�����';
comment on column FACT_100231_REMAIN_MAC.statdate
  is 'ͳ������';
comment on column FACT_100231_REMAIN_MAC.conndate
  is '��������';
comment on column FACT_100231_REMAIN_MAC.channelid
  is '����ID';
comment on column FACT_100231_REMAIN_MAC.serverid
  is '����ID';
comment on column FACT_100231_REMAIN_MAC.appid
  is '��ƷID';
comment on column FACT_100231_REMAIN_MAC.remain_days
  is '��������';
comment on column FACT_100231_REMAIN_MAC.new_remain
  is '��������';
comment on column FACT_100231_REMAIN_MAC.conn_remain
  is '��������';
comment on column FACT_100231_REMAIN_MAC.pay_remain
  is '��������';
comment on column FACT_100231_REMAIN_MAC.data_source
  is '����Դ';
create index IDX109_100231 on FACT_100231_REMAIN_MAC (CHANNELID);
create index IDX110_100231 on FACT_100231_REMAIN_MAC (SERVERID);
create index IDX111_100231 on FACT_100231_REMAIN_MAC (STATDATE);

prompt
prompt Creating table FACT_100231_REMAIN_USER
prompt ======================================
prompt
create table FACT_100231_REMAIN_USER
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_REMAIN_USER
  is '�û������';
comment on column FACT_100231_REMAIN_USER.statdate
  is 'ͳ������';
comment on column FACT_100231_REMAIN_USER.conndate
  is '��������';
comment on column FACT_100231_REMAIN_USER.channelid
  is '����ID';
comment on column FACT_100231_REMAIN_USER.serverid
  is '����ID';
comment on column FACT_100231_REMAIN_USER.appid
  is '��ƷID';
comment on column FACT_100231_REMAIN_USER.remain_days
  is '��������';
comment on column FACT_100231_REMAIN_USER.new_remain
  is '��������';
comment on column FACT_100231_REMAIN_USER.conn_remain
  is '��������';
comment on column FACT_100231_REMAIN_USER.pay_remain
  is '��������';
comment on column FACT_100231_REMAIN_USER.data_source
  is '����Դ';
create index IDX112_100231 on FACT_100231_REMAIN_USER (CHANNELID);
create index IDX113_100231 on FACT_100231_REMAIN_USER (SERVERID);
create index IDX114_100231 on FACT_100231_REMAIN_USER (STATDATE);

prompt
prompt Creating table FACT_100231_VC
prompt =============================
prompt
create table FACT_100231_VC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcamount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100231_VC
  is '������ҷ�����';
comment on column FACT_100231_VC.statdate
  is 'ͳ������';
comment on column FACT_100231_VC.channelid
  is '����';
comment on column FACT_100231_VC.serverid
  is '����';
comment on column FACT_100231_VC.appid
  is '��Ʒid';
comment on column FACT_100231_VC.versionid
  is '��Ʒ�汾';
comment on column FACT_100231_VC.vctype
  is '�����������';
comment on column FACT_100231_VC.vcusetype
  is '�������ʹ������';
comment on column FACT_100231_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column FACT_100231_VC.vcamount
  is '������ҽ��';
comment on column FACT_100231_VC.data_source
  is '������Դ';
create index IDX115_100231 on FACT_100231_VC (CHANNELID);
create index IDX116_100231 on FACT_100231_VC (SERVERID);
create index IDX117_100231 on FACT_100231_VC (STATDATE);

prompt
prompt Creating table FACT_100241_BACK_MAC
prompt ===================================
prompt
create table FACT_100241_BACK_MAC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_BACK_MAC
  is '�豸����������';
comment on column FACT_100241_BACK_MAC.statdate
  is 'ͳ������';
comment on column FACT_100241_BACK_MAC.channelid
  is '����ID';
comment on column FACT_100241_BACK_MAC.serverid
  is '����ID';
comment on column FACT_100241_BACK_MAC.appid
  is '��ƷID';
comment on column FACT_100241_BACK_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100241_BACK_MAC.back_conn
  is '��Ծ�豸������';
comment on column FACT_100241_BACK_MAC.back_pay
  is '�����豸������';
comment on column FACT_100241_BACK_MAC.data_source
  is '����Դ';
create index IDX1_100241 on FACT_100241_BACK_MAC (CHANNELID);
create index IDX2_100241 on FACT_100241_BACK_MAC (SERVERID);
create index IDX3_100241 on FACT_100241_BACK_MAC (STATDATE);

prompt
prompt Creating table FACT_100241_BACK_MAC_MONTH
prompt =========================================
prompt
create table FACT_100241_BACK_MAC_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_BACK_MAC_MONTH
  is '�豸����������';
comment on column FACT_100241_BACK_MAC_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100241_BACK_MAC_MONTH.channelid
  is '����ID';
comment on column FACT_100241_BACK_MAC_MONTH.serverid
  is '����ID';
comment on column FACT_100241_BACK_MAC_MONTH.appid
  is '��ƷID';
comment on column FACT_100241_BACK_MAC_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100241_BACK_MAC_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100241_BACK_MAC_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100241_BACK_MAC_MONTH.data_source
  is '����Դ';
create index IDX4_100241 on FACT_100241_BACK_MAC_MONTH (CHANNELID);
create index IDX5_100241 on FACT_100241_BACK_MAC_MONTH (SERVERID);
create index IDX6_100241 on FACT_100241_BACK_MAC_MONTH (STATDATE);

prompt
prompt Creating table FACT_100241_BACK_MAC_WEEK
prompt ========================================
prompt
create table FACT_100241_BACK_MAC_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_BACK_MAC_WEEK
  is '�豸����������';
comment on column FACT_100241_BACK_MAC_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100241_BACK_MAC_WEEK.channelid
  is '����ID';
comment on column FACT_100241_BACK_MAC_WEEK.serverid
  is '����ID';
comment on column FACT_100241_BACK_MAC_WEEK.appid
  is '��ƷID';
comment on column FACT_100241_BACK_MAC_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100241_BACK_MAC_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100241_BACK_MAC_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100241_BACK_MAC_WEEK.data_source
  is '����Դ';
create index IDX7_100241 on FACT_100241_BACK_MAC_WEEK (CHANNELID);
create index IDX8_100241 on FACT_100241_BACK_MAC_WEEK (SERVERID);
create index IDX9_100241 on FACT_100241_BACK_MAC_WEEK (STATDATE);

prompt
prompt Creating table FACT_100241_BACK_USER
prompt ====================================
prompt
create table FACT_100241_BACK_USER
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_BACK_USER
  is '�û�����������';
comment on column FACT_100241_BACK_USER.statdate
  is 'ͳ������';
comment on column FACT_100241_BACK_USER.channelid
  is '����ID';
comment on column FACT_100241_BACK_USER.serverid
  is '����ID';
comment on column FACT_100241_BACK_USER.appid
  is '��ƷID';
comment on column FACT_100241_BACK_USER.lost_days
  is '��ʧ����';
comment on column FACT_100241_BACK_USER.back_conn
  is '��Ծ�û�������';
comment on column FACT_100241_BACK_USER.back_pay
  is '�����û�������';
comment on column FACT_100241_BACK_USER.data_source
  is '����Դ';
create index IDX16_100241 on FACT_100241_BACK_USER (CHANNELID);
create index IDX17_100241 on FACT_100241_BACK_USER (SERVERID);
create index IDX18_100241 on FACT_100241_BACK_USER (STATDATE);

prompt
prompt Creating table FACT_100241_BACK_USER_MONTH
prompt ==========================================
prompt
create table FACT_100241_BACK_USER_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_BACK_USER_MONTH
  is '�豸����������';
comment on column FACT_100241_BACK_USER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100241_BACK_USER_MONTH.channelid
  is '����ID';
comment on column FACT_100241_BACK_USER_MONTH.serverid
  is '����ID';
comment on column FACT_100241_BACK_USER_MONTH.appid
  is '��ƷID';
comment on column FACT_100241_BACK_USER_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100241_BACK_USER_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100241_BACK_USER_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100241_BACK_USER_MONTH.data_source
  is '����Դ';
create index IDX13_100241 on FACT_100241_BACK_USER_MONTH (CHANNELID);
create index IDX14_100241 on FACT_100241_BACK_USER_MONTH (SERVERID);
create index IDX15_100241 on FACT_100241_BACK_USER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100241_BACK_USER_WEEK
prompt =========================================
prompt
create table FACT_100241_BACK_USER_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_BACK_USER_WEEK
  is '�豸����������';
comment on column FACT_100241_BACK_USER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100241_BACK_USER_WEEK.channelid
  is '����ID';
comment on column FACT_100241_BACK_USER_WEEK.serverid
  is '����ID';
comment on column FACT_100241_BACK_USER_WEEK.appid
  is '��ƷID';
comment on column FACT_100241_BACK_USER_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100241_BACK_USER_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100241_BACK_USER_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100241_BACK_USER_WEEK.data_source
  is '����Դ';
create index IDX10_100241 on FACT_100241_BACK_USER_WEEK (CHANNELID);
create index IDX11_100241 on FACT_100241_BACK_USER_WEEK (SERVERID);
create index IDX12_100241 on FACT_100241_BACK_USER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100241_CEVENT
prompt =================================
prompt
create table FACT_100241_CEVENT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  eventkey    VARCHAR2(50),
  eventcount  NUMBER,
  eventnum    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_CEVENT
  is '�Զ��������';
comment on column FACT_100241_CEVENT.statdate
  is 'ͳ������';
comment on column FACT_100241_CEVENT.channelid
  is '����';
comment on column FACT_100241_CEVENT.serverid
  is '����';
comment on column FACT_100241_CEVENT.appid
  is '��Ʒid';
comment on column FACT_100241_CEVENT.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100241_CEVENT.eventcount
  is '�¼��û���';
comment on column FACT_100241_CEVENT.eventnum
  is '�¼�����';
comment on column FACT_100241_CEVENT.data_source
  is '������Դ';
create index IDX181_100241 on FACT_100241_CEVENT (CHANNELID);
create index IDX182_100241 on FACT_100241_CEVENT (SERVERID);
create index IDX183_100241 on FACT_100241_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100241_CEVENT_PAR
prompt =====================================
prompt
create table FACT_100241_CEVENT_PAR
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  ilevel         NUMBER,
  eventkey       VARCHAR2(100),
  eventpar_key   VARCHAR2(100),
  eventpar_value VARCHAR2(100),
  eventcount     NUMBER,
  eventnum       NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100241_CEVENT_PAR
  is '�Զ������������';
comment on column FACT_100241_CEVENT_PAR.statdate
  is 'ͳ������';
comment on column FACT_100241_CEVENT_PAR.channelid
  is '����';
comment on column FACT_100241_CEVENT_PAR.serverid
  is '����';
comment on column FACT_100241_CEVENT_PAR.appid
  is '��Ʒid';
comment on column FACT_100241_CEVENT_PAR.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_CEVENT_PAR.ilevel
  is '��ɫ�ȼ�';
comment on column FACT_100241_CEVENT_PAR.eventkey
  is '�¼�����';
comment on column FACT_100241_CEVENT_PAR.eventpar_key
  is '�¼�����';
comment on column FACT_100241_CEVENT_PAR.eventpar_value
  is '�¼�����ֵ';
comment on column FACT_100241_CEVENT_PAR.eventcount
  is '�¼��û���';
comment on column FACT_100241_CEVENT_PAR.eventnum
  is '�¼�����';
comment on column FACT_100241_CEVENT_PAR.data_source
  is '������Դ';
create index IDX185_100241 on FACT_100241_CEVENT_PAR (CHANNELID);
create index IDX186_100241 on FACT_100241_CEVENT_PAR (SERVERID);
create index IDX187_100241 on FACT_100241_CEVENT_PAR (STATDATE);

prompt
prompt Creating table FACT_100241_COMP_CEVENT
prompt ======================================
prompt
create table FACT_100241_COMP_CEVENT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(10),
  channelid   VARCHAR2(50),
  gameversion VARCHAR2(50),
  serverid    VARCHAR2(50),
  ilevel      NUMBER,
  eventkey    VARCHAR2(100),
  compid      VARCHAR2(50),
  caltype     VARCHAR2(50),
  dimpars     VARCHAR2(2000),
  comp_data   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_COMP_CEVENT
  is '�Զ����¼���Ϸ�����';
comment on column FACT_100241_COMP_CEVENT.statdate
  is '����';
comment on column FACT_100241_COMP_CEVENT.appid
  is '��Ϸ�� appid';
comment on column FACT_100241_COMP_CEVENT.channelid
  is '���� ID';
comment on column FACT_100241_COMP_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column FACT_100241_COMP_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column FACT_100241_COMP_CEVENT.ilevel
  is '��ҵȼ�';
comment on column FACT_100241_COMP_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100241_COMP_CEVENT.compid
  is '��ϼ����¼�ID';
comment on column FACT_100241_COMP_CEVENT.caltype
  is '��ϼ����¼���������';
comment on column FACT_100241_COMP_CEVENT.dimpars
  is '��ϲ���';
comment on column FACT_100241_COMP_CEVENT.comp_data
  is '��ϼ�����';
create index IDX184_100241 on FACT_100241_COMP_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100241_DAILY_REPORT
prompt =======================================
prompt
create table FACT_100241_DAILY_REPORT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_DAILY_REPORT
  is '�ձ�����';
comment on column FACT_100241_DAILY_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100241_DAILY_REPORT.appid
  is '��ƷID';
comment on column FACT_100241_DAILY_REPORT.channelid
  is '����';
comment on column FACT_100241_DAILY_REPORT.serverid
  is '����';
comment on column FACT_100241_DAILY_REPORT.indexid
  is 'ָ��';
comment on column FACT_100241_DAILY_REPORT.indtype
  is 'ָ������';
comment on column FACT_100241_DAILY_REPORT.rpt_data
  is '����';
create index IDX176_100241 on FACT_100241_DAILY_REPORT (STATDATE);

prompt
prompt Creating table FACT_100241_DVID
prompt ===============================
prompt
create table FACT_100241_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_model  VARCHAR2(200),
  dvid_res    VARCHAR2(50),
  dvid_os     VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_DVID
  is '�豸������';
comment on column FACT_100241_DVID.statdate
  is 'ͳ������';
comment on column FACT_100241_DVID.channelid
  is '����';
comment on column FACT_100241_DVID.serverid
  is '����';
comment on column FACT_100241_DVID.appid
  is '��Ʒid';
comment on column FACT_100241_DVID.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_DVID.dvid_model
  is '����';
comment on column FACT_100241_DVID.dvid_res
  is '�豸�ֱ���';
comment on column FACT_100241_DVID.dvid_os
  is '�豸����ϵͳ';
comment on column FACT_100241_DVID.newcount
  is '�����û���';
comment on column FACT_100241_DVID.conncount
  is '�����û���';
comment on column FACT_100241_DVID.data_source
  is '������Դ';
create index IDX19_100241 on FACT_100241_DVID (CHANNELID);
create index IDX20_100241 on FACT_100241_DVID (SERVERID);
create index IDX21_100241 on FACT_100241_DVID (STATDATE);

prompt
prompt Creating table FACT_100241_FIRSTPAY
prompt ===================================
prompt
create table FACT_100241_FIRSTPAY
(
  statdate         VARCHAR2(10),
  firstpaydate     VARCHAR2(10),
  channelid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  datatype         VARCHAR2(50),
  appid            VARCHAR2(50),
  first_payfromreg NUMBER,
  first_paycount   NUMBER,
  payamount        NUMBER,
  loaddate         DATE default SYSDATE,
  data_source      VARCHAR2(100)
)
;
comment on table FACT_100241_FIRSTPAY
  is '�����û��״γ�ֵ������';
comment on column FACT_100241_FIRSTPAY.statdate
  is 'ͳ������';
comment on column FACT_100241_FIRSTPAY.firstpaydate
  is '�״θ�������';
comment on column FACT_100241_FIRSTPAY.channelid
  is '����';
comment on column FACT_100241_FIRSTPAY.serverid
  is '����';
comment on column FACT_100241_FIRSTPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100241_FIRSTPAY.appid
  is '��Ʒid';
comment on column FACT_100241_FIRSTPAY.first_payfromreg
  is 'ע���ڼ��쿪ʼ��ֵ(1��2��..7..30..)';
comment on column FACT_100241_FIRSTPAY.first_paycount
  is '���������û���';
comment on column FACT_100241_FIRSTPAY.payamount
  is '�ۼƵ��ڼ���ĳ�ֵ�ܶ�';
comment on column FACT_100241_FIRSTPAY.data_source
  is '������Դ';
create index IDX22_100241 on FACT_100241_FIRSTPAY (CHANNELID);
create index IDX23_100241 on FACT_100241_FIRSTPAY (SERVERID);
create index IDX24_100241 on FACT_100241_FIRSTPAY (STATDATE);

prompt
prompt Creating table FACT_100241_FIRSTPAY_AMOUNT
prompt ==========================================
prompt
create table FACT_100241_FIRSTPAY_AMOUNT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_FIRSTPAY_AMOUNT
  is '�״θ��ѽ�������';
comment on column FACT_100241_FIRSTPAY_AMOUNT.statdate
  is 'ͳ������';
comment on column FACT_100241_FIRSTPAY_AMOUNT.channelid
  is '����';
comment on column FACT_100241_FIRSTPAY_AMOUNT.serverid
  is '��������';
comment on column FACT_100241_FIRSTPAY_AMOUNT.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100241_FIRSTPAY_AMOUNT.appid
  is '��Ʒid';
comment on column FACT_100241_FIRSTPAY_AMOUNT.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_FIRSTPAY_AMOUNT.payamount
  is '�״θ��ѽ��';
comment on column FACT_100241_FIRSTPAY_AMOUNT.paycount
  is '�״θ��ѽ���Ӧ������';
create index IDX25_100241 on FACT_100241_FIRSTPAY_AMOUNT (CHANNELID);
create index IDX26_100241 on FACT_100241_FIRSTPAY_AMOUNT (SERVERID);
create index IDX27_100241 on FACT_100241_FIRSTPAY_AMOUNT (STATDATE);

prompt
prompt Creating table FACT_100241_GENERAL_DAY
prompt ======================================
prompt
create table FACT_100241_GENERAL_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_GENERAL_DAY
  is '�ջ���������';
comment on column FACT_100241_GENERAL_DAY.statdate
  is 'ͳ������';
comment on column FACT_100241_GENERAL_DAY.channelid
  is '����';
comment on column FACT_100241_GENERAL_DAY.serverid
  is '����';
comment on column FACT_100241_GENERAL_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100241_GENERAL_DAY.appid
  is '��Ʒid';
comment on column FACT_100241_GENERAL_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_GENERAL_DAY.newcount
  is '������';
comment on column FACT_100241_GENERAL_DAY.conncount
  is '������';
comment on column FACT_100241_GENERAL_DAY.paycount
  is '������';
comment on column FACT_100241_GENERAL_DAY.payamount
  is '���ѽ��';
comment on column FACT_100241_GENERAL_DAY.data_source
  is '������Դ';
create index IDX28_100241 on FACT_100241_GENERAL_DAY (CHANNELID);
create index IDX29_100241 on FACT_100241_GENERAL_DAY (SERVERID);
create index IDX30_100241 on FACT_100241_GENERAL_DAY (STATDATE);

prompt
prompt Creating table FACT_100241_GENERAL_DAY_DVID
prompt ===========================================
prompt
create table FACT_100241_GENERAL_DAY_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_GENERAL_DAY_DVID
  is '���豸����������';
comment on column FACT_100241_GENERAL_DAY_DVID.statdate
  is 'ͳ������';
comment on column FACT_100241_GENERAL_DAY_DVID.channelid
  is '����';
comment on column FACT_100241_GENERAL_DAY_DVID.appid
  is '��Ʒid';
comment on column FACT_100241_GENERAL_DAY_DVID.newcount
  is '������';
comment on column FACT_100241_GENERAL_DAY_DVID.conncount
  is '������';
comment on column FACT_100241_GENERAL_DAY_DVID.data_source
  is '������Դ';
create index IDX31_100241 on FACT_100241_GENERAL_DAY_DVID (CHANNELID);
create index IDX33_100241 on FACT_100241_GENERAL_DAY_DVID (STATDATE);

prompt
prompt Creating table FACT_100241_GENERAL_HOUR
prompt =======================================
prompt
create table FACT_100241_GENERAL_HOUR
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_GENERAL_HOUR
  is 'Сʱ����������';
comment on column FACT_100241_GENERAL_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100241_GENERAL_HOUR.channelid
  is '����';
comment on column FACT_100241_GENERAL_HOUR.serverid
  is '����';
comment on column FACT_100241_GENERAL_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100241_GENERAL_HOUR.appid
  is '��Ʒid';
comment on column FACT_100241_GENERAL_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_GENERAL_HOUR.newcount
  is '������';
comment on column FACT_100241_GENERAL_HOUR.conncount
  is '������';
comment on column FACT_100241_GENERAL_HOUR.paycount
  is '������';
comment on column FACT_100241_GENERAL_HOUR.payamount
  is '���ѽ��';
comment on column FACT_100241_GENERAL_HOUR.data_source
  is '������Դ';
create index IDX34_100241 on FACT_100241_GENERAL_HOUR (CHANNELID);
create index IDX35_100241 on FACT_100241_GENERAL_HOUR (SERVERID);
create index IDX36_100241 on FACT_100241_GENERAL_HOUR (STATDATE);

prompt
prompt Creating table FACT_100241_GENERAL_HOUR_DVID
prompt ============================================
prompt
create table FACT_100241_GENERAL_HOUR_DVID
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_GENERAL_HOUR_DVID
  is 'Сʱ�豸����������';
comment on column FACT_100241_GENERAL_HOUR_DVID.statdate
  is 'ͳ������';
comment on column FACT_100241_GENERAL_HOUR_DVID.channelid
  is '����';
comment on column FACT_100241_GENERAL_HOUR_DVID.appid
  is '��Ʒid';
comment on column FACT_100241_GENERAL_HOUR_DVID.newcount
  is '������';
comment on column FACT_100241_GENERAL_HOUR_DVID.conncount
  is '������';
comment on column FACT_100241_GENERAL_HOUR_DVID.data_source
  is '������Դ';
create index IDX37_100241 on FACT_100241_GENERAL_HOUR_DVID (CHANNELID);
create index IDX39_100241 on FACT_100241_GENERAL_HOUR_DVID (STATDATE);

prompt
prompt Creating table FACT_100241_GENERAL_LEVEL
prompt ========================================
prompt
create table FACT_100241_GENERAL_LEVEL
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  rolelevel   NUMBER,
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_GENERAL_LEVEL
  is '�û��ȼ�������';
comment on column FACT_100241_GENERAL_LEVEL.statdate
  is 'ͳ������';
comment on column FACT_100241_GENERAL_LEVEL.channelid
  is '����';
comment on column FACT_100241_GENERAL_LEVEL.serverid
  is '����';
comment on column FACT_100241_GENERAL_LEVEL.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100241_GENERAL_LEVEL.appid
  is '��Ʒid';
comment on column FACT_100241_GENERAL_LEVEL.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_GENERAL_LEVEL.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100241_GENERAL_LEVEL.newcount
  is '������';
comment on column FACT_100241_GENERAL_LEVEL.conncount
  is '������';
comment on column FACT_100241_GENERAL_LEVEL.paycount
  is '������';
comment on column FACT_100241_GENERAL_LEVEL.payamount
  is '���ѽ��';
comment on column FACT_100241_GENERAL_LEVEL.data_source
  is '������Դ';
create index IDX40_100241 on FACT_100241_GENERAL_LEVEL (CHANNELID);
create index IDX41_100241 on FACT_100241_GENERAL_LEVEL (SERVERID);
create index IDX42_100241 on FACT_100241_GENERAL_LEVEL (STATDATE);

prompt
prompt Creating table FACT_100241_GENERAL_MONTH
prompt ========================================
prompt
create table FACT_100241_GENERAL_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_GENERAL_MONTH
  is '�»���������';
comment on column FACT_100241_GENERAL_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100241_GENERAL_MONTH.channelid
  is '����';
comment on column FACT_100241_GENERAL_MONTH.serverid
  is '����';
comment on column FACT_100241_GENERAL_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100241_GENERAL_MONTH.appid
  is '��Ʒid';
comment on column FACT_100241_GENERAL_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_GENERAL_MONTH.newcount
  is '������';
comment on column FACT_100241_GENERAL_MONTH.conncount
  is '������';
comment on column FACT_100241_GENERAL_MONTH.paycount
  is '������';
comment on column FACT_100241_GENERAL_MONTH.payamount
  is '���ѽ��';
comment on column FACT_100241_GENERAL_MONTH.data_source
  is '������Դ';
create index IDX43_100241 on FACT_100241_GENERAL_MONTH (CHANNELID);
create index IDX44_100241 on FACT_100241_GENERAL_MONTH (SERVERID);
create index IDX45_100241 on FACT_100241_GENERAL_MONTH (STATDATE);

prompt
prompt Creating table FACT_100241_GENERAL_MONTH_DVID
prompt =============================================
prompt
create table FACT_100241_GENERAL_MONTH_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_GENERAL_MONTH_DVID
  is '���豸����������';
comment on column FACT_100241_GENERAL_MONTH_DVID.statdate
  is 'ͳ������';
comment on column FACT_100241_GENERAL_MONTH_DVID.channelid
  is '����';
comment on column FACT_100241_GENERAL_MONTH_DVID.appid
  is '��Ʒid';
comment on column FACT_100241_GENERAL_MONTH_DVID.newcount
  is '������';
comment on column FACT_100241_GENERAL_MONTH_DVID.conncount
  is '������';
comment on column FACT_100241_GENERAL_MONTH_DVID.data_source
  is '������Դ';
create index IDX46_100241 on FACT_100241_GENERAL_MONTH_DVID (CHANNELID);
create index IDX48_100241 on FACT_100241_GENERAL_MONTH_DVID (STATDATE);

prompt
prompt Creating table FACT_100241_GENERAL_WEEK
prompt =======================================
prompt
create table FACT_100241_GENERAL_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_GENERAL_WEEK
  is '�ܻ���������';
comment on column FACT_100241_GENERAL_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100241_GENERAL_WEEK.channelid
  is '����';
comment on column FACT_100241_GENERAL_WEEK.serverid
  is '����';
comment on column FACT_100241_GENERAL_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100241_GENERAL_WEEK.appid
  is '��Ʒid';
comment on column FACT_100241_GENERAL_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_GENERAL_WEEK.newcount
  is '������';
comment on column FACT_100241_GENERAL_WEEK.conncount
  is '������';
comment on column FACT_100241_GENERAL_WEEK.paycount
  is '������';
comment on column FACT_100241_GENERAL_WEEK.payamount
  is '���ѽ��';
comment on column FACT_100241_GENERAL_WEEK.data_source
  is '������Դ';
create index IDX52_100241 on FACT_100241_GENERAL_WEEK (CHANNELID);
create index IDX53_100241 on FACT_100241_GENERAL_WEEK (SERVERID);
create index IDX54_100241 on FACT_100241_GENERAL_WEEK (STATDATE);

prompt
prompt Creating table FACT_100241_GENERAL_WEEK_DVID
prompt ============================================
prompt
create table FACT_100241_GENERAL_WEEK_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_GENERAL_WEEK_DVID
  is '���豸����������';
comment on column FACT_100241_GENERAL_WEEK_DVID.statdate
  is 'ͳ������';
comment on column FACT_100241_GENERAL_WEEK_DVID.channelid
  is '����';
comment on column FACT_100241_GENERAL_WEEK_DVID.appid
  is '��Ʒid';
comment on column FACT_100241_GENERAL_WEEK_DVID.newcount
  is '������';
comment on column FACT_100241_GENERAL_WEEK_DVID.conncount
  is '������';
comment on column FACT_100241_GENERAL_WEEK_DVID.data_source
  is '������Դ';
create index IDX49_100241 on FACT_100241_GENERAL_WEEK_DVID (CHANNELID);
create index IDX51_100241 on FACT_100241_GENERAL_WEEK_DVID (STATDATE);

prompt
prompt Creating table FACT_100241_HOUR_REPORT
prompt ======================================
prompt
create table FACT_100241_HOUR_REPORT
(
  statdate    VARCHAR2(20),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_HOUR_REPORT
  is '�ձ�Сʱ����';
comment on column FACT_100241_HOUR_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100241_HOUR_REPORT.appid
  is '��ƷID';
comment on column FACT_100241_HOUR_REPORT.channelid
  is '����';
comment on column FACT_100241_HOUR_REPORT.serverid
  is '����';
comment on column FACT_100241_HOUR_REPORT.indexid
  is 'ָ��';
comment on column FACT_100241_HOUR_REPORT.indtype
  is 'ָ������';
comment on column FACT_100241_HOUR_REPORT.rpt_data
  is '����';

prompt
prompt Creating table FACT_100241_LEVELPAY
prompt ===================================
prompt
create table FACT_100241_LEVELPAY
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  datatype       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  rolelevel      NUMBER,
  paycount       NUMBER,
  first_paycount NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100241_LEVELPAY
  is '�û���ɫ�ȼ����ѷ�����';
comment on column FACT_100241_LEVELPAY.statdate
  is 'ͳ������';
comment on column FACT_100241_LEVELPAY.channelid
  is '����';
comment on column FACT_100241_LEVELPAY.serverid
  is '����';
comment on column FACT_100241_LEVELPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100241_LEVELPAY.appid
  is '��Ʒid';
comment on column FACT_100241_LEVELPAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_LEVELPAY.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100241_LEVELPAY.paycount
  is '�����û���';
comment on column FACT_100241_LEVELPAY.first_paycount
  is '���������û������״θ����û���';
comment on column FACT_100241_LEVELPAY.data_source
  is '������Դ';
create index IDX55_100241 on FACT_100241_LEVELPAY (CHANNELID);
create index IDX56_100241 on FACT_100241_LEVELPAY (SERVERID);
create index IDX57_100241 on FACT_100241_LEVELPAY (STATDATE);

prompt
prompt Creating table FACT_100241_LOST_MAC
prompt ===================================
prompt
create table FACT_100241_LOST_MAC
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_LOST_MAC
  is '�豸��ʧ������';
comment on column FACT_100241_LOST_MAC.statdate
  is 'ͳ������';
comment on column FACT_100241_LOST_MAC.lostdate
  is '��ʧ����';
comment on column FACT_100241_LOST_MAC.channelid
  is '����ID';
comment on column FACT_100241_LOST_MAC.serverid
  is '����ID';
comment on column FACT_100241_LOST_MAC.appid
  is '��ƷID';
comment on column FACT_100241_LOST_MAC.rolelevel
  is '��ʧʱ�ȼ�';
comment on column FACT_100241_LOST_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100241_LOST_MAC.lost_conn
  is '��Ծ�豸��ʧ';
comment on column FACT_100241_LOST_MAC.lost_pay
  is '�����豸��ʧ';
comment on column FACT_100241_LOST_MAC.data_source
  is '����Դ';
create index IDX58_100241 on FACT_100241_LOST_MAC (CHANNELID);
create index IDX59_100241 on FACT_100241_LOST_MAC (SERVERID);
create index IDX60_100241 on FACT_100241_LOST_MAC (STATDATE);

prompt
prompt Creating table FACT_100241_LOST_USER
prompt ====================================
prompt
create table FACT_100241_LOST_USER
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_LOST_USER
  is '�û���ʧ������';
comment on column FACT_100241_LOST_USER.statdate
  is 'ͳ������';
comment on column FACT_100241_LOST_USER.lostdate
  is '��ʧ����';
comment on column FACT_100241_LOST_USER.channelid
  is '����ID';
comment on column FACT_100241_LOST_USER.serverid
  is '����ID';
comment on column FACT_100241_LOST_USER.appid
  is '��ƷID';
comment on column FACT_100241_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column FACT_100241_LOST_USER.lost_days
  is '��ʧ����';
comment on column FACT_100241_LOST_USER.lost_conn
  is '��Ծ�û���ʧ';
comment on column FACT_100241_LOST_USER.lost_pay
  is '�����û���ʧ';
comment on column FACT_100241_LOST_USER.data_source
  is '����Դ';
create index IDX61_100241 on FACT_100241_LOST_USER (CHANNELID);
create index IDX62_100241 on FACT_100241_LOST_USER (SERVERID);
create index IDX63_100241 on FACT_100241_LOST_USER (STATDATE);

prompt
prompt Creating table FACT_100241_LTV_MAC
prompt ==================================
prompt
create table FACT_100241_LTV_MAC
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_LTV_MAC
  is '�豸LTV������';
comment on column FACT_100241_LTV_MAC.statdate
  is 'ͳ������';
comment on column FACT_100241_LTV_MAC.ltvdate
  is '��ֵ����';
comment on column FACT_100241_LTV_MAC.channelid
  is '����';
comment on column FACT_100241_LTV_MAC.serverid
  is '����';
comment on column FACT_100241_LTV_MAC.appid
  is '��Ʒid';
comment on column FACT_100241_LTV_MAC.ltv_days
  is 'ltv��';
comment on column FACT_100241_LTV_MAC.payamount
  is '���ѽ��';
comment on column FACT_100241_LTV_MAC.data_source
  is '������Դ';
create index IDX64_100241 on FACT_100241_LTV_MAC (CHANNELID);
create index IDX65_100241 on FACT_100241_LTV_MAC (SERVERID);
create index IDX66_100241 on FACT_100241_LTV_MAC (STATDATE);

prompt
prompt Creating table FACT_100241_LTV_USER
prompt ===================================
prompt
create table FACT_100241_LTV_USER
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_LTV_USER
  is '�û�LTV������';
comment on column FACT_100241_LTV_USER.statdate
  is 'ͳ������';
comment on column FACT_100241_LTV_USER.ltvdate
  is '��ֵ����';
comment on column FACT_100241_LTV_USER.channelid
  is '����';
comment on column FACT_100241_LTV_USER.serverid
  is '����';
comment on column FACT_100241_LTV_USER.appid
  is '��Ʒid';
comment on column FACT_100241_LTV_USER.ltv_days
  is 'ltv��';
comment on column FACT_100241_LTV_USER.payamount
  is '���ѽ��';
comment on column FACT_100241_LTV_USER.data_source
  is '������Դ';
create index IDX67_100241 on FACT_100241_LTV_USER (CHANNELID);
create index IDX68_100241 on FACT_100241_LTV_USER (SERVERID);
create index IDX69_100241 on FACT_100241_LTV_USER (STATDATE);

prompt
prompt Creating table FACT_100241_MISS_FIRST
prompt =====================================
prompt
create table FACT_100241_MISS_FIRST
(
  statdate        VARCHAR2(10),
  channelid       VARCHAR2(50),
  serverid        VARCHAR2(50),
  appid           VARCHAR2(50),
  versionid       VARCHAR2(50),
  missionid       VARCHAR2(50),
  rolelevel       NUMBER,
  rolejob         VARCHAR2(50) default '0',
  firstenter_succ NUMBER,
  firstenter_fail NUMBER,
  loaddate        DATE,
  data_source     VARCHAR2(100)
)
;
comment on table FACT_100241_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column FACT_100241_MISS_FIRST.statdate
  is 'ͳ������';
comment on column FACT_100241_MISS_FIRST.channelid
  is '����';
comment on column FACT_100241_MISS_FIRST.serverid
  is '����';
comment on column FACT_100241_MISS_FIRST.appid
  is '��ƷID';
comment on column FACT_100241_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_MISS_FIRST.missionid
  is '�ؿ�ID';
comment on column FACT_100241_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column FACT_100241_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column FACT_100241_MISS_FIRST.firstenter_succ
  is '��һ�ν���ؿ��ɹ���';
comment on column FACT_100241_MISS_FIRST.firstenter_fail
  is '��һ�ν���ؿ�ʧ����';
comment on column FACT_100241_MISS_FIRST.data_source
  is '������Դ';
create index IDX70_100241 on FACT_100241_MISS_FIRST (CHANNELID);
create index IDX71_100241 on FACT_100241_MISS_FIRST (SERVERID);
create index IDX72_100241 on FACT_100241_MISS_FIRST (STATDATE);

prompt
prompt Creating table FACT_100241_NET
prompt ==============================
prompt
create table FACT_100241_NET
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_net    VARCHAR2(50),
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_NET
  is '������ʽ������';
comment on column FACT_100241_NET.statdate
  is 'ͳ������';
comment on column FACT_100241_NET.channelid
  is '����';
comment on column FACT_100241_NET.serverid
  is '����';
comment on column FACT_100241_NET.appid
  is '��Ʒid';
comment on column FACT_100241_NET.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_NET.dvid_net
  is '������ʽ';
comment on column FACT_100241_NET.conncount
  is '������';
comment on column FACT_100241_NET.data_source
  is '������Դ';
create index IDX73_100241 on FACT_100241_NET (CHANNELID);
create index IDX74_100241 on FACT_100241_NET (SERVERID);
create index IDX75_100241 on FACT_100241_NET (STATDATE);

prompt
prompt Creating table FACT_100241_OPERATOR
prompt ===================================
prompt
create table FACT_100241_OPERATOR
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  dvid_operator VARCHAR2(50),
  conncount     NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100241_OPERATOR
  is '��Ӫ�̷�����';
comment on column FACT_100241_OPERATOR.statdate
  is 'ͳ������';
comment on column FACT_100241_OPERATOR.channelid
  is '����';
comment on column FACT_100241_OPERATOR.serverid
  is '����';
comment on column FACT_100241_OPERATOR.appid
  is '��Ʒid';
comment on column FACT_100241_OPERATOR.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_OPERATOR.dvid_operator
  is '������ʽ';
comment on column FACT_100241_OPERATOR.conncount
  is '������';
comment on column FACT_100241_OPERATOR.data_source
  is '������Դ';
create index IDX76_100241 on FACT_100241_OPERATOR (CHANNELID);
create index IDX77_100241 on FACT_100241_OPERATOR (SERVERID);
create index IDX78_100241 on FACT_100241_OPERATOR (STATDATE);

prompt
prompt Creating table FACT_100241_ORDER
prompt ================================
prompt
create table FACT_100241_ORDER
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100241_ORDER
  is '����������';
comment on column FACT_100241_ORDER.statdate
  is 'ͳ������';
comment on column FACT_100241_ORDER.channelid
  is '����';
comment on column FACT_100241_ORDER.serverid
  is '����';
comment on column FACT_100241_ORDER.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100241_ORDER.appid
  is '��Ʒid';
comment on column FACT_100241_ORDER.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_ORDER.paysucccount
  is '�ɹ�������';
comment on column FACT_100241_ORDER.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100241_ORDER.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100241_ORDER.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100241_ORDER.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100241_ORDER.payfailnum
  is '����ʧ������';
comment on column FACT_100241_ORDER.data_source
  is '������Դ';
create index IDX79_100241 on FACT_100241_ORDER (CHANNELID);
create index IDX80_100241 on FACT_100241_ORDER (SERVERID);
create index IDX81_100241 on FACT_100241_ORDER (STATDATE);

prompt
prompt Creating table FACT_100241_ORDER_HOUR
prompt =====================================
prompt
create table FACT_100241_ORDER_HOUR
(
  statdate      VARCHAR2(20),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100241_ORDER_HOUR
  is '����Сʱ������';
comment on column FACT_100241_ORDER_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100241_ORDER_HOUR.channelid
  is '����';
comment on column FACT_100241_ORDER_HOUR.serverid
  is '����';
comment on column FACT_100241_ORDER_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100241_ORDER_HOUR.appid
  is '��Ʒid';
comment on column FACT_100241_ORDER_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_ORDER_HOUR.paysucccount
  is '�ɹ�������';
comment on column FACT_100241_ORDER_HOUR.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100241_ORDER_HOUR.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100241_ORDER_HOUR.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100241_ORDER_HOUR.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100241_ORDER_HOUR.payfailnum
  is '����ʧ������';
comment on column FACT_100241_ORDER_HOUR.data_source
  is '������Դ';
create index IDX177_100241 on FACT_100241_ORDER_HOUR (CHANNELID);
create index IDX178_100241 on FACT_100241_ORDER_HOUR (SERVERID);
create index IDX179_100241 on FACT_100241_ORDER_HOUR (STATDATE);

prompt
prompt Creating table FACT_100241_ORDER_MONTH
prompt ======================================
prompt
create table FACT_100241_ORDER_MONTH
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100241_ORDER_MONTH
  is '�¶���������';
comment on column FACT_100241_ORDER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100241_ORDER_MONTH.channelid
  is '����';
comment on column FACT_100241_ORDER_MONTH.serverid
  is '����';
comment on column FACT_100241_ORDER_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100241_ORDER_MONTH.appid
  is '��Ʒid';
comment on column FACT_100241_ORDER_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_ORDER_MONTH.paysucccount
  is '�ɹ�������';
comment on column FACT_100241_ORDER_MONTH.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100241_ORDER_MONTH.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100241_ORDER_MONTH.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100241_ORDER_MONTH.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100241_ORDER_MONTH.payfailnum
  is '����ʧ������';
comment on column FACT_100241_ORDER_MONTH.data_source
  is '������Դ';
create index IDX191_100241 on FACT_100241_ORDER_MONTH (CHANNELID);
create index IDX192_100241 on FACT_100241_ORDER_MONTH (SERVERID);
create index IDX193_100241 on FACT_100241_ORDER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100241_ORDER_WEEK
prompt =====================================
prompt
create table FACT_100241_ORDER_WEEK
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100241_ORDER_WEEK
  is '�ܶ���������';
comment on column FACT_100241_ORDER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100241_ORDER_WEEK.channelid
  is '����';
comment on column FACT_100241_ORDER_WEEK.serverid
  is '����';
comment on column FACT_100241_ORDER_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100241_ORDER_WEEK.appid
  is '��Ʒid';
comment on column FACT_100241_ORDER_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_ORDER_WEEK.paysucccount
  is '�ɹ�������';
comment on column FACT_100241_ORDER_WEEK.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100241_ORDER_WEEK.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100241_ORDER_WEEK.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100241_ORDER_WEEK.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100241_ORDER_WEEK.payfailnum
  is '����ʧ������';
comment on column FACT_100241_ORDER_WEEK.data_source
  is '������Դ';
create index IDX188_100241 on FACT_100241_ORDER_WEEK (CHANNELID);
create index IDX189_100241 on FACT_100241_ORDER_WEEK (SERVERID);
create index IDX190_100241 on FACT_100241_ORDER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100241_PAYAMOUNT_DAY
prompt ========================================
prompt
create table FACT_100241_PAYAMOUNT_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_PAYAMOUNT_DAY
  is '�ճ�ֵ��������';
comment on column FACT_100241_PAYAMOUNT_DAY.statdate
  is 'ͳ������';
comment on column FACT_100241_PAYAMOUNT_DAY.channelid
  is '����';
comment on column FACT_100241_PAYAMOUNT_DAY.serverid
  is '����';
comment on column FACT_100241_PAYAMOUNT_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100241_PAYAMOUNT_DAY.appid
  is '��Ʒid';
comment on column FACT_100241_PAYAMOUNT_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_PAYAMOUNT_DAY.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100241_PAYAMOUNT_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100241_PAYAMOUNT_DAY.data_source
  is '������Դ';
create index IDX82_100241 on FACT_100241_PAYAMOUNT_DAY (CHANNELID);
create index IDX83_100241 on FACT_100241_PAYAMOUNT_DAY (SERVERID);
create index IDX84_100241 on FACT_100241_PAYAMOUNT_DAY (STATDATE);

prompt
prompt Creating table FACT_100241_PAYAMOUNT_MONTH
prompt ==========================================
prompt
create table FACT_100241_PAYAMOUNT_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_PAYAMOUNT_MONTH
  is '�³�ֵ��������';
comment on column FACT_100241_PAYAMOUNT_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100241_PAYAMOUNT_MONTH.channelid
  is '����';
comment on column FACT_100241_PAYAMOUNT_MONTH.serverid
  is '����';
comment on column FACT_100241_PAYAMOUNT_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100241_PAYAMOUNT_MONTH.appid
  is '��Ʒid';
comment on column FACT_100241_PAYAMOUNT_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_PAYAMOUNT_MONTH.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100241_PAYAMOUNT_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100241_PAYAMOUNT_MONTH.data_source
  is '������Դ';
create index IDX88_100241 on FACT_100241_PAYAMOUNT_MONTH (CHANNELID);
create index IDX89_100241 on FACT_100241_PAYAMOUNT_MONTH (SERVERID);
create index IDX90_100241 on FACT_100241_PAYAMOUNT_MONTH (STATDATE);

prompt
prompt Creating table FACT_100241_PAYAMOUNT_WEEK
prompt =========================================
prompt
create table FACT_100241_PAYAMOUNT_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_PAYAMOUNT_WEEK
  is '�ܳ�ֵ��������';
comment on column FACT_100241_PAYAMOUNT_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100241_PAYAMOUNT_WEEK.channelid
  is '����';
comment on column FACT_100241_PAYAMOUNT_WEEK.serverid
  is '����';
comment on column FACT_100241_PAYAMOUNT_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100241_PAYAMOUNT_WEEK.appid
  is '��Ʒid';
comment on column FACT_100241_PAYAMOUNT_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_PAYAMOUNT_WEEK.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100241_PAYAMOUNT_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100241_PAYAMOUNT_WEEK.data_source
  is '������Դ';
create index IDX85_100241 on FACT_100241_PAYAMOUNT_WEEK (CHANNELID);
create index IDX86_100241 on FACT_100241_PAYAMOUNT_WEEK (SERVERID);
create index IDX87_100241 on FACT_100241_PAYAMOUNT_WEEK (STATDATE);

prompt
prompt Creating table FACT_100241_PAYNUM_DAY
prompt =====================================
prompt
create table FACT_100241_PAYNUM_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_PAYNUM_DAY
  is '�ճ�ֵ����������';
comment on column FACT_100241_PAYNUM_DAY.statdate
  is 'ͳ������';
comment on column FACT_100241_PAYNUM_DAY.channelid
  is '����';
comment on column FACT_100241_PAYNUM_DAY.serverid
  is '����';
comment on column FACT_100241_PAYNUM_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100241_PAYNUM_DAY.appid
  is '��Ʒid';
comment on column FACT_100241_PAYNUM_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_PAYNUM_DAY.paynum
  is '��ֵ����';
comment on column FACT_100241_PAYNUM_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100241_PAYNUM_DAY.data_source
  is '������Դ';
create index IDX97_100241 on FACT_100241_PAYNUM_DAY (CHANNELID);
create index IDX98_100241 on FACT_100241_PAYNUM_DAY (SERVERID);
create index IDX99_100241 on FACT_100241_PAYNUM_DAY (STATDATE);

prompt
prompt Creating table FACT_100241_PAYNUM_MONTH
prompt =======================================
prompt
create table FACT_100241_PAYNUM_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_PAYNUM_MONTH
  is '�³�ֵ����������';
comment on column FACT_100241_PAYNUM_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100241_PAYNUM_MONTH.channelid
  is '����';
comment on column FACT_100241_PAYNUM_MONTH.serverid
  is '����';
comment on column FACT_100241_PAYNUM_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100241_PAYNUM_MONTH.appid
  is '��Ʒid';
comment on column FACT_100241_PAYNUM_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_PAYNUM_MONTH.paynum
  is '��ֵ����';
comment on column FACT_100241_PAYNUM_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100241_PAYNUM_MONTH.data_source
  is '������Դ';
create index IDX91_100241 on FACT_100241_PAYNUM_MONTH (CHANNELID);
create index IDX92_100241 on FACT_100241_PAYNUM_MONTH (SERVERID);
create index IDX93_100241 on FACT_100241_PAYNUM_MONTH (STATDATE);

prompt
prompt Creating table FACT_100241_PAYNUM_WEEK
prompt ======================================
prompt
create table FACT_100241_PAYNUM_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_PAYNUM_WEEK
  is '�ܳ�ֵ����������';
comment on column FACT_100241_PAYNUM_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100241_PAYNUM_WEEK.channelid
  is '����';
comment on column FACT_100241_PAYNUM_WEEK.serverid
  is '����';
comment on column FACT_100241_PAYNUM_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100241_PAYNUM_WEEK.appid
  is '��Ʒid';
comment on column FACT_100241_PAYNUM_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_PAYNUM_WEEK.paynum
  is '��ֵ����';
comment on column FACT_100241_PAYNUM_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100241_PAYNUM_WEEK.data_source
  is '������Դ';
create index IDX94_100241 on FACT_100241_PAYNUM_WEEK (CHANNELID);
create index IDX95_100241 on FACT_100241_PAYNUM_WEEK (SERVERID);
create index IDX96_100241 on FACT_100241_PAYNUM_WEEK (STATDATE);

prompt
prompt Creating table FACT_100241_PAYTYPE
prompt ==================================
prompt
create table FACT_100241_PAYTYPE
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paytypeid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_PAYTYPE
  is '��ֵ���ͷ�����';
comment on column FACT_100241_PAYTYPE.statdate
  is 'ͳ������';
comment on column FACT_100241_PAYTYPE.channelid
  is '����';
comment on column FACT_100241_PAYTYPE.serverid
  is '����';
comment on column FACT_100241_PAYTYPE.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100241_PAYTYPE.appid
  is '��Ʒid';
comment on column FACT_100241_PAYTYPE.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_PAYTYPE.paytypeid
  is '��ֵ����';
comment on column FACT_100241_PAYTYPE.payamount
  is '��ֵ���';
comment on column FACT_100241_PAYTYPE.paycount
  is '��ֵ����';
comment on column FACT_100241_PAYTYPE.paynum
  is '��ֵ����';
comment on column FACT_100241_PAYTYPE.data_source
  is '������Դ';
create index IDX100_100241 on FACT_100241_PAYTYPE (CHANNELID);
create index IDX101_100241 on FACT_100241_PAYTYPE (SERVERID);
create index IDX102_100241 on FACT_100241_PAYTYPE (STATDATE);

prompt
prompt Creating table FACT_100241_PAYWAY
prompt =================================
prompt
create table FACT_100241_PAYWAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paywayid    VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_PAYWAY
  is '��ֵ��ʽ������';
comment on column FACT_100241_PAYWAY.statdate
  is 'ͳ������';
comment on column FACT_100241_PAYWAY.channelid
  is '����';
comment on column FACT_100241_PAYWAY.serverid
  is '����';
comment on column FACT_100241_PAYWAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100241_PAYWAY.appid
  is '��Ʒid';
comment on column FACT_100241_PAYWAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_PAYWAY.paywayid
  is '��ֵ��ʽ';
comment on column FACT_100241_PAYWAY.payamount
  is '��ֵ���';
comment on column FACT_100241_PAYWAY.paycount
  is '��ֵ����';
comment on column FACT_100241_PAYWAY.paynum
  is '��ֵ����';
comment on column FACT_100241_PAYWAY.data_source
  is '������Դ';
create index IDX103_100241 on FACT_100241_PAYWAY (CHANNELID);
create index IDX104_100241 on FACT_100241_PAYWAY (SERVERID);
create index IDX105_100241 on FACT_100241_PAYWAY (STATDATE);

prompt
prompt Creating table FACT_100241_REGION
prompt =================================
prompt
create table FACT_100241_REGION
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  country     VARCHAR2(50),
  province    VARCHAR2(50),
  city        VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_REGION
  is '���������';
comment on column FACT_100241_REGION.statdate
  is 'ͳ������';
comment on column FACT_100241_REGION.channelid
  is '����';
comment on column FACT_100241_REGION.serverid
  is '����';
comment on column FACT_100241_REGION.appid
  is '��Ʒid';
comment on column FACT_100241_REGION.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_REGION.country
  is '����';
comment on column FACT_100241_REGION.province
  is 'ʡ';
comment on column FACT_100241_REGION.city
  is '��';
comment on column FACT_100241_REGION.newcount
  is '������';
comment on column FACT_100241_REGION.conncount
  is '������';
comment on column FACT_100241_REGION.paycount
  is '������';
comment on column FACT_100241_REGION.payamount
  is '���ѽ��';
comment on column FACT_100241_REGION.data_source
  is '������Դ';
create index IDX106_100241 on FACT_100241_REGION (CHANNELID);
create index IDX107_100241 on FACT_100241_REGION (SERVERID);
create index IDX108_100241 on FACT_100241_REGION (STATDATE);

prompt
prompt Creating table FACT_100241_REMAIN_MAC
prompt =====================================
prompt
create table FACT_100241_REMAIN_MAC
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_REMAIN_MAC
  is '�豸�����';
comment on column FACT_100241_REMAIN_MAC.statdate
  is 'ͳ������';
comment on column FACT_100241_REMAIN_MAC.conndate
  is '��������';
comment on column FACT_100241_REMAIN_MAC.channelid
  is '����ID';
comment on column FACT_100241_REMAIN_MAC.serverid
  is '����ID';
comment on column FACT_100241_REMAIN_MAC.appid
  is '��ƷID';
comment on column FACT_100241_REMAIN_MAC.remain_days
  is '��������';
comment on column FACT_100241_REMAIN_MAC.new_remain
  is '��������';
comment on column FACT_100241_REMAIN_MAC.conn_remain
  is '��������';
comment on column FACT_100241_REMAIN_MAC.pay_remain
  is '��������';
comment on column FACT_100241_REMAIN_MAC.data_source
  is '����Դ';
create index IDX109_100241 on FACT_100241_REMAIN_MAC (CHANNELID);
create index IDX110_100241 on FACT_100241_REMAIN_MAC (SERVERID);
create index IDX111_100241 on FACT_100241_REMAIN_MAC (STATDATE);

prompt
prompt Creating table FACT_100241_REMAIN_USER
prompt ======================================
prompt
create table FACT_100241_REMAIN_USER
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_REMAIN_USER
  is '�û������';
comment on column FACT_100241_REMAIN_USER.statdate
  is 'ͳ������';
comment on column FACT_100241_REMAIN_USER.conndate
  is '��������';
comment on column FACT_100241_REMAIN_USER.channelid
  is '����ID';
comment on column FACT_100241_REMAIN_USER.serverid
  is '����ID';
comment on column FACT_100241_REMAIN_USER.appid
  is '��ƷID';
comment on column FACT_100241_REMAIN_USER.remain_days
  is '��������';
comment on column FACT_100241_REMAIN_USER.new_remain
  is '��������';
comment on column FACT_100241_REMAIN_USER.conn_remain
  is '��������';
comment on column FACT_100241_REMAIN_USER.pay_remain
  is '��������';
comment on column FACT_100241_REMAIN_USER.data_source
  is '����Դ';
create index IDX112_100241 on FACT_100241_REMAIN_USER (CHANNELID);
create index IDX113_100241 on FACT_100241_REMAIN_USER (SERVERID);
create index IDX114_100241 on FACT_100241_REMAIN_USER (STATDATE);

prompt
prompt Creating table FACT_100241_VC
prompt =============================
prompt
create table FACT_100241_VC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcamount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100241_VC
  is '������ҷ�����';
comment on column FACT_100241_VC.statdate
  is 'ͳ������';
comment on column FACT_100241_VC.channelid
  is '����';
comment on column FACT_100241_VC.serverid
  is '����';
comment on column FACT_100241_VC.appid
  is '��Ʒid';
comment on column FACT_100241_VC.versionid
  is '��Ʒ�汾';
comment on column FACT_100241_VC.vctype
  is '�����������';
comment on column FACT_100241_VC.vcusetype
  is '�������ʹ������';
comment on column FACT_100241_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column FACT_100241_VC.vcamount
  is '������ҽ��';
comment on column FACT_100241_VC.data_source
  is '������Դ';
create index IDX115_100241 on FACT_100241_VC (CHANNELID);
create index IDX116_100241 on FACT_100241_VC (SERVERID);
create index IDX117_100241 on FACT_100241_VC (STATDATE);

prompt
prompt Creating table FACT_20002_BACK_MAC
prompt ==================================
prompt
create table FACT_20002_BACK_MAC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_BACK_MAC
  is '�豸����������';
comment on column FACT_20002_BACK_MAC.statdate
  is 'ͳ������';
comment on column FACT_20002_BACK_MAC.channelid
  is '����ID';
comment on column FACT_20002_BACK_MAC.serverid
  is '����ID';
comment on column FACT_20002_BACK_MAC.appid
  is '��ƷID';
comment on column FACT_20002_BACK_MAC.lost_days
  is '��ʧ����';
comment on column FACT_20002_BACK_MAC.back_conn
  is '��Ծ�豸������';
comment on column FACT_20002_BACK_MAC.back_pay
  is '�����豸������';
comment on column FACT_20002_BACK_MAC.data_source
  is '����Դ';
create index IDX1_20002 on FACT_20002_BACK_MAC (CHANNELID);
create index IDX2_20002 on FACT_20002_BACK_MAC (SERVERID);
create index IDX3_20002 on FACT_20002_BACK_MAC (STATDATE);

prompt
prompt Creating table FACT_20002_BACK_MAC_MONTH
prompt ========================================
prompt
create table FACT_20002_BACK_MAC_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_BACK_MAC_MONTH
  is '�豸����������';
comment on column FACT_20002_BACK_MAC_MONTH.statdate
  is 'ͳ������';
comment on column FACT_20002_BACK_MAC_MONTH.channelid
  is '����ID';
comment on column FACT_20002_BACK_MAC_MONTH.serverid
  is '����ID';
comment on column FACT_20002_BACK_MAC_MONTH.appid
  is '��ƷID';
comment on column FACT_20002_BACK_MAC_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_20002_BACK_MAC_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_20002_BACK_MAC_MONTH.back_pay
  is '�����豸������';
comment on column FACT_20002_BACK_MAC_MONTH.data_source
  is '����Դ';
create index IDX4_20002 on FACT_20002_BACK_MAC_MONTH (CHANNELID);
create index IDX5_20002 on FACT_20002_BACK_MAC_MONTH (SERVERID);
create index IDX6_20002 on FACT_20002_BACK_MAC_MONTH (STATDATE);

prompt
prompt Creating table FACT_20002_BACK_MAC_WEEK
prompt =======================================
prompt
create table FACT_20002_BACK_MAC_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_BACK_MAC_WEEK
  is '�豸����������';
comment on column FACT_20002_BACK_MAC_WEEK.statdate
  is 'ͳ������';
comment on column FACT_20002_BACK_MAC_WEEK.channelid
  is '����ID';
comment on column FACT_20002_BACK_MAC_WEEK.serverid
  is '����ID';
comment on column FACT_20002_BACK_MAC_WEEK.appid
  is '��ƷID';
comment on column FACT_20002_BACK_MAC_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_20002_BACK_MAC_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_20002_BACK_MAC_WEEK.back_pay
  is '�����豸������';
comment on column FACT_20002_BACK_MAC_WEEK.data_source
  is '����Դ';
create index IDX7_20002 on FACT_20002_BACK_MAC_WEEK (CHANNELID);
create index IDX8_20002 on FACT_20002_BACK_MAC_WEEK (SERVERID);
create index IDX9_20002 on FACT_20002_BACK_MAC_WEEK (STATDATE);

prompt
prompt Creating table FACT_20002_BACK_USER
prompt ===================================
prompt
create table FACT_20002_BACK_USER
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_BACK_USER
  is '�û�����������';
comment on column FACT_20002_BACK_USER.statdate
  is 'ͳ������';
comment on column FACT_20002_BACK_USER.channelid
  is '����ID';
comment on column FACT_20002_BACK_USER.serverid
  is '����ID';
comment on column FACT_20002_BACK_USER.appid
  is '��ƷID';
comment on column FACT_20002_BACK_USER.lost_days
  is '��ʧ����';
comment on column FACT_20002_BACK_USER.back_conn
  is '��Ծ�û�������';
comment on column FACT_20002_BACK_USER.back_pay
  is '�����û�������';
comment on column FACT_20002_BACK_USER.data_source
  is '����Դ';
create index IDX16_20002 on FACT_20002_BACK_USER (CHANNELID);
create index IDX17_20002 on FACT_20002_BACK_USER (SERVERID);
create index IDX18_20002 on FACT_20002_BACK_USER (STATDATE);

prompt
prompt Creating table FACT_20002_BACK_USER_MONTH
prompt =========================================
prompt
create table FACT_20002_BACK_USER_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_BACK_USER_MONTH
  is '�豸����������';
comment on column FACT_20002_BACK_USER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_20002_BACK_USER_MONTH.channelid
  is '����ID';
comment on column FACT_20002_BACK_USER_MONTH.serverid
  is '����ID';
comment on column FACT_20002_BACK_USER_MONTH.appid
  is '��ƷID';
comment on column FACT_20002_BACK_USER_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_20002_BACK_USER_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_20002_BACK_USER_MONTH.back_pay
  is '�����豸������';
comment on column FACT_20002_BACK_USER_MONTH.data_source
  is '����Դ';
create index IDX13_20002 on FACT_20002_BACK_USER_MONTH (CHANNELID);
create index IDX14_20002 on FACT_20002_BACK_USER_MONTH (SERVERID);
create index IDX15_20002 on FACT_20002_BACK_USER_MONTH (STATDATE);

prompt
prompt Creating table FACT_20002_BACK_USER_WEEK
prompt ========================================
prompt
create table FACT_20002_BACK_USER_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_BACK_USER_WEEK
  is '�豸����������';
comment on column FACT_20002_BACK_USER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_20002_BACK_USER_WEEK.channelid
  is '����ID';
comment on column FACT_20002_BACK_USER_WEEK.serverid
  is '����ID';
comment on column FACT_20002_BACK_USER_WEEK.appid
  is '��ƷID';
comment on column FACT_20002_BACK_USER_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_20002_BACK_USER_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_20002_BACK_USER_WEEK.back_pay
  is '�����豸������';
comment on column FACT_20002_BACK_USER_WEEK.data_source
  is '����Դ';
create index IDX10_20002 on FACT_20002_BACK_USER_WEEK (CHANNELID);
create index IDX11_20002 on FACT_20002_BACK_USER_WEEK (SERVERID);
create index IDX12_20002 on FACT_20002_BACK_USER_WEEK (STATDATE);

prompt
prompt Creating table FACT_20002_CEVENT
prompt ================================
prompt
create table FACT_20002_CEVENT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  eventkey    VARCHAR2(50),
  eventcount  NUMBER,
  eventnum    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_CEVENT
  is '�Զ��������';
comment on column FACT_20002_CEVENT.statdate
  is 'ͳ������';
comment on column FACT_20002_CEVENT.channelid
  is '����';
comment on column FACT_20002_CEVENT.serverid
  is '����';
comment on column FACT_20002_CEVENT.appid
  is '��Ʒid';
comment on column FACT_20002_CEVENT.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_20002_CEVENT.eventcount
  is '�¼��û���';
comment on column FACT_20002_CEVENT.eventnum
  is '�¼�����';
comment on column FACT_20002_CEVENT.data_source
  is '������Դ';
create index IDX181_20002 on FACT_20002_CEVENT (CHANNELID);
create index IDX182_20002 on FACT_20002_CEVENT (SERVERID);
create index IDX183_20002 on FACT_20002_CEVENT (STATDATE);

prompt
prompt Creating table FACT_20002_CEVENT_PAR
prompt ====================================
prompt
create table FACT_20002_CEVENT_PAR
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  ilevel         NUMBER,
  eventkey       VARCHAR2(100),
  eventpar_key   VARCHAR2(100),
  eventpar_value VARCHAR2(100),
  eventcount     NUMBER,
  eventnum       NUMBER,
  loaddate       DATE default Sysdate,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_20002_CEVENT_PAR
  is '�Զ������������';
comment on column FACT_20002_CEVENT_PAR.statdate
  is 'ͳ������';
comment on column FACT_20002_CEVENT_PAR.channelid
  is '����';
comment on column FACT_20002_CEVENT_PAR.serverid
  is '����';
comment on column FACT_20002_CEVENT_PAR.appid
  is '��Ʒid';
comment on column FACT_20002_CEVENT_PAR.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_CEVENT_PAR.ilevel
  is '��ɫ�ȼ�';
comment on column FACT_20002_CEVENT_PAR.eventkey
  is '�¼�����';
comment on column FACT_20002_CEVENT_PAR.eventpar_key
  is '�¼�����';
comment on column FACT_20002_CEVENT_PAR.eventpar_value
  is '�¼�����ֵ';
comment on column FACT_20002_CEVENT_PAR.eventcount
  is '�¼��û���';
comment on column FACT_20002_CEVENT_PAR.eventnum
  is '�¼�����';
comment on column FACT_20002_CEVENT_PAR.data_source
  is '������Դ';
create index IDX185_20002 on FACT_20002_CEVENT_PAR (CHANNELID);
create index IDX186_20002 on FACT_20002_CEVENT_PAR (SERVERID);
create index IDX187_20002 on FACT_20002_CEVENT_PAR (STATDATE);

prompt
prompt Creating table FACT_20002_COMP_CEVENT
prompt =====================================
prompt
create table FACT_20002_COMP_CEVENT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(10),
  channelid   VARCHAR2(50),
  gameversion VARCHAR2(50),
  serverid    VARCHAR2(50),
  ilevel      NUMBER,
  eventkey    VARCHAR2(100),
  compid      VARCHAR2(50),
  caltype     VARCHAR2(50),
  dimpars     VARCHAR2(2000),
  comp_data   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_COMP_CEVENT
  is '�Զ����¼���Ϸ�����';
comment on column FACT_20002_COMP_CEVENT.statdate
  is '����';
comment on column FACT_20002_COMP_CEVENT.appid
  is '��Ϸ�� appid';
comment on column FACT_20002_COMP_CEVENT.channelid
  is '���� ID';
comment on column FACT_20002_COMP_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column FACT_20002_COMP_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column FACT_20002_COMP_CEVENT.ilevel
  is '��ҵȼ�';
comment on column FACT_20002_COMP_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_20002_COMP_CEVENT.compid
  is '��ϼ����¼�ID';
comment on column FACT_20002_COMP_CEVENT.caltype
  is '��ϼ����¼���������';
comment on column FACT_20002_COMP_CEVENT.dimpars
  is '��ϲ���';
comment on column FACT_20002_COMP_CEVENT.comp_data
  is '��ϼ�����';
create index IDX184_20002 on FACT_20002_COMP_CEVENT (STATDATE);

prompt
prompt Creating table FACT_20002_DAILY_REPORT
prompt ======================================
prompt
create table FACT_20002_DAILY_REPORT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_DAILY_REPORT
  is '�ձ�����';
comment on column FACT_20002_DAILY_REPORT.statdate
  is 'ͳ������';
comment on column FACT_20002_DAILY_REPORT.appid
  is '��ƷID';
comment on column FACT_20002_DAILY_REPORT.channelid
  is '����';
comment on column FACT_20002_DAILY_REPORT.serverid
  is '����';
comment on column FACT_20002_DAILY_REPORT.indexid
  is 'ָ��';
comment on column FACT_20002_DAILY_REPORT.indtype
  is 'ָ������';
comment on column FACT_20002_DAILY_REPORT.rpt_data
  is '����';
create index IDX176_20002 on FACT_20002_DAILY_REPORT (STATDATE);

prompt
prompt Creating table FACT_20002_DVID
prompt ==============================
prompt
create table FACT_20002_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_model  VARCHAR2(200),
  dvid_res    VARCHAR2(50),
  dvid_os     VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_DVID
  is '�豸������';
comment on column FACT_20002_DVID.statdate
  is 'ͳ������';
comment on column FACT_20002_DVID.channelid
  is '����';
comment on column FACT_20002_DVID.serverid
  is '����';
comment on column FACT_20002_DVID.appid
  is '��Ʒid';
comment on column FACT_20002_DVID.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_DVID.dvid_model
  is '����';
comment on column FACT_20002_DVID.dvid_res
  is '�豸�ֱ���';
comment on column FACT_20002_DVID.dvid_os
  is '�豸����ϵͳ';
comment on column FACT_20002_DVID.newcount
  is '�����û���';
comment on column FACT_20002_DVID.conncount
  is '�����û���';
comment on column FACT_20002_DVID.data_source
  is '������Դ';
create index IDX19_20002 on FACT_20002_DVID (CHANNELID);
create index IDX20_20002 on FACT_20002_DVID (SERVERID);
create index IDX21_20002 on FACT_20002_DVID (STATDATE);

prompt
prompt Creating table FACT_20002_FIRSTPAY
prompt ==================================
prompt
create table FACT_20002_FIRSTPAY
(
  statdate         VARCHAR2(10),
  firstpaydate     VARCHAR2(10),
  channelid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  datatype         VARCHAR2(50),
  appid            VARCHAR2(50),
  first_payfromreg NUMBER,
  first_paycount   NUMBER,
  payamount        NUMBER,
  loaddate         DATE default Sysdate,
  data_source      VARCHAR2(100)
)
;
comment on table FACT_20002_FIRSTPAY
  is '�����û��״γ�ֵ������';
comment on column FACT_20002_FIRSTPAY.statdate
  is 'ͳ������';
comment on column FACT_20002_FIRSTPAY.firstpaydate
  is '�״θ�������';
comment on column FACT_20002_FIRSTPAY.channelid
  is '����';
comment on column FACT_20002_FIRSTPAY.serverid
  is '����';
comment on column FACT_20002_FIRSTPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_20002_FIRSTPAY.appid
  is '��Ʒid';
comment on column FACT_20002_FIRSTPAY.first_payfromreg
  is 'ע���ڼ��쿪ʼ��ֵ(1��2��..7..30..)';
comment on column FACT_20002_FIRSTPAY.first_paycount
  is '���������û���';
comment on column FACT_20002_FIRSTPAY.payamount
  is '�ۼƵ��ڼ���ĳ�ֵ�ܶ�';
comment on column FACT_20002_FIRSTPAY.data_source
  is '������Դ';
create index IDX22_20002 on FACT_20002_FIRSTPAY (CHANNELID);
create index IDX23_20002 on FACT_20002_FIRSTPAY (SERVERID);
create index IDX24_20002 on FACT_20002_FIRSTPAY (STATDATE);

prompt
prompt Creating table FACT_20002_FIRSTPAY_AMOUNT
prompt =========================================
prompt
create table FACT_20002_FIRSTPAY_AMOUNT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_FIRSTPAY_AMOUNT
  is '�״θ��ѽ�������';
comment on column FACT_20002_FIRSTPAY_AMOUNT.statdate
  is 'ͳ������';
comment on column FACT_20002_FIRSTPAY_AMOUNT.channelid
  is '����';
comment on column FACT_20002_FIRSTPAY_AMOUNT.serverid
  is '��������';
comment on column FACT_20002_FIRSTPAY_AMOUNT.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_20002_FIRSTPAY_AMOUNT.appid
  is '��Ʒid';
comment on column FACT_20002_FIRSTPAY_AMOUNT.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_FIRSTPAY_AMOUNT.payamount
  is '�״θ��ѽ��';
comment on column FACT_20002_FIRSTPAY_AMOUNT.paycount
  is '�״θ��ѽ���Ӧ������';
create index IDX25_20002 on FACT_20002_FIRSTPAY_AMOUNT (CHANNELID);
create index IDX26_20002 on FACT_20002_FIRSTPAY_AMOUNT (SERVERID);
create index IDX27_20002 on FACT_20002_FIRSTPAY_AMOUNT (STATDATE);

prompt
prompt Creating table FACT_20002_GENERAL_DAY
prompt =====================================
prompt
create table FACT_20002_GENERAL_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_GENERAL_DAY
  is '�ջ���������';
comment on column FACT_20002_GENERAL_DAY.statdate
  is 'ͳ������';
comment on column FACT_20002_GENERAL_DAY.channelid
  is '����';
comment on column FACT_20002_GENERAL_DAY.serverid
  is '����';
comment on column FACT_20002_GENERAL_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_20002_GENERAL_DAY.appid
  is '��Ʒid';
comment on column FACT_20002_GENERAL_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_GENERAL_DAY.newcount
  is '������';
comment on column FACT_20002_GENERAL_DAY.conncount
  is '������';
comment on column FACT_20002_GENERAL_DAY.paycount
  is '������';
comment on column FACT_20002_GENERAL_DAY.payamount
  is '���ѽ��';
comment on column FACT_20002_GENERAL_DAY.data_source
  is '������Դ';
create index IDX28_20002 on FACT_20002_GENERAL_DAY (CHANNELID);
create index IDX29_20002 on FACT_20002_GENERAL_DAY (SERVERID);
create index IDX30_20002 on FACT_20002_GENERAL_DAY (STATDATE);

prompt
prompt Creating table FACT_20002_GENERAL_DAY_DVID
prompt ==========================================
prompt
create table FACT_20002_GENERAL_DAY_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_GENERAL_DAY_DVID
  is '���豸����������';
comment on column FACT_20002_GENERAL_DAY_DVID.statdate
  is 'ͳ������';
comment on column FACT_20002_GENERAL_DAY_DVID.channelid
  is '����';
comment on column FACT_20002_GENERAL_DAY_DVID.appid
  is '��Ʒid';
comment on column FACT_20002_GENERAL_DAY_DVID.newcount
  is '������';
comment on column FACT_20002_GENERAL_DAY_DVID.conncount
  is '������';
comment on column FACT_20002_GENERAL_DAY_DVID.data_source
  is '������Դ';
create index IDX31_20002 on FACT_20002_GENERAL_DAY_DVID (CHANNELID);
create index IDX33_20002 on FACT_20002_GENERAL_DAY_DVID (STATDATE);

prompt
prompt Creating table FACT_20002_GENERAL_HOUR
prompt ======================================
prompt
create table FACT_20002_GENERAL_HOUR
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_GENERAL_HOUR
  is 'Сʱ����������';
comment on column FACT_20002_GENERAL_HOUR.statdate
  is 'ͳ������';
comment on column FACT_20002_GENERAL_HOUR.channelid
  is '����';
comment on column FACT_20002_GENERAL_HOUR.serverid
  is '����';
comment on column FACT_20002_GENERAL_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_20002_GENERAL_HOUR.appid
  is '��Ʒid';
comment on column FACT_20002_GENERAL_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_GENERAL_HOUR.newcount
  is '������';
comment on column FACT_20002_GENERAL_HOUR.conncount
  is '������';
comment on column FACT_20002_GENERAL_HOUR.paycount
  is '������';
comment on column FACT_20002_GENERAL_HOUR.payamount
  is '���ѽ��';
comment on column FACT_20002_GENERAL_HOUR.data_source
  is '������Դ';
create index IDX34_20002 on FACT_20002_GENERAL_HOUR (CHANNELID);
create index IDX35_20002 on FACT_20002_GENERAL_HOUR (SERVERID);
create index IDX36_20002 on FACT_20002_GENERAL_HOUR (STATDATE);

prompt
prompt Creating table FACT_20002_GENERAL_HOUR_DVID
prompt ===========================================
prompt
create table FACT_20002_GENERAL_HOUR_DVID
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_GENERAL_HOUR_DVID
  is 'Сʱ�豸����������';
comment on column FACT_20002_GENERAL_HOUR_DVID.statdate
  is 'ͳ������';
comment on column FACT_20002_GENERAL_HOUR_DVID.channelid
  is '����';
comment on column FACT_20002_GENERAL_HOUR_DVID.appid
  is '��Ʒid';
comment on column FACT_20002_GENERAL_HOUR_DVID.newcount
  is '������';
comment on column FACT_20002_GENERAL_HOUR_DVID.conncount
  is '������';
comment on column FACT_20002_GENERAL_HOUR_DVID.data_source
  is '������Դ';
create index IDX37_20002 on FACT_20002_GENERAL_HOUR_DVID (CHANNELID);
create index IDX39_20002 on FACT_20002_GENERAL_HOUR_DVID (STATDATE);

prompt
prompt Creating table FACT_20002_GENERAL_LEVEL
prompt =======================================
prompt
create table FACT_20002_GENERAL_LEVEL
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  rolelevel   NUMBER,
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_GENERAL_LEVEL
  is '�û��ȼ�������';
comment on column FACT_20002_GENERAL_LEVEL.statdate
  is 'ͳ������';
comment on column FACT_20002_GENERAL_LEVEL.channelid
  is '����';
comment on column FACT_20002_GENERAL_LEVEL.serverid
  is '����';
comment on column FACT_20002_GENERAL_LEVEL.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_20002_GENERAL_LEVEL.appid
  is '��Ʒid';
comment on column FACT_20002_GENERAL_LEVEL.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_GENERAL_LEVEL.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_20002_GENERAL_LEVEL.newcount
  is '������';
comment on column FACT_20002_GENERAL_LEVEL.conncount
  is '������';
comment on column FACT_20002_GENERAL_LEVEL.paycount
  is '������';
comment on column FACT_20002_GENERAL_LEVEL.payamount
  is '���ѽ��';
comment on column FACT_20002_GENERAL_LEVEL.data_source
  is '������Դ';
create index IDX40_20002 on FACT_20002_GENERAL_LEVEL (CHANNELID);
create index IDX41_20002 on FACT_20002_GENERAL_LEVEL (SERVERID);
create index IDX42_20002 on FACT_20002_GENERAL_LEVEL (STATDATE);

prompt
prompt Creating table FACT_20002_GENERAL_MONTH
prompt =======================================
prompt
create table FACT_20002_GENERAL_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_GENERAL_MONTH
  is '�»���������';
comment on column FACT_20002_GENERAL_MONTH.statdate
  is 'ͳ������';
comment on column FACT_20002_GENERAL_MONTH.channelid
  is '����';
comment on column FACT_20002_GENERAL_MONTH.serverid
  is '����';
comment on column FACT_20002_GENERAL_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_20002_GENERAL_MONTH.appid
  is '��Ʒid';
comment on column FACT_20002_GENERAL_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_GENERAL_MONTH.newcount
  is '������';
comment on column FACT_20002_GENERAL_MONTH.conncount
  is '������';
comment on column FACT_20002_GENERAL_MONTH.paycount
  is '������';
comment on column FACT_20002_GENERAL_MONTH.payamount
  is '���ѽ��';
comment on column FACT_20002_GENERAL_MONTH.data_source
  is '������Դ';
create index IDX43_20002 on FACT_20002_GENERAL_MONTH (CHANNELID);
create index IDX44_20002 on FACT_20002_GENERAL_MONTH (SERVERID);
create index IDX45_20002 on FACT_20002_GENERAL_MONTH (STATDATE);

prompt
prompt Creating table FACT_20002_GENERAL_MONTH_DVID
prompt ============================================
prompt
create table FACT_20002_GENERAL_MONTH_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_GENERAL_MONTH_DVID
  is '���豸����������';
comment on column FACT_20002_GENERAL_MONTH_DVID.statdate
  is 'ͳ������';
comment on column FACT_20002_GENERAL_MONTH_DVID.channelid
  is '����';
comment on column FACT_20002_GENERAL_MONTH_DVID.appid
  is '��Ʒid';
comment on column FACT_20002_GENERAL_MONTH_DVID.newcount
  is '������';
comment on column FACT_20002_GENERAL_MONTH_DVID.conncount
  is '������';
comment on column FACT_20002_GENERAL_MONTH_DVID.data_source
  is '������Դ';
create index IDX46_20002 on FACT_20002_GENERAL_MONTH_DVID (CHANNELID);
create index IDX48_20002 on FACT_20002_GENERAL_MONTH_DVID (STATDATE);

prompt
prompt Creating table FACT_20002_GENERAL_WEEK
prompt ======================================
prompt
create table FACT_20002_GENERAL_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_GENERAL_WEEK
  is '�ܻ���������';
comment on column FACT_20002_GENERAL_WEEK.statdate
  is 'ͳ������';
comment on column FACT_20002_GENERAL_WEEK.channelid
  is '����';
comment on column FACT_20002_GENERAL_WEEK.serverid
  is '����';
comment on column FACT_20002_GENERAL_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_20002_GENERAL_WEEK.appid
  is '��Ʒid';
comment on column FACT_20002_GENERAL_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_GENERAL_WEEK.newcount
  is '������';
comment on column FACT_20002_GENERAL_WEEK.conncount
  is '������';
comment on column FACT_20002_GENERAL_WEEK.paycount
  is '������';
comment on column FACT_20002_GENERAL_WEEK.payamount
  is '���ѽ��';
comment on column FACT_20002_GENERAL_WEEK.data_source
  is '������Դ';
create index IDX52_20002 on FACT_20002_GENERAL_WEEK (CHANNELID);
create index IDX53_20002 on FACT_20002_GENERAL_WEEK (SERVERID);
create index IDX54_20002 on FACT_20002_GENERAL_WEEK (STATDATE);

prompt
prompt Creating table FACT_20002_GENERAL_WEEK_DVID
prompt ===========================================
prompt
create table FACT_20002_GENERAL_WEEK_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_GENERAL_WEEK_DVID
  is '���豸����������';
comment on column FACT_20002_GENERAL_WEEK_DVID.statdate
  is 'ͳ������';
comment on column FACT_20002_GENERAL_WEEK_DVID.channelid
  is '����';
comment on column FACT_20002_GENERAL_WEEK_DVID.appid
  is '��Ʒid';
comment on column FACT_20002_GENERAL_WEEK_DVID.newcount
  is '������';
comment on column FACT_20002_GENERAL_WEEK_DVID.conncount
  is '������';
comment on column FACT_20002_GENERAL_WEEK_DVID.data_source
  is '������Դ';
create index IDX49_20002 on FACT_20002_GENERAL_WEEK_DVID (CHANNELID);
create index IDX51_20002 on FACT_20002_GENERAL_WEEK_DVID (STATDATE);

prompt
prompt Creating table FACT_20002_HOUR_REPORT
prompt =====================================
prompt
create table FACT_20002_HOUR_REPORT
(
  statdate    VARCHAR2(20),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_HOUR_REPORT
  is '�ձ�Сʱ����';
comment on column FACT_20002_HOUR_REPORT.statdate
  is 'ͳ������';
comment on column FACT_20002_HOUR_REPORT.appid
  is '��ƷID';
comment on column FACT_20002_HOUR_REPORT.channelid
  is '����';
comment on column FACT_20002_HOUR_REPORT.serverid
  is '����';
comment on column FACT_20002_HOUR_REPORT.indexid
  is 'ָ��';
comment on column FACT_20002_HOUR_REPORT.indtype
  is 'ָ������';
comment on column FACT_20002_HOUR_REPORT.rpt_data
  is '����';

prompt
prompt Creating table FACT_20002_LEVELPAY
prompt ==================================
prompt
create table FACT_20002_LEVELPAY
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  datatype       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  rolelevel      NUMBER,
  paycount       NUMBER,
  first_paycount NUMBER,
  loaddate       DATE default Sysdate,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_20002_LEVELPAY
  is '�û���ɫ�ȼ����ѷ�����';
comment on column FACT_20002_LEVELPAY.statdate
  is 'ͳ������';
comment on column FACT_20002_LEVELPAY.channelid
  is '����';
comment on column FACT_20002_LEVELPAY.serverid
  is '����';
comment on column FACT_20002_LEVELPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_20002_LEVELPAY.appid
  is '��Ʒid';
comment on column FACT_20002_LEVELPAY.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_LEVELPAY.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_20002_LEVELPAY.paycount
  is '�����û���';
comment on column FACT_20002_LEVELPAY.first_paycount
  is '���������û������״θ����û���';
comment on column FACT_20002_LEVELPAY.data_source
  is '������Դ';
create index IDX55_20002 on FACT_20002_LEVELPAY (CHANNELID);
create index IDX56_20002 on FACT_20002_LEVELPAY (SERVERID);
create index IDX57_20002 on FACT_20002_LEVELPAY (STATDATE);

prompt
prompt Creating table FACT_20002_LOST_MAC
prompt ==================================
prompt
create table FACT_20002_LOST_MAC
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_LOST_MAC
  is '�豸��ʧ������';
comment on column FACT_20002_LOST_MAC.statdate
  is 'ͳ������';
comment on column FACT_20002_LOST_MAC.lostdate
  is '��ʧ����';
comment on column FACT_20002_LOST_MAC.channelid
  is '����ID';
comment on column FACT_20002_LOST_MAC.serverid
  is '����ID';
comment on column FACT_20002_LOST_MAC.appid
  is '��ƷID';
comment on column FACT_20002_LOST_MAC.rolelevel
  is '��ʧʱ�ȼ�';
comment on column FACT_20002_LOST_MAC.lost_days
  is '��ʧ����';
comment on column FACT_20002_LOST_MAC.lost_conn
  is '��Ծ�豸��ʧ';
comment on column FACT_20002_LOST_MAC.lost_pay
  is '�����豸��ʧ';
comment on column FACT_20002_LOST_MAC.data_source
  is '����Դ';
create index IDX58_20002 on FACT_20002_LOST_MAC (CHANNELID);
create index IDX59_20002 on FACT_20002_LOST_MAC (SERVERID);
create index IDX60_20002 on FACT_20002_LOST_MAC (STATDATE);

prompt
prompt Creating table FACT_20002_LOST_USER
prompt ===================================
prompt
create table FACT_20002_LOST_USER
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_LOST_USER
  is '�û���ʧ������';
comment on column FACT_20002_LOST_USER.statdate
  is 'ͳ������';
comment on column FACT_20002_LOST_USER.lostdate
  is '��ʧ����';
comment on column FACT_20002_LOST_USER.channelid
  is '����ID';
comment on column FACT_20002_LOST_USER.serverid
  is '����ID';
comment on column FACT_20002_LOST_USER.appid
  is '��ƷID';
comment on column FACT_20002_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column FACT_20002_LOST_USER.lost_days
  is '��ʧ����';
comment on column FACT_20002_LOST_USER.lost_conn
  is '��Ծ�û���ʧ';
comment on column FACT_20002_LOST_USER.lost_pay
  is '�����û���ʧ';
comment on column FACT_20002_LOST_USER.data_source
  is '����Դ';
create index IDX61_20002 on FACT_20002_LOST_USER (CHANNELID);
create index IDX62_20002 on FACT_20002_LOST_USER (SERVERID);
create index IDX63_20002 on FACT_20002_LOST_USER (STATDATE);

prompt
prompt Creating table FACT_20002_LTV_MAC
prompt =================================
prompt
create table FACT_20002_LTV_MAC
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_LTV_MAC
  is '�豸LTV������';
comment on column FACT_20002_LTV_MAC.statdate
  is 'ͳ������';
comment on column FACT_20002_LTV_MAC.ltvdate
  is '��ֵ����';
comment on column FACT_20002_LTV_MAC.channelid
  is '����';
comment on column FACT_20002_LTV_MAC.serverid
  is '����';
comment on column FACT_20002_LTV_MAC.appid
  is '��Ʒid';
comment on column FACT_20002_LTV_MAC.ltv_days
  is 'ltv��';
comment on column FACT_20002_LTV_MAC.payamount
  is '���ѽ��';
comment on column FACT_20002_LTV_MAC.data_source
  is '������Դ';
create index IDX64_20002 on FACT_20002_LTV_MAC (CHANNELID);
create index IDX65_20002 on FACT_20002_LTV_MAC (SERVERID);
create index IDX66_20002 on FACT_20002_LTV_MAC (STATDATE);

prompt
prompt Creating table FACT_20002_LTV_USER
prompt ==================================
prompt
create table FACT_20002_LTV_USER
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_LTV_USER
  is '�û�LTV������';
comment on column FACT_20002_LTV_USER.statdate
  is 'ͳ������';
comment on column FACT_20002_LTV_USER.ltvdate
  is '��ֵ����';
comment on column FACT_20002_LTV_USER.channelid
  is '����';
comment on column FACT_20002_LTV_USER.serverid
  is '����';
comment on column FACT_20002_LTV_USER.appid
  is '��Ʒid';
comment on column FACT_20002_LTV_USER.ltv_days
  is 'ltv��';
comment on column FACT_20002_LTV_USER.payamount
  is '���ѽ��';
comment on column FACT_20002_LTV_USER.data_source
  is '������Դ';
create index IDX67_20002 on FACT_20002_LTV_USER (CHANNELID);
create index IDX68_20002 on FACT_20002_LTV_USER (SERVERID);
create index IDX69_20002 on FACT_20002_LTV_USER (STATDATE);

prompt
prompt Creating table FACT_20002_MISS_FIRST
prompt ====================================
prompt
create table FACT_20002_MISS_FIRST
(
  statdate        VARCHAR2(10),
  channelid       VARCHAR2(50),
  serverid        VARCHAR2(50),
  appid           VARCHAR2(50),
  versionid       VARCHAR2(50),
  missionid       VARCHAR2(50),
  rolelevel       NUMBER,
  rolejob         VARCHAR2(50) default '0',
  firstenter_succ NUMBER,
  firstenter_fail NUMBER,
  loaddate        DATE,
  data_source     VARCHAR2(100)
)
;
comment on table FACT_20002_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column FACT_20002_MISS_FIRST.statdate
  is 'ͳ������';
comment on column FACT_20002_MISS_FIRST.channelid
  is '����';
comment on column FACT_20002_MISS_FIRST.serverid
  is '����';
comment on column FACT_20002_MISS_FIRST.appid
  is '��ƷID';
comment on column FACT_20002_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_MISS_FIRST.missionid
  is '�ؿ�ID';
comment on column FACT_20002_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column FACT_20002_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column FACT_20002_MISS_FIRST.firstenter_succ
  is '��һ�ν���ؿ��ɹ���';
comment on column FACT_20002_MISS_FIRST.firstenter_fail
  is '��һ�ν���ؿ�ʧ����';
comment on column FACT_20002_MISS_FIRST.data_source
  is '������Դ';
create index IDX70_20002 on FACT_20002_MISS_FIRST (CHANNELID);
create index IDX71_20002 on FACT_20002_MISS_FIRST (SERVERID);
create index IDX72_20002 on FACT_20002_MISS_FIRST (STATDATE);

prompt
prompt Creating table FACT_20002_NET
prompt =============================
prompt
create table FACT_20002_NET
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_net    VARCHAR2(50),
  conncount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_NET
  is '������ʽ������';
comment on column FACT_20002_NET.statdate
  is 'ͳ������';
comment on column FACT_20002_NET.channelid
  is '����';
comment on column FACT_20002_NET.serverid
  is '����';
comment on column FACT_20002_NET.appid
  is '��Ʒid';
comment on column FACT_20002_NET.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_NET.dvid_net
  is '������ʽ';
comment on column FACT_20002_NET.conncount
  is '������';
comment on column FACT_20002_NET.data_source
  is '������Դ';
create index IDX73_20002 on FACT_20002_NET (CHANNELID);
create index IDX74_20002 on FACT_20002_NET (SERVERID);
create index IDX75_20002 on FACT_20002_NET (STATDATE);

prompt
prompt Creating table FACT_20002_OPERATOR
prompt ==================================
prompt
create table FACT_20002_OPERATOR
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  dvid_operator VARCHAR2(50),
  conncount     NUMBER,
  loaddate      DATE default Sysdate,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_20002_OPERATOR
  is '��Ӫ�̷�����';
comment on column FACT_20002_OPERATOR.statdate
  is 'ͳ������';
comment on column FACT_20002_OPERATOR.channelid
  is '����';
comment on column FACT_20002_OPERATOR.serverid
  is '����';
comment on column FACT_20002_OPERATOR.appid
  is '��Ʒid';
comment on column FACT_20002_OPERATOR.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_OPERATOR.dvid_operator
  is '������ʽ';
comment on column FACT_20002_OPERATOR.conncount
  is '������';
comment on column FACT_20002_OPERATOR.data_source
  is '������Դ';
create index IDX76_20002 on FACT_20002_OPERATOR (CHANNELID);
create index IDX77_20002 on FACT_20002_OPERATOR (SERVERID);
create index IDX78_20002 on FACT_20002_OPERATOR (STATDATE);

prompt
prompt Creating table FACT_20002_ORDER
prompt ===============================
prompt
create table FACT_20002_ORDER
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default Sysdate,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_20002_ORDER
  is '����������';
comment on column FACT_20002_ORDER.statdate
  is 'ͳ������';
comment on column FACT_20002_ORDER.channelid
  is '����';
comment on column FACT_20002_ORDER.serverid
  is '����';
comment on column FACT_20002_ORDER.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_20002_ORDER.appid
  is '��Ʒid';
comment on column FACT_20002_ORDER.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_ORDER.paysucccount
  is '�ɹ�������';
comment on column FACT_20002_ORDER.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_20002_ORDER.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_20002_ORDER.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_20002_ORDER.paysuccnum
  is '�����ɹ�����';
comment on column FACT_20002_ORDER.payfailnum
  is '����ʧ������';
comment on column FACT_20002_ORDER.data_source
  is '������Դ';
create index IDX79_20002 on FACT_20002_ORDER (CHANNELID);
create index IDX80_20002 on FACT_20002_ORDER (SERVERID);
create index IDX81_20002 on FACT_20002_ORDER (STATDATE);

prompt
prompt Creating table FACT_20002_ORDER_HOUR
prompt ====================================
prompt
create table FACT_20002_ORDER_HOUR
(
  statdate      VARCHAR2(20),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_20002_ORDER_HOUR
  is '����Сʱ������';
comment on column FACT_20002_ORDER_HOUR.statdate
  is 'ͳ������';
comment on column FACT_20002_ORDER_HOUR.channelid
  is '����';
comment on column FACT_20002_ORDER_HOUR.serverid
  is '����';
comment on column FACT_20002_ORDER_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_20002_ORDER_HOUR.appid
  is '��Ʒid';
comment on column FACT_20002_ORDER_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_ORDER_HOUR.paysucccount
  is '�ɹ�������';
comment on column FACT_20002_ORDER_HOUR.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_20002_ORDER_HOUR.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_20002_ORDER_HOUR.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_20002_ORDER_HOUR.paysuccnum
  is '�����ɹ�����';
comment on column FACT_20002_ORDER_HOUR.payfailnum
  is '����ʧ������';
comment on column FACT_20002_ORDER_HOUR.data_source
  is '������Դ';
create index IDX177_20002 on FACT_20002_ORDER_HOUR (CHANNELID);
create index IDX178_20002 on FACT_20002_ORDER_HOUR (SERVERID);
create index IDX179_20002 on FACT_20002_ORDER_HOUR (STATDATE);

prompt
prompt Creating table FACT_20002_ORDER_MONTH
prompt =====================================
prompt
create table FACT_20002_ORDER_MONTH
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_20002_ORDER_MONTH
  is '�¶���������';
comment on column FACT_20002_ORDER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_20002_ORDER_MONTH.channelid
  is '����';
comment on column FACT_20002_ORDER_MONTH.serverid
  is '����';
comment on column FACT_20002_ORDER_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_20002_ORDER_MONTH.appid
  is '��Ʒid';
comment on column FACT_20002_ORDER_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_ORDER_MONTH.paysucccount
  is '�ɹ�������';
comment on column FACT_20002_ORDER_MONTH.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_20002_ORDER_MONTH.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_20002_ORDER_MONTH.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_20002_ORDER_MONTH.paysuccnum
  is '�����ɹ�����';
comment on column FACT_20002_ORDER_MONTH.payfailnum
  is '����ʧ������';
comment on column FACT_20002_ORDER_MONTH.data_source
  is '������Դ';
create index IDX191_20002 on FACT_20002_ORDER_MONTH (CHANNELID);
create index IDX192_20002 on FACT_20002_ORDER_MONTH (SERVERID);
create index IDX193_20002 on FACT_20002_ORDER_MONTH (STATDATE);

prompt
prompt Creating table FACT_20002_ORDER_WEEK
prompt ====================================
prompt
create table FACT_20002_ORDER_WEEK
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_20002_ORDER_WEEK
  is '�ܶ���������';
comment on column FACT_20002_ORDER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_20002_ORDER_WEEK.channelid
  is '����';
comment on column FACT_20002_ORDER_WEEK.serverid
  is '����';
comment on column FACT_20002_ORDER_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_20002_ORDER_WEEK.appid
  is '��Ʒid';
comment on column FACT_20002_ORDER_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_ORDER_WEEK.paysucccount
  is '�ɹ�������';
comment on column FACT_20002_ORDER_WEEK.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_20002_ORDER_WEEK.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_20002_ORDER_WEEK.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_20002_ORDER_WEEK.paysuccnum
  is '�����ɹ�����';
comment on column FACT_20002_ORDER_WEEK.payfailnum
  is '����ʧ������';
comment on column FACT_20002_ORDER_WEEK.data_source
  is '������Դ';
create index IDX188_20002 on FACT_20002_ORDER_WEEK (CHANNELID);
create index IDX189_20002 on FACT_20002_ORDER_WEEK (SERVERID);
create index IDX190_20002 on FACT_20002_ORDER_WEEK (STATDATE);

prompt
prompt Creating table FACT_20002_PAYAMOUNT_DAY
prompt =======================================
prompt
create table FACT_20002_PAYAMOUNT_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_PAYAMOUNT_DAY
  is '�ճ�ֵ��������';
comment on column FACT_20002_PAYAMOUNT_DAY.statdate
  is 'ͳ������';
comment on column FACT_20002_PAYAMOUNT_DAY.channelid
  is '����';
comment on column FACT_20002_PAYAMOUNT_DAY.serverid
  is '����';
comment on column FACT_20002_PAYAMOUNT_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_20002_PAYAMOUNT_DAY.appid
  is '��Ʒid';
comment on column FACT_20002_PAYAMOUNT_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_PAYAMOUNT_DAY.payamount
  is '��ֵ��ȡ����';
comment on column FACT_20002_PAYAMOUNT_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_20002_PAYAMOUNT_DAY.data_source
  is '������Դ';
create index IDX82_20002 on FACT_20002_PAYAMOUNT_DAY (CHANNELID);
create index IDX83_20002 on FACT_20002_PAYAMOUNT_DAY (SERVERID);
create index IDX84_20002 on FACT_20002_PAYAMOUNT_DAY (STATDATE);

prompt
prompt Creating table FACT_20002_PAYAMOUNT_MONTH
prompt =========================================
prompt
create table FACT_20002_PAYAMOUNT_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_PAYAMOUNT_MONTH
  is '�³�ֵ��������';
comment on column FACT_20002_PAYAMOUNT_MONTH.statdate
  is 'ͳ������';
comment on column FACT_20002_PAYAMOUNT_MONTH.channelid
  is '����';
comment on column FACT_20002_PAYAMOUNT_MONTH.serverid
  is '����';
comment on column FACT_20002_PAYAMOUNT_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_20002_PAYAMOUNT_MONTH.appid
  is '��Ʒid';
comment on column FACT_20002_PAYAMOUNT_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_PAYAMOUNT_MONTH.payamount
  is '��ֵ��ȡ����';
comment on column FACT_20002_PAYAMOUNT_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_20002_PAYAMOUNT_MONTH.data_source
  is '������Դ';
create index IDX88_20002 on FACT_20002_PAYAMOUNT_MONTH (CHANNELID);
create index IDX89_20002 on FACT_20002_PAYAMOUNT_MONTH (SERVERID);
create index IDX90_20002 on FACT_20002_PAYAMOUNT_MONTH (STATDATE);

prompt
prompt Creating table FACT_20002_PAYAMOUNT_WEEK
prompt ========================================
prompt
create table FACT_20002_PAYAMOUNT_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_PAYAMOUNT_WEEK
  is '�ܳ�ֵ��������';
comment on column FACT_20002_PAYAMOUNT_WEEK.statdate
  is 'ͳ������';
comment on column FACT_20002_PAYAMOUNT_WEEK.channelid
  is '����';
comment on column FACT_20002_PAYAMOUNT_WEEK.serverid
  is '����';
comment on column FACT_20002_PAYAMOUNT_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_20002_PAYAMOUNT_WEEK.appid
  is '��Ʒid';
comment on column FACT_20002_PAYAMOUNT_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_PAYAMOUNT_WEEK.payamount
  is '��ֵ��ȡ����';
comment on column FACT_20002_PAYAMOUNT_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_20002_PAYAMOUNT_WEEK.data_source
  is '������Դ';
create index IDX85_20002 on FACT_20002_PAYAMOUNT_WEEK (CHANNELID);
create index IDX86_20002 on FACT_20002_PAYAMOUNT_WEEK (SERVERID);
create index IDX87_20002 on FACT_20002_PAYAMOUNT_WEEK (STATDATE);

prompt
prompt Creating table FACT_20002_PAYNUM_DAY
prompt ====================================
prompt
create table FACT_20002_PAYNUM_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_PAYNUM_DAY
  is '�ճ�ֵ����������';
comment on column FACT_20002_PAYNUM_DAY.statdate
  is 'ͳ������';
comment on column FACT_20002_PAYNUM_DAY.channelid
  is '����';
comment on column FACT_20002_PAYNUM_DAY.serverid
  is '����';
comment on column FACT_20002_PAYNUM_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_20002_PAYNUM_DAY.appid
  is '��Ʒid';
comment on column FACT_20002_PAYNUM_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_PAYNUM_DAY.paynum
  is '��ֵ����';
comment on column FACT_20002_PAYNUM_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_20002_PAYNUM_DAY.data_source
  is '������Դ';
create index IDX97_20002 on FACT_20002_PAYNUM_DAY (CHANNELID);
create index IDX98_20002 on FACT_20002_PAYNUM_DAY (SERVERID);
create index IDX99_20002 on FACT_20002_PAYNUM_DAY (STATDATE);

prompt
prompt Creating table FACT_20002_PAYNUM_MONTH
prompt ======================================
prompt
create table FACT_20002_PAYNUM_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_PAYNUM_MONTH
  is '�³�ֵ����������';
comment on column FACT_20002_PAYNUM_MONTH.statdate
  is 'ͳ������';
comment on column FACT_20002_PAYNUM_MONTH.channelid
  is '����';
comment on column FACT_20002_PAYNUM_MONTH.serverid
  is '����';
comment on column FACT_20002_PAYNUM_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_20002_PAYNUM_MONTH.appid
  is '��Ʒid';
comment on column FACT_20002_PAYNUM_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_PAYNUM_MONTH.paynum
  is '��ֵ����';
comment on column FACT_20002_PAYNUM_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_20002_PAYNUM_MONTH.data_source
  is '������Դ';
create index IDX91_20002 on FACT_20002_PAYNUM_MONTH (CHANNELID);
create index IDX92_20002 on FACT_20002_PAYNUM_MONTH (SERVERID);
create index IDX93_20002 on FACT_20002_PAYNUM_MONTH (STATDATE);

prompt
prompt Creating table FACT_20002_PAYNUM_WEEK
prompt =====================================
prompt
create table FACT_20002_PAYNUM_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_PAYNUM_WEEK
  is '�ܳ�ֵ����������';
comment on column FACT_20002_PAYNUM_WEEK.statdate
  is 'ͳ������';
comment on column FACT_20002_PAYNUM_WEEK.channelid
  is '����';
comment on column FACT_20002_PAYNUM_WEEK.serverid
  is '����';
comment on column FACT_20002_PAYNUM_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_20002_PAYNUM_WEEK.appid
  is '��Ʒid';
comment on column FACT_20002_PAYNUM_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_PAYNUM_WEEK.paynum
  is '��ֵ����';
comment on column FACT_20002_PAYNUM_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_20002_PAYNUM_WEEK.data_source
  is '������Դ';
create index IDX94_20002 on FACT_20002_PAYNUM_WEEK (CHANNELID);
create index IDX95_20002 on FACT_20002_PAYNUM_WEEK (SERVERID);
create index IDX96_20002 on FACT_20002_PAYNUM_WEEK (STATDATE);

prompt
prompt Creating table FACT_20002_PAYTYPE
prompt =================================
prompt
create table FACT_20002_PAYTYPE
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paytypeid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_PAYTYPE
  is '��ֵ���ͷ�����';
comment on column FACT_20002_PAYTYPE.statdate
  is 'ͳ������';
comment on column FACT_20002_PAYTYPE.channelid
  is '����';
comment on column FACT_20002_PAYTYPE.serverid
  is '����';
comment on column FACT_20002_PAYTYPE.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_20002_PAYTYPE.appid
  is '��Ʒid';
comment on column FACT_20002_PAYTYPE.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_PAYTYPE.paytypeid
  is '��ֵ����';
comment on column FACT_20002_PAYTYPE.payamount
  is '��ֵ���';
comment on column FACT_20002_PAYTYPE.paycount
  is '��ֵ����';
comment on column FACT_20002_PAYTYPE.paynum
  is '��ֵ����';
comment on column FACT_20002_PAYTYPE.data_source
  is '������Դ';
create index IDX100_20002 on FACT_20002_PAYTYPE (CHANNELID);
create index IDX101_20002 on FACT_20002_PAYTYPE (SERVERID);
create index IDX102_20002 on FACT_20002_PAYTYPE (STATDATE);

prompt
prompt Creating table FACT_20002_PAYWAY
prompt ================================
prompt
create table FACT_20002_PAYWAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paywayid    VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_PAYWAY
  is '��ֵ��ʽ������';
comment on column FACT_20002_PAYWAY.statdate
  is 'ͳ������';
comment on column FACT_20002_PAYWAY.channelid
  is '����';
comment on column FACT_20002_PAYWAY.serverid
  is '����';
comment on column FACT_20002_PAYWAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_20002_PAYWAY.appid
  is '��Ʒid';
comment on column FACT_20002_PAYWAY.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_PAYWAY.paywayid
  is '��ֵ��ʽ';
comment on column FACT_20002_PAYWAY.payamount
  is '��ֵ���';
comment on column FACT_20002_PAYWAY.paycount
  is '��ֵ����';
comment on column FACT_20002_PAYWAY.paynum
  is '��ֵ����';
comment on column FACT_20002_PAYWAY.data_source
  is '������Դ';
create index IDX103_20002 on FACT_20002_PAYWAY (CHANNELID);
create index IDX104_20002 on FACT_20002_PAYWAY (SERVERID);
create index IDX105_20002 on FACT_20002_PAYWAY (STATDATE);

prompt
prompt Creating table FACT_20002_REGION
prompt ================================
prompt
create table FACT_20002_REGION
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  country     VARCHAR2(50),
  province    VARCHAR2(50),
  city        VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_REGION
  is '���������';
comment on column FACT_20002_REGION.statdate
  is 'ͳ������';
comment on column FACT_20002_REGION.channelid
  is '����';
comment on column FACT_20002_REGION.serverid
  is '����';
comment on column FACT_20002_REGION.appid
  is '��Ʒid';
comment on column FACT_20002_REGION.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_REGION.country
  is '����';
comment on column FACT_20002_REGION.province
  is 'ʡ';
comment on column FACT_20002_REGION.city
  is '��';
comment on column FACT_20002_REGION.newcount
  is '������';
comment on column FACT_20002_REGION.conncount
  is '������';
comment on column FACT_20002_REGION.paycount
  is '������';
comment on column FACT_20002_REGION.payamount
  is '���ѽ��';
comment on column FACT_20002_REGION.data_source
  is '������Դ';
create index IDX106_20002 on FACT_20002_REGION (CHANNELID);
create index IDX107_20002 on FACT_20002_REGION (SERVERID);
create index IDX108_20002 on FACT_20002_REGION (STATDATE);

prompt
prompt Creating table FACT_20002_REMAIN_MAC
prompt ====================================
prompt
create table FACT_20002_REMAIN_MAC
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_REMAIN_MAC
  is '�豸�����';
comment on column FACT_20002_REMAIN_MAC.statdate
  is 'ͳ������';
comment on column FACT_20002_REMAIN_MAC.conndate
  is '��������';
comment on column FACT_20002_REMAIN_MAC.channelid
  is '����ID';
comment on column FACT_20002_REMAIN_MAC.serverid
  is '����ID';
comment on column FACT_20002_REMAIN_MAC.appid
  is '��ƷID';
comment on column FACT_20002_REMAIN_MAC.remain_days
  is '��������';
comment on column FACT_20002_REMAIN_MAC.new_remain
  is '��������';
comment on column FACT_20002_REMAIN_MAC.conn_remain
  is '��������';
comment on column FACT_20002_REMAIN_MAC.pay_remain
  is '��������';
comment on column FACT_20002_REMAIN_MAC.data_source
  is '����Դ';
create index IDX109_20002 on FACT_20002_REMAIN_MAC (CHANNELID);
create index IDX110_20002 on FACT_20002_REMAIN_MAC (SERVERID);
create index IDX111_20002 on FACT_20002_REMAIN_MAC (STATDATE);

prompt
prompt Creating table FACT_20002_REMAIN_USER
prompt =====================================
prompt
create table FACT_20002_REMAIN_USER
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_REMAIN_USER
  is '�û������';
comment on column FACT_20002_REMAIN_USER.statdate
  is 'ͳ������';
comment on column FACT_20002_REMAIN_USER.conndate
  is '��������';
comment on column FACT_20002_REMAIN_USER.channelid
  is '����ID';
comment on column FACT_20002_REMAIN_USER.serverid
  is '����ID';
comment on column FACT_20002_REMAIN_USER.appid
  is '��ƷID';
comment on column FACT_20002_REMAIN_USER.remain_days
  is '��������';
comment on column FACT_20002_REMAIN_USER.new_remain
  is '��������';
comment on column FACT_20002_REMAIN_USER.conn_remain
  is '��������';
comment on column FACT_20002_REMAIN_USER.pay_remain
  is '��������';
comment on column FACT_20002_REMAIN_USER.data_source
  is '����Դ';
create index IDX112_20002 on FACT_20002_REMAIN_USER (CHANNELID);
create index IDX113_20002 on FACT_20002_REMAIN_USER (SERVERID);
create index IDX114_20002 on FACT_20002_REMAIN_USER (STATDATE);

prompt
prompt Creating table FACT_20002_VC
prompt ============================
prompt
create table FACT_20002_VC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcamount    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20002_VC
  is '������ҷ�����';
comment on column FACT_20002_VC.statdate
  is 'ͳ������';
comment on column FACT_20002_VC.channelid
  is '����';
comment on column FACT_20002_VC.serverid
  is '����';
comment on column FACT_20002_VC.appid
  is '��Ʒid';
comment on column FACT_20002_VC.versionid
  is '��Ʒ�汾';
comment on column FACT_20002_VC.vctype
  is '�����������';
comment on column FACT_20002_VC.vcusetype
  is '�������ʹ������';
comment on column FACT_20002_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column FACT_20002_VC.vcamount
  is '������ҽ��';
comment on column FACT_20002_VC.data_source
  is '������Դ';
create index IDX115_20002 on FACT_20002_VC (CHANNELID);
create index IDX116_20002 on FACT_20002_VC (SERVERID);
create index IDX117_20002 on FACT_20002_VC (STATDATE);

prompt
prompt Creating table FACT_20003_BACK_MAC
prompt ==================================
prompt
create table FACT_20003_BACK_MAC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_BACK_MAC_MONTH
prompt ========================================
prompt
create table FACT_20003_BACK_MAC_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_BACK_MAC_WEEK
prompt =======================================
prompt
create table FACT_20003_BACK_MAC_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_BACK_USER
prompt ===================================
prompt
create table FACT_20003_BACK_USER
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_BACK_USER_MONTH
prompt =========================================
prompt
create table FACT_20003_BACK_USER_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_BACK_USER_WEEK
prompt ========================================
prompt
create table FACT_20003_BACK_USER_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_DVID
prompt ==============================
prompt
create table FACT_20003_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_model  VARCHAR2(50),
  dvid_res    VARCHAR2(50),
  dvid_os     VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20003_DVID
  is '�豸������';
comment on column FACT_20003_DVID.statdate
  is 'ͳ������';
comment on column FACT_20003_DVID.channelid
  is '����';
comment on column FACT_20003_DVID.serverid
  is '����';
comment on column FACT_20003_DVID.appid
  is '��Ʒid';
comment on column FACT_20003_DVID.versionid
  is '��Ʒ�汾';
comment on column FACT_20003_DVID.dvid_model
  is '����';
comment on column FACT_20003_DVID.dvid_res
  is '�豸�ֱ���';
comment on column FACT_20003_DVID.dvid_os
  is '�豸����ϵͳ';
comment on column FACT_20003_DVID.newcount
  is '�����û���';
comment on column FACT_20003_DVID.conncount
  is '�����û���';
comment on column FACT_20003_DVID.data_source
  is '������Դ';

prompt
prompt Creating table FACT_20003_FIRSTPAY
prompt ==================================
prompt
create table FACT_20003_FIRSTPAY
(
  statdate         VARCHAR2(10),
  firstpaydate     VARCHAR2(10),
  channelid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  datatype         VARCHAR2(50),
  appid            VARCHAR2(50),
  first_payfromreg NUMBER,
  first_paycount   NUMBER,
  payamount        NUMBER,
  loaddate         DATE default Sysdate,
  data_source      VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_GENERAL_DAY
prompt =====================================
prompt
create table FACT_20003_GENERAL_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_GENERAL_HOUR
prompt ======================================
prompt
create table FACT_20003_GENERAL_HOUR
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_GENERAL_LEVEL
prompt =======================================
prompt
create table FACT_20003_GENERAL_LEVEL
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  rolelevel   NUMBER,
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_GENERAL_MONTH
prompt =======================================
prompt
create table FACT_20003_GENERAL_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_GENERAL_WEEK
prompt ======================================
prompt
create table FACT_20003_GENERAL_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_LEVELPAY
prompt ==================================
prompt
create table FACT_20003_LEVELPAY
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  datatype       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  rolelevel      NUMBER,
  paycount       NUMBER,
  first_paycount NUMBER,
  loaddate       DATE default Sysdate,
  data_source    VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_LOST_MAC
prompt ==================================
prompt
create table FACT_20003_LOST_MAC
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_LOST_USER
prompt ===================================
prompt
create table FACT_20003_LOST_USER
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_LTV_MAC
prompt =================================
prompt
create table FACT_20003_LTV_MAC
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_LTV_USER
prompt ==================================
prompt
create table FACT_20003_LTV_USER
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_MISS_FIRST
prompt ====================================
prompt
create table FACT_20003_MISS_FIRST
(
  statdate        VARCHAR2(10),
  channelid       VARCHAR2(50),
  serverid        VARCHAR2(50),
  appid           VARCHAR2(50),
  versionid       VARCHAR2(50),
  missionid       VARCHAR2(50),
  rolelevel       NUMBER,
  rolejob         VARCHAR2(50) default '0',
  firstenter_succ NUMBER,
  firstenter_fail NUMBER,
  loaddate        DATE,
  data_source     VARCHAR2(100)
)
;
comment on table FACT_20003_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column FACT_20003_MISS_FIRST.statdate
  is 'ͳ������';
comment on column FACT_20003_MISS_FIRST.channelid
  is '����';
comment on column FACT_20003_MISS_FIRST.serverid
  is '����';
comment on column FACT_20003_MISS_FIRST.appid
  is '��ƷID';
comment on column FACT_20003_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column FACT_20003_MISS_FIRST.missionid
  is '�ؿ�ID';
comment on column FACT_20003_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column FACT_20003_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column FACT_20003_MISS_FIRST.firstenter_succ
  is '��һ�ν���ؿ��ɹ���';
comment on column FACT_20003_MISS_FIRST.firstenter_fail
  is '��һ�ν���ؿ�ʧ����';
comment on column FACT_20003_MISS_FIRST.data_source
  is '������Դ';

prompt
prompt Creating table FACT_20003_NET
prompt =============================
prompt
create table FACT_20003_NET
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_net    VARCHAR2(50),
  conncount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20003_NET
  is '������ʽ������';
comment on column FACT_20003_NET.statdate
  is 'ͳ������';
comment on column FACT_20003_NET.channelid
  is '����';
comment on column FACT_20003_NET.serverid
  is '����';
comment on column FACT_20003_NET.appid
  is '��Ʒid';
comment on column FACT_20003_NET.versionid
  is '��Ʒ�汾';
comment on column FACT_20003_NET.dvid_net
  is '������ʽ';
comment on column FACT_20003_NET.conncount
  is '������';
comment on column FACT_20003_NET.data_source
  is '������Դ';

prompt
prompt Creating table FACT_20003_OPERATOR
prompt ==================================
prompt
create table FACT_20003_OPERATOR
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  dvid_operator VARCHAR2(50),
  conncount     NUMBER,
  loaddate      DATE default Sysdate,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_20003_OPERATOR
  is '��Ӫ�̷�����';
comment on column FACT_20003_OPERATOR.statdate
  is 'ͳ������';
comment on column FACT_20003_OPERATOR.channelid
  is '����';
comment on column FACT_20003_OPERATOR.serverid
  is '����';
comment on column FACT_20003_OPERATOR.appid
  is '��Ʒid';
comment on column FACT_20003_OPERATOR.versionid
  is '��Ʒ�汾';
comment on column FACT_20003_OPERATOR.dvid_operator
  is '������ʽ';
comment on column FACT_20003_OPERATOR.conncount
  is '������';
comment on column FACT_20003_OPERATOR.data_source
  is '������Դ';

prompt
prompt Creating table FACT_20003_ORDER
prompt ===============================
prompt
create table FACT_20003_ORDER
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default Sysdate,
  data_source   VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_PAYAMOUNT_DAY
prompt =======================================
prompt
create table FACT_20003_PAYAMOUNT_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_PAYAMOUNT_MONTH
prompt =========================================
prompt
create table FACT_20003_PAYAMOUNT_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_PAYAMOUNT_WEEK
prompt ========================================
prompt
create table FACT_20003_PAYAMOUNT_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_PAYNUM_DAY
prompt ====================================
prompt
create table FACT_20003_PAYNUM_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_PAYNUM_MONTH
prompt ======================================
prompt
create table FACT_20003_PAYNUM_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_PAYNUM_WEEK
prompt =====================================
prompt
create table FACT_20003_PAYNUM_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_PAYTYPE
prompt =================================
prompt
create table FACT_20003_PAYTYPE
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paytypeid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_PAYWAY
prompt ================================
prompt
create table FACT_20003_PAYWAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paywayid    VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_REGION
prompt ================================
prompt
create table FACT_20003_REGION
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  country     VARCHAR2(50),
  province    VARCHAR2(50),
  city        VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20003_REGION
  is '���������';
comment on column FACT_20003_REGION.statdate
  is 'ͳ������';
comment on column FACT_20003_REGION.channelid
  is '����';
comment on column FACT_20003_REGION.serverid
  is '����';
comment on column FACT_20003_REGION.appid
  is '��Ʒid';
comment on column FACT_20003_REGION.versionid
  is '��Ʒ�汾';
comment on column FACT_20003_REGION.country
  is '����';
comment on column FACT_20003_REGION.province
  is 'ʡ';
comment on column FACT_20003_REGION.city
  is '��';
comment on column FACT_20003_REGION.newcount
  is '������';
comment on column FACT_20003_REGION.conncount
  is '������';
comment on column FACT_20003_REGION.paycount
  is '������';
comment on column FACT_20003_REGION.payamount
  is '���ѽ��';
comment on column FACT_20003_REGION.data_source
  is '������Դ';

prompt
prompt Creating table FACT_20003_REMAIN_MAC
prompt ====================================
prompt
create table FACT_20003_REMAIN_MAC
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_REMAIN_USER
prompt =====================================
prompt
create table FACT_20003_REMAIN_USER
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table FACT_20003_VC
prompt ============================
prompt
create table FACT_20003_VC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcamount    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_20003_VC
  is '������ҷ�����';
comment on column FACT_20003_VC.statdate
  is 'ͳ������';
comment on column FACT_20003_VC.channelid
  is '����';
comment on column FACT_20003_VC.serverid
  is '����';
comment on column FACT_20003_VC.appid
  is '��Ʒid';
comment on column FACT_20003_VC.versionid
  is '��Ʒ�汾';
comment on column FACT_20003_VC.vctype
  is '�����������';
comment on column FACT_20003_VC.vcusetype
  is '�������ʹ������';
comment on column FACT_20003_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column FACT_20003_VC.vcamount
  is '������ҽ��';
comment on column FACT_20003_VC.data_source
  is '������Դ';

prompt
prompt Creating table FACT_DEMO_BACK_MAC
prompt =================================
prompt
create table FACT_DEMO_BACK_MAC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_BACK_MAC
  is '�豸����������';
comment on column FACT_DEMO_BACK_MAC.statdate
  is 'ͳ������';
comment on column FACT_DEMO_BACK_MAC.channelid
  is '����ID';
comment on column FACT_DEMO_BACK_MAC.serverid
  is '����ID';
comment on column FACT_DEMO_BACK_MAC.appid
  is '��ƷID';
comment on column FACT_DEMO_BACK_MAC.lost_days
  is '��ʧ����';
comment on column FACT_DEMO_BACK_MAC.back_conn
  is '��Ծ�豸������';
comment on column FACT_DEMO_BACK_MAC.back_pay
  is '�����豸������';
comment on column FACT_DEMO_BACK_MAC.data_source
  is '����Դ';
create index IDX1_DEMO on FACT_DEMO_BACK_MAC (CHANNELID);
create index IDX2_DEMO on FACT_DEMO_BACK_MAC (SERVERID);
create index IDX3_DEMO on FACT_DEMO_BACK_MAC (STATDATE);

prompt
prompt Creating table FACT_DEMO_BACK_MAC_MONTH
prompt =======================================
prompt
create table FACT_DEMO_BACK_MAC_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_BACK_MAC_MONTH
  is '�豸����������';
comment on column FACT_DEMO_BACK_MAC_MONTH.statdate
  is 'ͳ������';
comment on column FACT_DEMO_BACK_MAC_MONTH.channelid
  is '����ID';
comment on column FACT_DEMO_BACK_MAC_MONTH.serverid
  is '����ID';
comment on column FACT_DEMO_BACK_MAC_MONTH.appid
  is '��ƷID';
comment on column FACT_DEMO_BACK_MAC_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_DEMO_BACK_MAC_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_DEMO_BACK_MAC_MONTH.back_pay
  is '�����豸������';
comment on column FACT_DEMO_BACK_MAC_MONTH.data_source
  is '����Դ';
create index IDX4_DEMO on FACT_DEMO_BACK_MAC_MONTH (CHANNELID);
create index IDX5_DEMO on FACT_DEMO_BACK_MAC_MONTH (SERVERID);
create index IDX6_DEMO on FACT_DEMO_BACK_MAC_MONTH (STATDATE);

prompt
prompt Creating table FACT_DEMO_BACK_MAC_WEEK
prompt ======================================
prompt
create table FACT_DEMO_BACK_MAC_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_BACK_MAC_WEEK
  is '�豸����������';
comment on column FACT_DEMO_BACK_MAC_WEEK.statdate
  is 'ͳ������';
comment on column FACT_DEMO_BACK_MAC_WEEK.channelid
  is '����ID';
comment on column FACT_DEMO_BACK_MAC_WEEK.serverid
  is '����ID';
comment on column FACT_DEMO_BACK_MAC_WEEK.appid
  is '��ƷID';
comment on column FACT_DEMO_BACK_MAC_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_DEMO_BACK_MAC_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_DEMO_BACK_MAC_WEEK.back_pay
  is '�����豸������';
comment on column FACT_DEMO_BACK_MAC_WEEK.data_source
  is '����Դ';
create index IDX7_DEMO on FACT_DEMO_BACK_MAC_WEEK (CHANNELID);
create index IDX8_DEMO on FACT_DEMO_BACK_MAC_WEEK (SERVERID);
create index IDX9_DEMO on FACT_DEMO_BACK_MAC_WEEK (STATDATE);

prompt
prompt Creating table FACT_DEMO_BACK_USER
prompt ==================================
prompt
create table FACT_DEMO_BACK_USER
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_BACK_USER
  is '�û�����������';
comment on column FACT_DEMO_BACK_USER.statdate
  is 'ͳ������';
comment on column FACT_DEMO_BACK_USER.channelid
  is '����ID';
comment on column FACT_DEMO_BACK_USER.serverid
  is '����ID';
comment on column FACT_DEMO_BACK_USER.appid
  is '��ƷID';
comment on column FACT_DEMO_BACK_USER.lost_days
  is '��ʧ����';
comment on column FACT_DEMO_BACK_USER.back_conn
  is '��Ծ�û�������';
comment on column FACT_DEMO_BACK_USER.back_pay
  is '�����û�������';
comment on column FACT_DEMO_BACK_USER.data_source
  is '����Դ';
create index IDX16_DEMO on FACT_DEMO_BACK_USER (CHANNELID);
create index IDX17_DEMO on FACT_DEMO_BACK_USER (SERVERID);
create index IDX18_DEMO on FACT_DEMO_BACK_USER (STATDATE);

prompt
prompt Creating table FACT_DEMO_BACK_USER_MONTH
prompt ========================================
prompt
create table FACT_DEMO_BACK_USER_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_BACK_USER_MONTH
  is '�豸����������';
comment on column FACT_DEMO_BACK_USER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_DEMO_BACK_USER_MONTH.channelid
  is '����ID';
comment on column FACT_DEMO_BACK_USER_MONTH.serverid
  is '����ID';
comment on column FACT_DEMO_BACK_USER_MONTH.appid
  is '��ƷID';
comment on column FACT_DEMO_BACK_USER_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_DEMO_BACK_USER_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_DEMO_BACK_USER_MONTH.back_pay
  is '�����豸������';
comment on column FACT_DEMO_BACK_USER_MONTH.data_source
  is '����Դ';
create index IDX13_DEMO on FACT_DEMO_BACK_USER_MONTH (CHANNELID);
create index IDX14_DEMO on FACT_DEMO_BACK_USER_MONTH (SERVERID);
create index IDX15_DEMO on FACT_DEMO_BACK_USER_MONTH (STATDATE);

prompt
prompt Creating table FACT_DEMO_BACK_USER_WEEK
prompt =======================================
prompt
create table FACT_DEMO_BACK_USER_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_BACK_USER_WEEK
  is '�豸����������';
comment on column FACT_DEMO_BACK_USER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_DEMO_BACK_USER_WEEK.channelid
  is '����ID';
comment on column FACT_DEMO_BACK_USER_WEEK.serverid
  is '����ID';
comment on column FACT_DEMO_BACK_USER_WEEK.appid
  is '��ƷID';
comment on column FACT_DEMO_BACK_USER_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_DEMO_BACK_USER_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_DEMO_BACK_USER_WEEK.back_pay
  is '�����豸������';
comment on column FACT_DEMO_BACK_USER_WEEK.data_source
  is '����Դ';
create index IDX10_DEMO on FACT_DEMO_BACK_USER_WEEK (CHANNELID);
create index IDX11_DEMO on FACT_DEMO_BACK_USER_WEEK (SERVERID);
create index IDX12_DEMO on FACT_DEMO_BACK_USER_WEEK (STATDATE);

prompt
prompt Creating table FACT_DEMO_CEVENT
prompt ===============================
prompt
create table FACT_DEMO_CEVENT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  eventkey    VARCHAR2(50),
  eventcount  NUMBER,
  eventnum    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_CEVENT
  is '�Զ��������';
comment on column FACT_DEMO_CEVENT.statdate
  is 'ͳ������';
comment on column FACT_DEMO_CEVENT.channelid
  is '����';
comment on column FACT_DEMO_CEVENT.serverid
  is '����';
comment on column FACT_DEMO_CEVENT.appid
  is '��Ʒid';
comment on column FACT_DEMO_CEVENT.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_DEMO_CEVENT.eventcount
  is '�¼��û���';
comment on column FACT_DEMO_CEVENT.eventnum
  is '�¼�����';
comment on column FACT_DEMO_CEVENT.data_source
  is '������Դ';
create index IDX181_DEMO on FACT_DEMO_CEVENT (CHANNELID);
create index IDX182_DEMO on FACT_DEMO_CEVENT (SERVERID);
create index IDX183_DEMO on FACT_DEMO_CEVENT (STATDATE);

prompt
prompt Creating table FACT_DEMO_CEVENT_PAR
prompt ===================================
prompt
create table FACT_DEMO_CEVENT_PAR
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  ilevel         NUMBER,
  eventkey       VARCHAR2(100),
  eventpar_key   VARCHAR2(100),
  eventpar_value VARCHAR2(100),
  eventcount     NUMBER,
  eventnum       NUMBER,
  loaddate       DATE default Sysdate,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_DEMO_CEVENT_PAR
  is '�Զ������������';
comment on column FACT_DEMO_CEVENT_PAR.statdate
  is 'ͳ������';
comment on column FACT_DEMO_CEVENT_PAR.channelid
  is '����';
comment on column FACT_DEMO_CEVENT_PAR.serverid
  is '����';
comment on column FACT_DEMO_CEVENT_PAR.appid
  is '��Ʒid';
comment on column FACT_DEMO_CEVENT_PAR.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_CEVENT_PAR.ilevel
  is '��ɫ�ȼ�';
comment on column FACT_DEMO_CEVENT_PAR.eventkey
  is '�¼�����';
comment on column FACT_DEMO_CEVENT_PAR.eventpar_key
  is '�¼�����';
comment on column FACT_DEMO_CEVENT_PAR.eventpar_value
  is '�¼�����ֵ';
comment on column FACT_DEMO_CEVENT_PAR.eventcount
  is '�¼��û���';
comment on column FACT_DEMO_CEVENT_PAR.eventnum
  is '�¼�����';
comment on column FACT_DEMO_CEVENT_PAR.data_source
  is '������Դ';
create index IDX185_DEMO on FACT_DEMO_CEVENT_PAR (CHANNELID);
create index IDX186_DEMO on FACT_DEMO_CEVENT_PAR (SERVERID);
create index IDX187_DEMO on FACT_DEMO_CEVENT_PAR (STATDATE);

prompt
prompt Creating table FACT_DEMO_COMP_CEVENT
prompt ====================================
prompt
create table FACT_DEMO_COMP_CEVENT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(10),
  channelid   VARCHAR2(50),
  gameversion VARCHAR2(50),
  serverid    VARCHAR2(50),
  ilevel      NUMBER,
  eventkey    VARCHAR2(100),
  compid      VARCHAR2(50),
  caltype     VARCHAR2(50),
  dimpars     VARCHAR2(2000),
  comp_data   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_COMP_CEVENT
  is '�Զ����¼���Ϸ�����';
comment on column FACT_DEMO_COMP_CEVENT.statdate
  is '����';
comment on column FACT_DEMO_COMP_CEVENT.appid
  is '��Ϸ�� appid';
comment on column FACT_DEMO_COMP_CEVENT.channelid
  is '���� ID';
comment on column FACT_DEMO_COMP_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column FACT_DEMO_COMP_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column FACT_DEMO_COMP_CEVENT.ilevel
  is '��ҵȼ�';
comment on column FACT_DEMO_COMP_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_DEMO_COMP_CEVENT.compid
  is '��ϼ����¼�ID';
comment on column FACT_DEMO_COMP_CEVENT.caltype
  is '��ϼ����¼���������';
comment on column FACT_DEMO_COMP_CEVENT.dimpars
  is '��ϲ���';
comment on column FACT_DEMO_COMP_CEVENT.comp_data
  is '��ϼ�����';
create index IDX184_DEMO on FACT_DEMO_COMP_CEVENT (STATDATE);

prompt
prompt Creating table FACT_DEMO_DAILY_REPORT
prompt =====================================
prompt
create table FACT_DEMO_DAILY_REPORT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_DAILY_REPORT
  is '�ձ�����';
comment on column FACT_DEMO_DAILY_REPORT.statdate
  is 'ͳ������';
comment on column FACT_DEMO_DAILY_REPORT.appid
  is '��ƷID';
comment on column FACT_DEMO_DAILY_REPORT.channelid
  is '����';
comment on column FACT_DEMO_DAILY_REPORT.serverid
  is '����';
comment on column FACT_DEMO_DAILY_REPORT.indexid
  is 'ָ��';
comment on column FACT_DEMO_DAILY_REPORT.indtype
  is 'ָ������';
comment on column FACT_DEMO_DAILY_REPORT.rpt_data
  is '����';
create index IDX176_DEMO on FACT_DEMO_DAILY_REPORT (STATDATE);

prompt
prompt Creating table FACT_DEMO_DVID
prompt =============================
prompt
create table FACT_DEMO_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_model  VARCHAR2(200),
  dvid_res    VARCHAR2(50),
  dvid_os     VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_DVID
  is '�豸������';
comment on column FACT_DEMO_DVID.statdate
  is 'ͳ������';
comment on column FACT_DEMO_DVID.channelid
  is '����';
comment on column FACT_DEMO_DVID.serverid
  is '����';
comment on column FACT_DEMO_DVID.appid
  is '��Ʒid';
comment on column FACT_DEMO_DVID.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_DVID.dvid_model
  is '����';
comment on column FACT_DEMO_DVID.dvid_res
  is '�豸�ֱ���';
comment on column FACT_DEMO_DVID.dvid_os
  is '�豸����ϵͳ';
comment on column FACT_DEMO_DVID.newcount
  is '�����û���';
comment on column FACT_DEMO_DVID.conncount
  is '�����û���';
comment on column FACT_DEMO_DVID.data_source
  is '������Դ';
create index IDX19_DEMO on FACT_DEMO_DVID (CHANNELID);
create index IDX20_DEMO on FACT_DEMO_DVID (SERVERID);
create index IDX21_DEMO on FACT_DEMO_DVID (STATDATE);

prompt
prompt Creating table FACT_DEMO_FIRSTPAY
prompt =================================
prompt
create table FACT_DEMO_FIRSTPAY
(
  statdate         VARCHAR2(10),
  firstpaydate     VARCHAR2(10),
  channelid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  datatype         VARCHAR2(50),
  appid            VARCHAR2(50),
  first_payfromreg NUMBER,
  first_paycount   NUMBER,
  payamount        NUMBER,
  loaddate         DATE default Sysdate,
  data_source      VARCHAR2(100)
)
;
comment on table FACT_DEMO_FIRSTPAY
  is '�����û��״γ�ֵ������';
comment on column FACT_DEMO_FIRSTPAY.statdate
  is 'ͳ������';
comment on column FACT_DEMO_FIRSTPAY.firstpaydate
  is '�״θ�������';
comment on column FACT_DEMO_FIRSTPAY.channelid
  is '����';
comment on column FACT_DEMO_FIRSTPAY.serverid
  is '����';
comment on column FACT_DEMO_FIRSTPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_DEMO_FIRSTPAY.appid
  is '��Ʒid';
comment on column FACT_DEMO_FIRSTPAY.first_payfromreg
  is 'ע���ڼ��쿪ʼ��ֵ(1��2��..7..30..)';
comment on column FACT_DEMO_FIRSTPAY.first_paycount
  is '���������û���';
comment on column FACT_DEMO_FIRSTPAY.payamount
  is '�ۼƵ��ڼ���ĳ�ֵ�ܶ�';
comment on column FACT_DEMO_FIRSTPAY.data_source
  is '������Դ';
create index IDX22_DEMO on FACT_DEMO_FIRSTPAY (CHANNELID);
create index IDX23_DEMO on FACT_DEMO_FIRSTPAY (SERVERID);
create index IDX24_DEMO on FACT_DEMO_FIRSTPAY (STATDATE);

prompt
prompt Creating table FACT_DEMO_FIRSTPAY_AMOUNT
prompt ========================================
prompt
create table FACT_DEMO_FIRSTPAY_AMOUNT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_FIRSTPAY_AMOUNT
  is '�״θ��ѽ�������';
comment on column FACT_DEMO_FIRSTPAY_AMOUNT.statdate
  is 'ͳ������';
comment on column FACT_DEMO_FIRSTPAY_AMOUNT.channelid
  is '����';
comment on column FACT_DEMO_FIRSTPAY_AMOUNT.serverid
  is '��������';
comment on column FACT_DEMO_FIRSTPAY_AMOUNT.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_DEMO_FIRSTPAY_AMOUNT.appid
  is '��Ʒid';
comment on column FACT_DEMO_FIRSTPAY_AMOUNT.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_FIRSTPAY_AMOUNT.payamount
  is '�״θ��ѽ��';
comment on column FACT_DEMO_FIRSTPAY_AMOUNT.paycount
  is '�״θ��ѽ���Ӧ������';
create index IDX25_DEMO on FACT_DEMO_FIRSTPAY_AMOUNT (CHANNELID);
create index IDX26_DEMO on FACT_DEMO_FIRSTPAY_AMOUNT (SERVERID);
create index IDX27_DEMO on FACT_DEMO_FIRSTPAY_AMOUNT (STATDATE);

prompt
prompt Creating table FACT_DEMO_GENERAL_DAY
prompt ====================================
prompt
create table FACT_DEMO_GENERAL_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_GENERAL_DAY
  is '�ջ���������';
comment on column FACT_DEMO_GENERAL_DAY.statdate
  is 'ͳ������';
comment on column FACT_DEMO_GENERAL_DAY.channelid
  is '����';
comment on column FACT_DEMO_GENERAL_DAY.serverid
  is '����';
comment on column FACT_DEMO_GENERAL_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_DEMO_GENERAL_DAY.appid
  is '��Ʒid';
comment on column FACT_DEMO_GENERAL_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_GENERAL_DAY.newcount
  is '������';
comment on column FACT_DEMO_GENERAL_DAY.conncount
  is '������';
comment on column FACT_DEMO_GENERAL_DAY.paycount
  is '������';
comment on column FACT_DEMO_GENERAL_DAY.payamount
  is '���ѽ��';
comment on column FACT_DEMO_GENERAL_DAY.data_source
  is '������Դ';
create index IDX28_DEMO on FACT_DEMO_GENERAL_DAY (CHANNELID);
create index IDX29_DEMO on FACT_DEMO_GENERAL_DAY (SERVERID);
create index IDX30_DEMO on FACT_DEMO_GENERAL_DAY (STATDATE);

prompt
prompt Creating table FACT_DEMO_GENERAL_DAY_DVID
prompt =========================================
prompt
create table FACT_DEMO_GENERAL_DAY_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_GENERAL_DAY_DVID
  is '���豸����������';
comment on column FACT_DEMO_GENERAL_DAY_DVID.statdate
  is 'ͳ������';
comment on column FACT_DEMO_GENERAL_DAY_DVID.channelid
  is '����';
comment on column FACT_DEMO_GENERAL_DAY_DVID.appid
  is '��Ʒid';
comment on column FACT_DEMO_GENERAL_DAY_DVID.newcount
  is '������';
comment on column FACT_DEMO_GENERAL_DAY_DVID.conncount
  is '������';
comment on column FACT_DEMO_GENERAL_DAY_DVID.data_source
  is '������Դ';
create index IDX31_DEMO on FACT_DEMO_GENERAL_DAY_DVID (CHANNELID);
create index IDX33_DEMO on FACT_DEMO_GENERAL_DAY_DVID (STATDATE);

prompt
prompt Creating table FACT_DEMO_GENERAL_HOUR
prompt =====================================
prompt
create table FACT_DEMO_GENERAL_HOUR
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_GENERAL_HOUR
  is 'Сʱ����������';
comment on column FACT_DEMO_GENERAL_HOUR.statdate
  is 'ͳ������';
comment on column FACT_DEMO_GENERAL_HOUR.channelid
  is '����';
comment on column FACT_DEMO_GENERAL_HOUR.serverid
  is '����';
comment on column FACT_DEMO_GENERAL_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_DEMO_GENERAL_HOUR.appid
  is '��Ʒid';
comment on column FACT_DEMO_GENERAL_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_GENERAL_HOUR.newcount
  is '������';
comment on column FACT_DEMO_GENERAL_HOUR.conncount
  is '������';
comment on column FACT_DEMO_GENERAL_HOUR.paycount
  is '������';
comment on column FACT_DEMO_GENERAL_HOUR.payamount
  is '���ѽ��';
comment on column FACT_DEMO_GENERAL_HOUR.data_source
  is '������Դ';
create index IDX34_DEMO on FACT_DEMO_GENERAL_HOUR (CHANNELID);
create index IDX35_DEMO on FACT_DEMO_GENERAL_HOUR (SERVERID);
create index IDX36_DEMO on FACT_DEMO_GENERAL_HOUR (STATDATE);

prompt
prompt Creating table FACT_DEMO_GENERAL_HOUR_DVID
prompt ==========================================
prompt
create table FACT_DEMO_GENERAL_HOUR_DVID
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_GENERAL_HOUR_DVID
  is 'Сʱ�豸����������';
comment on column FACT_DEMO_GENERAL_HOUR_DVID.statdate
  is 'ͳ������';
comment on column FACT_DEMO_GENERAL_HOUR_DVID.channelid
  is '����';
comment on column FACT_DEMO_GENERAL_HOUR_DVID.appid
  is '��Ʒid';
comment on column FACT_DEMO_GENERAL_HOUR_DVID.newcount
  is '������';
comment on column FACT_DEMO_GENERAL_HOUR_DVID.conncount
  is '������';
comment on column FACT_DEMO_GENERAL_HOUR_DVID.data_source
  is '������Դ';
create index IDX37_DEMO on FACT_DEMO_GENERAL_HOUR_DVID (CHANNELID);
create index IDX39_DEMO on FACT_DEMO_GENERAL_HOUR_DVID (STATDATE);

prompt
prompt Creating table FACT_DEMO_GENERAL_LEVEL
prompt ======================================
prompt
create table FACT_DEMO_GENERAL_LEVEL
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  rolelevel   NUMBER,
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_GENERAL_LEVEL
  is '�û��ȼ�������';
comment on column FACT_DEMO_GENERAL_LEVEL.statdate
  is 'ͳ������';
comment on column FACT_DEMO_GENERAL_LEVEL.channelid
  is '����';
comment on column FACT_DEMO_GENERAL_LEVEL.serverid
  is '����';
comment on column FACT_DEMO_GENERAL_LEVEL.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_DEMO_GENERAL_LEVEL.appid
  is '��Ʒid';
comment on column FACT_DEMO_GENERAL_LEVEL.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_GENERAL_LEVEL.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_DEMO_GENERAL_LEVEL.newcount
  is '������';
comment on column FACT_DEMO_GENERAL_LEVEL.conncount
  is '������';
comment on column FACT_DEMO_GENERAL_LEVEL.paycount
  is '������';
comment on column FACT_DEMO_GENERAL_LEVEL.payamount
  is '���ѽ��';
comment on column FACT_DEMO_GENERAL_LEVEL.data_source
  is '������Դ';
create index IDX40_DEMO on FACT_DEMO_GENERAL_LEVEL (CHANNELID);
create index IDX41_DEMO on FACT_DEMO_GENERAL_LEVEL (SERVERID);
create index IDX42_DEMO on FACT_DEMO_GENERAL_LEVEL (STATDATE);

prompt
prompt Creating table FACT_DEMO_GENERAL_MONTH
prompt ======================================
prompt
create table FACT_DEMO_GENERAL_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_GENERAL_MONTH
  is '�»���������';
comment on column FACT_DEMO_GENERAL_MONTH.statdate
  is 'ͳ������';
comment on column FACT_DEMO_GENERAL_MONTH.channelid
  is '����';
comment on column FACT_DEMO_GENERAL_MONTH.serverid
  is '����';
comment on column FACT_DEMO_GENERAL_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_DEMO_GENERAL_MONTH.appid
  is '��Ʒid';
comment on column FACT_DEMO_GENERAL_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_GENERAL_MONTH.newcount
  is '������';
comment on column FACT_DEMO_GENERAL_MONTH.conncount
  is '������';
comment on column FACT_DEMO_GENERAL_MONTH.paycount
  is '������';
comment on column FACT_DEMO_GENERAL_MONTH.payamount
  is '���ѽ��';
comment on column FACT_DEMO_GENERAL_MONTH.data_source
  is '������Դ';
create index IDX43_DEMO on FACT_DEMO_GENERAL_MONTH (CHANNELID);
create index IDX44_DEMO on FACT_DEMO_GENERAL_MONTH (SERVERID);
create index IDX45_DEMO on FACT_DEMO_GENERAL_MONTH (STATDATE);

prompt
prompt Creating table FACT_DEMO_GENERAL_MONTH_DVID
prompt ===========================================
prompt
create table FACT_DEMO_GENERAL_MONTH_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_GENERAL_MONTH_DVID
  is '���豸����������';
comment on column FACT_DEMO_GENERAL_MONTH_DVID.statdate
  is 'ͳ������';
comment on column FACT_DEMO_GENERAL_MONTH_DVID.channelid
  is '����';
comment on column FACT_DEMO_GENERAL_MONTH_DVID.appid
  is '��Ʒid';
comment on column FACT_DEMO_GENERAL_MONTH_DVID.newcount
  is '������';
comment on column FACT_DEMO_GENERAL_MONTH_DVID.conncount
  is '������';
comment on column FACT_DEMO_GENERAL_MONTH_DVID.data_source
  is '������Դ';
create index IDX46_DEMO on FACT_DEMO_GENERAL_MONTH_DVID (CHANNELID);
create index IDX48_DEMO on FACT_DEMO_GENERAL_MONTH_DVID (STATDATE);

prompt
prompt Creating table FACT_DEMO_GENERAL_WEEK
prompt =====================================
prompt
create table FACT_DEMO_GENERAL_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_GENERAL_WEEK
  is '�ܻ���������';
comment on column FACT_DEMO_GENERAL_WEEK.statdate
  is 'ͳ������';
comment on column FACT_DEMO_GENERAL_WEEK.channelid
  is '����';
comment on column FACT_DEMO_GENERAL_WEEK.serverid
  is '����';
comment on column FACT_DEMO_GENERAL_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_DEMO_GENERAL_WEEK.appid
  is '��Ʒid';
comment on column FACT_DEMO_GENERAL_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_GENERAL_WEEK.newcount
  is '������';
comment on column FACT_DEMO_GENERAL_WEEK.conncount
  is '������';
comment on column FACT_DEMO_GENERAL_WEEK.paycount
  is '������';
comment on column FACT_DEMO_GENERAL_WEEK.payamount
  is '���ѽ��';
comment on column FACT_DEMO_GENERAL_WEEK.data_source
  is '������Դ';
create index IDX52_DEMO on FACT_DEMO_GENERAL_WEEK (CHANNELID);
create index IDX53_DEMO on FACT_DEMO_GENERAL_WEEK (SERVERID);
create index IDX54_DEMO on FACT_DEMO_GENERAL_WEEK (STATDATE);

prompt
prompt Creating table FACT_DEMO_GENERAL_WEEK_DVID
prompt ==========================================
prompt
create table FACT_DEMO_GENERAL_WEEK_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_GENERAL_WEEK_DVID
  is '���豸����������';
comment on column FACT_DEMO_GENERAL_WEEK_DVID.statdate
  is 'ͳ������';
comment on column FACT_DEMO_GENERAL_WEEK_DVID.channelid
  is '����';
comment on column FACT_DEMO_GENERAL_WEEK_DVID.appid
  is '��Ʒid';
comment on column FACT_DEMO_GENERAL_WEEK_DVID.newcount
  is '������';
comment on column FACT_DEMO_GENERAL_WEEK_DVID.conncount
  is '������';
comment on column FACT_DEMO_GENERAL_WEEK_DVID.data_source
  is '������Դ';
create index IDX49_DEMO on FACT_DEMO_GENERAL_WEEK_DVID (CHANNELID);
create index IDX51_DEMO on FACT_DEMO_GENERAL_WEEK_DVID (STATDATE);

prompt
prompt Creating table FACT_DEMO_HOUR_REPORT
prompt ====================================
prompt
create table FACT_DEMO_HOUR_REPORT
(
  statdate    VARCHAR2(20),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_HOUR_REPORT
  is '�ձ�Сʱ����';
comment on column FACT_DEMO_HOUR_REPORT.statdate
  is 'ͳ������';
comment on column FACT_DEMO_HOUR_REPORT.appid
  is '��ƷID';
comment on column FACT_DEMO_HOUR_REPORT.channelid
  is '����';
comment on column FACT_DEMO_HOUR_REPORT.serverid
  is '����';
comment on column FACT_DEMO_HOUR_REPORT.indexid
  is 'ָ��';
comment on column FACT_DEMO_HOUR_REPORT.indtype
  is 'ָ������';
comment on column FACT_DEMO_HOUR_REPORT.rpt_data
  is '����';

prompt
prompt Creating table FACT_DEMO_LEVELPAY
prompt =================================
prompt
create table FACT_DEMO_LEVELPAY
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  datatype       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  rolelevel      NUMBER,
  paycount       NUMBER,
  first_paycount NUMBER,
  loaddate       DATE default Sysdate,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_DEMO_LEVELPAY
  is '�û���ɫ�ȼ����ѷ�����';
comment on column FACT_DEMO_LEVELPAY.statdate
  is 'ͳ������';
comment on column FACT_DEMO_LEVELPAY.channelid
  is '����';
comment on column FACT_DEMO_LEVELPAY.serverid
  is '����';
comment on column FACT_DEMO_LEVELPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_DEMO_LEVELPAY.appid
  is '��Ʒid';
comment on column FACT_DEMO_LEVELPAY.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_LEVELPAY.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_DEMO_LEVELPAY.paycount
  is '�����û���';
comment on column FACT_DEMO_LEVELPAY.first_paycount
  is '���������û������״θ����û���';
comment on column FACT_DEMO_LEVELPAY.data_source
  is '������Դ';
create index IDX55_DEMO on FACT_DEMO_LEVELPAY (CHANNELID);
create index IDX56_DEMO on FACT_DEMO_LEVELPAY (SERVERID);
create index IDX57_DEMO on FACT_DEMO_LEVELPAY (STATDATE);

prompt
prompt Creating table FACT_DEMO_LOST_MAC
prompt =================================
prompt
create table FACT_DEMO_LOST_MAC
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_LOST_MAC
  is '�豸��ʧ������';
comment on column FACT_DEMO_LOST_MAC.statdate
  is 'ͳ������';
comment on column FACT_DEMO_LOST_MAC.lostdate
  is '��ʧ����';
comment on column FACT_DEMO_LOST_MAC.channelid
  is '����ID';
comment on column FACT_DEMO_LOST_MAC.serverid
  is '����ID';
comment on column FACT_DEMO_LOST_MAC.appid
  is '��ƷID';
comment on column FACT_DEMO_LOST_MAC.rolelevel
  is '��ʧʱ�ȼ�';
comment on column FACT_DEMO_LOST_MAC.lost_days
  is '��ʧ����';
comment on column FACT_DEMO_LOST_MAC.lost_conn
  is '��Ծ�豸��ʧ';
comment on column FACT_DEMO_LOST_MAC.lost_pay
  is '�����豸��ʧ';
comment on column FACT_DEMO_LOST_MAC.data_source
  is '����Դ';
create index IDX58_DEMO on FACT_DEMO_LOST_MAC (CHANNELID);
create index IDX59_DEMO on FACT_DEMO_LOST_MAC (SERVERID);
create index IDX60_DEMO on FACT_DEMO_LOST_MAC (STATDATE);

prompt
prompt Creating table FACT_DEMO_LOST_USER
prompt ==================================
prompt
create table FACT_DEMO_LOST_USER
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_LOST_USER
  is '�û���ʧ������';
comment on column FACT_DEMO_LOST_USER.statdate
  is 'ͳ������';
comment on column FACT_DEMO_LOST_USER.lostdate
  is '��ʧ����';
comment on column FACT_DEMO_LOST_USER.channelid
  is '����ID';
comment on column FACT_DEMO_LOST_USER.serverid
  is '����ID';
comment on column FACT_DEMO_LOST_USER.appid
  is '��ƷID';
comment on column FACT_DEMO_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column FACT_DEMO_LOST_USER.lost_days
  is '��ʧ����';
comment on column FACT_DEMO_LOST_USER.lost_conn
  is '��Ծ�û���ʧ';
comment on column FACT_DEMO_LOST_USER.lost_pay
  is '�����û���ʧ';
comment on column FACT_DEMO_LOST_USER.data_source
  is '����Դ';
create index IDX61_DEMO on FACT_DEMO_LOST_USER (CHANNELID);
create index IDX62_DEMO on FACT_DEMO_LOST_USER (SERVERID);
create index IDX63_DEMO on FACT_DEMO_LOST_USER (STATDATE);

prompt
prompt Creating table FACT_DEMO_LTV_MAC
prompt ================================
prompt
create table FACT_DEMO_LTV_MAC
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_LTV_MAC
  is '�豸LTV������';
comment on column FACT_DEMO_LTV_MAC.statdate
  is 'ͳ������';
comment on column FACT_DEMO_LTV_MAC.ltvdate
  is '��ֵ����';
comment on column FACT_DEMO_LTV_MAC.channelid
  is '����';
comment on column FACT_DEMO_LTV_MAC.serverid
  is '����';
comment on column FACT_DEMO_LTV_MAC.appid
  is '��Ʒid';
comment on column FACT_DEMO_LTV_MAC.ltv_days
  is 'ltv��';
comment on column FACT_DEMO_LTV_MAC.payamount
  is '���ѽ��';
comment on column FACT_DEMO_LTV_MAC.data_source
  is '������Դ';
create index IDX64_DEMO on FACT_DEMO_LTV_MAC (CHANNELID);
create index IDX65_DEMO on FACT_DEMO_LTV_MAC (SERVERID);
create index IDX66_DEMO on FACT_DEMO_LTV_MAC (STATDATE);

prompt
prompt Creating table FACT_DEMO_LTV_USER
prompt =================================
prompt
create table FACT_DEMO_LTV_USER
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_LTV_USER
  is '�û�LTV������';
comment on column FACT_DEMO_LTV_USER.statdate
  is 'ͳ������';
comment on column FACT_DEMO_LTV_USER.ltvdate
  is '��ֵ����';
comment on column FACT_DEMO_LTV_USER.channelid
  is '����';
comment on column FACT_DEMO_LTV_USER.serverid
  is '����';
comment on column FACT_DEMO_LTV_USER.appid
  is '��Ʒid';
comment on column FACT_DEMO_LTV_USER.ltv_days
  is 'ltv��';
comment on column FACT_DEMO_LTV_USER.payamount
  is '���ѽ��';
comment on column FACT_DEMO_LTV_USER.data_source
  is '������Դ';
create index IDX67_DEMO on FACT_DEMO_LTV_USER (CHANNELID);
create index IDX68_DEMO on FACT_DEMO_LTV_USER (SERVERID);
create index IDX69_DEMO on FACT_DEMO_LTV_USER (STATDATE);

prompt
prompt Creating table FACT_DEMO_MISS_FIRST
prompt ===================================
prompt
create table FACT_DEMO_MISS_FIRST
(
  statdate        VARCHAR2(10),
  channelid       VARCHAR2(50),
  serverid        VARCHAR2(50),
  appid           VARCHAR2(50),
  versionid       VARCHAR2(50),
  missionid       VARCHAR2(50),
  rolelevel       NUMBER,
  rolejob         VARCHAR2(50) default '0',
  firstenter_succ NUMBER,
  firstenter_fail NUMBER,
  loaddate        DATE,
  data_source     VARCHAR2(100)
)
;
comment on table FACT_DEMO_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column FACT_DEMO_MISS_FIRST.statdate
  is 'ͳ������';
comment on column FACT_DEMO_MISS_FIRST.channelid
  is '����';
comment on column FACT_DEMO_MISS_FIRST.serverid
  is '����';
comment on column FACT_DEMO_MISS_FIRST.appid
  is '��ƷID';
comment on column FACT_DEMO_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_MISS_FIRST.missionid
  is '�ؿ�ID';
comment on column FACT_DEMO_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column FACT_DEMO_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column FACT_DEMO_MISS_FIRST.firstenter_succ
  is '��һ�ν���ؿ��ɹ���';
comment on column FACT_DEMO_MISS_FIRST.firstenter_fail
  is '��һ�ν���ؿ�ʧ����';
comment on column FACT_DEMO_MISS_FIRST.data_source
  is '������Դ';
create index IDX70_DEMO on FACT_DEMO_MISS_FIRST (CHANNELID);
create index IDX71_DEMO on FACT_DEMO_MISS_FIRST (SERVERID);
create index IDX72_DEMO on FACT_DEMO_MISS_FIRST (STATDATE);

prompt
prompt Creating table FACT_DEMO_NET
prompt ============================
prompt
create table FACT_DEMO_NET
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_net    VARCHAR2(50),
  conncount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_NET
  is '������ʽ������';
comment on column FACT_DEMO_NET.statdate
  is 'ͳ������';
comment on column FACT_DEMO_NET.channelid
  is '����';
comment on column FACT_DEMO_NET.serverid
  is '����';
comment on column FACT_DEMO_NET.appid
  is '��Ʒid';
comment on column FACT_DEMO_NET.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_NET.dvid_net
  is '������ʽ';
comment on column FACT_DEMO_NET.conncount
  is '������';
comment on column FACT_DEMO_NET.data_source
  is '������Դ';
create index IDX73_DEMO on FACT_DEMO_NET (CHANNELID);
create index IDX74_DEMO on FACT_DEMO_NET (SERVERID);
create index IDX75_DEMO on FACT_DEMO_NET (STATDATE);

prompt
prompt Creating table FACT_DEMO_OPERATOR
prompt =================================
prompt
create table FACT_DEMO_OPERATOR
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  dvid_operator VARCHAR2(50),
  conncount     NUMBER,
  loaddate      DATE default Sysdate,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_DEMO_OPERATOR
  is '��Ӫ�̷�����';
comment on column FACT_DEMO_OPERATOR.statdate
  is 'ͳ������';
comment on column FACT_DEMO_OPERATOR.channelid
  is '����';
comment on column FACT_DEMO_OPERATOR.serverid
  is '����';
comment on column FACT_DEMO_OPERATOR.appid
  is '��Ʒid';
comment on column FACT_DEMO_OPERATOR.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_OPERATOR.dvid_operator
  is '������ʽ';
comment on column FACT_DEMO_OPERATOR.conncount
  is '������';
comment on column FACT_DEMO_OPERATOR.data_source
  is '������Դ';
create index IDX76_DEMO on FACT_DEMO_OPERATOR (CHANNELID);
create index IDX77_DEMO on FACT_DEMO_OPERATOR (SERVERID);
create index IDX78_DEMO on FACT_DEMO_OPERATOR (STATDATE);

prompt
prompt Creating table FACT_DEMO_ORDER
prompt ==============================
prompt
create table FACT_DEMO_ORDER
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default Sysdate,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_DEMO_ORDER
  is '����������';
comment on column FACT_DEMO_ORDER.statdate
  is 'ͳ������';
comment on column FACT_DEMO_ORDER.channelid
  is '����';
comment on column FACT_DEMO_ORDER.serverid
  is '����';
comment on column FACT_DEMO_ORDER.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_DEMO_ORDER.appid
  is '��Ʒid';
comment on column FACT_DEMO_ORDER.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_ORDER.paysucccount
  is '�ɹ�������';
comment on column FACT_DEMO_ORDER.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_DEMO_ORDER.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_DEMO_ORDER.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_DEMO_ORDER.paysuccnum
  is '�����ɹ�����';
comment on column FACT_DEMO_ORDER.payfailnum
  is '����ʧ������';
comment on column FACT_DEMO_ORDER.data_source
  is '������Դ';
create index IDX79_DEMO on FACT_DEMO_ORDER (CHANNELID);
create index IDX80_DEMO on FACT_DEMO_ORDER (SERVERID);
create index IDX81_DEMO on FACT_DEMO_ORDER (STATDATE);

prompt
prompt Creating table FACT_DEMO_ORDER_HOUR
prompt ===================================
prompt
create table FACT_DEMO_ORDER_HOUR
(
  statdate      VARCHAR2(20),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_DEMO_ORDER_HOUR
  is '����Сʱ������';
comment on column FACT_DEMO_ORDER_HOUR.statdate
  is 'ͳ������';
comment on column FACT_DEMO_ORDER_HOUR.channelid
  is '����';
comment on column FACT_DEMO_ORDER_HOUR.serverid
  is '����';
comment on column FACT_DEMO_ORDER_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_DEMO_ORDER_HOUR.appid
  is '��Ʒid';
comment on column FACT_DEMO_ORDER_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_ORDER_HOUR.paysucccount
  is '�ɹ�������';
comment on column FACT_DEMO_ORDER_HOUR.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_DEMO_ORDER_HOUR.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_DEMO_ORDER_HOUR.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_DEMO_ORDER_HOUR.paysuccnum
  is '�����ɹ�����';
comment on column FACT_DEMO_ORDER_HOUR.payfailnum
  is '����ʧ������';
comment on column FACT_DEMO_ORDER_HOUR.data_source
  is '������Դ';
create index IDX177_DEMO on FACT_DEMO_ORDER_HOUR (CHANNELID);
create index IDX178_DEMO on FACT_DEMO_ORDER_HOUR (SERVERID);
create index IDX179_DEMO on FACT_DEMO_ORDER_HOUR (STATDATE);

prompt
prompt Creating table FACT_DEMO_ORDER_MONTH
prompt ====================================
prompt
create table FACT_DEMO_ORDER_MONTH
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_DEMO_ORDER_MONTH
  is '�¶���������';
comment on column FACT_DEMO_ORDER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_DEMO_ORDER_MONTH.channelid
  is '����';
comment on column FACT_DEMO_ORDER_MONTH.serverid
  is '����';
comment on column FACT_DEMO_ORDER_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_DEMO_ORDER_MONTH.appid
  is '��Ʒid';
comment on column FACT_DEMO_ORDER_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_ORDER_MONTH.paysucccount
  is '�ɹ�������';
comment on column FACT_DEMO_ORDER_MONTH.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_DEMO_ORDER_MONTH.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_DEMO_ORDER_MONTH.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_DEMO_ORDER_MONTH.paysuccnum
  is '�����ɹ�����';
comment on column FACT_DEMO_ORDER_MONTH.payfailnum
  is '����ʧ������';
comment on column FACT_DEMO_ORDER_MONTH.data_source
  is '������Դ';
create index IDX191_DEMO on FACT_DEMO_ORDER_MONTH (CHANNELID);
create index IDX192_DEMO on FACT_DEMO_ORDER_MONTH (SERVERID);
create index IDX193_DEMO on FACT_DEMO_ORDER_MONTH (STATDATE);

prompt
prompt Creating table FACT_DEMO_ORDER_WEEK
prompt ===================================
prompt
create table FACT_DEMO_ORDER_WEEK
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_DEMO_ORDER_WEEK
  is '�ܶ���������';
comment on column FACT_DEMO_ORDER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_DEMO_ORDER_WEEK.channelid
  is '����';
comment on column FACT_DEMO_ORDER_WEEK.serverid
  is '����';
comment on column FACT_DEMO_ORDER_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_DEMO_ORDER_WEEK.appid
  is '��Ʒid';
comment on column FACT_DEMO_ORDER_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_ORDER_WEEK.paysucccount
  is '�ɹ�������';
comment on column FACT_DEMO_ORDER_WEEK.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_DEMO_ORDER_WEEK.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_DEMO_ORDER_WEEK.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_DEMO_ORDER_WEEK.paysuccnum
  is '�����ɹ�����';
comment on column FACT_DEMO_ORDER_WEEK.payfailnum
  is '����ʧ������';
comment on column FACT_DEMO_ORDER_WEEK.data_source
  is '������Դ';
create index IDX188_DEMO on FACT_DEMO_ORDER_WEEK (CHANNELID);
create index IDX189_DEMO on FACT_DEMO_ORDER_WEEK (SERVERID);
create index IDX190_DEMO on FACT_DEMO_ORDER_WEEK (STATDATE);

prompt
prompt Creating table FACT_DEMO_PAYAMOUNT_DAY
prompt ======================================
prompt
create table FACT_DEMO_PAYAMOUNT_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_PAYAMOUNT_DAY
  is '�ճ�ֵ��������';
comment on column FACT_DEMO_PAYAMOUNT_DAY.statdate
  is 'ͳ������';
comment on column FACT_DEMO_PAYAMOUNT_DAY.channelid
  is '����';
comment on column FACT_DEMO_PAYAMOUNT_DAY.serverid
  is '����';
comment on column FACT_DEMO_PAYAMOUNT_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_DEMO_PAYAMOUNT_DAY.appid
  is '��Ʒid';
comment on column FACT_DEMO_PAYAMOUNT_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_PAYAMOUNT_DAY.payamount
  is '��ֵ��ȡ����';
comment on column FACT_DEMO_PAYAMOUNT_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_DEMO_PAYAMOUNT_DAY.data_source
  is '������Դ';
create index IDX82_DEMO on FACT_DEMO_PAYAMOUNT_DAY (CHANNELID);
create index IDX83_DEMO on FACT_DEMO_PAYAMOUNT_DAY (SERVERID);
create index IDX84_DEMO on FACT_DEMO_PAYAMOUNT_DAY (STATDATE);

prompt
prompt Creating table FACT_DEMO_PAYAMOUNT_MONTH
prompt ========================================
prompt
create table FACT_DEMO_PAYAMOUNT_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_PAYAMOUNT_MONTH
  is '�³�ֵ��������';
comment on column FACT_DEMO_PAYAMOUNT_MONTH.statdate
  is 'ͳ������';
comment on column FACT_DEMO_PAYAMOUNT_MONTH.channelid
  is '����';
comment on column FACT_DEMO_PAYAMOUNT_MONTH.serverid
  is '����';
comment on column FACT_DEMO_PAYAMOUNT_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_DEMO_PAYAMOUNT_MONTH.appid
  is '��Ʒid';
comment on column FACT_DEMO_PAYAMOUNT_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_PAYAMOUNT_MONTH.payamount
  is '��ֵ��ȡ����';
comment on column FACT_DEMO_PAYAMOUNT_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_DEMO_PAYAMOUNT_MONTH.data_source
  is '������Դ';
create index IDX88_DEMO on FACT_DEMO_PAYAMOUNT_MONTH (CHANNELID);
create index IDX89_DEMO on FACT_DEMO_PAYAMOUNT_MONTH (SERVERID);
create index IDX90_DEMO on FACT_DEMO_PAYAMOUNT_MONTH (STATDATE);

prompt
prompt Creating table FACT_DEMO_PAYAMOUNT_WEEK
prompt =======================================
prompt
create table FACT_DEMO_PAYAMOUNT_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_PAYAMOUNT_WEEK
  is '�ܳ�ֵ��������';
comment on column FACT_DEMO_PAYAMOUNT_WEEK.statdate
  is 'ͳ������';
comment on column FACT_DEMO_PAYAMOUNT_WEEK.channelid
  is '����';
comment on column FACT_DEMO_PAYAMOUNT_WEEK.serverid
  is '����';
comment on column FACT_DEMO_PAYAMOUNT_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_DEMO_PAYAMOUNT_WEEK.appid
  is '��Ʒid';
comment on column FACT_DEMO_PAYAMOUNT_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_PAYAMOUNT_WEEK.payamount
  is '��ֵ��ȡ����';
comment on column FACT_DEMO_PAYAMOUNT_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_DEMO_PAYAMOUNT_WEEK.data_source
  is '������Դ';
create index IDX85_DEMO on FACT_DEMO_PAYAMOUNT_WEEK (CHANNELID);
create index IDX86_DEMO on FACT_DEMO_PAYAMOUNT_WEEK (SERVERID);
create index IDX87_DEMO on FACT_DEMO_PAYAMOUNT_WEEK (STATDATE);

prompt
prompt Creating table FACT_DEMO_PAYNUM_DAY
prompt ===================================
prompt
create table FACT_DEMO_PAYNUM_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_PAYNUM_DAY
  is '�ճ�ֵ����������';
comment on column FACT_DEMO_PAYNUM_DAY.statdate
  is 'ͳ������';
comment on column FACT_DEMO_PAYNUM_DAY.channelid
  is '����';
comment on column FACT_DEMO_PAYNUM_DAY.serverid
  is '����';
comment on column FACT_DEMO_PAYNUM_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_DEMO_PAYNUM_DAY.appid
  is '��Ʒid';
comment on column FACT_DEMO_PAYNUM_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_PAYNUM_DAY.paynum
  is '��ֵ����';
comment on column FACT_DEMO_PAYNUM_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_DEMO_PAYNUM_DAY.data_source
  is '������Դ';
create index IDX97_DEMO on FACT_DEMO_PAYNUM_DAY (CHANNELID);
create index IDX98_DEMO on FACT_DEMO_PAYNUM_DAY (SERVERID);
create index IDX99_DEMO on FACT_DEMO_PAYNUM_DAY (STATDATE);

prompt
prompt Creating table FACT_DEMO_PAYNUM_MONTH
prompt =====================================
prompt
create table FACT_DEMO_PAYNUM_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_PAYNUM_MONTH
  is '�³�ֵ����������';
comment on column FACT_DEMO_PAYNUM_MONTH.statdate
  is 'ͳ������';
comment on column FACT_DEMO_PAYNUM_MONTH.channelid
  is '����';
comment on column FACT_DEMO_PAYNUM_MONTH.serverid
  is '����';
comment on column FACT_DEMO_PAYNUM_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_DEMO_PAYNUM_MONTH.appid
  is '��Ʒid';
comment on column FACT_DEMO_PAYNUM_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_PAYNUM_MONTH.paynum
  is '��ֵ����';
comment on column FACT_DEMO_PAYNUM_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_DEMO_PAYNUM_MONTH.data_source
  is '������Դ';
create index IDX91_DEMO on FACT_DEMO_PAYNUM_MONTH (CHANNELID);
create index IDX92_DEMO on FACT_DEMO_PAYNUM_MONTH (SERVERID);
create index IDX93_DEMO on FACT_DEMO_PAYNUM_MONTH (STATDATE);

prompt
prompt Creating table FACT_DEMO_PAYNUM_WEEK
prompt ====================================
prompt
create table FACT_DEMO_PAYNUM_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_PAYNUM_WEEK
  is '�ܳ�ֵ����������';
comment on column FACT_DEMO_PAYNUM_WEEK.statdate
  is 'ͳ������';
comment on column FACT_DEMO_PAYNUM_WEEK.channelid
  is '����';
comment on column FACT_DEMO_PAYNUM_WEEK.serverid
  is '����';
comment on column FACT_DEMO_PAYNUM_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_DEMO_PAYNUM_WEEK.appid
  is '��Ʒid';
comment on column FACT_DEMO_PAYNUM_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_PAYNUM_WEEK.paynum
  is '��ֵ����';
comment on column FACT_DEMO_PAYNUM_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_DEMO_PAYNUM_WEEK.data_source
  is '������Դ';
create index IDX94_DEMO on FACT_DEMO_PAYNUM_WEEK (CHANNELID);
create index IDX95_DEMO on FACT_DEMO_PAYNUM_WEEK (SERVERID);
create index IDX96_DEMO on FACT_DEMO_PAYNUM_WEEK (STATDATE);

prompt
prompt Creating table FACT_DEMO_PAYTYPE
prompt ================================
prompt
create table FACT_DEMO_PAYTYPE
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paytypeid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_PAYTYPE
  is '��ֵ���ͷ�����';
comment on column FACT_DEMO_PAYTYPE.statdate
  is 'ͳ������';
comment on column FACT_DEMO_PAYTYPE.channelid
  is '����';
comment on column FACT_DEMO_PAYTYPE.serverid
  is '����';
comment on column FACT_DEMO_PAYTYPE.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_DEMO_PAYTYPE.appid
  is '��Ʒid';
comment on column FACT_DEMO_PAYTYPE.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_PAYTYPE.paytypeid
  is '��ֵ����';
comment on column FACT_DEMO_PAYTYPE.payamount
  is '��ֵ���';
comment on column FACT_DEMO_PAYTYPE.paycount
  is '��ֵ����';
comment on column FACT_DEMO_PAYTYPE.paynum
  is '��ֵ����';
comment on column FACT_DEMO_PAYTYPE.data_source
  is '������Դ';
create index IDX100_DEMO on FACT_DEMO_PAYTYPE (CHANNELID);
create index IDX101_DEMO on FACT_DEMO_PAYTYPE (SERVERID);
create index IDX102_DEMO on FACT_DEMO_PAYTYPE (STATDATE);

prompt
prompt Creating table FACT_DEMO_PAYWAY
prompt ===============================
prompt
create table FACT_DEMO_PAYWAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paywayid    VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_PAYWAY
  is '��ֵ��ʽ������';
comment on column FACT_DEMO_PAYWAY.statdate
  is 'ͳ������';
comment on column FACT_DEMO_PAYWAY.channelid
  is '����';
comment on column FACT_DEMO_PAYWAY.serverid
  is '����';
comment on column FACT_DEMO_PAYWAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_DEMO_PAYWAY.appid
  is '��Ʒid';
comment on column FACT_DEMO_PAYWAY.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_PAYWAY.paywayid
  is '��ֵ��ʽ';
comment on column FACT_DEMO_PAYWAY.payamount
  is '��ֵ���';
comment on column FACT_DEMO_PAYWAY.paycount
  is '��ֵ����';
comment on column FACT_DEMO_PAYWAY.paynum
  is '��ֵ����';
comment on column FACT_DEMO_PAYWAY.data_source
  is '������Դ';
create index IDX103_DEMO on FACT_DEMO_PAYWAY (CHANNELID);
create index IDX104_DEMO on FACT_DEMO_PAYWAY (SERVERID);
create index IDX105_DEMO on FACT_DEMO_PAYWAY (STATDATE);

prompt
prompt Creating table FACT_DEMO_REGION
prompt ===============================
prompt
create table FACT_DEMO_REGION
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  country     VARCHAR2(50),
  province    VARCHAR2(50),
  city        VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_REGION
  is '���������';
comment on column FACT_DEMO_REGION.statdate
  is 'ͳ������';
comment on column FACT_DEMO_REGION.channelid
  is '����';
comment on column FACT_DEMO_REGION.serverid
  is '����';
comment on column FACT_DEMO_REGION.appid
  is '��Ʒid';
comment on column FACT_DEMO_REGION.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_REGION.country
  is '����';
comment on column FACT_DEMO_REGION.province
  is 'ʡ';
comment on column FACT_DEMO_REGION.city
  is '��';
comment on column FACT_DEMO_REGION.newcount
  is '������';
comment on column FACT_DEMO_REGION.conncount
  is '������';
comment on column FACT_DEMO_REGION.paycount
  is '������';
comment on column FACT_DEMO_REGION.payamount
  is '���ѽ��';
comment on column FACT_DEMO_REGION.data_source
  is '������Դ';
create index IDX106_DEMO on FACT_DEMO_REGION (CHANNELID);
create index IDX107_DEMO on FACT_DEMO_REGION (SERVERID);
create index IDX108_DEMO on FACT_DEMO_REGION (STATDATE);

prompt
prompt Creating table FACT_DEMO_REMAIN_MAC
prompt ===================================
prompt
create table FACT_DEMO_REMAIN_MAC
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_REMAIN_MAC
  is '�豸�����';
comment on column FACT_DEMO_REMAIN_MAC.statdate
  is 'ͳ������';
comment on column FACT_DEMO_REMAIN_MAC.conndate
  is '��������';
comment on column FACT_DEMO_REMAIN_MAC.channelid
  is '����ID';
comment on column FACT_DEMO_REMAIN_MAC.serverid
  is '����ID';
comment on column FACT_DEMO_REMAIN_MAC.appid
  is '��ƷID';
comment on column FACT_DEMO_REMAIN_MAC.remain_days
  is '��������';
comment on column FACT_DEMO_REMAIN_MAC.new_remain
  is '��������';
comment on column FACT_DEMO_REMAIN_MAC.conn_remain
  is '��������';
comment on column FACT_DEMO_REMAIN_MAC.pay_remain
  is '��������';
comment on column FACT_DEMO_REMAIN_MAC.data_source
  is '����Դ';
create index IDX109_DEMO on FACT_DEMO_REMAIN_MAC (CHANNELID);
create index IDX110_DEMO on FACT_DEMO_REMAIN_MAC (SERVERID);
create index IDX111_DEMO on FACT_DEMO_REMAIN_MAC (STATDATE);

prompt
prompt Creating table FACT_DEMO_REMAIN_USER
prompt ====================================
prompt
create table FACT_DEMO_REMAIN_USER
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_REMAIN_USER
  is '�û������';
comment on column FACT_DEMO_REMAIN_USER.statdate
  is 'ͳ������';
comment on column FACT_DEMO_REMAIN_USER.conndate
  is '��������';
comment on column FACT_DEMO_REMAIN_USER.channelid
  is '����ID';
comment on column FACT_DEMO_REMAIN_USER.serverid
  is '����ID';
comment on column FACT_DEMO_REMAIN_USER.appid
  is '��ƷID';
comment on column FACT_DEMO_REMAIN_USER.remain_days
  is '��������';
comment on column FACT_DEMO_REMAIN_USER.new_remain
  is '��������';
comment on column FACT_DEMO_REMAIN_USER.conn_remain
  is '��������';
comment on column FACT_DEMO_REMAIN_USER.pay_remain
  is '��������';
comment on column FACT_DEMO_REMAIN_USER.data_source
  is '����Դ';
create index IDX112_DEMO on FACT_DEMO_REMAIN_USER (CHANNELID);
create index IDX113_DEMO on FACT_DEMO_REMAIN_USER (SERVERID);
create index IDX114_DEMO on FACT_DEMO_REMAIN_USER (STATDATE);

prompt
prompt Creating table FACT_DEMO_VC
prompt ===========================
prompt
create table FACT_DEMO_VC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcamount    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_DEMO_VC
  is '������ҷ�����';
comment on column FACT_DEMO_VC.statdate
  is 'ͳ������';
comment on column FACT_DEMO_VC.channelid
  is '����';
comment on column FACT_DEMO_VC.serverid
  is '����';
comment on column FACT_DEMO_VC.appid
  is '��Ʒid';
comment on column FACT_DEMO_VC.versionid
  is '��Ʒ�汾';
comment on column FACT_DEMO_VC.vctype
  is '�����������';
comment on column FACT_DEMO_VC.vcusetype
  is '�������ʹ������';
comment on column FACT_DEMO_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column FACT_DEMO_VC.vcamount
  is '������ҽ��';
comment on column FACT_DEMO_VC.data_source
  is '������Դ';
create index IDX115_DEMO on FACT_DEMO_VC (CHANNELID);
create index IDX116_DEMO on FACT_DEMO_VC (SERVERID);
create index IDX117_DEMO on FACT_DEMO_VC (STATDATE);

prompt
prompt Creating table FACT_FIRM_DVID
prompt =============================
prompt
create table FACT_FIRM_DVID
(
  statdate     VARCHAR2(20) not null,
  date_type    VARCHAR2(2) not null,
  dvid_tpye    VARCHAR2(20) not null,
  channelid    VARCHAR2(20) not null,
  platform     VARCHAR2(20) not null,
  country_type VARCHAR2(20) not null,
  online_type  VARCHAR2(20) not null,
  dvid_data    NUMBER,
  loaddate     DATE default Sysdate,
  data_source  VARCHAR2(100)
)
;
comment on table FACT_FIRM_DVID
  is '��˾�豸������';
comment on column FACT_FIRM_DVID.statdate
  is 'ͳ��ʱ��';
comment on column FACT_FIRM_DVID.date_type
  is 'ʱ������ ''D'' ��,''W'' ��,''M'' ��,''Y'' ��';
comment on column FACT_FIRM_DVID.dvid_tpye
  is '�豸���� 1 ����,2 ����';
comment on column FACT_FIRM_DVID.channelid
  is '����ID';
comment on column FACT_FIRM_DVID.platform
  is 'ƽ̨';
comment on column FACT_FIRM_DVID.country_type
  is '���� ''INTERNAL''������ ''OVERSEAS''';
comment on column FACT_FIRM_DVID.online_type
  is '���� ''ONLINE''������ ''SINGLE''';
comment on column FACT_FIRM_DVID.dvid_data
  is '�豸����';
create index IDX5_FIRM on FACT_FIRM_DVID (CHANNELID);
create index IDX6_FIRM on FACT_FIRM_DVID (STATDATE);

prompt
prompt Creating table FACT_FIRM_SDK_INCOME
prompt ===================================
prompt
create table FACT_FIRM_SDK_INCOME
(
  statdate     VARCHAR2(20) not null,
  date_type    VARCHAR2(2) not null,
  channelid    VARCHAR2(20) not null,
  platform     VARCHAR2(20) not null,
  country_type VARCHAR2(20) not null,
  online_type  VARCHAR2(20) not null,
  amount       NUMBER,
  loaddate     DATE default Sysdate,
  data_source  VARCHAR2(100)
)
;
comment on table FACT_FIRM_SDK_INCOME
  is '��˾SDK���������';
comment on column FACT_FIRM_SDK_INCOME.statdate
  is 'ͳ��ʱ��';
comment on column FACT_FIRM_SDK_INCOME.date_type
  is 'ʱ������ ''D'' ��,''W'' ��,''M'' ��,''Y'' ��';
comment on column FACT_FIRM_SDK_INCOME.channelid
  is '����ID';
comment on column FACT_FIRM_SDK_INCOME.platform
  is 'ƽ̨';
comment on column FACT_FIRM_SDK_INCOME.country_type
  is '���� ''INTERNAL''������ ''OVERSEAS''';
comment on column FACT_FIRM_SDK_INCOME.online_type
  is '���� ''ONLINE''������ ''SINGLE''';
comment on column FACT_FIRM_SDK_INCOME.amount
  is '���루�֣�';
create index IDX8_FIRM on FACT_FIRM_SDK_INCOME (CHANNELID);
create index IDX9_FIRM on FACT_FIRM_SDK_INCOME (STATDATE);

prompt
prompt Creating table FACT_SUM_REP
prompt ===========================
prompt
create table FACT_SUM_REP
(
  statdate       VARCHAR2(20),
  appid          VARCHAR2(20),
  newcount_user  NUMBER,
  newcount_dvid  NUMBER,
  conncount_user NUMBER,
  conncount_dvid NUMBER,
  payamount      NUMBER,
  paycount_user  NUMBER,
  remain1_user   NUMBER,
  first_paycount NUMBER,
  loaddate       DATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_SUM_REP
  is '���в�Ʒ���ܱ���';
comment on column FACT_SUM_REP.statdate
  is 'ͳ������';
comment on column FACT_SUM_REP.appid
  is '��ƷID';
comment on column FACT_SUM_REP.newcount_user
  is '�����û���';
comment on column FACT_SUM_REP.newcount_dvid
  is '�����豸��';
comment on column FACT_SUM_REP.conncount_user
  is '�����û���';
comment on column FACT_SUM_REP.conncount_dvid
  is '�����豸��';
comment on column FACT_SUM_REP.payamount
  is '�����ܶ�';
comment on column FACT_SUM_REP.paycount_user
  is '�����û���';
comment on column FACT_SUM_REP.remain1_user
  is '�����û���������';
comment on column FACT_SUM_REP.first_paycount
  is '���������û���';


spool off
