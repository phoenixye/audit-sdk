------------------------------------------------------------
-- Export file for user DEVELOPER@BI_RACDB1_111.13.20.109 --
-- Created by Administrator on 2015/6/3, 15:00:04 ----------
------------------------------------------------------------

set define off
spool --pakage-fact���岿��.log

prompt
prompt Creating package PKG_FACT_100091
prompt ================================
prompt
CREATE OR REPLACE Package Pkg_Fact_100091 Is
  --����ȫ��
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --����ά����Ϣ
  Procedure p_Dim_Other(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR����
  Procedure p_Fact_General_Hour(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY����
  Procedure p_Fact_General(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_FIRSTPAY����
  Procedure p_Fact_Firstpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_PAYHABIT����
  Procedure p_Fact_Payhabit(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_ORDER����
  Procedure p_Fact_Order(p_Logtime In Varchar2,
                         p_Errcode Out Number,
                         p_Errstr  Out Varchar2);
  --����FACT_REMAIN����
  Procedure p_Fact_Remain(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_LOST����
  Procedure p_Fact_Lost(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_LEVELPAY����
  Procedure p_Fact_Levelpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_GENERAL_LEVEL����
  Procedure p_Fact_General_Level(p_Logtime In Varchar2,
                                 p_Errcode Out Number,
                                 p_Errstr  Out Varchar2);
  --����FACT_LTV����
  Procedure p_Fact_Ltv(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);

  --����FACT_BACK����
  Procedure p_Fact_Back(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_MISS_FIRST����
  Procedure p_Fact_Miss_First(p_Logtime In Varchar2,
                              p_Errcode Out Number,
                              p_Errstr  Out Varchar2);
  --����FACT_DVID����
  Procedure p_Fact_Dvid(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_VC����
  Procedure p_Fact_Vc(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);
  --����FACT_NET����
  Procedure p_Fact_Net(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);
  --����FACT_OPERATOR����
  Procedure p_Fact_Operator(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_REGION����
  Procedure p_Fact_Region(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_SUM_REP����
  Procedure p_Fact_Sum_Rep(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY_DVID����
  Procedure p_Fact_General_Dvid(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR_DVID����
  Procedure p_Fact_General_Hour_Dvid(p_Logtime In Varchar2,
                                     p_Errcode Out Number,
                                     p_Errstr  Out Varchar2);
  --����FACT_CEVENT����
  Procedure p_Fact_Cevent(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_COMP_CEVENT����
  Procedure p_Fact_Comp_Cevent(p_Logtime In Varchar2,
                               p_Errcode Out Number,
                               p_Errstr  Out Varchar2);
  --����FACT_DAILY_REPORT����
  Procedure p_Fact_Daily_Report(p_Logtime In Varchar2 Default To_Char(Sysdate - 1,
                                                                      'YYYY-MM-DD'),
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
End Pkg_Fact_100091;
/

prompt
prompt Creating package PKG_FACT_100105
prompt ================================
prompt
CREATE OR REPLACE Package Pkg_Fact_100105 Is
  --����ȫ��
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --����ά����Ϣ
  Procedure p_Dim_Other(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR����
  Procedure p_Fact_General_Hour(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY����
  Procedure p_Fact_General(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_FIRSTPAY����
  Procedure p_Fact_Firstpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_PAYHABIT����
  Procedure p_Fact_Payhabit(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_ORDER����
  Procedure p_Fact_Order(p_Logtime In Varchar2,
                         p_Errcode Out Number,
                         p_Errstr  Out Varchar2);
  --����FACT_REMAIN����
  Procedure p_Fact_Remain(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_LOST����
  Procedure p_Fact_Lost(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_LEVELPAY����
  Procedure p_Fact_Levelpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_GENERAL_LEVEL����
  Procedure p_Fact_General_Level(p_Logtime In Varchar2,
                                 p_Errcode Out Number,
                                 p_Errstr  Out Varchar2);
  --����FACT_LTV����
  Procedure p_Fact_Ltv(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);

  --����FACT_BACK����
  Procedure p_Fact_Back(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_MISS_FIRST����
  Procedure p_Fact_Miss_First(p_Logtime In Varchar2,
                              p_Errcode Out Number,
                              p_Errstr  Out Varchar2);
  --����FACT_DVID����
  Procedure p_Fact_Dvid(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_VC����
  Procedure p_Fact_Vc(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);
  --����FACT_NET����
  Procedure p_Fact_Net(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);
  --����FACT_OPERATOR����
  Procedure p_Fact_Operator(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_REGION����
  Procedure p_Fact_Region(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_SUM_REP����
  Procedure p_Fact_Sum_Rep(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY_DVID����
  Procedure p_Fact_General_Dvid(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR_DVID����
  Procedure p_Fact_General_Hour_Dvid(p_Logtime In Varchar2,
                                     p_Errcode Out Number,
                                     p_Errstr  Out Varchar2);
  --����FACT_CEVENT����
  Procedure p_Fact_Cevent(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_COMP_CEVENT����
  Procedure p_Fact_Comp_Cevent(p_Logtime In Varchar2,
                               p_Errcode Out Number,
                               p_Errstr  Out Varchar2);
  --����FACT_DAILY_REPORT����                         
  Procedure p_Fact_Daily_Report(p_Logtime In Varchar2 Default To_Char(Sysdate - 1,
                                                                      'YYYY-MM-DD'),
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
End Pkg_Fact_100105;
/

prompt
prompt Creating package PKG_FACT_100131
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FACT_100131" IS
  --����ȫ��
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --����ά����Ϣ
  PROCEDURE P_DIM_OTHER(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR����
  PROCEDURE P_FACT_GENERAL_HOUR(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY����
  PROCEDURE P_FACT_GENERAL(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_FIRSTPAY����
  PROCEDURE P_FACT_FIRSTPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_PAYHABIT����
  PROCEDURE P_FACT_PAYHABIT(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_ORDER����
  PROCEDURE P_FACT_ORDER(P_LOGTIME IN VARCHAR2,
                         P_ERRCODE OUT NUMBER,
                         P_ERRSTR  OUT VARCHAR2);
  --����FACT_REMAIN����
  PROCEDURE P_FACT_REMAIN(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_LOST����
  PROCEDURE P_FACT_LOST(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_LEVELPAY����
  PROCEDURE P_FACT_LEVELPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_LEVEL����
  PROCEDURE P_FACT_GENERAL_LEVEL(P_LOGTIME IN VARCHAR2,
                                 P_ERRCODE OUT NUMBER,
                                 P_ERRSTR  OUT VARCHAR2);
  --����FACT_LTV����
  PROCEDURE P_FACT_LTV(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);

  --����FACT_BACK����
  PROCEDURE P_FACT_BACK(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_MISS_FIRST����
  PROCEDURE P_FACT_MISS_FIRST(P_LOGTIME IN VARCHAR2,
                              P_ERRCODE OUT NUMBER,
                              P_ERRSTR  OUT VARCHAR2);
  --����FACT_DVID����
  PROCEDURE P_FACT_DVID(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_VC����
  PROCEDURE P_FACT_VC(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);
  --����FACT_NET����
  PROCEDURE P_FACT_NET(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);
  --����FACT_OPERATOR����
  PROCEDURE P_FACT_OPERATOR(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_REGION����
  PROCEDURE P_FACT_REGION(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_SUM_REP����
  PROCEDURE P_FACT_SUM_REP(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY_DVID����
  PROCEDURE P_FACT_GENERAL_DVID(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR_DVID����
  PROCEDURE P_FACT_GENERAL_HOUR_DVID(P_LOGTIME IN VARCHAR2,
                                     P_ERRCODE OUT NUMBER,
                                     P_ERRSTR  OUT VARCHAR2);
  --����FACT_CEVENT����
  PROCEDURE P_FACT_CEVENT(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_COMP_CEVENT����
  PROCEDURE P_FACT_COMP_CEVENT(P_LOGTIME IN VARCHAR2,
                               P_ERRCODE OUT NUMBER,
                               P_ERRSTR  OUT VARCHAR2);
  --����FACT_DAILY_REPORT����                         
  PROCEDURE P_FACT_DAILY_REPORT(P_LOGTIME IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE - 1,
                                                                      'YYYY-MM-DD'),
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
END PKG_FACT_100131;
/

prompt
prompt Creating package PKG_FACT_100132
prompt ================================
prompt
CREATE OR REPLACE Package Pkg_Fact_100132 Is
  --����ȫ��
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --����ά����Ϣ
  Procedure p_Dim_Other(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR����
  Procedure p_Fact_General_Hour(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY����
  Procedure p_Fact_General(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_FIRSTPAY����
  Procedure p_Fact_Firstpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_PAYHABIT����
  Procedure p_Fact_Payhabit(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_ORDER����
  Procedure p_Fact_Order(p_Logtime In Varchar2,
                         p_Errcode Out Number,
                         p_Errstr  Out Varchar2);
  --����FACT_REMAIN����
  Procedure p_Fact_Remain(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_LOST����
  Procedure p_Fact_Lost(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_LEVELPAY����
  Procedure p_Fact_Levelpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_GENERAL_LEVEL����
  Procedure p_Fact_General_Level(p_Logtime In Varchar2,
                                 p_Errcode Out Number,
                                 p_Errstr  Out Varchar2);
  --����FACT_LTV����
  Procedure p_Fact_Ltv(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);

  --����FACT_BACK����
  Procedure p_Fact_Back(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_MISS_FIRST����
  Procedure p_Fact_Miss_First(p_Logtime In Varchar2,
                              p_Errcode Out Number,
                              p_Errstr  Out Varchar2);
  --����FACT_DVID����
  Procedure p_Fact_Dvid(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_VC����
  Procedure p_Fact_Vc(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);
  --����FACT_NET����
  Procedure p_Fact_Net(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);
  --����FACT_OPERATOR����
  Procedure p_Fact_Operator(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_REGION����
  Procedure p_Fact_Region(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_SUM_REP����
  Procedure p_Fact_Sum_Rep(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY_DVID����
  Procedure p_Fact_General_Dvid(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR_DVID����
  Procedure p_Fact_General_Hour_Dvid(p_Logtime In Varchar2,
                                     p_Errcode Out Number,
                                     p_Errstr  Out Varchar2);
  --����FACT_CEVENT����
  Procedure p_Fact_Cevent(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_COMP_CEVENT����
  Procedure p_Fact_Comp_Cevent(p_Logtime In Varchar2,
                               p_Errcode Out Number,
                               p_Errstr  Out Varchar2);
  --����FACT_DAILY_REPORT����                         
  Procedure p_Fact_Daily_Report(p_Logtime In Varchar2 Default To_Char(Sysdate - 1,
                                                                      'YYYY-MM-DD'),
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
End Pkg_Fact_100132;
/

prompt
prompt Creating package PKG_FACT_100138
prompt ================================
prompt
CREATE OR REPLACE Package Pkg_Fact_100138 Is
  --����ȫ��
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --����ά����Ϣ
  Procedure p_Dim_Other(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR����
  Procedure p_Fact_General_Hour(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY����
  Procedure p_Fact_General(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_FIRSTPAY����
  Procedure p_Fact_Firstpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_PAYHABIT����
  Procedure p_Fact_Payhabit(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_ORDER����
  Procedure p_Fact_Order(p_Logtime In Varchar2,
                         p_Errcode Out Number,
                         p_Errstr  Out Varchar2);
  --����FACT_REMAIN����
  Procedure p_Fact_Remain(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_LOST����
  Procedure p_Fact_Lost(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_LEVELPAY����
  Procedure p_Fact_Levelpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_GENERAL_LEVEL����
  Procedure p_Fact_General_Level(p_Logtime In Varchar2,
                                 p_Errcode Out Number,
                                 p_Errstr  Out Varchar2);
  --����FACT_LTV����
  Procedure p_Fact_Ltv(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);

  --����FACT_BACK����
  Procedure p_Fact_Back(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_MISS_FIRST����
  Procedure p_Fact_Miss_First(p_Logtime In Varchar2,
                              p_Errcode Out Number,
                              p_Errstr  Out Varchar2);
  --����FACT_DVID����
  Procedure p_Fact_Dvid(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_VC����
  Procedure p_Fact_Vc(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);
  --����FACT_NET����
  Procedure p_Fact_Net(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);
  --����FACT_OPERATOR����
  Procedure p_Fact_Operator(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_REGION����
  Procedure p_Fact_Region(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_SUM_REP����
  Procedure p_Fact_Sum_Rep(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY_DVID����
  Procedure p_Fact_General_Dvid(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR_DVID����
  Procedure p_Fact_General_Hour_Dvid(p_Logtime In Varchar2,
                                     p_Errcode Out Number,
                                     p_Errstr  Out Varchar2);
  --����FACT_CEVENT����
  Procedure p_Fact_Cevent(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_COMP_CEVENT����
  Procedure p_Fact_Comp_Cevent(p_Logtime In Varchar2,
                               p_Errcode Out Number,
                               p_Errstr  Out Varchar2);
  --����FACT_DAILY_REPORT����                         
  Procedure p_Fact_Daily_Report(p_Logtime In Varchar2 Default To_Char(Sysdate - 1,
                                                                      'YYYY-MM-DD'),
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
End Pkg_Fact_100138;
/

prompt
prompt Creating package PKG_FACT_100139
prompt ================================
prompt
CREATE OR REPLACE Package Pkg_Fact_100139 Is
  --����ȫ��
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --����ά����Ϣ
  Procedure p_Dim_Other(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR����
  Procedure p_Fact_General_Hour(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY����
  Procedure p_Fact_General(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_FIRSTPAY����
  Procedure p_Fact_Firstpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_PAYHABIT����
  Procedure p_Fact_Payhabit(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_ORDER����
  Procedure p_Fact_Order(p_Logtime In Varchar2,
                         p_Errcode Out Number,
                         p_Errstr  Out Varchar2);
  --����FACT_REMAIN����
  Procedure p_Fact_Remain(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_LOST����
  Procedure p_Fact_Lost(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_LEVELPAY����
  Procedure p_Fact_Levelpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_GENERAL_LEVEL����
  Procedure p_Fact_General_Level(p_Logtime In Varchar2,
                                 p_Errcode Out Number,
                                 p_Errstr  Out Varchar2);
  --����FACT_LTV����
  Procedure p_Fact_Ltv(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);

  --����FACT_BACK����
  Procedure p_Fact_Back(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_MISS_FIRST����
  Procedure p_Fact_Miss_First(p_Logtime In Varchar2,
                              p_Errcode Out Number,
                              p_Errstr  Out Varchar2);
  --����FACT_DVID����
  Procedure p_Fact_Dvid(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_VC����
  Procedure p_Fact_Vc(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);
  --����FACT_NET����
  Procedure p_Fact_Net(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);
  --����FACT_OPERATOR����
  Procedure p_Fact_Operator(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_REGION����
  Procedure p_Fact_Region(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_SUM_REP����
  Procedure p_Fact_Sum_Rep(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY_DVID����
  Procedure p_Fact_General_Dvid(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR_DVID����
  Procedure p_Fact_General_Hour_Dvid(p_Logtime In Varchar2,
                                     p_Errcode Out Number,
                                     p_Errstr  Out Varchar2);
  --����FACT_CEVENT����
  Procedure p_Fact_Cevent(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_COMP_CEVENT����
  Procedure p_Fact_Comp_Cevent(p_Logtime In Varchar2,
                               p_Errcode Out Number,
                               p_Errstr  Out Varchar2);
  --����FACT_DAILY_REPORT����                         
  Procedure p_Fact_Daily_Report(p_Logtime In Varchar2 Default To_Char(Sysdate - 1,
                                                                      'YYYY-MM-DD'),
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
End Pkg_Fact_100139;
/

prompt
prompt Creating package PKG_FACT_100150
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FACT_100150" IS
  --����ȫ��
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --����ά����Ϣ
  PROCEDURE P_DIM_OTHER(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR����
  PROCEDURE P_FACT_GENERAL_HOUR(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY����
  PROCEDURE P_FACT_GENERAL(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_FIRSTPAY����
  PROCEDURE P_FACT_FIRSTPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_PAYHABIT����
  PROCEDURE P_FACT_PAYHABIT(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_ORDER����
  PROCEDURE P_FACT_ORDER(P_LOGTIME IN VARCHAR2,
                         P_ERRCODE OUT NUMBER,
                         P_ERRSTR  OUT VARCHAR2);
  --����FACT_REMAIN����
  PROCEDURE P_FACT_REMAIN(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_LOST����
  PROCEDURE P_FACT_LOST(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_LEVELPAY����
  PROCEDURE P_FACT_LEVELPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_LEVEL����
  PROCEDURE P_FACT_GENERAL_LEVEL(P_LOGTIME IN VARCHAR2,
                                 P_ERRCODE OUT NUMBER,
                                 P_ERRSTR  OUT VARCHAR2);
  --����FACT_LTV����
  PROCEDURE P_FACT_LTV(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);

  --����FACT_BACK����
  PROCEDURE P_FACT_BACK(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_MISS_FIRST����
  PROCEDURE P_FACT_MISS_FIRST(P_LOGTIME IN VARCHAR2,
                              P_ERRCODE OUT NUMBER,
                              P_ERRSTR  OUT VARCHAR2);
  --����FACT_DVID����
  PROCEDURE P_FACT_DVID(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_VC����
  PROCEDURE P_FACT_VC(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);
  --����FACT_NET����
  PROCEDURE P_FACT_NET(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);
  --����FACT_OPERATOR����
  PROCEDURE P_FACT_OPERATOR(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_REGION����
  PROCEDURE P_FACT_REGION(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_SUM_REP����
  PROCEDURE P_FACT_SUM_REP(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY_DVID����
  PROCEDURE P_FACT_GENERAL_DVID(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR_DVID����
  PROCEDURE P_FACT_GENERAL_HOUR_DVID(P_LOGTIME IN VARCHAR2,
                                     P_ERRCODE OUT NUMBER,
                                     P_ERRSTR  OUT VARCHAR2);
  --����FACT_CEVENT����
  PROCEDURE P_FACT_CEVENT(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_COMP_CEVENT����
  PROCEDURE P_FACT_COMP_CEVENT(P_LOGTIME IN VARCHAR2,
                               P_ERRCODE OUT NUMBER,
                               P_ERRSTR  OUT VARCHAR2);
  --����FACT_DAILY_REPORT����
  PROCEDURE P_FACT_DAILY_REPORT(P_LOGTIME IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE - 1,
                                                                      'YYYY-MM-DD'),
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
END PKG_FACT_100150;
/

prompt
prompt Creating package PKG_FACT_100167
prompt ================================
prompt
CREATE OR REPLACE Package Pkg_Fact_100167 Is
  --����ȫ��
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --����ά����Ϣ
  Procedure p_Dim_Other(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR����
  Procedure p_Fact_General_Hour(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY����
  Procedure p_Fact_General(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_FIRSTPAY����
  Procedure p_Fact_Firstpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_PAYHABIT����
  Procedure p_Fact_Payhabit(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_ORDER����
  Procedure p_Fact_Order(p_Logtime In Varchar2,
                         p_Errcode Out Number,
                         p_Errstr  Out Varchar2);
  --����FACT_REMAIN����
  Procedure p_Fact_Remain(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_LOST����
  Procedure p_Fact_Lost(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_LEVELPAY����
  Procedure p_Fact_Levelpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_GENERAL_LEVEL����
  Procedure p_Fact_General_Level(p_Logtime In Varchar2,
                                 p_Errcode Out Number,
                                 p_Errstr  Out Varchar2);
  --����FACT_LTV����
  Procedure p_Fact_Ltv(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);

  --����FACT_BACK����
  Procedure p_Fact_Back(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_MISS_FIRST����
  Procedure p_Fact_Miss_First(p_Logtime In Varchar2,
                              p_Errcode Out Number,
                              p_Errstr  Out Varchar2);
  --����FACT_DVID����
  Procedure p_Fact_Dvid(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_VC����
  Procedure p_Fact_Vc(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);
  --����FACT_NET����
  Procedure p_Fact_Net(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);
  --����FACT_OPERATOR����
  Procedure p_Fact_Operator(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_REGION����
  Procedure p_Fact_Region(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_SUM_REP����
  Procedure p_Fact_Sum_Rep(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY_DVID����
  Procedure p_Fact_General_Dvid(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR_DVID����
  Procedure p_Fact_General_Hour_Dvid(p_Logtime In Varchar2,
                                     p_Errcode Out Number,
                                     p_Errstr  Out Varchar2);
  --����FACT_CEVENT����
  Procedure p_Fact_Cevent(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_COMP_CEVENT����
  Procedure p_Fact_Comp_Cevent(p_Logtime In Varchar2,
                               p_Errcode Out Number,
                               p_Errstr  Out Varchar2);
  --����FACT_DAILY_REPORT����                         
  Procedure p_Fact_Daily_Report(p_Logtime In Varchar2 Default To_Char(Sysdate - 1,
                                                                      'YYYY-MM-DD'),
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
End Pkg_Fact_100167;
/

prompt
prompt Creating package PKG_FACT_100169
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FACT_100169" IS
  --����ȫ��
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --����ά����Ϣ
  PROCEDURE P_DIM_OTHER(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR����
  PROCEDURE P_FACT_GENERAL_HOUR(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY����
  PROCEDURE P_FACT_GENERAL(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_FIRSTPAY����
  PROCEDURE P_FACT_FIRSTPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_PAYHABIT����
  PROCEDURE P_FACT_PAYHABIT(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_ORDER����
  PROCEDURE P_FACT_ORDER(P_LOGTIME IN VARCHAR2,
                         P_ERRCODE OUT NUMBER,
                         P_ERRSTR  OUT VARCHAR2);
  --����FACT_REMAIN����
  PROCEDURE P_FACT_REMAIN(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_LOST����
  PROCEDURE P_FACT_LOST(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_LEVELPAY����
  PROCEDURE P_FACT_LEVELPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_LEVEL����
  PROCEDURE P_FACT_GENERAL_LEVEL(P_LOGTIME IN VARCHAR2,
                                 P_ERRCODE OUT NUMBER,
                                 P_ERRSTR  OUT VARCHAR2);
  --����FACT_LTV����
  PROCEDURE P_FACT_LTV(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);

  --����FACT_BACK����
  PROCEDURE P_FACT_BACK(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_MISS_FIRST����
  PROCEDURE P_FACT_MISS_FIRST(P_LOGTIME IN VARCHAR2,
                              P_ERRCODE OUT NUMBER,
                              P_ERRSTR  OUT VARCHAR2);
  --����FACT_DVID����
  PROCEDURE P_FACT_DVID(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_VC����
  PROCEDURE P_FACT_VC(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);
  --����FACT_NET����
  PROCEDURE P_FACT_NET(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);
  --����FACT_OPERATOR����
  PROCEDURE P_FACT_OPERATOR(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_REGION����
  PROCEDURE P_FACT_REGION(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_SUM_REP����
  PROCEDURE P_FACT_SUM_REP(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY_DVID����
  PROCEDURE P_FACT_GENERAL_DVID(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR_DVID����
  PROCEDURE P_FACT_GENERAL_HOUR_DVID(P_LOGTIME IN VARCHAR2,
                                     P_ERRCODE OUT NUMBER,
                                     P_ERRSTR  OUT VARCHAR2);
  --����FACT_CEVENT����
  PROCEDURE P_FACT_CEVENT(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_COMP_CEVENT����
  PROCEDURE P_FACT_COMP_CEVENT(P_LOGTIME IN VARCHAR2,
                               P_ERRCODE OUT NUMBER,
                               P_ERRSTR  OUT VARCHAR2);
  --����FACT_DAILY_REPORT����                         
  PROCEDURE P_FACT_DAILY_REPORT(P_LOGTIME IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE - 1,
                                                                      'YYYY-MM-DD'),
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
END PKG_FACT_100169;
/

prompt
prompt Creating package PKG_FACT_100172
prompt ================================
prompt
CREATE OR REPLACE Package Pkg_Fact_100172 Is
  --����ȫ��
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --����ά����Ϣ
  Procedure p_Dim_Other(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR����
  Procedure p_Fact_General_Hour(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY����
  Procedure p_Fact_General(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_FIRSTPAY����
  Procedure p_Fact_Firstpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_PAYHABIT����
  Procedure p_Fact_Payhabit(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_ORDER����
  Procedure p_Fact_Order(p_Logtime In Varchar2,
                         p_Errcode Out Number,
                         p_Errstr  Out Varchar2);
  --����FACT_REMAIN����
  Procedure p_Fact_Remain(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_LOST����
  Procedure p_Fact_Lost(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_LEVELPAY����
  Procedure p_Fact_Levelpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_GENERAL_LEVEL����
  Procedure p_Fact_General_Level(p_Logtime In Varchar2,
                                 p_Errcode Out Number,
                                 p_Errstr  Out Varchar2);
  --����FACT_LTV����
  Procedure p_Fact_Ltv(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);

  --����FACT_BACK����
  Procedure p_Fact_Back(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_MISS_FIRST����
  Procedure p_Fact_Miss_First(p_Logtime In Varchar2,
                              p_Errcode Out Number,
                              p_Errstr  Out Varchar2);
  --����FACT_DVID����
  Procedure p_Fact_Dvid(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_VC����
  Procedure p_Fact_Vc(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);
  --����FACT_NET����
  Procedure p_Fact_Net(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);
  --����FACT_OPERATOR����
  Procedure p_Fact_Operator(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_REGION����
  Procedure p_Fact_Region(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_SUM_REP����
  Procedure p_Fact_Sum_Rep(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY_DVID����
  Procedure p_Fact_General_Dvid(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR_DVID����
  Procedure p_Fact_General_Hour_Dvid(p_Logtime In Varchar2,
                                     p_Errcode Out Number,
                                     p_Errstr  Out Varchar2);
  --����FACT_CEVENT����
  Procedure p_Fact_Cevent(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_COMP_CEVENT����
  Procedure p_Fact_Comp_Cevent(p_Logtime In Varchar2,
                               p_Errcode Out Number,
                               p_Errstr  Out Varchar2);
  --����FACT_DAILY_REPORT����                         
  Procedure p_Fact_Daily_Report(p_Logtime In Varchar2 Default To_Char(Sysdate - 1,
                                                                      'YYYY-MM-DD'),
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
End Pkg_Fact_100172;
/

prompt
prompt Creating package PKG_FACT_100173
prompt ================================
prompt
CREATE OR REPLACE Package Pkg_Fact_100173 Is
  --����ȫ��
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --����ά����Ϣ
  Procedure p_Dim_Other(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR����
  Procedure p_Fact_General_Hour(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY����
  Procedure p_Fact_General(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_FIRSTPAY����
  Procedure p_Fact_Firstpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_PAYHABIT����
  Procedure p_Fact_Payhabit(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_ORDER����
  Procedure p_Fact_Order(p_Logtime In Varchar2,
                         p_Errcode Out Number,
                         p_Errstr  Out Varchar2);
  --����FACT_REMAIN����
  Procedure p_Fact_Remain(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_LOST����
  Procedure p_Fact_Lost(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_LEVELPAY����
  Procedure p_Fact_Levelpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_GENERAL_LEVEL����
  Procedure p_Fact_General_Level(p_Logtime In Varchar2,
                                 p_Errcode Out Number,
                                 p_Errstr  Out Varchar2);
  --����FACT_LTV����
  Procedure p_Fact_Ltv(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);

  --����FACT_BACK����
  Procedure p_Fact_Back(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_MISS_FIRST����
  Procedure p_Fact_Miss_First(p_Logtime In Varchar2,
                              p_Errcode Out Number,
                              p_Errstr  Out Varchar2);
  --����FACT_DVID����
  Procedure p_Fact_Dvid(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_VC����
  Procedure p_Fact_Vc(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);
  --����FACT_NET����
  Procedure p_Fact_Net(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);
  --����FACT_OPERATOR����
  Procedure p_Fact_Operator(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_REGION����
  Procedure p_Fact_Region(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_SUM_REP����
  Procedure p_Fact_Sum_Rep(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY_DVID����
  Procedure p_Fact_General_Dvid(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR_DVID����
  Procedure p_Fact_General_Hour_Dvid(p_Logtime In Varchar2,
                                     p_Errcode Out Number,
                                     p_Errstr  Out Varchar2);
  --����FACT_CEVENT����
  Procedure p_Fact_Cevent(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_COMP_CEVENT����
  Procedure p_Fact_Comp_Cevent(p_Logtime In Varchar2,
                               p_Errcode Out Number,
                               p_Errstr  Out Varchar2);
  --����FACT_DAILY_REPORT����                         
  Procedure p_Fact_Daily_Report(p_Logtime In Varchar2 Default To_Char(Sysdate - 1,
                                                                      'YYYY-MM-DD'),
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
End Pkg_Fact_100173;
/

prompt
prompt Creating package PKG_FACT_100174
prompt ================================
prompt
CREATE OR REPLACE Package Pkg_Fact_100174 Is
  --����ȫ��
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --����ά����Ϣ
  Procedure p_Dim_Other(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR����
  Procedure p_Fact_General_Hour(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY����
  Procedure p_Fact_General(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_FIRSTPAY����
  Procedure p_Fact_Firstpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_PAYHABIT����
  Procedure p_Fact_Payhabit(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_ORDER����
  Procedure p_Fact_Order(p_Logtime In Varchar2,
                         p_Errcode Out Number,
                         p_Errstr  Out Varchar2);
  --����FACT_REMAIN����
  Procedure p_Fact_Remain(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_LOST����
  Procedure p_Fact_Lost(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_LEVELPAY����
  Procedure p_Fact_Levelpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_GENERAL_LEVEL����
  Procedure p_Fact_General_Level(p_Logtime In Varchar2,
                                 p_Errcode Out Number,
                                 p_Errstr  Out Varchar2);
  --����FACT_LTV����
  Procedure p_Fact_Ltv(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);

  --����FACT_BACK����
  Procedure p_Fact_Back(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_MISS_FIRST����
  Procedure p_Fact_Miss_First(p_Logtime In Varchar2,
                              p_Errcode Out Number,
                              p_Errstr  Out Varchar2);
  --����FACT_DVID����
  Procedure p_Fact_Dvid(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_VC����
  Procedure p_Fact_Vc(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);
  --����FACT_NET����
  Procedure p_Fact_Net(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);
  --����FACT_OPERATOR����
  Procedure p_Fact_Operator(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_REGION����
  Procedure p_Fact_Region(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_SUM_REP����
  Procedure p_Fact_Sum_Rep(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY_DVID����
  Procedure p_Fact_General_Dvid(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR_DVID����
  Procedure p_Fact_General_Hour_Dvid(p_Logtime In Varchar2,
                                     p_Errcode Out Number,
                                     p_Errstr  Out Varchar2);
  --����FACT_CEVENT����
  Procedure p_Fact_Cevent(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_COMP_CEVENT����
  Procedure p_Fact_Comp_Cevent(p_Logtime In Varchar2,
                               p_Errcode Out Number,
                               p_Errstr  Out Varchar2);
  --����FACT_DAILY_REPORT����                         
  Procedure p_Fact_Daily_Report(p_Logtime In Varchar2 Default To_Char(Sysdate - 1,
                                                                      'YYYY-MM-DD'),
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
End Pkg_Fact_100174;
/

prompt
prompt Creating package PKG_FACT_100176
prompt ================================
prompt
CREATE OR REPLACE Package Pkg_Fact_100176 Is
  --����ȫ��
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --����ά����Ϣ
  Procedure p_Dim_Other(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR����
  Procedure p_Fact_General_Hour(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY����
  Procedure p_Fact_General(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_FIRSTPAY����
  Procedure p_Fact_Firstpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_PAYHABIT����
  Procedure p_Fact_Payhabit(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_ORDER����
  Procedure p_Fact_Order(p_Logtime In Varchar2,
                         p_Errcode Out Number,
                         p_Errstr  Out Varchar2);
  --����FACT_REMAIN����
  Procedure p_Fact_Remain(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_LOST����
  Procedure p_Fact_Lost(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_LEVELPAY����
  Procedure p_Fact_Levelpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_GENERAL_LEVEL����
  Procedure p_Fact_General_Level(p_Logtime In Varchar2,
                                 p_Errcode Out Number,
                                 p_Errstr  Out Varchar2);
  --����FACT_LTV����
  Procedure p_Fact_Ltv(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);

  --����FACT_BACK����
  Procedure p_Fact_Back(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_MISS_FIRST����
  Procedure p_Fact_Miss_First(p_Logtime In Varchar2,
                              p_Errcode Out Number,
                              p_Errstr  Out Varchar2);
  --����FACT_DVID����
  Procedure p_Fact_Dvid(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_VC����
  Procedure p_Fact_Vc(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);
  --����FACT_NET����
  Procedure p_Fact_Net(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);
  --����FACT_OPERATOR����
  Procedure p_Fact_Operator(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_REGION����
  Procedure p_Fact_Region(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_SUM_REP����
  Procedure p_Fact_Sum_Rep(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY_DVID����
  Procedure p_Fact_General_Dvid(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR_DVID����
  Procedure p_Fact_General_Hour_Dvid(p_Logtime In Varchar2,
                                     p_Errcode Out Number,
                                     p_Errstr  Out Varchar2);
  --����FACT_CEVENT����
  Procedure p_Fact_Cevent(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_COMP_CEVENT����
  Procedure p_Fact_Comp_Cevent(p_Logtime In Varchar2,
                               p_Errcode Out Number,
                               p_Errstr  Out Varchar2);
  --����FACT_DAILY_REPORT����                         
  Procedure p_Fact_Daily_Report(p_Logtime In Varchar2 Default To_Char(Sysdate - 1,
                                                                      'YYYY-MM-DD'),
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
End Pkg_Fact_100176;
/

prompt
prompt Creating package PKG_FACT_100177
prompt ================================
prompt
CREATE OR REPLACE Package Pkg_Fact_100177 Is
  --����ȫ��
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --����ά����Ϣ
  Procedure p_Dim_Other(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR����
  Procedure p_Fact_General_Hour(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY����
  Procedure p_Fact_General(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_FIRSTPAY����
  Procedure p_Fact_Firstpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_PAYHABIT����
  Procedure p_Fact_Payhabit(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_ORDER����
  Procedure p_Fact_Order(p_Logtime In Varchar2,
                         p_Errcode Out Number,
                         p_Errstr  Out Varchar2);
  --����FACT_REMAIN����
  Procedure p_Fact_Remain(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_LOST����
  Procedure p_Fact_Lost(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_LEVELPAY����
  Procedure p_Fact_Levelpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_GENERAL_LEVEL����
  Procedure p_Fact_General_Level(p_Logtime In Varchar2,
                                 p_Errcode Out Number,
                                 p_Errstr  Out Varchar2);
  --����FACT_LTV����
  Procedure p_Fact_Ltv(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);

  --����FACT_BACK����
  Procedure p_Fact_Back(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_MISS_FIRST����
  Procedure p_Fact_Miss_First(p_Logtime In Varchar2,
                              p_Errcode Out Number,
                              p_Errstr  Out Varchar2);
  --����FACT_DVID����
  Procedure p_Fact_Dvid(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_VC����
  Procedure p_Fact_Vc(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);
  --����FACT_NET����
  Procedure p_Fact_Net(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);
  --����FACT_OPERATOR����
  Procedure p_Fact_Operator(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_REGION����
  Procedure p_Fact_Region(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_SUM_REP����
  Procedure p_Fact_Sum_Rep(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY_DVID����
  Procedure p_Fact_General_Dvid(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR_DVID����
  Procedure p_Fact_General_Hour_Dvid(p_Logtime In Varchar2,
                                     p_Errcode Out Number,
                                     p_Errstr  Out Varchar2);
  --����FACT_CEVENT����
  Procedure p_Fact_Cevent(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_COMP_CEVENT����
  Procedure p_Fact_Comp_Cevent(p_Logtime In Varchar2,
                               p_Errcode Out Number,
                               p_Errstr  Out Varchar2);
  --����FACT_DAILY_REPORT����                         
  Procedure p_Fact_Daily_Report(p_Logtime In Varchar2 Default To_Char(Sysdate - 1,
                                                                      'YYYY-MM-DD'),
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
End Pkg_Fact_100177;
/

prompt
prompt Creating package PKG_FACT_100178
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FACT_100178" IS
  --����ȫ��
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --����ά����Ϣ
  PROCEDURE P_DIM_OTHER(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR����
  PROCEDURE P_FACT_GENERAL_HOUR(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY����
  PROCEDURE P_FACT_GENERAL(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_FIRSTPAY����
  PROCEDURE P_FACT_FIRSTPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_PAYHABIT����
  PROCEDURE P_FACT_PAYHABIT(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_ORDER����
  PROCEDURE P_FACT_ORDER(P_LOGTIME IN VARCHAR2,
                         P_ERRCODE OUT NUMBER,
                         P_ERRSTR  OUT VARCHAR2);
  --����FACT_REMAIN����
  PROCEDURE P_FACT_REMAIN(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_LOST����
  PROCEDURE P_FACT_LOST(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_LEVELPAY����
  PROCEDURE P_FACT_LEVELPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_LEVEL����
  PROCEDURE P_FACT_GENERAL_LEVEL(P_LOGTIME IN VARCHAR2,
                                 P_ERRCODE OUT NUMBER,
                                 P_ERRSTR  OUT VARCHAR2);
  --����FACT_LTV����
  PROCEDURE P_FACT_LTV(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);

  --����FACT_BACK����
  PROCEDURE P_FACT_BACK(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_MISS_FIRST����
  PROCEDURE P_FACT_MISS_FIRST(P_LOGTIME IN VARCHAR2,
                              P_ERRCODE OUT NUMBER,
                              P_ERRSTR  OUT VARCHAR2);
  --����FACT_DVID����
  PROCEDURE P_FACT_DVID(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_VC����
  PROCEDURE P_FACT_VC(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);
  --����FACT_NET����
  PROCEDURE P_FACT_NET(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);
  --����FACT_OPERATOR����
  PROCEDURE P_FACT_OPERATOR(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_REGION����
  PROCEDURE P_FACT_REGION(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_SUM_REP����
  PROCEDURE P_FACT_SUM_REP(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY_DVID����
  PROCEDURE P_FACT_GENERAL_DVID(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR_DVID����
  PROCEDURE P_FACT_GENERAL_HOUR_DVID(P_LOGTIME IN VARCHAR2,
                                     P_ERRCODE OUT NUMBER,
                                     P_ERRSTR  OUT VARCHAR2);
  --����FACT_CEVENT����
  PROCEDURE P_FACT_CEVENT(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_COMP_CEVENT����
  PROCEDURE P_FACT_COMP_CEVENT(P_LOGTIME IN VARCHAR2,
                               P_ERRCODE OUT NUMBER,
                               P_ERRSTR  OUT VARCHAR2);
  --����FACT_DAILY_REPORT����                         
  PROCEDURE P_FACT_DAILY_REPORT(P_LOGTIME IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE - 1,
                                                                      'YYYY-MM-DD'),
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
END PKG_FACT_100178;
/

prompt
prompt Creating package PKG_FACT_100179
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FACT_100179" IS
  --����ȫ��
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --����ά����Ϣ
  PROCEDURE P_DIM_OTHER(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR����
  PROCEDURE P_FACT_GENERAL_HOUR(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY����
  PROCEDURE P_FACT_GENERAL(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_FIRSTPAY����
  PROCEDURE P_FACT_FIRSTPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_PAYHABIT����
  PROCEDURE P_FACT_PAYHABIT(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_ORDER����
  PROCEDURE P_FACT_ORDER(P_LOGTIME IN VARCHAR2,
                         P_ERRCODE OUT NUMBER,
                         P_ERRSTR  OUT VARCHAR2);
  --����FACT_REMAIN����
  PROCEDURE P_FACT_REMAIN(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_LOST����
  PROCEDURE P_FACT_LOST(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_LEVELPAY����
  PROCEDURE P_FACT_LEVELPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_LEVEL����
  PROCEDURE P_FACT_GENERAL_LEVEL(P_LOGTIME IN VARCHAR2,
                                 P_ERRCODE OUT NUMBER,
                                 P_ERRSTR  OUT VARCHAR2);
  --����FACT_LTV����
  PROCEDURE P_FACT_LTV(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);

  --����FACT_BACK����
  PROCEDURE P_FACT_BACK(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_MISS_FIRST����
  PROCEDURE P_FACT_MISS_FIRST(P_LOGTIME IN VARCHAR2,
                              P_ERRCODE OUT NUMBER,
                              P_ERRSTR  OUT VARCHAR2);
  --����FACT_DVID����
  PROCEDURE P_FACT_DVID(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_VC����
  PROCEDURE P_FACT_VC(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);
  --����FACT_NET����
  PROCEDURE P_FACT_NET(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);
  --����FACT_OPERATOR����
  PROCEDURE P_FACT_OPERATOR(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_REGION����
  PROCEDURE P_FACT_REGION(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_SUM_REP����
  PROCEDURE P_FACT_SUM_REP(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY_DVID����
  PROCEDURE P_FACT_GENERAL_DVID(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR_DVID����
  PROCEDURE P_FACT_GENERAL_HOUR_DVID(P_LOGTIME IN VARCHAR2,
                                     P_ERRCODE OUT NUMBER,
                                     P_ERRSTR  OUT VARCHAR2);
  --����FACT_CEVENT����
  PROCEDURE P_FACT_CEVENT(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_COMP_CEVENT����
  PROCEDURE P_FACT_COMP_CEVENT(P_LOGTIME IN VARCHAR2,
                               P_ERRCODE OUT NUMBER,
                               P_ERRSTR  OUT VARCHAR2);
  --����FACT_DAILY_REPORT����                         
  PROCEDURE P_FACT_DAILY_REPORT(P_LOGTIME IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE - 1,
                                                                      'YYYY-MM-DD'),
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
END PKG_FACT_100179;
/

prompt
prompt Creating package PKG_FACT_100181
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FACT_100181" IS
  --����ȫ��
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --����ά����Ϣ
  PROCEDURE P_DIM_OTHER(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR����
  PROCEDURE P_FACT_GENERAL_HOUR(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY����
  PROCEDURE P_FACT_GENERAL(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_FIRSTPAY����
  PROCEDURE P_FACT_FIRSTPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_PAYHABIT����
  PROCEDURE P_FACT_PAYHABIT(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_ORDER����
  PROCEDURE P_FACT_ORDER(P_LOGTIME IN VARCHAR2,
                         P_ERRCODE OUT NUMBER,
                         P_ERRSTR  OUT VARCHAR2);
  --����FACT_REMAIN����
  PROCEDURE P_FACT_REMAIN(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_LOST����
  PROCEDURE P_FACT_LOST(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_LEVELPAY����
  PROCEDURE P_FACT_LEVELPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_LEVEL����
  PROCEDURE P_FACT_GENERAL_LEVEL(P_LOGTIME IN VARCHAR2,
                                 P_ERRCODE OUT NUMBER,
                                 P_ERRSTR  OUT VARCHAR2);
  --����FACT_LTV����
  PROCEDURE P_FACT_LTV(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);

  --����FACT_BACK����
  PROCEDURE P_FACT_BACK(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_MISS_FIRST����
  PROCEDURE P_FACT_MISS_FIRST(P_LOGTIME IN VARCHAR2,
                              P_ERRCODE OUT NUMBER,
                              P_ERRSTR  OUT VARCHAR2);
  --����FACT_DVID����
  PROCEDURE P_FACT_DVID(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_VC����
  PROCEDURE P_FACT_VC(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);
  --����FACT_NET����
  PROCEDURE P_FACT_NET(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);
  --����FACT_OPERATOR����
  PROCEDURE P_FACT_OPERATOR(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_REGION����
  PROCEDURE P_FACT_REGION(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_SUM_REP����
  PROCEDURE P_FACT_SUM_REP(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY_DVID����
  PROCEDURE P_FACT_GENERAL_DVID(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR_DVID����
  PROCEDURE P_FACT_GENERAL_HOUR_DVID(P_LOGTIME IN VARCHAR2,
                                     P_ERRCODE OUT NUMBER,
                                     P_ERRSTR  OUT VARCHAR2);
  --����FACT_CEVENT����
  PROCEDURE P_FACT_CEVENT(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_COMP_CEVENT����
  PROCEDURE P_FACT_COMP_CEVENT(P_LOGTIME IN VARCHAR2,
                               P_ERRCODE OUT NUMBER,
                               P_ERRSTR  OUT VARCHAR2);
  --����FACT_DAILY_REPORT����                         
  PROCEDURE P_FACT_DAILY_REPORT(P_LOGTIME IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE - 1,
                                                                      'YYYY-MM-DD'),
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
END PKG_FACT_100181;
/

prompt
prompt Creating package PKG_FACT_100190
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FACT_100190" IS
  --����ȫ��
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --����ά����Ϣ
  PROCEDURE P_DIM_OTHER(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR����
  PROCEDURE P_FACT_GENERAL_HOUR(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY����
  PROCEDURE P_FACT_GENERAL(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_FIRSTPAY����
  PROCEDURE P_FACT_FIRSTPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_PAYHABIT����
  PROCEDURE P_FACT_PAYHABIT(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_ORDER����
  PROCEDURE P_FACT_ORDER(P_LOGTIME IN VARCHAR2,
                         P_ERRCODE OUT NUMBER,
                         P_ERRSTR  OUT VARCHAR2);
  --����FACT_REMAIN����
  PROCEDURE P_FACT_REMAIN(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_LOST����
  PROCEDURE P_FACT_LOST(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_LEVELPAY����
  PROCEDURE P_FACT_LEVELPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_LEVEL����
  PROCEDURE P_FACT_GENERAL_LEVEL(P_LOGTIME IN VARCHAR2,
                                 P_ERRCODE OUT NUMBER,
                                 P_ERRSTR  OUT VARCHAR2);
  --����FACT_LTV����
  PROCEDURE P_FACT_LTV(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);

  --����FACT_BACK����
  PROCEDURE P_FACT_BACK(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_MISS_FIRST����
  PROCEDURE P_FACT_MISS_FIRST(P_LOGTIME IN VARCHAR2,
                              P_ERRCODE OUT NUMBER,
                              P_ERRSTR  OUT VARCHAR2);
  --����FACT_DVID����
  PROCEDURE P_FACT_DVID(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_VC����
  PROCEDURE P_FACT_VC(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);
  --����FACT_NET����
  PROCEDURE P_FACT_NET(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);
  --����FACT_OPERATOR����
  PROCEDURE P_FACT_OPERATOR(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_REGION����
  PROCEDURE P_FACT_REGION(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_SUM_REP����
  PROCEDURE P_FACT_SUM_REP(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY_DVID����
  PROCEDURE P_FACT_GENERAL_DVID(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR_DVID����
  PROCEDURE P_FACT_GENERAL_HOUR_DVID(P_LOGTIME IN VARCHAR2,
                                     P_ERRCODE OUT NUMBER,
                                     P_ERRSTR  OUT VARCHAR2);
  --����FACT_CEVENT����
  PROCEDURE P_FACT_CEVENT(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_COMP_CEVENT����
  PROCEDURE P_FACT_COMP_CEVENT(P_LOGTIME IN VARCHAR2,
                               P_ERRCODE OUT NUMBER,
                               P_ERRSTR  OUT VARCHAR2);
  --����FACT_DAILY_REPORT����                         
  PROCEDURE P_FACT_DAILY_REPORT(P_LOGTIME IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE - 1,
                                                                      'YYYY-MM-DD'),
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
END PKG_FACT_100190;
/

prompt
prompt Creating package PKG_FACT_100192
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FACT_100192" IS
  --����ȫ��
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --����ά����Ϣ
  PROCEDURE P_DIM_OTHER(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR����
  PROCEDURE P_FACT_GENERAL_HOUR(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY����
  PROCEDURE P_FACT_GENERAL(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_FIRSTPAY����
  PROCEDURE P_FACT_FIRSTPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_PAYHABIT����
  PROCEDURE P_FACT_PAYHABIT(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_ORDER����
  PROCEDURE P_FACT_ORDER(P_LOGTIME IN VARCHAR2,
                         P_ERRCODE OUT NUMBER,
                         P_ERRSTR  OUT VARCHAR2);
  --����FACT_REMAIN����
  PROCEDURE P_FACT_REMAIN(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_LOST����
  PROCEDURE P_FACT_LOST(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_LEVELPAY����
  PROCEDURE P_FACT_LEVELPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_LEVEL����
  PROCEDURE P_FACT_GENERAL_LEVEL(P_LOGTIME IN VARCHAR2,
                                 P_ERRCODE OUT NUMBER,
                                 P_ERRSTR  OUT VARCHAR2);
  --����FACT_LTV����
  PROCEDURE P_FACT_LTV(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);

  --����FACT_BACK����
  PROCEDURE P_FACT_BACK(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_MISS_FIRST����
  PROCEDURE P_FACT_MISS_FIRST(P_LOGTIME IN VARCHAR2,
                              P_ERRCODE OUT NUMBER,
                              P_ERRSTR  OUT VARCHAR2);
  --����FACT_DVID����
  PROCEDURE P_FACT_DVID(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_VC����
  PROCEDURE P_FACT_VC(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);
  --����FACT_NET����
  PROCEDURE P_FACT_NET(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);
  --����FACT_OPERATOR����
  PROCEDURE P_FACT_OPERATOR(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_REGION����
  PROCEDURE P_FACT_REGION(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_SUM_REP����
  PROCEDURE P_FACT_SUM_REP(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY_DVID����
  PROCEDURE P_FACT_GENERAL_DVID(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR_DVID����
  PROCEDURE P_FACT_GENERAL_HOUR_DVID(P_LOGTIME IN VARCHAR2,
                                     P_ERRCODE OUT NUMBER,
                                     P_ERRSTR  OUT VARCHAR2);
  --����FACT_CEVENT����
  PROCEDURE P_FACT_CEVENT(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_COMP_CEVENT����
  PROCEDURE P_FACT_COMP_CEVENT(P_LOGTIME IN VARCHAR2,
                               P_ERRCODE OUT NUMBER,
                               P_ERRSTR  OUT VARCHAR2);
  --����FACT_DAILY_REPORT����                         
  PROCEDURE P_FACT_DAILY_REPORT(P_LOGTIME IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE - 1,
                                                                      'YYYY-MM-DD'),
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
END PKG_FACT_100192;
/

prompt
prompt Creating package PKG_FACT_100193
prompt ================================
prompt
CREATE OR REPLACE Package Pkg_Fact_100193 Is
  --����ȫ��
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --����ά����Ϣ
  Procedure p_Dim_Other(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR����
  Procedure p_Fact_General_Hour(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY����
  Procedure p_Fact_General(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_FIRSTPAY����
  Procedure p_Fact_Firstpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_PAYHABIT����
  Procedure p_Fact_Payhabit(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_ORDER����
  Procedure p_Fact_Order(p_Logtime In Varchar2,
                         p_Errcode Out Number,
                         p_Errstr  Out Varchar2);
  --����FACT_REMAIN����
  Procedure p_Fact_Remain(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_LOST����
  Procedure p_Fact_Lost(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_LEVELPAY����
  Procedure p_Fact_Levelpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_GENERAL_LEVEL����
  Procedure p_Fact_General_Level(p_Logtime In Varchar2,
                                 p_Errcode Out Number,
                                 p_Errstr  Out Varchar2);
  --����FACT_LTV����
  Procedure p_Fact_Ltv(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);

  --����FACT_BACK����
  Procedure p_Fact_Back(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_MISS_FIRST����
  Procedure p_Fact_Miss_First(p_Logtime In Varchar2,
                              p_Errcode Out Number,
                              p_Errstr  Out Varchar2);
  --����FACT_DVID����
  Procedure p_Fact_Dvid(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_VC����
  Procedure p_Fact_Vc(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);
  --����FACT_NET����
  Procedure p_Fact_Net(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);
  --����FACT_OPERATOR����
  Procedure p_Fact_Operator(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_REGION����
  Procedure p_Fact_Region(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_SUM_REP����
  Procedure p_Fact_Sum_Rep(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY_DVID����
  Procedure p_Fact_General_Dvid(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR_DVID����
  Procedure p_Fact_General_Hour_Dvid(p_Logtime In Varchar2,
                                     p_Errcode Out Number,
                                     p_Errstr  Out Varchar2);
  --����FACT_CEVENT����
  Procedure p_Fact_Cevent(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_COMP_CEVENT����
  Procedure p_Fact_Comp_Cevent(p_Logtime In Varchar2,
                               p_Errcode Out Number,
                               p_Errstr  Out Varchar2);
  --����FACT_DAILY_REPORT����                         
  Procedure p_Fact_Daily_Report(p_Logtime In Varchar2 Default To_Char(Sysdate - 1,
                                                                      'YYYY-MM-DD'),
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
End Pkg_Fact_100193;
/

prompt
prompt Creating package PKG_FACT_100194
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FACT_100194" IS
  --����ȫ��
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --����ά����Ϣ
  PROCEDURE P_DIM_OTHER(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR����
  PROCEDURE P_FACT_GENERAL_HOUR(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY����
  PROCEDURE P_FACT_GENERAL(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_FIRSTPAY����
  PROCEDURE P_FACT_FIRSTPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_PAYHABIT����
  PROCEDURE P_FACT_PAYHABIT(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_ORDER����
  PROCEDURE P_FACT_ORDER(P_LOGTIME IN VARCHAR2,
                         P_ERRCODE OUT NUMBER,
                         P_ERRSTR  OUT VARCHAR2);
  --����FACT_REMAIN����
  PROCEDURE P_FACT_REMAIN(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_LOST����
  PROCEDURE P_FACT_LOST(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_LEVELPAY����
  PROCEDURE P_FACT_LEVELPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_LEVEL����
  PROCEDURE P_FACT_GENERAL_LEVEL(P_LOGTIME IN VARCHAR2,
                                 P_ERRCODE OUT NUMBER,
                                 P_ERRSTR  OUT VARCHAR2);
  --����FACT_LTV����
  PROCEDURE P_FACT_LTV(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);

  --����FACT_BACK����
  PROCEDURE P_FACT_BACK(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_MISS_FIRST����
  PROCEDURE P_FACT_MISS_FIRST(P_LOGTIME IN VARCHAR2,
                              P_ERRCODE OUT NUMBER,
                              P_ERRSTR  OUT VARCHAR2);
  --����FACT_DVID����
  PROCEDURE P_FACT_DVID(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_VC����
  PROCEDURE P_FACT_VC(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);
  --����FACT_NET����
  PROCEDURE P_FACT_NET(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);
  --����FACT_OPERATOR����
  PROCEDURE P_FACT_OPERATOR(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_REGION����
  PROCEDURE P_FACT_REGION(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_SUM_REP����
  PROCEDURE P_FACT_SUM_REP(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY_DVID����
  PROCEDURE P_FACT_GENERAL_DVID(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR_DVID����
  PROCEDURE P_FACT_GENERAL_HOUR_DVID(P_LOGTIME IN VARCHAR2,
                                     P_ERRCODE OUT NUMBER,
                                     P_ERRSTR  OUT VARCHAR2);
  --����FACT_CEVENT����
  PROCEDURE P_FACT_CEVENT(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_COMP_CEVENT����
  PROCEDURE P_FACT_COMP_CEVENT(P_LOGTIME IN VARCHAR2,
                               P_ERRCODE OUT NUMBER,
                               P_ERRSTR  OUT VARCHAR2);
  --����FACT_DAILY_REPORT����                         
  PROCEDURE P_FACT_DAILY_REPORT(P_LOGTIME IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE - 1,
                                                                      'YYYY-MM-DD'),
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
END PKG_FACT_100194;
/

prompt
prompt Creating package PKG_FACT_100196
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FACT_100196" IS
  --����ȫ��
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --����ά����Ϣ
  PROCEDURE P_DIM_OTHER(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR����
  PROCEDURE P_FACT_GENERAL_HOUR(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY����
  PROCEDURE P_FACT_GENERAL(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_FIRSTPAY����
  PROCEDURE P_FACT_FIRSTPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_PAYHABIT����
  PROCEDURE P_FACT_PAYHABIT(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_ORDER����
  PROCEDURE P_FACT_ORDER(P_LOGTIME IN VARCHAR2,
                         P_ERRCODE OUT NUMBER,
                         P_ERRSTR  OUT VARCHAR2);
  --����FACT_REMAIN����
  PROCEDURE P_FACT_REMAIN(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_LOST����
  PROCEDURE P_FACT_LOST(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_LEVELPAY����
  PROCEDURE P_FACT_LEVELPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_LEVEL����
  PROCEDURE P_FACT_GENERAL_LEVEL(P_LOGTIME IN VARCHAR2,
                                 P_ERRCODE OUT NUMBER,
                                 P_ERRSTR  OUT VARCHAR2);
  --����FACT_LTV����
  PROCEDURE P_FACT_LTV(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);

  --����FACT_BACK����
  PROCEDURE P_FACT_BACK(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_MISS_FIRST����
  PROCEDURE P_FACT_MISS_FIRST(P_LOGTIME IN VARCHAR2,
                              P_ERRCODE OUT NUMBER,
                              P_ERRSTR  OUT VARCHAR2);
  --����FACT_DVID����
  PROCEDURE P_FACT_DVID(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_VC����
  PROCEDURE P_FACT_VC(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);
  --����FACT_NET����
  PROCEDURE P_FACT_NET(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);
  --����FACT_OPERATOR����
  PROCEDURE P_FACT_OPERATOR(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_REGION����
  PROCEDURE P_FACT_REGION(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_SUM_REP����
  PROCEDURE P_FACT_SUM_REP(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY_DVID����
  PROCEDURE P_FACT_GENERAL_DVID(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR_DVID����
  PROCEDURE P_FACT_GENERAL_HOUR_DVID(P_LOGTIME IN VARCHAR2,
                                     P_ERRCODE OUT NUMBER,
                                     P_ERRSTR  OUT VARCHAR2);
  --����FACT_CEVENT����
  PROCEDURE P_FACT_CEVENT(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_COMP_CEVENT����
  PROCEDURE P_FACT_COMP_CEVENT(P_LOGTIME IN VARCHAR2,
                               P_ERRCODE OUT NUMBER,
                               P_ERRSTR  OUT VARCHAR2);
  --����FACT_DAILY_REPORT����                         
  PROCEDURE P_FACT_DAILY_REPORT(P_LOGTIME IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE - 1,
                                                                      'YYYY-MM-DD'),
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
END PKG_FACT_100196;
/

prompt
prompt Creating package PKG_FACT_100197
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FACT_100197" IS
  --����ȫ��
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --����ά����Ϣ
  PROCEDURE P_DIM_OTHER(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR����
  PROCEDURE P_FACT_GENERAL_HOUR(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY����
  PROCEDURE P_FACT_GENERAL(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_FIRSTPAY����
  PROCEDURE P_FACT_FIRSTPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_PAYHABIT����
  PROCEDURE P_FACT_PAYHABIT(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_ORDER����
  PROCEDURE P_FACT_ORDER(P_LOGTIME IN VARCHAR2,
                         P_ERRCODE OUT NUMBER,
                         P_ERRSTR  OUT VARCHAR2);
  --����FACT_REMAIN����
  PROCEDURE P_FACT_REMAIN(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_LOST����
  PROCEDURE P_FACT_LOST(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_LEVELPAY����
  PROCEDURE P_FACT_LEVELPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_LEVEL����
  PROCEDURE P_FACT_GENERAL_LEVEL(P_LOGTIME IN VARCHAR2,
                                 P_ERRCODE OUT NUMBER,
                                 P_ERRSTR  OUT VARCHAR2);
  --����FACT_LTV����
  PROCEDURE P_FACT_LTV(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);

  --����FACT_BACK����
  PROCEDURE P_FACT_BACK(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_MISS_FIRST����
  PROCEDURE P_FACT_MISS_FIRST(P_LOGTIME IN VARCHAR2,
                              P_ERRCODE OUT NUMBER,
                              P_ERRSTR  OUT VARCHAR2);
  --����FACT_DVID����
  PROCEDURE P_FACT_DVID(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_VC����
  PROCEDURE P_FACT_VC(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);
  --����FACT_NET����
  PROCEDURE P_FACT_NET(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);
  --����FACT_OPERATOR����
  PROCEDURE P_FACT_OPERATOR(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_REGION����
  PROCEDURE P_FACT_REGION(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_SUM_REP����
  PROCEDURE P_FACT_SUM_REP(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY_DVID����
  PROCEDURE P_FACT_GENERAL_DVID(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR_DVID����
  PROCEDURE P_FACT_GENERAL_HOUR_DVID(P_LOGTIME IN VARCHAR2,
                                     P_ERRCODE OUT NUMBER,
                                     P_ERRSTR  OUT VARCHAR2);
  --����FACT_CEVENT����
  PROCEDURE P_FACT_CEVENT(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_COMP_CEVENT����
  PROCEDURE P_FACT_COMP_CEVENT(P_LOGTIME IN VARCHAR2,
                               P_ERRCODE OUT NUMBER,
                               P_ERRSTR  OUT VARCHAR2);
  --����FACT_DAILY_REPORT����                         
  PROCEDURE P_FACT_DAILY_REPORT(P_LOGTIME IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE - 1,
                                                                      'YYYY-MM-DD'),
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
END PKG_FACT_100197;
/

prompt
prompt Creating package PKG_FACT_100198
prompt ================================
prompt
CREATE OR REPLACE Package Pkg_Fact_100198 Is
  --����ȫ��
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --����ά����Ϣ
  Procedure p_Dim_Other(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR����
  Procedure p_Fact_General_Hour(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY����
  Procedure p_Fact_General(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_FIRSTPAY����
  Procedure p_Fact_Firstpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_PAYHABIT����
  Procedure p_Fact_Payhabit(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_ORDER����
  Procedure p_Fact_Order(p_Logtime In Varchar2,
                         p_Errcode Out Number,
                         p_Errstr  Out Varchar2);
  --����FACT_REMAIN����
  Procedure p_Fact_Remain(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_LOST����
  Procedure p_Fact_Lost(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_LEVELPAY����
  Procedure p_Fact_Levelpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_GENERAL_LEVEL����
  Procedure p_Fact_General_Level(p_Logtime In Varchar2,
                                 p_Errcode Out Number,
                                 p_Errstr  Out Varchar2);
  --����FACT_LTV����
  Procedure p_Fact_Ltv(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);

  --����FACT_BACK����
  Procedure p_Fact_Back(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_MISS_FIRST����
  Procedure p_Fact_Miss_First(p_Logtime In Varchar2,
                              p_Errcode Out Number,
                              p_Errstr  Out Varchar2);
  --����FACT_DVID����
  Procedure p_Fact_Dvid(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_VC����
  Procedure p_Fact_Vc(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);
  --����FACT_NET����
  Procedure p_Fact_Net(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);
  --����FACT_OPERATOR����
  Procedure p_Fact_Operator(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_REGION����
  Procedure p_Fact_Region(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_SUM_REP����
  Procedure p_Fact_Sum_Rep(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY_DVID����
  Procedure p_Fact_General_Dvid(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR_DVID����
  Procedure p_Fact_General_Hour_Dvid(p_Logtime In Varchar2,
                                     p_Errcode Out Number,
                                     p_Errstr  Out Varchar2);
  --����FACT_CEVENT����
  Procedure p_Fact_Cevent(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_COMP_CEVENT����
  Procedure p_Fact_Comp_Cevent(p_Logtime In Varchar2,
                               p_Errcode Out Number,
                               p_Errstr  Out Varchar2);
  --����FACT_DAILY_REPORT����                         
  Procedure p_Fact_Daily_Report(p_Logtime In Varchar2 Default To_Char(Sysdate - 1,
                                                                      'YYYY-MM-DD'),
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
End Pkg_Fact_100198;
/

prompt
prompt Creating package PKG_FACT_100201
prompt ================================
prompt
CREATE OR REPLACE Package Pkg_Fact_100201 Is
  --����ȫ��
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --����ά����Ϣ
  Procedure p_Dim_Other(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR����
  Procedure p_Fact_General_Hour(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY����
  Procedure p_Fact_General(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_FIRSTPAY����
  Procedure p_Fact_Firstpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_PAYHABIT����
  Procedure p_Fact_Payhabit(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_ORDER����
  Procedure p_Fact_Order(p_Logtime In Varchar2,
                         p_Errcode Out Number,
                         p_Errstr  Out Varchar2);
  --����FACT_REMAIN����
  Procedure p_Fact_Remain(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_LOST����
  Procedure p_Fact_Lost(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_LEVELPAY����
  Procedure p_Fact_Levelpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_GENERAL_LEVEL����
  Procedure p_Fact_General_Level(p_Logtime In Varchar2,
                                 p_Errcode Out Number,
                                 p_Errstr  Out Varchar2);
  --����FACT_LTV����
  Procedure p_Fact_Ltv(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);

  --����FACT_BACK����
  Procedure p_Fact_Back(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_MISS_FIRST����
  Procedure p_Fact_Miss_First(p_Logtime In Varchar2,
                              p_Errcode Out Number,
                              p_Errstr  Out Varchar2);
  --����FACT_DVID����
  Procedure p_Fact_Dvid(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_VC����
  Procedure p_Fact_Vc(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);
  --����FACT_NET����
  Procedure p_Fact_Net(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);
  --����FACT_OPERATOR����
  Procedure p_Fact_Operator(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_REGION����
  Procedure p_Fact_Region(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_SUM_REP����
  Procedure p_Fact_Sum_Rep(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY_DVID����
  Procedure p_Fact_General_Dvid(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR_DVID����
  Procedure p_Fact_General_Hour_Dvid(p_Logtime In Varchar2,
                                     p_Errcode Out Number,
                                     p_Errstr  Out Varchar2);
  --����FACT_CEVENT����
  Procedure p_Fact_Cevent(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_COMP_CEVENT����
  Procedure p_Fact_Comp_Cevent(p_Logtime In Varchar2,
                               p_Errcode Out Number,
                               p_Errstr  Out Varchar2);
  --����FACT_DAILY_REPORT����                         
  Procedure p_Fact_Daily_Report(p_Logtime In Varchar2 Default To_Char(Sysdate - 1,
                                                                      'YYYY-MM-DD'),
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
End Pkg_Fact_100201;
/

prompt
prompt Creating package PKG_FACT_100202
prompt ================================
prompt
CREATE OR REPLACE Package Pkg_Fact_100202 Is
  --����ȫ��
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --����ά����Ϣ
  Procedure p_Dim_Other(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR����
  Procedure p_Fact_General_Hour(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY����
  Procedure p_Fact_General(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_FIRSTPAY����
  Procedure p_Fact_Firstpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_PAYHABIT����
  Procedure p_Fact_Payhabit(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_ORDER����
  Procedure p_Fact_Order(p_Logtime In Varchar2,
                         p_Errcode Out Number,
                         p_Errstr  Out Varchar2);
  --����FACT_REMAIN����
  Procedure p_Fact_Remain(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_LOST����
  Procedure p_Fact_Lost(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_LEVELPAY����
  Procedure p_Fact_Levelpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_GENERAL_LEVEL����
  Procedure p_Fact_General_Level(p_Logtime In Varchar2,
                                 p_Errcode Out Number,
                                 p_Errstr  Out Varchar2);
  --����FACT_LTV����
  Procedure p_Fact_Ltv(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);

  --����FACT_BACK����
  Procedure p_Fact_Back(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_MISS_FIRST����
  Procedure p_Fact_Miss_First(p_Logtime In Varchar2,
                              p_Errcode Out Number,
                              p_Errstr  Out Varchar2);
  --����FACT_DVID����
  Procedure p_Fact_Dvid(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_VC����
  Procedure p_Fact_Vc(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);
  --����FACT_NET����
  Procedure p_Fact_Net(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);
  --����FACT_OPERATOR����
  Procedure p_Fact_Operator(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_REGION����
  Procedure p_Fact_Region(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_SUM_REP����
  Procedure p_Fact_Sum_Rep(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY_DVID����
  Procedure p_Fact_General_Dvid(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR_DVID����
  Procedure p_Fact_General_Hour_Dvid(p_Logtime In Varchar2,
                                     p_Errcode Out Number,
                                     p_Errstr  Out Varchar2);
  --����FACT_CEVENT����
  Procedure p_Fact_Cevent(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_COMP_CEVENT����
  Procedure p_Fact_Comp_Cevent(p_Logtime In Varchar2,
                               p_Errcode Out Number,
                               p_Errstr  Out Varchar2);
  --����FACT_DAILY_REPORT����                         
  Procedure p_Fact_Daily_Report(p_Logtime In Varchar2 Default To_Char(Sysdate - 1,
                                                                      'YYYY-MM-DD'),
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
End Pkg_Fact_100202;
/

prompt
prompt Creating package PKG_FACT_100209
prompt ================================
prompt
CREATE OR REPLACE Package Pkg_Fact_100209 Is
  --����ȫ��
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --����ά����Ϣ
  Procedure p_Dim_Other(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR����
  Procedure p_Fact_General_Hour(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY����
  Procedure p_Fact_General(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_FIRSTPAY����
  Procedure p_Fact_Firstpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_PAYHABIT����
  Procedure p_Fact_Payhabit(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_ORDER����
  Procedure p_Fact_Order(p_Logtime In Varchar2,
                         p_Errcode Out Number,
                         p_Errstr  Out Varchar2);
  --����FACT_REMAIN����
  Procedure p_Fact_Remain(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_LOST����
  Procedure p_Fact_Lost(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_LEVELPAY����
  Procedure p_Fact_Levelpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_GENERAL_LEVEL����
  Procedure p_Fact_General_Level(p_Logtime In Varchar2,
                                 p_Errcode Out Number,
                                 p_Errstr  Out Varchar2);
  --����FACT_LTV����
  Procedure p_Fact_Ltv(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);

  --����FACT_BACK����
  Procedure p_Fact_Back(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_MISS_FIRST����
  Procedure p_Fact_Miss_First(p_Logtime In Varchar2,
                              p_Errcode Out Number,
                              p_Errstr  Out Varchar2);
  --����FACT_DVID����
  Procedure p_Fact_Dvid(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_VC����
  Procedure p_Fact_Vc(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);
  --����FACT_NET����
  Procedure p_Fact_Net(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);
  --����FACT_OPERATOR����
  Procedure p_Fact_Operator(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_REGION����
  Procedure p_Fact_Region(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_SUM_REP����
  Procedure p_Fact_Sum_Rep(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY_DVID����
  Procedure p_Fact_General_Dvid(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR_DVID����
  Procedure p_Fact_General_Hour_Dvid(p_Logtime In Varchar2,
                                     p_Errcode Out Number,
                                     p_Errstr  Out Varchar2);
  --����FACT_CEVENT����
  Procedure p_Fact_Cevent(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_COMP_CEVENT����
  Procedure p_Fact_Comp_Cevent(p_Logtime In Varchar2,
                               p_Errcode Out Number,
                               p_Errstr  Out Varchar2);
  --����FACT_DAILY_REPORT����                         
  Procedure p_Fact_Daily_Report(p_Logtime In Varchar2 Default To_Char(Sysdate - 1,
                                                                      'YYYY-MM-DD'),
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
End Pkg_Fact_100209;
/

prompt
prompt Creating package PKG_FACT_100228
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FACT_100228" IS
  --����ȫ��
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --����ά����Ϣ
  PROCEDURE P_DIM_OTHER(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR����
  PROCEDURE P_FACT_GENERAL_HOUR(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY����
  PROCEDURE P_FACT_GENERAL(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_FIRSTPAY����
  PROCEDURE P_FACT_FIRSTPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_PAYHABIT����
  PROCEDURE P_FACT_PAYHABIT(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_ORDER����
  PROCEDURE P_FACT_ORDER(P_LOGTIME IN VARCHAR2,
                         P_ERRCODE OUT NUMBER,
                         P_ERRSTR  OUT VARCHAR2);
  --����FACT_REMAIN����
  PROCEDURE P_FACT_REMAIN(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_LOST����
  PROCEDURE P_FACT_LOST(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_LEVELPAY����
  PROCEDURE P_FACT_LEVELPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_LEVEL����
  PROCEDURE P_FACT_GENERAL_LEVEL(P_LOGTIME IN VARCHAR2,
                                 P_ERRCODE OUT NUMBER,
                                 P_ERRSTR  OUT VARCHAR2);
  --����FACT_LTV����
  PROCEDURE P_FACT_LTV(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);

  --����FACT_BACK����
  PROCEDURE P_FACT_BACK(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_MISS_FIRST����
  PROCEDURE P_FACT_MISS_FIRST(P_LOGTIME IN VARCHAR2,
                              P_ERRCODE OUT NUMBER,
                              P_ERRSTR  OUT VARCHAR2);
  --����FACT_DVID����
  PROCEDURE P_FACT_DVID(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_VC����
  PROCEDURE P_FACT_VC(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);
  --����FACT_NET����
  PROCEDURE P_FACT_NET(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);
  --����FACT_OPERATOR����
  PROCEDURE P_FACT_OPERATOR(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_REGION����
  PROCEDURE P_FACT_REGION(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_SUM_REP����
  PROCEDURE P_FACT_SUM_REP(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY_DVID����
  PROCEDURE P_FACT_GENERAL_DVID(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR_DVID����
  PROCEDURE P_FACT_GENERAL_HOUR_DVID(P_LOGTIME IN VARCHAR2,
                                     P_ERRCODE OUT NUMBER,
                                     P_ERRSTR  OUT VARCHAR2);
  --����FACT_CEVENT����
  PROCEDURE P_FACT_CEVENT(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_COMP_CEVENT����
  PROCEDURE P_FACT_COMP_CEVENT(P_LOGTIME IN VARCHAR2,
                               P_ERRCODE OUT NUMBER,
                               P_ERRSTR  OUT VARCHAR2);
  --����FACT_DAILY_REPORT����                         
  PROCEDURE P_FACT_DAILY_REPORT(P_LOGTIME IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE - 1,
                                                                      'YYYY-MM-DD'),
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
END PKG_FACT_100228;
/

prompt
prompt Creating package PKG_FACT_100230
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FACT_100230" IS
  --����ȫ��
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --����ά����Ϣ
  PROCEDURE P_DIM_OTHER(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR����
  PROCEDURE P_FACT_GENERAL_HOUR(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY����
  PROCEDURE P_FACT_GENERAL(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_FIRSTPAY����
  PROCEDURE P_FACT_FIRSTPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_PAYHABIT����
  PROCEDURE P_FACT_PAYHABIT(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_ORDER����
  PROCEDURE P_FACT_ORDER(P_LOGTIME IN VARCHAR2,
                         P_ERRCODE OUT NUMBER,
                         P_ERRSTR  OUT VARCHAR2);
  --����FACT_REMAIN����
  PROCEDURE P_FACT_REMAIN(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_LOST����
  PROCEDURE P_FACT_LOST(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_LEVELPAY����
  PROCEDURE P_FACT_LEVELPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_LEVEL����
  PROCEDURE P_FACT_GENERAL_LEVEL(P_LOGTIME IN VARCHAR2,
                                 P_ERRCODE OUT NUMBER,
                                 P_ERRSTR  OUT VARCHAR2);
  --����FACT_LTV����
  PROCEDURE P_FACT_LTV(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);

  --����FACT_BACK����
  PROCEDURE P_FACT_BACK(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_MISS_FIRST����
  PROCEDURE P_FACT_MISS_FIRST(P_LOGTIME IN VARCHAR2,
                              P_ERRCODE OUT NUMBER,
                              P_ERRSTR  OUT VARCHAR2);
  --����FACT_DVID����
  PROCEDURE P_FACT_DVID(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_VC����
  PROCEDURE P_FACT_VC(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);
  --����FACT_NET����
  PROCEDURE P_FACT_NET(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);
  --����FACT_OPERATOR����
  PROCEDURE P_FACT_OPERATOR(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_REGION����
  PROCEDURE P_FACT_REGION(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_SUM_REP����
  PROCEDURE P_FACT_SUM_REP(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY_DVID����
  PROCEDURE P_FACT_GENERAL_DVID(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR_DVID����
  PROCEDURE P_FACT_GENERAL_HOUR_DVID(P_LOGTIME IN VARCHAR2,
                                     P_ERRCODE OUT NUMBER,
                                     P_ERRSTR  OUT VARCHAR2);
  --����FACT_CEVENT����
  PROCEDURE P_FACT_CEVENT(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_COMP_CEVENT����
  PROCEDURE P_FACT_COMP_CEVENT(P_LOGTIME IN VARCHAR2,
                               P_ERRCODE OUT NUMBER,
                               P_ERRSTR  OUT VARCHAR2);
  --����FACT_DAILY_REPORT����                         
  PROCEDURE P_FACT_DAILY_REPORT(P_LOGTIME IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE - 1,
                                                                      'YYYY-MM-DD'),
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
END PKG_FACT_100230;
/

prompt
prompt Creating package PKG_FACT_100231
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FACT_100231" IS
  --����ȫ��
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --����ά����Ϣ
  PROCEDURE P_DIM_OTHER(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR����
  PROCEDURE P_FACT_GENERAL_HOUR(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY����
  PROCEDURE P_FACT_GENERAL(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_FIRSTPAY����
  PROCEDURE P_FACT_FIRSTPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_PAYHABIT����
  PROCEDURE P_FACT_PAYHABIT(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_ORDER����
  PROCEDURE P_FACT_ORDER(P_LOGTIME IN VARCHAR2,
                         P_ERRCODE OUT NUMBER,
                         P_ERRSTR  OUT VARCHAR2);
  --����FACT_REMAIN����
  PROCEDURE P_FACT_REMAIN(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_LOST����
  PROCEDURE P_FACT_LOST(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_LEVELPAY����
  PROCEDURE P_FACT_LEVELPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_LEVEL����
  PROCEDURE P_FACT_GENERAL_LEVEL(P_LOGTIME IN VARCHAR2,
                                 P_ERRCODE OUT NUMBER,
                                 P_ERRSTR  OUT VARCHAR2);
  --����FACT_LTV����
  PROCEDURE P_FACT_LTV(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);

  --����FACT_BACK����
  PROCEDURE P_FACT_BACK(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_MISS_FIRST����
  PROCEDURE P_FACT_MISS_FIRST(P_LOGTIME IN VARCHAR2,
                              P_ERRCODE OUT NUMBER,
                              P_ERRSTR  OUT VARCHAR2);
  --����FACT_DVID����
  PROCEDURE P_FACT_DVID(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_VC����
  PROCEDURE P_FACT_VC(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);
  --����FACT_NET����
  PROCEDURE P_FACT_NET(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);
  --����FACT_OPERATOR����
  PROCEDURE P_FACT_OPERATOR(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_REGION����
  PROCEDURE P_FACT_REGION(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_SUM_REP����
  PROCEDURE P_FACT_SUM_REP(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY_DVID����
  PROCEDURE P_FACT_GENERAL_DVID(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR_DVID����
  PROCEDURE P_FACT_GENERAL_HOUR_DVID(P_LOGTIME IN VARCHAR2,
                                     P_ERRCODE OUT NUMBER,
                                     P_ERRSTR  OUT VARCHAR2);
  --����FACT_CEVENT����
  PROCEDURE P_FACT_CEVENT(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_COMP_CEVENT����
  PROCEDURE P_FACT_COMP_CEVENT(P_LOGTIME IN VARCHAR2,
                               P_ERRCODE OUT NUMBER,
                               P_ERRSTR  OUT VARCHAR2);
  --����FACT_DAILY_REPORT����                         
  PROCEDURE P_FACT_DAILY_REPORT(P_LOGTIME IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE - 1,
                                                                      'YYYY-MM-DD'),
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
END PKG_FACT_100231;
/

prompt
prompt Creating package PKG_FACT_100241
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FACT_100241" IS
  --����ȫ��
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --����ά����Ϣ
  PROCEDURE P_DIM_OTHER(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR����
  PROCEDURE P_FACT_GENERAL_HOUR(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY����
  PROCEDURE P_FACT_GENERAL(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_FIRSTPAY����
  PROCEDURE P_FACT_FIRSTPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_PAYHABIT����
  PROCEDURE P_FACT_PAYHABIT(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_ORDER����
  PROCEDURE P_FACT_ORDER(P_LOGTIME IN VARCHAR2,
                         P_ERRCODE OUT NUMBER,
                         P_ERRSTR  OUT VARCHAR2);
  --����FACT_REMAIN����
  PROCEDURE P_FACT_REMAIN(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_LOST����
  PROCEDURE P_FACT_LOST(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_LEVELPAY����
  PROCEDURE P_FACT_LEVELPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_LEVEL����
  PROCEDURE P_FACT_GENERAL_LEVEL(P_LOGTIME IN VARCHAR2,
                                 P_ERRCODE OUT NUMBER,
                                 P_ERRSTR  OUT VARCHAR2);
  --����FACT_LTV����
  PROCEDURE P_FACT_LTV(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);

  --����FACT_BACK����
  PROCEDURE P_FACT_BACK(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_MISS_FIRST����
  PROCEDURE P_FACT_MISS_FIRST(P_LOGTIME IN VARCHAR2,
                              P_ERRCODE OUT NUMBER,
                              P_ERRSTR  OUT VARCHAR2);
  --����FACT_DVID����
  PROCEDURE P_FACT_DVID(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2);
  --����FACT_VC����
  PROCEDURE P_FACT_VC(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);
  --����FACT_NET����
  PROCEDURE P_FACT_NET(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2);
  --����FACT_OPERATOR����
  PROCEDURE P_FACT_OPERATOR(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2);
  --����FACT_REGION����
  PROCEDURE P_FACT_REGION(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_SUM_REP����
  PROCEDURE P_FACT_SUM_REP(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_DAY_DVID����
  PROCEDURE P_FACT_GENERAL_DVID(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
  --����FACT_GENERAL_HOUR_DVID����
  PROCEDURE P_FACT_GENERAL_HOUR_DVID(P_LOGTIME IN VARCHAR2,
                                     P_ERRCODE OUT NUMBER,
                                     P_ERRSTR  OUT VARCHAR2);
  --����FACT_CEVENT����
  PROCEDURE P_FACT_CEVENT(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2);
  --����FACT_COMP_CEVENT����
  PROCEDURE P_FACT_COMP_CEVENT(P_LOGTIME IN VARCHAR2,
                               P_ERRCODE OUT NUMBER,
                               P_ERRSTR  OUT VARCHAR2);
  --����FACT_DAILY_REPORT����                         
  PROCEDURE P_FACT_DAILY_REPORT(P_LOGTIME IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE - 1,
                                                                      'YYYY-MM-DD'),
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2);
END PKG_FACT_100241;
/

prompt
prompt Creating package PKG_FACT_20002
prompt ===============================
prompt
CREATE OR REPLACE Package Pkg_Fact_20002 Is
  --����ȫ��
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --����ά����Ϣ
  Procedure p_Dim_Other(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR����
  Procedure p_Fact_General_Hour(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY����
  Procedure p_Fact_General(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_FIRSTPAY����
  Procedure p_Fact_Firstpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_PAYHABIT����
  Procedure p_Fact_Payhabit(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_ORDER����
  Procedure p_Fact_Order(p_Logtime In Varchar2,
                         p_Errcode Out Number,
                         p_Errstr  Out Varchar2);
  --����FACT_REMAIN����
  Procedure p_Fact_Remain(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_LOST����
  Procedure p_Fact_Lost(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_LEVELPAY����
  Procedure p_Fact_Levelpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_GENERAL_LEVEL����
  Procedure p_Fact_General_Level(p_Logtime In Varchar2,
                                 p_Errcode Out Number,
                                 p_Errstr  Out Varchar2);
  --����FACT_LTV����
  Procedure p_Fact_Ltv(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);

  --����FACT_BACK����
  Procedure p_Fact_Back(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_MISS_FIRST����
  Procedure p_Fact_Miss_First(p_Logtime In Varchar2,
                              p_Errcode Out Number,
                              p_Errstr  Out Varchar2);
  --����FACT_DVID����
  Procedure p_Fact_Dvid(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_VC����
  Procedure p_Fact_Vc(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);
  --����FACT_NET����
  Procedure p_Fact_Net(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);
  --����FACT_OPERATOR����
  Procedure p_Fact_Operator(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_REGION����
  Procedure p_Fact_Region(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_SUM_REP����
  Procedure p_Fact_Sum_Rep(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY_DVID����
  Procedure p_Fact_General_Dvid(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR_DVID����
  Procedure p_Fact_General_Hour_Dvid(p_Logtime In Varchar2,
                                     p_Errcode Out Number,
                                     p_Errstr  Out Varchar2);
  --����FACT_CEVENT����
  Procedure p_Fact_Cevent(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_COMP_CEVENT����
  Procedure p_Fact_Comp_Cevent(p_Logtime In Varchar2,
                               p_Errcode Out Number,
                               p_Errstr  Out Varchar2);
  --����FACT_DAILY_REPORT����                         
  Procedure p_Fact_Daily_Report(p_Logtime In Varchar2 Default To_Char(Sysdate - 1,
                                                                      'YYYY-MM-DD'),
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
End Pkg_Fact_20002;
/

prompt
prompt Creating package PKG_FACT_20003
prompt ===============================
prompt
CREATE OR REPLACE Package Pkg_Fact_20003 Is
  --����ά����Ϣ
  Procedure p_Dim_Other(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR����
  Procedure p_Fact_General_Hour(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY����
  Procedure p_Fact_General(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_FIRSTPAY����
  Procedure p_Fact_Firstpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_PAYHABIT����
  Procedure p_Fact_Payhabit(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_ORDER����
  Procedure p_Fact_Order(p_Logtime In Varchar2,
                         p_Errcode Out Number,
                         p_Errstr  Out Varchar2);
  --����FACT_REMAIN����
  Procedure p_Fact_Remain(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_LOST����
  Procedure p_Fact_Lost(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_LEVELPAY����
  Procedure p_Fact_Levelpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_GENERAL_LEVEL����
  Procedure p_Fact_General_Level(p_Logtime In Varchar2,
                                 p_Errcode Out Number,
                                 p_Errstr  Out Varchar2);
  --����FACT_LTV����
  Procedure p_Fact_Ltv(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);

  --����FACT_BACK����
  Procedure p_Fact_Back(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_MISS_FIRST����
  Procedure p_Fact_Miss_First(p_Logtime In Varchar2,
                              p_Errcode Out Number,
                              p_Errstr  Out Varchar2);
  --����FACT_DVID����
  Procedure p_Fact_Dvid(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_VC����
  Procedure p_Fact_Vc(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);
  --����FACT_NET����
  Procedure p_Fact_Net(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);
  --����FACT_OPERATOR����
  Procedure p_Fact_Operator(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_REGION����
  Procedure p_Fact_Region(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����Fact_Sum_Rep����
  Procedure p_Fact_Sum_Rep(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
End Pkg_Fact_20003;
/

prompt
prompt Creating package PKG_FACT_DEMO
prompt ==============================
prompt
CREATE OR REPLACE Package Pkg_Fact_demo Is
  --����ȫ��
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --����ά����Ϣ
  Procedure p_Dim_Other(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR����
  Procedure p_Fact_General_Hour(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY����
  Procedure p_Fact_General(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_FIRSTPAY����
  Procedure p_Fact_Firstpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_PAYHABIT����
  Procedure p_Fact_Payhabit(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_ORDER����
  Procedure p_Fact_Order(p_Logtime In Varchar2,
                         p_Errcode Out Number,
                         p_Errstr  Out Varchar2);
  --����FACT_REMAIN����
  Procedure p_Fact_Remain(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_LOST����
  Procedure p_Fact_Lost(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_LEVELPAY����
  Procedure p_Fact_Levelpay(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_GENERAL_LEVEL����
  Procedure p_Fact_General_Level(p_Logtime In Varchar2,
                                 p_Errcode Out Number,
                                 p_Errstr  Out Varchar2);
  --����FACT_LTV����
  Procedure p_Fact_Ltv(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);

  --����FACT_BACK����
  Procedure p_Fact_Back(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_MISS_FIRST����
  Procedure p_Fact_Miss_First(p_Logtime In Varchar2,
                              p_Errcode Out Number,
                              p_Errstr  Out Varchar2);
  --����FACT_DVID����
  Procedure p_Fact_Dvid(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --����FACT_VC����
  Procedure p_Fact_Vc(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);
  --����FACT_NET����
  Procedure p_Fact_Net(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);
  --����FACT_OPERATOR����
  Procedure p_Fact_Operator(p_Logtime In Varchar2,
                            p_Errcode Out Number,
                            p_Errstr  Out Varchar2);
  --����FACT_REGION����
  Procedure p_Fact_Region(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_SUM_REP����
  Procedure p_Fact_Sum_Rep(p_Logtime In Varchar2,
                           p_Errcode Out Number,
                           p_Errstr  Out Varchar2);
  --����FACT_GENERAL_DAY_DVID����
  Procedure p_Fact_General_Dvid(p_Logtime In Varchar2,
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
  --����FACT_GENERAL_HOUR_DVID����
  Procedure p_Fact_General_Hour_Dvid(p_Logtime In Varchar2,
                                     p_Errcode Out Number,
                                     p_Errstr  Out Varchar2);
  --����FACT_CEVENT����
  Procedure p_Fact_Cevent(p_Logtime In Varchar2,
                          p_Errcode Out Number,
                          p_Errstr  Out Varchar2);
  --����FACT_COMP_CEVENT����
  Procedure p_Fact_Comp_Cevent(p_Logtime In Varchar2,
                               p_Errcode Out Number,
                               p_Errstr  Out Varchar2);
  --����FACT_DAILY_REPORT����                         
  Procedure p_Fact_Daily_Report(p_Logtime In Varchar2 Default To_Char(Sysdate - 1,
                                                                      'YYYY-MM-DD'),
                                p_Errcode Out Number,
                                p_Errstr  Out Varchar2);
End Pkg_Fact_demo;
/


spool off
