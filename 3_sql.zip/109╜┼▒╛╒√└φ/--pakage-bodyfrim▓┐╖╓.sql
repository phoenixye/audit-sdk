------------------------------------------------------------
-- Export file for user DEVELOPER@BI_RACDB1_111.13.20.109 --
-- Created by Administrator on 2015/6/4, 17:05:51 ----------
------------------------------------------------------------

set define off
spool --pakage-bodyfrim����.log

prompt
prompt Creating package PKG_FIRM_100091
prompt ================================
prompt
CREATE OR REPLACE Package Pkg_Firm_100091 Is

  -- Author  : ADMINISTRATOR
  -- Created : 2014-11-04 16:24:47
  -- Purpose : ��˾���ݲɼ�

  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2);
  --��˾�����豸�ɼ�                        
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);

End Pkg_Firm_100091;
/

prompt
prompt Creating package PKG_FIRM_100105
prompt ================================
prompt
CREATE OR REPLACE Package Pkg_Firm_100105 Is

  -- Author  : ADMINISTRATOR
  -- Created : 2014-11-04 16:24:47
  -- Purpose : ��˾���ݲɼ�

  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2);
  --��˾�����豸�ɼ�                        
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);

End Pkg_Firm_100105;
/

prompt
prompt Creating package PKG_FIRM_100131
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100131" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100131;
/

prompt
prompt Creating package PKG_FIRM_100132
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100132" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100132;
/

prompt
prompt Creating package PKG_FIRM_100138
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100138" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100138;
/

prompt
prompt Creating package PKG_FIRM_100139
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100139" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100139;
/

prompt
prompt Creating package PKG_FIRM_100150
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100150" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100150;
/

prompt
prompt Creating package PKG_FIRM_100167
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100167" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100167;
/

prompt
prompt Creating package PKG_FIRM_100169
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100169" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100169;
/

prompt
prompt Creating package PKG_FIRM_100172
prompt ================================
prompt
CREATE OR REPLACE Package Pkg_Firm_100172 Is

  -- Author  : ADMINISTRATOR
  -- Created : 2014-11-04 16:24:47
  -- Purpose : ��˾���ݲɼ�

  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2);
  --��˾�����豸�ɼ�                        
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);

End Pkg_Firm_100172;
/

prompt
prompt Creating package PKG_FIRM_100173
prompt ================================
prompt
CREATE OR REPLACE Package Pkg_Firm_100173 Is

  -- Author  : ADMINISTRATOR
  -- Created : 2014-11-04 16:24:47
  -- Purpose : ��˾���ݲɼ�

  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2);
  --��˾�����豸�ɼ�                        
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);

End Pkg_Firm_100173;
/

prompt
prompt Creating package PKG_FIRM_100174
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100174" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100174;
/

prompt
prompt Creating package PKG_FIRM_100176
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100176" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100176;
/

prompt
prompt Creating package PKG_FIRM_100177
prompt ================================
prompt
CREATE OR REPLACE Package Pkg_Firm_100177 Is

  -- Author  : ADMINISTRATOR
  -- Created : 2014-11-04 16:24:47
  -- Purpose : ��˾���ݲɼ�

  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2);
  --��˾�����豸�ɼ�                        
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);

End Pkg_Firm_100177;
/

prompt
prompt Creating package PKG_FIRM_100178
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100178" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100178;
/

prompt
prompt Creating package PKG_FIRM_100179
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100179" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100179;
/

prompt
prompt Creating package PKG_FIRM_100181
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100181" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100181;
/

prompt
prompt Creating package PKG_FIRM_100190
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100190" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100190;
/

prompt
prompt Creating package PKG_FIRM_100192
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100192" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100192;
/

prompt
prompt Creating package PKG_FIRM_100193
prompt ================================
prompt
CREATE OR REPLACE Package Pkg_Firm_100193 Is

  -- Author  : ADMINISTRATOR
  -- Created : 2014-11-04 16:24:47
  -- Purpose : ��˾���ݲɼ�

  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2);
  --��˾�����豸�ɼ�                        
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);

End Pkg_Firm_100193;
/

prompt
prompt Creating package PKG_FIRM_100194
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100194" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100194;
/

prompt
prompt Creating package PKG_FIRM_100196
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100196" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100196;
/

prompt
prompt Creating package PKG_FIRM_100197
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100197" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100197;
/

prompt
prompt Creating package PKG_FIRM_100198
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100198" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100198;
/

prompt
prompt Creating package PKG_FIRM_100201
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100201" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100201;
/

prompt
prompt Creating package PKG_FIRM_100202
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100202" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100202;
/

prompt
prompt Creating package PKG_FIRM_100209
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100209" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100209;
/

prompt
prompt Creating package PKG_FIRM_100228
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100228" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100228;
/

prompt
prompt Creating package PKG_FIRM_100230
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100230" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100230;
/

prompt
prompt Creating package PKG_FIRM_100231
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100231" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100231;
/

prompt
prompt Creating package PKG_FIRM_100241
prompt ================================
prompt
CREATE OR REPLACE PACKAGE "PKG_FIRM_100241" IS

  -- AUTHOR  : ADMINISTRATOR
  -- CREATED : 2014-11-04 16:24:47
  -- PURPOSE : ��˾���ݲɼ�

  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2);
  --��˾�����豸�ɼ�                        
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2);

END PKG_FIRM_100241;
/

prompt
prompt Creating package PKG_FIRM_20002
prompt ===============================
prompt
CREATE OR REPLACE Package Pkg_Firm_20002 Is

  -- Author  : ADMINISTRATOR
  -- Created : 2014-11-04 16:24:47
  -- Purpose : ��˾���ݲɼ�

  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2);
  --��˾�����豸�ɼ�                        
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);

End Pkg_Firm_20002;
/

prompt
prompt Creating package PKG_FIRM_DEMO
prompt ==============================
prompt
CREATE OR REPLACE Package Pkg_Firm_demo Is

  -- Author  : ADMINISTRATOR
  -- Created : 2014-11-04 16:24:47
  -- Purpose : ��˾���ݲɼ�

  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2);
  --��˾�����豸�ɼ�                        
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2);

End Pkg_Firm_demo;
/

prompt
prompt Creating package body PKG_FIRM_100091
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100091 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100091.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100091', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100091');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100091_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100091', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100091');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100091', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100091.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100091', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100091');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100091_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100091', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100091');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100091', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100091;
/

prompt
prompt Creating package body PKG_FIRM_100105
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100105 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100105.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100105', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100105');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100105_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100105', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100105');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100105', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100105.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100105', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100105');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100105_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100105', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100105');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100105', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100105;
/

prompt
prompt Creating package body PKG_FIRM_100131
prompt =====================================
prompt
CREATE OR REPLACE PACKAGE BODY "PKG_FIRM_100131" IS
  /******************************************ִ������***************************************************************/
  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2) IS
  BEGIN
  
    P_NU_MAC(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    P_NU_DVID(P_LOGTIME, P_ERRCODE, P_ERRSTR);
  
  END;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FIRM_100131.P_NU_MAC';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100131', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    V_ERRPOSITION := '1-1';
    DELETE FROM T_FIRM_NU_MAC T
     WHERE T.THEDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') AND UPPER(T.GAMEID)=UPPER('100131');
    COMMIT;
    V_ERRPOSITION := '1-2';
    INSERT INTO T_FIRM_NU_MAC
      SELECT DISTINCT TO_CHAR(T.THEDATE, 'YYYY-MM-DD') THEDATE,
                      T.GAMEID,
                      T.CHANNELID,
                      T.DVID,
                      D.PLATFORM,
                      D.COUNTRY_TYPE,
                      D.ONLINE_TYPE,
                      SYSDATE,
                      V_ERRSOURCE
        FROM T_100131_NU_MAC T
       INNER JOIN DIM_APP D
          ON T.GAMEID = D.APPID
       WHERE T.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
         AND T.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1);
    COMMIT;
  
    PKG_FACT_FIRM.P_FACT_MAC(P_LOGTIME, P_ERRCODE, P_ERRSTR);
  
    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100131', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_FIRM_NU_MAC';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100131');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100131', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FIRM_100131.P_NU_DVID';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100131', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    V_ERRPOSITION := '1-1';
    DELETE FROM T_FIRM_NU_DVID T
     WHERE T.THEDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') AND UPPER(T.GAMEID)=UPPER('100131');
    COMMIT;
    V_ERRPOSITION := '1-2';
    INSERT INTO T_FIRM_NU_DVID
      SELECT TO_CHAR(T.THEDATE, 'YYYY-MM-DD') THEDATE,
             T.GAMEID,
             T.CHANNELID,
             T.DVID,
             D.PLATFORM,
             D.COUNTRY_TYPE,
             D.ONLINE_TYPE,
             SYSDATE,
             V_ERRSOURCE
        FROM T_100131_NU_DVID T
       INNER JOIN DIM_APP D
          ON T.GAMEID = D.APPID
       WHERE T.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
         AND T.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1);
    COMMIT;
  
    PKG_FACT_FIRM.P_FACT_DVID(P_LOGTIME, P_ERRCODE, P_ERRSTR);
  
    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100131', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_FIRM_NU_DVID';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100131');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100131', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;
END PKG_FIRM_100131;
/

prompt
prompt Creating package body PKG_FIRM_100132
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100132 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100132.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100132', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100132');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100132_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100132', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100132');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100132', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100132.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100132', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100132');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100132_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100132', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100132');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100132', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100132;
/

prompt
prompt Creating package body PKG_FIRM_100138
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100138 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100138.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100138', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100138');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100138_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100138', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100138');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100138', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100138.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100138', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100138');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100138_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100138', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100138');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100138', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100138;
/

prompt
prompt Creating package body PKG_FIRM_100139
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100139 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100139.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100139', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100139');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100139_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100139', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100139');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100139', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100139.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100139', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100139');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100139_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100139', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100139');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100139', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100139;
/

prompt
prompt Creating package body PKG_FIRM_100150
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100150 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100150.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100150', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100150');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100150_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100150', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100150');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100150', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100150.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100150', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100150');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100150_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100150', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100150');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100150', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100150;
/

prompt
prompt Creating package body PKG_FIRM_100167
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100167 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100167.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100167', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100167');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100167_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100167', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100167');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100167', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100167.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100167', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100167');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100167_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100167', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100167');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100167', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100167;
/

prompt
prompt Creating package body PKG_FIRM_100169
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100169 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100169.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100169', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100169');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100169_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100169', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100169');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100169', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100169.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100169', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100169');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100169_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100169', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100169');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100169', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100169;
/

prompt
prompt Creating package body PKG_FIRM_100172
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100172 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100172.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100172', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100172');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100172_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100172', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100172');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100172', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100172.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100172', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100172');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100172_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100172', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100172');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100172', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100172;
/

prompt
prompt Creating package body PKG_FIRM_100173
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100173 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100173.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100173', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100173');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100173_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100173', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100173');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100173', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100173.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100173', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100173');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100173_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100173', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100173');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100173', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100173;
/

prompt
prompt Creating package body PKG_FIRM_100174
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100174 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100174.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100174', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100174');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100174_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100174', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100174');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100174', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100174.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100174', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100174');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100174_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100174', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100174');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100174', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100174;
/

prompt
prompt Creating package body PKG_FIRM_100176
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100176 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100176.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100176', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100176');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100176_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100176', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100176');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100176', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100176.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100176', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100176');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100176_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100176', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100176');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100176', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100176;
/

prompt
prompt Creating package body PKG_FIRM_100177
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100177 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100177.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100177', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100177');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100177_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100177', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100177');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100177', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100177.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100177', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100177');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100177_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100177', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100177');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100177', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100177;
/

prompt
prompt Creating package body PKG_FIRM_100178
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100178 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100178.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100178', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100178');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100178_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100178', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100178');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100178', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100178.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100178', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100178');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100178_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100178', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100178');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100178', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100178;
/

prompt
prompt Creating package body PKG_FIRM_100179
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100179 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100179.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100179', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100179');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100179_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100179', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100179');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100179', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100179.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100179', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100179');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100179_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100179', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100179');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100179', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100179;
/

prompt
prompt Creating package body PKG_FIRM_100181
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100181 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100181.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100181', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100181');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100181_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100181', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100181');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100181', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100181.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100181', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100181');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100181_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100181', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100181');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100181', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100181;
/

prompt
prompt Creating package body PKG_FIRM_100190
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100190 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100190.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100190', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100190');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100190_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100190', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100190');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100190', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100190.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100190', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100190');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100190_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100190', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100190');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100190', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100190;
/

prompt
prompt Creating package body PKG_FIRM_100192
prompt =====================================
prompt
CREATE OR REPLACE PACKAGE BODY "PKG_FIRM_100192" IS
  /******************************************ִ������***************************************************************/
  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2) IS
  BEGIN
  
    P_NU_MAC(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    P_NU_DVID(P_LOGTIME, P_ERRCODE, P_ERRSTR);
  
  END;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FIRM_100192.P_NU_MAC';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100192', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    V_ERRPOSITION := '1-1';
    DELETE FROM T_FIRM_NU_MAC T
     WHERE T.THEDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') AND UPPER(T.GAMEID)=UPPER('100192');
    COMMIT;
    V_ERRPOSITION := '1-2';
    INSERT INTO T_FIRM_NU_MAC
      SELECT DISTINCT TO_CHAR(T.THEDATE, 'YYYY-MM-DD') THEDATE,
                      T.GAMEID,
                      T.CHANNELID,
                      T.DVID,
                      D.PLATFORM,
                      D.COUNTRY_TYPE,
                      D.ONLINE_TYPE,
                      SYSDATE,
                      V_ERRSOURCE
        FROM T_100192_NU_MAC T
       INNER JOIN DIM_APP D
          ON T.GAMEID = D.APPID
       WHERE T.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
         AND T.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1);
    COMMIT;
  
    PKG_FACT_FIRM.P_FACT_MAC(P_LOGTIME, P_ERRCODE, P_ERRSTR);
  
    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100192', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_FIRM_NU_MAC';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100192');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100192', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FIRM_100192.P_NU_DVID';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100192', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    V_ERRPOSITION := '1-1';
    DELETE FROM T_FIRM_NU_DVID T
     WHERE T.THEDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') AND UPPER(T.GAMEID)=UPPER('100192');
    COMMIT;
    V_ERRPOSITION := '1-2';
    INSERT INTO T_FIRM_NU_DVID
      SELECT TO_CHAR(T.THEDATE, 'YYYY-MM-DD') THEDATE,
             T.GAMEID,
             T.CHANNELID,
             T.DVID,
             D.PLATFORM,
             D.COUNTRY_TYPE,
             D.ONLINE_TYPE,
             SYSDATE,
             V_ERRSOURCE
        FROM T_100192_NU_DVID T
       INNER JOIN DIM_APP D
          ON T.GAMEID = D.APPID
       WHERE T.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
         AND T.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1);
    COMMIT;
  
    PKG_FACT_FIRM.P_FACT_DVID(P_LOGTIME, P_ERRCODE, P_ERRSTR);
  
    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100192', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_FIRM_NU_DVID';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100192');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100192', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;
END PKG_FIRM_100192;
/

prompt
prompt Creating package body PKG_FIRM_100193
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100193 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100193.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100193', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100193');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100193_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100193', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100193');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100193', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100193.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100193', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100193');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100193_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100193', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100193');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100193', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100193;
/

prompt
prompt Creating package body PKG_FIRM_100194
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100194 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100194.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100194', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100194');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100194_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100194', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100194');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100194', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100194.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100194', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100194');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100194_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100194', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100194');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100194', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100194;
/

prompt
prompt Creating package body PKG_FIRM_100196
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100196 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100196.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100196', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100196');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100196_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100196', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100196');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100196', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100196.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100196', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100196');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100196_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100196', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100196');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100196', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100196;
/

prompt
prompt Creating package body PKG_FIRM_100197
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100197 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100197.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100197', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100197');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100197_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100197', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100197');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100197', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100197.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100197', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100197');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100197_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100197', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100197');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100197', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100197;
/

prompt
prompt Creating package body PKG_FIRM_100198
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100198 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100198.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100198', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100198');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100198_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100198', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100198');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100198', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100198.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100198', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100198');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100198_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100198', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100198');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100198', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100198;
/

prompt
prompt Creating package body PKG_FIRM_100201
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100201 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100201.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100201', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100201');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100201_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100201', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100201');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100201', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100201.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100201', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100201');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100201_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100201', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100201');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100201', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100201;
/

prompt
prompt Creating package body PKG_FIRM_100202
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100202 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100202.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100202', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100202');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100202_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100202', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100202');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100202', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100202.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100202', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100202');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100202_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100202', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100202');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100202', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100202;
/

prompt
prompt Creating package body PKG_FIRM_100209
prompt =====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_100209 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100209.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100209', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100209');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_100209_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100209', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100209');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100209', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_100209.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100209', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('100209');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_100209_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '100209', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100209');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100209', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_100209;
/

prompt
prompt Creating package body PKG_FIRM_100228
prompt =====================================
prompt
CREATE OR REPLACE PACKAGE BODY "PKG_FIRM_100228" IS
  /******************************************ִ������***************************************************************/
  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2) IS
  BEGIN
  
    P_NU_MAC(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    P_NU_DVID(P_LOGTIME, P_ERRCODE, P_ERRSTR);
  
  END;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FIRM_100228.P_NU_MAC';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100228', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    V_ERRPOSITION := '1-1';
    DELETE FROM T_FIRM_NU_MAC T
     WHERE T.THEDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') AND UPPER(T.GAMEID)=UPPER('100228');
    COMMIT;
    V_ERRPOSITION := '1-2';
    INSERT INTO T_FIRM_NU_MAC
      SELECT DISTINCT TO_CHAR(T.THEDATE, 'YYYY-MM-DD') THEDATE,
                      T.GAMEID,
                      T.CHANNELID,
                      T.DVID,
                      D.PLATFORM,
                      D.COUNTRY_TYPE,
                      D.ONLINE_TYPE,
                      SYSDATE,
                      V_ERRSOURCE
        FROM T_100228_NU_MAC T
       INNER JOIN DIM_APP D
          ON T.GAMEID = D.APPID
       WHERE T.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
         AND T.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1);
    COMMIT;
  
    PKG_FACT_FIRM.P_FACT_MAC(P_LOGTIME, P_ERRCODE, P_ERRSTR);
  
    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100228', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_FIRM_NU_MAC';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100228');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100228', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FIRM_100228.P_NU_DVID';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100228', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    V_ERRPOSITION := '1-1';
    DELETE FROM T_FIRM_NU_DVID T
     WHERE T.THEDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') AND UPPER(T.GAMEID)=UPPER('100228');
    COMMIT;
    V_ERRPOSITION := '1-2';
    INSERT INTO T_FIRM_NU_DVID
      SELECT TO_CHAR(T.THEDATE, 'YYYY-MM-DD') THEDATE,
             T.GAMEID,
             T.CHANNELID,
             T.DVID,
             D.PLATFORM,
             D.COUNTRY_TYPE,
             D.ONLINE_TYPE,
             SYSDATE,
             V_ERRSOURCE
        FROM T_100228_NU_DVID T
       INNER JOIN DIM_APP D
          ON T.GAMEID = D.APPID
       WHERE T.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
         AND T.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1);
    COMMIT;
  
    PKG_FACT_FIRM.P_FACT_DVID(P_LOGTIME, P_ERRCODE, P_ERRSTR);
  
    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100228', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_FIRM_NU_DVID';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100228');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100228', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;
END PKG_FIRM_100228;
/

prompt
prompt Creating package body PKG_FIRM_100230
prompt =====================================
prompt
CREATE OR REPLACE PACKAGE BODY "PKG_FIRM_100230" IS
  /******************************************ִ������***************************************************************/
  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2) IS
  BEGIN
  
    P_NU_MAC(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    P_NU_DVID(P_LOGTIME, P_ERRCODE, P_ERRSTR);
  
  END;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FIRM_100230.P_NU_MAC';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100230', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    V_ERRPOSITION := '1-1';
    DELETE FROM T_FIRM_NU_MAC T
     WHERE T.THEDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') AND UPPER(T.GAMEID)=UPPER('100230');
    COMMIT;
    V_ERRPOSITION := '1-2';
    INSERT INTO T_FIRM_NU_MAC
      SELECT DISTINCT TO_CHAR(T.THEDATE, 'YYYY-MM-DD') THEDATE,
                      T.GAMEID,
                      T.CHANNELID,
                      T.DVID,
                      D.PLATFORM,
                      D.COUNTRY_TYPE,
                      D.ONLINE_TYPE,
                      SYSDATE,
                      V_ERRSOURCE
        FROM T_100230_NU_MAC T
       INNER JOIN DIM_APP D
          ON T.GAMEID = D.APPID
       WHERE T.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
         AND T.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1);
    COMMIT;
  
    PKG_FACT_FIRM.P_FACT_MAC(P_LOGTIME, P_ERRCODE, P_ERRSTR);
  
    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100230', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_FIRM_NU_MAC';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100230');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100230', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FIRM_100230.P_NU_DVID';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100230', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    V_ERRPOSITION := '1-1';
    DELETE FROM T_FIRM_NU_DVID T
     WHERE T.THEDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') AND UPPER(T.GAMEID)=UPPER('100230');
    COMMIT;
    V_ERRPOSITION := '1-2';
    INSERT INTO T_FIRM_NU_DVID
      SELECT TO_CHAR(T.THEDATE, 'YYYY-MM-DD') THEDATE,
             T.GAMEID,
             T.CHANNELID,
             T.DVID,
             D.PLATFORM,
             D.COUNTRY_TYPE,
             D.ONLINE_TYPE,
             SYSDATE,
             V_ERRSOURCE
        FROM T_100230_NU_DVID T
       INNER JOIN DIM_APP D
          ON T.GAMEID = D.APPID
       WHERE T.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
         AND T.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1);
    COMMIT;
  
    PKG_FACT_FIRM.P_FACT_DVID(P_LOGTIME, P_ERRCODE, P_ERRSTR);
  
    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100230', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_FIRM_NU_DVID';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100230');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100230', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;
END PKG_FIRM_100230;
/

prompt
prompt Creating package body PKG_FIRM_100231
prompt =====================================
prompt
CREATE OR REPLACE PACKAGE BODY "PKG_FIRM_100231" IS
  /******************************************ִ������***************************************************************/
  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2) IS
  BEGIN
  
    P_NU_MAC(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    P_NU_DVID(P_LOGTIME, P_ERRCODE, P_ERRSTR);
  
  END;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FIRM_100231.P_NU_MAC';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100231', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    V_ERRPOSITION := '1-1';
    DELETE FROM T_FIRM_NU_MAC T
     WHERE T.THEDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') AND UPPER(T.GAMEID)=UPPER('100231');
    COMMIT;
    V_ERRPOSITION := '1-2';
    INSERT INTO T_FIRM_NU_MAC
      SELECT DISTINCT TO_CHAR(T.THEDATE, 'YYYY-MM-DD') THEDATE,
                      T.GAMEID,
                      T.CHANNELID,
                      T.DVID,
                      D.PLATFORM,
                      D.COUNTRY_TYPE,
                      D.ONLINE_TYPE,
                      SYSDATE,
                      V_ERRSOURCE
        FROM T_100231_NU_MAC T
       INNER JOIN DIM_APP D
          ON T.GAMEID = D.APPID
       WHERE T.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
         AND T.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1);
    COMMIT;
  
    PKG_FACT_FIRM.P_FACT_MAC(P_LOGTIME, P_ERRCODE, P_ERRSTR);
  
    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100231', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_FIRM_NU_MAC';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100231');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100231', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FIRM_100231.P_NU_DVID';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100231', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    V_ERRPOSITION := '1-1';
    DELETE FROM T_FIRM_NU_DVID T
     WHERE T.THEDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') AND UPPER(T.GAMEID)=UPPER('100231');
    COMMIT;
    V_ERRPOSITION := '1-2';
    INSERT INTO T_FIRM_NU_DVID
      SELECT TO_CHAR(T.THEDATE, 'YYYY-MM-DD') THEDATE,
             T.GAMEID,
             T.CHANNELID,
             T.DVID,
             D.PLATFORM,
             D.COUNTRY_TYPE,
             D.ONLINE_TYPE,
             SYSDATE,
             V_ERRSOURCE
        FROM T_100231_NU_DVID T
       INNER JOIN DIM_APP D
          ON T.GAMEID = D.APPID
       WHERE T.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
         AND T.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1);
    COMMIT;
  
    PKG_FACT_FIRM.P_FACT_DVID(P_LOGTIME, P_ERRCODE, P_ERRSTR);
  
    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100231', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_FIRM_NU_DVID';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100231');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100231', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;
END PKG_FIRM_100231;
/

prompt
prompt Creating package body PKG_FIRM_100241
prompt =====================================
prompt
CREATE OR REPLACE PACKAGE BODY "PKG_FIRM_100241" IS
  /******************************************ִ������***************************************************************/
  --ִ������
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2) IS
  BEGIN
  
    P_NU_MAC(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    P_NU_DVID(P_LOGTIME, P_ERRCODE, P_ERRSTR);
  
  END;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_MAC(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FIRM_100241.P_NU_MAC';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100241', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    V_ERRPOSITION := '1-1';
    DELETE FROM T_FIRM_NU_MAC T
     WHERE T.THEDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') AND UPPER(T.GAMEID)=UPPER('100241');
    COMMIT;
    V_ERRPOSITION := '1-2';
    INSERT INTO T_FIRM_NU_MAC
      SELECT DISTINCT TO_CHAR(T.THEDATE, 'YYYY-MM-DD') THEDATE,
                      T.GAMEID,
                      T.CHANNELID,
                      T.DVID,
                      D.PLATFORM,
                      D.COUNTRY_TYPE,
                      D.ONLINE_TYPE,
                      SYSDATE,
                      V_ERRSOURCE
        FROM T_100241_NU_MAC T
       INNER JOIN DIM_APP D
          ON T.GAMEID = D.APPID
       WHERE T.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
         AND T.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1);
    COMMIT;
  
    PKG_FACT_FIRM.P_FACT_MAC(P_LOGTIME, P_ERRCODE, P_ERRSTR);
  
    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100241', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_FIRM_NU_MAC';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100241');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100241', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  PROCEDURE P_NU_DVID(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FIRM_100241.P_NU_DVID';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100241', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    V_ERRPOSITION := '1-1';
    DELETE FROM T_FIRM_NU_DVID T
     WHERE T.THEDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') AND UPPER(T.GAMEID)=UPPER('100241');
    COMMIT;
    V_ERRPOSITION := '1-2';
    INSERT INTO T_FIRM_NU_DVID
      SELECT TO_CHAR(T.THEDATE, 'YYYY-MM-DD') THEDATE,
             T.GAMEID,
             T.CHANNELID,
             T.DVID,
             D.PLATFORM,
             D.COUNTRY_TYPE,
             D.ONLINE_TYPE,
             SYSDATE,
             V_ERRSOURCE
        FROM T_100241_NU_DVID T
       INNER JOIN DIM_APP D
          ON T.GAMEID = D.APPID
       WHERE T.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
         AND T.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1);
    COMMIT;
  
    PKG_FACT_FIRM.P_FACT_DVID(P_LOGTIME, P_ERRCODE, P_ERRSTR);
  
    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100241', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_FIRM_NU_DVID';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100241');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100241', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;
END PKG_FIRM_100241;
/

prompt
prompt Creating package body PKG_FIRM_20002
prompt ====================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_20002 Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_20002.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '20002', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('20002');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_20002_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '20002', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '20002');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '20002', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_20002.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, '20002', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('20002');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_20002_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, '20002', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '20002');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, '20002', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_20002;
/

prompt
prompt Creating package body PKG_FIRM_DEMO
prompt ===================================
prompt
CREATE OR REPLACE Package Body Pkg_Firm_demo Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
  
    p_Nu_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Nu_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Mac(p_Logtime In Varchar2,
                     p_Errcode Out Number,
                     p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_demo.p_Nu_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, 'demo', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Mac t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('demo');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Mac
      Select Distinct To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
                      t.Gameid,
                      t.Channelid,
                      t.Dvid,
                      d.Platform,
                      d.Country_Type,
                      d.Online_Type,
                      Sysdate,
                      v_Errsource
        From t_demo_Nu_Mac t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, 'demo', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Mac';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           'demo');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, 'demo', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸�ɼ�***************************************************************/
  --��˾�����豸�ɼ�
  Procedure p_Nu_Dvid(p_Logtime In Varchar2,
                      p_Errcode Out Number,
                      p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Firm_demo.p_Nu_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, 'demo', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From t_Firm_Nu_Dvid t
     Where t.Thedate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD') And upper(t.gameid)=upper('demo');
    Commit;
    v_Errposition := '1-2';
    Insert Into t_Firm_Nu_Dvid
      Select To_Char(t.Thedate, 'yyyy-mm-dd') Thedate,
             t.Gameid,
             t.Channelid,
             t.Dvid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sysdate,
             v_Errsource
        From t_demo_Nu_Dvid t
       Inner Join Dim_App d
          On t.Gameid = d.Appid
       Where t.Thedate >= Trunc(Sysdate - v_Inputdate)
         And t.Thedate < Trunc(Sysdate - v_Inputdate + 1);
    Commit;
  
    Pkg_Fact_Firm.p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, 'demo', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=t_Firm_Nu_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           'demo');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, 'demo', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Firm_demo;
/


spool off
