------------------------------------------------------------
-- Export file for user DEVELOPER@BI_RACDB1_111.13.20.109 --
-- Created by Administrator on 2015/6/2, 17:27:29 ----------
------------------------------------------------------------

set define off
spool --��������T��6.log

prompt
prompt Creating table T_100201_CEVENT
prompt ==============================
prompt
create table T_100201_CEVENT
(
  thedate          VARCHAR2(10),
  datenum          NUMBER,
  appid            VARCHAR2(10),
  channelid        VARCHAR2(50),
  gameversion      VARCHAR2(50),
  dvid             VARCHAR2(50),
  accountid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  ilevel           NUMBER,
  roleid           VARCHAR2(50),
  eventkey         VARCHAR2(100),
  eventvalue_key   VARCHAR2(100),
  eventvalue_value VARCHAR2(100),
  ipaddr           VARCHAR2(50),
  prerowid         VARCHAR2(200)
)
;
comment on table T_100201_CEVENT
  is '�Զ����¼���ֱ�';
comment on column T_100201_CEVENT.thedate
  is '����';
comment on column T_100201_CEVENT.datenum
  is '�������ָ�ʽ';
comment on column T_100201_CEVENT.appid
  is '��Ϸ�� appid';
comment on column T_100201_CEVENT.channelid
  is '���� ID';
comment on column T_100201_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column T_100201_CEVENT.dvid
  is '�豸 ID��Ψһ�豸��';
comment on column T_100201_CEVENT.accountid
  is '�ʻ� id';
comment on column T_100201_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column T_100201_CEVENT.ilevel
  is '��ҵȼ�';
comment on column T_100201_CEVENT.roleid
  is '��ɫ id';
comment on column T_100201_CEVENT.eventkey
  is '�¼�����';
comment on column T_100201_CEVENT.eventvalue_key
  is '�¼�ֵ�е�key';
comment on column T_100201_CEVENT.eventvalue_value
  is '�¼�ֵ��key��Ӧ��ֵ';
comment on column T_100201_CEVENT.ipaddr
  is 'ip ��ַ';
comment on column T_100201_CEVENT.prerowid
  is 'ԭΨһ��ID';
create index IDX180_100201 on T_100201_CEVENT (THEDATE);

prompt
prompt Creating table T_100201_CONN
prompt ============================
prompt
create table T_100201_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100201_CONN
  is '����&��ʧ&������������������ע���˺ţ�ע���豸��';
comment on column T_100201_CONN.conndate
  is '����ʱ��';
comment on column T_100201_CONN.gameid
  is '��ϷID';
comment on column T_100201_CONN.channelid
  is '����ID';
comment on column T_100201_CONN.gameversion
  is '��Ϸ�汾';
comment on column T_100201_CONN.serverid
  is '����ID';
comment on column T_100201_CONN.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100201_CONN.position
  is 'λ����Ϣ';
comment on column T_100201_CONN.dvid
  is '�豸��';
comment on column T_100201_CONN.accountid
  is '�˺�ID';
comment on column T_100201_CONN.regdate
  is 'ע��ʱ��';
comment on column T_100201_CONN.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100201_CONN.regdate_as
  is 'ע��ʱ��(���з�����)';
create index IDX118_100201 on T_100201_CONN (CHANNELID);
create index IDX119_100201 on T_100201_CONN (SERVERID);
create index IDX120_100201 on T_100201_CONN (CONNDATE);

prompt
prompt Creating table T_100201_CONN_ACT
prompt ================================
prompt
create table T_100201_CONN_ACT
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100201_CONN_ACT
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100201_CONN_ACT.basedate
  is '����ʱ��';
comment on column T_100201_CONN_ACT.gameid
  is '��ϷID';
comment on column T_100201_CONN_ACT.channelid
  is '����ID';
comment on column T_100201_CONN_ACT.gameversion
  is '��Ϸ�汾';
comment on column T_100201_CONN_ACT.serverid
  is '����ID';
comment on column T_100201_CONN_ACT.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100201_CONN_ACT.position
  is 'λ����Ϣ';
comment on column T_100201_CONN_ACT.dvid
  is '�豸��';
comment on column T_100201_CONN_ACT.accountid
  is '�˺�';
comment on column T_100201_CONN_ACT.conndate
  is '��Ծʱ��';
comment on column T_100201_CONN_ACT.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_100201 on T_100201_CONN_ACT (CHANNELID);
create index IDX122_100201 on T_100201_CONN_ACT (SERVERID);
create index IDX123_100201 on T_100201_CONN_ACT (CONNDATE);
create index IDX124_100201 on T_100201_CONN_ACT (BASEDATE);

prompt
prompt Creating table T_100201_CONN_ACT_AS
prompt ===================================
prompt
create table T_100201_CONN_ACT_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100201_CONN_ACT_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100201_CONN_ACT_AS.basedate
  is '����ʱ��';
comment on column T_100201_CONN_ACT_AS.gameid
  is '��ϷID';
comment on column T_100201_CONN_ACT_AS.channelid
  is '����ID';
comment on column T_100201_CONN_ACT_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100201_CONN_ACT_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100201_CONN_ACT_AS.position
  is 'λ����Ϣ';
comment on column T_100201_CONN_ACT_AS.dvid
  is '�豸��';
comment on column T_100201_CONN_ACT_AS.accountid
  is '�˺�';
comment on column T_100201_CONN_ACT_AS.conndate
  is '��Ծʱ��';
comment on column T_100201_CONN_ACT_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX205_100201 on T_100201_CONN_ACT_AS (CHANNELID);
create index IDX206_100201 on T_100201_CONN_ACT_AS (CONNDATE);
create index IDX207_100201 on T_100201_CONN_ACT_AS (BASEDATE);

prompt
prompt Creating table T_100201_CONN_ACT_BAK
prompt ====================================
prompt
create table T_100201_CONN_ACT_BAK
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100201_CONN_ACT_BAK
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)���ݱ�';
comment on column T_100201_CONN_ACT_BAK.basedate
  is '����ʱ��';
comment on column T_100201_CONN_ACT_BAK.gameid
  is '��ϷID';
comment on column T_100201_CONN_ACT_BAK.channelid
  is '����ID';
comment on column T_100201_CONN_ACT_BAK.gameversion
  is '��Ϸ�汾';
comment on column T_100201_CONN_ACT_BAK.serverid
  is '����ID';
comment on column T_100201_CONN_ACT_BAK.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100201_CONN_ACT_BAK.position
  is 'λ����Ϣ';
comment on column T_100201_CONN_ACT_BAK.dvid
  is '�豸��';
comment on column T_100201_CONN_ACT_BAK.accountid
  is '�˺�';
comment on column T_100201_CONN_ACT_BAK.conndate
  is '��Ծʱ��';
comment on column T_100201_CONN_ACT_BAK.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_100201_BAK on T_100201_CONN_ACT_BAK (CHANNELID);
create index IDX122_100201_BAK on T_100201_CONN_ACT_BAK (SERVERID);
create index IDX123_100201_BAK on T_100201_CONN_ACT_BAK (CONNDATE);
create index IDX124_100201_BAK on T_100201_CONN_ACT_BAK (BASEDATE);

prompt
prompt Creating table T_100201_CONN_ACT_MAC
prompt ====================================
prompt
create table T_100201_CONN_ACT_MAC
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100201_CONN_ACT_MAC
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100201_CONN_ACT_MAC.basedate
  is '����ʱ��';
comment on column T_100201_CONN_ACT_MAC.gameid
  is '��ϷID';
comment on column T_100201_CONN_ACT_MAC.channelid
  is '����ID';
comment on column T_100201_CONN_ACT_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100201_CONN_ACT_MAC.serverid
  is '����ID';
comment on column T_100201_CONN_ACT_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100201_CONN_ACT_MAC.position
  is 'λ����Ϣ';
comment on column T_100201_CONN_ACT_MAC.dvid
  is '�豸��';
comment on column T_100201_CONN_ACT_MAC.accountid
  is '�˺�';
comment on column T_100201_CONN_ACT_MAC.conndate
  is '��Ծʱ��';
comment on column T_100201_CONN_ACT_MAC.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_100201 on T_100201_CONN_ACT_MAC (CHANNELID);
create index IDX126_100201 on T_100201_CONN_ACT_MAC (SERVERID);
create index IDX127_100201 on T_100201_CONN_ACT_MAC (CONNDATE);
create index IDX128_100201 on T_100201_CONN_ACT_MAC (BASEDATE);

prompt
prompt Creating table T_100201_CONN_ACT_MAC_AS
prompt =======================================
prompt
create table T_100201_CONN_ACT_MAC_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100201_CONN_ACT_MAC_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100201_CONN_ACT_MAC_AS.basedate
  is '����ʱ��';
comment on column T_100201_CONN_ACT_MAC_AS.gameid
  is '��ϷID';
comment on column T_100201_CONN_ACT_MAC_AS.channelid
  is '����ID';
comment on column T_100201_CONN_ACT_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100201_CONN_ACT_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100201_CONN_ACT_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100201_CONN_ACT_MAC_AS.dvid
  is '�豸��';
comment on column T_100201_CONN_ACT_MAC_AS.accountid
  is '�˺�';
comment on column T_100201_CONN_ACT_MAC_AS.conndate
  is '��Ծʱ��';
comment on column T_100201_CONN_ACT_MAC_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX202_100201 on T_100201_CONN_ACT_MAC_AS (CHANNELID);
create index IDX203_100201 on T_100201_CONN_ACT_MAC_AS (CONNDATE);
create index IDX204_100201 on T_100201_CONN_ACT_MAC_AS (BASEDATE);

prompt
prompt Creating table T_100201_CONN_ACT_MAC_BAK
prompt ========================================
prompt
create table T_100201_CONN_ACT_MAC_BAK
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100201_CONN_ACT_MAC_BAK
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)���ݱ�';
comment on column T_100201_CONN_ACT_MAC_BAK.basedate
  is '����ʱ��';
comment on column T_100201_CONN_ACT_MAC_BAK.gameid
  is '��ϷID';
comment on column T_100201_CONN_ACT_MAC_BAK.channelid
  is '����ID';
comment on column T_100201_CONN_ACT_MAC_BAK.gameversion
  is '��Ϸ�汾';
comment on column T_100201_CONN_ACT_MAC_BAK.serverid
  is '����ID';
comment on column T_100201_CONN_ACT_MAC_BAK.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100201_CONN_ACT_MAC_BAK.position
  is 'λ����Ϣ';
comment on column T_100201_CONN_ACT_MAC_BAK.dvid
  is '�豸��';
comment on column T_100201_CONN_ACT_MAC_BAK.accountid
  is '�˺�';
comment on column T_100201_CONN_ACT_MAC_BAK.conndate
  is '��Ծʱ��';
comment on column T_100201_CONN_ACT_MAC_BAK.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_100201_BAK on T_100201_CONN_ACT_MAC_BAK (CHANNELID);
create index IDX126_100201_BAK on T_100201_CONN_ACT_MAC_BAK (SERVERID);
create index IDX127_100201_BAK on T_100201_CONN_ACT_MAC_BAK (CONNDATE);
create index IDX128_100201_BAK on T_100201_CONN_ACT_MAC_BAK (BASEDATE);

prompt
prompt Creating table T_100201_CONN_DVID
prompt =================================
prompt
create table T_100201_CONN_DVID
(
  conndate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  dvid      VARCHAR2(50),
  regdate   VARCHAR2(10)
)
;
comment on table T_100201_CONN_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100201_CONN_DVID.conndate
  is '����ʱ��';
comment on column T_100201_CONN_DVID.gameid
  is '��ϷID';
comment on column T_100201_CONN_DVID.channelid
  is '����ID';
comment on column T_100201_CONN_DVID.dvid
  is '�豸��';
comment on column T_100201_CONN_DVID.regdate
  is 'ע��ʱ��';
create index IDX129_100201 on T_100201_CONN_DVID (CHANNELID);
create index IDX130_100201 on T_100201_CONN_DVID (CONNDATE);

prompt
prompt Creating table T_100201_CONN_MAC
prompt ================================
prompt
create table T_100201_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100201_CONN_MAC
  is '���� ��ʧ ������������������ע���˺ţ�ע���豸��';
comment on column T_100201_CONN_MAC.conndate
  is '����ʱ��';
comment on column T_100201_CONN_MAC.gameid
  is '��ϷID';
comment on column T_100201_CONN_MAC.channelid
  is '����ID';
comment on column T_100201_CONN_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100201_CONN_MAC.serverid
  is '����ID';
comment on column T_100201_CONN_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100201_CONN_MAC.position
  is 'λ����Ϣ';
comment on column T_100201_CONN_MAC.dvid
  is '�豸��';
comment on column T_100201_CONN_MAC.accountid
  is '�˺�ID';
comment on column T_100201_CONN_MAC.regdate
  is 'ע��ʱ��';
comment on column T_100201_CONN_MAC.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100201_CONN_MAC.regdate_as
  is 'ע��ʱ��(���з�����)';
create index IDX131_100201 on T_100201_CONN_MAC (CHANNELID);
create index IDX132_100201 on T_100201_CONN_MAC (SERVERID);
create index IDX133_100201 on T_100201_CONN_MAC (CONNDATE);

prompt
prompt Creating table T_100201_LOST_MAC
prompt ================================
prompt
create table T_100201_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100201_LOST_MAC
  is '�豸�ȼ���ʧ������';
comment on column T_100201_LOST_MAC.statdate
  is '�����������';
comment on column T_100201_LOST_MAC.lost_date
  is '��ʧ����';
comment on column T_100201_LOST_MAC.channelid
  is '����';
comment on column T_100201_LOST_MAC.serverid
  is '����';
comment on column T_100201_LOST_MAC.appid
  is '��Ʒid';
comment on column T_100201_LOST_MAC.macid
  is '�豸id';
comment on column T_100201_LOST_MAC.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100201_LOST_MAC.lost_days
  is '��ʧ����';
comment on column T_100201_LOST_MAC.data_source
  is '������Դ';
create index IDX134_100201 on T_100201_LOST_MAC (CHANNELID);
create index IDX135_100201 on T_100201_LOST_MAC (SERVERID);
create index IDX136_100201 on T_100201_LOST_MAC (STATDATE);

prompt
prompt Creating table T_100201_LOST_MAC_AS
prompt ===================================
prompt
create table T_100201_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table T_100201_LOST_MAC_AS
  is '�豸�ȼ���ʧ������allserver';
comment on column T_100201_LOST_MAC_AS.statdate
  is '�����������';
comment on column T_100201_LOST_MAC_AS.lost_date
  is '��ʧ����';
comment on column T_100201_LOST_MAC_AS.channelid
  is '����';
comment on column T_100201_LOST_MAC_AS.appid
  is '��Ʒid';
comment on column T_100201_LOST_MAC_AS.macid
  is '�豸id';
comment on column T_100201_LOST_MAC_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100201_LOST_MAC_AS.lost_days
  is '��ʧ����';
comment on column T_100201_LOST_MAC_AS.data_source
  is '������Դ';
create index IDX210_100201 on T_100201_LOST_MAC_AS (CHANNELID);
create index IDX211_100201 on T_100201_LOST_MAC_AS (STATDATE);

prompt
prompt Creating table T_100201_LOST_USER
prompt =================================
prompt
create table T_100201_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100201_LOST_USER
  is '�û��ȼ���ʧ������';
comment on column T_100201_LOST_USER.statdate
  is '�����������';
comment on column T_100201_LOST_USER.lost_date
  is '��ʧ����';
comment on column T_100201_LOST_USER.channelid
  is '����';
comment on column T_100201_LOST_USER.serverid
  is '����';
comment on column T_100201_LOST_USER.appid
  is '��Ʒid';
comment on column T_100201_LOST_USER.userid
  is '�û�id';
comment on column T_100201_LOST_USER.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100201_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100201_LOST_USER.lost_days
  is '��ʧ����';
comment on column T_100201_LOST_USER.data_source
  is '������Դ';
create index IDX137_100201 on T_100201_LOST_USER (CHANNELID);
create index IDX138_100201 on T_100201_LOST_USER (SERVERID);
create index IDX139_100201 on T_100201_LOST_USER (STATDATE);

prompt
prompt Creating table T_100201_LOST_USER_AS
prompt ====================================
prompt
create table T_100201_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table T_100201_LOST_USER_AS
  is '�û��ȼ���ʧ������allserver';
comment on column T_100201_LOST_USER_AS.statdate
  is '�����������';
comment on column T_100201_LOST_USER_AS.lost_date
  is '��ʧ����';
comment on column T_100201_LOST_USER_AS.channelid
  is '����';
comment on column T_100201_LOST_USER_AS.appid
  is '��Ʒid';
comment on column T_100201_LOST_USER_AS.userid
  is '�û�id';
comment on column T_100201_LOST_USER_AS.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100201_LOST_USER_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100201_LOST_USER_AS.lost_days
  is '��ʧ����';
comment on column T_100201_LOST_USER_AS.data_source
  is '������Դ';
create index IDX208_100201 on T_100201_LOST_USER_AS (CHANNELID);
create index IDX209_100201 on T_100201_LOST_USER_AS (STATDATE);

prompt
prompt Creating table T_100201_MISS_FIRST
prompt ==================================
prompt
create table T_100201_MISS_FIRST
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50) default '0',
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100201_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column T_100201_MISS_FIRST.statdate
  is 'ͳ������';
comment on column T_100201_MISS_FIRST.channelid
  is '����';
comment on column T_100201_MISS_FIRST.serverid
  is '����';
comment on column T_100201_MISS_FIRST.appid
  is '��ƷID';
comment on column T_100201_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column T_100201_MISS_FIRST.accountid
  is '�û�ID';
comment on column T_100201_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100201_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column T_100201_MISS_FIRST.issucc
  is '�Ƿ���ͨ��';
comment on column T_100201_MISS_FIRST.data_source
  is '������Դ';
create index IDX140_100201 on T_100201_MISS_FIRST (CHANNELID);
create index IDX141_100201 on T_100201_MISS_FIRST (SERVERID);
create index IDX142_100201 on T_100201_MISS_FIRST (STATDATE);

prompt
prompt Creating table T_100201_NU
prompt ==========================
prompt
create table T_100201_NU
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100201_NU
  is '�����û���Ϣ��';
comment on column T_100201_NU.thedate
  is '��������';
comment on column T_100201_NU.gameid
  is '��ϷID';
comment on column T_100201_NU.channelid
  is '����ID';
comment on column T_100201_NU.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100201_NU.serverid
  is '���ڷ�ID';
comment on column T_100201_NU.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100201_NU.position
  is '����λ��';
comment on column T_100201_NU.accountid
  is '�˺�ID';
create index IDX143_100201 on T_100201_NU (CHANNELID);
create index IDX144_100201 on T_100201_NU (SERVERID);
create index IDX145_100201 on T_100201_NU (THEDATE);

prompt
prompt Creating table T_100201_NU_ALLSERVER
prompt ====================================
prompt
create table T_100201_NU_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100201_NU_ALLSERVER
  is '�����û���Ϣ��ALLSERVER';
comment on column T_100201_NU_ALLSERVER.thedate
  is '��������';
comment on column T_100201_NU_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100201_NU_ALLSERVER.channelid
  is '����ID';
comment on column T_100201_NU_ALLSERVER.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100201_NU_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100201_NU_ALLSERVER.position
  is '����λ��';
comment on column T_100201_NU_ALLSERVER.accountid
  is '�˺�ID';
create index IDX194_100201 on T_100201_NU_ALLSERVER (CHANNELID);
create index IDX195_100201 on T_100201_NU_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100201_NU_DVID
prompt ===============================
prompt
create table T_100201_NU_DVID
(
  thedate   DATE not null,
  gameid    VARCHAR2(20) not null,
  channelid VARCHAR2(20) not null,
  dvid      VARCHAR2(50) not null,
  ipaddr    VARCHAR2(50)
)
;
comment on table T_100201_NU_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100201_NU_DVID.thedate
  is '����ʱ��';
comment on column T_100201_NU_DVID.gameid
  is '��ϷID';
comment on column T_100201_NU_DVID.channelid
  is '����ID';
comment on column T_100201_NU_DVID.dvid
  is '�豸ID';
comment on column T_100201_NU_DVID.ipaddr
  is 'IP';
create index IDX146_100201 on T_100201_NU_DVID (CHANNELID);
create index IDX147_100201 on T_100201_NU_DVID (THEDATE);

prompt
prompt Creating table T_100201_NU_MAC
prompt ==============================
prompt
create table T_100201_NU_MAC
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100201_NU_MAC
  is '�豸������';
comment on column T_100201_NU_MAC.thedate
  is '����ʱ��';
comment on column T_100201_NU_MAC.gameid
  is '��ϷID';
comment on column T_100201_NU_MAC.channelid
  is '����ID';
comment on column T_100201_NU_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100201_NU_MAC.serverid
  is '��������ID';
comment on column T_100201_NU_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100201_NU_MAC.position
  is 'λ����Ϣ';
comment on column T_100201_NU_MAC.dvid
  is '�豸ID';
create index IDX148_100201 on T_100201_NU_MAC (CHANNELID);
create index IDX149_100201 on T_100201_NU_MAC (SERVERID);
create index IDX150_100201 on T_100201_NU_MAC (THEDATE);

prompt
prompt Creating table T_100201_NU_MAC_ALLSERVER
prompt ========================================
prompt
create table T_100201_NU_MAC_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100201_NU_MAC_ALLSERVER
  is '�豸������ALLSERVER';
comment on column T_100201_NU_MAC_ALLSERVER.thedate
  is '����ʱ��';
comment on column T_100201_NU_MAC_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100201_NU_MAC_ALLSERVER.channelid
  is '����ID';
comment on column T_100201_NU_MAC_ALLSERVER.gameversion
  is '��Ϸ�汾';
comment on column T_100201_NU_MAC_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100201_NU_MAC_ALLSERVER.position
  is 'λ����Ϣ';
comment on column T_100201_NU_MAC_ALLSERVER.dvid
  is '�豸ID';
create index IDX196_100201 on T_100201_NU_MAC_ALLSERVER (CHANNELID);
create index IDX197_100201 on T_100201_NU_MAC_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100201_NU_PAY
prompt ==============================
prompt
create table T_100201_NU_PAY
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100201_NU_PAY
  is '�����û���';
comment on column T_100201_NU_PAY.thedate
  is '����ʱ��';
comment on column T_100201_NU_PAY.gameid
  is '��ϷID';
comment on column T_100201_NU_PAY.channelid
  is '����ID';
comment on column T_100201_NU_PAY.gameversion
  is '��Ϸ�汾';
comment on column T_100201_NU_PAY.serverid
  is '������Ϣ';
comment on column T_100201_NU_PAY.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100201_NU_PAY.position
  is 'λ����Ϣ';
comment on column T_100201_NU_PAY.accountid
  is '�˺�ID';
comment on column T_100201_NU_PAY.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100201_NU_PAY.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX151_100201 on T_100201_NU_PAY (CHANNELID);
create index IDX152_100201 on T_100201_NU_PAY (SERVERID);
create index IDX153_100201 on T_100201_NU_PAY (THEDATE);

prompt
prompt Creating table T_100201_NU_PAY_AS
prompt =================================
prompt
create table T_100201_NU_PAY_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100201_NU_PAY_AS
  is '�����û���allsever';
comment on column T_100201_NU_PAY_AS.thedate
  is '����ʱ��';
comment on column T_100201_NU_PAY_AS.gameid
  is '��ϷID';
comment on column T_100201_NU_PAY_AS.channelid
  is '����ID';
comment on column T_100201_NU_PAY_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100201_NU_PAY_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100201_NU_PAY_AS.position
  is 'λ����Ϣ';
comment on column T_100201_NU_PAY_AS.accountid
  is '�˺�ID';
comment on column T_100201_NU_PAY_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100201_NU_PAY_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX198_100201 on T_100201_NU_PAY_AS (CHANNELID);
create index IDX199_100201 on T_100201_NU_PAY_AS (THEDATE);

prompt
prompt Creating table T_100201_NU_PAY_MAC
prompt ==================================
prompt
create table T_100201_NU_PAY_MAC
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100201_NU_PAY_MAC
  is '�����û���';
comment on column T_100201_NU_PAY_MAC.thedate
  is '����ʱ��';
comment on column T_100201_NU_PAY_MAC.gameid
  is '��ϷID';
comment on column T_100201_NU_PAY_MAC.channelid
  is '����ID';
comment on column T_100201_NU_PAY_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100201_NU_PAY_MAC.serverid
  is '������Ϣ';
comment on column T_100201_NU_PAY_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100201_NU_PAY_MAC.position
  is 'λ����Ϣ';
comment on column T_100201_NU_PAY_MAC.dvid
  is '�豸ID';
comment on column T_100201_NU_PAY_MAC.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100201_NU_PAY_MAC.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX154_100201 on T_100201_NU_PAY_MAC (CHANNELID);
create index IDX155_100201 on T_100201_NU_PAY_MAC (SERVERID);
create index IDX156_100201 on T_100201_NU_PAY_MAC (THEDATE);

prompt
prompt Creating table T_100201_NU_PAY_MAC_AS
prompt =====================================
prompt
create table T_100201_NU_PAY_MAC_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100201_NU_PAY_MAC_AS
  is '�����û���ALLSERVER';
comment on column T_100201_NU_PAY_MAC_AS.thedate
  is '����ʱ��';
comment on column T_100201_NU_PAY_MAC_AS.gameid
  is '��ϷID';
comment on column T_100201_NU_PAY_MAC_AS.channelid
  is '����ID';
comment on column T_100201_NU_PAY_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100201_NU_PAY_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100201_NU_PAY_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100201_NU_PAY_MAC_AS.dvid
  is '�豸ID';
comment on column T_100201_NU_PAY_MAC_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100201_NU_PAY_MAC_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX200_100201 on T_100201_NU_PAY_MAC_AS (CHANNELID);
create index IDX201_100201 on T_100201_NU_PAY_MAC_AS (THEDATE);

prompt
prompt Creating table T_100201_ORDER_FAILURE
prompt =====================================
prompt
create table T_100201_ORDER_FAILURE
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100201_ORDER_FAILURE
  is '��ֵ�ɹ���¼��';
comment on column T_100201_ORDER_FAILURE.thedate
  is '��ֵʱ��';
comment on column T_100201_ORDER_FAILURE.gameid
  is '��ϷID';
comment on column T_100201_ORDER_FAILURE.channelid
  is '����ID';
comment on column T_100201_ORDER_FAILURE.gameversion
  is '��Ϸ�汾';
comment on column T_100201_ORDER_FAILURE.serverid
  is '��������';
comment on column T_100201_ORDER_FAILURE.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100201_ORDER_FAILURE.position
  is 'λ����Ϣ';
comment on column T_100201_ORDER_FAILURE.dvid
  is '�豸��';
comment on column T_100201_ORDER_FAILURE.accountid
  is '�˺�';
comment on column T_100201_ORDER_FAILURE.money
  is '��ֵ���';
comment on column T_100201_ORDER_FAILURE.vc
  is '��ֵ��õ����������';
comment on column T_100201_ORDER_FAILURE.orderid
  is '������';
comment on column T_100201_ORDER_FAILURE.paychannel
  is '֧������';
comment on column T_100201_ORDER_FAILURE.iapid
  is '��ֵ����  30  60';
create index IDX157_100201 on T_100201_ORDER_FAILURE (CHANNELID);
create index IDX158_100201 on T_100201_ORDER_FAILURE (SERVERID);
create index IDX159_100201 on T_100201_ORDER_FAILURE (THEDATE);

prompt
prompt Creating table T_100201_ORDER_SUCC
prompt ==================================
prompt
create table T_100201_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100201_ORDER_SUCC
  is '��ֵ�ɹ���¼��';
comment on column T_100201_ORDER_SUCC.thedate
  is '��ֵʱ��';
comment on column T_100201_ORDER_SUCC.gameid
  is '��ϷID';
comment on column T_100201_ORDER_SUCC.channelid
  is '����ID';
comment on column T_100201_ORDER_SUCC.gameversion
  is '��Ϸ�汾';
comment on column T_100201_ORDER_SUCC.serverid
  is '��������';
comment on column T_100201_ORDER_SUCC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100201_ORDER_SUCC.position
  is 'λ����Ϣ';
comment on column T_100201_ORDER_SUCC.dvid
  is '�豸��';
comment on column T_100201_ORDER_SUCC.accountid
  is '�˺�';
comment on column T_100201_ORDER_SUCC.money
  is '��ֵ���';
comment on column T_100201_ORDER_SUCC.vc
  is '��ֵ��õ����������';
comment on column T_100201_ORDER_SUCC.orderid
  is '������';
comment on column T_100201_ORDER_SUCC.paychannel
  is '֧������';
comment on column T_100201_ORDER_SUCC.iapid
  is '��ֵ����  30  60';
create index IDX160_100201 on T_100201_ORDER_SUCC (CHANNELID);
create index IDX161_100201 on T_100201_ORDER_SUCC (SERVERID);
create index IDX162_100201 on T_100201_ORDER_SUCC (THEDATE);

prompt
prompt Creating table T_100201_VC
prompt ==========================
prompt
create table T_100201_VC
(
  statdate    DATE,
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcchange    NUMBER,
  vcbefore    NUMBER,
  vcafter     NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100201_VC
  is '������ұ仯������';
comment on column T_100201_VC.statdate
  is 'ͳ������';
comment on column T_100201_VC.channelid
  is '����';
comment on column T_100201_VC.serverid
  is '����';
comment on column T_100201_VC.appid
  is '��Ʒid';
comment on column T_100201_VC.versionid
  is '��Ʒ�汾';
comment on column T_100201_VC.accountid
  is '�û�ID';
comment on column T_100201_VC.vctype
  is '�����������';
comment on column T_100201_VC.vcusetype
  is '�������ʹ������';
comment on column T_100201_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column T_100201_VC.vcchange
  is '������ұ仯���';
comment on column T_100201_VC.vcbefore
  is '������ұ仯ǰ���';
comment on column T_100201_VC.vcafter
  is '������ұ仯����';
comment on column T_100201_VC.data_source
  is '������Դ';
create index IDX163_100201 on T_100201_VC (CHANNELID);
create index IDX164_100201 on T_100201_VC (SERVERID);
create index IDX165_100201 on T_100201_VC (STATDATE);

prompt
prompt Creating table T_100202_CEVENT
prompt ==============================
prompt
create table T_100202_CEVENT
(
  thedate          VARCHAR2(10),
  datenum          NUMBER,
  appid            VARCHAR2(10),
  channelid        VARCHAR2(50),
  gameversion      VARCHAR2(50),
  dvid             VARCHAR2(50),
  accountid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  ilevel           NUMBER,
  roleid           VARCHAR2(50),
  eventkey         VARCHAR2(100),
  eventvalue_key   VARCHAR2(100),
  eventvalue_value VARCHAR2(100),
  ipaddr           VARCHAR2(50),
  prerowid         VARCHAR2(200)
)
;
comment on table T_100202_CEVENT
  is '�Զ����¼���ֱ�';
comment on column T_100202_CEVENT.thedate
  is '����';
comment on column T_100202_CEVENT.datenum
  is '�������ָ�ʽ';
comment on column T_100202_CEVENT.appid
  is '��Ϸ�� appid';
comment on column T_100202_CEVENT.channelid
  is '���� ID';
comment on column T_100202_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column T_100202_CEVENT.dvid
  is '�豸 ID��Ψһ�豸��';
comment on column T_100202_CEVENT.accountid
  is '�ʻ� id';
comment on column T_100202_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column T_100202_CEVENT.ilevel
  is '��ҵȼ�';
comment on column T_100202_CEVENT.roleid
  is '��ɫ id';
comment on column T_100202_CEVENT.eventkey
  is '�¼�����';
comment on column T_100202_CEVENT.eventvalue_key
  is '�¼�ֵ�е�key';
comment on column T_100202_CEVENT.eventvalue_value
  is '�¼�ֵ��key��Ӧ��ֵ';
comment on column T_100202_CEVENT.ipaddr
  is 'ip ��ַ';
comment on column T_100202_CEVENT.prerowid
  is 'ԭΨһ��ID';
create index IDX180_100202 on T_100202_CEVENT (THEDATE);

prompt
prompt Creating table T_100202_CONN
prompt ============================
prompt
create table T_100202_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100202_CONN
  is '����&��ʧ&������������������ע���˺ţ�ע���豸��';
comment on column T_100202_CONN.conndate
  is '����ʱ��';
comment on column T_100202_CONN.gameid
  is '��ϷID';
comment on column T_100202_CONN.channelid
  is '����ID';
comment on column T_100202_CONN.gameversion
  is '��Ϸ�汾';
comment on column T_100202_CONN.serverid
  is '����ID';
comment on column T_100202_CONN.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100202_CONN.position
  is 'λ����Ϣ';
comment on column T_100202_CONN.dvid
  is '�豸��';
comment on column T_100202_CONN.accountid
  is '�˺�ID';
comment on column T_100202_CONN.regdate
  is 'ע��ʱ��';
comment on column T_100202_CONN.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100202_CONN.regdate_as
  is 'ע��ʱ��(���з�����)';
create index IDX118_100202 on T_100202_CONN (CHANNELID);
create index IDX119_100202 on T_100202_CONN (SERVERID);
create index IDX120_100202 on T_100202_CONN (CONNDATE);

prompt
prompt Creating table T_100202_CONN_ACT
prompt ================================
prompt
create table T_100202_CONN_ACT
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100202_CONN_ACT
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100202_CONN_ACT.basedate
  is '����ʱ��';
comment on column T_100202_CONN_ACT.gameid
  is '��ϷID';
comment on column T_100202_CONN_ACT.channelid
  is '����ID';
comment on column T_100202_CONN_ACT.gameversion
  is '��Ϸ�汾';
comment on column T_100202_CONN_ACT.serverid
  is '����ID';
comment on column T_100202_CONN_ACT.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100202_CONN_ACT.position
  is 'λ����Ϣ';
comment on column T_100202_CONN_ACT.dvid
  is '�豸��';
comment on column T_100202_CONN_ACT.accountid
  is '�˺�';
comment on column T_100202_CONN_ACT.conndate
  is '��Ծʱ��';
comment on column T_100202_CONN_ACT.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_100202 on T_100202_CONN_ACT (CHANNELID);
create index IDX122_100202 on T_100202_CONN_ACT (SERVERID);
create index IDX123_100202 on T_100202_CONN_ACT (CONNDATE);
create index IDX124_100202 on T_100202_CONN_ACT (BASEDATE);

prompt
prompt Creating table T_100202_CONN_ACT_AS
prompt ===================================
prompt
create table T_100202_CONN_ACT_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100202_CONN_ACT_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100202_CONN_ACT_AS.basedate
  is '����ʱ��';
comment on column T_100202_CONN_ACT_AS.gameid
  is '��ϷID';
comment on column T_100202_CONN_ACT_AS.channelid
  is '����ID';
comment on column T_100202_CONN_ACT_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100202_CONN_ACT_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100202_CONN_ACT_AS.position
  is 'λ����Ϣ';
comment on column T_100202_CONN_ACT_AS.dvid
  is '�豸��';
comment on column T_100202_CONN_ACT_AS.accountid
  is '�˺�';
comment on column T_100202_CONN_ACT_AS.conndate
  is '��Ծʱ��';
comment on column T_100202_CONN_ACT_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX205_100202 on T_100202_CONN_ACT_AS (CHANNELID);
create index IDX206_100202 on T_100202_CONN_ACT_AS (CONNDATE);
create index IDX207_100202 on T_100202_CONN_ACT_AS (BASEDATE);

prompt
prompt Creating table T_100202_CONN_ACT_BAK
prompt ====================================
prompt
create table T_100202_CONN_ACT_BAK
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100202_CONN_ACT_BAK
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)���ݱ�';
comment on column T_100202_CONN_ACT_BAK.basedate
  is '����ʱ��';
comment on column T_100202_CONN_ACT_BAK.gameid
  is '��ϷID';
comment on column T_100202_CONN_ACT_BAK.channelid
  is '����ID';
comment on column T_100202_CONN_ACT_BAK.gameversion
  is '��Ϸ�汾';
comment on column T_100202_CONN_ACT_BAK.serverid
  is '����ID';
comment on column T_100202_CONN_ACT_BAK.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100202_CONN_ACT_BAK.position
  is 'λ����Ϣ';
comment on column T_100202_CONN_ACT_BAK.dvid
  is '�豸��';
comment on column T_100202_CONN_ACT_BAK.accountid
  is '�˺�';
comment on column T_100202_CONN_ACT_BAK.conndate
  is '��Ծʱ��';
comment on column T_100202_CONN_ACT_BAK.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_100202_BAK on T_100202_CONN_ACT_BAK (CHANNELID);
create index IDX122_100202_BAK on T_100202_CONN_ACT_BAK (SERVERID);
create index IDX123_100202_BAK on T_100202_CONN_ACT_BAK (CONNDATE);
create index IDX124_100202_BAK on T_100202_CONN_ACT_BAK (BASEDATE);

prompt
prompt Creating table T_100202_CONN_ACT_MAC
prompt ====================================
prompt
create table T_100202_CONN_ACT_MAC
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100202_CONN_ACT_MAC
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100202_CONN_ACT_MAC.basedate
  is '����ʱ��';
comment on column T_100202_CONN_ACT_MAC.gameid
  is '��ϷID';
comment on column T_100202_CONN_ACT_MAC.channelid
  is '����ID';
comment on column T_100202_CONN_ACT_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100202_CONN_ACT_MAC.serverid
  is '����ID';
comment on column T_100202_CONN_ACT_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100202_CONN_ACT_MAC.position
  is 'λ����Ϣ';
comment on column T_100202_CONN_ACT_MAC.dvid
  is '�豸��';
comment on column T_100202_CONN_ACT_MAC.accountid
  is '�˺�';
comment on column T_100202_CONN_ACT_MAC.conndate
  is '��Ծʱ��';
comment on column T_100202_CONN_ACT_MAC.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_100202 on T_100202_CONN_ACT_MAC (CHANNELID);
create index IDX126_100202 on T_100202_CONN_ACT_MAC (SERVERID);
create index IDX127_100202 on T_100202_CONN_ACT_MAC (CONNDATE);
create index IDX128_100202 on T_100202_CONN_ACT_MAC (BASEDATE);

prompt
prompt Creating table T_100202_CONN_ACT_MAC_AS
prompt =======================================
prompt
create table T_100202_CONN_ACT_MAC_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100202_CONN_ACT_MAC_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100202_CONN_ACT_MAC_AS.basedate
  is '����ʱ��';
comment on column T_100202_CONN_ACT_MAC_AS.gameid
  is '��ϷID';
comment on column T_100202_CONN_ACT_MAC_AS.channelid
  is '����ID';
comment on column T_100202_CONN_ACT_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100202_CONN_ACT_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100202_CONN_ACT_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100202_CONN_ACT_MAC_AS.dvid
  is '�豸��';
comment on column T_100202_CONN_ACT_MAC_AS.accountid
  is '�˺�';
comment on column T_100202_CONN_ACT_MAC_AS.conndate
  is '��Ծʱ��';
comment on column T_100202_CONN_ACT_MAC_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX202_100202 on T_100202_CONN_ACT_MAC_AS (CHANNELID);
create index IDX203_100202 on T_100202_CONN_ACT_MAC_AS (CONNDATE);
create index IDX204_100202 on T_100202_CONN_ACT_MAC_AS (BASEDATE);

prompt
prompt Creating table T_100202_CONN_ACT_MAC_BAK
prompt ========================================
prompt
create table T_100202_CONN_ACT_MAC_BAK
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100202_CONN_ACT_MAC_BAK
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)���ݱ�';
comment on column T_100202_CONN_ACT_MAC_BAK.basedate
  is '����ʱ��';
comment on column T_100202_CONN_ACT_MAC_BAK.gameid
  is '��ϷID';
comment on column T_100202_CONN_ACT_MAC_BAK.channelid
  is '����ID';
comment on column T_100202_CONN_ACT_MAC_BAK.gameversion
  is '��Ϸ�汾';
comment on column T_100202_CONN_ACT_MAC_BAK.serverid
  is '����ID';
comment on column T_100202_CONN_ACT_MAC_BAK.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100202_CONN_ACT_MAC_BAK.position
  is 'λ����Ϣ';
comment on column T_100202_CONN_ACT_MAC_BAK.dvid
  is '�豸��';
comment on column T_100202_CONN_ACT_MAC_BAK.accountid
  is '�˺�';
comment on column T_100202_CONN_ACT_MAC_BAK.conndate
  is '��Ծʱ��';
comment on column T_100202_CONN_ACT_MAC_BAK.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_100202_BAK on T_100202_CONN_ACT_MAC_BAK (CHANNELID);
create index IDX126_100202_BAK on T_100202_CONN_ACT_MAC_BAK (SERVERID);
create index IDX127_100202_BAK on T_100202_CONN_ACT_MAC_BAK (CONNDATE);
create index IDX128_100202_BAK on T_100202_CONN_ACT_MAC_BAK (BASEDATE);

prompt
prompt Creating table T_100202_CONN_DVID
prompt =================================
prompt
create table T_100202_CONN_DVID
(
  conndate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  dvid      VARCHAR2(50),
  regdate   VARCHAR2(10)
)
;
comment on table T_100202_CONN_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100202_CONN_DVID.conndate
  is '����ʱ��';
comment on column T_100202_CONN_DVID.gameid
  is '��ϷID';
comment on column T_100202_CONN_DVID.channelid
  is '����ID';
comment on column T_100202_CONN_DVID.dvid
  is '�豸��';
comment on column T_100202_CONN_DVID.regdate
  is 'ע��ʱ��';
create index IDX129_100202 on T_100202_CONN_DVID (CHANNELID);
create index IDX130_100202 on T_100202_CONN_DVID (CONNDATE);

prompt
prompt Creating table T_100202_CONN_MAC
prompt ================================
prompt
create table T_100202_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100202_CONN_MAC
  is '���� ��ʧ ������������������ע���˺ţ�ע���豸��';
comment on column T_100202_CONN_MAC.conndate
  is '����ʱ��';
comment on column T_100202_CONN_MAC.gameid
  is '��ϷID';
comment on column T_100202_CONN_MAC.channelid
  is '����ID';
comment on column T_100202_CONN_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100202_CONN_MAC.serverid
  is '����ID';
comment on column T_100202_CONN_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100202_CONN_MAC.position
  is 'λ����Ϣ';
comment on column T_100202_CONN_MAC.dvid
  is '�豸��';
comment on column T_100202_CONN_MAC.accountid
  is '�˺�ID';
comment on column T_100202_CONN_MAC.regdate
  is 'ע��ʱ��';
comment on column T_100202_CONN_MAC.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100202_CONN_MAC.regdate_as
  is 'ע��ʱ��(���з�����)';
create index IDX131_100202 on T_100202_CONN_MAC (CHANNELID);
create index IDX132_100202 on T_100202_CONN_MAC (SERVERID);
create index IDX133_100202 on T_100202_CONN_MAC (CONNDATE);

prompt
prompt Creating table T_100202_LOST_MAC
prompt ================================
prompt
create table T_100202_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100202_LOST_MAC
  is '�豸�ȼ���ʧ������';
comment on column T_100202_LOST_MAC.statdate
  is '�����������';
comment on column T_100202_LOST_MAC.lost_date
  is '��ʧ����';
comment on column T_100202_LOST_MAC.channelid
  is '����';
comment on column T_100202_LOST_MAC.serverid
  is '����';
comment on column T_100202_LOST_MAC.appid
  is '��Ʒid';
comment on column T_100202_LOST_MAC.macid
  is '�豸id';
comment on column T_100202_LOST_MAC.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100202_LOST_MAC.lost_days
  is '��ʧ����';
comment on column T_100202_LOST_MAC.data_source
  is '������Դ';
create index IDX134_100202 on T_100202_LOST_MAC (CHANNELID);
create index IDX135_100202 on T_100202_LOST_MAC (SERVERID);
create index IDX136_100202 on T_100202_LOST_MAC (STATDATE);

prompt
prompt Creating table T_100202_LOST_MAC_AS
prompt ===================================
prompt
create table T_100202_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table T_100202_LOST_MAC_AS
  is '�豸�ȼ���ʧ������allserver';
comment on column T_100202_LOST_MAC_AS.statdate
  is '�����������';
comment on column T_100202_LOST_MAC_AS.lost_date
  is '��ʧ����';
comment on column T_100202_LOST_MAC_AS.channelid
  is '����';
comment on column T_100202_LOST_MAC_AS.appid
  is '��Ʒid';
comment on column T_100202_LOST_MAC_AS.macid
  is '�豸id';
comment on column T_100202_LOST_MAC_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100202_LOST_MAC_AS.lost_days
  is '��ʧ����';
comment on column T_100202_LOST_MAC_AS.data_source
  is '������Դ';
create index IDX210_100202 on T_100202_LOST_MAC_AS (CHANNELID);
create index IDX211_100202 on T_100202_LOST_MAC_AS (STATDATE);

prompt
prompt Creating table T_100202_LOST_USER
prompt =================================
prompt
create table T_100202_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100202_LOST_USER
  is '�û��ȼ���ʧ������';
comment on column T_100202_LOST_USER.statdate
  is '�����������';
comment on column T_100202_LOST_USER.lost_date
  is '��ʧ����';
comment on column T_100202_LOST_USER.channelid
  is '����';
comment on column T_100202_LOST_USER.serverid
  is '����';
comment on column T_100202_LOST_USER.appid
  is '��Ʒid';
comment on column T_100202_LOST_USER.userid
  is '�û�id';
comment on column T_100202_LOST_USER.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100202_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100202_LOST_USER.lost_days
  is '��ʧ����';
comment on column T_100202_LOST_USER.data_source
  is '������Դ';
create index IDX137_100202 on T_100202_LOST_USER (CHANNELID);
create index IDX138_100202 on T_100202_LOST_USER (SERVERID);
create index IDX139_100202 on T_100202_LOST_USER (STATDATE);

prompt
prompt Creating table T_100202_LOST_USER_AS
prompt ====================================
prompt
create table T_100202_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table T_100202_LOST_USER_AS
  is '�û��ȼ���ʧ������allserver';
comment on column T_100202_LOST_USER_AS.statdate
  is '�����������';
comment on column T_100202_LOST_USER_AS.lost_date
  is '��ʧ����';
comment on column T_100202_LOST_USER_AS.channelid
  is '����';
comment on column T_100202_LOST_USER_AS.appid
  is '��Ʒid';
comment on column T_100202_LOST_USER_AS.userid
  is '�û�id';
comment on column T_100202_LOST_USER_AS.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100202_LOST_USER_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100202_LOST_USER_AS.lost_days
  is '��ʧ����';
comment on column T_100202_LOST_USER_AS.data_source
  is '������Դ';
create index IDX208_100202 on T_100202_LOST_USER_AS (CHANNELID);
create index IDX209_100202 on T_100202_LOST_USER_AS (STATDATE);

prompt
prompt Creating table T_100202_MISS_FIRST
prompt ==================================
prompt
create table T_100202_MISS_FIRST
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50) default '0',
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100202_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column T_100202_MISS_FIRST.statdate
  is 'ͳ������';
comment on column T_100202_MISS_FIRST.channelid
  is '����';
comment on column T_100202_MISS_FIRST.serverid
  is '����';
comment on column T_100202_MISS_FIRST.appid
  is '��ƷID';
comment on column T_100202_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column T_100202_MISS_FIRST.accountid
  is '�û�ID';
comment on column T_100202_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100202_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column T_100202_MISS_FIRST.issucc
  is '�Ƿ���ͨ��';
comment on column T_100202_MISS_FIRST.data_source
  is '������Դ';
create index IDX140_100202 on T_100202_MISS_FIRST (CHANNELID);
create index IDX141_100202 on T_100202_MISS_FIRST (SERVERID);
create index IDX142_100202 on T_100202_MISS_FIRST (STATDATE);

prompt
prompt Creating table T_100202_NU
prompt ==========================
prompt
create table T_100202_NU
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100202_NU
  is '�����û���Ϣ��';
comment on column T_100202_NU.thedate
  is '��������';
comment on column T_100202_NU.gameid
  is '��ϷID';
comment on column T_100202_NU.channelid
  is '����ID';
comment on column T_100202_NU.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100202_NU.serverid
  is '���ڷ�ID';
comment on column T_100202_NU.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100202_NU.position
  is '����λ��';
comment on column T_100202_NU.accountid
  is '�˺�ID';
create index IDX143_100202 on T_100202_NU (CHANNELID);
create index IDX144_100202 on T_100202_NU (SERVERID);
create index IDX145_100202 on T_100202_NU (THEDATE);

prompt
prompt Creating table T_100202_NU_ALLSERVER
prompt ====================================
prompt
create table T_100202_NU_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100202_NU_ALLSERVER
  is '�����û���Ϣ��ALLSERVER';
comment on column T_100202_NU_ALLSERVER.thedate
  is '��������';
comment on column T_100202_NU_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100202_NU_ALLSERVER.channelid
  is '����ID';
comment on column T_100202_NU_ALLSERVER.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100202_NU_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100202_NU_ALLSERVER.position
  is '����λ��';
comment on column T_100202_NU_ALLSERVER.accountid
  is '�˺�ID';
create index IDX194_100202 on T_100202_NU_ALLSERVER (CHANNELID);
create index IDX195_100202 on T_100202_NU_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100202_NU_DVID
prompt ===============================
prompt
create table T_100202_NU_DVID
(
  thedate   DATE not null,
  gameid    VARCHAR2(20) not null,
  channelid VARCHAR2(20) not null,
  dvid      VARCHAR2(50) not null,
  ipaddr    VARCHAR2(50)
)
;
comment on table T_100202_NU_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100202_NU_DVID.thedate
  is '����ʱ��';
comment on column T_100202_NU_DVID.gameid
  is '��ϷID';
comment on column T_100202_NU_DVID.channelid
  is '����ID';
comment on column T_100202_NU_DVID.dvid
  is '�豸ID';
comment on column T_100202_NU_DVID.ipaddr
  is 'IP';
create index IDX146_100202 on T_100202_NU_DVID (CHANNELID);
create index IDX147_100202 on T_100202_NU_DVID (THEDATE);

prompt
prompt Creating table T_100202_NU_MAC
prompt ==============================
prompt
create table T_100202_NU_MAC
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100202_NU_MAC
  is '�豸������';
comment on column T_100202_NU_MAC.thedate
  is '����ʱ��';
comment on column T_100202_NU_MAC.gameid
  is '��ϷID';
comment on column T_100202_NU_MAC.channelid
  is '����ID';
comment on column T_100202_NU_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100202_NU_MAC.serverid
  is '��������ID';
comment on column T_100202_NU_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100202_NU_MAC.position
  is 'λ����Ϣ';
comment on column T_100202_NU_MAC.dvid
  is '�豸ID';
create index IDX148_100202 on T_100202_NU_MAC (CHANNELID);
create index IDX149_100202 on T_100202_NU_MAC (SERVERID);
create index IDX150_100202 on T_100202_NU_MAC (THEDATE);

prompt
prompt Creating table T_100202_NU_MAC_ALLSERVER
prompt ========================================
prompt
create table T_100202_NU_MAC_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100202_NU_MAC_ALLSERVER
  is '�豸������ALLSERVER';
comment on column T_100202_NU_MAC_ALLSERVER.thedate
  is '����ʱ��';
comment on column T_100202_NU_MAC_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100202_NU_MAC_ALLSERVER.channelid
  is '����ID';
comment on column T_100202_NU_MAC_ALLSERVER.gameversion
  is '��Ϸ�汾';
comment on column T_100202_NU_MAC_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100202_NU_MAC_ALLSERVER.position
  is 'λ����Ϣ';
comment on column T_100202_NU_MAC_ALLSERVER.dvid
  is '�豸ID';
create index IDX196_100202 on T_100202_NU_MAC_ALLSERVER (CHANNELID);
create index IDX197_100202 on T_100202_NU_MAC_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100202_NU_PAY
prompt ==============================
prompt
create table T_100202_NU_PAY
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100202_NU_PAY
  is '�����û���';
comment on column T_100202_NU_PAY.thedate
  is '����ʱ��';
comment on column T_100202_NU_PAY.gameid
  is '��ϷID';
comment on column T_100202_NU_PAY.channelid
  is '����ID';
comment on column T_100202_NU_PAY.gameversion
  is '��Ϸ�汾';
comment on column T_100202_NU_PAY.serverid
  is '������Ϣ';
comment on column T_100202_NU_PAY.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100202_NU_PAY.position
  is 'λ����Ϣ';
comment on column T_100202_NU_PAY.accountid
  is '�˺�ID';
comment on column T_100202_NU_PAY.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100202_NU_PAY.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX151_100202 on T_100202_NU_PAY (CHANNELID);
create index IDX152_100202 on T_100202_NU_PAY (SERVERID);
create index IDX153_100202 on T_100202_NU_PAY (THEDATE);

prompt
prompt Creating table T_100202_NU_PAY_AS
prompt =================================
prompt
create table T_100202_NU_PAY_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100202_NU_PAY_AS
  is '�����û���allsever';
comment on column T_100202_NU_PAY_AS.thedate
  is '����ʱ��';
comment on column T_100202_NU_PAY_AS.gameid
  is '��ϷID';
comment on column T_100202_NU_PAY_AS.channelid
  is '����ID';
comment on column T_100202_NU_PAY_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100202_NU_PAY_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100202_NU_PAY_AS.position
  is 'λ����Ϣ';
comment on column T_100202_NU_PAY_AS.accountid
  is '�˺�ID';
comment on column T_100202_NU_PAY_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100202_NU_PAY_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX198_100202 on T_100202_NU_PAY_AS (CHANNELID);
create index IDX199_100202 on T_100202_NU_PAY_AS (THEDATE);

prompt
prompt Creating table T_100202_NU_PAY_MAC
prompt ==================================
prompt
create table T_100202_NU_PAY_MAC
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100202_NU_PAY_MAC
  is '�����û���';
comment on column T_100202_NU_PAY_MAC.thedate
  is '����ʱ��';
comment on column T_100202_NU_PAY_MAC.gameid
  is '��ϷID';
comment on column T_100202_NU_PAY_MAC.channelid
  is '����ID';
comment on column T_100202_NU_PAY_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100202_NU_PAY_MAC.serverid
  is '������Ϣ';
comment on column T_100202_NU_PAY_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100202_NU_PAY_MAC.position
  is 'λ����Ϣ';
comment on column T_100202_NU_PAY_MAC.dvid
  is '�豸ID';
comment on column T_100202_NU_PAY_MAC.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100202_NU_PAY_MAC.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX154_100202 on T_100202_NU_PAY_MAC (CHANNELID);
create index IDX155_100202 on T_100202_NU_PAY_MAC (SERVERID);
create index IDX156_100202 on T_100202_NU_PAY_MAC (THEDATE);

prompt
prompt Creating table T_100202_NU_PAY_MAC_AS
prompt =====================================
prompt
create table T_100202_NU_PAY_MAC_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100202_NU_PAY_MAC_AS
  is '�����û���ALLSERVER';
comment on column T_100202_NU_PAY_MAC_AS.thedate
  is '����ʱ��';
comment on column T_100202_NU_PAY_MAC_AS.gameid
  is '��ϷID';
comment on column T_100202_NU_PAY_MAC_AS.channelid
  is '����ID';
comment on column T_100202_NU_PAY_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100202_NU_PAY_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100202_NU_PAY_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100202_NU_PAY_MAC_AS.dvid
  is '�豸ID';
comment on column T_100202_NU_PAY_MAC_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100202_NU_PAY_MAC_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX200_100202 on T_100202_NU_PAY_MAC_AS (CHANNELID);
create index IDX201_100202 on T_100202_NU_PAY_MAC_AS (THEDATE);

prompt
prompt Creating table T_100202_ORDER_FAILURE
prompt =====================================
prompt
create table T_100202_ORDER_FAILURE
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100202_ORDER_FAILURE
  is '��ֵ�ɹ���¼��';
comment on column T_100202_ORDER_FAILURE.thedate
  is '��ֵʱ��';
comment on column T_100202_ORDER_FAILURE.gameid
  is '��ϷID';
comment on column T_100202_ORDER_FAILURE.channelid
  is '����ID';
comment on column T_100202_ORDER_FAILURE.gameversion
  is '��Ϸ�汾';
comment on column T_100202_ORDER_FAILURE.serverid
  is '��������';
comment on column T_100202_ORDER_FAILURE.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100202_ORDER_FAILURE.position
  is 'λ����Ϣ';
comment on column T_100202_ORDER_FAILURE.dvid
  is '�豸��';
comment on column T_100202_ORDER_FAILURE.accountid
  is '�˺�';
comment on column T_100202_ORDER_FAILURE.money
  is '��ֵ���';
comment on column T_100202_ORDER_FAILURE.vc
  is '��ֵ��õ����������';
comment on column T_100202_ORDER_FAILURE.orderid
  is '������';
comment on column T_100202_ORDER_FAILURE.paychannel
  is '֧������';
comment on column T_100202_ORDER_FAILURE.iapid
  is '��ֵ����  30  60';
create index IDX157_100202 on T_100202_ORDER_FAILURE (CHANNELID);
create index IDX158_100202 on T_100202_ORDER_FAILURE (SERVERID);
create index IDX159_100202 on T_100202_ORDER_FAILURE (THEDATE);

prompt
prompt Creating table T_100202_ORDER_SUCC
prompt ==================================
prompt
create table T_100202_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100202_ORDER_SUCC
  is '��ֵ�ɹ���¼��';
comment on column T_100202_ORDER_SUCC.thedate
  is '��ֵʱ��';
comment on column T_100202_ORDER_SUCC.gameid
  is '��ϷID';
comment on column T_100202_ORDER_SUCC.channelid
  is '����ID';
comment on column T_100202_ORDER_SUCC.gameversion
  is '��Ϸ�汾';
comment on column T_100202_ORDER_SUCC.serverid
  is '��������';
comment on column T_100202_ORDER_SUCC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100202_ORDER_SUCC.position
  is 'λ����Ϣ';
comment on column T_100202_ORDER_SUCC.dvid
  is '�豸��';
comment on column T_100202_ORDER_SUCC.accountid
  is '�˺�';
comment on column T_100202_ORDER_SUCC.money
  is '��ֵ���';
comment on column T_100202_ORDER_SUCC.vc
  is '��ֵ��õ����������';
comment on column T_100202_ORDER_SUCC.orderid
  is '������';
comment on column T_100202_ORDER_SUCC.paychannel
  is '֧������';
comment on column T_100202_ORDER_SUCC.iapid
  is '��ֵ����  30  60';
create index IDX160_100202 on T_100202_ORDER_SUCC (CHANNELID);
create index IDX161_100202 on T_100202_ORDER_SUCC (SERVERID);
create index IDX162_100202 on T_100202_ORDER_SUCC (THEDATE);

prompt
prompt Creating table T_100202_VC
prompt ==========================
prompt
create table T_100202_VC
(
  statdate    DATE,
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcchange    NUMBER,
  vcbefore    NUMBER,
  vcafter     NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100202_VC
  is '������ұ仯������';
comment on column T_100202_VC.statdate
  is 'ͳ������';
comment on column T_100202_VC.channelid
  is '����';
comment on column T_100202_VC.serverid
  is '����';
comment on column T_100202_VC.appid
  is '��Ʒid';
comment on column T_100202_VC.versionid
  is '��Ʒ�汾';
comment on column T_100202_VC.accountid
  is '�û�ID';
comment on column T_100202_VC.vctype
  is '�����������';
comment on column T_100202_VC.vcusetype
  is '�������ʹ������';
comment on column T_100202_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column T_100202_VC.vcchange
  is '������ұ仯���';
comment on column T_100202_VC.vcbefore
  is '������ұ仯ǰ���';
comment on column T_100202_VC.vcafter
  is '������ұ仯����';
comment on column T_100202_VC.data_source
  is '������Դ';
create index IDX163_100202 on T_100202_VC (CHANNELID);
create index IDX164_100202 on T_100202_VC (SERVERID);
create index IDX165_100202 on T_100202_VC (STATDATE);

prompt
prompt Creating table T_100209_CEVENT
prompt ==============================
prompt
create table T_100209_CEVENT
(
  thedate          VARCHAR2(10),
  datenum          NUMBER,
  appid            VARCHAR2(10),
  channelid        VARCHAR2(50),
  gameversion      VARCHAR2(50),
  dvid             VARCHAR2(50),
  accountid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  ilevel           NUMBER,
  roleid           VARCHAR2(50),
  eventkey         VARCHAR2(100),
  eventvalue_key   VARCHAR2(100),
  eventvalue_value VARCHAR2(100),
  ipaddr           VARCHAR2(50),
  prerowid         VARCHAR2(200)
)
;
comment on table T_100209_CEVENT
  is '�Զ����¼���ֱ�';
comment on column T_100209_CEVENT.thedate
  is '����';
comment on column T_100209_CEVENT.datenum
  is '�������ָ�ʽ';
comment on column T_100209_CEVENT.appid
  is '��Ϸ�� appid';
comment on column T_100209_CEVENT.channelid
  is '���� ID';
comment on column T_100209_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column T_100209_CEVENT.dvid
  is '�豸 ID��Ψһ�豸��';
comment on column T_100209_CEVENT.accountid
  is '�ʻ� id';
comment on column T_100209_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column T_100209_CEVENT.ilevel
  is '��ҵȼ�';
comment on column T_100209_CEVENT.roleid
  is '��ɫ id';
comment on column T_100209_CEVENT.eventkey
  is '�¼�����';
comment on column T_100209_CEVENT.eventvalue_key
  is '�¼�ֵ�е�key';
comment on column T_100209_CEVENT.eventvalue_value
  is '�¼�ֵ��key��Ӧ��ֵ';
comment on column T_100209_CEVENT.ipaddr
  is 'ip ��ַ';
comment on column T_100209_CEVENT.prerowid
  is 'ԭΨһ��ID';
create index IDX180_100209 on T_100209_CEVENT (THEDATE);

prompt
prompt Creating table T_100209_CONN
prompt ============================
prompt
create table T_100209_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100209_CONN
  is '����&��ʧ&������������������ע���˺ţ�ע���豸��';
comment on column T_100209_CONN.conndate
  is '����ʱ��';
comment on column T_100209_CONN.gameid
  is '��ϷID';
comment on column T_100209_CONN.channelid
  is '����ID';
comment on column T_100209_CONN.gameversion
  is '��Ϸ�汾';
comment on column T_100209_CONN.serverid
  is '����ID';
comment on column T_100209_CONN.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100209_CONN.position
  is 'λ����Ϣ';
comment on column T_100209_CONN.dvid
  is '�豸��';
comment on column T_100209_CONN.accountid
  is '�˺�ID';
comment on column T_100209_CONN.regdate
  is 'ע��ʱ��';
comment on column T_100209_CONN.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100209_CONN.regdate_as
  is '����ע��ʱ��';
create index IDX118_100209 on T_100209_CONN (CHANNELID);
create index IDX119_100209 on T_100209_CONN (SERVERID);
create index IDX120_100209 on T_100209_CONN (CONNDATE);

prompt
prompt Creating table T_100209_CONN_ACT
prompt ================================
prompt
create table T_100209_CONN_ACT
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100209_CONN_ACT
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100209_CONN_ACT.basedate
  is '����ʱ��';
comment on column T_100209_CONN_ACT.gameid
  is '��ϷID';
comment on column T_100209_CONN_ACT.channelid
  is '����ID';
comment on column T_100209_CONN_ACT.gameversion
  is '��Ϸ�汾';
comment on column T_100209_CONN_ACT.serverid
  is '����ID';
comment on column T_100209_CONN_ACT.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100209_CONN_ACT.position
  is 'λ����Ϣ';
comment on column T_100209_CONN_ACT.dvid
  is '�豸��';
comment on column T_100209_CONN_ACT.accountid
  is '�˺�';
comment on column T_100209_CONN_ACT.conndate
  is '��Ծʱ��';
comment on column T_100209_CONN_ACT.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_100209 on T_100209_CONN_ACT (CHANNELID);
create index IDX122_100209 on T_100209_CONN_ACT (SERVERID);
create index IDX123_100209 on T_100209_CONN_ACT (CONNDATE);
create index IDX124_100209 on T_100209_CONN_ACT (BASEDATE);

prompt
prompt Creating table T_100209_CONN_ACT_AS
prompt ===================================
prompt
create table T_100209_CONN_ACT_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100209_CONN_ACT_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100209_CONN_ACT_AS.basedate
  is '����ʱ��';
comment on column T_100209_CONN_ACT_AS.gameid
  is '��ϷID';
comment on column T_100209_CONN_ACT_AS.channelid
  is '����ID';
comment on column T_100209_CONN_ACT_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100209_CONN_ACT_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100209_CONN_ACT_AS.position
  is 'λ����Ϣ';
comment on column T_100209_CONN_ACT_AS.dvid
  is '�豸��';
comment on column T_100209_CONN_ACT_AS.accountid
  is '�˺�';
comment on column T_100209_CONN_ACT_AS.conndate
  is '��Ծʱ��';
comment on column T_100209_CONN_ACT_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX205_100209 on T_100209_CONN_ACT_AS (CHANNELID);
create index IDX206_100209 on T_100209_CONN_ACT_AS (CONNDATE);
create index IDX207_100209 on T_100209_CONN_ACT_AS (BASEDATE);

prompt
prompt Creating table T_100209_CONN_ACT_MAC
prompt ====================================
prompt
create table T_100209_CONN_ACT_MAC
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100209_CONN_ACT_MAC
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100209_CONN_ACT_MAC.basedate
  is '����ʱ��';
comment on column T_100209_CONN_ACT_MAC.gameid
  is '��ϷID';
comment on column T_100209_CONN_ACT_MAC.channelid
  is '����ID';
comment on column T_100209_CONN_ACT_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100209_CONN_ACT_MAC.serverid
  is '����ID';
comment on column T_100209_CONN_ACT_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100209_CONN_ACT_MAC.position
  is 'λ����Ϣ';
comment on column T_100209_CONN_ACT_MAC.dvid
  is '�豸��';
comment on column T_100209_CONN_ACT_MAC.accountid
  is '�˺�';
comment on column T_100209_CONN_ACT_MAC.conndate
  is '��Ծʱ��';
comment on column T_100209_CONN_ACT_MAC.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_100209 on T_100209_CONN_ACT_MAC (CHANNELID);
create index IDX126_100209 on T_100209_CONN_ACT_MAC (SERVERID);
create index IDX127_100209 on T_100209_CONN_ACT_MAC (CONNDATE);
create index IDX128_100209 on T_100209_CONN_ACT_MAC (BASEDATE);

prompt
prompt Creating table T_100209_CONN_ACT_MAC_AS
prompt =======================================
prompt
create table T_100209_CONN_ACT_MAC_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100209_CONN_ACT_MAC_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100209_CONN_ACT_MAC_AS.basedate
  is '����ʱ��';
comment on column T_100209_CONN_ACT_MAC_AS.gameid
  is '��ϷID';
comment on column T_100209_CONN_ACT_MAC_AS.channelid
  is '����ID';
comment on column T_100209_CONN_ACT_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100209_CONN_ACT_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100209_CONN_ACT_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100209_CONN_ACT_MAC_AS.dvid
  is '�豸��';
comment on column T_100209_CONN_ACT_MAC_AS.accountid
  is '�˺�';
comment on column T_100209_CONN_ACT_MAC_AS.conndate
  is '��Ծʱ��';
comment on column T_100209_CONN_ACT_MAC_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX202_100209 on T_100209_CONN_ACT_MAC_AS (CHANNELID);
create index IDX203_100209 on T_100209_CONN_ACT_MAC_AS (CONNDATE);
create index IDX204_100209 on T_100209_CONN_ACT_MAC_AS (BASEDATE);

prompt
prompt Creating table T_100209_CONN_DVID
prompt =================================
prompt
create table T_100209_CONN_DVID
(
  conndate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  dvid      VARCHAR2(50),
  regdate   VARCHAR2(10)
)
;
comment on table T_100209_CONN_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100209_CONN_DVID.conndate
  is '����ʱ��';
comment on column T_100209_CONN_DVID.gameid
  is '��ϷID';
comment on column T_100209_CONN_DVID.channelid
  is '����ID';
comment on column T_100209_CONN_DVID.dvid
  is '�豸��';
comment on column T_100209_CONN_DVID.regdate
  is 'ע��ʱ��';
create index IDX129_100209 on T_100209_CONN_DVID (CHANNELID);
create index IDX130_100209 on T_100209_CONN_DVID (CONNDATE);

prompt
prompt Creating table T_100209_CONN_MAC
prompt ================================
prompt
create table T_100209_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100209_CONN_MAC
  is '���� ��ʧ ������������������ע���˺ţ�ע���豸��';
comment on column T_100209_CONN_MAC.conndate
  is '����ʱ��';
comment on column T_100209_CONN_MAC.gameid
  is '��ϷID';
comment on column T_100209_CONN_MAC.channelid
  is '����ID';
comment on column T_100209_CONN_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100209_CONN_MAC.serverid
  is '����ID';
comment on column T_100209_CONN_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100209_CONN_MAC.position
  is 'λ����Ϣ';
comment on column T_100209_CONN_MAC.dvid
  is '�豸��';
comment on column T_100209_CONN_MAC.accountid
  is '�˺�ID';
comment on column T_100209_CONN_MAC.regdate
  is 'ע��ʱ��';
comment on column T_100209_CONN_MAC.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100209_CONN_MAC.regdate_as
  is '����ע��ʱ��';
create index IDX131_100209 on T_100209_CONN_MAC (CHANNELID);
create index IDX132_100209 on T_100209_CONN_MAC (SERVERID);
create index IDX133_100209 on T_100209_CONN_MAC (CONNDATE);

prompt
prompt Creating table T_100209_LOST_MAC
prompt ================================
prompt
create table T_100209_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100209_LOST_MAC
  is '�豸�ȼ���ʧ������';
comment on column T_100209_LOST_MAC.statdate
  is '�����������';
comment on column T_100209_LOST_MAC.lost_date
  is '��ʧ����';
comment on column T_100209_LOST_MAC.channelid
  is '����';
comment on column T_100209_LOST_MAC.serverid
  is '����';
comment on column T_100209_LOST_MAC.appid
  is '��Ʒid';
comment on column T_100209_LOST_MAC.macid
  is '�豸id';
comment on column T_100209_LOST_MAC.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100209_LOST_MAC.lost_days
  is '��ʧ����';
comment on column T_100209_LOST_MAC.data_source
  is '������Դ';
create index IDX134_100209 on T_100209_LOST_MAC (CHANNELID);
create index IDX135_100209 on T_100209_LOST_MAC (SERVERID);
create index IDX136_100209 on T_100209_LOST_MAC (STATDATE);

prompt
prompt Creating table T_100209_LOST_MAC_AS
prompt ===================================
prompt
create table T_100209_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table T_100209_LOST_MAC_AS
  is '�豸�ȼ���ʧ������allserver';
comment on column T_100209_LOST_MAC_AS.statdate
  is '�����������';
comment on column T_100209_LOST_MAC_AS.lost_date
  is '��ʧ����';
comment on column T_100209_LOST_MAC_AS.channelid
  is '����';
comment on column T_100209_LOST_MAC_AS.appid
  is '��Ʒid';
comment on column T_100209_LOST_MAC_AS.macid
  is '�豸id';
comment on column T_100209_LOST_MAC_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100209_LOST_MAC_AS.lost_days
  is '��ʧ����';
comment on column T_100209_LOST_MAC_AS.data_source
  is '������Դ';
create index IDX210_100209 on T_100209_LOST_MAC_AS (CHANNELID);
create index IDX211_100209 on T_100209_LOST_MAC_AS (STATDATE);

prompt
prompt Creating table T_100209_LOST_USER
prompt =================================
prompt
create table T_100209_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100209_LOST_USER
  is '�û��ȼ���ʧ������';
comment on column T_100209_LOST_USER.statdate
  is '�����������';
comment on column T_100209_LOST_USER.lost_date
  is '��ʧ����';
comment on column T_100209_LOST_USER.channelid
  is '����';
comment on column T_100209_LOST_USER.serverid
  is '����';
comment on column T_100209_LOST_USER.appid
  is '��Ʒid';
comment on column T_100209_LOST_USER.userid
  is '�û�id';
comment on column T_100209_LOST_USER.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100209_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100209_LOST_USER.lost_days
  is '��ʧ����';
comment on column T_100209_LOST_USER.data_source
  is '������Դ';
create index IDX137_100209 on T_100209_LOST_USER (CHANNELID);
create index IDX138_100209 on T_100209_LOST_USER (SERVERID);
create index IDX139_100209 on T_100209_LOST_USER (STATDATE);

prompt
prompt Creating table T_100209_LOST_USER_AS
prompt ====================================
prompt
create table T_100209_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table T_100209_LOST_USER_AS
  is '�û��ȼ���ʧ������allserver';
comment on column T_100209_LOST_USER_AS.statdate
  is '�����������';
comment on column T_100209_LOST_USER_AS.lost_date
  is '��ʧ����';
comment on column T_100209_LOST_USER_AS.channelid
  is '����';
comment on column T_100209_LOST_USER_AS.appid
  is '��Ʒid';
comment on column T_100209_LOST_USER_AS.userid
  is '�û�id';
comment on column T_100209_LOST_USER_AS.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100209_LOST_USER_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100209_LOST_USER_AS.lost_days
  is '��ʧ����';
comment on column T_100209_LOST_USER_AS.data_source
  is '������Դ';
create index IDX208_100209 on T_100209_LOST_USER_AS (CHANNELID);
create index IDX209_100209 on T_100209_LOST_USER_AS (STATDATE);

prompt
prompt Creating table T_100209_MISS_FIRST
prompt ==================================
prompt
create table T_100209_MISS_FIRST
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50) default '0',
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100209_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column T_100209_MISS_FIRST.statdate
  is 'ͳ������';
comment on column T_100209_MISS_FIRST.channelid
  is '����';
comment on column T_100209_MISS_FIRST.serverid
  is '����';
comment on column T_100209_MISS_FIRST.appid
  is '��ƷID';
comment on column T_100209_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column T_100209_MISS_FIRST.accountid
  is '�û�ID';
comment on column T_100209_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100209_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column T_100209_MISS_FIRST.issucc
  is '�Ƿ���ͨ��';
comment on column T_100209_MISS_FIRST.data_source
  is '������Դ';
create index IDX140_100209 on T_100209_MISS_FIRST (CHANNELID);
create index IDX141_100209 on T_100209_MISS_FIRST (SERVERID);
create index IDX142_100209 on T_100209_MISS_FIRST (STATDATE);

prompt
prompt Creating table T_100209_NU
prompt ==========================
prompt
create table T_100209_NU
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100209_NU
  is '�����û���Ϣ��';
comment on column T_100209_NU.thedate
  is '��������';
comment on column T_100209_NU.gameid
  is '��ϷID';
comment on column T_100209_NU.channelid
  is '����ID';
comment on column T_100209_NU.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100209_NU.serverid
  is '���ڷ�ID';
comment on column T_100209_NU.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100209_NU.position
  is '����λ��';
comment on column T_100209_NU.accountid
  is '�˺�ID';
create index IDX143_100209 on T_100209_NU (CHANNELID);
create index IDX144_100209 on T_100209_NU (SERVERID);
create index IDX145_100209 on T_100209_NU (THEDATE);

prompt
prompt Creating table T_100209_NU_ALLSERVER
prompt ====================================
prompt
create table T_100209_NU_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100209_NU_ALLSERVER
  is '�����û���Ϣ��ALLSERVER';
comment on column T_100209_NU_ALLSERVER.thedate
  is '��������';
comment on column T_100209_NU_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100209_NU_ALLSERVER.channelid
  is '����ID';
comment on column T_100209_NU_ALLSERVER.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100209_NU_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100209_NU_ALLSERVER.position
  is '����λ��';
comment on column T_100209_NU_ALLSERVER.accountid
  is '�˺�ID';
create index IDX194_100209 on T_100209_NU_ALLSERVER (CHANNELID);
create index IDX195_100209 on T_100209_NU_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100209_NU_DVID
prompt ===============================
prompt
create table T_100209_NU_DVID
(
  thedate   DATE not null,
  gameid    VARCHAR2(20) not null,
  channelid VARCHAR2(20) not null,
  dvid      VARCHAR2(50) not null,
  ipaddr    VARCHAR2(50)
)
;
comment on table T_100209_NU_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100209_NU_DVID.thedate
  is '����ʱ��';
comment on column T_100209_NU_DVID.gameid
  is '��ϷID';
comment on column T_100209_NU_DVID.channelid
  is '����ID';
comment on column T_100209_NU_DVID.dvid
  is '�豸ID';
comment on column T_100209_NU_DVID.ipaddr
  is 'IP';
create index IDX146_100209 on T_100209_NU_DVID (CHANNELID);
create index IDX147_100209 on T_100209_NU_DVID (THEDATE);

prompt
prompt Creating table T_100209_NU_MAC
prompt ==============================
prompt
create table T_100209_NU_MAC
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100209_NU_MAC
  is '�豸������';
comment on column T_100209_NU_MAC.thedate
  is '����ʱ��';
comment on column T_100209_NU_MAC.gameid
  is '��ϷID';
comment on column T_100209_NU_MAC.channelid
  is '����ID';
comment on column T_100209_NU_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100209_NU_MAC.serverid
  is '��������ID';
comment on column T_100209_NU_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100209_NU_MAC.position
  is 'λ����Ϣ';
comment on column T_100209_NU_MAC.dvid
  is '�豸ID';
create index IDX148_100209 on T_100209_NU_MAC (CHANNELID);
create index IDX149_100209 on T_100209_NU_MAC (SERVERID);
create index IDX150_100209 on T_100209_NU_MAC (THEDATE);

prompt
prompt Creating table T_100209_NU_MAC_ALLSERVER
prompt ========================================
prompt
create table T_100209_NU_MAC_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100209_NU_MAC_ALLSERVER
  is '�豸������ALLSERVER';
comment on column T_100209_NU_MAC_ALLSERVER.thedate
  is '����ʱ��';
comment on column T_100209_NU_MAC_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100209_NU_MAC_ALLSERVER.channelid
  is '����ID';
comment on column T_100209_NU_MAC_ALLSERVER.gameversion
  is '��Ϸ�汾';
comment on column T_100209_NU_MAC_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100209_NU_MAC_ALLSERVER.position
  is 'λ����Ϣ';
comment on column T_100209_NU_MAC_ALLSERVER.dvid
  is '�豸ID';
create index IDX196_100209 on T_100209_NU_MAC_ALLSERVER (CHANNELID);
create index IDX197_100209 on T_100209_NU_MAC_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100209_NU_PAY
prompt ==============================
prompt
create table T_100209_NU_PAY
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100209_NU_PAY
  is '�����û���';
comment on column T_100209_NU_PAY.thedate
  is '����ʱ��';
comment on column T_100209_NU_PAY.gameid
  is '��ϷID';
comment on column T_100209_NU_PAY.channelid
  is '����ID';
comment on column T_100209_NU_PAY.gameversion
  is '��Ϸ�汾';
comment on column T_100209_NU_PAY.serverid
  is '������Ϣ';
comment on column T_100209_NU_PAY.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100209_NU_PAY.position
  is 'λ����Ϣ';
comment on column T_100209_NU_PAY.accountid
  is '�˺�ID';
comment on column T_100209_NU_PAY.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100209_NU_PAY.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX151_100209 on T_100209_NU_PAY (CHANNELID);
create index IDX152_100209 on T_100209_NU_PAY (SERVERID);
create index IDX153_100209 on T_100209_NU_PAY (THEDATE);

prompt
prompt Creating table T_100209_NU_PAY_AS
prompt =================================
prompt
create table T_100209_NU_PAY_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100209_NU_PAY_AS
  is '�����û���allsever';
comment on column T_100209_NU_PAY_AS.thedate
  is '����ʱ��';
comment on column T_100209_NU_PAY_AS.gameid
  is '��ϷID';
comment on column T_100209_NU_PAY_AS.channelid
  is '����ID';
comment on column T_100209_NU_PAY_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100209_NU_PAY_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100209_NU_PAY_AS.position
  is 'λ����Ϣ';
comment on column T_100209_NU_PAY_AS.accountid
  is '�˺�ID';
comment on column T_100209_NU_PAY_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100209_NU_PAY_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX198_100209 on T_100209_NU_PAY_AS (CHANNELID);
create index IDX199_100209 on T_100209_NU_PAY_AS (THEDATE);

prompt
prompt Creating table T_100209_NU_PAY_MAC
prompt ==================================
prompt
create table T_100209_NU_PAY_MAC
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100209_NU_PAY_MAC
  is '�����û���';
comment on column T_100209_NU_PAY_MAC.thedate
  is '����ʱ��';
comment on column T_100209_NU_PAY_MAC.gameid
  is '��ϷID';
comment on column T_100209_NU_PAY_MAC.channelid
  is '����ID';
comment on column T_100209_NU_PAY_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100209_NU_PAY_MAC.serverid
  is '������Ϣ';
comment on column T_100209_NU_PAY_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100209_NU_PAY_MAC.position
  is 'λ����Ϣ';
comment on column T_100209_NU_PAY_MAC.dvid
  is '�豸ID';
comment on column T_100209_NU_PAY_MAC.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100209_NU_PAY_MAC.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX154_100209 on T_100209_NU_PAY_MAC (CHANNELID);
create index IDX155_100209 on T_100209_NU_PAY_MAC (SERVERID);
create index IDX156_100209 on T_100209_NU_PAY_MAC (THEDATE);

prompt
prompt Creating table T_100209_NU_PAY_MAC_AS
prompt =====================================
prompt
create table T_100209_NU_PAY_MAC_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100209_NU_PAY_MAC_AS
  is '�����û���ALLSERVER';
comment on column T_100209_NU_PAY_MAC_AS.thedate
  is '����ʱ��';
comment on column T_100209_NU_PAY_MAC_AS.gameid
  is '��ϷID';
comment on column T_100209_NU_PAY_MAC_AS.channelid
  is '����ID';
comment on column T_100209_NU_PAY_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100209_NU_PAY_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100209_NU_PAY_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100209_NU_PAY_MAC_AS.dvid
  is '�豸ID';
comment on column T_100209_NU_PAY_MAC_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100209_NU_PAY_MAC_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX200_100209 on T_100209_NU_PAY_MAC_AS (CHANNELID);
create index IDX201_100209 on T_100209_NU_PAY_MAC_AS (THEDATE);

prompt
prompt Creating table T_100209_ORDER_FAILURE
prompt =====================================
prompt
create table T_100209_ORDER_FAILURE
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100209_ORDER_FAILURE
  is '��ֵ�ɹ���¼��';
comment on column T_100209_ORDER_FAILURE.thedate
  is '��ֵʱ��';
comment on column T_100209_ORDER_FAILURE.gameid
  is '��ϷID';
comment on column T_100209_ORDER_FAILURE.channelid
  is '����ID';
comment on column T_100209_ORDER_FAILURE.gameversion
  is '��Ϸ�汾';
comment on column T_100209_ORDER_FAILURE.serverid
  is '��������';
comment on column T_100209_ORDER_FAILURE.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100209_ORDER_FAILURE.position
  is 'λ����Ϣ';
comment on column T_100209_ORDER_FAILURE.dvid
  is '�豸��';
comment on column T_100209_ORDER_FAILURE.accountid
  is '�˺�';
comment on column T_100209_ORDER_FAILURE.money
  is '��ֵ���';
comment on column T_100209_ORDER_FAILURE.vc
  is '��ֵ��õ����������';
comment on column T_100209_ORDER_FAILURE.orderid
  is '������';
comment on column T_100209_ORDER_FAILURE.paychannel
  is '֧������';
comment on column T_100209_ORDER_FAILURE.iapid
  is '��ֵ����  30  60';
create index IDX157_100209 on T_100209_ORDER_FAILURE (CHANNELID);
create index IDX158_100209 on T_100209_ORDER_FAILURE (SERVERID);
create index IDX159_100209 on T_100209_ORDER_FAILURE (THEDATE);

prompt
prompt Creating table T_100209_ORDER_SUCC
prompt ==================================
prompt
create table T_100209_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100209_ORDER_SUCC
  is '��ֵ�ɹ���¼��';
comment on column T_100209_ORDER_SUCC.thedate
  is '��ֵʱ��';
comment on column T_100209_ORDER_SUCC.gameid
  is '��ϷID';
comment on column T_100209_ORDER_SUCC.channelid
  is '����ID';
comment on column T_100209_ORDER_SUCC.gameversion
  is '��Ϸ�汾';
comment on column T_100209_ORDER_SUCC.serverid
  is '��������';
comment on column T_100209_ORDER_SUCC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100209_ORDER_SUCC.position
  is 'λ����Ϣ';
comment on column T_100209_ORDER_SUCC.dvid
  is '�豸��';
comment on column T_100209_ORDER_SUCC.accountid
  is '�˺�';
comment on column T_100209_ORDER_SUCC.money
  is '��ֵ���';
comment on column T_100209_ORDER_SUCC.vc
  is '��ֵ��õ����������';
comment on column T_100209_ORDER_SUCC.orderid
  is '������';
comment on column T_100209_ORDER_SUCC.paychannel
  is '֧������';
comment on column T_100209_ORDER_SUCC.iapid
  is '��ֵ����  30  60';
create index IDX160_100209 on T_100209_ORDER_SUCC (CHANNELID);
create index IDX161_100209 on T_100209_ORDER_SUCC (SERVERID);
create index IDX162_100209 on T_100209_ORDER_SUCC (THEDATE);

prompt
prompt Creating table T_100209_VC
prompt ==========================
prompt
create table T_100209_VC
(
  statdate    DATE,
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcchange    NUMBER,
  vcbefore    NUMBER,
  vcafter     NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100209_VC
  is '������ұ仯������';
comment on column T_100209_VC.statdate
  is 'ͳ������';
comment on column T_100209_VC.channelid
  is '����';
comment on column T_100209_VC.serverid
  is '����';
comment on column T_100209_VC.appid
  is '��Ʒid';
comment on column T_100209_VC.versionid
  is '��Ʒ�汾';
comment on column T_100209_VC.accountid
  is '�û�ID';
comment on column T_100209_VC.vctype
  is '�����������';
comment on column T_100209_VC.vcusetype
  is '�������ʹ������';
comment on column T_100209_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column T_100209_VC.vcchange
  is '������ұ仯���';
comment on column T_100209_VC.vcbefore
  is '������ұ仯ǰ���';
comment on column T_100209_VC.vcafter
  is '������ұ仯����';
comment on column T_100209_VC.data_source
  is '������Դ';
create index IDX163_100209 on T_100209_VC (CHANNELID);
create index IDX164_100209 on T_100209_VC (SERVERID);
create index IDX165_100209 on T_100209_VC (STATDATE);


spool off
