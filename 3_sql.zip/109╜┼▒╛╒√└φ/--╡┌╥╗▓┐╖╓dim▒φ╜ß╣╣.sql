------------------------------------------------------------
-- Export file for user DEVELOPER@BI_RACDB1_111.13.20.109 --
-- Created by Administrator on 2015/5/20, 10:15:41 ---------
------------------------------------------------------------

set define off
spool --��һ���ֱ��ṹ.log

prompt
prompt Creating table DICT_MONITOR_APPLIST
prompt ===================================
prompt
create table DICT_MONITOR_APPLIST
(
  appid    VARCHAR2(50),
  add_time DATE,
  status   NUMBER,
  msg      VARCHAR2(1000),
  appname  VARCHAR2(100)
)
;
comment on table DICT_MONITOR_APPLIST
  is '�����Ϸ�б�';
comment on column DICT_MONITOR_APPLIST.appid
  is '��Ʒid';
comment on column DICT_MONITOR_APPLIST.add_time
  is '����ʱ��';
comment on column DICT_MONITOR_APPLIST.status
  is '״̬ ��Ϊ0��Ϊ��Ч��APPID��';
comment on column DICT_MONITOR_APPLIST.msg
  is '��Ϣ';
comment on column DICT_MONITOR_APPLIST.appname
  is '��Ʒ����';

prompt
prompt Creating table DIM_APP
prompt ======================
prompt
create table DIM_APP
(
  appid        VARCHAR2(50),
  appname      VARCHAR2(200),
  platform     VARCHAR2(20),
  loaddate     DATE default sysdate,
  isdisplay    VARCHAR2(5) default 'N',
  country_type VARCHAR2(20) default 'INTERNAL',
  online_type  VARCHAR2(20) default 'ONLINE'
)
;
comment on table DIM_APP
  is '��Ʒά�ȱ�';
comment on column DIM_APP.appid
  is '��ƷID';
comment on column DIM_APP.appname
  is '��Ʒ����';
comment on column DIM_APP.platform
  is '��Ʒƽ̨';
comment on column DIM_APP.isdisplay
  is '�Ƿ�BIչʾ��Y �� N��';
comment on column DIM_APP.country_type
  is '���� ''INTERNAL''������ ''OVERSEAS''';
comment on column DIM_APP.online_type
  is '���� ''ONLINE''������ ''SINGLE''';

prompt
prompt Creating table DIM_APPCHANNEL
prompt =============================
prompt
create table DIM_APPCHANNEL
(
  appchannelid   VARCHAR2(50),
  appid          VARCHAR2(50),
  appname        VARCHAR2(200),
  platform       VARCHAR2(20),
  channelid      VARCHAR2(20),
  oldchannelname VARCHAR2(200),
  channelname    VARCHAR2(200),
  loaddate       DATE default Sysdate
)
;
comment on table DIM_APPCHANNEL
  is '��Ʒ-����ά�ȱ�';
comment on column DIM_APPCHANNEL.appchannelid
  is 'Ψһ����';
comment on column DIM_APPCHANNEL.appid
  is '��ƷID';
comment on column DIM_APPCHANNEL.appname
  is '��Ʒ����';
comment on column DIM_APPCHANNEL.platform
  is '��Ʒƽ̨';
comment on column DIM_APPCHANNEL.channelid
  is '����ID';
comment on column DIM_APPCHANNEL.oldchannelname
  is 'ԭʼ��������';
comment on column DIM_APPCHANNEL.channelname
  is '��������';

prompt
prompt Creating table DIM_APPPAYTYPE
prompt =============================
prompt
create table DIM_APPPAYTYPE
(
  apppaytypeid VARCHAR2(50),
  appid        VARCHAR2(50),
  appname      VARCHAR2(200),
  paytypeid    VARCHAR2(20),
  paytypename  VARCHAR2(20),
  loaddate     DATE default Sysdate
)
;
comment on table DIM_APPPAYTYPE
  is '��Ʒ-��ֵ����ά�ȱ�';
comment on column DIM_APPPAYTYPE.apppaytypeid
  is 'Ψһ����';
comment on column DIM_APPPAYTYPE.appid
  is '��ƷID';
comment on column DIM_APPPAYTYPE.appname
  is '��Ʒ����';
comment on column DIM_APPPAYTYPE.paytypeid
  is '��ֵ����ID';
comment on column DIM_APPPAYTYPE.paytypename
  is '��ֵ��������';

prompt
prompt Creating table DIM_APPPAYWAY
prompt ============================
prompt
create table DIM_APPPAYWAY
(
  apppaywayid VARCHAR2(50),
  appid       VARCHAR2(50),
  appname     VARCHAR2(200),
  paywayid    VARCHAR2(20),
  paywayname  VARCHAR2(20),
  loaddate    DATE default Sysdate
)
;
comment on table DIM_APPPAYWAY
  is '��Ʒ-��ֵ����ά�ȱ�';
comment on column DIM_APPPAYWAY.apppaywayid
  is 'Ψһ����';
comment on column DIM_APPPAYWAY.appid
  is '��ƷID';
comment on column DIM_APPPAYWAY.appname
  is '��Ʒ����';
comment on column DIM_APPPAYWAY.paywayid
  is '��ֵ����ID';
comment on column DIM_APPPAYWAY.paywayname
  is '��ֵ��������';

prompt
prompt Creating table DIM_APPSERVER
prompt ============================
prompt
create table DIM_APPSERVER
(
  appserverid VARCHAR2(50),
  appid       VARCHAR2(50),
  appname     VARCHAR2(200),
  serverid    VARCHAR2(20),
  servername  VARCHAR2(20),
  loaddate    DATE default Sysdate
)
;
comment on table DIM_APPSERVER
  is '��Ʒ-����ά�ȱ�';
comment on column DIM_APPSERVER.appserverid
  is 'Ψһ����';
comment on column DIM_APPSERVER.appid
  is '��ƷID';
comment on column DIM_APPSERVER.appname
  is '��Ʒ����';
comment on column DIM_APPSERVER.serverid
  is '����ID';
comment on column DIM_APPSERVER.servername
  is '��������';

prompt
prompt Creating table DIM_APPVERSION
prompt =============================
prompt
create table DIM_APPVERSION
(
  appversionid VARCHAR2(50),
  appid        VARCHAR2(50),
  appname      VARCHAR2(200),
  versionid    VARCHAR2(20),
  versionname  VARCHAR2(20),
  loaddate     DATE default Sysdate
)
;
comment on table DIM_APPVERSION
  is '��Ʒ-�汾ά�ȱ�';
comment on column DIM_APPVERSION.appversionid
  is 'Ψһ����';
comment on column DIM_APPVERSION.appid
  is '��ƷID';
comment on column DIM_APPVERSION.appname
  is '��Ʒ����';
comment on column DIM_APPVERSION.versionid
  is '�汾ID';
comment on column DIM_APPVERSION.versionname
  is '�汾����';

prompt
prompt Creating table DIM_APP_PRE
prompt ==========================
prompt
create table DIM_APP_PRE
(
  appid        VARCHAR2(50),
  appname      VARCHAR2(200),
  platform     VARCHAR2(20),
  loaddate     DATE default sysdate,
  isdisplay    VARCHAR2(5) default 'N',
  country_type VARCHAR2(20) default 'INTERNAL',
  online_type  VARCHAR2(20) default 'ONLINE'
)
;
comment on table DIM_APP_PRE
  is '��Ʒά�ȱ�����׼����';
comment on column DIM_APP_PRE.appid
  is '��ƷID';
comment on column DIM_APP_PRE.appname
  is '��Ʒ����';
comment on column DIM_APP_PRE.platform
  is '��Ʒƽ̨';
comment on column DIM_APP_PRE.isdisplay
  is '�Ƿ�BIչʾ��Y �� N��';
comment on column DIM_APP_PRE.country_type
  is '���� ''INTERNAL''������ ''OVERSEAS''';
comment on column DIM_APP_PRE.online_type
  is '���� ''ONLINE''������ ''SINGLE''';

prompt
prompt Creating table DIM_CEVENT
prompt =========================
prompt
create table DIM_CEVENT
(
  appid     VARCHAR2(50),
  ceventid  VARCHAR2(50),
  ceventpar VARCHAR2(200),
  loaddate  DATE default Sysdate
)
;
comment on table DIM_CEVENT
  is '�¼�����ά�ȱ�';
comment on column DIM_CEVENT.appid
  is '��ƷID';
comment on column DIM_CEVENT.ceventid
  is '�¼�ID';
comment on column DIM_CEVENT.ceventpar
  is '�¼�����';

prompt
prompt Creating table DIM_CHANNEL
prompt ==========================
prompt
create table DIM_CHANNEL
(
  channelid       VARCHAR2(20),
  channelname     VARCHAR2(200),
  parentchannelid VARCHAR2(20),
  loaddate        DATE default Sysdate
)
;
comment on table DIM_CHANNEL
  is '����ά�ȱ�';
comment on column DIM_CHANNEL.channelid
  is '����ID';
comment on column DIM_CHANNEL.channelname
  is '��������';
comment on column DIM_CHANNEL.parentchannelid
  is '������ID';

prompt
prompt Creating table DIM_COMP_CEVENT
prompt ==============================
prompt
create table DIM_COMP_CEVENT
(
  appid      VARCHAR2(50),
  ceventid   VARCHAR2(50),
  compid     VARCHAR2(50),
  compname   VARCHAR2(200),
  dimpars    VARCHAR2(2000),
  calpars    VARCHAR2(50),
  caltype    VARCHAR2(50),
  error_info VARCHAR2(2000),
  loaddate   DATE default Sysdate
)
;
comment on table DIM_COMP_CEVENT
  is '�����¼���ϲ���ά�����ñ�';
comment on column DIM_COMP_CEVENT.appid
  is '��ƷID';
comment on column DIM_COMP_CEVENT.ceventid
  is '�¼�ID';
comment on column DIM_COMP_CEVENT.compid
  is '��ϲ���ID';
comment on column DIM_COMP_CEVENT.compname
  is '��ϲ�������';
comment on column DIM_COMP_CEVENT.dimpars
  is 'ά�Ȳ�����';
comment on column DIM_COMP_CEVENT.calpars
  is '�����������';
comment on column DIM_COMP_CEVENT.caltype
  is '�����������ͣ�SUM��COUNT_DISTINCT��MAX��MIN��';
comment on column DIM_COMP_CEVENT.error_info
  is '������Ϣ';

prompt
prompt Creating table DIM_COUNTRYTYPE
prompt ==============================
prompt
create table DIM_COUNTRYTYPE
(
  country_type VARCHAR2(50)
)
;

prompt
prompt Creating table DIM_DATATYPE
prompt ===========================
prompt
create table DIM_DATATYPE
(
  datatypeid VARCHAR2(50)
)
;

prompt
prompt Creating table DIM_DAY
prompt ======================
prompt
create table DIM_DAY
(
  dayid           NUMBER,
  weekid          NUMBER,
  monthid         NUMBER,
  quarterid       NUMBER,
  yearid          NUMBER,
  day_cal         NUMBER,
  day_d           VARCHAR2(10),
  day_month       VARCHAR2(10),
  day_des         VARCHAR2(10),
  day_date        DATE,
  week_day_cal    NUMBER,
  week_day_des    VARCHAR2(10),
  month_start_day VARCHAR2(10),
  month_end_day   VARCHAR2(10),
  last_month_id   NUMBER,
  last_month      VARCHAR2(10),
  day_before_id   NUMBER,
  day_before      VARCHAR2(10),
  day_of_year     NUMBER,
  month_count     NUMBER,
  month_end_flag  VARCHAR2(5),
  isworkday       VARCHAR2(5)
)
;
comment on table DIM_DAY
  is '��ά�ȱ�';
comment on column DIM_DAY.dayid
  is '��ID��20141202��';
comment on column DIM_DAY.weekid
  is '��ID��201409��';
comment on column DIM_DAY.monthid
  is '��ID��201412��';
comment on column DIM_DAY.quarterid
  is '����ID��20144��';
comment on column DIM_DAY.yearid
  is '��ID��2014��';
comment on column DIM_DAY.day_cal
  is '�����ָ�ʽ��1��';
comment on column DIM_DAY.day_d
  is '�գ�01�գ�';
comment on column DIM_DAY.day_month
  is '���ո�ʽ��12-02��';
comment on column DIM_DAY.day_des
  is '��������2012-01-01��';
comment on column DIM_DAY.day_date
  is '������������';
comment on column DIM_DAY.week_day_cal
  is '�������ָ�ʽ';
comment on column DIM_DAY.week_day_des
  is '��������������һ��';
comment on column DIM_DAY.month_start_day
  is '�����³�����';
comment on column DIM_DAY.month_end_day
  is '������ĩ����';
comment on column DIM_DAY.last_month_id
  is '��ID��20141102��';
comment on column DIM_DAY.last_month
  is '���¸���';
comment on column DIM_DAY.day_before_id
  is '��ID��20141201��';
comment on column DIM_DAY.day_before
  is 'ǰһ��';
comment on column DIM_DAY.day_of_year
  is '����ڶ�����';
comment on column DIM_DAY.month_count
  is '��������';
comment on column DIM_DAY.month_end_flag
  is '��ĩ��ʶ����''E''��';
comment on column DIM_DAY.isworkday
  is '�Ƿ����գ������� ��Y�� ��Ϣ�� ��N����';

prompt
prompt Creating table DIM_HOUR
prompt =======================
prompt
create table DIM_HOUR
(
  hourid   NUMBER,
  hour_des VARCHAR2(5)
)
;
comment on table DIM_HOUR
  is 'Сʱά�ȱ�';
comment on column DIM_HOUR.hourid
  is 'Сʱ���ݸ�ʽ';
comment on column DIM_HOUR.hour_des
  is 'Сʱ�ַ�����ʽ';

prompt
prompt Creating table DIM_IP
prompt =====================
prompt
create table DIM_IP
(
  ipbegin      NUMBER not null,
  ipend        NUMBER not null,
  countryid    NUMBER not null,
  countryname  VARCHAR2(20) not null,
  provinceid   NUMBER not null,
  provincename VARCHAR2(50) not null,
  cityid       NUMBER not null,
  cityname     VARCHAR2(50) not null,
  cid          NUMBER not null
)
;
create index IDX_DIM_IP on DIM_IP (IPBEGIN, IPEND);

prompt
prompt Creating table DIM_MONTH
prompt ========================
prompt
create table DIM_MONTH
(
  monthid       NUMBER,
  month_cal     NUMBER,
  month_d       VARCHAR2(10),
  month_des     VARCHAR2(10),
  last_month_id NUMBER,
  last_month    VARCHAR2(10),
  last_year_id  NUMBER,
  last_year     VARCHAR2(10),
  month_count   NUMBER
)
;
comment on table DIM_MONTH
  is '��ά�ȱ�';
comment on column DIM_MONTH.monthid
  is '��ID��201412��';
comment on column DIM_MONTH.month_cal
  is '�����ָ�ʽ��1��';
comment on column DIM_MONTH.month_d
  is '�·ݣ�01�£�';
comment on column DIM_MONTH.month_des
  is '��������2012-01)';
comment on column DIM_MONTH.last_month_id
  is '����ID';
comment on column DIM_MONTH.last_month
  is '����';
comment on column DIM_MONTH.last_year_id
  is 'ȥ�����ID';
comment on column DIM_MONTH.last_year
  is 'ȥ�����';
comment on column DIM_MONTH.month_count
  is '��������';

prompt
prompt Creating table DIM_NET
prompt ======================
prompt
create table DIM_NET
(
  netid    VARCHAR2(5),
  netname  VARCHAR2(20),
  loaddate DATE default Sysdate
)
;
comment on table DIM_NET
  is '������ʽά�ȱ�';
comment on column DIM_NET.netid
  is '������ʽID';
comment on column DIM_NET.netname
  is '������ʽ����';

prompt
prompt Creating table DIM_ONLINETYPE
prompt =============================
prompt
create table DIM_ONLINETYPE
(
  online_type VARCHAR2(50)
)
;

prompt
prompt Creating table DIM_OPERATOR
prompt ===========================
prompt
create table DIM_OPERATOR
(
  operatorid   VARCHAR2(5),
  operatorname VARCHAR2(20),
  loaddate     DATE default Sysdate
)
;
comment on table DIM_OPERATOR
  is '��Ӫ��ά�ȱ�';
comment on column DIM_OPERATOR.operatorid
  is '��Ӫ��ID';
comment on column DIM_OPERATOR.operatorname
  is '��Ӫ������';

prompt
prompt Creating table DIM_REMAIN_DAY
prompt =============================
prompt
create table DIM_REMAIN_DAY
(
  remain_day NUMBER
)
;
comment on table DIM_REMAIN_DAY
  is '��������ά�ȱ�';
comment on column DIM_REMAIN_DAY.remain_day
  is '��������';

prompt
prompt Creating table DIM_UC_OPEN_MAPPING
prompt ==================================
prompt
create table DIM_UC_OPEN_MAPPING
(
  f_logtime DATE,
  uuid      NUMBER,
  unique_id VARCHAR2(100),
  appid     NUMBER
)
;

prompt
prompt Creating table DIM_UC_OPEN_MAPPING_100091
prompt =========================================
prompt
create table DIM_UC_OPEN_MAPPING_100091
(
  f_logtime DATE,
  uuid      NUMBER,
  unique_id VARCHAR2(100),
  appid     NUMBER
)
;

prompt
prompt Creating table DIM_UC_OPEN_MAPPING_100131
prompt =========================================
prompt
create table DIM_UC_OPEN_MAPPING_100131
(
  f_logtime DATE,
  uuid      NUMBER,
  unique_id VARCHAR2(100),
  appid     NUMBER
)
nologging;

prompt
prompt Creating table DIM_UC_OPEN_MAPPING_100132
prompt =========================================
prompt
create table DIM_UC_OPEN_MAPPING_100132
(
  f_logtime DATE,
  uuid      NUMBER,
  unique_id VARCHAR2(100),
  appid     NUMBER
)
nologging;

prompt
prompt Creating table DIM_UC_OPEN_MAPPING_100150
prompt =========================================
prompt
create table DIM_UC_OPEN_MAPPING_100150
(
  f_logtime DATE,
  uuid      NUMBER,
  unique_id VARCHAR2(100),
  appid     NUMBER
)
;

prompt
prompt Creating table DIM_UC_OPEN_MAPPING_100178
prompt =========================================
prompt
create table DIM_UC_OPEN_MAPPING_100178
(
  f_logtime DATE,
  uuid      NUMBER,
  unique_id VARCHAR2(100),
  appid     NUMBER
)
;

prompt
prompt Creating table DIM_WEEK
prompt =======================
prompt
create table DIM_WEEK
(
  weekid       NUMBER,
  week_cal     NUMBER,
  week_d       VARCHAR2(10),
  week_des     VARCHAR2(10),
  last_week_id NUMBER,
  last_week    VARCHAR2(10)
)
;
comment on table DIM_WEEK
  is '��ά�ȱ�';
comment on column DIM_WEEK.weekid
  is '��ID��201409��';
comment on column DIM_WEEK.week_cal
  is '�����ָ�ʽ��1��';
comment on column DIM_WEEK.week_d
  is '�ܣ�01�ܣ�';
comment on column DIM_WEEK.week_des
  is '��������2012-W01��';
comment on column DIM_WEEK.last_week_id
  is '��������201208��';
comment on column DIM_WEEK.last_week
  is '��������2012-W08��';

prompt
prompt Creating table DX_SDK_CONN_1151
prompt ===============================
prompt
create table DX_SDK_CONN_1151
(
  thedate         VARCHAR2(48) not null,
  userid          VARCHAR2(40) not null,
  uuid            VARCHAR2(200) not null,
  gameid          VARCHAR2(400) not null,
  version         VARCHAR2(100),
  platform        VARCHAR2(20),
  pid             VARCHAR2(20),
  loaddate        DATE,
  newdate         VARCHAR2(40),
  subcoopid       VARCHAR2(40),
  originalcoopid  VARCHAR2(40),
  originalversion VARCHAR2(100)
)
;

prompt
prompt Creating table DX_SDK_CONN_1160
prompt ===============================
prompt
create table DX_SDK_CONN_1160
(
  thedate         VARCHAR2(48) not null,
  userid          VARCHAR2(40) not null,
  uuid            VARCHAR2(200) not null,
  gameid          VARCHAR2(400) not null,
  version         VARCHAR2(100),
  platform        VARCHAR2(20),
  pid             VARCHAR2(20),
  loaddate        DATE,
  newdate         VARCHAR2(40),
  subcoopid       VARCHAR2(40),
  originalcoopid  VARCHAR2(40),
  originalversion VARCHAR2(100)
)
;

prompt
prompt Creating table DX_SDK_CONN_ANDR_OPEN
prompt ====================================
prompt
create table DX_SDK_CONN_ANDR_OPEN
(
  thedate        VARCHAR2(48) not null,
  gameid         VARCHAR2(400) not null,
  originalcoopid VARCHAR2(40),
  version        VARCHAR2(100),
  uuid           VARCHAR2(200) not null,
  userid         VARCHAR2(40) not null,
  newdate        VARCHAR2(40)
)
;

prompt
prompt Creating table DX_SDK_NEWUSER_1151
prompt ==================================
prompt
create table DX_SDK_NEWUSER_1151
(
  uuid           NUMBER,
  gameid         NUMBER,
  userid         VARCHAR2(40),
  firstlogintime NUMBER,
  lastlogintime  NUMBER,
  platformid     NUMBER,
  version        VARCHAR2(40),
  pid            NUMBER,
  loaddate       DATE,
  subcoopid      VARCHAR2(40),
  reg_time       DATE
)
;

prompt
prompt Creating table DX_SDK_NEWUSER_1160
prompt ==================================
prompt
create table DX_SDK_NEWUSER_1160
(
  uuid           NUMBER,
  gameid         NUMBER,
  userid         VARCHAR2(40),
  firstlogintime NUMBER,
  lastlogintime  NUMBER,
  platformid     NUMBER,
  version        VARCHAR2(40),
  pid            NUMBER,
  loaddate       DATE,
  subcoopid      VARCHAR2(40),
  reg_time       DATE
)
;

prompt
prompt Creating table DX_SDK_NEWUSER_ANDR_OPEN
prompt =======================================
prompt
create table DX_SDK_NEWUSER_ANDR_OPEN
(
  reg_time  DATE,
  gameid    VARCHAR2(40),
  subcoopid VARCHAR2(40),
  version   VARCHAR2(40),
  uuid      VARCHAR2(40),
  userid    VARCHAR2(40)
)
;

prompt
prompt Creating table DX_SDK_ORDER_ANDR_OPEN
prompt =====================================
prompt
create table DX_SDK_ORDER_ANDR_OPEN
(
  appid          VARCHAR2(20),
  uuid           VARCHAR2(100),
  uuid_old       VARCHAR2(100),
  channelid      VARCHAR2(100),
  orderid        VARCHAR2(200),
  rechargeamt    NUMBER,
  orderstarttime DATE,
  orderendtime   DATE,
  rechargstatus  NUMBER,
  server         VARCHAR2(100),
  role_name      VARCHAR2(200),
  ilevel         NUMBER(10),
  custom_column  VARCHAR2(200),
  cpid           VARCHAR2(100),
  coins          NUMBER,
  roleid         VARCHAR2(100),
  createtime     DATE
)
;

prompt
prompt Creating table EMPP
prompt ===================
prompt
create table EMPP
(
  emp_no VARCHAR2(2)
)
;

prompt
prompt Creating table ERROR_LOG
prompt ========================
prompt
create table ERROR_LOG
(
  error_id         NUMBER,
  error_createtime DATE,
  error_code       VARCHAR2(200),
  error_source     VARCHAR2(100),
  error_localinfo  VARCHAR2(500),
  error_position   VARCHAR2(100),
  error_appid      VARCHAR2(100),
  error_alert      NUMBER default 0
)
;
comment on table ERROR_LOG
  is '���ݴ��ݴ����¼';
comment on column ERROR_LOG.error_id
  is 'id';
comment on column ERROR_LOG.error_createtime
  is '����ʱ��';
comment on column ERROR_LOG.error_code
  is 'ϵͳ�������';
comment on column ERROR_LOG.error_source
  is '����Դ';
comment on column ERROR_LOG.error_localinfo
  is '���ش�����Ϣ';
comment on column ERROR_LOG.error_position
  is '����λ��';
comment on column ERROR_LOG.error_appid
  is '����APPID';
comment on column ERROR_LOG.error_alert
  is '0��ʾû�з���Ԥ�� 1��ʾ�Ѿ�����Ԥ��';

prompt
prompt Creating table ERROR_LOG_HOUR
prompt =============================
prompt
create table ERROR_LOG_HOUR
(
  error_id         NUMBER,
  error_createtime DATE,
  error_code       VARCHAR2(200),
  error_source     VARCHAR2(100),
  error_localinfo  VARCHAR2(500),
  error_position   VARCHAR2(100),
  error_appid      VARCHAR2(100),
  error_alert      NUMBER
)
;


spool off
