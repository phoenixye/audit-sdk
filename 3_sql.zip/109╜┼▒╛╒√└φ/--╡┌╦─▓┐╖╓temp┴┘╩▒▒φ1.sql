------------------------------------------------------------
-- Export file for user DEVELOPER@BI_RACDB1_111.13.20.109 --
-- Created by Administrator on 2015/6/3, 14:34:20 ----------
------------------------------------------------------------

set define off
spool --���Ĳ���temp��ʱ��1.log

prompt
prompt Creating table T_ERROR_LOG
prompt ==========================
prompt
create table T_ERROR_LOG
(
  err_time   DATE,
  err_proc   VARCHAR2(64),
  err_code   VARCHAR2(32),
  err_str    VARCHAR2(500),
  err_status NUMBER
)
;
comment on table T_ERROR_LOG
  is '������־��';

prompt
prompt Creating table T_FIRM_NU_DVID
prompt =============================
prompt
create table T_FIRM_NU_DVID
(
  thedate      VARCHAR2(20) not null,
  gameid       VARCHAR2(20) not null,
  channelid    VARCHAR2(20) not null,
  dvid         VARCHAR2(50) not null,
  platform     VARCHAR2(20) not null,
  country_type VARCHAR2(20) not null,
  online_type  VARCHAR2(20) not null,
  loaddate     DATE default Sysdate,
  data_source  VARCHAR2(100)
)
;
comment on table T_FIRM_NU_DVID
  is '��˾�豸�����';
comment on column T_FIRM_NU_DVID.thedate
  is '����ʱ��';
comment on column T_FIRM_NU_DVID.gameid
  is '��ϷID';
comment on column T_FIRM_NU_DVID.channelid
  is '����ID';
comment on column T_FIRM_NU_DVID.dvid
  is '�豸ID';
comment on column T_FIRM_NU_DVID.platform
  is 'ƽ̨';
comment on column T_FIRM_NU_DVID.country_type
  is '���� ''INTERNAL''������ ''OVERSEAS''';
comment on column T_FIRM_NU_DVID.online_type
  is '���� ''ONLINE''������ ''SINGLE''';
create index IDX3_FIRM on T_FIRM_NU_DVID (CHANNELID);
create index IDX4_FIRM on T_FIRM_NU_DVID (THEDATE);

prompt
prompt Creating table T_FIRM_NU_MAC
prompt ============================
prompt
create table T_FIRM_NU_MAC
(
  thedate      VARCHAR2(20) not null,
  gameid       VARCHAR2(20) not null,
  channelid    VARCHAR2(20) not null,
  dvid         VARCHAR2(50) not null,
  platform     VARCHAR2(20) not null,
  country_type VARCHAR2(20) not null,
  online_type  VARCHAR2(20) not null,
  loaddate     DATE default Sysdate,
  data_source  VARCHAR2(100)
)
;
comment on table T_FIRM_NU_MAC
  is '��˾�豸������';
comment on column T_FIRM_NU_MAC.thedate
  is '����ʱ��';
comment on column T_FIRM_NU_MAC.gameid
  is '��ϷID';
comment on column T_FIRM_NU_MAC.channelid
  is '����ID';
comment on column T_FIRM_NU_MAC.dvid
  is '�豸ID';
comment on column T_FIRM_NU_MAC.platform
  is 'ƽ̨';
comment on column T_FIRM_NU_MAC.country_type
  is '���� ''INTERNAL''������ ''OVERSEAS''';
comment on column T_FIRM_NU_MAC.online_type
  is '���� ''ONLINE''������ ''SINGLE''';
create index IDX1_FIRM on T_FIRM_NU_MAC (CHANNELID);
create index IDX2_FIRM on T_FIRM_NU_MAC (THEDATE);

prompt
prompt Creating table T_FIRM_SDK_INCOME
prompt ================================
prompt
create table T_FIRM_SDK_INCOME
(
  thedate   VARCHAR2(10),
  appid     VARCHAR2(50),
  channelid VARCHAR2(50),
  amount    NUMBER,
  loaddate  DATE default sysdate
)
;
comment on table T_FIRM_SDK_INCOME
  is '��˾sdk������ϸ��';
comment on column T_FIRM_SDK_INCOME.thedate
  is '����';
comment on column T_FIRM_SDK_INCOME.appid
  is '��ƷID';
comment on column T_FIRM_SDK_INCOME.channelid
  is '����ID';
comment on column T_FIRM_SDK_INCOME.amount
  is '���֣�';
create index IDX7_FIRM on T_FIRM_SDK_INCOME (THEDATE);

prompt
prompt Creating table T_MAPPING_APP_CHANNEL
prompt ====================================
prompt
create table T_MAPPING_APP_CHANNEL
(
  gameid    NUMBER,
  channelid NUMBER
)
;
comment on table T_MAPPING_APP_CHANNEL
  is '��Ʒ����ӳ���';

prompt
prompt Creating table T_TEMPLATE_INCOME
prompt ================================
prompt
create table T_TEMPLATE_INCOME
(
  thedate      VARCHAR2(20),
  appname      VARCHAR2(100),
  operatorcode VARCHAR2(20),
  operatorname CHAR(40),
  channelid    VARCHAR2(100),
  channelname  VARCHAR2(100),
  activeusers  NUMBER,
  payusers     NUMBER,
  payincome    NUMBER
)
;
comment on column T_TEMPLATE_INCOME.thedate
  is '����';
comment on column T_TEMPLATE_INCOME.appname
  is '��Ϸ����';
comment on column T_TEMPLATE_INCOME.operatorcode
  is '��Ӫ�̴���';
comment on column T_TEMPLATE_INCOME.operatorname
  is '��Ӫ������';
comment on column T_TEMPLATE_INCOME.channelid
  is '����ID';
comment on column T_TEMPLATE_INCOME.channelname
  is '��������';
comment on column T_TEMPLATE_INCOME.activeusers
  is '���������û���';
comment on column T_TEMPLATE_INCOME.payusers
  is '���ո�������';
comment on column T_TEMPLATE_INCOME.payincome
  is '���ո����ܶ�';

prompt
prompt Creating table T_TEMPLATE_INCOME_BACKUP
prompt =======================================
prompt
create table T_TEMPLATE_INCOME_BACKUP
(
  thedate      VARCHAR2(20),
  appname      VARCHAR2(100),
  operatorcode VARCHAR2(20),
  operatorname CHAR(40),
  channelid    VARCHAR2(100),
  channelname  VARCHAR2(100),
  activeusers  NUMBER,
  payusers     NUMBER,
  payincome    NUMBER
)
;

prompt
prompt Creating table T_TMP_100091_CONN
prompt ================================
prompt
create table T_TMP_100091_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(60),
  ispay       NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100091_CONN_LOST_MAC
prompt =========================================
prompt
create table T_TMP_100091_CONN_LOST_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
nologging;

prompt
prompt Creating table T_TMP_100091_CONN_LOST_USER
prompt ==========================================
prompt
create table T_TMP_100091_CONN_LOST_USER
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(60),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
nologging;

prompt
prompt Creating table T_TMP_100091_CONN_MAC
prompt ====================================
prompt
create table T_TMP_100091_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  ispay       NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100091_CONN_MAC_F_BACK
prompt ===========================================
prompt
create table T_TMP_100091_CONN_MAC_F_BACK
(
  conndate  VARCHAR2(10),
  channelid VARCHAR2(20),
  serverid  VARCHAR2(20),
  gameid    VARCHAR2(20),
  dvid      VARCHAR2(50)
)
nologging;

prompt
prompt Creating table T_TMP_100091_CONN_USER_F_BACK
prompt ============================================
prompt
create table T_TMP_100091_CONN_USER_F_BACK
(
  conndate  VARCHAR2(10),
  channelid VARCHAR2(20),
  serverid  VARCHAR2(20),
  gameid    VARCHAR2(20),
  accountid VARCHAR2(60)
)
nologging;

prompt
prompt Creating table T_TMP_100091_FACT_LOST_MAC
prompt =========================================
prompt
create table T_TMP_100091_FACT_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
nologging;

prompt
prompt Creating table T_TMP_100091_FACT_LOST_MAC_AS
prompt ============================================
prompt
create table T_TMP_100091_FACT_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
nologging;

prompt
prompt Creating table T_TMP_100091_FACT_LOST_USER
prompt ==========================================
prompt
create table T_TMP_100091_FACT_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(60),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
nologging;

prompt
prompt Creating table T_TMP_100091_FACT_LOST_USER_AS
prompt =============================================
prompt
create table T_TMP_100091_FACT_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(60),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
nologging;

prompt
prompt Creating table T_TMP_100091_LOST_MAC
prompt ====================================
prompt
create table T_TMP_100091_LOST_MAC
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  macid     VARCHAR2(50),
  lost_days NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100091_LOST_MAC_ISPAY
prompt ==========================================
prompt
create table T_TMP_100091_LOST_MAC_ISPAY
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  macid     VARCHAR2(50),
  lost_days NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100091_LOST_MAC_ISPAY_W
prompt ============================================
prompt
create table T_TMP_100091_LOST_MAC_ISPAY_W
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  macid     VARCHAR2(50),
  lost_days VARCHAR2(20)
)
nologging;

prompt
prompt Creating table T_TMP_100091_LOST_MAC_WEEK
prompt =========================================
prompt
create table T_TMP_100091_LOST_MAC_WEEK
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  macid     VARCHAR2(50),
  lost_days VARCHAR2(20)
)
nologging;

prompt
prompt Creating table T_TMP_100091_LOST_USER
prompt =====================================
prompt
create table T_TMP_100091_LOST_USER
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  userid    VARCHAR2(60),
  lost_days NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100091_LOST_USER_ISPAY
prompt ===========================================
prompt
create table T_TMP_100091_LOST_USER_ISPAY
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  userid    VARCHAR2(60),
  lost_days NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100091_LOST_USER_ISPAY_W
prompt =============================================
prompt
create table T_TMP_100091_LOST_USER_ISPAY_W
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  userid    VARCHAR2(60),
  lost_days VARCHAR2(20)
)
nologging;

prompt
prompt Creating table T_TMP_100091_LOST_USER_WEEK
prompt ==========================================
prompt
create table T_TMP_100091_LOST_USER_WEEK
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  userid    VARCHAR2(60),
  lost_days VARCHAR2(20)
)
nologging;

prompt
prompt Creating table T_TMP_100091_ORDER_SUCC
prompt ======================================
prompt
create table T_TMP_100091_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  serverid    VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  position    VARCHAR2(50),
  rolelevel   NUMBER,
  accountid   VARCHAR2(60),
  money       NUMBER,
  nu          NUMBER
)
;

prompt
prompt Creating table T_TMP_100131_CONN
prompt ================================
prompt
create table T_TMP_100131_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50),
  ispay       NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100131_CONN_LOST_MAC
prompt =========================================
prompt
create table T_TMP_100131_CONN_LOST_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
nologging;

prompt
prompt Creating table T_TMP_100131_CONN_LOST_USER
prompt ==========================================
prompt
create table T_TMP_100131_CONN_LOST_USER
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
nologging;

prompt
prompt Creating table T_TMP_100131_CONN_MAC
prompt ====================================
prompt
create table T_TMP_100131_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  ispay       NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100131_CONN_MAC_F_BACK
prompt ===========================================
prompt
create table T_TMP_100131_CONN_MAC_F_BACK
(
  conndate  VARCHAR2(10),
  channelid VARCHAR2(20),
  serverid  VARCHAR2(20),
  gameid    VARCHAR2(20),
  dvid      VARCHAR2(50)
)
nologging;

prompt
prompt Creating table T_TMP_100131_CONN_USER_F_BACK
prompt ============================================
prompt
create table T_TMP_100131_CONN_USER_F_BACK
(
  conndate  VARCHAR2(10),
  channelid VARCHAR2(20),
  serverid  VARCHAR2(20),
  gameid    VARCHAR2(20),
  accountid VARCHAR2(50)
)
nologging;

prompt
prompt Creating table T_TMP_100131_FACT_LOST_MAC
prompt =========================================
prompt
create table T_TMP_100131_FACT_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
nologging;

prompt
prompt Creating table T_TMP_100131_FACT_LOST_MAC_AS
prompt ============================================
prompt
create table T_TMP_100131_FACT_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
nologging;

prompt
prompt Creating table T_TMP_100131_FACT_LOST_USER
prompt ==========================================
prompt
create table T_TMP_100131_FACT_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
nologging;

prompt
prompt Creating table T_TMP_100131_FACT_LOST_USER_AS
prompt =============================================
prompt
create table T_TMP_100131_FACT_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
nologging;

prompt
prompt Creating table T_TMP_100131_LOST_MAC
prompt ====================================
prompt
create table T_TMP_100131_LOST_MAC
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  macid     VARCHAR2(50),
  lost_days NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100131_LOST_MAC_ISPAY
prompt ==========================================
prompt
create table T_TMP_100131_LOST_MAC_ISPAY
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  macid     VARCHAR2(50),
  lost_days NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100131_LOST_MAC_ISPAY_W
prompt ============================================
prompt
create table T_TMP_100131_LOST_MAC_ISPAY_W
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  macid     VARCHAR2(50),
  lost_days VARCHAR2(20)
)
nologging;

prompt
prompt Creating table T_TMP_100131_LOST_MAC_WEEK
prompt =========================================
prompt
create table T_TMP_100131_LOST_MAC_WEEK
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  macid     VARCHAR2(50),
  lost_days VARCHAR2(20)
)
nologging;

prompt
prompt Creating table T_TMP_100131_LOST_USER
prompt =====================================
prompt
create table T_TMP_100131_LOST_USER
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  userid    VARCHAR2(50),
  lost_days NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100131_LOST_USER_ISPAY
prompt ===========================================
prompt
create table T_TMP_100131_LOST_USER_ISPAY
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  userid    VARCHAR2(50),
  lost_days NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100131_LOST_USER_ISPAY_W
prompt =============================================
prompt
create table T_TMP_100131_LOST_USER_ISPAY_W
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  userid    VARCHAR2(50),
  lost_days VARCHAR2(20)
)
nologging;

prompt
prompt Creating table T_TMP_100131_LOST_USER_WEEK
prompt ==========================================
prompt
create table T_TMP_100131_LOST_USER_WEEK
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  userid    VARCHAR2(50),
  lost_days VARCHAR2(20)
)
nologging;

prompt
prompt Creating table T_TMP_100131_ORDER_SUCC
prompt ======================================
prompt
create table T_TMP_100131_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  serverid    VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  position    VARCHAR2(50),
  rolelevel   NUMBER,
  accountid   VARCHAR2(50),
  money       NUMBER,
  nu          NUMBER
)
;

prompt
prompt Creating table T_TMP_100132_CONN
prompt ================================
prompt
create table T_TMP_100132_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(60),
  ispay       NUMBER
)
;

prompt
prompt Creating table T_TMP_100132_CONN_A
prompt ==================================
prompt
create table T_TMP_100132_CONN_A
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(60),
  ispay       NUMBER
)
;

prompt
prompt Creating table T_TMP_100132_CONN_LOST_MAC
prompt =========================================
prompt
create table T_TMP_100132_CONN_LOST_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
nologging;

prompt
prompt Creating table T_TMP_100132_CONN_LOST_USER
prompt ==========================================
prompt
create table T_TMP_100132_CONN_LOST_USER
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(60),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
nologging;

prompt
prompt Creating table T_TMP_100132_CONN_MAC
prompt ====================================
prompt
create table T_TMP_100132_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  ispay       NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100132_CONN_MAC_F_BACK
prompt ===========================================
prompt
create table T_TMP_100132_CONN_MAC_F_BACK
(
  conndate  VARCHAR2(10),
  channelid VARCHAR2(20),
  serverid  VARCHAR2(20),
  gameid    VARCHAR2(20),
  dvid      VARCHAR2(50)
)
nologging;

prompt
prompt Creating table T_TMP_100132_CONN_USER_F_BACK
prompt ============================================
prompt
create table T_TMP_100132_CONN_USER_F_BACK
(
  conndate  VARCHAR2(10),
  channelid VARCHAR2(20),
  serverid  VARCHAR2(20),
  gameid    VARCHAR2(20),
  accountid VARCHAR2(60)
)
nologging;

prompt
prompt Creating table T_TMP_100132_FACT_LOST_MAC
prompt =========================================
prompt
create table T_TMP_100132_FACT_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
nologging;

prompt
prompt Creating table T_TMP_100132_FACT_LOST_MAC_AS
prompt ============================================
prompt
create table T_TMP_100132_FACT_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
nologging;

prompt
prompt Creating table T_TMP_100132_FACT_LOST_USER
prompt ==========================================
prompt
create table T_TMP_100132_FACT_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(60),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
nologging;

prompt
prompt Creating table T_TMP_100132_FACT_LOST_USER_AS
prompt =============================================
prompt
create table T_TMP_100132_FACT_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(60),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
nologging;

prompt
prompt Creating table T_TMP_100132_LOST_MAC
prompt ====================================
prompt
create table T_TMP_100132_LOST_MAC
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  macid     VARCHAR2(50),
  lost_days NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100132_LOST_MAC_ISPAY
prompt ==========================================
prompt
create table T_TMP_100132_LOST_MAC_ISPAY
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  macid     VARCHAR2(50),
  lost_days NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100132_LOST_MAC_ISPAY_W
prompt ============================================
prompt
create table T_TMP_100132_LOST_MAC_ISPAY_W
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  macid     VARCHAR2(50),
  lost_days VARCHAR2(20)
)
nologging;

prompt
prompt Creating table T_TMP_100132_LOST_MAC_WEEK
prompt =========================================
prompt
create table T_TMP_100132_LOST_MAC_WEEK
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  macid     VARCHAR2(50),
  lost_days VARCHAR2(20)
)
nologging;

prompt
prompt Creating table T_TMP_100132_LOST_USER
prompt =====================================
prompt
create table T_TMP_100132_LOST_USER
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  userid    VARCHAR2(60),
  lost_days NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100132_LOST_USER_ISPAY
prompt ===========================================
prompt
create table T_TMP_100132_LOST_USER_ISPAY
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  userid    VARCHAR2(60),
  lost_days NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100132_LOST_USER_ISPAY_W
prompt =============================================
prompt
create table T_TMP_100132_LOST_USER_ISPAY_W
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  userid    VARCHAR2(60),
  lost_days VARCHAR2(20)
)
nologging;

prompt
prompt Creating table T_TMP_100132_LOST_USER_WEEK
prompt ==========================================
prompt
create table T_TMP_100132_LOST_USER_WEEK
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  userid    VARCHAR2(60),
  lost_days VARCHAR2(20)
)
nologging;

prompt
prompt Creating table T_TMP_100132_ORDER_SUCC
prompt ======================================
prompt
create table T_TMP_100132_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  serverid    VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  position    VARCHAR2(50),
  rolelevel   NUMBER,
  accountid   VARCHAR2(60),
  money       NUMBER,
  nu          NUMBER
)
;

prompt
prompt Creating table T_TMP_100138_CONN
prompt ================================
prompt
create table T_TMP_100138_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50),
  ispay       NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100138_CONN_LOST_MAC
prompt =========================================
prompt
create table T_TMP_100138_CONN_LOST_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
nologging;

prompt
prompt Creating table T_TMP_100138_CONN_LOST_USER
prompt ==========================================
prompt
create table T_TMP_100138_CONN_LOST_USER
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
nologging;

prompt
prompt Creating table T_TMP_100138_CONN_MAC
prompt ====================================
prompt
create table T_TMP_100138_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  ispay       NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100138_CONN_MAC_F_BACK
prompt ===========================================
prompt
create table T_TMP_100138_CONN_MAC_F_BACK
(
  conndate  VARCHAR2(10),
  channelid VARCHAR2(20),
  serverid  VARCHAR2(20),
  gameid    VARCHAR2(20),
  dvid      VARCHAR2(50)
)
nologging;

prompt
prompt Creating table T_TMP_100138_CONN_USER_F_BACK
prompt ============================================
prompt
create table T_TMP_100138_CONN_USER_F_BACK
(
  conndate  VARCHAR2(10),
  channelid VARCHAR2(20),
  serverid  VARCHAR2(20),
  gameid    VARCHAR2(20),
  accountid VARCHAR2(50)
)
nologging;

prompt
prompt Creating table T_TMP_100138_FACT_LOST_MAC
prompt =========================================
prompt
create table T_TMP_100138_FACT_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
nologging;

prompt
prompt Creating table T_TMP_100138_FACT_LOST_MAC_AS
prompt ============================================
prompt
create table T_TMP_100138_FACT_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
nologging;

prompt
prompt Creating table T_TMP_100138_FACT_LOST_USER
prompt ==========================================
prompt
create table T_TMP_100138_FACT_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
nologging;

prompt
prompt Creating table T_TMP_100138_FACT_LOST_USER_AS
prompt =============================================
prompt
create table T_TMP_100138_FACT_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
nologging;

prompt
prompt Creating table T_TMP_100138_LOST_MAC
prompt ====================================
prompt
create table T_TMP_100138_LOST_MAC
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  macid     VARCHAR2(50),
  lost_days NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100138_LOST_MAC_ISPAY
prompt ==========================================
prompt
create table T_TMP_100138_LOST_MAC_ISPAY
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  macid     VARCHAR2(50),
  lost_days NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100138_LOST_MAC_ISPAY_W
prompt ============================================
prompt
create table T_TMP_100138_LOST_MAC_ISPAY_W
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  macid     VARCHAR2(50),
  lost_days VARCHAR2(20)
)
nologging;

prompt
prompt Creating table T_TMP_100138_LOST_MAC_WEEK
prompt =========================================
prompt
create table T_TMP_100138_LOST_MAC_WEEK
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  macid     VARCHAR2(50),
  lost_days VARCHAR2(20)
)
nologging;

prompt
prompt Creating table T_TMP_100138_LOST_USER
prompt =====================================
prompt
create table T_TMP_100138_LOST_USER
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  userid    VARCHAR2(50),
  lost_days NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100138_LOST_USER_ISPAY
prompt ===========================================
prompt
create table T_TMP_100138_LOST_USER_ISPAY
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  userid    VARCHAR2(50),
  lost_days NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100138_LOST_USER_ISPAY_W
prompt =============================================
prompt
create table T_TMP_100138_LOST_USER_ISPAY_W
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  userid    VARCHAR2(50),
  lost_days VARCHAR2(20)
)
nologging;

prompt
prompt Creating table T_TMP_100138_LOST_USER_WEEK
prompt ==========================================
prompt
create table T_TMP_100138_LOST_USER_WEEK
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  userid    VARCHAR2(50),
  lost_days VARCHAR2(20)
)
nologging;

prompt
prompt Creating table T_TMP_100150_CONN
prompt ================================
prompt
create table T_TMP_100150_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50),
  ispay       NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100150_CONN_LOST_MAC
prompt =========================================
prompt
create table T_TMP_100150_CONN_LOST_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
nologging;

prompt
prompt Creating table T_TMP_100150_CONN_LOST_USER
prompt ==========================================
prompt
create table T_TMP_100150_CONN_LOST_USER
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
nologging;

prompt
prompt Creating table T_TMP_100150_CONN_MAC
prompt ====================================
prompt
create table T_TMP_100150_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  ispay       NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100150_CONN_MAC_F_BACK
prompt ===========================================
prompt
create table T_TMP_100150_CONN_MAC_F_BACK
(
  conndate  VARCHAR2(10),
  channelid VARCHAR2(20),
  serverid  VARCHAR2(20),
  gameid    VARCHAR2(20),
  dvid      VARCHAR2(50)
)
nologging;

prompt
prompt Creating table T_TMP_100150_CONN_USER_F_BACK
prompt ============================================
prompt
create table T_TMP_100150_CONN_USER_F_BACK
(
  conndate  VARCHAR2(10),
  channelid VARCHAR2(20),
  serverid  VARCHAR2(20),
  gameid    VARCHAR2(20),
  accountid VARCHAR2(50)
)
nologging;

prompt
prompt Creating table T_TMP_100150_FACT_LOST_MAC
prompt =========================================
prompt
create table T_TMP_100150_FACT_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
nologging;

prompt
prompt Creating table T_TMP_100150_FACT_LOST_MAC_AS
prompt ============================================
prompt
create table T_TMP_100150_FACT_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
nologging;

prompt
prompt Creating table T_TMP_100150_FACT_LOST_USER
prompt ==========================================
prompt
create table T_TMP_100150_FACT_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
nologging;

prompt
prompt Creating table T_TMP_100150_FACT_LOST_USER_AS
prompt =============================================
prompt
create table T_TMP_100150_FACT_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
nologging;

prompt
prompt Creating table T_TMP_100150_LOST_MAC
prompt ====================================
prompt
create table T_TMP_100150_LOST_MAC
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  macid     VARCHAR2(50),
  lost_days NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100150_LOST_MAC_ISPAY
prompt ==========================================
prompt
create table T_TMP_100150_LOST_MAC_ISPAY
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  macid     VARCHAR2(50),
  lost_days NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100150_LOST_MAC_ISPAY_W
prompt ============================================
prompt
create table T_TMP_100150_LOST_MAC_ISPAY_W
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  macid     VARCHAR2(50),
  lost_days VARCHAR2(20)
)
nologging;

prompt
prompt Creating table T_TMP_100150_LOST_MAC_WEEK
prompt =========================================
prompt
create table T_TMP_100150_LOST_MAC_WEEK
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  macid     VARCHAR2(50),
  lost_days VARCHAR2(20)
)
nologging;

prompt
prompt Creating table T_TMP_100150_LOST_USER
prompt =====================================
prompt
create table T_TMP_100150_LOST_USER
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  userid    VARCHAR2(50),
  lost_days NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100150_LOST_USER_ISPAY
prompt ===========================================
prompt
create table T_TMP_100150_LOST_USER_ISPAY
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  userid    VARCHAR2(50),
  lost_days NUMBER
)
nologging;

prompt
prompt Creating table T_TMP_100150_LOST_USER_ISPAY_W
prompt =============================================
prompt
create table T_TMP_100150_LOST_USER_ISPAY_W
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  userid    VARCHAR2(50),
  lost_days VARCHAR2(20)
)
nologging;

prompt
prompt Creating table T_TMP_100150_LOST_USER_WEEK
prompt ==========================================
prompt
create table T_TMP_100150_LOST_USER_WEEK
(
  channelid VARCHAR2(50),
  serverid  VARCHAR2(50),
  appid     VARCHAR2(50),
  userid    VARCHAR2(50),
  lost_days VARCHAR2(20)
)
nologging;

prompt
prompt Creating table T_TMP_100150_ORDER_SUCC
prompt ======================================
prompt
create table T_TMP_100150_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  serverid    VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  position    VARCHAR2(50),
  rolelevel   NUMBER,
  accountid   VARCHAR2(50),
  money       NUMBER,
  nu          NUMBER
)
;

prompt
prompt Creating table T_TMP_DW_100138_CONN_MAC
prompt =======================================
prompt
create table T_TMP_DW_100138_CONN_MAC
(
  thedate     VARCHAR2(10),
  appid       VARCHAR2(10),
  channelid   VARCHAR2(50),
  gameversion VARCHAR2(50),
  dvid        VARCHAR2(50),
  serverid    VARCHAR2(50),
  rolelevel   NUMBER
)
;

prompt
prompt Creating table T_TMP_DW_100138_CONN_USER
prompt ========================================
prompt
create table T_TMP_DW_100138_CONN_USER
(
  thedate     VARCHAR2(10),
  appid       VARCHAR2(10),
  channelid   VARCHAR2(50),
  gameversion VARCHAR2(50),
  accountid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  rolelevel   NUMBER
)
;


spool off
