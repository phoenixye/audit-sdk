------------------------------------------------------------
-- Export file for user DEVELOPER@BI_RACDB1_111.13.20.109 --
-- Created by Administrator on 2015/6/4, 14:56:30 ----------
------------------------------------------------------------

set define off
spool --pakage-body open Ǩ�Ƽ����̲���.log

prompt
prompt Creating package PKG_OPEN_TO_BI
prompt ===============================
prompt
CREATE OR REPLACE Package Pkg_Open_To_Bi Is
  Procedure p_All;

  Procedure Sgzs_Sdk_Newuser_1149_To_Nu;

  Procedure Sgzs_Sdk_Newuser_1161_To_Nu;

  Procedure Sgzs_Pdt_Sdk_Conn_1149_To_Conn;

  Procedure Sgzs_Pdt_Sdk_Conn_1161_To_Conn;

  Procedure p_His_Ins;

  Procedure p_New_Ins; --2014-12-04(��)
		
	Procedure p_inssss; --
End Pkg_Open_To_Bi;
/

prompt
prompt Creating package PKG_OPEN_TO_BISOURCE_100091
prompt ============================================
prompt
CREATE OR REPLACE PACKAGE PKG_OPEN_TO_BISOURCE_100091 AS

  PROCEDURE PROC_OPEN_TO_BISU_100091_ALL(INPUTDATE IN NUMBER);
  PROCEDURE PROC_OPEN_TO_BISU_100091_MAP(INPUTDATE IN NUMBER);
  PROCEDURE PROC_OPEN_TO_BISU_100091_NU(INPUTDATE IN NUMBER);
  PROCEDURE PROC_OPEN_TO_BISU_100091_CONN(INPUTDATE IN NUMBER);
  PROCEDURE PROC_OPEN_TO_BISU_100091_ORDER(INPUTDATE IN NUMBER);
  PROCEDURE PROC_LOCAL_TO_BI_100091_NU(INPUTDATE IN NUMBER);
  PROCEDURE PROC_LOCAL_TO_BI_100091_CO_NP(INPUTDATE IN NUMBER);
  PROCEDURE PROC_LOCAL_TO_BI_100091_PAY(INPUTDATE IN NUMBER);

END PKG_OPEN_TO_BISOURCE_100091;
/

prompt
prompt Creating package PKG_OPEN_TO_BISOURCE_100131
prompt ============================================
prompt
CREATE OR REPLACE PACKAGE PKG_OPEN_TO_BISOURCE_100131 AS

  PROCEDURE PROC_OPEN_TO_BISU_100131_ALL(INPUTDATE IN NUMBER);
  PROCEDURE PROC_OPEN_TO_BISU_100131_MAP(INPUTDATE IN NUMBER);
  PROCEDURE PROC_OPEN_TO_BISU_100131_NU(INPUTDATE IN NUMBER);
  PROCEDURE PROC_OPEN_TO_BISU_100131_CONN(INPUTDATE IN NUMBER);
  PROCEDURE PROC_OPEN_TO_BISU_100131_ORDER(INPUTDATE IN NUMBER);
  PROCEDURE PROC_LOCAL_TO_BI_100131_NU(INPUTDATE IN NUMBER);
  PROCEDURE PROC_LOCAL_TO_BI_100131_CO_NP(INPUTDATE IN NUMBER);
  PROCEDURE PROC_LOCAL_TO_BI_100131_PAY(INPUTDATE IN NUMBER);

END PKG_OPEN_TO_BISOURCE_100131;
/

prompt
prompt Creating package PKG_OPEN_TO_BISOURCE_100132
prompt ============================================
prompt
CREATE OR REPLACE PACKAGE PKG_OPEN_TO_BISOURCE_100132 AS

  PROCEDURE PROC_OPEN_TO_BISU_100132_ALL(INPUTDATE IN NUMBER);
  PROCEDURE PROC_OPEN_TO_BISU_100132_MAP(INPUTDATE IN NUMBER);
  PROCEDURE PROC_OPEN_TO_BISU_100132_NU(INPUTDATE IN NUMBER);
  PROCEDURE PROC_OPEN_TO_BISU_100132_CONN(INPUTDATE IN NUMBER);
  PROCEDURE PROC_OPEN_TO_BISU_100132_ORDER(INPUTDATE IN NUMBER);
  PROCEDURE PROC_LOCAL_TO_BI_100132_NU(INPUTDATE IN NUMBER);
  PROCEDURE PROC_LOCAL_TO_BI_100132_CO_NP(INPUTDATE IN NUMBER);
  PROCEDURE PROC_LOCAL_TO_BI_100132_PAY(INPUTDATE IN NUMBER);

END PKG_OPEN_TO_BISOURCE_100132;
/

prompt
prompt Creating package PKG_OPEN_TO_BISOURCE_100150
prompt ============================================
prompt
CREATE OR REPLACE PACKAGE PKG_OPEN_TO_BISOURCE_100150 AS

  PROCEDURE PROC_OPEN_TO_BISU_100150_ALL(INPUTDATE IN NUMBER);
  PROCEDURE PROC_OPEN_TO_BISU_100150_MAP(INPUTDATE IN NUMBER);
  PROCEDURE PROC_OPEN_TO_BISU_100150_NU(INPUTDATE IN NUMBER);
  PROCEDURE PROC_OPEN_TO_BISU_100150_CONN(INPUTDATE IN NUMBER);
  PROCEDURE PROC_OPEN_TO_BISU_100150_ORDER(INPUTDATE IN NUMBER);
  PROCEDURE PROC_LOCAL_TO_BI_100150_NU(INPUTDATE IN NUMBER);
  PROCEDURE PROC_LOCAL_TO_BI_100150_CO_NP(INPUTDATE IN NUMBER);
  PROCEDURE PROC_LOCAL_TO_BI_100150_PAY(INPUTDATE IN NUMBER);

END PKG_OPEN_TO_BISOURCE_100150;
/

prompt
prompt Creating package PKG_OPEN_TO_BISOURCE_100178
prompt ============================================
prompt
CREATE OR REPLACE PACKAGE PKG_OPEN_TO_BISOURCE_100178 AS

  PROCEDURE PROC_OPEN_TO_BISU_100178_ALL(INPUTDATE IN NUMBER);
  PROCEDURE PROC_OPEN_TO_BISU_100178_MAP(INPUTDATE IN NUMBER);
  /*PROCEDURE PROC_OPEN_TO_BISU_100178_NU(INPUTDATE IN NUMBER);*/
  PROCEDURE PROC_OPEN_TO_BISU_100178_CONN(INPUTDATE IN NUMBER);
  PROCEDURE PROC_OPEN_TO_BISU_100178_ORDER(INPUTDATE IN NUMBER);
  PROCEDURE PROC_LOCAL_TO_BI_100178_LOGIN(INPUTDATE IN NUMBER);
  PROCEDURE PROC_LOCAL_TO_BI_100178_PAY(INPUTDATE IN NUMBER);

END PKG_OPEN_TO_BISOURCE_100178;
/

prompt
prompt Creating package PKG_OPEN_TO_BI_100178
prompt ======================================
prompt
CREATE OR REPLACE PACKAGE PKG_OPEN_TO_BI_100178 IS
  PROCEDURE P_NEW_INS;
END PKG_OPEN_TO_BI_100178;
/

prompt
prompt Creating package PKG_OPEN_TO_BI_100179
prompt ======================================
prompt
CREATE OR REPLACE PACKAGE PKG_OPEN_TO_BI_100179 IS
  PROCEDURE P_HIS_INS;
END PKG_OPEN_TO_BI_100179;
/

prompt
prompt Creating package PKG_OPEN_TO_BI_3_100138
prompt ========================================
prompt
CREATE OR REPLACE PACKAGE PKG_OPEN_TO_BI_3_100138 IS
  PROCEDURE P_HIS_INS;
END PKG_OPEN_TO_BI_3_100138;
/

prompt
prompt Creating package PKG_OPERATOR_INCOME_STAT
prompt =========================================
prompt
CREATE OR REPLACE PACKAGE PKG_OPERATOR_INCOME_STAT IS
  PROCEDURE SP_OPERATOR_INCOME(P_LOGTIME IN VARCHAR2,
                               P_ERRCODE OUT NUMBER,
                               P_ERRSTR  OUT VARCHAR2);
END PKG_OPERATOR_INCOME_STAT;
/

prompt
prompt Creating function F_IP_TO_NUM
prompt =============================
prompt
CREATE OR REPLACE Function f_Ip_To_Num(p_Ipaddress In Varchar2)
  Return Number As
  v_Return Number;
  v_Ip     Varchar2(200) := p_Ipaddress;
Begin
  v_Ip := Nvl(Substr(v_Ip, 1, Instr(v_Ip, ',', 1) - 1), v_Ip);
  For i In 1 .. 3 Loop
  
    v_Ip := Substr(v_Ip, 1, Instr(v_Ip, '.') - 1) || '*POWER(256, ' ||
            (4 - i) || ') + ' || Substr(v_Ip, Instr(v_Ip, '.') + 1);
  End Loop;

  Execute Immediate 'SELECT ' || v_Ip || ' FROM DUAL'
    Into v_Return;
  Return v_Return;
Exception
  When Others Then
    Dbms_Output.Put_Line(p_Ipaddress);
    v_Return := 0;
    Return v_Return;
End;
/

prompt
prompt Creating function F_ORACLE_TO_UNIX
prompt ==================================
prompt
create or replace function F_ORACLE_TO_UNIX(in_date IN DATE)
return number
is
/*
date����תʱ���
*/
begin
  return( (in_date -TO_DATE('1970010108','yyyymmddHH24'))*86400);
end F_ORACLE_TO_UNIX;
/

prompt
prompt Creating function F_UNIX_TO_ORACLE
prompt ==================================
prompt
create or replace function F_UNIX_TO_ORACLE(in_number NUMBER) return date is
/*
ʱ���תdate����
*/
  begin

   return(TO_DATE('1970010108','yyyymmddHH24') + in_number/86400 );

  end F_UNIX_TO_ORACLE;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100091
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100091" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100091';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100091', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100091_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100091_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100091_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100091_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100091_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100091_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100091_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100091_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100091_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100091', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100091_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100091');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100091', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100105
prompt ============================================
prompt
CREATE OR REPLACE Procedure p_Fact_Hour_Report_100105(p_Logtime In Varchar2) Is
  v_Errposition  Varchar2(100); --λ��
  v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
  v_Errsource    Varchar2(100); --��Դ
  v_Errcode      Varchar2(200); --���ݿ�������
  v_Inputdate    Number := 0;
Begin
  --p_Errcode := 7100;
  /*Select Trunc(Sysdate) -
       Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  Into v_Inputdate
  From Dual;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  v_Errsource := 'p_Fact_Hour_Report_100105';
  Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100105', v_Inputdate);
  ------------------------------ִ����־��ʼ----------------------------------------------
  v_Errposition := '1-1';
  Delete From Fact_100105_Hour_Report t;
  Commit;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  v_Errposition := '1-2';
  --����Сʱָ������
  Insert Into Fact_100105_Hour_Report
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           Case
             When t.Datatype = '1' Then
              '�����û���'
             Else
              '�����豸��'
           End Indexid,
           'Сʱָ��' Indtype,
           Sum(t.Newcount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_100105_General_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid, t.Datatype
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           Case
             When t.Datatype = '1' Then
              '��Ծ�û���'
             Else
              '��Ծ�豸��'
           End Indexid,
           'Сʱָ��' Indtype,
           Sum(t.Conncount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_100105_General_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid, t.Datatype
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           Case
             When t.Datatype = '1' Then
              '�����û���'
             Else
              '�����豸��'
           End Indexid,
           'Сʱָ��' Indtype,
           Sum(t.Paycount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_100105_General_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid, t.Datatype
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           '���ѽ��' Indexid,
           'Сʱָ��' Indtype,
           Sum(t.Payamount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_100105_General_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
       And t.Datatype = '1'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid

    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           'ʧ�ܸ����û���' Indexid,
           '��ָ��' Indtype,
           Sum(t.Payfailcount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_100105_Order_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
       And t.Datatype = '1'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           '�����ɹ���' Indexid,
           '��ָ��' Indtype,
           Sum(t.Paysuccnum) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_100105_Order_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
       And t.Datatype = '1'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           '����ʧ����' Indexid,
           '��ָ��' Indtype,
           Sum(t.Payfailnum) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_100105_Order_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
       And t.Datatype = '1'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid;
  Commit;

  ------------------------------ִ����־����----------------------------------------------
  Pkg_Log.Sp_Run_Log_End(v_Errsource, '100105', v_Inputdate);
  ------------------------------ִ����־����----------------------------------------------
Exception
  When Others Then
    Rollback;
    --p_Errcode      := 8100;
    --p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
    v_Errlocalinfo := 'TABLE NAME=Fact_100105_Hour_Report';
    v_Errcode      := Substr(Sqlerrm, 1, 200);
    Pkg_Log.Sp_Error_Log(v_Errcode,
                         v_Errsource,
                         v_Errlocalinfo,
                         v_Errposition,
                         '100105');
    Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100105', v_Inputdate);
    ------------------------------�쳣����----------------------------------------------
End;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100131
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100131" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100131';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100131', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100131_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100131_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100131_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100131_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100131_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100131_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100131_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100131_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100131_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100131', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100131_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100131');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100131', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100132
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100132" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100132';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100132', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100132_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100132_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100132_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100132_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100132_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100132_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100132_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100132_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100132_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100132', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100132_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100132');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100132', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100138
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100138" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100138';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100138', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100138_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100138_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100138_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100138_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100138_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100138_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100138_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100138_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100138_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100138', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100138_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100138');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100138', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100139
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100139" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100139';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100139', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100139_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100139_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100139_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100139_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100139_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100139_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100139_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100139_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100139_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100139', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100139_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100139');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100139', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100150
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100150" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100150';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100150', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100150_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100150_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100150_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100150_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100150_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100150_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100150_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100150_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100150_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100150', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100150_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100150');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100150', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100167
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100167" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100167';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100167', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100167_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100167_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100167_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100167_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100167_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100167_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100167_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100167_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100167_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100167', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100167_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100167');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100167', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100169
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100169" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100169';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100169', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100169_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100169_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100169_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100169_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100169_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100169_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100169_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100169_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100169_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100169', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100169_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100169');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100169', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100172
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100172" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100172';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100172', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100172_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100172_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100172_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100172_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100172_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100172_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100172_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100172_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100172_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100172', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100172_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100172');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100172', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100173
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100173" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100173';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100173', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100173_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100173_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100173_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100173_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100173_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100173_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100173_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100173_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100173_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100173', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100173_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100173');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100173', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100174
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100174" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100174';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100174', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100174_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100174_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100174_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100174_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100174_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100174_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100174_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100174_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100174_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100174', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100174_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100174');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100174', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100176
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100176" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100176';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100176', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100176_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100176_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100176_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100176_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100176_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100176_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100176_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100176_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100176_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100176', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100176_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100176');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100176', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100177
prompt ============================================
prompt
CREATE OR REPLACE Procedure p_Fact_Hour_Report_100177(p_Logtime In Varchar2) Is
  v_Errposition  Varchar2(100); --λ��
  v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
  v_Errsource    Varchar2(100); --��Դ
  v_Errcode      Varchar2(200); --���ݿ�������
  v_Inputdate    Number := 0;
Begin
  --p_Errcode := 7100;
  /*Select Trunc(Sysdate) -
       Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  Into v_Inputdate
  From Dual;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  v_Errsource := 'p_Fact_Hour_Report_100177';
  Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100177', v_Inputdate);
  ------------------------------ִ����־��ʼ----------------------------------------------
  v_Errposition := '1-1';
  Delete From Fact_100177_Hour_Report t;
  Commit;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  v_Errposition := '1-2';
  --����Сʱָ������
  Insert Into Fact_100177_Hour_Report
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           Case
             When t.Datatype = '1' Then
              '�����û���'
             Else
              '�����豸��'
           End Indexid,
           'Сʱָ��' Indtype,
           Sum(t.Newcount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_100177_General_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid, t.Datatype
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           Case
             When t.Datatype = '1' Then
              '��Ծ�û���'
             Else
              '��Ծ�豸��'
           End Indexid,
           'Сʱָ��' Indtype,
           Sum(t.Conncount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_100177_General_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid, t.Datatype
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           Case
             When t.Datatype = '1' Then
              '�����û���'
             Else
              '�����豸��'
           End Indexid,
           'Сʱָ��' Indtype,
           Sum(t.Paycount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_100177_General_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid, t.Datatype
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           '���ѽ��' Indexid,
           'Сʱָ��' Indtype,
           Sum(t.Payamount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_100177_General_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
       And t.Datatype = '1'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid

    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           'ʧ�ܸ����û���' Indexid,
           '��ָ��' Indtype,
           Sum(t.Payfailcount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_100177_Order_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
       And t.Datatype = '1'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           '�����ɹ���' Indexid,
           '��ָ��' Indtype,
           Sum(t.Paysuccnum) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_100177_Order_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
       And t.Datatype = '1'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           '����ʧ����' Indexid,
           '��ָ��' Indtype,
           Sum(t.Payfailnum) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_100177_Order_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
       And t.Datatype = '1'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid;
  Commit;

  ------------------------------ִ����־����----------------------------------------------
  Pkg_Log.Sp_Run_Log_End(v_Errsource, '100177', v_Inputdate);
  ------------------------------ִ����־����----------------------------------------------
Exception
  When Others Then
    Rollback;
    --p_Errcode      := 8100;
    --p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
    v_Errlocalinfo := 'TABLE NAME=Fact_100177_Hour_Report';
    v_Errcode      := Substr(Sqlerrm, 1, 200);
    Pkg_Log.Sp_Error_Log(v_Errcode,
                         v_Errsource,
                         v_Errlocalinfo,
                         v_Errposition,
                         '100177');
    Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100177', v_Inputdate);
    ------------------------------�쳣����----------------------------------------------
End;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100178
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100178" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100178';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100178', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100178_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100178_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100178_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100178_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100178_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100178_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100178_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100178_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100178_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100178', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100178_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100178');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100178', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100179
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100179" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100179';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100179', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100179_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100179_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100179_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100179_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100179_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100179_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100179_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100179_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100179_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100179', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100179_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100179');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100179', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100181
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100181" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100181';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100181', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100181_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100181_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100181_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100181_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100181_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100181_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100181_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100181_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100181_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100181', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100181_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100181');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100181', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100190
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100190" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100190';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100190', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100190_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100190_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100190_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100190_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100190_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100190_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100190_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100190_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100190_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100190', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100190_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100190');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100190', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100192
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100192" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100192';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100192', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100192_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100192_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100192_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100192_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100192_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100192_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100192_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100192_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100192_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100192', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100192_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100192');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100192', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100193
prompt ============================================
prompt
CREATE OR REPLACE Procedure p_Fact_Hour_Report_100193(p_Logtime In Varchar2) Is
  v_Errposition  Varchar2(100); --λ��
  v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
  v_Errsource    Varchar2(100); --��Դ
  v_Errcode      Varchar2(200); --���ݿ�������
  v_Inputdate    Number := 0;
Begin
  --p_Errcode := 7100;
  /*Select Trunc(Sysdate) -
       Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  Into v_Inputdate
  From Dual;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  v_Errsource := 'p_Fact_Hour_Report_100193';
  Pkg_Log.Sp_Run_Log_Start(v_Errsource, '100193', v_Inputdate);
  ------------------------------ִ����־��ʼ----------------------------------------------
  v_Errposition := '1-1';
  Delete From Fact_100193_Hour_Report t;
  Commit;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  v_Errposition := '1-2';
  --����Сʱָ������
  Insert Into Fact_100193_Hour_Report
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           Case
             When t.Datatype = '1' Then
              '�����û���'
             Else
              '�����豸��'
           End Indexid,
           'Сʱָ��' Indtype,
           Sum(t.Newcount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_100193_General_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid, t.Datatype
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           Case
             When t.Datatype = '1' Then
              '��Ծ�û���'
             Else
              '��Ծ�豸��'
           End Indexid,
           'Сʱָ��' Indtype,
           Sum(t.Conncount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_100193_General_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid, t.Datatype
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           Case
             When t.Datatype = '1' Then
              '�����û���'
             Else
              '�����豸��'
           End Indexid,
           'Сʱָ��' Indtype,
           Sum(t.Paycount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_100193_General_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid, t.Datatype
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           '���ѽ��' Indexid,
           'Сʱָ��' Indtype,
           Sum(t.Payamount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_100193_General_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
       And t.Datatype = '1'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid

    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           'ʧ�ܸ����û���' Indexid,
           '��ָ��' Indtype,
           Sum(t.Payfailcount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_100193_Order_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
       And t.Datatype = '1'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           '�����ɹ���' Indexid,
           '��ָ��' Indtype,
           Sum(t.Paysuccnum) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_100193_Order_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
       And t.Datatype = '1'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           '����ʧ����' Indexid,
           '��ָ��' Indtype,
           Sum(t.Payfailnum) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_100193_Order_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
       And t.Datatype = '1'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid;
  Commit;

  ------------------------------ִ����־����----------------------------------------------
  Pkg_Log.Sp_Run_Log_End(v_Errsource, '100193', v_Inputdate);
  ------------------------------ִ����־����----------------------------------------------
Exception
  When Others Then
    Rollback;
    --p_Errcode      := 8100;
    --p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
    v_Errlocalinfo := 'TABLE NAME=Fact_100193_Hour_Report';
    v_Errcode      := Substr(Sqlerrm, 1, 200);
    Pkg_Log.Sp_Error_Log(v_Errcode,
                         v_Errsource,
                         v_Errlocalinfo,
                         v_Errposition,
                         '100193');
    Pkg_Log.Sp_Run_Log_Error(v_Errsource, '100193', v_Inputdate);
    ------------------------------�쳣����----------------------------------------------
End;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100194
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100194" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100194';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100194', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100194_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100194_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100194_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100194_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100194_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100194_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100194_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100194_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100194_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100194', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100194_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100194');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100194', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100196
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100196" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100196';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100196', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100196_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100196_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100196_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100196_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100196_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100196_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100196_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100196_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100196_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100196', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100196_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100196');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100196', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100197
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100197" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100197';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100197_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100197_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100197_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100197_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100197_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100197_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100197_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100197_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100197_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100197_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100197');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100198
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100198" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100198';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100198', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100198_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100198_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100198_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100198_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100198_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100198_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100198_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100198_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100198_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100198', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100198_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100198');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100198', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100201
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100201" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100201';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100201', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100201_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100201_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100201_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100201_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100201_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100201_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100201_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100201_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100201_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100201', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100201_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100201');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100201', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100202
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100202" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100202';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100202', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100202_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100202_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100202_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100202_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100202_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100202_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100202_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100202_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100202_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100202', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100202_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100202');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100202', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100209
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100209" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100209';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100209', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100209_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100209_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100209_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100209_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100209_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100209_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100209_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100209_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100209_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100209', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100209_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100209');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100209', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100228
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100228" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100228';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100228', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100228_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100228_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100228_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100228_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100228_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100228_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100228_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100228_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100228_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100228', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100228_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100228');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100228', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100230
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100230" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100230';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100230', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100230_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100230_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100230_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100230_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100230_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100230_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100230_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100230_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100230_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100230', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100230_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100230');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100230', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100231
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100231" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100231';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100231', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100231_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100231_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100231_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100231_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100231_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100231_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100231_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100231_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100231_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100231', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100231_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100231');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100231', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_100241
prompt ============================================
prompt
CREATE OR REPLACE PROCEDURE "P_FACT_HOUR_REPORT_100241" (P_LOGTIME IN VARCHAR2) IS
  V_ERRPOSITION  VARCHAR2(100); --λ��
  V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
  V_ERRSOURCE    VARCHAR2(100); --��Դ
  V_ERRCODE      VARCHAR2(200); --���ݿ�������
  V_INPUTDATE    NUMBER := 0;
BEGIN
  --P_ERRCODE := 7100;
  /*SELECT TRUNC(SYSDATE) -
       TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  INTO V_INPUTDATE
  FROM DUAL;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRSOURCE := 'P_FACT_HOUR_REPORT_100241';
  PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100241', V_INPUTDATE);
  ------------------------------ִ����־��ʼ----------------------------------------------
  V_ERRPOSITION := '1-1';
  DELETE FROM FACT_100241_HOUR_REPORT T;
  COMMIT;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  V_ERRPOSITION := '1-2';
  --����Сʱָ������
  INSERT INTO FACT_100241_HOUR_REPORT
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.NEWCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100241_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '��Ծ�û���'
             ELSE
              '��Ծ�豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.CONNCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100241_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           CASE
             WHEN T.DATATYPE = '1' THEN
              '�����û���'
             ELSE
              '�����豸��'
           END INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100241_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '���ѽ��' INDEXID,
           'Сʱָ��' INDTYPE,
           SUM(T.PAYAMOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100241_GENERAL_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID

    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           'ʧ�ܸ����û���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILCOUNT) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100241_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '�����ɹ���' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYSUCCNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100241_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
    UNION ALL
    SELECT T.STATDATE,
           T.APPID,
           T.CHANNELID,
           T.SERVERID,
           '����ʧ����' INDEXID,
           '��ָ��' INDTYPE,
           SUM(T.PAYFAILNUM) RPT_DATA,
           SYSDATE,
           V_ERRSOURCE
      FROM FACT_100241_ORDER_HOUR T
     WHERE T.STATDATE LIKE
           TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') || '%'
       AND T.DATATYPE = '1'
     GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
  COMMIT;

  ------------------------------ִ����־����----------------------------------------------
  PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100241', V_INPUTDATE);
  ------------------------------ִ����־����----------------------------------------------
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    --P_ERRCODE      := 8100;
    --P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
    V_ERRLOCALINFO := 'TABLE NAME=FACT_100241_HOUR_REPORT';
    V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
    PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                         V_ERRSOURCE,
                         V_ERRLOCALINFO,
                         V_ERRPOSITION,
                         '100241');
    PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100241', V_INPUTDATE);
    ------------------------------�쳣����----------------------------------------------
END;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_20002
prompt ===========================================
prompt
CREATE OR REPLACE Procedure p_Fact_Hour_Report_20002(p_Logtime In Varchar2) Is
  v_Errposition  Varchar2(100); --λ��
  v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
  v_Errsource    Varchar2(100); --��Դ
  v_Errcode      Varchar2(200); --���ݿ�������
  v_Inputdate    Number := 0;
Begin
  --p_Errcode := 7100;
  /*Select Trunc(Sysdate) -
       Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  Into v_Inputdate
  From Dual;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  v_Errsource := 'p_Fact_Hour_Report_20002';
  Pkg_Log.Sp_Run_Log_Start(v_Errsource, '20002', v_Inputdate);
  ------------------------------ִ����־��ʼ----------------------------------------------
  v_Errposition := '1-1';
  Delete From Fact_20002_Hour_Report t;
  Commit;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  v_Errposition := '1-2';
  --����Сʱָ������
  Insert Into Fact_20002_Hour_Report
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           Case
             When t.Datatype = '1' Then
              '�����û���'
             Else
              '�����豸��'
           End Indexid,
           'Сʱָ��' Indtype,
           Sum(t.Newcount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_20002_General_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid, t.Datatype
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           Case
             When t.Datatype = '1' Then
              '��Ծ�û���'
             Else
              '��Ծ�豸��'
           End Indexid,
           'Сʱָ��' Indtype,
           Sum(t.Conncount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_20002_General_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid, t.Datatype
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           Case
             When t.Datatype = '1' Then
              '�����û���'
             Else
              '�����豸��'
           End Indexid,
           'Сʱָ��' Indtype,
           Sum(t.Paycount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_20002_General_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid, t.Datatype
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           '���ѽ��' Indexid,
           'Сʱָ��' Indtype,
           Sum(t.Payamount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_20002_General_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
       And t.Datatype = '1'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid

    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           'ʧ�ܸ����û���' Indexid,
           '��ָ��' Indtype,
           Sum(t.Payfailcount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_20002_Order_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
       And t.Datatype = '1'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           '�����ɹ���' Indexid,
           '��ָ��' Indtype,
           Sum(t.Paysuccnum) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_20002_Order_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
       And t.Datatype = '1'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           '����ʧ����' Indexid,
           '��ָ��' Indtype,
           Sum(t.Payfailnum) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_20002_Order_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
       And t.Datatype = '1'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid;
  Commit;

  ------------------------------ִ����־����----------------------------------------------
  Pkg_Log.Sp_Run_Log_End(v_Errsource, '20002', v_Inputdate);
  ------------------------------ִ����־����----------------------------------------------
Exception
  When Others Then
    Rollback;
    --p_Errcode      := 8100;
    --p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
    v_Errlocalinfo := 'TABLE NAME=Fact_20002_Hour_Report';
    v_Errcode      := Substr(Sqlerrm, 1, 200);
    Pkg_Log.Sp_Error_Log(v_Errcode,
                         v_Errsource,
                         v_Errlocalinfo,
                         v_Errposition,
                         '20002');
    Pkg_Log.Sp_Run_Log_Error(v_Errsource, '20002', v_Inputdate);
    ------------------------------�쳣����----------------------------------------------
End;
/

prompt
prompt Creating procedure P_FACT_HOUR_REPORT_DEMO
prompt ==========================================
prompt
CREATE OR REPLACE Procedure p_Fact_Hour_Report_demo(p_Logtime In Varchar2) Is
  v_Errposition  Varchar2(100); --λ��
  v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
  v_Errsource    Varchar2(100); --��Դ
  v_Errcode      Varchar2(200); --���ݿ�������
  v_Inputdate    Number := 0;
Begin
  --p_Errcode := 7100;
  /*Select Trunc(Sysdate) -
       Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
  Into v_Inputdate
  From Dual;*/

  ------------------------------ִ����־��ʼ----------------------------------------------
  v_Errsource := 'p_Fact_Hour_Report_demo';
  Pkg_Log.Sp_Run_Log_Start(v_Errsource, 'demo', v_Inputdate);
  ------------------------------ִ����־��ʼ----------------------------------------------
  v_Errposition := '1-1';
  Delete From Fact_demo_Hour_Report t;
  Commit;

  --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,ʧ�ܸ����û���,�����ɹ���,����ʧ������
  v_Errposition := '1-2';
  --����Сʱָ������
  Insert Into Fact_demo_Hour_Report
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           Case
             When t.Datatype = '1' Then
              '�����û���'
             Else
              '�����豸��'
           End Indexid,
           'Сʱָ��' Indtype,
           Sum(t.Newcount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_demo_General_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid, t.Datatype
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           Case
             When t.Datatype = '1' Then
              '��Ծ�û���'
             Else
              '��Ծ�豸��'
           End Indexid,
           'Сʱָ��' Indtype,
           Sum(t.Conncount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_demo_General_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid, t.Datatype
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           Case
             When t.Datatype = '1' Then
              '�����û���'
             Else
              '�����豸��'
           End Indexid,
           'Сʱָ��' Indtype,
           Sum(t.Paycount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_demo_General_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid, t.Datatype
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           '���ѽ��' Indexid,
           'Сʱָ��' Indtype,
           Sum(t.Payamount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_demo_General_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
       And t.Datatype = '1'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid

    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           'ʧ�ܸ����û���' Indexid,
           '��ָ��' Indtype,
           Sum(t.Payfailcount) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_demo_Order_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
       And t.Datatype = '1'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           '�����ɹ���' Indexid,
           '��ָ��' Indtype,
           Sum(t.Paysuccnum) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_demo_Order_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
       And t.Datatype = '1'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid
    Union All
    Select t.Statdate,
           t.Appid,
           t.Channelid,
           t.Serverid,
           '����ʧ����' Indexid,
           '��ָ��' Indtype,
           Sum(t.Payfailnum) Rpt_Data,
           Sysdate,
           v_Errsource
      From Fact_demo_Order_Hour t
     Where t.Statdate Like
           To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') || '%'
       And t.Datatype = '1'
     Group By t.Statdate, t.Appid, t.Channelid, t.Serverid;
  Commit;

  ------------------------------ִ����־����----------------------------------------------
  Pkg_Log.Sp_Run_Log_End(v_Errsource, 'demo', v_Inputdate);
  ------------------------------ִ����־����----------------------------------------------
Exception
  When Others Then
    Rollback;
    --p_Errcode      := 8100;
    --p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
    v_Errlocalinfo := 'TABLE NAME=Fact_demo_Hour_Report';
    v_Errcode      := Substr(Sqlerrm, 1, 200);
    Pkg_Log.Sp_Error_Log(v_Errcode,
                         v_Errsource,
                         v_Errlocalinfo,
                         v_Errposition,
                         'demo');
    Pkg_Log.Sp_Run_Log_Error(v_Errsource, 'demo', v_Inputdate);
    ------------------------------�쳣����----------------------------------------------
End;
/

prompt
prompt Creating procedure P_RANDOM_INS
prompt ===============================
prompt
CREATE OR REPLACE Procedure p_Random_Ins(p_Date_Des   Varchar2,
                                              p_Start_Time Varchar2,
                                              p_End_Time   Varchar2,
                                              p_Flag       Varchar2) Is
  --p_Start_Time��p_End_Time  ��ʽ��2014-09-20 2014-10-04   �¸�ʽ2014-09  2014-10
  --p_date_des��ʽ �� 2014-09-28 �� ÿ����һ������ 2014-09-29 �� 2014-09
  --p_flag��ʽ  ��  D �� W �� M
  --------��
  Cursor Cur_Date Is
    Select t.Day_Des
      From Dim_Day t
     Where t.Day_Des Between p_Start_Time And p_End_Time
       And t.Day_Des <> p_Date_Des;
  Cursor Cur_Tab Is
    Select t.Table_Name
      From User_Tables t
     Where t.Table_Name Like '%FACT_DEMO%'
       And t.Table_Name Not Like '%WEEK%'
			 And t.Table_Name Not Like '%MONTH%';
  --------��
  Cursor Cur_Date_Week Is
    Select t.Day_Des
      From Dim_Day t
     Where t.Day_Des Between p_Start_Time And p_End_Time
       And t.Week_Day_Cal = 1
       And t.Day_Des <> p_Date_Des;
  Cursor Cur_Week_Tab Is
    Select t.Table_Name
      From User_Tables t
     Where t.Table_Name Like '%FACT_DEMO%'
       And t.Table_Name Like '%WEEK%';
  --------��
  Cursor Cur_Date_Month Is
    Select Distinct Substr(t.Monthid, 1, 4) || '-' ||
                    Substr(t.Monthid, 5, 6) Day_Des
      From Dim_Day t
     Where Substr(t.Monthid, 1, 4) || '-' || Substr(t.Monthid, 5, 6) Between
           p_Start_Time And p_End_Time
       And Substr(t.Monthid, 1, 4) || '-' || Substr(t.Monthid, 5, 6) <>
           p_Date_Des;
  Cursor Cur_Month_Tab Is
    Select t.Table_Name
      From User_Tables t
     Where t.Table_Name Like '%FACT_DEMO%'
       And t.Table_Name Like '%MONTH%';
  v_Sql0 Varchar2(4000);
  v_Sql  Varchar2(4000);
  v_Sql1 Varchar2(4000);
  v_Sql2 Varchar2(4000);
  v_Sql3 Varchar2(4000);
Begin
  Dbms_Output.Put_Line(p_Flag);
  If p_Flag = 'D' Then
    --����ģ���ĳһ�������������ɶ������ݲ���ģ���
  
    For Ct In Cur_Tab Loop
    
      v_Sql0 := 'delete from ' || Ct.Table_Name;
    
      Execute Immediate v_Sql0;
      Commit;
    
      For Cd In Cur_Date Loop
      
        v_Sql := 'insert into ' || Ct.Table_Name || ' select * from ' ||
                 Replace(Ct.Table_Name, 'DEMO', '100177') ||
                 ' where substr(statdate,1,10)=''' || p_Date_Des || '''';
      
        --Dbms_Output.Put_Line(v_Sql);
        Execute Immediate v_Sql;
        v_Sql1 := 'update ' || Ct.Table_Name ||
                 
                  ' set statdate=replace(statdate,substr(statdate,1,10),''' ||
                  Cd.Day_Des || ''') where substr(statdate,1,10)=''' ||
                  p_Date_Des || '''';
        --Dbms_Output.Put_Line(Cd.Day_Des);
        --Dbms_Output.Put_Line(v_Sql1);
        Execute Immediate v_Sql1;
        For c In (Select t.Table_Name,
                         t.Column_Name,
                         t.Data_Type,
                         t.Column_Id
                    From User_Tab_Columns t
                   Where t.Table_Name = Ct.Table_Name
                     And t.Data_Type = 'NUMBER'
                     And t.Column_Name Not Like '%DAY%'
                     And t.Column_Name Not Like '%WEEK%'
                     And t.Column_Name Not Like '%PAYFROMREG%'
                     And t.Column_Name Not Like '%LEVEL%') Loop
        
          v_Sql2 := 'update ' || Ct.Table_Name || ' set ' || c.
                    Column_Name || '= trunc(dbms_random.value(1,2)*' ||
                    c.Column_Name || ') where substr(statdate,1,10)=''' ||
                    Cd.Day_Des || '''';
          --Dbms_Output.Put_Line(v_Sql2);
          Execute Immediate v_Sql2;
        End Loop;
      
      End Loop;
    
    End Loop;
    Commit;
    For Ct In Cur_Tab Loop
      v_Sql3 := 'insert into ' || Ct.Table_Name || ' select * from ' ||
                Replace(Ct.Table_Name, 'DEMO', '100177') ||
                ' where substr(statdate,1,10)=''' || p_Date_Des || '''';
    
      --Dbms_Output.Put_Line(v_Sql);
      Execute Immediate v_Sql3;
    End Loop;
    Commit;
  End If;
  If p_Flag = 'W' Then
    For Ct In Cur_Week_Tab Loop
    
      v_Sql0 := 'delete from ' || Ct.Table_Name;
    
      Execute Immediate v_Sql0;
      Commit;
    
      For Cd In Cur_Date_Week Loop
      
        v_Sql := 'insert into ' || Ct.Table_Name || ' select * from ' ||
                 Replace(Ct.Table_Name, 'DEMO', '100177') ||
                 ' where substr(statdate,1,10)=''' || p_Date_Des || '''';
      
        --Dbms_Output.Put_Line(v_Sql);
        Execute Immediate v_Sql;
        v_Sql1 := 'update ' || Ct.Table_Name ||
                 
                  ' set statdate=replace(statdate,substr(statdate,1,10),''' ||
                  Cd.Day_Des || ''') where substr(statdate,1,10)=''' ||
                  p_Date_Des || '''';
        --Dbms_Output.Put_Line(Cd.Day_Des);
        --Dbms_Output.Put_Line(v_Sql1);
        Execute Immediate v_Sql1;
        For c In (Select t.Table_Name,
                         t.Column_Name,
                         t.Data_Type,
                         t.Column_Id
                    From User_Tab_Columns t
                   Where t.Table_Name = Ct.Table_Name
                     And t.Data_Type = 'NUMBER'
                     And t.Column_Name Not Like '%DAY%'
                     And t.Column_Name Not Like '%WEEK%'
                     And t.Column_Name Not Like '%PAYFROMREG%'
                     And t.Column_Name Not Like '%LEVEL%') Loop
        
          v_Sql2 := 'update ' || Ct.Table_Name || ' set ' || c.
                    Column_Name || '= trunc(dbms_random.value(1,2)*' ||
                    c.Column_Name || ') where substr(statdate,1,10)=''' ||
                    Cd.Day_Des || '''';
          --Dbms_Output.Put_Line(v_Sql2);
          Execute Immediate v_Sql2;
        End Loop;
      
      End Loop;
    
    End Loop;
    Commit;
    For Ct In Cur_Week_Tab Loop
      v_Sql3 := 'insert into ' || Ct.Table_Name || ' select * from ' ||
                Replace(Ct.Table_Name, 'DEMO', '100177') ||
                ' where substr(statdate,1,10)=''' || p_Date_Des || '''';
      --Dbms_Output.Put_Line(v_Sql);
      Execute Immediate v_Sql3;
    End Loop;
    Commit;
  End If;

  If p_Flag = 'M' Then
    For Ct In Cur_Month_Tab Loop
    
      v_Sql0 := 'delete from ' || Ct.Table_Name;
    
      Execute Immediate v_Sql0;
      Commit;
    
      For Cd In Cur_Date_Month Loop
      
        v_Sql := 'insert into ' || Ct.Table_Name || ' select * from ' ||
                 Replace(Ct.Table_Name, 'DEMO', '100177') ||
                 ' where statdate=''' || p_Date_Des || '''';
      
        --Dbms_Output.Put_Line(v_Sql);
        Execute Immediate v_Sql;
        v_Sql1 := 'update ' || Ct.Table_Name ||
                 
                  ' set statdate=''' || Cd.Day_Des ||
                  ''' where statdate=''' || p_Date_Des || '''';
        --Dbms_Output.Put_Line(Cd.Day_Des);
        --Dbms_Output.Put_Line(v_Sql1);
        Execute Immediate v_Sql1;
        For c In (Select t.Table_Name,
                         t.Column_Name,
                         t.Data_Type,
                         t.Column_Id
                    From User_Tab_Columns t
                   Where t.Table_Name = Ct.Table_Name
                     And t.Data_Type = 'NUMBER'
                     And t.Column_Name Not Like '%DAY%'
                     And t.Column_Name Not Like '%WEEK%'
                     And t.Column_Name Not Like '%PAYFROMREG%'
                     And t.Column_Name Not Like '%LEVEL%') Loop
        
          v_Sql2 := 'update ' || Ct.Table_Name || ' set ' || c.
                    Column_Name || '= trunc(dbms_random.value(1,2)*' ||
                    c.Column_Name || ') where statdate=''' || Cd.Day_Des || '''';
          --Dbms_Output.Put_Line(v_Sql2);
          Execute Immediate v_Sql2;
        End Loop;
      
      End Loop;
    
    End Loop;
    Commit;
    For Ct In Cur_Month_Tab Loop
      v_Sql3 := 'insert into ' || Ct.Table_Name || ' select * from ' ||
                Replace(Ct.Table_Name, 'DEMO', '100177') ||
                ' where statdate=''' || p_Date_Des || '''';
      --Dbms_Output.Put_Line(v_Sql);
      Execute Immediate v_Sql3;
    End Loop;
    Commit;
  End If;
End p_Random_Ins;
/

prompt
prompt Creating procedure P_INS_DATA
prompt =============================
prompt
CREATE OR REPLACE Procedure p_Ins_Data Is
  v_date_des Varchar2(10);
	v_start_time Varchar2(10);
	v_end_time Varchar2(10);
	v_flag Varchar2(10);
Begin
  v_date_des:='2014-09-28';
	v_start_time:=to_char(Sysdate-60,'yyyy-mm-dd');
	v_end_time:=to_char(Sysdate-1,'yyyy-mm-dd');
	v_flag:='D';
	--dbms_output.put_line(v_start_time||'----------------------------'||v_end_time);
  p_Random_Ins(v_date_des,v_start_time,v_end_time,v_flag);
	
	v_date_des:='2014-09-29';
	v_start_time:=to_char(Sysdate-60,'yyyy-mm-dd');
	v_end_time:=to_char(Sysdate-1,'yyyy-mm-dd');
	v_flag:='W';
	p_Random_Ins(v_date_des,v_start_time,v_end_time,v_flag);
	
	v_date_des:='2014-09';
	v_start_time:=to_char(Sysdate-60,'yyyy-mm');
	v_end_time:=to_char(Sysdate-1,'yyyy-mm');
	v_flag:='M';
	--dbms_output.put_line(v_start_time||'----------------------------'||v_end_time);
	p_Random_Ins(v_date_des,v_start_time,v_end_time,v_flag);
End p_Ins_Data;
/

prompt
prompt Creating procedure SP_A_TEST
prompt ============================
prompt
create or replace procedure sp_a_test
as
i number;
begin
  delete from a_test t;
  commit;
  insert into a_test(a) values('ssss');
  commit;
  select count(*) into i from a_test;
end;
/

prompt
prompt Creating procedure SP_DO_NOTHING
prompt ================================
prompt
create or replace procedure sp_do_nothing
(table_name varchar2,pardate char,o_num out number,o_str out VARCHAR2)
as
begin
  o_num:=7100;
    o_str:= 'ok';
  end;
/

prompt
prompt Creating package body PKG_OPEN_TO_BI
prompt ====================================
prompt
CREATE OR REPLACE Package Body Pkg_Open_To_Bi Is
  Procedure p_All Is
  Begin
    /*Sgzs_Sdk_Newuser_1149_To_Nu;
    Sgzs_Sdk_Newuser_1161_To_Nu;
    Sgzs_Pdt_Sdk_Conn_1149_To_Conn;
    Sgzs_Pdt_Sdk_Conn_1161_To_Conn;*/
		/*p_inssss;*/
  /*  p_His_Ins;*/
    p_New_Ins;
  End;
  Procedure Sgzs_Sdk_Newuser_1149_To_Nu Is
    Cursor Cur Is
      Select f_Unix_To_Oracle(t.Firstlogintime),
             t.Gameid,
             t.Subcoopid,
             t.Version,
             0,
             0,
             '',
             t.Uuid
        From Sgzs_Sdk_Newuser_1149@Jtstatic_243 t;
    Type Rec Is Table Of t_100138_Nu%Rowtype;
    Recs           Rec;
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
  Begin
    v_Errsource := 'Pkg_Open_To_Bi.Sgzs_Sdk_Newuser_1149_To_Nu';
    Open Cur;
    While (True) Loop
      Fetch Cur Bulk Collect
        Into Recs Limit 5000;
      Forall i In 1 .. Recs.Count
        Insert /*+APPEND */
        Into t_100138_Nu
        Values Recs
          (i);
      Commit;
      Exit When Cur%Notfound;
    End Loop;
    Close Cur;
  Exception
    When Others Then
      Rollback;
      --v_Errorcode      := 8100;
      --v_Errorstr       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      v_Errlocalinfo := 'TABLE NAME=T_100138_CONN_MAC';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100138');
  End;

  Procedure Sgzs_Sdk_Newuser_1161_To_Nu Is
    Cursor Cur Is
      Select f_Unix_To_Oracle(t.Firstlogintime),
             t.Gameid,
             t.Subcoopid,
             t.Version,
             0,
             0,
             '',
             d.Unique_Identification
        From (Select * From Tmp_Uuid_Mapping Tt Where Tt.Sourceid = 100138) d
       Inner Join Sgzs_Sdk_Newuser_1161@Jtstatic_243 t
          On d.Uuid = t.Uuid;
    Type Rec Is Table Of t_100138_Nu%Rowtype;
    Recs           Rec;
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
  Begin
    v_Errsource := 'Pkg_Open_To_Bi.Sgzs_Sdk_Newuser_1161_To_Nu';
    Open Cur;
    While (True) Loop
      Fetch Cur Bulk Collect
        Into Recs Limit 5000;
      Forall i In 1 .. Recs.Count
        Insert /*+APPEND */
        Into t_100138_Nu
        Values Recs
          (i);
      Commit;
      Exit When Cur%Notfound;
    End Loop;
    Close Cur;
  Exception
    When Others Then
      Rollback;
      --v_Errorcode      := 8100;
      -- v_Errorstr       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      v_Errlocalinfo := 'TABLE NAME=T_100138_CONN_MAC';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100138');
  End;

  Procedure Sgzs_Pdt_Sdk_Conn_1149_To_Conn Is
    Cursor Cur Is
      Select t.Thedate,
             t.Gameid,
             t.Originalcoopid,
             t.Version,
             0,
             0,
             '',
             '',
             t.Uuid,
             t.Newdate,
             0,
						 t.Newdate
        From Sgzs_Pdt_Sdk_Conn_1149@Jtstatic_243 t;
    Type Rec Is Table Of t_100138_Conn%Rowtype;
    Recs           Rec;
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
  Begin
    v_Errsource := 'Pkg_Open_To_Bi.Sgzs_Pdt_Sdk_Conn_1149_To_Conn';
    Open Cur;
    While (True) Loop
      Fetch Cur Bulk Collect
        Into Recs Limit 5000;
      Forall i In 1 .. Recs.Count
        Insert /*+APPEND */
        Into t_100138_Conn
        Values Recs
          (i);
      Commit;
      Exit When Cur%Notfound;
    End Loop;
    Close Cur;
  Exception
    When Others Then
      Rollback;
      --v_Errorcode      := 8100;
      --v_Errorstr       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      v_Errlocalinfo := 'TABLE NAME=T_100138_CONN_MAC';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100138');
  End;

  Procedure Sgzs_Pdt_Sdk_Conn_1161_To_Conn Is
    Cursor Cur Is
      Select t.Thedate,
             t.Gameid,
             t.Originalcoopid,
             t.Version,
             0,
             0,
             '',
             '',
             d.Unique_Identification,
             t.Newdate,
             0,
						 t.Newdate
        From (Select * From Tmp_Uuid_Mapping Tt Where Tt.Sourceid = 100138) d
       Inner Join Sgzs_Pdt_Sdk_Conn_1161@Jtstatic_243 t
          On d.Uuid = t.Uuid;
    Type Rec Is Table Of t_100138_Conn%Rowtype;
    Recs           Rec;
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
  Begin
    v_Errsource := 'Pkg_Open_To_Bi.Sgzs_Pdt_Sdk_Conn_1161_To_Conn';
    Open Cur;
    While (True) Loop
      Fetch Cur Bulk Collect
        Into Recs Limit 5000;
      Forall i In 1 .. Recs.Count
        Insert /*+APPEND */
        Into t_100138_Conn
        Values Recs
          (i);
      Commit;
      Exit When Cur%Notfound;
    End Loop;
    Close Cur;
  Exception
    When Others Then
      Rollback;
      -- v_Errorcode      := 8100;
      --v_Errorstr       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      v_Errlocalinfo := 'TABLE NAME=T_100138_CONN_MAC';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100138');
  End;

  Procedure p_His_Ins Is
    Cursor Cur Is
      Select *
        From Dim_Day t
       Where t.Day_Des Between '2014-11-06' And '2014-12-03'
			 Order By t.dayid;
    v_Errorcode    Number;
    v_Errorstr     Varchar2(2000);
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
  Begin
    v_Errsource := 'Pkg_Open_To_Bi.p_His_Ins';
    For c In Cur Loop
      Pkg_Base_Data_100138.Sp_Conn_Act(c.Day_Des, v_Errorcode, v_Errorstr);
      Pkg_Base_Data_100138.Sp_Lost(c.Day_Des, v_Errorcode, v_Errorstr);
      Pkg_Fact_100138.p_All(c.Day_Des, v_Errorcode, v_Errorstr);
    End Loop;
  Exception
    When Others Then
      Rollback;
      v_Errorcode    := 8100;
      v_Errorstr     := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=T_100138_CONN_MAC';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100138');
  End;

  Procedure p_New_Ins Is
    Cursor Cur Is
      Select *
        From Dim_Day t
       Where t.Day_Des Between '2014-12-04' And '2014-12-13'
			 Order By t.dayid;
    v_Errorcode    Number;
    v_Errorstr     Varchar2(2000);
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
  Begin
    v_Errsource := 'Pkg_Open_To_Bi.p_New_Ins';
    For c In Cur Loop
      Pkg_Base_Data_100138.Sp_All(c.Day_Des, v_Errorcode, v_Errorstr);
      Pkg_Fact_100138.p_All(c.Day_Des, v_Errorcode, v_Errorstr);
    End Loop;
  Exception
    When Others Then
      Rollback;
      v_Errorcode    := 8100;
      v_Errorstr     := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=T_100138_CONN_MAC';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100138');
  End;
 	Procedure p_inssss Is
		v_Errorcode    Number;
    v_Errorstr     Varchar2(2000);
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
		Begin
			v_Errsource := 'Pkg_Open_To_Bi.p_inssss';
			Insert Into t_100138_nu_allserver
			Select 
			  t.thedate,t.gameid,t.channelid,t.gameversion,t.rolelevel,t.position,t.accountid
			 From t_100138_nu t;
			Commit;
			Update t_100138_conn t Set t.regdate_as=t.regdate;
			Commit;
		
		
		
		Exception
    When Others Then
      Rollback;
      v_Errorcode    := 8100;
      v_Errorstr     := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=T_100138_CONN_MAC';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           '100138');
		End;
End Pkg_Open_To_Bi;
/

prompt
prompt Creating package body PKG_OPEN_TO_BISOURCE_100091
prompt =================================================
prompt
CREATE OR REPLACE PACKAGE BODY PKG_OPEN_TO_BISOURCE_100091 AS

  PROCEDURE PROC_OPEN_TO_BISU_100091_ALL(INPUTDATE IN NUMBER) AS
  BEGIN

    --��ȡ�˻���Ӧ��ϵ�����ݵ�����
    /*PROC_OPEN_TO_BISU_100091_MAP(INPUTDATE);*/

    --��ȡ�û��������ݵ�����
    PROC_OPEN_TO_BISU_100091_NU(INPUTDATE);

    --��ȡ�û��������ݵ�����
    PROC_OPEN_TO_BISU_100091_CONN(INPUTDATE);

    --��ȡ�û��������ݵ�����
    PROC_OPEN_TO_BISU_100091_ORDER(INPUTDATE);

    --���ر����������ݵ�BI
    PROC_LOCAL_TO_BI_100091_NU(INPUTDATE);

    --���ر����������ݵ�BI
    PROC_LOCAL_TO_BI_100091_CO_NP(INPUTDATE);

    --���ر��ظ������ݵ�BI
    PROC_LOCAL_TO_BI_100091_PAY(INPUTDATE);

  END PROC_OPEN_TO_BISU_100091_ALL;

  --��ȡ�˻���Ӧ��ϵ������
  PROCEDURE PROC_OPEN_TO_BISU_100091_MAP(INPUTDATE IN NUMBER) AS
  BEGIN
    DELETE FROM DIM_UC_OPEN_MAPPING_100091 T
     WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    INSERT INTO DIM_UC_OPEN_MAPPING_100091
      SELECT *
        FROM DIM_UC_OPEN_MAPPING T
       WHERE T.APPID = 100091
         AND T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

  END PROC_OPEN_TO_BISU_100091_MAP;

  --��ȡ�û���������
  PROCEDURE PROC_OPEN_TO_BISU_100091_NU(INPUTDATE IN NUMBER) AS
  BEGIN
    /*    DELETE FROM PPSG_SDK_NEWUSER_1149 T
     WHERE T.PID = 1149
       AND T.GAMEID = 100091
       AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    DELETE FROM PPSG_SDK_NEWUSER_1161 T
     WHERE T.PID = 1161
       AND T.GAMEID = 100091
       AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    DELETE FROM PPSG_SDK_NEWUSER_100091 T
     WHERE T.GAMEID = 100091
       AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;*/

    /*INSERT INTO PPSG_SDK_NEWUSER_1149
      SELECT T.*, F_UNIX_TO_ORACLE(T.FIRSTLOGINTIME) REG_TIME
        FROM PDT_SDK_NEWUSER@JTSTATIC_243 T
       WHERE T.PID = 1149
         AND T.GAMEID = 100091
         AND T.FIRSTLOGINTIME >=
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE))
         AND T.FIRSTLOGINTIME <
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE + 1));
    COMMIT;*/

    EXECUTE IMMEDIATE 'TRUNCATE TABLE PPSG_SDK_NEWUSER_100091';
    EXECUTE IMMEDIATE 'TRUNCATE TABLE PPSG_SDK_NEWUSER_1161';

    --1149
    INSERT INTO PPSG_SDK_NEWUSER_100091
      SELECT F_UNIX_TO_ORACLE(T.FIRSTLOGINTIME) REG_TIME,
             TO_CHAR(T.GAMEID) GAMEID,
             T.SUBCOOPID,
             T.VERSION,
             TO_CHAR(T.UUID) UUID,
             T.USERID
        FROM PDT_SDK_NEWUSER@JTSTATIC_243 T
       WHERE T.PID = 1149
         AND T.GAMEID = 100091
         AND T.FIRSTLOGINTIME >=
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE))
         AND T.FIRSTLOGINTIME <
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE + 1));
    COMMIT;

    --1161
    /*INSERT INTO PPSG_SDK_NEWUSER_1161
      SELECT T.*, F_UNIX_TO_ORACLE(T.FIRSTLOGINTIME) REG_TIME
        FROM PDT_SDK_NEWUSER@JTSTATIC_243 T
       WHERE T.PID = 1161
         AND T.GAMEID = 100091
         AND T.FIRSTLOGINTIME >=
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE))
         AND T.FIRSTLOGINTIME <
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE + 1));
    COMMIT;*/

    /*INSERT INTO PPSG_SDK_NEWUSER_100091
      SELECT T.REG_TIME,
             TO_CHAR(T.GAMEID) GAMEID,
             T.SUBCOOPID,
             T.VERSION,
             TO_CHAR(T.UUID) UUID,
             T.USERID
        FROM PPSG_SDK_NEWUSER_1149 T
       WHERE T.PID = 1149
         AND T.GAMEID = 100091
         AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;*/

    --1161+ӳ��д��
    /*INSERT INTO PPSG_SDK_NEWUSER_100091
      SELECT DISTINCT T.REG_TIME,
                      T.GAMEID,
                      T.SUBCOOPID,
                      T.VERSION,
                      NVL(M.UNIQUE_ID, T.UUID) UUID,
                      T.USERID
        FROM PPSG_SDK_NEWUSER_1161 T
        LEFT JOIN DIM_UC_OPEN_MAPPING_100091 M
          ON T.UUID = M.UUID
       WHERE T.PID = 1161
         AND T.GAMEID = 100091
         AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;*/

  END PROC_OPEN_TO_BISU_100091_NU;

  --��ȡ�û���������
  PROCEDURE PROC_OPEN_TO_BISU_100091_CONN(INPUTDATE IN NUMBER) AS
  BEGIN
    /*DELETE FROM PPSG_SDK_CONN_1149 T
     WHERE T.PID = '1149'
       AND T.GAMEID = '100091'
       AND T.THEDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    DELETE FROM PPSG_SDK_CONN_1161 T
     WHERE T.PID = '1161'
       AND T.GAMEID = '100091'
       AND T.THEDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    DELETE FROM PPSG_SDK_CONN_100091 T
     WHERE T.GAMEID = '100091'
       AND T.THEDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
    COMMIT;*/

    EXECUTE IMMEDIATE 'TRUNCATE TABLE PPSG_SDK_CONN_1161';
    EXECUTE IMMEDIATE 'TRUNCATE TABLE PPSG_SDK_CONN_100091';

    /*INSERT INTO PPSG_SDK_CONN_1149
      SELECT *
        FROM PDT_SDK_CONN@JTSTATIC_243 T
       WHERE T.PID = 1149
         AND T.GAMEID = 100091
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');
    COMMIT;*/

    --1149--ֱ��д��
    INSERT INTO PPSG_SDK_CONN_100091
      SELECT T.THEDATE,
             T.GAMEID,
             T.ORIGINALCOOPID,
             T.VERSION,
             T.UUID,
             T.USERID,
             T.NEWDATE
        FROM PDT_SDK_CONN@JTSTATIC_243 T
       WHERE T.PID = 1149
         AND T.GAMEID = 100091
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');

    --1161
    /*INSERT INTO PPSG_SDK_CONN_1161
      SELECT *
        FROM PDT_SDK_CONN@JTSTATIC_243 T
       WHERE T.PID = 1161
         AND T.GAMEID = 100091
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');
    COMMIT;*/

    /* INSERT INTO PPSG_SDK_CONN_100091
      SELECT T.THEDATE,
             T.GAMEID,
             T.ORIGINALCOOPID,
             T.VERSION,
             T.UUID,
             T.USERID,
             T.NEWDATE
        FROM PPSG_SDK_CONN_1149 T
       WHERE T.PID = 1149
         AND T.GAMEID = 100091
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');
    COMMIT;*/

    --1161+ӳ��д��
    /*INSERT INTO PPSG_SDK_CONN_100091
      SELECT DISTINCT T.THEDATE,
                      T.GAMEID,
                      T.ORIGINALCOOPID,
                      T.VERSION,
                      NVL(M.UNIQUE_ID, T.UUID) UUID,
                      T.USERID,
                      T.NEWDATE
        FROM PPSG_SDK_CONN_1161 T
        LEFT JOIN DIM_UC_OPEN_MAPPING_100091 M
          ON T.UUID = M.UUID
       WHERE T.PID = 1161
         AND T.GAMEID = 100091
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');
    COMMIT;*/

  END PROC_OPEN_TO_BISU_100091_CONN;

  --��ȡ�û���������
  PROCEDURE PROC_OPEN_TO_BISU_100091_ORDER(INPUTDATE IN NUMBER) AS
  BEGIN
    /*DELETE FROM PPSG_SDK_ORDER_100091 T
     WHERE T.APPID = '100091'
       AND T.ORDERENDTIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.ORDERENDTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;*/

    EXECUTE IMMEDIATE 'TRUNCATE TABLE PPSG_SDK_ORDER_100091';

    INSERT INTO PPSG_SDK_ORDER_100091
      SELECT *
        FROM PDT_CP_SDK_ORDER_CLEAN@JTSTATIC_243 T
       WHERE T.APPID = '100091'
         AND T.ORDERENDTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.ORDERENDTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  END PROC_OPEN_TO_BISU_100091_ORDER;

  --���ر����������ݵ�BI
  PROCEDURE PROC_LOCAL_TO_BI_100091_NU(INPUTDATE IN NUMBER) AS
  BEGIN
    DELETE FROM T_100091_NU T
     WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
       AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    DELETE FROM T_100091_NU_ALLSERVER T
     WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
       AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    INSERT /*+APPEND */
    INTO T_100091_NU NOLOGGING
      (THEDATE,
       GAMEID,
       CHANNELID,
       GAMEVERSION,
       SERVERID,
       ROLELEVEL,
       POSITION,
       ACCOUNTID)
      SELECT TRUNC(T.REG_TIME) THEDATE,
             T.GAMEID,
             T.SUBCOOPID,
             'OPEN' GAMEVERSION,
             'OPEN' SERVERID,
             NULL,
             NULL,
             T.UUID
        FROM PPSG_SDK_NEWUSER_100091 T
       WHERE T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    INSERT /*+APPEND */
    INTO T_100091_NU_ALLSERVER NOLOGGING
      (THEDATE,
       GAMEID,
       CHANNELID,
       GAMEVERSION,
       ROLELEVEL,
       POSITION,
       ACCOUNTID)
      SELECT TRUNC(T.REG_TIME) THEDATE,
             T.GAMEID,
             T.SUBCOOPID,
             'OPEN' GAMEVERSION,
             NULL,
             NULL,
             T.UUID
        FROM PPSG_SDK_NEWUSER_100091 T
       WHERE T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

  END PROC_LOCAL_TO_BI_100091_NU;

  --���ر����������ݵ�BI
  PROCEDURE PROC_LOCAL_TO_BI_100091_CO_NP(INPUTDATE IN NUMBER) AS
  BEGIN
    /*DELETE FROM T_100091_CONN_NOPAY T
     WHERE T.CONNDATE = TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD');
    COMMIT;*/

    DELETE FROM T_100091_CONN T
     WHERE T.CONNDATE = TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD');
    COMMIT;

    --���ص�BI
    INSERT /*+append*/
    /*INTO T_100091_CONN_NOPAY NOLOGGING*/
    INTO T_100091_CONN NOLOGGING
      (CONNDATE,
       GAMEID,
       CHANNELID,
       GAMEVERSION,
       SERVERID,
       ROLELEVEL,
       POSITION,
       DVID,
       ACCOUNTID,
       REGDATE,
       ISPAY,
       REGDATE_AS)
      SELECT T.THEDATE,
             T.GAMEID,
             T.ORIGINALCOOPID,
             'OPEN',
             'OPEN',
             0,
             '',
             '',
             T.UUID,
             T.NEWDATE,
             0,
             T.NEWDATE
        FROM PPSG_SDK_CONN_100091 T
       WHERE T.THEDATE = TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD');
    COMMIT;

    /*INSERT \*+APPEND *\
    INTO T_DW_100091_LOGIN NOLOGGING
      (F_LOGTIME,
       T_LOGTIME,
       APPID,
       CHANNELID,
       GAMEVERSION,
       DVID,
       ACCOUNTID,
       ACCOUNTNAME,
       ACCOUNTYPE,
       SERVERID,
       ILEVEL,
       ROLEID,
       ROLENAME,
       IPADDR)
      SELECT TO_DATE(T.THEDATE, 'YYYY-MM-DD'),
             TO_DATE(T.THEDATE, 'YYYY-MM-DD'),
             T.GAMEID,
             NVL(T.ORIGINALCOOPID, '-1') CHANNELID,
             'OPEN' GAMEVERSION,
             NULL,
             T.UUID,
             NULL,
             NULL,
             'OPEN' SERVERID,
             NULL,
             NULL,
             NULL,
             NULL
        FROM PPSG_SDK_CONN_100091 T
       WHERE T.GAMEID = 100091
         AND T.THEDATE >= TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD')
         AND T.THEDATE <
             TO_CHAR(TRUNC(SYSDATE - INPUTDATE + 1), 'YYYY-MM-DD');
    COMMIT;*/

  END PROC_LOCAL_TO_BI_100091_CO_NP;

  --���ر��ظ������ݵ�BI
  PROCEDURE PROC_LOCAL_TO_BI_100091_PAY(INPUTDATE IN NUMBER) AS
  BEGIN
    DELETE FROM T_DW_100091_PAY T
     WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    --���ص�BI
    INSERT /*+APPEND */
    INTO T_DW_100091_PAY NOLOGGING
      (F_LOGTIME,
       T_LOGTIME,
       APPID,
       CHANNELID,
       GAMEVERSION,
       DVID,
       ACCOUNTID,
       SERVERID,
       LOGTYPE,
       ORDERID,
       IAPID,
       CURRENCYTYPE,
       PAYCHANNEL,
       CAMOUNT,
       VCAMOUNT,
       REASON,
       IPADDR)
      SELECT T.ORDERSTARTTIME,
             T.ORDERSTARTTIME,
             T.APPID,
             NVL(T.CHANNELID, '-1') CHANNELID,
             'OPEN' GAMEVERSION,
             NULL,
             T.UUID_OLD,
             'OPEN' SERVERID,
             'payrequest',
             T.ORDERID,
             NULL,
             NULL,
             NULL,
             T.RECHARGEAMT / 100 CAMOUNT,
             NULL,
             NULL,
             NULL
        FROM PPSG_SDK_ORDER_100091 T
       WHERE T.APPID = '100091'
         AND T.ORDERENDTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.ORDERENDTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    INSERT /*+APPEND */
    INTO T_DW_100091_PAY NOLOGGING
      (F_LOGTIME,
       T_LOGTIME,
       APPID,
       CHANNELID,
       GAMEVERSION,
       DVID,
       ACCOUNTID,
       SERVERID,
       LOGTYPE,
       ORDERID,
       IAPID,
       CURRENCYTYPE,
       PAYCHANNEL,
       CAMOUNT,
       VCAMOUNT,
       REASON,
       IPADDR)
      SELECT T.ORDERENDTIME,
             T.ORDERENDTIME,
             T.APPID,
             NVL(T.CHANNELID, '-1') CHANNELID,
             'OPEN' GAMEVERSION,
             NULL,
             T.UUID_OLD,
             'OPEN' SERVERID,
             'paysucc',
             T.ORDERID,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL
        FROM PPSG_SDK_ORDER_100091 T
       WHERE T.APPID = '100091'
         AND T.ORDERENDTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.ORDERENDTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

  END PROC_LOCAL_TO_BI_100091_PAY;

END PKG_OPEN_TO_BISOURCE_100091;
/

prompt
prompt Creating package body PKG_OPEN_TO_BISOURCE_100131
prompt =================================================
prompt
CREATE OR REPLACE PACKAGE BODY PKG_OPEN_TO_BISOURCE_100131 AS

  PROCEDURE PROC_OPEN_TO_BISU_100131_ALL(INPUTDATE IN NUMBER) AS
  BEGIN
  
    --��ȡ�˻���Ӧ��ϵ�����ݵ�����
    PROC_OPEN_TO_BISU_100131_MAP(INPUTDATE);
  
    --��ȡ�û��������ݵ�����
    PROC_OPEN_TO_BISU_100131_NU(INPUTDATE);
  
    --��ȡ�û��������ݵ�����
    PROC_OPEN_TO_BISU_100131_CONN(INPUTDATE);
  
    --��ȡ�û��������ݵ�����
    PROC_OPEN_TO_BISU_100131_ORDER(INPUTDATE);
  
    --���ر����������ݵ�BI
    PROC_LOCAL_TO_BI_100131_NU(INPUTDATE);
  
    --���ر����������ݵ�BI
    PROC_LOCAL_TO_BI_100131_CO_NP(INPUTDATE);
  
    --���ر��ظ������ݵ�BI
    PROC_LOCAL_TO_BI_100131_PAY(INPUTDATE);
  
  END PROC_OPEN_TO_BISU_100131_ALL;

  --��ȡ�˻���Ӧ��ϵ������
  PROCEDURE PROC_OPEN_TO_BISU_100131_MAP(INPUTDATE IN NUMBER) AS
  BEGIN
    DELETE FROM DIM_UC_OPEN_MAPPING_100131 T
     WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    INSERT INTO DIM_UC_OPEN_MAPPING_100131
      SELECT *
        FROM DIM_UC_OPEN_MAPPING T
       WHERE T.APPID = 100131
         AND T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
  END PROC_OPEN_TO_BISU_100131_MAP;

  --��ȡ�û���������
  PROCEDURE PROC_OPEN_TO_BISU_100131_NU(INPUTDATE IN NUMBER) AS
  BEGIN
    /*    DELETE FROM GCLD_SDK_NEWUSER_1149 T
     WHERE T.PID = 1149
       AND T.GAMEID = 100131
       AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
    
    DELETE FROM GCLD_SDK_NEWUSER_1161 T
     WHERE T.PID = 1161
       AND T.GAMEID = 100131
       AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
    
    DELETE FROM GCLD_SDK_NEWUSER_100131 T
     WHERE T.GAMEID = 100131
       AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;*/
  
    /*INSERT INTO GCLD_SDK_NEWUSER_1149
      SELECT T.*, F_UNIX_TO_ORACLE(T.FIRSTLOGINTIME) REG_TIME
        FROM PDT_SDK_NEWUSER@JTSTATIC_243 T
       WHERE T.PID = 1149
         AND T.GAMEID = 100131
         AND T.FIRSTLOGINTIME >=
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE))
         AND T.FIRSTLOGINTIME <
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE + 1));
    COMMIT;*/
  
    EXECUTE IMMEDIATE 'TRUNCATE TABLE GCLD_SDK_NEWUSER_100131';
    EXECUTE IMMEDIATE 'TRUNCATE TABLE GCLD_SDK_NEWUSER_1161';
  
    --1149
    INSERT INTO GCLD_SDK_NEWUSER_100131
      SELECT F_UNIX_TO_ORACLE(T.FIRSTLOGINTIME) REG_TIME,
             TO_CHAR(T.GAMEID) GAMEID,
             T.SUBCOOPID,
             T.VERSION,
             TO_CHAR(T.UUID) UUID,
             T.USERID
        FROM PDT_SDK_NEWUSER@JTSTATIC_243 T
       WHERE T.PID = 1149
         AND T.GAMEID = 100131
         AND trunc(F_UNIX_TO_ORACLE(T.FIRSTLOGINTIME)) >=
             (TRUNC(SYSDATE - INPUTDATE))
         AND trunc(F_UNIX_TO_ORACLE(T.FIRSTLOGINTIME)) <
             (TRUNC(SYSDATE - INPUTDATE + 1));
    COMMIT;
  
    --1161
    INSERT INTO GCLD_SDK_NEWUSER_1161
      SELECT T.*, F_UNIX_TO_ORACLE(T.FIRSTLOGINTIME) REG_TIME
        FROM PDT_SDK_NEWUSER@JTSTATIC_243 T
       WHERE T.PID = 1161
         AND T.GAMEID = 100131
         AND trunc(F_UNIX_TO_ORACLE(T.FIRSTLOGINTIME)) >=
             (TRUNC(SYSDATE - INPUTDATE))
         AND trunc(F_UNIX_TO_ORACLE(T.FIRSTLOGINTIME)) <
             (TRUNC(SYSDATE - INPUTDATE + 1));
    COMMIT;
  
    /*INSERT INTO GCLD_SDK_NEWUSER_100131
      SELECT T.REG_TIME,
             TO_CHAR(T.GAMEID) GAMEID,
             T.SUBCOOPID,
             T.VERSION,
             TO_CHAR(T.UUID) UUID,
             T.USERID
        FROM GCLD_SDK_NEWUSER_1149 T
       WHERE T.PID = 1149
         AND T.GAMEID = 100131
         AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;*/
  
    --1161+ӳ��д��
    INSERT INTO GCLD_SDK_NEWUSER_100131
      SELECT DISTINCT T.REG_TIME,
                      T.GAMEID,
                      T.SUBCOOPID,
                      T.VERSION,
                      NVL(M.UNIQUE_ID, T.UUID) UUID,
                      T.USERID
        FROM GCLD_SDK_NEWUSER_1161 T
        LEFT JOIN DIM_UC_OPEN_MAPPING_100131 M
          ON T.UUID = M.UUID
       WHERE T.PID = 1161
         AND T.GAMEID = 100131
         AND trunc(T.REG_TIME) >= TRUNC(SYSDATE - INPUTDATE)
         AND trunc(T.REG_TIME) < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
  END PROC_OPEN_TO_BISU_100131_NU;

  --��ȡ�û���������
  PROCEDURE PROC_OPEN_TO_BISU_100131_CONN(INPUTDATE IN NUMBER) AS
  BEGIN
    /*DELETE FROM GCLD_SDK_CONN_1149 T
     WHERE T.PID = '1149'
       AND T.GAMEID = '100131'
       AND T.THEDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
    COMMIT;
    
    DELETE FROM GCLD_SDK_CONN_1161 T
     WHERE T.PID = '1161'
       AND T.GAMEID = '100131'
       AND T.THEDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
    COMMIT;
    
    DELETE FROM GCLD_SDK_CONN_100131 T
     WHERE T.GAMEID = '100131'
       AND T.THEDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
    COMMIT;*/
  
    EXECUTE IMMEDIATE 'TRUNCATE TABLE GCLD_SDK_CONN_1161';
    EXECUTE IMMEDIATE 'TRUNCATE TABLE GCLD_SDK_CONN_100131';
  
    /*INSERT INTO GCLD_SDK_CONN_1149
      SELECT *
        FROM PDT_SDK_CONN@JTSTATIC_243 T
       WHERE T.PID = 1149
         AND T.GAMEID = 100131
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');
    COMMIT;*/
  
    --1149--ֱ��д��    
    INSERT INTO GCLD_SDK_CONN_100131
      SELECT T.THEDATE,
             T.GAMEID,
             T.ORIGINALCOOPID,
             T.VERSION,
             T.UUID,
             T.USERID,
             T.NEWDATE
        FROM PDT_SDK_CONN@JTSTATIC_243 T
       WHERE T.PID = 1149
         AND T.GAMEID = 100131
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');
    COMMIT;
  
    --1161
    INSERT INTO GCLD_SDK_CONN_1161
      SELECT *
        FROM PDT_SDK_CONN@JTSTATIC_243 T
       WHERE T.PID = 1161
         AND T.GAMEID = 100131
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');
    COMMIT;
  
    /* INSERT INTO GCLD_SDK_CONN_100131
      SELECT T.THEDATE,
             T.GAMEID,
             T.ORIGINALCOOPID,
             T.VERSION,
             T.UUID,
             T.USERID,
             T.NEWDATE
        FROM GCLD_SDK_CONN_1149 T
       WHERE T.PID = 1149
         AND T.GAMEID = 100131
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');
    COMMIT;*/
  
    --1161+ӳ��д��
    INSERT INTO GCLD_SDK_CONN_100131
      SELECT DISTINCT T.THEDATE,
                      T.GAMEID,
                      T.ORIGINALCOOPID,
                      T.VERSION,
                      NVL(M.UNIQUE_ID, T.UUID) UUID,
                      T.USERID,
                      T.NEWDATE
        FROM GCLD_SDK_CONN_1161 T
        LEFT JOIN DIM_UC_OPEN_MAPPING_100131 M
          ON T.UUID = M.UUID
       WHERE T.PID = 1161
         AND T.GAMEID = 100131
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');
    COMMIT;
  
  END PROC_OPEN_TO_BISU_100131_CONN;

  --��ȡ�û���������
  PROCEDURE PROC_OPEN_TO_BISU_100131_ORDER(INPUTDATE IN NUMBER) AS
  BEGIN
    /*DELETE FROM GCLD_SDK_ORDER_100131 T
     WHERE T.APPID = '100131'
       AND T.ORDERENDTIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.ORDERENDTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;*/
  
    EXECUTE IMMEDIATE 'TRUNCATE TABLE GCLD_SDK_ORDER_100131';
  
    INSERT INTO GCLD_SDK_ORDER_100131
      SELECT *
        FROM PDT_CP_SDK_ORDER_CLEAN@JTSTATIC_243 T
       WHERE T.APPID = '100131'
         AND T.ORDERENDTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.ORDERENDTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
  END PROC_OPEN_TO_BISU_100131_ORDER;

  --���ر����������ݵ�BI
  PROCEDURE PROC_LOCAL_TO_BI_100131_NU(INPUTDATE IN NUMBER) AS
  BEGIN
    DELETE FROM T_100131_NU T
     WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
       AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    DELETE FROM T_100131_NU_ALLSERVER T
     WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
       AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    INSERT 
    INTO T_100131_NU NOLOGGING
      (THEDATE,
       GAMEID,
       CHANNELID,
       GAMEVERSION,
       SERVERID,
       ROLELEVEL,
       POSITION,
       ACCOUNTID)
      SELECT TRUNC(T.REG_TIME) THEDATE,
             T.GAMEID,
             T.SUBCOOPID,
             'OPEN' GAMEVERSION,
             'OPEN' SERVERID,
             NULL,
             NULL,
             T.UUID
        FROM GCLD_SDK_NEWUSER_100131 T
       WHERE trunc(T.REG_TIME) >= TRUNC(SYSDATE - INPUTDATE)
         AND trunc(T.REG_TIME) < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    --allserver
    INSERT 
    INTO T_100131_NU_ALLSERVER NOLOGGING
      (THEDATE,
       GAMEID,
       CHANNELID,
       GAMEVERSION,
       ROLELEVEL,
       POSITION,
       ACCOUNTID)
      SELECT TRUNC(T.REG_TIME) THEDATE,
             T.GAMEID,
             T.SUBCOOPID,
             'OPEN' GAMEVERSION,
             NULL,
             NULL,
             T.UUID
        FROM GCLD_SDK_NEWUSER_100131 T
       WHERE trunc(T.REG_TIME) >= TRUNC(SYSDATE - INPUTDATE)
         AND trunc(T.REG_TIME) < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
  END PROC_LOCAL_TO_BI_100131_NU;

  --���ر����������ݵ�BI
  PROCEDURE PROC_LOCAL_TO_BI_100131_CO_NP(INPUTDATE IN NUMBER) AS
  BEGIN
    /*DELETE FROM T_100131_CONN_NOPAY T
     WHERE T.CONNDATE = TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD');
    COMMIT;*/
  
    DELETE FROM T_100131_CONN T
     WHERE T.CONNDATE = TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD');
    COMMIT;
  
    --���ص�BI
    INSERT /*+append*/
    /*INTO T_100131_CONN_NOPAY NOLOGGING*/
    INTO T_100131_CONN NOLOGGING
      (CONNDATE,
       GAMEID,
       CHANNELID,
       GAMEVERSION,
       SERVERID,
       ROLELEVEL,
       POSITION,
       DVID,
       ACCOUNTID,
       REGDATE,
       ISPAY,
       REGDATE_AS)
      SELECT T.THEDATE,
             T.GAMEID,
             T.ORIGINALCOOPID,
             'OPEN',
             'OPEN',
             0,
             '',
             '',
             T.UUID,
             T.NEWDATE,
             0,
             T.NEWDATE
        FROM GCLD_SDK_CONN_100131 T
       WHERE T.THEDATE = TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD');
    COMMIT;
  
    /*INSERT \*+APPEND *\
    INTO T_DW_100131_LOGIN NOLOGGING
      (F_LOGTIME,
       T_LOGTIME,
       APPID,
       CHANNELID,
       GAMEVERSION,
       DVID,
       ACCOUNTID,
       ACCOUNTNAME,
       ACCOUNTYPE,
       SERVERID,
       ILEVEL,
       ROLEID,
       ROLENAME,
       IPADDR)
      SELECT TO_DATE(T.THEDATE, 'YYYY-MM-DD'),
             TO_DATE(T.THEDATE, 'YYYY-MM-DD'),
             T.GAMEID,
             NVL(T.ORIGINALCOOPID, '-1') CHANNELID,
             'OPEN' GAMEVERSION,
             NULL,
             T.UUID,
             NULL,
             NULL,
             'OPEN' SERVERID,
             NULL,
             NULL,
             NULL,
             NULL
        FROM GCLD_SDK_CONN_100131 T
       WHERE T.GAMEID = 100131
         AND T.THEDATE >= TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD')
         AND T.THEDATE <
             TO_CHAR(TRUNC(SYSDATE - INPUTDATE + 1), 'YYYY-MM-DD');
    COMMIT;*/
  
  END PROC_LOCAL_TO_BI_100131_CO_NP;

  --���ر��ظ������ݵ�BI
  PROCEDURE PROC_LOCAL_TO_BI_100131_PAY(INPUTDATE IN NUMBER) AS
  BEGIN
    DELETE FROM T_DW_100131_PAY T
     WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    --���ص�BI
    INSERT 
    INTO T_DW_100131_PAY NOLOGGING
      (F_LOGTIME,
       T_LOGTIME,
       APPID,
       CHANNELID,
       GAMEVERSION,
       DVID,
       ACCOUNTID,
       SERVERID,
       LOGTYPE,
       ORDERID,
       IAPID,
       CURRENCYTYPE,
       PAYCHANNEL,
       CAMOUNT,
       VCAMOUNT,
       REASON,
       IPADDR)
      SELECT T.ORDERSTARTTIME,
             T.ORDERSTARTTIME,
             T.APPID,
             NVL(T.CHANNELID, '-1') CHANNELID,
             'OPEN' GAMEVERSION,
             NULL,
             T.UUID_OLD,
             'OPEN' SERVERID,
             'payrequest',
             T.ORDERID,
             NULL,
             NULL,
             NULL,
             T.RECHARGEAMT / 100 CAMOUNT,
             NULL,
             NULL,
             NULL
        FROM GCLD_SDK_ORDER_100131 T
       WHERE T.APPID = '100131'
         AND T.ORDERENDTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.ORDERENDTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    INSERT 
    INTO T_DW_100131_PAY NOLOGGING
      (F_LOGTIME,
       T_LOGTIME,
       APPID,
       CHANNELID,
       GAMEVERSION,
       DVID,
       ACCOUNTID,
       SERVERID,
       LOGTYPE,
       ORDERID,
       IAPID,
       CURRENCYTYPE,
       PAYCHANNEL,
       CAMOUNT,
       VCAMOUNT,
       REASON,
       IPADDR)
      SELECT T.ORDERENDTIME,
             T.ORDERENDTIME,
             T.APPID,
             NVL(T.CHANNELID, '-1') CHANNELID,
             'OPEN' GAMEVERSION,
             NULL,
             T.UUID_OLD,
             'OPEN' SERVERID,
             'paysucc',
             T.ORDERID,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL
        FROM GCLD_SDK_ORDER_100131 T
       WHERE T.APPID = '100131'
         AND T.ORDERENDTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.ORDERENDTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
  END PROC_LOCAL_TO_BI_100131_PAY;

END PKG_OPEN_TO_BISOURCE_100131;
/

prompt
prompt Creating package body PKG_OPEN_TO_BISOURCE_100132
prompt =================================================
prompt
CREATE OR REPLACE PACKAGE BODY PKG_OPEN_TO_BISOURCE_100132 AS

  PROCEDURE PROC_OPEN_TO_BISU_100132_ALL(INPUTDATE IN NUMBER) AS
  BEGIN
  
    --��ȡ�˻���Ӧ��ϵ�����ݵ�����
    PROC_OPEN_TO_BISU_100132_MAP(INPUTDATE);
  
    --��ȡ�û��������ݵ�����
    PROC_OPEN_TO_BISU_100132_NU(INPUTDATE);
  
    --��ȡ�û��������ݵ�����
    PROC_OPEN_TO_BISU_100132_CONN(INPUTDATE);
  
    --��ȡ�û��������ݵ�����
    PROC_OPEN_TO_BISU_100132_ORDER(INPUTDATE);
  
    --���ر����������ݵ�BI
    PROC_LOCAL_TO_BI_100132_NU(INPUTDATE);
  
    --���ر����������ݵ�BI
    PROC_LOCAL_TO_BI_100132_CO_NP(INPUTDATE);
  
    --���ر��ظ������ݵ�BI
    PROC_LOCAL_TO_BI_100132_PAY(INPUTDATE);
  
  END PROC_OPEN_TO_BISU_100132_ALL;

  --��ȡ�˻���Ӧ��ϵ������
  PROCEDURE PROC_OPEN_TO_BISU_100132_MAP(INPUTDATE IN NUMBER) AS
  BEGIN
    DELETE FROM DIM_UC_OPEN_MAPPING_100132 T
     WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    INSERT INTO DIM_UC_OPEN_MAPPING_100132
      SELECT *
        FROM DIM_UC_OPEN_MAPPING T
       WHERE T.APPID = 100132
         AND T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
  END PROC_OPEN_TO_BISU_100132_MAP;

  --��ȡ�û���������
  PROCEDURE PROC_OPEN_TO_BISU_100132_NU(INPUTDATE IN NUMBER) AS
  BEGIN
    /*    DELETE FROM GCLD_SDK_NEWUSER_1151 T
     WHERE T.PID = 1151
       AND T.GAMEID = 100132
       AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
    
    DELETE FROM GCLD_SDK_NEWUSER_1160 T
     WHERE T.PID = 1160
       AND T.GAMEID = 100132
       AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
    
    DELETE FROM GCLD_SDK_NEWUSER_100132 T
     WHERE T.GAMEID = 100132
       AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;*/
  
    /*INSERT INTO GCLD_SDK_NEWUSER_1151
      SELECT T.*, F_UNIX_TO_ORACLE(T.FIRSTLOGINTIME) REG_TIME
        FROM PDT_SDK_NEWUSER@JTSTATIC_243 T
       WHERE T.PID = 1151
         AND T.GAMEID = 100132
         AND T.FIRSTLOGINTIME >=
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE))
         AND T.FIRSTLOGINTIME <
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE + 1));
    COMMIT;*/
  
    EXECUTE IMMEDIATE 'TRUNCATE TABLE GCLD_SDK_NEWUSER_100132';
    EXECUTE IMMEDIATE 'TRUNCATE TABLE GCLD_SDK_NEWUSER_1160';
  
    --1151
    INSERT INTO GCLD_SDK_NEWUSER_100132
      SELECT F_UNIX_TO_ORACLE(T.FIRSTLOGINTIME) REG_TIME,
             TO_CHAR(T.GAMEID) GAMEID,
             T.SUBCOOPID,
             T.VERSION,
             TO_CHAR(T.UUID) UUID,
             T.USERID
        FROM PDT_SDK_NEWUSER@JTSTATIC_243 T
       WHERE T.PID = 1151
         AND T.GAMEID = 100132
         AND T.FIRSTLOGINTIME >=
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE))
         AND T.FIRSTLOGINTIME <
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE + 1));
    COMMIT;
  
    --1160
    INSERT INTO GCLD_SDK_NEWUSER_1160
      SELECT T.*, F_UNIX_TO_ORACLE(T.FIRSTLOGINTIME) REG_TIME
        FROM PDT_SDK_NEWUSER@JTSTATIC_243 T
       WHERE T.PID = 1160
         AND T.GAMEID = 100132
         AND T.FIRSTLOGINTIME >=
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE))
         AND T.FIRSTLOGINTIME <
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE + 1));
    COMMIT;
  
    /*INSERT INTO GCLD_SDK_NEWUSER_100132
      SELECT T.REG_TIME,
             TO_CHAR(T.GAMEID) GAMEID,
             T.SUBCOOPID,
             T.VERSION,
             TO_CHAR(T.UUID) UUID,
             T.USERID
        FROM GCLD_SDK_NEWUSER_1151 T
       WHERE T.PID = 1151
         AND T.GAMEID = 100132
         AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;*/
  
    --1160+ӳ��д��
    INSERT INTO GCLD_SDK_NEWUSER_100132
      SELECT DISTINCT T.REG_TIME,
                      T.GAMEID,
                      T.SUBCOOPID,
                      T.VERSION,
                      NVL(M.UNIQUE_ID, T.UUID) UUID,
                      T.USERID
        FROM GCLD_SDK_NEWUSER_1160 T
        LEFT JOIN DIM_UC_OPEN_MAPPING_100132 M
          ON T.UUID = M.UUID
       WHERE T.PID = 1160
         AND T.GAMEID = 100132
         AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
  END PROC_OPEN_TO_BISU_100132_NU;

  --��ȡ�û���������
  PROCEDURE PROC_OPEN_TO_BISU_100132_CONN(INPUTDATE IN NUMBER) AS
  BEGIN
    /*DELETE FROM GCLD_SDK_CONN_1151 T
     WHERE T.PID = '1151'
       AND T.GAMEID = '100132'
       AND T.THEDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
    COMMIT;
    
    DELETE FROM GCLD_SDK_CONN_1160 T
     WHERE T.PID = '1160'
       AND T.GAMEID = '100132'
       AND T.THEDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
    COMMIT;
    
    DELETE FROM GCLD_SDK_CONN_100132 T
     WHERE T.GAMEID = '100132'
       AND T.THEDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
    COMMIT;*/
  
    EXECUTE IMMEDIATE 'TRUNCATE TABLE GCLD_SDK_CONN_1160';
    EXECUTE IMMEDIATE 'TRUNCATE TABLE GCLD_SDK_CONN_100132';
  
    /*INSERT INTO GCLD_SDK_CONN_1151
      SELECT *
        FROM PDT_SDK_CONN@JTSTATIC_243 T
       WHERE T.PID = 1151
         AND T.GAMEID = 100132
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');
    COMMIT;*/
  
    --1151--ֱ��д��
    INSERT INTO GCLD_SDK_CONN_100132
      SELECT T.THEDATE,
             T.GAMEID,
             T.ORIGINALCOOPID,
             T.VERSION,
             T.UUID,
             T.USERID,
             T.NEWDATE
        FROM PDT_SDK_CONN@JTSTATIC_243 T
       WHERE T.PID = 1151
         AND T.GAMEID = 100132
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');
  
    --1160
    INSERT INTO GCLD_SDK_CONN_1160
      SELECT *
        FROM PDT_SDK_CONN@JTSTATIC_243 T
       WHERE T.PID = 1160
         AND T.GAMEID = 100132
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');
    COMMIT;
  
    /* INSERT INTO GCLD_SDK_CONN_100132
      SELECT T.THEDATE,
             T.GAMEID,
             T.ORIGINALCOOPID,
             T.VERSION,
             T.UUID,
             T.USERID,
             T.NEWDATE
        FROM GCLD_SDK_CONN_1151 T
       WHERE T.PID = 1151
         AND T.GAMEID = 100132
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');
    COMMIT;*/
  
    --1160+ӳ��д��
    INSERT INTO GCLD_SDK_CONN_100132
      SELECT DISTINCT T.THEDATE,
                      T.GAMEID,
                      T.ORIGINALCOOPID,
                      T.VERSION,
                      NVL(M.UNIQUE_ID, T.UUID) UUID,
                      T.USERID,
                      T.NEWDATE
        FROM GCLD_SDK_CONN_1160 T
        LEFT JOIN DIM_UC_OPEN_MAPPING_100132 M
          ON T.UUID = M.UUID
       WHERE T.PID = 1160
         AND T.GAMEID = 100132
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');
    COMMIT;
  
  END PROC_OPEN_TO_BISU_100132_CONN;

  --��ȡ�û���������
  PROCEDURE PROC_OPEN_TO_BISU_100132_ORDER(INPUTDATE IN NUMBER) AS
  BEGIN
    /*DELETE FROM GCLD_SDK_ORDER_100132 T
     WHERE T.APPID = '100132'
       AND T.ORDERENDTIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.ORDERENDTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;*/
  
    EXECUTE IMMEDIATE 'TRUNCATE TABLE GCLD_SDK_ORDER_100132';
  
    INSERT INTO GCLD_SDK_ORDER_100132
      SELECT *
        FROM PDT_CP_SDK_ORDER_CLEAN@JTSTATIC_243 T
       WHERE T.APPID = '100132'
         AND T.ORDERENDTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.ORDERENDTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  END PROC_OPEN_TO_BISU_100132_ORDER;

  --���ر����������ݵ�BI
  PROCEDURE PROC_LOCAL_TO_BI_100132_NU(INPUTDATE IN NUMBER) AS
  BEGIN
    DELETE FROM T_100132_NU T
     WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
       AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    DELETE FROM T_100132_NU_ALLSERVER T
     WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
       AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    INSERT 
    INTO T_100132_NU NOLOGGING
      (THEDATE,
       GAMEID,
       CHANNELID,
       GAMEVERSION,
       SERVERID,
       ROLELEVEL,
       POSITION,
       ACCOUNTID)
      SELECT TRUNC(T.REG_TIME) THEDATE,
             T.GAMEID,
             T.SUBCOOPID,
             'OPEN' GAMEVERSION,
             'OPEN' SERVERID,
             NULL,
             NULL,
             T.UUID
        FROM GCLD_SDK_NEWUSER_100132 T
       WHERE T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    INSERT 
    INTO T_100132_NU_ALLSERVER NOLOGGING
      (THEDATE,
       GAMEID,
       CHANNELID,
       GAMEVERSION,
       ROLELEVEL,
       POSITION,
       ACCOUNTID)
      SELECT TRUNC(T.REG_TIME) THEDATE,
             T.GAMEID,
             T.SUBCOOPID,
             'OPEN' GAMEVERSION,
             NULL,
             NULL,
             T.UUID
        FROM GCLD_SDK_NEWUSER_100132 T
       WHERE T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
  END PROC_LOCAL_TO_BI_100132_NU;

  --���ر����������ݵ�BI
  PROCEDURE PROC_LOCAL_TO_BI_100132_CO_NP(INPUTDATE IN NUMBER) AS
  BEGIN
    /*DELETE FROM T_100132_CONN_NOPAY T
     WHERE T.CONNDATE = TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD');
    COMMIT;*/
  
    DELETE FROM T_100132_CONN T
     WHERE T.CONNDATE = TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD');
    COMMIT;
  
    --���ص�BI
    INSERT /*+append*/
    /*INTO T_100132_CONN_NOPAY NOLOGGING*/
    INTO T_100132_CONN NOLOGGING
      (CONNDATE,
       GAMEID,
       CHANNELID,
       GAMEVERSION,
       SERVERID,
       ROLELEVEL,
       POSITION,
       DVID,
       ACCOUNTID,
       REGDATE,
       ISPAY,
       REGDATE_AS)
      SELECT T.THEDATE,
             T.GAMEID,
             T.ORIGINALCOOPID,
             'OPEN',
             'OPEN',
             0,
             '',
             '',
             T.UUID,
             T.NEWDATE,
             0,
             T.NEWDATE
        FROM GCLD_SDK_CONN_100132 T
       WHERE T.THEDATE = TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD');
    COMMIT;
  
    /*INSERT \*+APPEND *\
    INTO T_DW_100132_LOGIN NOLOGGING
      (F_LOGTIME,
       T_LOGTIME,
       APPID,
       CHANNELID,
       GAMEVERSION,
       DVID,
       ACCOUNTID,
       ACCOUNTNAME,
       ACCOUNTYPE,
       SERVERID,
       ILEVEL,
       ROLEID,
       ROLENAME,
       IPADDR)
      SELECT TO_DATE(T.THEDATE, 'YYYY-MM-DD'),
             TO_DATE(T.THEDATE, 'YYYY-MM-DD'),
             T.GAMEID,
             NVL(T.ORIGINALCOOPID, '-1') CHANNELID,
             'OPEN' GAMEVERSION,
             NULL,
             T.UUID,
             NULL,
             NULL,
             'OPEN' SERVERID,
             NULL,
             NULL,
             NULL,
             NULL
        FROM GCLD_SDK_CONN_100132 T
       WHERE T.GAMEID = 100132
         AND T.THEDATE >= TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD')
         AND T.THEDATE <
             TO_CHAR(TRUNC(SYSDATE - INPUTDATE + 1), 'YYYY-MM-DD');
    COMMIT;*/
  
  END PROC_LOCAL_TO_BI_100132_CO_NP;

  --���ر��ظ������ݵ�BI
  PROCEDURE PROC_LOCAL_TO_BI_100132_PAY(INPUTDATE IN NUMBER) AS
  BEGIN
    DELETE FROM T_DW_100132_PAY T
     WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    --���ص�BI
    INSERT 
    INTO T_DW_100132_PAY NOLOGGING
      (F_LOGTIME,
       T_LOGTIME,
       APPID,
       CHANNELID,
       GAMEVERSION,
       DVID,
       ACCOUNTID,
       SERVERID,
       LOGTYPE,
       ORDERID,
       IAPID,
       CURRENCYTYPE,
       PAYCHANNEL,
       CAMOUNT,
       VCAMOUNT,
       REASON,
       IPADDR)
      SELECT T.ORDERSTARTTIME,
             T.ORDERSTARTTIME,
             T.APPID,
             NVL(T.CHANNELID, '-1') CHANNELID,
             'OPEN' GAMEVERSION,
             NULL,
             T.UUID_OLD,
             'OPEN' SERVERID,
             'payrequest',
             T.ORDERID,
             NULL,
             NULL,
             NULL,
             T.RECHARGEAMT / 100 CAMOUNT,
             NULL,
             NULL,
             NULL
        FROM GCLD_SDK_ORDER_100132 T
       WHERE T.APPID = '100132'
         AND T.ORDERENDTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.ORDERENDTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    INSERT 
    INTO T_DW_100132_PAY NOLOGGING
      (F_LOGTIME,
       T_LOGTIME,
       APPID,
       CHANNELID,
       GAMEVERSION,
       DVID,
       ACCOUNTID,
       SERVERID,
       LOGTYPE,
       ORDERID,
       IAPID,
       CURRENCYTYPE,
       PAYCHANNEL,
       CAMOUNT,
       VCAMOUNT,
       REASON,
       IPADDR)
      SELECT T.ORDERENDTIME,
             T.ORDERENDTIME,
             T.APPID,
             NVL(T.CHANNELID, '-1') CHANNELID,
             'OPEN' GAMEVERSION,
             NULL,
             T.UUID_OLD,
             'OPEN' SERVERID,
             'paysucc',
             T.ORDERID,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL
        FROM GCLD_SDK_ORDER_100132 T
       WHERE T.APPID = '100132'
         AND T.ORDERENDTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.ORDERENDTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
  END PROC_LOCAL_TO_BI_100132_PAY;

END PKG_OPEN_TO_BISOURCE_100132;
/

prompt
prompt Creating package body PKG_OPEN_TO_BISOURCE_100150
prompt =================================================
prompt
CREATE OR REPLACE PACKAGE BODY PKG_OPEN_TO_BISOURCE_100150 AS

  PROCEDURE PROC_OPEN_TO_BISU_100150_ALL(INPUTDATE IN NUMBER) AS
  BEGIN

    --��ȡ�˻���Ӧ��ϵ�����ݵ�����
    PROC_OPEN_TO_BISU_100150_MAP(INPUTDATE);

    --��ȡ�û��������ݵ�����
    PROC_OPEN_TO_BISU_100150_NU(INPUTDATE);

    --��ȡ�û��������ݵ�����
    PROC_OPEN_TO_BISU_100150_CONN(INPUTDATE);

    /*--��ȡ�û��������ݵ�����
    PROC_OPEN_TO_BISU_100150_ORDER(INPUTDATE);*/

    --���ر����������ݵ�BI
    PROC_LOCAL_TO_BI_100150_NU(INPUTDATE);

    --���ر����������ݵ�BI
    PROC_LOCAL_TO_BI_100150_CO_NP(INPUTDATE);

    /*--���ر��ظ������ݵ�BI
    PROC_LOCAL_TO_BI_100150_PAY(INPUTDATE);*/

  END PROC_OPEN_TO_BISU_100150_ALL;

  --��ȡ�˻���Ӧ��ϵ������
  PROCEDURE PROC_OPEN_TO_BISU_100150_MAP(INPUTDATE IN NUMBER) AS
  BEGIN
    DELETE FROM DIM_UC_OPEN_MAPPING_100150 T
     WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    INSERT INTO DIM_UC_OPEN_MAPPING_100150
      SELECT *
        FROM DIM_UC_OPEN_MAPPING T
       WHERE T.APPID = 100150
         AND T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

  END PROC_OPEN_TO_BISU_100150_MAP;

  --��ȡ�û���������
  PROCEDURE PROC_OPEN_TO_BISU_100150_NU(INPUTDATE IN NUMBER) AS
  BEGIN
    /*    DELETE FROM ZDTK_SDK_NEWUSER_1149 T
     WHERE T.PID = 1149
       AND T.GAMEID = 100150
       AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    DELETE FROM ZDTK_SDK_NEWUSER_1161 T
     WHERE T.PID = 1161
       AND T.GAMEID = 100150
       AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    DELETE FROM ZDTK_SDK_NEWUSER_100150 T
     WHERE T.GAMEID = 100150
       AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;*/

    /*INSERT INTO ZDTK_SDK_NEWUSER_1149
      SELECT T.*, F_UNIX_TO_ORACLE(T.FIRSTLOGINTIME) REG_TIME
        FROM PDT_SDK_NEWUSER@JTSTATIC_243 T
       WHERE T.PID = 1149
         AND T.GAMEID = 100150
         AND T.FIRSTLOGINTIME >=
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE))
         AND T.FIRSTLOGINTIME <
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE + 1));
    COMMIT;*/

    EXECUTE IMMEDIATE 'TRUNCATE TABLE ZDTK_SDK_NEWUSER_100150';
    EXECUTE IMMEDIATE 'TRUNCATE TABLE ZDTK_SDK_NEWUSER_1161';

    --1149
    INSERT INTO ZDTK_SDK_NEWUSER_100150
      SELECT F_UNIX_TO_ORACLE(T.FIRSTLOGINTIME) REG_TIME,
             TO_CHAR(T.GAMEID) GAMEID,
             T.SUBCOOPID,
             T.VERSION,
             TO_CHAR(T.UUID) UUID,
             T.USERID
        FROM PDT_SDK_NEWUSER@JTSTATIC_243 T
       WHERE T.PID = 1149
         AND T.GAMEID = 100150
         AND T.FIRSTLOGINTIME >=
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE))
         AND T.FIRSTLOGINTIME <
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE + 1));
    COMMIT;

    --1161
    INSERT INTO ZDTK_SDK_NEWUSER_1161
      SELECT T.*, F_UNIX_TO_ORACLE(T.FIRSTLOGINTIME) REG_TIME
        FROM PDT_SDK_NEWUSER@JTSTATIC_243 T
       WHERE T.PID = 1161
         AND T.GAMEID = 100150
         AND T.FIRSTLOGINTIME >=
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE))
         AND T.FIRSTLOGINTIME <
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE + 1));
    COMMIT;

    /*INSERT INTO ZDTK_SDK_NEWUSER_100150
      SELECT T.REG_TIME,
             TO_CHAR(T.GAMEID) GAMEID,
             T.SUBCOOPID,
             T.VERSION,
             TO_CHAR(T.UUID) UUID,
             T.USERID
        FROM ZDTK_SDK_NEWUSER_1149 T
       WHERE T.PID = 1149
         AND T.GAMEID = 100150
         AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;*/

    --1161+ӳ��д��
    INSERT INTO ZDTK_SDK_NEWUSER_100150
      SELECT DISTINCT T.REG_TIME,
                      T.GAMEID,
                      T.SUBCOOPID,
                      T.VERSION,
                      NVL(M.UNIQUE_ID, T.UUID) UUID,
                      T.USERID
        FROM ZDTK_SDK_NEWUSER_1161 T
        LEFT JOIN DIM_UC_OPEN_MAPPING_100150 M
          ON T.UUID = M.UUID
       WHERE T.PID = 1161
         AND T.GAMEID = 100150
         AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

  END PROC_OPEN_TO_BISU_100150_NU;

  --��ȡ�û���������
  PROCEDURE PROC_OPEN_TO_BISU_100150_CONN(INPUTDATE IN NUMBER) AS
  BEGIN
    /*DELETE FROM ZDTK_SDK_CONN_1149 T
     WHERE T.PID = '1149'
       AND T.GAMEID = '100150'
       AND T.THEDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    DELETE FROM ZDTK_SDK_CONN_1161 T
     WHERE T.PID = '1161'
       AND T.GAMEID = '100150'
       AND T.THEDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    DELETE FROM ZDTK_SDK_CONN_100150 T
     WHERE T.GAMEID = '100150'
       AND T.THEDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
    COMMIT;*/

    EXECUTE IMMEDIATE 'TRUNCATE TABLE ZDTK_SDK_CONN_1161';
    EXECUTE IMMEDIATE 'TRUNCATE TABLE ZDTK_SDK_CONN_100150';

    /*INSERT INTO ZDTK_SDK_CONN_1149
      SELECT *
        FROM PDT_SDK_CONN@JTSTATIC_243 T
       WHERE T.PID = 1149
         AND T.GAMEID = 100150
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');
    COMMIT;*/

    --1149--ֱ��д��
    INSERT INTO ZDTK_SDK_CONN_100150
      SELECT T.THEDATE,
             T.GAMEID,
             T.ORIGINALCOOPID,
             T.VERSION,
             T.UUID,
             T.USERID,
             T.NEWDATE
        FROM PDT_SDK_CONN@JTSTATIC_243 T
       WHERE T.PID = 1149
         AND T.GAMEID = 100150
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');

    --1161
    INSERT INTO ZDTK_SDK_CONN_1161
      SELECT *
        FROM PDT_SDK_CONN@JTSTATIC_243 T
       WHERE T.PID = 1161
         AND T.GAMEID = 100150
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');
    COMMIT;

    /* INSERT INTO ZDTK_SDK_CONN_100150
      SELECT T.THEDATE,
             T.GAMEID,
             T.ORIGINALCOOPID,
             T.VERSION,
             T.UUID,
             T.USERID,
             T.NEWDATE
        FROM ZDTK_SDK_CONN_1149 T
       WHERE T.PID = 1149
         AND T.GAMEID = 100150
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');
    COMMIT;*/

    --1161+ӳ��д��
    INSERT INTO ZDTK_SDK_CONN_100150
      SELECT DISTINCT T.THEDATE,
                      T.GAMEID,
                      T.ORIGINALCOOPID,
                      T.VERSION,
                      NVL(M.UNIQUE_ID, T.UUID) UUID,
                      T.USERID,
                      T.NEWDATE
        FROM ZDTK_SDK_CONN_1161 T
        LEFT JOIN DIM_UC_OPEN_MAPPING_100150 M
          ON T.UUID = M.UUID
       WHERE T.PID = 1161
         AND T.GAMEID = 100150
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');
    COMMIT;

  END PROC_OPEN_TO_BISU_100150_CONN;

  --��ȡ�û���������
  PROCEDURE PROC_OPEN_TO_BISU_100150_ORDER(INPUTDATE IN NUMBER) AS
  BEGIN
    /*DELETE FROM ZDTK_SDK_ORDER_100150 T
     WHERE T.APPID = '100150'
       AND T.ORDERENDTIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.ORDERENDTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;*/

    EXECUTE IMMEDIATE 'TRUNCATE TABLE ZDTK_SDK_ORDER_100150';

    INSERT INTO ZDTK_SDK_ORDER_100150
      SELECT *
        FROM PDT_CP_SDK_ORDER_CLEAN@JTSTATIC_243 T
       WHERE T.APPID = '100150'
         AND T.ORDERENDTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.ORDERENDTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  END PROC_OPEN_TO_BISU_100150_ORDER;

  --���ر����������ݵ�BI
  PROCEDURE PROC_LOCAL_TO_BI_100150_NU(INPUTDATE IN NUMBER) AS
  BEGIN
    DELETE FROM T_100150_NU T
     WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
       AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    DELETE FROM T_100150_NU_ALLSERVER T
     WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
       AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    INSERT /*+APPEND */
    INTO T_100150_NU NOLOGGING
      (THEDATE,
       GAMEID,
       CHANNELID,
       GAMEVERSION,
       SERVERID,
       ROLELEVEL,
       POSITION,
       ACCOUNTID)
      SELECT TRUNC(T.REG_TIME) THEDATE,
             T.GAMEID,
             T.SUBCOOPID,
             'OPEN' GAMEVERSION,
             'OPEN' SERVERID,
             NULL,
             NULL,
             T.UUID
        FROM ZDTK_SDK_NEWUSER_100150 T
       WHERE T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    INSERT /*+APPEND */
    INTO T_100150_NU_ALLSERVER NOLOGGING
      (THEDATE,
       GAMEID,
       CHANNELID,
       GAMEVERSION,
       ROLELEVEL,
       POSITION,
       ACCOUNTID)
      SELECT TRUNC(T.REG_TIME) THEDATE,
             T.GAMEID,
             T.SUBCOOPID,
             'OPEN' GAMEVERSION,
             NULL,
             NULL,
             T.UUID
        FROM ZDTK_SDK_NEWUSER_100150 T
       WHERE T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

  END PROC_LOCAL_TO_BI_100150_NU;

  --���ر����������ݵ�BI
  PROCEDURE PROC_LOCAL_TO_BI_100150_CO_NP(INPUTDATE IN NUMBER) AS
  BEGIN
    /*DELETE FROM T_100150_CONN_NOPAY T
     WHERE T.CONNDATE = TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD');
    COMMIT;*/

    DELETE FROM T_100150_CONN T
     WHERE T.CONNDATE = TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD');
    COMMIT;

    --���ص�BI
    INSERT /*+append*/
    /*INTO T_100150_CONN_NOPAY NOLOGGING*/
    INTO T_100150_CONN NOLOGGING
      (CONNDATE,
       GAMEID,
       CHANNELID,
       GAMEVERSION,
       SERVERID,
       ROLELEVEL,
       POSITION,
       DVID,
       ACCOUNTID,
       REGDATE,
       ISPAY,
       REGDATE_AS)
      SELECT T.THEDATE,
             T.GAMEID,
             T.ORIGINALCOOPID,
             'OPEN',
             'OPEN',
             0,
             '',
             '',
             T.UUID,
             T.NEWDATE,
             0,
             T.NEWDATE
        FROM ZDTK_SDK_CONN_100150 T
       WHERE T.THEDATE = TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD');
    COMMIT;

    /*INSERT \*+APPEND *\
    INTO T_DW_100150_LOGIN NOLOGGING
      (F_LOGTIME,
       T_LOGTIME,
       APPID,
       CHANNELID,
       GAMEVERSION,
       DVID,
       ACCOUNTID,
       ACCOUNTNAME,
       ACCOUNTYPE,
       SERVERID,
       ILEVEL,
       ROLEID,
       ROLENAME,
       IPADDR)
      SELECT TO_DATE(T.THEDATE, 'YYYY-MM-DD'),
             TO_DATE(T.THEDATE, 'YYYY-MM-DD'),
             T.GAMEID,
             NVL(T.ORIGINALCOOPID, '-1') CHANNELID,
             'OPEN' GAMEVERSION,
             NULL,
             T.UUID,
             NULL,
             NULL,
             'OPEN' SERVERID,
             NULL,
             NULL,
             NULL,
             NULL
        FROM ZDTK_SDK_CONN_100150 T
       WHERE T.GAMEID = 100150
         AND T.THEDATE >= TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD')
         AND T.THEDATE <
             TO_CHAR(TRUNC(SYSDATE - INPUTDATE + 1), 'YYYY-MM-DD');
    COMMIT;*/

  END PROC_LOCAL_TO_BI_100150_CO_NP;

  --���ر��ظ������ݵ�BI
  PROCEDURE PROC_LOCAL_TO_BI_100150_PAY(INPUTDATE IN NUMBER) AS
  BEGIN
    DELETE FROM T_DW_100150_PAY T
     WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    --���ص�BI
    INSERT /*+APPEND */
    INTO T_DW_100150_PAY NOLOGGING
      (F_LOGTIME,
       T_LOGTIME,
       APPID,
       CHANNELID,
       GAMEVERSION,
       DVID,
       ACCOUNTID,
       SERVERID,
       LOGTYPE,
       ORDERID,
       IAPID,
       CURRENCYTYPE,
       PAYCHANNEL,
       CAMOUNT,
       VCAMOUNT,
       REASON,
       IPADDR)
      SELECT T.ORDERSTARTTIME,
             T.ORDERSTARTTIME,
             T.APPID,
             NVL(T.CHANNELID, '-1') CHANNELID,
             'OPEN' GAMEVERSION,
             NULL,
             T.UUID_OLD,
             'OPEN' SERVERID,
             'payrequest',
             T.ORDERID,
             NULL,
             NULL,
             NULL,
             T.RECHARGEAMT / 100 CAMOUNT,
             NULL,
             NULL,
             NULL
        FROM ZDTK_SDK_ORDER_100150 T
       WHERE T.APPID = '100150'
         AND T.ORDERENDTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.ORDERENDTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    INSERT /*+APPEND */
    INTO T_DW_100150_PAY NOLOGGING
      (F_LOGTIME,
       T_LOGTIME,
       APPID,
       CHANNELID,
       GAMEVERSION,
       DVID,
       ACCOUNTID,
       SERVERID,
       LOGTYPE,
       ORDERID,
       IAPID,
       CURRENCYTYPE,
       PAYCHANNEL,
       CAMOUNT,
       VCAMOUNT,
       REASON,
       IPADDR)
      SELECT T.ORDERENDTIME,
             T.ORDERENDTIME,
             T.APPID,
             NVL(T.CHANNELID, '-1') CHANNELID,
             'OPEN' GAMEVERSION,
             NULL,
             T.UUID_OLD,
             'OPEN' SERVERID,
             'paysucc',
             T.ORDERID,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL
        FROM ZDTK_SDK_ORDER_100150 T
       WHERE T.APPID = '100150'
         AND T.ORDERENDTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.ORDERENDTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

  END PROC_LOCAL_TO_BI_100150_PAY;

END PKG_OPEN_TO_BISOURCE_100150;
/

prompt
prompt Creating package body PKG_OPEN_TO_BISOURCE_100178
prompt =================================================
prompt
CREATE OR REPLACE PACKAGE BODY PKG_OPEN_TO_BISOURCE_100178 AS

  PROCEDURE PROC_OPEN_TO_BISU_100178_ALL(INPUTDATE IN NUMBER) AS
  BEGIN
  
    --��ȡ�˻���Ӧ��ϵ�����ݵ�����
    PROC_OPEN_TO_BISU_100178_MAP(INPUTDATE);
  
    /*--��ȡ�û���������
    PROC_OPEN_TO_BISU_100178_NU(INPUTDATE);*/
  
    --��ȡ�û��������ݵ�����
    PROC_OPEN_TO_BISU_100178_CONN(INPUTDATE);
  
    --��ȡ�û��������ݵ�����
    PROC_OPEN_TO_BISU_100178_ORDER(INPUTDATE);
  
    --�����⾵�ͱ����������ݵ�BI
    PROC_LOCAL_TO_BI_100178_LOGIN(INPUTDATE);
  
    --�����⾵�ͱ��ظ������ݵ�BI
    PROC_LOCAL_TO_BI_100178_PAY(INPUTDATE);
  
  END PROC_OPEN_TO_BISU_100178_ALL;

  --��ȡ�˻���Ӧ��ϵ������
  PROCEDURE PROC_OPEN_TO_BISU_100178_MAP(INPUTDATE IN NUMBER) AS
  BEGIN
    DELETE FROM DIM_UC_OPEN_MAPPING_100178 T
     WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    INSERT INTO DIM_UC_OPEN_MAPPING_100178
      SELECT *
        FROM DIM_UC_OPEN_MAPPING T
       WHERE T.APPID = 100178
         AND T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
  END PROC_OPEN_TO_BISU_100178_MAP;

  /*--��ȡ�û���������
  PROCEDURE PROC_OPEN_TO_BISU_100178_NU(INPUTDATE IN NUMBER) AS
  BEGIN
    DELETE FROM DX_SDK_NEWUSER_1151 T
     WHERE T.PID = 1151
       AND T.GAMEID = 100178
       AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    DELETE FROM DX_SDK_NEWUSER_1160 T
     WHERE T.PID = 1160
       AND T.GAMEID = 100178
       AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    DELETE FROM DX_SDK_NEWUSER_ANDR_OPEN T
     WHERE T.GAMEID = 100178
       AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    INSERT INTO DX_SDK_NEWUSER_1151
      SELECT T.*, F_UNIX_TO_ORACLE(T.FIRSTLOGINTIME) REG_TIME
        FROM PDT_SDK_NEWUSER@JTSTATIC_243 T
       WHERE T.PID = 1151
         AND T.GAMEID = 100178
         AND T.FIRSTLOGINTIME >=
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE))
         AND T.FIRSTLOGINTIME <
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE + 1));
    COMMIT;
  
    INSERT INTO DX_SDK_NEWUSER_1160
      SELECT T.*, F_UNIX_TO_ORACLE(T.FIRSTLOGINTIME) REG_TIME
        FROM PDT_SDK_NEWUSER@JTSTATIC_243 T
       WHERE T.PID = 1160
         AND T.GAMEID = 100178
         AND T.FIRSTLOGINTIME >=
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE))
         AND T.FIRSTLOGINTIME <
             F_ORACLE_TO_UNIX(TRUNC(SYSDATE - INPUTDATE + 1));
    COMMIT;
  
    INSERT INTO DX_SDK_NEWUSER_ANDR_OPEN
      SELECT T.REG_TIME,
             TO_CHAR(T.GAMEID) GAMEID,
             T.SUBCOOPID,
             T.VERSION,
             TO_CHAR(T.UUID) UUID,
             T.USERID
        FROM DX_SDK_NEWUSER_1151 T
       WHERE T.PID = 1151
         AND T.GAMEID = 100178
         AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    INSERT INTO DX_SDK_NEWUSER_ANDR_OPEN
      SELECT T.REG_TIME,
             T.GAMEID,
             T.SUBCOOPID,
             T.VERSION,
             M.UNIQUE_ID,
             T.USERID
        FROM DX_SDK_NEWUSER_1160 T
       INNER JOIN DIM_UC_OPEN_MAPPING_100178 M
          ON T.UUID = M.UUID
       WHERE T.PID = 1160
         AND T.GAMEID = 100178
         AND T.REG_TIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.REG_TIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
  END PROC_OPEN_TO_BISU_100178_NU;*/

  --��ȡ�û���������
  PROCEDURE PROC_OPEN_TO_BISU_100178_CONN(INPUTDATE IN NUMBER) AS
  BEGIN
    DELETE FROM DX_SDK_CONN_1151 T
     WHERE T.PID = '1151'
       AND T.GAMEID = '100178'
       AND T.THEDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
    COMMIT;
  
    DELETE FROM DX_SDK_CONN_1160 T
     WHERE T.PID = '1160'
       AND T.GAMEID = '100178'
       AND T.THEDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
    COMMIT;
  
    DELETE FROM DX_SDK_CONN_ANDR_OPEN T
     WHERE T.GAMEID = '100178'
       AND T.THEDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
    COMMIT;
  
    INSERT INTO DX_SDK_CONN_1151
      SELECT *
        FROM PDT_SDK_CONN@JTSTATIC_243 T
       WHERE T.PID = 1151
         AND T.GAMEID = 100178
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');
    COMMIT;
  
    INSERT INTO DX_SDK_CONN_1160
      SELECT *
        FROM PDT_SDK_CONN@JTSTATIC_243 T
       WHERE T.PID = 1160
         AND T.GAMEID = 100178
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');
    COMMIT;
  
    INSERT INTO DX_SDK_CONN_ANDR_OPEN
      SELECT T.THEDATE,
             T.GAMEID,
             T.ORIGINALCOOPID,
             T.VERSION,
             T.UUID,
             T.USERID,
             T.NEWDATE
        FROM DX_SDK_CONN_1151 T
       WHERE T.PID = 1151
         AND T.GAMEID = 100178
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');
    COMMIT;
  
    INSERT INTO DX_SDK_CONN_ANDR_OPEN
      SELECT T.THEDATE,
             T.GAMEID,
             T.ORIGINALCOOPID,
             T.VERSION,
             M.UNIQUE_ID,
             T.USERID,
             T.NEWDATE
        FROM DX_SDK_CONN_1160 T
       INNER JOIN DIM_UC_OPEN_MAPPING_100178 M
          ON T.UUID = M.UUID
       WHERE T.PID = 1160
         AND T.GAMEID = 100178
         AND T.THEDATE >= TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         AND T.THEDATE < TO_CHAR(SYSDATE - INPUTDATE + 1, 'YYYY-MM-DD');
    COMMIT;
  
  END PROC_OPEN_TO_BISU_100178_CONN;

  --��ȡ�û���������
  PROCEDURE PROC_OPEN_TO_BISU_100178_ORDER(INPUTDATE IN NUMBER) AS
  BEGIN
    DELETE FROM DX_SDK_ORDER_ANDR_OPEN T
     WHERE T.APPID = '100178'
       AND T.ORDERENDTIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.ORDERENDTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    INSERT INTO DX_SDK_ORDER_ANDR_OPEN
      SELECT *
        FROM PDT_CP_SDK_ORDER_CLEAN@JTSTATIC_243 T
       WHERE T.APPID = '100178'
         AND T.ORDERENDTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.ORDERENDTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
  END PROC_OPEN_TO_BISU_100178_ORDER;

  PROCEDURE PROC_LOCAL_TO_BI_100178_LOGIN(INPUTDATE IN NUMBER) AS
  BEGIN
    DELETE FROM T_DW_100178_LOGIN T
     WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    --�����⾵�������������ݵ�BI
    INSERT /*+APPEND */
    INTO T_DW_100178_LOGIN NOLOGGING
      (F_LOGTIME,
       T_LOGTIME,
       APPID,
       CHANNELID,
       GAMEVERSION,
       DVID,
       ACCOUNTID,
       ACCOUNTNAME,
       ACCOUNTYPE,
       SERVERID,
       ILEVEL,
       ROLEID,
       ROLENAME,
       IPADDR)
      SELECT T.F_LOGTIME,
             T.F_LOGTIME,
             T.APPID,
             NVL(T.CHANNELID, '-1') CHANNELID,
             /*T.GAMEVERSION,*/
             'all' GAMEVERSION,
             T.DVID,
             T.USERID,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             T.IP
        FROM T_DW_100178_LOGIN_PAY_F3 T
       WHERE LOWER(T.LOGTYPE) = 'login'
         AND T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    --���ر����������ݵ�BI 
    INSERT /*+APPEND */
    INTO T_DW_100178_LOGIN NOLOGGING
      (F_LOGTIME,
       T_LOGTIME,
       APPID,
       CHANNELID,
       GAMEVERSION,
       DVID,
       ACCOUNTID,
       ACCOUNTNAME,
       ACCOUNTYPE,
       SERVERID,
       ILEVEL,
       ROLEID,
       ROLENAME,
       IPADDR)
      SELECT TO_DATE(T.THEDATE, 'YYYY-MM-DD'),
             TO_DATE(T.THEDATE, 'YYYY-MM-DD'),
             T.GAMEID,
             NVL(T.ORIGINALCOOPID, '-1') CHANNELID,
             /*T.VERSION,*/
             'all' GAMEVERSION,
             NULL,
             T.UUID,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL
        FROM DX_SDK_CONN_ANDR_OPEN T
       WHERE T.GAMEID = 100178
         AND T.THEDATE >= TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD')
         AND T.THEDATE <
             TO_CHAR(TRUNC(SYSDATE - INPUTDATE + 1), 'YYYY-MM-DD');
    COMMIT;
  
  END PROC_LOCAL_TO_BI_100178_LOGIN;

  PROCEDURE PROC_LOCAL_TO_BI_100178_PAY(INPUTDATE IN NUMBER) AS
  BEGIN
    DELETE FROM T_DW_100178_PAY T
     WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
       AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    --�����⾵�������������ݵ�BI
    INSERT /*+APPEND */
    INTO T_DW_100178_PAY NOLOGGING
      (F_LOGTIME,
       T_LOGTIME,
       APPID,
       CHANNELID,
       GAMEVERSION,
       DVID,
       ACCOUNTID,
       SERVERID,
       LOGTYPE,
       ORDERID,
       IAPID,
       CURRENCYTYPE,
       PAYCHANNEL,
       CAMOUNT,
       VCAMOUNT,
       REASON,
       IPADDR)
      SELECT T.F_LOGTIME,
             T.F_LOGTIME,
             T.APPID,
             NVL(T.CHANNELID, '-1') CHANNELID,
             /*T.GAMEVERSION,*/
             'all' GAMEVERSION,
             T.DVID,
             T.USERID,
             NULL,
             'payrequest',
             T.ORDERID,
             NULL,
             NULL,
             NULL,
             T.PRICE / 100 PRICE,
             NULL,
             NULL,
             T.IP
        FROM T_DW_100178_LOGIN_PAY_F3 T
       WHERE LOWER(T.LOGTYPE) = 'purchase'
         AND T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    INSERT /*+APPEND */
    INTO T_DW_100178_PAY NOLOGGING
      (F_LOGTIME,
       T_LOGTIME,
       APPID,
       CHANNELID,
       GAMEVERSION,
       DVID,
       ACCOUNTID,
       SERVERID,
       LOGTYPE,
       ORDERID,
       IAPID,
       CURRENCYTYPE,
       PAYCHANNEL,
       CAMOUNT,
       VCAMOUNT,
       REASON,
       IPADDR)
      SELECT T.F_LOGTIME,
             T.F_LOGTIME,
             T.APPID,
             NVL(T.CHANNELID, '-1') CHANNELID,
             /*T.GAMEVERSION,*/
             'all' GAMEVERSION,
             T.DVID,
             T.USERID,
             NULL,
             'paysucc',
             T.ORDERID,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             T.IP
        FROM T_DW_100178_LOGIN_PAY_F3 T
       WHERE LOWER(T.LOGTYPE) = 'purchase'
         AND T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    --���ر��ظ������ݵ�BI
    INSERT /*+APPEND */
    INTO T_DW_100178_PAY NOLOGGING
      (F_LOGTIME,
       T_LOGTIME,
       APPID,
       CHANNELID,
       GAMEVERSION,
       DVID,
       ACCOUNTID,
       SERVERID,
       LOGTYPE,
       ORDERID,
       IAPID,
       CURRENCYTYPE,
       PAYCHANNEL,
       CAMOUNT,
       VCAMOUNT,
       REASON,
       IPADDR)
      SELECT T.ORDERSTARTTIME,
             T.ORDERSTARTTIME,
             T.APPID,
             NVL(T.CHANNELID, '-1') CHANNELID,
             /*NULL,*/
             'all' GAMEVERSION,
             NULL,
             T.UUID_OLD,
             NULL,
             'payrequest',
             T.ORDERID,
             NULL,
             NULL,
             NULL,
             T.RECHARGEAMT / 100 CAMOUNT,
             NULL,
             NULL,
             NULL
        FROM DX_SDK_ORDER_ANDR_OPEN T
       WHERE T.APPID = '100178'
         AND T.ORDERENDTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.ORDERENDTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    INSERT /*+APPEND */
    INTO T_DW_100178_PAY NOLOGGING
      (F_LOGTIME,
       T_LOGTIME,
       APPID,
       CHANNELID,
       GAMEVERSION,
       DVID,
       ACCOUNTID,
       SERVERID,
       LOGTYPE,
       ORDERID,
       IAPID,
       CURRENCYTYPE,
       PAYCHANNEL,
       CAMOUNT,
       VCAMOUNT,
       REASON,
       IPADDR)
      SELECT T.ORDERENDTIME,
             T.ORDERENDTIME,
             T.APPID,
             NVL(T.CHANNELID, '-1') CHANNELID,
             /*NULL,*/
             'all' GAMEVERSION,
             NULL,
             T.UUID_OLD,
             NULL,
             'paysucc',
             T.ORDERID,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL,
             NULL
        FROM DX_SDK_ORDER_ANDR_OPEN T
       WHERE T.APPID = '100178'
         AND T.ORDERENDTIME >= TRUNC(SYSDATE - INPUTDATE)
         AND T.ORDERENDTIME < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
  END PROC_LOCAL_TO_BI_100178_PAY;

END PKG_OPEN_TO_BISOURCE_100178;
/

prompt
prompt Creating package body PKG_OPEN_TO_BI_100178
prompt ===========================================
prompt
CREATE OR REPLACE PACKAGE BODY PKG_OPEN_TO_BI_100178 IS

  PROCEDURE P_NEW_INS IS

    CURSOR CUR IS
      SELECT *
        FROM DIM_DAY T
       WHERE T.DAY_DES BETWEEN '2014-12-23' AND '2015-01-02'
       ORDER BY T.DAYID;

    V_ERRORCODE    NUMBER;
    V_ERRORSTR     VARCHAR2(2000);
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������

  BEGIN
    V_ERRSOURCE := 'PKG_OPEN_TO_BI_100178.P_NEW_INS';
    FOR C IN CUR LOOP
      PKG_BASE_DATA_100178.SP_ALL(C.DAY_DES, V_ERRORCODE, V_ERRORSTR);
      PKG_FACT_100178.P_ALL(C.DAY_DES, V_ERRORCODE, V_ERRORSTR);
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      V_ERRORCODE    := 8100;
      V_ERRORSTR     := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_100178_CONN_MAC';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100178');
  END;
END PKG_OPEN_TO_BI_100178;
/

prompt
prompt Creating package body PKG_OPEN_TO_BI_100179
prompt ===========================================
prompt
CREATE OR REPLACE PACKAGE BODY PKG_OPEN_TO_BI_100179 IS

  PROCEDURE P_HIS_INS IS
  
    CURSOR CUR IS
      SELECT *
        FROM DIM_DAY T
       WHERE T.DAY_DES BETWEEN '2015-01-19' AND '2015-01-19'
       ORDER BY T.DAYID;
  
    V_ERRORCODE    NUMBER;
    V_ERRORSTR     VARCHAR2(2000);
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
  
  BEGIN
    V_ERRORCODE := 8100;
    V_ERRORSTR  := 'null';
  
    V_ERRSOURCE := 'PKG_OPEN_TO_BI_100179.P_HIS_INS';
    FOR C IN CUR LOOP
      PKG_BASE_DATA_100179.SP_ORDER(C.DAY_DES, V_ERRORCODE, V_ERRORSTR);
      PKG_BASE_DATA_100179.SP_NU_PAY(C.DAY_DES, V_ERRORCODE, V_ERRORSTR);
      PKG_BASE_DATA_100179.SP_CONN_ACT(C.DAY_DES, V_ERRORCODE, V_ERRORSTR);
      PKG_BASE_DATA_100179.SP_LOST(C.DAY_DES, V_ERRORCODE, V_ERRORSTR);
      PKG_FACT_100179.P_ALL(C.DAY_DES, V_ERRORCODE, V_ERRORSTR);
    END LOOP;
  
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      V_ERRORCODE    := 8100;
      V_ERRORSTR     := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_100179_CONN_MAC';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100179');
  END;
END PKG_OPEN_TO_BI_100179;
/

prompt
prompt Creating package body PKG_OPEN_TO_BI_3_100138
prompt =============================================
prompt
CREATE OR REPLACE PACKAGE BODY PKG_OPEN_TO_BI_3_100138 IS

  PROCEDURE P_HIS_INS IS
  
    CURSOR CUR IS
      SELECT *
        FROM DIM_DAY T
       WHERE T.DAY_DES BETWEEN '2015-02-06' AND '2015-02-10'
       ORDER BY T.DAYID;
  
    V_ERRORCODE    NUMBER;
    V_ERRORSTR     VARCHAR2(2000);
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_DAY_DES      VARCHAR2(20);
  
  BEGIN
    V_ERRSOURCE := 'Pkg_Open_To_Bi.p_His_Ins';
  
    FOR C IN CUR LOOP
      V_DAY_DES := C.DAY_DES || ' 23';
    
      /*PKG_BASE_DATA_100138.SP_CONN_ACT(V_DAY_DES, V_ERRORCODE, V_ERRORSTR);
      \*PKG_BASE_DATA_100138.SP_LOST(V_DAY_DES, V_ERRORCODE, V_ERRORSTR);*\
      PKG_FACT_100138.P_FACT_GENERAL(V_DAY_DES, V_ERRORCODE, V_ERRORSTR);
      PKG_FACT_100138.P_FACT_REMAIN(V_DAY_DES, V_ERRORCODE, V_ERRORSTR);
      \*PKG_FACT_100138.P_FACT_LOST(V_DAY_DES, V_ERRORCODE, V_ERRORSTR);*\
      PKG_FACT_100138.P_FACT_GENERAL_LEVEL(V_DAY_DES,
                                           V_ERRORCODE,
                                           V_ERRORSTR);
      \*PKG_FACT_100138.P_FACT_BACK(V_DAY_DES, V_ERRORCODE, V_ERRORSTR);*\
      PKG_FACT_100138.P_FACT_SUM_REP(V_DAY_DES, V_ERRORCODE, V_ERRORSTR);*/
      PKG_BASE_DATA_100138.SP_ALL(V_DAY_DES, V_ERRORCODE, V_ERRORSTR);
      PKG_FACT_100138.P_ALL(V_DAY_DES, V_ERRORCODE, V_ERRORSTR);
    END LOOP;
  
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      V_ERRORCODE    := 8100;
      V_ERRORSTR     := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_100138_CONN_MAC';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100138');
  END P_HIS_INS;
END PKG_OPEN_TO_BI_3_100138;
/

prompt
prompt Creating package body PKG_OPERATOR_INCOME_STAT
prompt ==============================================
prompt
CREATE OR REPLACE PACKAGE BODY PKG_OPERATOR_INCOME_STAT IS

  -- AUTHOR  : degnwenbo
  -- CREATED : 2015-02-02 13:52:00
  -- PURPOSE : �����ĸ���Ӫ����������
  --������Ӫ����������
  PROCEDURE SP_OPERATOR_INCOME(P_LOGTIME IN VARCHAR2,
                               P_ERRCODE OUT NUMBER,
                               P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    INPUTDATE      NUMBER;
  
  BEGIN
    INPUTDATE := 0;
    P_ERRCODE := 7100;
  
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO INPUTDATE
      FROM DUAL;
  
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_OPERATOR_INCOME_STAT.SP_OPERATOR_INCOME';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, 'OPERATOR', INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    V_ERRPOSITION := '1-1';
    DELETE FROM T_TEMPLATE_INCOME T
     WHERE T.THEDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
    COMMIT;
  
    --���ص�������
    V_ERRPOSITION := '1-2';
    INSERT INTO T_TEMPLATE_INCOME
      SELECT TO_CHAR(T.THEDATE, 'YYYY-MM-DD') THEDATE,
             CASE
               WHEN INSTR(T.GAMENAME, '��ŭ��С��') > 0 AND
                    INSTR(T.GAMENAME, '���껪') > 0 THEN
                '��ŭ��С����껪'
               WHEN INSTR(T.GAMENAME, '������Ӵ�ը') > 0 THEN
                '������Ӵ�ը'
               ELSE
                T.GAMENAME
             END GAMENAME,
             'TELECOM' OPERATORCODE,
             '����' OPERATORNAME,
             '' CHANNELID,
             T.CHANNELNAME,
             T.DOWNLOADUSERS,
             T.PAYUSERS,
             T.INCOME
        FROM T_DW_TEMPLATE_TELECOM T
       WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
         AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    --������ͨ����
    V_ERRPOSITION := '1-3';
    INSERT INTO T_TEMPLATE_INCOME
      SELECT TO_CHAR(T.THEDATE, 'YYYY-MM-DD') THEDATE,
             CASE
               WHEN INSTR(T.APPNAME, '��ŭ��С��') > 0 AND
                    INSTR(T.APPNAME, '���껪') > 0 THEN
                '��ŭ��С����껪'
               WHEN INSTR(T.APPNAME, '������Ӵ�ը') > 0 THEN
                '������Ӵ�ը'
               ELSE
                T.APPNAME
             END APPNAME,
             'UNICOM' OPERATORCODE,
             '��ͨ' OPERATORNAME,
             '' CHANNELID,
             T.CHANNELNAME,
             NULL ACTIVEUSERS,
             NULL PAYUSERS,
             T.INCOME
        FROM T_DW_TEMPLATE_UNICOM T
       WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
         AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    --�����ƶ�mm����
    V_ERRPOSITION := '1-4';
    INSERT INTO T_TEMPLATE_INCOME
      SELECT TO_CHAR(T.THEDATE, 'YYYY-MM-DD') THEDATE,
             CASE
               WHEN INSTR(T.APPNAME, '��ŭ��С��') > 0 AND
                    INSTR(T.APPNAME, '���껪') > 0 THEN
                '��ŭ��С����껪'
               WHEN INSTR(T.APPNAME, '������Ӵ�ը') > 0 THEN
                '������Ӵ�ը'
               ELSE
                T.APPNAME
             END APPNAME,
             'MM' OPERATORCODE,
             '�ƶ�MM' OPERATORNAME,
             T.CHANNELID,
             T.CHANNELNAME,
             T.NEWUSERS,
             T.PAYUSERS,
             T.PAYAMOUNT
        FROM T_DW_TEMPLATE_MM T
       WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
         AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    --�����ƶ���������
    V_ERRPOSITION := '1-5';
    INSERT INTO T_TEMPLATE_INCOME
      SELECT TO_CHAR(T.THEDATE, 'YYYY-MM-DD') THEDATE,
             CASE
               WHEN INSTR(T.APPNAME, '��ŭ��С��') > 0 AND
                    INSTR(T.APPNAME, '���껪') > 0 THEN
                '��ŭ��С����껪'
               WHEN INSTR(T.APPNAME, '������Ӵ�ը') > 0 THEN
                '������Ӵ�ը'
               ELSE
                T.APPNAME
             END APPNAME,
             'MB' OPERATORCODE,
             '�ƶ�����' OPERATORNAME,
             T.CHANNEL_COMPANYID,
             T.CHANNEL_COMPANYNAME,
             T.PLA_SDK_DOWNLOADUSERS,
             T.PAYUSERS,
             T.INCOME
        FROM T_DW_TEMPLATE_MB T
       WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
         AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;
  
    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, 'OPERATOR', INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_TEMPLATE_INCOME';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           'OPERATOR');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, 'INCOME', INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  
  END SP_OPERATOR_INCOME;

END PKG_OPERATOR_INCOME_STAT;
/


spool off
