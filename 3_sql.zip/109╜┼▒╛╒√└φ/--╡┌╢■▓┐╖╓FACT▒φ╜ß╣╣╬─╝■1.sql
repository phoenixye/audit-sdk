------------------------------------------------------------
-- Export file for user DEVELOPER@BI_RACDB1_111.13.20.109 --
-- Created by Administrator on 2015/5/20, 12:02:55 ---------
------------------------------------------------------------

set define off
spool --�ڶ�����FACT���ṹ�ļ�1.log

prompt
prompt Creating table FACT_100091_BACK_MAC
prompt ===================================
prompt
create table FACT_100091_BACK_MAC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_BACK_MAC
  is '�豸����������';
comment on column FACT_100091_BACK_MAC.statdate
  is 'ͳ������';
comment on column FACT_100091_BACK_MAC.channelid
  is '����ID';
comment on column FACT_100091_BACK_MAC.serverid
  is '����ID';
comment on column FACT_100091_BACK_MAC.appid
  is '��ƷID';
comment on column FACT_100091_BACK_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100091_BACK_MAC.back_conn
  is '��Ծ�豸������';
comment on column FACT_100091_BACK_MAC.back_pay
  is '�����豸������';
comment on column FACT_100091_BACK_MAC.data_source
  is '����Դ';
create index IDX1_100091 on FACT_100091_BACK_MAC (CHANNELID);
create index IDX2_100091 on FACT_100091_BACK_MAC (SERVERID);
create index IDX3_100091 on FACT_100091_BACK_MAC (STATDATE);

prompt
prompt Creating table FACT_100091_BACK_MAC_MONTH
prompt =========================================
prompt
create table FACT_100091_BACK_MAC_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_BACK_MAC_MONTH
  is '�豸����������';
comment on column FACT_100091_BACK_MAC_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100091_BACK_MAC_MONTH.channelid
  is '����ID';
comment on column FACT_100091_BACK_MAC_MONTH.serverid
  is '����ID';
comment on column FACT_100091_BACK_MAC_MONTH.appid
  is '��ƷID';
comment on column FACT_100091_BACK_MAC_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100091_BACK_MAC_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100091_BACK_MAC_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100091_BACK_MAC_MONTH.data_source
  is '����Դ';
create index IDX4_100091 on FACT_100091_BACK_MAC_MONTH (CHANNELID);
create index IDX5_100091 on FACT_100091_BACK_MAC_MONTH (SERVERID);
create index IDX6_100091 on FACT_100091_BACK_MAC_MONTH (STATDATE);

prompt
prompt Creating table FACT_100091_BACK_MAC_WEEK
prompt ========================================
prompt
create table FACT_100091_BACK_MAC_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_BACK_MAC_WEEK
  is '�豸����������';
comment on column FACT_100091_BACK_MAC_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100091_BACK_MAC_WEEK.channelid
  is '����ID';
comment on column FACT_100091_BACK_MAC_WEEK.serverid
  is '����ID';
comment on column FACT_100091_BACK_MAC_WEEK.appid
  is '��ƷID';
comment on column FACT_100091_BACK_MAC_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100091_BACK_MAC_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100091_BACK_MAC_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100091_BACK_MAC_WEEK.data_source
  is '����Դ';
create index IDX7_100091 on FACT_100091_BACK_MAC_WEEK (CHANNELID);
create index IDX8_100091 on FACT_100091_BACK_MAC_WEEK (SERVERID);
create index IDX9_100091 on FACT_100091_BACK_MAC_WEEK (STATDATE);

prompt
prompt Creating table FACT_100091_BACK_USER
prompt ====================================
prompt
create table FACT_100091_BACK_USER
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_BACK_USER
  is '�û�����������';
comment on column FACT_100091_BACK_USER.statdate
  is 'ͳ������';
comment on column FACT_100091_BACK_USER.channelid
  is '����ID';
comment on column FACT_100091_BACK_USER.serverid
  is '����ID';
comment on column FACT_100091_BACK_USER.appid
  is '��ƷID';
comment on column FACT_100091_BACK_USER.lost_days
  is '��ʧ����';
comment on column FACT_100091_BACK_USER.back_conn
  is '��Ծ�û�������';
comment on column FACT_100091_BACK_USER.back_pay
  is '�����û�������';
comment on column FACT_100091_BACK_USER.data_source
  is '����Դ';
create index IDX16_100091 on FACT_100091_BACK_USER (CHANNELID);
create index IDX17_100091 on FACT_100091_BACK_USER (SERVERID);
create index IDX18_100091 on FACT_100091_BACK_USER (STATDATE);

prompt
prompt Creating table FACT_100091_BACK_USER_MONTH
prompt ==========================================
prompt
create table FACT_100091_BACK_USER_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_BACK_USER_MONTH
  is '�豸����������';
comment on column FACT_100091_BACK_USER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100091_BACK_USER_MONTH.channelid
  is '����ID';
comment on column FACT_100091_BACK_USER_MONTH.serverid
  is '����ID';
comment on column FACT_100091_BACK_USER_MONTH.appid
  is '��ƷID';
comment on column FACT_100091_BACK_USER_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100091_BACK_USER_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100091_BACK_USER_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100091_BACK_USER_MONTH.data_source
  is '����Դ';
create index IDX13_100091 on FACT_100091_BACK_USER_MONTH (CHANNELID);
create index IDX14_100091 on FACT_100091_BACK_USER_MONTH (SERVERID);
create index IDX15_100091 on FACT_100091_BACK_USER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100091_BACK_USER_WEEK
prompt =========================================
prompt
create table FACT_100091_BACK_USER_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_BACK_USER_WEEK
  is '�豸����������';
comment on column FACT_100091_BACK_USER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100091_BACK_USER_WEEK.channelid
  is '����ID';
comment on column FACT_100091_BACK_USER_WEEK.serverid
  is '����ID';
comment on column FACT_100091_BACK_USER_WEEK.appid
  is '��ƷID';
comment on column FACT_100091_BACK_USER_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100091_BACK_USER_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100091_BACK_USER_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100091_BACK_USER_WEEK.data_source
  is '����Դ';
create index IDX10_100091 on FACT_100091_BACK_USER_WEEK (CHANNELID);
create index IDX11_100091 on FACT_100091_BACK_USER_WEEK (SERVERID);
create index IDX12_100091 on FACT_100091_BACK_USER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100091_CEVENT
prompt =================================
prompt
create table FACT_100091_CEVENT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  eventkey    VARCHAR2(50),
  eventcount  NUMBER,
  eventnum    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_CEVENT
  is '�Զ��������';
comment on column FACT_100091_CEVENT.statdate
  is 'ͳ������';
comment on column FACT_100091_CEVENT.channelid
  is '����';
comment on column FACT_100091_CEVENT.serverid
  is '����';
comment on column FACT_100091_CEVENT.appid
  is '��Ʒid';
comment on column FACT_100091_CEVENT.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100091_CEVENT.eventcount
  is '�¼��û���';
comment on column FACT_100091_CEVENT.eventnum
  is '�¼�����';
comment on column FACT_100091_CEVENT.data_source
  is '������Դ';
create index IDX181_100091 on FACT_100091_CEVENT (CHANNELID);
create index IDX182_100091 on FACT_100091_CEVENT (SERVERID);
create index IDX183_100091 on FACT_100091_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100091_CEVENT_PAR
prompt =====================================
prompt
create table FACT_100091_CEVENT_PAR
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  ilevel         NUMBER,
  eventkey       VARCHAR2(100),
  eventpar_key   VARCHAR2(100),
  eventpar_value VARCHAR2(100),
  eventcount     NUMBER,
  eventnum       NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100091_CEVENT_PAR
  is '�Զ������������';
comment on column FACT_100091_CEVENT_PAR.statdate
  is 'ͳ������';
comment on column FACT_100091_CEVENT_PAR.channelid
  is '����';
comment on column FACT_100091_CEVENT_PAR.serverid
  is '����';
comment on column FACT_100091_CEVENT_PAR.appid
  is '��Ʒid';
comment on column FACT_100091_CEVENT_PAR.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_CEVENT_PAR.ilevel
  is '��ɫ�ȼ�';
comment on column FACT_100091_CEVENT_PAR.eventkey
  is '�¼�����';
comment on column FACT_100091_CEVENT_PAR.eventpar_key
  is '�¼�����';
comment on column FACT_100091_CEVENT_PAR.eventpar_value
  is '�¼�����ֵ';
comment on column FACT_100091_CEVENT_PAR.eventcount
  is '�¼��û���';
comment on column FACT_100091_CEVENT_PAR.eventnum
  is '�¼�����';
comment on column FACT_100091_CEVENT_PAR.data_source
  is '������Դ';
create index IDX185_100091 on FACT_100091_CEVENT_PAR (CHANNELID);
create index IDX186_100091 on FACT_100091_CEVENT_PAR (SERVERID);
create index IDX187_100091 on FACT_100091_CEVENT_PAR (STATDATE);

prompt
prompt Creating table FACT_100091_COMP_CEVENT
prompt ======================================
prompt
create table FACT_100091_COMP_CEVENT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(10),
  channelid   VARCHAR2(50),
  gameversion VARCHAR2(50),
  serverid    VARCHAR2(50),
  ilevel      NUMBER,
  eventkey    VARCHAR2(100),
  compid      VARCHAR2(50),
  caltype     VARCHAR2(50),
  dimpars     VARCHAR2(2000),
  comp_data   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_COMP_CEVENT
  is '�Զ����¼���Ϸ�����';
comment on column FACT_100091_COMP_CEVENT.statdate
  is '����';
comment on column FACT_100091_COMP_CEVENT.appid
  is '��Ϸ�� appid';
comment on column FACT_100091_COMP_CEVENT.channelid
  is '���� ID';
comment on column FACT_100091_COMP_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column FACT_100091_COMP_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column FACT_100091_COMP_CEVENT.ilevel
  is '��ҵȼ�';
comment on column FACT_100091_COMP_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100091_COMP_CEVENT.compid
  is '��ϼ����¼�ID';
comment on column FACT_100091_COMP_CEVENT.caltype
  is '��ϼ����¼���������';
comment on column FACT_100091_COMP_CEVENT.dimpars
  is '��ϲ���';
comment on column FACT_100091_COMP_CEVENT.comp_data
  is '��ϼ�����';
create index IDX184_100091 on FACT_100091_COMP_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100091_DAILY_REPORT
prompt =======================================
prompt
create table FACT_100091_DAILY_REPORT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_DAILY_REPORT
  is '�ձ�����';
comment on column FACT_100091_DAILY_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100091_DAILY_REPORT.appid
  is '��ƷID';
comment on column FACT_100091_DAILY_REPORT.channelid
  is '����';
comment on column FACT_100091_DAILY_REPORT.serverid
  is '����';
comment on column FACT_100091_DAILY_REPORT.indexid
  is 'ָ��';
comment on column FACT_100091_DAILY_REPORT.indtype
  is 'ָ������';
comment on column FACT_100091_DAILY_REPORT.rpt_data
  is '����';
create index IDX176_100091 on FACT_100091_DAILY_REPORT (STATDATE);

prompt
prompt Creating table FACT_100091_DVID
prompt ===============================
prompt
create table FACT_100091_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_model  VARCHAR2(200),
  dvid_res    VARCHAR2(50),
  dvid_os     VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_DVID
  is '�豸������';
comment on column FACT_100091_DVID.statdate
  is 'ͳ������';
comment on column FACT_100091_DVID.channelid
  is '����';
comment on column FACT_100091_DVID.serverid
  is '����';
comment on column FACT_100091_DVID.appid
  is '��Ʒid';
comment on column FACT_100091_DVID.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_DVID.dvid_model
  is '����';
comment on column FACT_100091_DVID.dvid_res
  is '�豸�ֱ���';
comment on column FACT_100091_DVID.dvid_os
  is '�豸����ϵͳ';
comment on column FACT_100091_DVID.newcount
  is '�����û���';
comment on column FACT_100091_DVID.conncount
  is '�����û���';
comment on column FACT_100091_DVID.data_source
  is '������Դ';
create index IDX19_100091 on FACT_100091_DVID (CHANNELID);
create index IDX20_100091 on FACT_100091_DVID (SERVERID);
create index IDX21_100091 on FACT_100091_DVID (STATDATE);

prompt
prompt Creating table FACT_100091_FIRSTPAY
prompt ===================================
prompt
create table FACT_100091_FIRSTPAY
(
  statdate         VARCHAR2(10),
  firstpaydate     VARCHAR2(10),
  channelid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  datatype         VARCHAR2(50),
  appid            VARCHAR2(50),
  first_payfromreg NUMBER,
  first_paycount   NUMBER,
  payamount        NUMBER,
  loaddate         DATE default SYSDATE,
  data_source      VARCHAR2(100)
)
;
comment on table FACT_100091_FIRSTPAY
  is '�����û��״γ�ֵ������';
comment on column FACT_100091_FIRSTPAY.statdate
  is 'ͳ������';
comment on column FACT_100091_FIRSTPAY.firstpaydate
  is '�״θ�������';
comment on column FACT_100091_FIRSTPAY.channelid
  is '����';
comment on column FACT_100091_FIRSTPAY.serverid
  is '����';
comment on column FACT_100091_FIRSTPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100091_FIRSTPAY.appid
  is '��Ʒid';
comment on column FACT_100091_FIRSTPAY.first_payfromreg
  is 'ע���ڼ��쿪ʼ��ֵ(1��2��..7..30..)';
comment on column FACT_100091_FIRSTPAY.first_paycount
  is '���������û���';
comment on column FACT_100091_FIRSTPAY.payamount
  is '�ۼƵ��ڼ���ĳ�ֵ�ܶ�';
comment on column FACT_100091_FIRSTPAY.data_source
  is '������Դ';
create index IDX22_100091 on FACT_100091_FIRSTPAY (CHANNELID);
create index IDX23_100091 on FACT_100091_FIRSTPAY (SERVERID);
create index IDX24_100091 on FACT_100091_FIRSTPAY (STATDATE);

prompt
prompt Creating table FACT_100091_FIRSTPAY_AMOUNT
prompt ==========================================
prompt
create table FACT_100091_FIRSTPAY_AMOUNT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_FIRSTPAY_AMOUNT
  is '�״θ��ѽ�������';
comment on column FACT_100091_FIRSTPAY_AMOUNT.statdate
  is 'ͳ������';
comment on column FACT_100091_FIRSTPAY_AMOUNT.channelid
  is '����';
comment on column FACT_100091_FIRSTPAY_AMOUNT.serverid
  is '��������';
comment on column FACT_100091_FIRSTPAY_AMOUNT.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100091_FIRSTPAY_AMOUNT.appid
  is '��Ʒid';
comment on column FACT_100091_FIRSTPAY_AMOUNT.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_FIRSTPAY_AMOUNT.payamount
  is '�״θ��ѽ��';
comment on column FACT_100091_FIRSTPAY_AMOUNT.paycount
  is '�״θ��ѽ���Ӧ������';
create index IDX25_100091 on FACT_100091_FIRSTPAY_AMOUNT (CHANNELID);
create index IDX26_100091 on FACT_100091_FIRSTPAY_AMOUNT (SERVERID);
create index IDX27_100091 on FACT_100091_FIRSTPAY_AMOUNT (STATDATE);

prompt
prompt Creating table FACT_100091_GENERAL_DAY
prompt ======================================
prompt
create table FACT_100091_GENERAL_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_GENERAL_DAY
  is '�ջ���������';
comment on column FACT_100091_GENERAL_DAY.statdate
  is 'ͳ������';
comment on column FACT_100091_GENERAL_DAY.channelid
  is '����';
comment on column FACT_100091_GENERAL_DAY.serverid
  is '����';
comment on column FACT_100091_GENERAL_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100091_GENERAL_DAY.appid
  is '��Ʒid';
comment on column FACT_100091_GENERAL_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_GENERAL_DAY.newcount
  is '������';
comment on column FACT_100091_GENERAL_DAY.conncount
  is '������';
comment on column FACT_100091_GENERAL_DAY.paycount
  is '������';
comment on column FACT_100091_GENERAL_DAY.payamount
  is '���ѽ��';
comment on column FACT_100091_GENERAL_DAY.data_source
  is '������Դ';
create index IDX28_100091 on FACT_100091_GENERAL_DAY (CHANNELID);
create index IDX29_100091 on FACT_100091_GENERAL_DAY (SERVERID);
create index IDX30_100091 on FACT_100091_GENERAL_DAY (STATDATE);

prompt
prompt Creating table FACT_100091_GENERAL_DAY_DVID
prompt ===========================================
prompt
create table FACT_100091_GENERAL_DAY_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_GENERAL_DAY_DVID
  is '���豸����������';
comment on column FACT_100091_GENERAL_DAY_DVID.statdate
  is 'ͳ������';
comment on column FACT_100091_GENERAL_DAY_DVID.channelid
  is '����';
comment on column FACT_100091_GENERAL_DAY_DVID.appid
  is '��Ʒid';
comment on column FACT_100091_GENERAL_DAY_DVID.newcount
  is '������';
comment on column FACT_100091_GENERAL_DAY_DVID.conncount
  is '������';
comment on column FACT_100091_GENERAL_DAY_DVID.data_source
  is '������Դ';
create index IDX31_100091 on FACT_100091_GENERAL_DAY_DVID (CHANNELID);
create index IDX33_100091 on FACT_100091_GENERAL_DAY_DVID (STATDATE);

prompt
prompt Creating table FACT_100091_GENERAL_HOUR
prompt =======================================
prompt
create table FACT_100091_GENERAL_HOUR
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_GENERAL_HOUR
  is 'Сʱ����������';
comment on column FACT_100091_GENERAL_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100091_GENERAL_HOUR.channelid
  is '����';
comment on column FACT_100091_GENERAL_HOUR.serverid
  is '����';
comment on column FACT_100091_GENERAL_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100091_GENERAL_HOUR.appid
  is '��Ʒid';
comment on column FACT_100091_GENERAL_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_GENERAL_HOUR.newcount
  is '������';
comment on column FACT_100091_GENERAL_HOUR.conncount
  is '������';
comment on column FACT_100091_GENERAL_HOUR.paycount
  is '������';
comment on column FACT_100091_GENERAL_HOUR.payamount
  is '���ѽ��';
comment on column FACT_100091_GENERAL_HOUR.data_source
  is '������Դ';
create index IDX34_100091 on FACT_100091_GENERAL_HOUR (CHANNELID);
create index IDX35_100091 on FACT_100091_GENERAL_HOUR (SERVERID);
create index IDX36_100091 on FACT_100091_GENERAL_HOUR (STATDATE);

prompt
prompt Creating table FACT_100091_GENERAL_HOUR_DVID
prompt ============================================
prompt
create table FACT_100091_GENERAL_HOUR_DVID
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_GENERAL_HOUR_DVID
  is 'Сʱ�豸����������';
comment on column FACT_100091_GENERAL_HOUR_DVID.statdate
  is 'ͳ������';
comment on column FACT_100091_GENERAL_HOUR_DVID.channelid
  is '����';
comment on column FACT_100091_GENERAL_HOUR_DVID.appid
  is '��Ʒid';
comment on column FACT_100091_GENERAL_HOUR_DVID.newcount
  is '������';
comment on column FACT_100091_GENERAL_HOUR_DVID.conncount
  is '������';
comment on column FACT_100091_GENERAL_HOUR_DVID.data_source
  is '������Դ';
create index IDX37_100091 on FACT_100091_GENERAL_HOUR_DVID (CHANNELID);
create index IDX39_100091 on FACT_100091_GENERAL_HOUR_DVID (STATDATE);

prompt
prompt Creating table FACT_100091_GENERAL_LEVEL
prompt ========================================
prompt
create table FACT_100091_GENERAL_LEVEL
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  rolelevel   NUMBER,
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_GENERAL_LEVEL
  is '�û��ȼ�������';
comment on column FACT_100091_GENERAL_LEVEL.statdate
  is 'ͳ������';
comment on column FACT_100091_GENERAL_LEVEL.channelid
  is '����';
comment on column FACT_100091_GENERAL_LEVEL.serverid
  is '����';
comment on column FACT_100091_GENERAL_LEVEL.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100091_GENERAL_LEVEL.appid
  is '��Ʒid';
comment on column FACT_100091_GENERAL_LEVEL.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_GENERAL_LEVEL.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100091_GENERAL_LEVEL.newcount
  is '������';
comment on column FACT_100091_GENERAL_LEVEL.conncount
  is '������';
comment on column FACT_100091_GENERAL_LEVEL.paycount
  is '������';
comment on column FACT_100091_GENERAL_LEVEL.payamount
  is '���ѽ��';
comment on column FACT_100091_GENERAL_LEVEL.data_source
  is '������Դ';
create index IDX40_100091 on FACT_100091_GENERAL_LEVEL (CHANNELID);
create index IDX41_100091 on FACT_100091_GENERAL_LEVEL (SERVERID);
create index IDX42_100091 on FACT_100091_GENERAL_LEVEL (STATDATE);

prompt
prompt Creating table FACT_100091_GENERAL_MONTH
prompt ========================================
prompt
create table FACT_100091_GENERAL_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_GENERAL_MONTH
  is '�»���������';
comment on column FACT_100091_GENERAL_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100091_GENERAL_MONTH.channelid
  is '����';
comment on column FACT_100091_GENERAL_MONTH.serverid
  is '����';
comment on column FACT_100091_GENERAL_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100091_GENERAL_MONTH.appid
  is '��Ʒid';
comment on column FACT_100091_GENERAL_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_GENERAL_MONTH.newcount
  is '������';
comment on column FACT_100091_GENERAL_MONTH.conncount
  is '������';
comment on column FACT_100091_GENERAL_MONTH.paycount
  is '������';
comment on column FACT_100091_GENERAL_MONTH.payamount
  is '���ѽ��';
comment on column FACT_100091_GENERAL_MONTH.data_source
  is '������Դ';
create index IDX43_100091 on FACT_100091_GENERAL_MONTH (CHANNELID);
create index IDX44_100091 on FACT_100091_GENERAL_MONTH (SERVERID);
create index IDX45_100091 on FACT_100091_GENERAL_MONTH (STATDATE);

prompt
prompt Creating table FACT_100091_GENERAL_MONTH_DVID
prompt =============================================
prompt
create table FACT_100091_GENERAL_MONTH_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_GENERAL_MONTH_DVID
  is '���豸����������';
comment on column FACT_100091_GENERAL_MONTH_DVID.statdate
  is 'ͳ������';
comment on column FACT_100091_GENERAL_MONTH_DVID.channelid
  is '����';
comment on column FACT_100091_GENERAL_MONTH_DVID.appid
  is '��Ʒid';
comment on column FACT_100091_GENERAL_MONTH_DVID.newcount
  is '������';
comment on column FACT_100091_GENERAL_MONTH_DVID.conncount
  is '������';
comment on column FACT_100091_GENERAL_MONTH_DVID.data_source
  is '������Դ';
create index IDX46_100091 on FACT_100091_GENERAL_MONTH_DVID (CHANNELID);
create index IDX48_100091 on FACT_100091_GENERAL_MONTH_DVID (STATDATE);

prompt
prompt Creating table FACT_100091_GENERAL_WEEK
prompt =======================================
prompt
create table FACT_100091_GENERAL_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_GENERAL_WEEK
  is '�ܻ���������';
comment on column FACT_100091_GENERAL_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100091_GENERAL_WEEK.channelid
  is '����';
comment on column FACT_100091_GENERAL_WEEK.serverid
  is '����';
comment on column FACT_100091_GENERAL_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100091_GENERAL_WEEK.appid
  is '��Ʒid';
comment on column FACT_100091_GENERAL_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_GENERAL_WEEK.newcount
  is '������';
comment on column FACT_100091_GENERAL_WEEK.conncount
  is '������';
comment on column FACT_100091_GENERAL_WEEK.paycount
  is '������';
comment on column FACT_100091_GENERAL_WEEK.payamount
  is '���ѽ��';
comment on column FACT_100091_GENERAL_WEEK.data_source
  is '������Դ';
create index IDX52_100091 on FACT_100091_GENERAL_WEEK (CHANNELID);
create index IDX53_100091 on FACT_100091_GENERAL_WEEK (SERVERID);
create index IDX54_100091 on FACT_100091_GENERAL_WEEK (STATDATE);

prompt
prompt Creating table FACT_100091_GENERAL_WEEK_DVID
prompt ============================================
prompt
create table FACT_100091_GENERAL_WEEK_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_GENERAL_WEEK_DVID
  is '���豸����������';
comment on column FACT_100091_GENERAL_WEEK_DVID.statdate
  is 'ͳ������';
comment on column FACT_100091_GENERAL_WEEK_DVID.channelid
  is '����';
comment on column FACT_100091_GENERAL_WEEK_DVID.appid
  is '��Ʒid';
comment on column FACT_100091_GENERAL_WEEK_DVID.newcount
  is '������';
comment on column FACT_100091_GENERAL_WEEK_DVID.conncount
  is '������';
comment on column FACT_100091_GENERAL_WEEK_DVID.data_source
  is '������Դ';
create index IDX49_100091 on FACT_100091_GENERAL_WEEK_DVID (CHANNELID);
create index IDX51_100091 on FACT_100091_GENERAL_WEEK_DVID (STATDATE);

prompt
prompt Creating table FACT_100091_HOUR_REPORT
prompt ======================================
prompt
create table FACT_100091_HOUR_REPORT
(
  statdate    VARCHAR2(20),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_HOUR_REPORT
  is '�ձ�Сʱ����';
comment on column FACT_100091_HOUR_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100091_HOUR_REPORT.appid
  is '��ƷID';
comment on column FACT_100091_HOUR_REPORT.channelid
  is '����';
comment on column FACT_100091_HOUR_REPORT.serverid
  is '����';
comment on column FACT_100091_HOUR_REPORT.indexid
  is 'ָ��';
comment on column FACT_100091_HOUR_REPORT.indtype
  is 'ָ������';
comment on column FACT_100091_HOUR_REPORT.rpt_data
  is '����';

prompt
prompt Creating table FACT_100091_LEVELPAY
prompt ===================================
prompt
create table FACT_100091_LEVELPAY
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  datatype       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  rolelevel      NUMBER,
  paycount       NUMBER,
  first_paycount NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100091_LEVELPAY
  is '�û���ɫ�ȼ����ѷ�����';
comment on column FACT_100091_LEVELPAY.statdate
  is 'ͳ������';
comment on column FACT_100091_LEVELPAY.channelid
  is '����';
comment on column FACT_100091_LEVELPAY.serverid
  is '����';
comment on column FACT_100091_LEVELPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100091_LEVELPAY.appid
  is '��Ʒid';
comment on column FACT_100091_LEVELPAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_LEVELPAY.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100091_LEVELPAY.paycount
  is '�����û���';
comment on column FACT_100091_LEVELPAY.first_paycount
  is '���������û������״θ����û���';
comment on column FACT_100091_LEVELPAY.data_source
  is '������Դ';
create index IDX55_100091 on FACT_100091_LEVELPAY (CHANNELID);
create index IDX56_100091 on FACT_100091_LEVELPAY (SERVERID);
create index IDX57_100091 on FACT_100091_LEVELPAY (STATDATE);

prompt
prompt Creating table FACT_100091_LOST_MAC
prompt ===================================
prompt
create table FACT_100091_LOST_MAC
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_LOST_MAC
  is '�豸��ʧ������';
comment on column FACT_100091_LOST_MAC.statdate
  is 'ͳ������';
comment on column FACT_100091_LOST_MAC.lostdate
  is '��ʧ����';
comment on column FACT_100091_LOST_MAC.channelid
  is '����ID';
comment on column FACT_100091_LOST_MAC.serverid
  is '����ID';
comment on column FACT_100091_LOST_MAC.appid
  is '��ƷID';
comment on column FACT_100091_LOST_MAC.rolelevel
  is '��ʧʱ�ȼ�';
comment on column FACT_100091_LOST_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100091_LOST_MAC.lost_conn
  is '��Ծ�豸��ʧ';
comment on column FACT_100091_LOST_MAC.lost_pay
  is '�����豸��ʧ';
comment on column FACT_100091_LOST_MAC.data_source
  is '����Դ';
create index IDX58_100091 on FACT_100091_LOST_MAC (CHANNELID);
create index IDX59_100091 on FACT_100091_LOST_MAC (SERVERID);
create index IDX60_100091 on FACT_100091_LOST_MAC (STATDATE);

prompt
prompt Creating table FACT_100091_LOST_USER
prompt ====================================
prompt
create table FACT_100091_LOST_USER
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_LOST_USER
  is '�û���ʧ������';
comment on column FACT_100091_LOST_USER.statdate
  is 'ͳ������';
comment on column FACT_100091_LOST_USER.lostdate
  is '��ʧ����';
comment on column FACT_100091_LOST_USER.channelid
  is '����ID';
comment on column FACT_100091_LOST_USER.serverid
  is '����ID';
comment on column FACT_100091_LOST_USER.appid
  is '��ƷID';
comment on column FACT_100091_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column FACT_100091_LOST_USER.lost_days
  is '��ʧ����';
comment on column FACT_100091_LOST_USER.lost_conn
  is '��Ծ�û���ʧ';
comment on column FACT_100091_LOST_USER.lost_pay
  is '�����û���ʧ';
comment on column FACT_100091_LOST_USER.data_source
  is '����Դ';
create index IDX61_100091 on FACT_100091_LOST_USER (CHANNELID);
create index IDX62_100091 on FACT_100091_LOST_USER (SERVERID);
create index IDX63_100091 on FACT_100091_LOST_USER (STATDATE);

prompt
prompt Creating table FACT_100091_LTV_MAC
prompt ==================================
prompt
create table FACT_100091_LTV_MAC
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_LTV_MAC
  is '�豸LTV������';
comment on column FACT_100091_LTV_MAC.statdate
  is 'ͳ������';
comment on column FACT_100091_LTV_MAC.ltvdate
  is '��ֵ����';
comment on column FACT_100091_LTV_MAC.channelid
  is '����';
comment on column FACT_100091_LTV_MAC.serverid
  is '����';
comment on column FACT_100091_LTV_MAC.appid
  is '��Ʒid';
comment on column FACT_100091_LTV_MAC.ltv_days
  is 'ltv��';
comment on column FACT_100091_LTV_MAC.payamount
  is '���ѽ��';
comment on column FACT_100091_LTV_MAC.data_source
  is '������Դ';
create index IDX64_100091 on FACT_100091_LTV_MAC (CHANNELID);
create index IDX65_100091 on FACT_100091_LTV_MAC (SERVERID);
create index IDX66_100091 on FACT_100091_LTV_MAC (STATDATE);

prompt
prompt Creating table FACT_100091_LTV_USER
prompt ===================================
prompt
create table FACT_100091_LTV_USER
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_LTV_USER
  is '�û�LTV������';
comment on column FACT_100091_LTV_USER.statdate
  is 'ͳ������';
comment on column FACT_100091_LTV_USER.ltvdate
  is '��ֵ����';
comment on column FACT_100091_LTV_USER.channelid
  is '����';
comment on column FACT_100091_LTV_USER.serverid
  is '����';
comment on column FACT_100091_LTV_USER.appid
  is '��Ʒid';
comment on column FACT_100091_LTV_USER.ltv_days
  is 'ltv��';
comment on column FACT_100091_LTV_USER.payamount
  is '���ѽ��';
comment on column FACT_100091_LTV_USER.data_source
  is '������Դ';
create index IDX67_100091 on FACT_100091_LTV_USER (CHANNELID);
create index IDX68_100091 on FACT_100091_LTV_USER (SERVERID);
create index IDX69_100091 on FACT_100091_LTV_USER (STATDATE);

prompt
prompt Creating table FACT_100091_MISS_FIRST
prompt =====================================
prompt
create table FACT_100091_MISS_FIRST
(
  statdate        VARCHAR2(10),
  channelid       VARCHAR2(50),
  serverid        VARCHAR2(50),
  appid           VARCHAR2(50),
  versionid       VARCHAR2(50),
  missionid       VARCHAR2(50),
  rolelevel       NUMBER,
  rolejob         VARCHAR2(50) default '0',
  firstenter_succ NUMBER,
  firstenter_fail NUMBER,
  loaddate        DATE,
  data_source     VARCHAR2(100)
)
;
comment on table FACT_100091_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column FACT_100091_MISS_FIRST.statdate
  is 'ͳ������';
comment on column FACT_100091_MISS_FIRST.channelid
  is '����';
comment on column FACT_100091_MISS_FIRST.serverid
  is '����';
comment on column FACT_100091_MISS_FIRST.appid
  is '��ƷID';
comment on column FACT_100091_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_MISS_FIRST.missionid
  is '�ؿ�ID';
comment on column FACT_100091_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column FACT_100091_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column FACT_100091_MISS_FIRST.firstenter_succ
  is '��һ�ν���ؿ��ɹ���';
comment on column FACT_100091_MISS_FIRST.firstenter_fail
  is '��һ�ν���ؿ�ʧ����';
comment on column FACT_100091_MISS_FIRST.data_source
  is '������Դ';
create index IDX70_100091 on FACT_100091_MISS_FIRST (CHANNELID);
create index IDX71_100091 on FACT_100091_MISS_FIRST (SERVERID);
create index IDX72_100091 on FACT_100091_MISS_FIRST (STATDATE);

prompt
prompt Creating table FACT_100091_NET
prompt ==============================
prompt
create table FACT_100091_NET
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_net    VARCHAR2(50),
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_NET
  is '������ʽ������';
comment on column FACT_100091_NET.statdate
  is 'ͳ������';
comment on column FACT_100091_NET.channelid
  is '����';
comment on column FACT_100091_NET.serverid
  is '����';
comment on column FACT_100091_NET.appid
  is '��Ʒid';
comment on column FACT_100091_NET.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_NET.dvid_net
  is '������ʽ';
comment on column FACT_100091_NET.conncount
  is '������';
comment on column FACT_100091_NET.data_source
  is '������Դ';
create index IDX73_100091 on FACT_100091_NET (CHANNELID);
create index IDX74_100091 on FACT_100091_NET (SERVERID);
create index IDX75_100091 on FACT_100091_NET (STATDATE);

prompt
prompt Creating table FACT_100091_OPERATOR
prompt ===================================
prompt
create table FACT_100091_OPERATOR
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  dvid_operator VARCHAR2(50),
  conncount     NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100091_OPERATOR
  is '��Ӫ�̷�����';
comment on column FACT_100091_OPERATOR.statdate
  is 'ͳ������';
comment on column FACT_100091_OPERATOR.channelid
  is '����';
comment on column FACT_100091_OPERATOR.serverid
  is '����';
comment on column FACT_100091_OPERATOR.appid
  is '��Ʒid';
comment on column FACT_100091_OPERATOR.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_OPERATOR.dvid_operator
  is '������ʽ';
comment on column FACT_100091_OPERATOR.conncount
  is '������';
comment on column FACT_100091_OPERATOR.data_source
  is '������Դ';
create index IDX76_100091 on FACT_100091_OPERATOR (CHANNELID);
create index IDX77_100091 on FACT_100091_OPERATOR (SERVERID);
create index IDX78_100091 on FACT_100091_OPERATOR (STATDATE);

prompt
prompt Creating table FACT_100091_ORDER
prompt ================================
prompt
create table FACT_100091_ORDER
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100091_ORDER
  is '����������';
comment on column FACT_100091_ORDER.statdate
  is 'ͳ������';
comment on column FACT_100091_ORDER.channelid
  is '����';
comment on column FACT_100091_ORDER.serverid
  is '����';
comment on column FACT_100091_ORDER.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100091_ORDER.appid
  is '��Ʒid';
comment on column FACT_100091_ORDER.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_ORDER.paysucccount
  is '�ɹ�������';
comment on column FACT_100091_ORDER.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100091_ORDER.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100091_ORDER.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100091_ORDER.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100091_ORDER.payfailnum
  is '����ʧ������';
comment on column FACT_100091_ORDER.data_source
  is '������Դ';
create index IDX79_100091 on FACT_100091_ORDER (CHANNELID);
create index IDX80_100091 on FACT_100091_ORDER (SERVERID);
create index IDX81_100091 on FACT_100091_ORDER (STATDATE);

prompt
prompt Creating table FACT_100091_ORDER_HOUR
prompt =====================================
prompt
create table FACT_100091_ORDER_HOUR
(
  statdate      VARCHAR2(20),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100091_ORDER_HOUR
  is '����Сʱ������';
comment on column FACT_100091_ORDER_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100091_ORDER_HOUR.channelid
  is '����';
comment on column FACT_100091_ORDER_HOUR.serverid
  is '����';
comment on column FACT_100091_ORDER_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100091_ORDER_HOUR.appid
  is '��Ʒid';
comment on column FACT_100091_ORDER_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_ORDER_HOUR.paysucccount
  is '�ɹ�������';
comment on column FACT_100091_ORDER_HOUR.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100091_ORDER_HOUR.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100091_ORDER_HOUR.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100091_ORDER_HOUR.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100091_ORDER_HOUR.payfailnum
  is '����ʧ������';
comment on column FACT_100091_ORDER_HOUR.data_source
  is '������Դ';
create index IDX177_100091 on FACT_100091_ORDER_HOUR (CHANNELID);
create index IDX178_100091 on FACT_100091_ORDER_HOUR (SERVERID);
create index IDX179_100091 on FACT_100091_ORDER_HOUR (STATDATE);

prompt
prompt Creating table FACT_100091_ORDER_MONTH
prompt ======================================
prompt
create table FACT_100091_ORDER_MONTH
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100091_ORDER_MONTH
  is '�¶���������';
comment on column FACT_100091_ORDER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100091_ORDER_MONTH.channelid
  is '����';
comment on column FACT_100091_ORDER_MONTH.serverid
  is '����';
comment on column FACT_100091_ORDER_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100091_ORDER_MONTH.appid
  is '��Ʒid';
comment on column FACT_100091_ORDER_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_ORDER_MONTH.paysucccount
  is '�ɹ�������';
comment on column FACT_100091_ORDER_MONTH.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100091_ORDER_MONTH.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100091_ORDER_MONTH.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100091_ORDER_MONTH.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100091_ORDER_MONTH.payfailnum
  is '����ʧ������';
comment on column FACT_100091_ORDER_MONTH.data_source
  is '������Դ';
create index IDX191_100091 on FACT_100091_ORDER_MONTH (CHANNELID);
create index IDX192_100091 on FACT_100091_ORDER_MONTH (SERVERID);
create index IDX193_100091 on FACT_100091_ORDER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100091_ORDER_WEEK
prompt =====================================
prompt
create table FACT_100091_ORDER_WEEK
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100091_ORDER_WEEK
  is '�ܶ���������';
comment on column FACT_100091_ORDER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100091_ORDER_WEEK.channelid
  is '����';
comment on column FACT_100091_ORDER_WEEK.serverid
  is '����';
comment on column FACT_100091_ORDER_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100091_ORDER_WEEK.appid
  is '��Ʒid';
comment on column FACT_100091_ORDER_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_ORDER_WEEK.paysucccount
  is '�ɹ�������';
comment on column FACT_100091_ORDER_WEEK.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100091_ORDER_WEEK.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100091_ORDER_WEEK.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100091_ORDER_WEEK.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100091_ORDER_WEEK.payfailnum
  is '����ʧ������';
comment on column FACT_100091_ORDER_WEEK.data_source
  is '������Դ';
create index IDX188_100091 on FACT_100091_ORDER_WEEK (CHANNELID);
create index IDX189_100091 on FACT_100091_ORDER_WEEK (SERVERID);
create index IDX190_100091 on FACT_100091_ORDER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100091_PAYAMOUNT_DAY
prompt ========================================
prompt
create table FACT_100091_PAYAMOUNT_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_PAYAMOUNT_DAY
  is '�ճ�ֵ��������';
comment on column FACT_100091_PAYAMOUNT_DAY.statdate
  is 'ͳ������';
comment on column FACT_100091_PAYAMOUNT_DAY.channelid
  is '����';
comment on column FACT_100091_PAYAMOUNT_DAY.serverid
  is '����';
comment on column FACT_100091_PAYAMOUNT_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100091_PAYAMOUNT_DAY.appid
  is '��Ʒid';
comment on column FACT_100091_PAYAMOUNT_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_PAYAMOUNT_DAY.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100091_PAYAMOUNT_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100091_PAYAMOUNT_DAY.data_source
  is '������Դ';
create index IDX82_100091 on FACT_100091_PAYAMOUNT_DAY (CHANNELID);
create index IDX83_100091 on FACT_100091_PAYAMOUNT_DAY (SERVERID);
create index IDX84_100091 on FACT_100091_PAYAMOUNT_DAY (STATDATE);

prompt
prompt Creating table FACT_100091_PAYAMOUNT_MONTH
prompt ==========================================
prompt
create table FACT_100091_PAYAMOUNT_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_PAYAMOUNT_MONTH
  is '�³�ֵ��������';
comment on column FACT_100091_PAYAMOUNT_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100091_PAYAMOUNT_MONTH.channelid
  is '����';
comment on column FACT_100091_PAYAMOUNT_MONTH.serverid
  is '����';
comment on column FACT_100091_PAYAMOUNT_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100091_PAYAMOUNT_MONTH.appid
  is '��Ʒid';
comment on column FACT_100091_PAYAMOUNT_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_PAYAMOUNT_MONTH.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100091_PAYAMOUNT_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100091_PAYAMOUNT_MONTH.data_source
  is '������Դ';
create index IDX88_100091 on FACT_100091_PAYAMOUNT_MONTH (CHANNELID);
create index IDX89_100091 on FACT_100091_PAYAMOUNT_MONTH (SERVERID);
create index IDX90_100091 on FACT_100091_PAYAMOUNT_MONTH (STATDATE);

prompt
prompt Creating table FACT_100091_PAYAMOUNT_WEEK
prompt =========================================
prompt
create table FACT_100091_PAYAMOUNT_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_PAYAMOUNT_WEEK
  is '�ܳ�ֵ��������';
comment on column FACT_100091_PAYAMOUNT_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100091_PAYAMOUNT_WEEK.channelid
  is '����';
comment on column FACT_100091_PAYAMOUNT_WEEK.serverid
  is '����';
comment on column FACT_100091_PAYAMOUNT_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100091_PAYAMOUNT_WEEK.appid
  is '��Ʒid';
comment on column FACT_100091_PAYAMOUNT_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_PAYAMOUNT_WEEK.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100091_PAYAMOUNT_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100091_PAYAMOUNT_WEEK.data_source
  is '������Դ';
create index IDX85_100091 on FACT_100091_PAYAMOUNT_WEEK (CHANNELID);
create index IDX86_100091 on FACT_100091_PAYAMOUNT_WEEK (SERVERID);
create index IDX87_100091 on FACT_100091_PAYAMOUNT_WEEK (STATDATE);

prompt
prompt Creating table FACT_100091_PAYNUM_DAY
prompt =====================================
prompt
create table FACT_100091_PAYNUM_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_PAYNUM_DAY
  is '�ճ�ֵ����������';
comment on column FACT_100091_PAYNUM_DAY.statdate
  is 'ͳ������';
comment on column FACT_100091_PAYNUM_DAY.channelid
  is '����';
comment on column FACT_100091_PAYNUM_DAY.serverid
  is '����';
comment on column FACT_100091_PAYNUM_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100091_PAYNUM_DAY.appid
  is '��Ʒid';
comment on column FACT_100091_PAYNUM_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_PAYNUM_DAY.paynum
  is '��ֵ����';
comment on column FACT_100091_PAYNUM_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100091_PAYNUM_DAY.data_source
  is '������Դ';
create index IDX97_100091 on FACT_100091_PAYNUM_DAY (CHANNELID);
create index IDX98_100091 on FACT_100091_PAYNUM_DAY (SERVERID);
create index IDX99_100091 on FACT_100091_PAYNUM_DAY (STATDATE);

prompt
prompt Creating table FACT_100091_PAYNUM_MONTH
prompt =======================================
prompt
create table FACT_100091_PAYNUM_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_PAYNUM_MONTH
  is '�³�ֵ����������';
comment on column FACT_100091_PAYNUM_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100091_PAYNUM_MONTH.channelid
  is '����';
comment on column FACT_100091_PAYNUM_MONTH.serverid
  is '����';
comment on column FACT_100091_PAYNUM_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100091_PAYNUM_MONTH.appid
  is '��Ʒid';
comment on column FACT_100091_PAYNUM_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_PAYNUM_MONTH.paynum
  is '��ֵ����';
comment on column FACT_100091_PAYNUM_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100091_PAYNUM_MONTH.data_source
  is '������Դ';
create index IDX91_100091 on FACT_100091_PAYNUM_MONTH (CHANNELID);
create index IDX92_100091 on FACT_100091_PAYNUM_MONTH (SERVERID);
create index IDX93_100091 on FACT_100091_PAYNUM_MONTH (STATDATE);

prompt
prompt Creating table FACT_100091_PAYNUM_WEEK
prompt ======================================
prompt
create table FACT_100091_PAYNUM_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_PAYNUM_WEEK
  is '�ܳ�ֵ����������';
comment on column FACT_100091_PAYNUM_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100091_PAYNUM_WEEK.channelid
  is '����';
comment on column FACT_100091_PAYNUM_WEEK.serverid
  is '����';
comment on column FACT_100091_PAYNUM_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100091_PAYNUM_WEEK.appid
  is '��Ʒid';
comment on column FACT_100091_PAYNUM_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_PAYNUM_WEEK.paynum
  is '��ֵ����';
comment on column FACT_100091_PAYNUM_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100091_PAYNUM_WEEK.data_source
  is '������Դ';
create index IDX94_100091 on FACT_100091_PAYNUM_WEEK (CHANNELID);
create index IDX95_100091 on FACT_100091_PAYNUM_WEEK (SERVERID);
create index IDX96_100091 on FACT_100091_PAYNUM_WEEK (STATDATE);

prompt
prompt Creating table FACT_100091_PAYTYPE
prompt ==================================
prompt
create table FACT_100091_PAYTYPE
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paytypeid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_PAYTYPE
  is '��ֵ���ͷ�����';
comment on column FACT_100091_PAYTYPE.statdate
  is 'ͳ������';
comment on column FACT_100091_PAYTYPE.channelid
  is '����';
comment on column FACT_100091_PAYTYPE.serverid
  is '����';
comment on column FACT_100091_PAYTYPE.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100091_PAYTYPE.appid
  is '��Ʒid';
comment on column FACT_100091_PAYTYPE.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_PAYTYPE.paytypeid
  is '��ֵ����';
comment on column FACT_100091_PAYTYPE.payamount
  is '��ֵ���';
comment on column FACT_100091_PAYTYPE.paycount
  is '��ֵ����';
comment on column FACT_100091_PAYTYPE.paynum
  is '��ֵ����';
comment on column FACT_100091_PAYTYPE.data_source
  is '������Դ';
create index IDX100_100091 on FACT_100091_PAYTYPE (CHANNELID);
create index IDX101_100091 on FACT_100091_PAYTYPE (SERVERID);
create index IDX102_100091 on FACT_100091_PAYTYPE (STATDATE);

prompt
prompt Creating table FACT_100091_PAYWAY
prompt =================================
prompt
create table FACT_100091_PAYWAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paywayid    VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_PAYWAY
  is '��ֵ��ʽ������';
comment on column FACT_100091_PAYWAY.statdate
  is 'ͳ������';
comment on column FACT_100091_PAYWAY.channelid
  is '����';
comment on column FACT_100091_PAYWAY.serverid
  is '����';
comment on column FACT_100091_PAYWAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100091_PAYWAY.appid
  is '��Ʒid';
comment on column FACT_100091_PAYWAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_PAYWAY.paywayid
  is '��ֵ��ʽ';
comment on column FACT_100091_PAYWAY.payamount
  is '��ֵ���';
comment on column FACT_100091_PAYWAY.paycount
  is '��ֵ����';
comment on column FACT_100091_PAYWAY.paynum
  is '��ֵ����';
comment on column FACT_100091_PAYWAY.data_source
  is '������Դ';
create index IDX103_100091 on FACT_100091_PAYWAY (CHANNELID);
create index IDX104_100091 on FACT_100091_PAYWAY (SERVERID);
create index IDX105_100091 on FACT_100091_PAYWAY (STATDATE);

prompt
prompt Creating table FACT_100091_REGION
prompt =================================
prompt
create table FACT_100091_REGION
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  country     VARCHAR2(50),
  province    VARCHAR2(50),
  city        VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_REGION
  is '���������';
comment on column FACT_100091_REGION.statdate
  is 'ͳ������';
comment on column FACT_100091_REGION.channelid
  is '����';
comment on column FACT_100091_REGION.serverid
  is '����';
comment on column FACT_100091_REGION.appid
  is '��Ʒid';
comment on column FACT_100091_REGION.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_REGION.country
  is '����';
comment on column FACT_100091_REGION.province
  is 'ʡ';
comment on column FACT_100091_REGION.city
  is '��';
comment on column FACT_100091_REGION.newcount
  is '������';
comment on column FACT_100091_REGION.conncount
  is '������';
comment on column FACT_100091_REGION.paycount
  is '������';
comment on column FACT_100091_REGION.payamount
  is '���ѽ��';
comment on column FACT_100091_REGION.data_source
  is '������Դ';
create index IDX106_100091 on FACT_100091_REGION (CHANNELID);
create index IDX107_100091 on FACT_100091_REGION (SERVERID);
create index IDX108_100091 on FACT_100091_REGION (STATDATE);

prompt
prompt Creating table FACT_100091_REMAIN_MAC
prompt =====================================
prompt
create table FACT_100091_REMAIN_MAC
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_REMAIN_MAC
  is '�豸�����';
comment on column FACT_100091_REMAIN_MAC.statdate
  is 'ͳ������';
comment on column FACT_100091_REMAIN_MAC.conndate
  is '��������';
comment on column FACT_100091_REMAIN_MAC.channelid
  is '����ID';
comment on column FACT_100091_REMAIN_MAC.serverid
  is '����ID';
comment on column FACT_100091_REMAIN_MAC.appid
  is '��ƷID';
comment on column FACT_100091_REMAIN_MAC.remain_days
  is '��������';
comment on column FACT_100091_REMAIN_MAC.new_remain
  is '��������';
comment on column FACT_100091_REMAIN_MAC.conn_remain
  is '��������';
comment on column FACT_100091_REMAIN_MAC.pay_remain
  is '��������';
comment on column FACT_100091_REMAIN_MAC.data_source
  is '����Դ';
create index IDX109_100091 on FACT_100091_REMAIN_MAC (CHANNELID);
create index IDX110_100091 on FACT_100091_REMAIN_MAC (SERVERID);
create index IDX111_100091 on FACT_100091_REMAIN_MAC (STATDATE);

prompt
prompt Creating table FACT_100091_REMAIN_USER
prompt ======================================
prompt
create table FACT_100091_REMAIN_USER
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_REMAIN_USER
  is '�û������';
comment on column FACT_100091_REMAIN_USER.statdate
  is 'ͳ������';
comment on column FACT_100091_REMAIN_USER.conndate
  is '��������';
comment on column FACT_100091_REMAIN_USER.channelid
  is '����ID';
comment on column FACT_100091_REMAIN_USER.serverid
  is '����ID';
comment on column FACT_100091_REMAIN_USER.appid
  is '��ƷID';
comment on column FACT_100091_REMAIN_USER.remain_days
  is '��������';
comment on column FACT_100091_REMAIN_USER.new_remain
  is '��������';
comment on column FACT_100091_REMAIN_USER.conn_remain
  is '��������';
comment on column FACT_100091_REMAIN_USER.pay_remain
  is '��������';
comment on column FACT_100091_REMAIN_USER.data_source
  is '����Դ';
create index IDX112_100091 on FACT_100091_REMAIN_USER (CHANNELID);
create index IDX113_100091 on FACT_100091_REMAIN_USER (SERVERID);
create index IDX114_100091 on FACT_100091_REMAIN_USER (STATDATE);

prompt
prompt Creating table FACT_100091_VC
prompt =============================
prompt
create table FACT_100091_VC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcamount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100091_VC
  is '������ҷ�����';
comment on column FACT_100091_VC.statdate
  is 'ͳ������';
comment on column FACT_100091_VC.channelid
  is '����';
comment on column FACT_100091_VC.serverid
  is '����';
comment on column FACT_100091_VC.appid
  is '��Ʒid';
comment on column FACT_100091_VC.versionid
  is '��Ʒ�汾';
comment on column FACT_100091_VC.vctype
  is '�����������';
comment on column FACT_100091_VC.vcusetype
  is '�������ʹ������';
comment on column FACT_100091_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column FACT_100091_VC.vcamount
  is '������ҽ��';
comment on column FACT_100091_VC.data_source
  is '������Դ';
create index IDX115_100091 on FACT_100091_VC (CHANNELID);
create index IDX116_100091 on FACT_100091_VC (SERVERID);
create index IDX117_100091 on FACT_100091_VC (STATDATE);

prompt
prompt Creating table FACT_100105_BACK_MAC
prompt ===================================
prompt
create table FACT_100105_BACK_MAC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_BACK_MAC
  is '�豸����������';
comment on column FACT_100105_BACK_MAC.statdate
  is 'ͳ������';
comment on column FACT_100105_BACK_MAC.channelid
  is '����ID';
comment on column FACT_100105_BACK_MAC.serverid
  is '����ID';
comment on column FACT_100105_BACK_MAC.appid
  is '��ƷID';
comment on column FACT_100105_BACK_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100105_BACK_MAC.back_conn
  is '��Ծ�豸������';
comment on column FACT_100105_BACK_MAC.back_pay
  is '�����豸������';
comment on column FACT_100105_BACK_MAC.data_source
  is '����Դ';
create index IDX1_100105 on FACT_100105_BACK_MAC (CHANNELID);
create index IDX2_100105 on FACT_100105_BACK_MAC (SERVERID);
create index IDX3_100105 on FACT_100105_BACK_MAC (STATDATE);

prompt
prompt Creating table FACT_100105_BACK_MAC_MONTH
prompt =========================================
prompt
create table FACT_100105_BACK_MAC_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_BACK_MAC_MONTH
  is '�豸����������';
comment on column FACT_100105_BACK_MAC_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100105_BACK_MAC_MONTH.channelid
  is '����ID';
comment on column FACT_100105_BACK_MAC_MONTH.serverid
  is '����ID';
comment on column FACT_100105_BACK_MAC_MONTH.appid
  is '��ƷID';
comment on column FACT_100105_BACK_MAC_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100105_BACK_MAC_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100105_BACK_MAC_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100105_BACK_MAC_MONTH.data_source
  is '����Դ';
create index IDX4_100105 on FACT_100105_BACK_MAC_MONTH (CHANNELID);
create index IDX5_100105 on FACT_100105_BACK_MAC_MONTH (SERVERID);
create index IDX6_100105 on FACT_100105_BACK_MAC_MONTH (STATDATE);

prompt
prompt Creating table FACT_100105_BACK_MAC_WEEK
prompt ========================================
prompt
create table FACT_100105_BACK_MAC_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_BACK_MAC_WEEK
  is '�豸����������';
comment on column FACT_100105_BACK_MAC_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100105_BACK_MAC_WEEK.channelid
  is '����ID';
comment on column FACT_100105_BACK_MAC_WEEK.serverid
  is '����ID';
comment on column FACT_100105_BACK_MAC_WEEK.appid
  is '��ƷID';
comment on column FACT_100105_BACK_MAC_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100105_BACK_MAC_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100105_BACK_MAC_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100105_BACK_MAC_WEEK.data_source
  is '����Դ';
create index IDX7_100105 on FACT_100105_BACK_MAC_WEEK (CHANNELID);
create index IDX8_100105 on FACT_100105_BACK_MAC_WEEK (SERVERID);
create index IDX9_100105 on FACT_100105_BACK_MAC_WEEK (STATDATE);

prompt
prompt Creating table FACT_100105_BACK_USER
prompt ====================================
prompt
create table FACT_100105_BACK_USER
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_BACK_USER
  is '�û�����������';
comment on column FACT_100105_BACK_USER.statdate
  is 'ͳ������';
comment on column FACT_100105_BACK_USER.channelid
  is '����ID';
comment on column FACT_100105_BACK_USER.serverid
  is '����ID';
comment on column FACT_100105_BACK_USER.appid
  is '��ƷID';
comment on column FACT_100105_BACK_USER.lost_days
  is '��ʧ����';
comment on column FACT_100105_BACK_USER.back_conn
  is '��Ծ�û�������';
comment on column FACT_100105_BACK_USER.back_pay
  is '�����û�������';
comment on column FACT_100105_BACK_USER.data_source
  is '����Դ';
create index IDX16_100105 on FACT_100105_BACK_USER (CHANNELID);
create index IDX17_100105 on FACT_100105_BACK_USER (SERVERID);
create index IDX18_100105 on FACT_100105_BACK_USER (STATDATE);

prompt
prompt Creating table FACT_100105_BACK_USER_MONTH
prompt ==========================================
prompt
create table FACT_100105_BACK_USER_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_BACK_USER_MONTH
  is '�豸����������';
comment on column FACT_100105_BACK_USER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100105_BACK_USER_MONTH.channelid
  is '����ID';
comment on column FACT_100105_BACK_USER_MONTH.serverid
  is '����ID';
comment on column FACT_100105_BACK_USER_MONTH.appid
  is '��ƷID';
comment on column FACT_100105_BACK_USER_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100105_BACK_USER_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100105_BACK_USER_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100105_BACK_USER_MONTH.data_source
  is '����Դ';
create index IDX13_100105 on FACT_100105_BACK_USER_MONTH (CHANNELID);
create index IDX14_100105 on FACT_100105_BACK_USER_MONTH (SERVERID);
create index IDX15_100105 on FACT_100105_BACK_USER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100105_BACK_USER_WEEK
prompt =========================================
prompt
create table FACT_100105_BACK_USER_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_BACK_USER_WEEK
  is '�豸����������';
comment on column FACT_100105_BACK_USER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100105_BACK_USER_WEEK.channelid
  is '����ID';
comment on column FACT_100105_BACK_USER_WEEK.serverid
  is '����ID';
comment on column FACT_100105_BACK_USER_WEEK.appid
  is '��ƷID';
comment on column FACT_100105_BACK_USER_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100105_BACK_USER_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100105_BACK_USER_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100105_BACK_USER_WEEK.data_source
  is '����Դ';
create index IDX10_100105 on FACT_100105_BACK_USER_WEEK (CHANNELID);
create index IDX11_100105 on FACT_100105_BACK_USER_WEEK (SERVERID);
create index IDX12_100105 on FACT_100105_BACK_USER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100105_CEVENT
prompt =================================
prompt
create table FACT_100105_CEVENT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  eventkey    VARCHAR2(50),
  eventcount  NUMBER,
  eventnum    NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_CEVENT
  is '�Զ��������';
comment on column FACT_100105_CEVENT.statdate
  is 'ͳ������';
comment on column FACT_100105_CEVENT.channelid
  is '����';
comment on column FACT_100105_CEVENT.serverid
  is '����';
comment on column FACT_100105_CEVENT.appid
  is '��Ʒid';
comment on column FACT_100105_CEVENT.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100105_CEVENT.eventcount
  is '�¼��û���';
comment on column FACT_100105_CEVENT.eventnum
  is '�¼�����';
comment on column FACT_100105_CEVENT.data_source
  is '������Դ';
create index IDX181_100105 on FACT_100105_CEVENT (CHANNELID);
create index IDX182_100105 on FACT_100105_CEVENT (SERVERID);
create index IDX183_100105 on FACT_100105_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100105_CEVENT_PAR
prompt =====================================
prompt
create table FACT_100105_CEVENT_PAR
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  ilevel         NUMBER,
  eventkey       VARCHAR2(100),
  eventpar_key   VARCHAR2(100),
  eventpar_value VARCHAR2(100),
  eventcount     NUMBER,
  eventnum       NUMBER,
  loaddate       DATE default Sysdate,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100105_CEVENT_PAR
  is '�Զ������������';
comment on column FACT_100105_CEVENT_PAR.statdate
  is 'ͳ������';
comment on column FACT_100105_CEVENT_PAR.channelid
  is '����';
comment on column FACT_100105_CEVENT_PAR.serverid
  is '����';
comment on column FACT_100105_CEVENT_PAR.appid
  is '��Ʒid';
comment on column FACT_100105_CEVENT_PAR.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_CEVENT_PAR.ilevel
  is '��ɫ�ȼ�';
comment on column FACT_100105_CEVENT_PAR.eventkey
  is '�¼�����';
comment on column FACT_100105_CEVENT_PAR.eventpar_key
  is '�¼�����';
comment on column FACT_100105_CEVENT_PAR.eventpar_value
  is '�¼�����ֵ';
comment on column FACT_100105_CEVENT_PAR.eventcount
  is '�¼��û���';
comment on column FACT_100105_CEVENT_PAR.eventnum
  is '�¼�����';
comment on column FACT_100105_CEVENT_PAR.data_source
  is '������Դ';
create index IDX185_100105 on FACT_100105_CEVENT_PAR (CHANNELID);
create index IDX186_100105 on FACT_100105_CEVENT_PAR (SERVERID);
create index IDX187_100105 on FACT_100105_CEVENT_PAR (STATDATE);

prompt
prompt Creating table FACT_100105_COMP_CEVENT
prompt ======================================
prompt
create table FACT_100105_COMP_CEVENT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(10),
  channelid   VARCHAR2(50),
  gameversion VARCHAR2(50),
  serverid    VARCHAR2(50),
  ilevel      NUMBER,
  eventkey    VARCHAR2(100),
  compid      VARCHAR2(50),
  caltype     VARCHAR2(50),
  dimpars     VARCHAR2(2000),
  comp_data   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_COMP_CEVENT
  is '�Զ����¼���Ϸ�����';
comment on column FACT_100105_COMP_CEVENT.statdate
  is '����';
comment on column FACT_100105_COMP_CEVENT.appid
  is '��Ϸ�� appid';
comment on column FACT_100105_COMP_CEVENT.channelid
  is '���� ID';
comment on column FACT_100105_COMP_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column FACT_100105_COMP_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column FACT_100105_COMP_CEVENT.ilevel
  is '��ҵȼ�';
comment on column FACT_100105_COMP_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100105_COMP_CEVENT.compid
  is '��ϼ����¼�ID';
comment on column FACT_100105_COMP_CEVENT.caltype
  is '��ϼ����¼���������';
comment on column FACT_100105_COMP_CEVENT.dimpars
  is '��ϲ���';
comment on column FACT_100105_COMP_CEVENT.comp_data
  is '��ϼ�����';
create index IDX184_100105 on FACT_100105_COMP_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100105_DAILY_REPORT
prompt =======================================
prompt
create table FACT_100105_DAILY_REPORT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_DAILY_REPORT
  is '�ձ�����';
comment on column FACT_100105_DAILY_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100105_DAILY_REPORT.appid
  is '��ƷID';
comment on column FACT_100105_DAILY_REPORT.channelid
  is '����';
comment on column FACT_100105_DAILY_REPORT.serverid
  is '����';
comment on column FACT_100105_DAILY_REPORT.indexid
  is 'ָ��';
comment on column FACT_100105_DAILY_REPORT.indtype
  is 'ָ������';
comment on column FACT_100105_DAILY_REPORT.rpt_data
  is '����';
create index IDX176_100105 on FACT_100105_DAILY_REPORT (STATDATE);

prompt
prompt Creating table FACT_100105_DVID
prompt ===============================
prompt
create table FACT_100105_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_model  VARCHAR2(200),
  dvid_res    VARCHAR2(50),
  dvid_os     VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_DVID
  is '�豸������';
comment on column FACT_100105_DVID.statdate
  is 'ͳ������';
comment on column FACT_100105_DVID.channelid
  is '����';
comment on column FACT_100105_DVID.serverid
  is '����';
comment on column FACT_100105_DVID.appid
  is '��Ʒid';
comment on column FACT_100105_DVID.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_DVID.dvid_model
  is '����';
comment on column FACT_100105_DVID.dvid_res
  is '�豸�ֱ���';
comment on column FACT_100105_DVID.dvid_os
  is '�豸����ϵͳ';
comment on column FACT_100105_DVID.newcount
  is '�����û���';
comment on column FACT_100105_DVID.conncount
  is '�����û���';
comment on column FACT_100105_DVID.data_source
  is '������Դ';
create index IDX19_100105 on FACT_100105_DVID (CHANNELID);
create index IDX20_100105 on FACT_100105_DVID (SERVERID);
create index IDX21_100105 on FACT_100105_DVID (STATDATE);

prompt
prompt Creating table FACT_100105_FIRSTPAY
prompt ===================================
prompt
create table FACT_100105_FIRSTPAY
(
  statdate         VARCHAR2(10),
  firstpaydate     VARCHAR2(10),
  channelid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  datatype         VARCHAR2(50),
  appid            VARCHAR2(50),
  first_payfromreg NUMBER,
  first_paycount   NUMBER,
  payamount        NUMBER,
  loaddate         DATE default SYSDATE,
  data_source      VARCHAR2(100)
)
;
comment on table FACT_100105_FIRSTPAY
  is '�����û��״γ�ֵ������';
comment on column FACT_100105_FIRSTPAY.statdate
  is 'ͳ������';
comment on column FACT_100105_FIRSTPAY.firstpaydate
  is '�״θ�������';
comment on column FACT_100105_FIRSTPAY.channelid
  is '����';
comment on column FACT_100105_FIRSTPAY.serverid
  is '����';
comment on column FACT_100105_FIRSTPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100105_FIRSTPAY.appid
  is '��Ʒid';
comment on column FACT_100105_FIRSTPAY.first_payfromreg
  is 'ע���ڼ��쿪ʼ��ֵ(1��2��..7..30..)';
comment on column FACT_100105_FIRSTPAY.first_paycount
  is '���������û���';
comment on column FACT_100105_FIRSTPAY.payamount
  is '�ۼƵ��ڼ���ĳ�ֵ�ܶ�';
comment on column FACT_100105_FIRSTPAY.data_source
  is '������Դ';
create index IDX22_100105 on FACT_100105_FIRSTPAY (CHANNELID);
create index IDX23_100105 on FACT_100105_FIRSTPAY (SERVERID);
create index IDX24_100105 on FACT_100105_FIRSTPAY (STATDATE);

prompt
prompt Creating table FACT_100105_FIRSTPAY_AMOUNT
prompt ==========================================
prompt
create table FACT_100105_FIRSTPAY_AMOUNT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_FIRSTPAY_AMOUNT
  is '�״θ��ѽ�������';
comment on column FACT_100105_FIRSTPAY_AMOUNT.statdate
  is 'ͳ������';
comment on column FACT_100105_FIRSTPAY_AMOUNT.channelid
  is '����';
comment on column FACT_100105_FIRSTPAY_AMOUNT.serverid
  is '��������';
comment on column FACT_100105_FIRSTPAY_AMOUNT.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100105_FIRSTPAY_AMOUNT.appid
  is '��Ʒid';
comment on column FACT_100105_FIRSTPAY_AMOUNT.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_FIRSTPAY_AMOUNT.payamount
  is '�״θ��ѽ��';
comment on column FACT_100105_FIRSTPAY_AMOUNT.paycount
  is '�״θ��ѽ���Ӧ������';
create index IDX25_100105 on FACT_100105_FIRSTPAY_AMOUNT (CHANNELID);
create index IDX26_100105 on FACT_100105_FIRSTPAY_AMOUNT (SERVERID);
create index IDX27_100105 on FACT_100105_FIRSTPAY_AMOUNT (STATDATE);

prompt
prompt Creating table FACT_100105_GENERAL_DAY
prompt ======================================
prompt
create table FACT_100105_GENERAL_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_GENERAL_DAY
  is '�ջ���������';
comment on column FACT_100105_GENERAL_DAY.statdate
  is 'ͳ������';
comment on column FACT_100105_GENERAL_DAY.channelid
  is '����';
comment on column FACT_100105_GENERAL_DAY.serverid
  is '����';
comment on column FACT_100105_GENERAL_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100105_GENERAL_DAY.appid
  is '��Ʒid';
comment on column FACT_100105_GENERAL_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_GENERAL_DAY.newcount
  is '������';
comment on column FACT_100105_GENERAL_DAY.conncount
  is '������';
comment on column FACT_100105_GENERAL_DAY.paycount
  is '������';
comment on column FACT_100105_GENERAL_DAY.payamount
  is '���ѽ��';
comment on column FACT_100105_GENERAL_DAY.data_source
  is '������Դ';
create index IDX28_100105 on FACT_100105_GENERAL_DAY (CHANNELID);
create index IDX29_100105 on FACT_100105_GENERAL_DAY (SERVERID);
create index IDX30_100105 on FACT_100105_GENERAL_DAY (STATDATE);

prompt
prompt Creating table FACT_100105_GENERAL_DAY_DVID
prompt ===========================================
prompt
create table FACT_100105_GENERAL_DAY_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_GENERAL_DAY_DVID
  is '���豸����������';
comment on column FACT_100105_GENERAL_DAY_DVID.statdate
  is 'ͳ������';
comment on column FACT_100105_GENERAL_DAY_DVID.channelid
  is '����';
comment on column FACT_100105_GENERAL_DAY_DVID.appid
  is '��Ʒid';
comment on column FACT_100105_GENERAL_DAY_DVID.newcount
  is '������';
comment on column FACT_100105_GENERAL_DAY_DVID.conncount
  is '������';
comment on column FACT_100105_GENERAL_DAY_DVID.data_source
  is '������Դ';
create index IDX31_100105 on FACT_100105_GENERAL_DAY_DVID (CHANNELID);
create index IDX33_100105 on FACT_100105_GENERAL_DAY_DVID (STATDATE);

prompt
prompt Creating table FACT_100105_GENERAL_HOUR
prompt =======================================
prompt
create table FACT_100105_GENERAL_HOUR
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_GENERAL_HOUR
  is 'Сʱ����������';
comment on column FACT_100105_GENERAL_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100105_GENERAL_HOUR.channelid
  is '����';
comment on column FACT_100105_GENERAL_HOUR.serverid
  is '����';
comment on column FACT_100105_GENERAL_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100105_GENERAL_HOUR.appid
  is '��Ʒid';
comment on column FACT_100105_GENERAL_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_GENERAL_HOUR.newcount
  is '������';
comment on column FACT_100105_GENERAL_HOUR.conncount
  is '������';
comment on column FACT_100105_GENERAL_HOUR.paycount
  is '������';
comment on column FACT_100105_GENERAL_HOUR.payamount
  is '���ѽ��';
comment on column FACT_100105_GENERAL_HOUR.data_source
  is '������Դ';
create index IDX34_100105 on FACT_100105_GENERAL_HOUR (CHANNELID);
create index IDX35_100105 on FACT_100105_GENERAL_HOUR (SERVERID);
create index IDX36_100105 on FACT_100105_GENERAL_HOUR (STATDATE);

prompt
prompt Creating table FACT_100105_GENERAL_HOUR_DVID
prompt ============================================
prompt
create table FACT_100105_GENERAL_HOUR_DVID
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_GENERAL_HOUR_DVID
  is 'Сʱ�豸����������';
comment on column FACT_100105_GENERAL_HOUR_DVID.statdate
  is 'ͳ������';
comment on column FACT_100105_GENERAL_HOUR_DVID.channelid
  is '����';
comment on column FACT_100105_GENERAL_HOUR_DVID.appid
  is '��Ʒid';
comment on column FACT_100105_GENERAL_HOUR_DVID.newcount
  is '������';
comment on column FACT_100105_GENERAL_HOUR_DVID.conncount
  is '������';
comment on column FACT_100105_GENERAL_HOUR_DVID.data_source
  is '������Դ';
create index IDX37_100105 on FACT_100105_GENERAL_HOUR_DVID (CHANNELID);
create index IDX39_100105 on FACT_100105_GENERAL_HOUR_DVID (STATDATE);

prompt
prompt Creating table FACT_100105_GENERAL_LEVEL
prompt ========================================
prompt
create table FACT_100105_GENERAL_LEVEL
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  rolelevel   NUMBER,
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_GENERAL_LEVEL
  is '�û��ȼ�������';
comment on column FACT_100105_GENERAL_LEVEL.statdate
  is 'ͳ������';
comment on column FACT_100105_GENERAL_LEVEL.channelid
  is '����';
comment on column FACT_100105_GENERAL_LEVEL.serverid
  is '����';
comment on column FACT_100105_GENERAL_LEVEL.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100105_GENERAL_LEVEL.appid
  is '��Ʒid';
comment on column FACT_100105_GENERAL_LEVEL.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_GENERAL_LEVEL.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100105_GENERAL_LEVEL.newcount
  is '������';
comment on column FACT_100105_GENERAL_LEVEL.conncount
  is '������';
comment on column FACT_100105_GENERAL_LEVEL.paycount
  is '������';
comment on column FACT_100105_GENERAL_LEVEL.payamount
  is '���ѽ��';
comment on column FACT_100105_GENERAL_LEVEL.data_source
  is '������Դ';
create index IDX40_100105 on FACT_100105_GENERAL_LEVEL (CHANNELID);
create index IDX41_100105 on FACT_100105_GENERAL_LEVEL (SERVERID);
create index IDX42_100105 on FACT_100105_GENERAL_LEVEL (STATDATE);

prompt
prompt Creating table FACT_100105_GENERAL_MONTH
prompt ========================================
prompt
create table FACT_100105_GENERAL_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_GENERAL_MONTH
  is '�»���������';
comment on column FACT_100105_GENERAL_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100105_GENERAL_MONTH.channelid
  is '����';
comment on column FACT_100105_GENERAL_MONTH.serverid
  is '����';
comment on column FACT_100105_GENERAL_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100105_GENERAL_MONTH.appid
  is '��Ʒid';
comment on column FACT_100105_GENERAL_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_GENERAL_MONTH.newcount
  is '������';
comment on column FACT_100105_GENERAL_MONTH.conncount
  is '������';
comment on column FACT_100105_GENERAL_MONTH.paycount
  is '������';
comment on column FACT_100105_GENERAL_MONTH.payamount
  is '���ѽ��';
comment on column FACT_100105_GENERAL_MONTH.data_source
  is '������Դ';
create index IDX43_100105 on FACT_100105_GENERAL_MONTH (CHANNELID);
create index IDX44_100105 on FACT_100105_GENERAL_MONTH (SERVERID);
create index IDX45_100105 on FACT_100105_GENERAL_MONTH (STATDATE);

prompt
prompt Creating table FACT_100105_GENERAL_MONTH_DVID
prompt =============================================
prompt
create table FACT_100105_GENERAL_MONTH_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_GENERAL_MONTH_DVID
  is '���豸����������';
comment on column FACT_100105_GENERAL_MONTH_DVID.statdate
  is 'ͳ������';
comment on column FACT_100105_GENERAL_MONTH_DVID.channelid
  is '����';
comment on column FACT_100105_GENERAL_MONTH_DVID.appid
  is '��Ʒid';
comment on column FACT_100105_GENERAL_MONTH_DVID.newcount
  is '������';
comment on column FACT_100105_GENERAL_MONTH_DVID.conncount
  is '������';
comment on column FACT_100105_GENERAL_MONTH_DVID.data_source
  is '������Դ';
create index IDX46_100105 on FACT_100105_GENERAL_MONTH_DVID (CHANNELID);
create index IDX48_100105 on FACT_100105_GENERAL_MONTH_DVID (STATDATE);

prompt
prompt Creating table FACT_100105_GENERAL_WEEK
prompt =======================================
prompt
create table FACT_100105_GENERAL_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_GENERAL_WEEK
  is '�ܻ���������';
comment on column FACT_100105_GENERAL_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100105_GENERAL_WEEK.channelid
  is '����';
comment on column FACT_100105_GENERAL_WEEK.serverid
  is '����';
comment on column FACT_100105_GENERAL_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100105_GENERAL_WEEK.appid
  is '��Ʒid';
comment on column FACT_100105_GENERAL_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_GENERAL_WEEK.newcount
  is '������';
comment on column FACT_100105_GENERAL_WEEK.conncount
  is '������';
comment on column FACT_100105_GENERAL_WEEK.paycount
  is '������';
comment on column FACT_100105_GENERAL_WEEK.payamount
  is '���ѽ��';
comment on column FACT_100105_GENERAL_WEEK.data_source
  is '������Դ';
create index IDX52_100105 on FACT_100105_GENERAL_WEEK (CHANNELID);
create index IDX53_100105 on FACT_100105_GENERAL_WEEK (SERVERID);
create index IDX54_100105 on FACT_100105_GENERAL_WEEK (STATDATE);

prompt
prompt Creating table FACT_100105_GENERAL_WEEK_DVID
prompt ============================================
prompt
create table FACT_100105_GENERAL_WEEK_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_GENERAL_WEEK_DVID
  is '���豸����������';
comment on column FACT_100105_GENERAL_WEEK_DVID.statdate
  is 'ͳ������';
comment on column FACT_100105_GENERAL_WEEK_DVID.channelid
  is '����';
comment on column FACT_100105_GENERAL_WEEK_DVID.appid
  is '��Ʒid';
comment on column FACT_100105_GENERAL_WEEK_DVID.newcount
  is '������';
comment on column FACT_100105_GENERAL_WEEK_DVID.conncount
  is '������';
comment on column FACT_100105_GENERAL_WEEK_DVID.data_source
  is '������Դ';
create index IDX49_100105 on FACT_100105_GENERAL_WEEK_DVID (CHANNELID);
create index IDX51_100105 on FACT_100105_GENERAL_WEEK_DVID (STATDATE);

prompt
prompt Creating table FACT_100105_HOUR_REPORT
prompt ======================================
prompt
create table FACT_100105_HOUR_REPORT
(
  statdate    VARCHAR2(20),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_HOUR_REPORT
  is '�ձ�Сʱ����';
comment on column FACT_100105_HOUR_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100105_HOUR_REPORT.appid
  is '��ƷID';
comment on column FACT_100105_HOUR_REPORT.channelid
  is '����';
comment on column FACT_100105_HOUR_REPORT.serverid
  is '����';
comment on column FACT_100105_HOUR_REPORT.indexid
  is 'ָ��';
comment on column FACT_100105_HOUR_REPORT.indtype
  is 'ָ������';
comment on column FACT_100105_HOUR_REPORT.rpt_data
  is '����';

prompt
prompt Creating table FACT_100105_LEVELPAY
prompt ===================================
prompt
create table FACT_100105_LEVELPAY
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  datatype       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  rolelevel      NUMBER,
  paycount       NUMBER,
  first_paycount NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100105_LEVELPAY
  is '�û���ɫ�ȼ����ѷ�����';
comment on column FACT_100105_LEVELPAY.statdate
  is 'ͳ������';
comment on column FACT_100105_LEVELPAY.channelid
  is '����';
comment on column FACT_100105_LEVELPAY.serverid
  is '����';
comment on column FACT_100105_LEVELPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100105_LEVELPAY.appid
  is '��Ʒid';
comment on column FACT_100105_LEVELPAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_LEVELPAY.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100105_LEVELPAY.paycount
  is '�����û���';
comment on column FACT_100105_LEVELPAY.first_paycount
  is '���������û������״θ����û���';
comment on column FACT_100105_LEVELPAY.data_source
  is '������Դ';
create index IDX55_100105 on FACT_100105_LEVELPAY (CHANNELID);
create index IDX56_100105 on FACT_100105_LEVELPAY (SERVERID);
create index IDX57_100105 on FACT_100105_LEVELPAY (STATDATE);

prompt
prompt Creating table FACT_100105_LOST_MAC
prompt ===================================
prompt
create table FACT_100105_LOST_MAC
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_LOST_MAC
  is '�豸��ʧ������';
comment on column FACT_100105_LOST_MAC.statdate
  is 'ͳ������';
comment on column FACT_100105_LOST_MAC.lostdate
  is '��ʧ����';
comment on column FACT_100105_LOST_MAC.channelid
  is '����ID';
comment on column FACT_100105_LOST_MAC.serverid
  is '����ID';
comment on column FACT_100105_LOST_MAC.appid
  is '��ƷID';
comment on column FACT_100105_LOST_MAC.rolelevel
  is '��ʧʱ�ȼ�';
comment on column FACT_100105_LOST_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100105_LOST_MAC.lost_conn
  is '��Ծ�豸��ʧ';
comment on column FACT_100105_LOST_MAC.lost_pay
  is '�����豸��ʧ';
comment on column FACT_100105_LOST_MAC.data_source
  is '����Դ';
create index IDX58_100105 on FACT_100105_LOST_MAC (CHANNELID);
create index IDX59_100105 on FACT_100105_LOST_MAC (SERVERID);
create index IDX60_100105 on FACT_100105_LOST_MAC (STATDATE);

prompt
prompt Creating table FACT_100105_LOST_USER
prompt ====================================
prompt
create table FACT_100105_LOST_USER
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_LOST_USER
  is '�û���ʧ������';
comment on column FACT_100105_LOST_USER.statdate
  is 'ͳ������';
comment on column FACT_100105_LOST_USER.lostdate
  is '��ʧ����';
comment on column FACT_100105_LOST_USER.channelid
  is '����ID';
comment on column FACT_100105_LOST_USER.serverid
  is '����ID';
comment on column FACT_100105_LOST_USER.appid
  is '��ƷID';
comment on column FACT_100105_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column FACT_100105_LOST_USER.lost_days
  is '��ʧ����';
comment on column FACT_100105_LOST_USER.lost_conn
  is '��Ծ�û���ʧ';
comment on column FACT_100105_LOST_USER.lost_pay
  is '�����û���ʧ';
comment on column FACT_100105_LOST_USER.data_source
  is '����Դ';
create index IDX61_100105 on FACT_100105_LOST_USER (CHANNELID);
create index IDX62_100105 on FACT_100105_LOST_USER (SERVERID);
create index IDX63_100105 on FACT_100105_LOST_USER (STATDATE);

prompt
prompt Creating table FACT_100105_LTV_MAC
prompt ==================================
prompt
create table FACT_100105_LTV_MAC
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_LTV_MAC
  is '�豸LTV������';
comment on column FACT_100105_LTV_MAC.statdate
  is 'ͳ������';
comment on column FACT_100105_LTV_MAC.ltvdate
  is '��ֵ����';
comment on column FACT_100105_LTV_MAC.channelid
  is '����';
comment on column FACT_100105_LTV_MAC.serverid
  is '����';
comment on column FACT_100105_LTV_MAC.appid
  is '��Ʒid';
comment on column FACT_100105_LTV_MAC.ltv_days
  is 'ltv��';
comment on column FACT_100105_LTV_MAC.payamount
  is '���ѽ��';
comment on column FACT_100105_LTV_MAC.data_source
  is '������Դ';
create index IDX64_100105 on FACT_100105_LTV_MAC (CHANNELID);
create index IDX65_100105 on FACT_100105_LTV_MAC (SERVERID);
create index IDX66_100105 on FACT_100105_LTV_MAC (STATDATE);

prompt
prompt Creating table FACT_100105_LTV_USER
prompt ===================================
prompt
create table FACT_100105_LTV_USER
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_LTV_USER
  is '�û�LTV������';
comment on column FACT_100105_LTV_USER.statdate
  is 'ͳ������';
comment on column FACT_100105_LTV_USER.ltvdate
  is '��ֵ����';
comment on column FACT_100105_LTV_USER.channelid
  is '����';
comment on column FACT_100105_LTV_USER.serverid
  is '����';
comment on column FACT_100105_LTV_USER.appid
  is '��Ʒid';
comment on column FACT_100105_LTV_USER.ltv_days
  is 'ltv��';
comment on column FACT_100105_LTV_USER.payamount
  is '���ѽ��';
comment on column FACT_100105_LTV_USER.data_source
  is '������Դ';
create index IDX67_100105 on FACT_100105_LTV_USER (CHANNELID);
create index IDX68_100105 on FACT_100105_LTV_USER (SERVERID);
create index IDX69_100105 on FACT_100105_LTV_USER (STATDATE);

prompt
prompt Creating table FACT_100105_MISS_FIRST
prompt =====================================
prompt
create table FACT_100105_MISS_FIRST
(
  statdate        VARCHAR2(10),
  channelid       VARCHAR2(50),
  serverid        VARCHAR2(50),
  appid           VARCHAR2(50),
  versionid       VARCHAR2(50),
  missionid       VARCHAR2(50),
  rolelevel       NUMBER,
  rolejob         VARCHAR2(50) default '0',
  firstenter_succ NUMBER,
  firstenter_fail NUMBER,
  loaddate        DATE,
  data_source     VARCHAR2(100)
)
;
comment on table FACT_100105_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column FACT_100105_MISS_FIRST.statdate
  is 'ͳ������';
comment on column FACT_100105_MISS_FIRST.channelid
  is '����';
comment on column FACT_100105_MISS_FIRST.serverid
  is '����';
comment on column FACT_100105_MISS_FIRST.appid
  is '��ƷID';
comment on column FACT_100105_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_MISS_FIRST.missionid
  is '�ؿ�ID';
comment on column FACT_100105_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column FACT_100105_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column FACT_100105_MISS_FIRST.firstenter_succ
  is '��һ�ν���ؿ��ɹ���';
comment on column FACT_100105_MISS_FIRST.firstenter_fail
  is '��һ�ν���ؿ�ʧ����';
comment on column FACT_100105_MISS_FIRST.data_source
  is '������Դ';
create index IDX70_100105 on FACT_100105_MISS_FIRST (CHANNELID);
create index IDX71_100105 on FACT_100105_MISS_FIRST (SERVERID);
create index IDX72_100105 on FACT_100105_MISS_FIRST (STATDATE);

prompt
prompt Creating table FACT_100105_NET
prompt ==============================
prompt
create table FACT_100105_NET
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_net    VARCHAR2(50),
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_NET
  is '������ʽ������';
comment on column FACT_100105_NET.statdate
  is 'ͳ������';
comment on column FACT_100105_NET.channelid
  is '����';
comment on column FACT_100105_NET.serverid
  is '����';
comment on column FACT_100105_NET.appid
  is '��Ʒid';
comment on column FACT_100105_NET.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_NET.dvid_net
  is '������ʽ';
comment on column FACT_100105_NET.conncount
  is '������';
comment on column FACT_100105_NET.data_source
  is '������Դ';
create index IDX73_100105 on FACT_100105_NET (CHANNELID);
create index IDX74_100105 on FACT_100105_NET (SERVERID);
create index IDX75_100105 on FACT_100105_NET (STATDATE);

prompt
prompt Creating table FACT_100105_OPERATOR
prompt ===================================
prompt
create table FACT_100105_OPERATOR
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  dvid_operator VARCHAR2(50),
  conncount     NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100105_OPERATOR
  is '��Ӫ�̷�����';
comment on column FACT_100105_OPERATOR.statdate
  is 'ͳ������';
comment on column FACT_100105_OPERATOR.channelid
  is '����';
comment on column FACT_100105_OPERATOR.serverid
  is '����';
comment on column FACT_100105_OPERATOR.appid
  is '��Ʒid';
comment on column FACT_100105_OPERATOR.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_OPERATOR.dvid_operator
  is '������ʽ';
comment on column FACT_100105_OPERATOR.conncount
  is '������';
comment on column FACT_100105_OPERATOR.data_source
  is '������Դ';
create index IDX76_100105 on FACT_100105_OPERATOR (CHANNELID);
create index IDX77_100105 on FACT_100105_OPERATOR (SERVERID);
create index IDX78_100105 on FACT_100105_OPERATOR (STATDATE);

prompt
prompt Creating table FACT_100105_ORDER
prompt ================================
prompt
create table FACT_100105_ORDER
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100105_ORDER
  is '����������';
comment on column FACT_100105_ORDER.statdate
  is 'ͳ������';
comment on column FACT_100105_ORDER.channelid
  is '����';
comment on column FACT_100105_ORDER.serverid
  is '����';
comment on column FACT_100105_ORDER.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100105_ORDER.appid
  is '��Ʒid';
comment on column FACT_100105_ORDER.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_ORDER.paysucccount
  is '�ɹ�������';
comment on column FACT_100105_ORDER.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100105_ORDER.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100105_ORDER.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100105_ORDER.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100105_ORDER.payfailnum
  is '����ʧ������';
comment on column FACT_100105_ORDER.data_source
  is '������Դ';
create index IDX79_100105 on FACT_100105_ORDER (CHANNELID);
create index IDX80_100105 on FACT_100105_ORDER (SERVERID);
create index IDX81_100105 on FACT_100105_ORDER (STATDATE);

prompt
prompt Creating table FACT_100105_ORDER_HOUR
prompt =====================================
prompt
create table FACT_100105_ORDER_HOUR
(
  statdate      VARCHAR2(20),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100105_ORDER_HOUR
  is '����Сʱ������';
comment on column FACT_100105_ORDER_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100105_ORDER_HOUR.channelid
  is '����';
comment on column FACT_100105_ORDER_HOUR.serverid
  is '����';
comment on column FACT_100105_ORDER_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100105_ORDER_HOUR.appid
  is '��Ʒid';
comment on column FACT_100105_ORDER_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_ORDER_HOUR.paysucccount
  is '�ɹ�������';
comment on column FACT_100105_ORDER_HOUR.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100105_ORDER_HOUR.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100105_ORDER_HOUR.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100105_ORDER_HOUR.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100105_ORDER_HOUR.payfailnum
  is '����ʧ������';
comment on column FACT_100105_ORDER_HOUR.data_source
  is '������Դ';
create index IDX177_100105 on FACT_100105_ORDER_HOUR (CHANNELID);
create index IDX178_100105 on FACT_100105_ORDER_HOUR (SERVERID);
create index IDX179_100105 on FACT_100105_ORDER_HOUR (STATDATE);

prompt
prompt Creating table FACT_100105_ORDER_MONTH
prompt ======================================
prompt
create table FACT_100105_ORDER_MONTH
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100105_ORDER_MONTH
  is '�¶���������';
comment on column FACT_100105_ORDER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100105_ORDER_MONTH.channelid
  is '����';
comment on column FACT_100105_ORDER_MONTH.serverid
  is '����';
comment on column FACT_100105_ORDER_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100105_ORDER_MONTH.appid
  is '��Ʒid';
comment on column FACT_100105_ORDER_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_ORDER_MONTH.paysucccount
  is '�ɹ�������';
comment on column FACT_100105_ORDER_MONTH.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100105_ORDER_MONTH.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100105_ORDER_MONTH.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100105_ORDER_MONTH.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100105_ORDER_MONTH.payfailnum
  is '����ʧ������';
comment on column FACT_100105_ORDER_MONTH.data_source
  is '������Դ';
create index IDX191_100105 on FACT_100105_ORDER_MONTH (CHANNELID);
create index IDX192_100105 on FACT_100105_ORDER_MONTH (SERVERID);
create index IDX193_100105 on FACT_100105_ORDER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100105_ORDER_WEEK
prompt =====================================
prompt
create table FACT_100105_ORDER_WEEK
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100105_ORDER_WEEK
  is '�ܶ���������';
comment on column FACT_100105_ORDER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100105_ORDER_WEEK.channelid
  is '����';
comment on column FACT_100105_ORDER_WEEK.serverid
  is '����';
comment on column FACT_100105_ORDER_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100105_ORDER_WEEK.appid
  is '��Ʒid';
comment on column FACT_100105_ORDER_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_ORDER_WEEK.paysucccount
  is '�ɹ�������';
comment on column FACT_100105_ORDER_WEEK.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100105_ORDER_WEEK.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100105_ORDER_WEEK.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100105_ORDER_WEEK.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100105_ORDER_WEEK.payfailnum
  is '����ʧ������';
comment on column FACT_100105_ORDER_WEEK.data_source
  is '������Դ';
create index IDX188_100105 on FACT_100105_ORDER_WEEK (CHANNELID);
create index IDX189_100105 on FACT_100105_ORDER_WEEK (SERVERID);
create index IDX190_100105 on FACT_100105_ORDER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100105_PAYAMOUNT_DAY
prompt ========================================
prompt
create table FACT_100105_PAYAMOUNT_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_PAYAMOUNT_DAY
  is '�ճ�ֵ��������';
comment on column FACT_100105_PAYAMOUNT_DAY.statdate
  is 'ͳ������';
comment on column FACT_100105_PAYAMOUNT_DAY.channelid
  is '����';
comment on column FACT_100105_PAYAMOUNT_DAY.serverid
  is '����';
comment on column FACT_100105_PAYAMOUNT_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100105_PAYAMOUNT_DAY.appid
  is '��Ʒid';
comment on column FACT_100105_PAYAMOUNT_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_PAYAMOUNT_DAY.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100105_PAYAMOUNT_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100105_PAYAMOUNT_DAY.data_source
  is '������Դ';
create index IDX82_100105 on FACT_100105_PAYAMOUNT_DAY (CHANNELID);
create index IDX83_100105 on FACT_100105_PAYAMOUNT_DAY (SERVERID);
create index IDX84_100105 on FACT_100105_PAYAMOUNT_DAY (STATDATE);

prompt
prompt Creating table FACT_100105_PAYAMOUNT_MONTH
prompt ==========================================
prompt
create table FACT_100105_PAYAMOUNT_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_PAYAMOUNT_MONTH
  is '�³�ֵ��������';
comment on column FACT_100105_PAYAMOUNT_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100105_PAYAMOUNT_MONTH.channelid
  is '����';
comment on column FACT_100105_PAYAMOUNT_MONTH.serverid
  is '����';
comment on column FACT_100105_PAYAMOUNT_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100105_PAYAMOUNT_MONTH.appid
  is '��Ʒid';
comment on column FACT_100105_PAYAMOUNT_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_PAYAMOUNT_MONTH.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100105_PAYAMOUNT_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100105_PAYAMOUNT_MONTH.data_source
  is '������Դ';
create index IDX88_100105 on FACT_100105_PAYAMOUNT_MONTH (CHANNELID);
create index IDX89_100105 on FACT_100105_PAYAMOUNT_MONTH (SERVERID);
create index IDX90_100105 on FACT_100105_PAYAMOUNT_MONTH (STATDATE);

prompt
prompt Creating table FACT_100105_PAYAMOUNT_WEEK
prompt =========================================
prompt
create table FACT_100105_PAYAMOUNT_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_PAYAMOUNT_WEEK
  is '�ܳ�ֵ��������';
comment on column FACT_100105_PAYAMOUNT_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100105_PAYAMOUNT_WEEK.channelid
  is '����';
comment on column FACT_100105_PAYAMOUNT_WEEK.serverid
  is '����';
comment on column FACT_100105_PAYAMOUNT_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100105_PAYAMOUNT_WEEK.appid
  is '��Ʒid';
comment on column FACT_100105_PAYAMOUNT_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_PAYAMOUNT_WEEK.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100105_PAYAMOUNT_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100105_PAYAMOUNT_WEEK.data_source
  is '������Դ';
create index IDX85_100105 on FACT_100105_PAYAMOUNT_WEEK (CHANNELID);
create index IDX86_100105 on FACT_100105_PAYAMOUNT_WEEK (SERVERID);
create index IDX87_100105 on FACT_100105_PAYAMOUNT_WEEK (STATDATE);

prompt
prompt Creating table FACT_100105_PAYNUM_DAY
prompt =====================================
prompt
create table FACT_100105_PAYNUM_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_PAYNUM_DAY
  is '�ճ�ֵ����������';
comment on column FACT_100105_PAYNUM_DAY.statdate
  is 'ͳ������';
comment on column FACT_100105_PAYNUM_DAY.channelid
  is '����';
comment on column FACT_100105_PAYNUM_DAY.serverid
  is '����';
comment on column FACT_100105_PAYNUM_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100105_PAYNUM_DAY.appid
  is '��Ʒid';
comment on column FACT_100105_PAYNUM_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_PAYNUM_DAY.paynum
  is '��ֵ����';
comment on column FACT_100105_PAYNUM_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100105_PAYNUM_DAY.data_source
  is '������Դ';
create index IDX97_100105 on FACT_100105_PAYNUM_DAY (CHANNELID);
create index IDX98_100105 on FACT_100105_PAYNUM_DAY (SERVERID);
create index IDX99_100105 on FACT_100105_PAYNUM_DAY (STATDATE);

prompt
prompt Creating table FACT_100105_PAYNUM_MONTH
prompt =======================================
prompt
create table FACT_100105_PAYNUM_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_PAYNUM_MONTH
  is '�³�ֵ����������';
comment on column FACT_100105_PAYNUM_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100105_PAYNUM_MONTH.channelid
  is '����';
comment on column FACT_100105_PAYNUM_MONTH.serverid
  is '����';
comment on column FACT_100105_PAYNUM_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100105_PAYNUM_MONTH.appid
  is '��Ʒid';
comment on column FACT_100105_PAYNUM_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_PAYNUM_MONTH.paynum
  is '��ֵ����';
comment on column FACT_100105_PAYNUM_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100105_PAYNUM_MONTH.data_source
  is '������Դ';
create index IDX91_100105 on FACT_100105_PAYNUM_MONTH (CHANNELID);
create index IDX92_100105 on FACT_100105_PAYNUM_MONTH (SERVERID);
create index IDX93_100105 on FACT_100105_PAYNUM_MONTH (STATDATE);

prompt
prompt Creating table FACT_100105_PAYNUM_WEEK
prompt ======================================
prompt
create table FACT_100105_PAYNUM_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_PAYNUM_WEEK
  is '�ܳ�ֵ����������';
comment on column FACT_100105_PAYNUM_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100105_PAYNUM_WEEK.channelid
  is '����';
comment on column FACT_100105_PAYNUM_WEEK.serverid
  is '����';
comment on column FACT_100105_PAYNUM_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100105_PAYNUM_WEEK.appid
  is '��Ʒid';
comment on column FACT_100105_PAYNUM_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_PAYNUM_WEEK.paynum
  is '��ֵ����';
comment on column FACT_100105_PAYNUM_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100105_PAYNUM_WEEK.data_source
  is '������Դ';
create index IDX94_100105 on FACT_100105_PAYNUM_WEEK (CHANNELID);
create index IDX95_100105 on FACT_100105_PAYNUM_WEEK (SERVERID);
create index IDX96_100105 on FACT_100105_PAYNUM_WEEK (STATDATE);

prompt
prompt Creating table FACT_100105_PAYTYPE
prompt ==================================
prompt
create table FACT_100105_PAYTYPE
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paytypeid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_PAYTYPE
  is '��ֵ���ͷ�����';
comment on column FACT_100105_PAYTYPE.statdate
  is 'ͳ������';
comment on column FACT_100105_PAYTYPE.channelid
  is '����';
comment on column FACT_100105_PAYTYPE.serverid
  is '����';
comment on column FACT_100105_PAYTYPE.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100105_PAYTYPE.appid
  is '��Ʒid';
comment on column FACT_100105_PAYTYPE.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_PAYTYPE.paytypeid
  is '��ֵ����';
comment on column FACT_100105_PAYTYPE.payamount
  is '��ֵ���';
comment on column FACT_100105_PAYTYPE.paycount
  is '��ֵ����';
comment on column FACT_100105_PAYTYPE.paynum
  is '��ֵ����';
comment on column FACT_100105_PAYTYPE.data_source
  is '������Դ';
create index IDX100_100105 on FACT_100105_PAYTYPE (CHANNELID);
create index IDX101_100105 on FACT_100105_PAYTYPE (SERVERID);
create index IDX102_100105 on FACT_100105_PAYTYPE (STATDATE);

prompt
prompt Creating table FACT_100105_PAYWAY
prompt =================================
prompt
create table FACT_100105_PAYWAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paywayid    VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_PAYWAY
  is '��ֵ��ʽ������';
comment on column FACT_100105_PAYWAY.statdate
  is 'ͳ������';
comment on column FACT_100105_PAYWAY.channelid
  is '����';
comment on column FACT_100105_PAYWAY.serverid
  is '����';
comment on column FACT_100105_PAYWAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100105_PAYWAY.appid
  is '��Ʒid';
comment on column FACT_100105_PAYWAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_PAYWAY.paywayid
  is '��ֵ��ʽ';
comment on column FACT_100105_PAYWAY.payamount
  is '��ֵ���';
comment on column FACT_100105_PAYWAY.paycount
  is '��ֵ����';
comment on column FACT_100105_PAYWAY.paynum
  is '��ֵ����';
comment on column FACT_100105_PAYWAY.data_source
  is '������Դ';
create index IDX103_100105 on FACT_100105_PAYWAY (CHANNELID);
create index IDX104_100105 on FACT_100105_PAYWAY (SERVERID);
create index IDX105_100105 on FACT_100105_PAYWAY (STATDATE);

prompt
prompt Creating table FACT_100105_REGION
prompt =================================
prompt
create table FACT_100105_REGION
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  country     VARCHAR2(50),
  province    VARCHAR2(50),
  city        VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_REGION
  is '���������';
comment on column FACT_100105_REGION.statdate
  is 'ͳ������';
comment on column FACT_100105_REGION.channelid
  is '����';
comment on column FACT_100105_REGION.serverid
  is '����';
comment on column FACT_100105_REGION.appid
  is '��Ʒid';
comment on column FACT_100105_REGION.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_REGION.country
  is '����';
comment on column FACT_100105_REGION.province
  is 'ʡ';
comment on column FACT_100105_REGION.city
  is '��';
comment on column FACT_100105_REGION.newcount
  is '������';
comment on column FACT_100105_REGION.conncount
  is '������';
comment on column FACT_100105_REGION.paycount
  is '������';
comment on column FACT_100105_REGION.payamount
  is '���ѽ��';
comment on column FACT_100105_REGION.data_source
  is '������Դ';
create index IDX106_100105 on FACT_100105_REGION (CHANNELID);
create index IDX107_100105 on FACT_100105_REGION (SERVERID);
create index IDX108_100105 on FACT_100105_REGION (STATDATE);

prompt
prompt Creating table FACT_100105_REMAIN_MAC
prompt =====================================
prompt
create table FACT_100105_REMAIN_MAC
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_REMAIN_MAC
  is '�豸�����';
comment on column FACT_100105_REMAIN_MAC.statdate
  is 'ͳ������';
comment on column FACT_100105_REMAIN_MAC.conndate
  is '��������';
comment on column FACT_100105_REMAIN_MAC.channelid
  is '����ID';
comment on column FACT_100105_REMAIN_MAC.serverid
  is '����ID';
comment on column FACT_100105_REMAIN_MAC.appid
  is '��ƷID';
comment on column FACT_100105_REMAIN_MAC.remain_days
  is '��������';
comment on column FACT_100105_REMAIN_MAC.new_remain
  is '��������';
comment on column FACT_100105_REMAIN_MAC.conn_remain
  is '��������';
comment on column FACT_100105_REMAIN_MAC.pay_remain
  is '��������';
comment on column FACT_100105_REMAIN_MAC.data_source
  is '����Դ';
create index IDX109_100105 on FACT_100105_REMAIN_MAC (CHANNELID);
create index IDX110_100105 on FACT_100105_REMAIN_MAC (SERVERID);
create index IDX111_100105 on FACT_100105_REMAIN_MAC (STATDATE);

prompt
prompt Creating table FACT_100105_REMAIN_USER
prompt ======================================
prompt
create table FACT_100105_REMAIN_USER
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_REMAIN_USER
  is '�û������';
comment on column FACT_100105_REMAIN_USER.statdate
  is 'ͳ������';
comment on column FACT_100105_REMAIN_USER.conndate
  is '��������';
comment on column FACT_100105_REMAIN_USER.channelid
  is '����ID';
comment on column FACT_100105_REMAIN_USER.serverid
  is '����ID';
comment on column FACT_100105_REMAIN_USER.appid
  is '��ƷID';
comment on column FACT_100105_REMAIN_USER.remain_days
  is '��������';
comment on column FACT_100105_REMAIN_USER.new_remain
  is '��������';
comment on column FACT_100105_REMAIN_USER.conn_remain
  is '��������';
comment on column FACT_100105_REMAIN_USER.pay_remain
  is '��������';
comment on column FACT_100105_REMAIN_USER.data_source
  is '����Դ';
create index IDX112_100105 on FACT_100105_REMAIN_USER (CHANNELID);
create index IDX113_100105 on FACT_100105_REMAIN_USER (SERVERID);
create index IDX114_100105 on FACT_100105_REMAIN_USER (STATDATE);

prompt
prompt Creating table FACT_100105_VC
prompt =============================
prompt
create table FACT_100105_VC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcamount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100105_VC
  is '������ҷ�����';
comment on column FACT_100105_VC.statdate
  is 'ͳ������';
comment on column FACT_100105_VC.channelid
  is '����';
comment on column FACT_100105_VC.serverid
  is '����';
comment on column FACT_100105_VC.appid
  is '��Ʒid';
comment on column FACT_100105_VC.versionid
  is '��Ʒ�汾';
comment on column FACT_100105_VC.vctype
  is '�����������';
comment on column FACT_100105_VC.vcusetype
  is '�������ʹ������';
comment on column FACT_100105_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column FACT_100105_VC.vcamount
  is '������ҽ��';
comment on column FACT_100105_VC.data_source
  is '������Դ';
create index IDX115_100105 on FACT_100105_VC (CHANNELID);
create index IDX116_100105 on FACT_100105_VC (SERVERID);
create index IDX117_100105 on FACT_100105_VC (STATDATE);

prompt
prompt Creating table FACT_100131_BACK_MAC
prompt ===================================
prompt
create table FACT_100131_BACK_MAC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_BACK_MAC
  is '�豸����������';
comment on column FACT_100131_BACK_MAC.statdate
  is 'ͳ������';
comment on column FACT_100131_BACK_MAC.channelid
  is '����ID';
comment on column FACT_100131_BACK_MAC.serverid
  is '����ID';
comment on column FACT_100131_BACK_MAC.appid
  is '��ƷID';
comment on column FACT_100131_BACK_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100131_BACK_MAC.back_conn
  is '��Ծ�豸������';
comment on column FACT_100131_BACK_MAC.back_pay
  is '�����豸������';
comment on column FACT_100131_BACK_MAC.data_source
  is '����Դ';
create index IDX1_100131 on FACT_100131_BACK_MAC (CHANNELID);
create index IDX2_100131 on FACT_100131_BACK_MAC (SERVERID);
create index IDX3_100131 on FACT_100131_BACK_MAC (STATDATE);

prompt
prompt Creating table FACT_100131_BACK_MAC_MONTH
prompt =========================================
prompt
create table FACT_100131_BACK_MAC_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_BACK_MAC_MONTH
  is '�豸����������';
comment on column FACT_100131_BACK_MAC_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100131_BACK_MAC_MONTH.channelid
  is '����ID';
comment on column FACT_100131_BACK_MAC_MONTH.serverid
  is '����ID';
comment on column FACT_100131_BACK_MAC_MONTH.appid
  is '��ƷID';
comment on column FACT_100131_BACK_MAC_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100131_BACK_MAC_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100131_BACK_MAC_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100131_BACK_MAC_MONTH.data_source
  is '����Դ';
create index IDX4_100131 on FACT_100131_BACK_MAC_MONTH (CHANNELID);
create index IDX5_100131 on FACT_100131_BACK_MAC_MONTH (SERVERID);
create index IDX6_100131 on FACT_100131_BACK_MAC_MONTH (STATDATE);

prompt
prompt Creating table FACT_100131_BACK_MAC_WEEK
prompt ========================================
prompt
create table FACT_100131_BACK_MAC_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_BACK_MAC_WEEK
  is '�豸����������';
comment on column FACT_100131_BACK_MAC_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100131_BACK_MAC_WEEK.channelid
  is '����ID';
comment on column FACT_100131_BACK_MAC_WEEK.serverid
  is '����ID';
comment on column FACT_100131_BACK_MAC_WEEK.appid
  is '��ƷID';
comment on column FACT_100131_BACK_MAC_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100131_BACK_MAC_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100131_BACK_MAC_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100131_BACK_MAC_WEEK.data_source
  is '����Դ';
create index IDX7_100131 on FACT_100131_BACK_MAC_WEEK (CHANNELID);
create index IDX8_100131 on FACT_100131_BACK_MAC_WEEK (SERVERID);
create index IDX9_100131 on FACT_100131_BACK_MAC_WEEK (STATDATE);

prompt
prompt Creating table FACT_100131_BACK_USER
prompt ====================================
prompt
create table FACT_100131_BACK_USER
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
nologging;
comment on table FACT_100131_BACK_USER
  is '�û�����������';
comment on column FACT_100131_BACK_USER.statdate
  is 'ͳ������';
comment on column FACT_100131_BACK_USER.channelid
  is '����ID';
comment on column FACT_100131_BACK_USER.serverid
  is '����ID';
comment on column FACT_100131_BACK_USER.appid
  is '��ƷID';
comment on column FACT_100131_BACK_USER.lost_days
  is '��ʧ����';
comment on column FACT_100131_BACK_USER.back_conn
  is '��Ծ�û�������';
comment on column FACT_100131_BACK_USER.back_pay
  is '�����û�������';
comment on column FACT_100131_BACK_USER.data_source
  is '����Դ';
create index IDX16_100131 on FACT_100131_BACK_USER (CHANNELID);
create index IDX17_100131 on FACT_100131_BACK_USER (SERVERID);
create index IDX18_100131 on FACT_100131_BACK_USER (STATDATE);

prompt
prompt Creating table FACT_100131_BACK_USER_MONTH
prompt ==========================================
prompt
create table FACT_100131_BACK_USER_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_BACK_USER_MONTH
  is '�豸����������';
comment on column FACT_100131_BACK_USER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100131_BACK_USER_MONTH.channelid
  is '����ID';
comment on column FACT_100131_BACK_USER_MONTH.serverid
  is '����ID';
comment on column FACT_100131_BACK_USER_MONTH.appid
  is '��ƷID';
comment on column FACT_100131_BACK_USER_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100131_BACK_USER_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100131_BACK_USER_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100131_BACK_USER_MONTH.data_source
  is '����Դ';
create index IDX13_100131 on FACT_100131_BACK_USER_MONTH (CHANNELID);
create index IDX14_100131 on FACT_100131_BACK_USER_MONTH (SERVERID);
create index IDX15_100131 on FACT_100131_BACK_USER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100131_BACK_USER_WEEK
prompt =========================================
prompt
create table FACT_100131_BACK_USER_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_BACK_USER_WEEK
  is '�豸����������';
comment on column FACT_100131_BACK_USER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100131_BACK_USER_WEEK.channelid
  is '����ID';
comment on column FACT_100131_BACK_USER_WEEK.serverid
  is '����ID';
comment on column FACT_100131_BACK_USER_WEEK.appid
  is '��ƷID';
comment on column FACT_100131_BACK_USER_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100131_BACK_USER_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100131_BACK_USER_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100131_BACK_USER_WEEK.data_source
  is '����Դ';
create index IDX10_100131 on FACT_100131_BACK_USER_WEEK (CHANNELID);
create index IDX11_100131 on FACT_100131_BACK_USER_WEEK (SERVERID);
create index IDX12_100131 on FACT_100131_BACK_USER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100131_CEVENT
prompt =================================
prompt
create table FACT_100131_CEVENT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  eventkey    VARCHAR2(50),
  eventcount  NUMBER,
  eventnum    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_CEVENT
  is '�Զ��������';
comment on column FACT_100131_CEVENT.statdate
  is 'ͳ������';
comment on column FACT_100131_CEVENT.channelid
  is '����';
comment on column FACT_100131_CEVENT.serverid
  is '����';
comment on column FACT_100131_CEVENT.appid
  is '��Ʒid';
comment on column FACT_100131_CEVENT.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100131_CEVENT.eventcount
  is '�¼��û���';
comment on column FACT_100131_CEVENT.eventnum
  is '�¼�����';
comment on column FACT_100131_CEVENT.data_source
  is '������Դ';
create index IDX181_100131 on FACT_100131_CEVENT (CHANNELID);
create index IDX182_100131 on FACT_100131_CEVENT (SERVERID);
create index IDX183_100131 on FACT_100131_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100131_CEVENT_PAR
prompt =====================================
prompt
create table FACT_100131_CEVENT_PAR
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  ilevel         NUMBER,
  eventkey       VARCHAR2(100),
  eventpar_key   VARCHAR2(100),
  eventpar_value VARCHAR2(100),
  eventcount     NUMBER,
  eventnum       NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100131_CEVENT_PAR
  is '�Զ������������';
comment on column FACT_100131_CEVENT_PAR.statdate
  is 'ͳ������';
comment on column FACT_100131_CEVENT_PAR.channelid
  is '����';
comment on column FACT_100131_CEVENT_PAR.serverid
  is '����';
comment on column FACT_100131_CEVENT_PAR.appid
  is '��Ʒid';
comment on column FACT_100131_CEVENT_PAR.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_CEVENT_PAR.ilevel
  is '��ɫ�ȼ�';
comment on column FACT_100131_CEVENT_PAR.eventkey
  is '�¼�����';
comment on column FACT_100131_CEVENT_PAR.eventpar_key
  is '�¼�����';
comment on column FACT_100131_CEVENT_PAR.eventpar_value
  is '�¼�����ֵ';
comment on column FACT_100131_CEVENT_PAR.eventcount
  is '�¼��û���';
comment on column FACT_100131_CEVENT_PAR.eventnum
  is '�¼�����';
comment on column FACT_100131_CEVENT_PAR.data_source
  is '������Դ';
create index IDX185_100131 on FACT_100131_CEVENT_PAR (CHANNELID);
create index IDX186_100131 on FACT_100131_CEVENT_PAR (SERVERID);
create index IDX187_100131 on FACT_100131_CEVENT_PAR (STATDATE);

prompt
prompt Creating table FACT_100131_COMP_CEVENT
prompt ======================================
prompt
create table FACT_100131_COMP_CEVENT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(10),
  channelid   VARCHAR2(50),
  gameversion VARCHAR2(50),
  serverid    VARCHAR2(50),
  ilevel      NUMBER,
  eventkey    VARCHAR2(100),
  compid      VARCHAR2(50),
  caltype     VARCHAR2(50),
  dimpars     VARCHAR2(2000),
  comp_data   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_COMP_CEVENT
  is '�Զ����¼���Ϸ�����';
comment on column FACT_100131_COMP_CEVENT.statdate
  is '����';
comment on column FACT_100131_COMP_CEVENT.appid
  is '��Ϸ�� appid';
comment on column FACT_100131_COMP_CEVENT.channelid
  is '���� ID';
comment on column FACT_100131_COMP_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column FACT_100131_COMP_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column FACT_100131_COMP_CEVENT.ilevel
  is '��ҵȼ�';
comment on column FACT_100131_COMP_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100131_COMP_CEVENT.compid
  is '��ϼ����¼�ID';
comment on column FACT_100131_COMP_CEVENT.caltype
  is '��ϼ����¼���������';
comment on column FACT_100131_COMP_CEVENT.dimpars
  is '��ϲ���';
comment on column FACT_100131_COMP_CEVENT.comp_data
  is '��ϼ�����';
create index IDX184_100131 on FACT_100131_COMP_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100131_DAILY_REPORT
prompt =======================================
prompt
create table FACT_100131_DAILY_REPORT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_DAILY_REPORT
  is '�ձ�����';
comment on column FACT_100131_DAILY_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100131_DAILY_REPORT.appid
  is '��ƷID';
comment on column FACT_100131_DAILY_REPORT.channelid
  is '����';
comment on column FACT_100131_DAILY_REPORT.serverid
  is '����';
comment on column FACT_100131_DAILY_REPORT.indexid
  is 'ָ��';
comment on column FACT_100131_DAILY_REPORT.indtype
  is 'ָ������';
comment on column FACT_100131_DAILY_REPORT.rpt_data
  is '����';
create index IDX176_100131 on FACT_100131_DAILY_REPORT (STATDATE);

prompt
prompt Creating table FACT_100131_DVID
prompt ===============================
prompt
create table FACT_100131_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_model  VARCHAR2(200),
  dvid_res    VARCHAR2(50),
  dvid_os     VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_DVID
  is '�豸������';
comment on column FACT_100131_DVID.statdate
  is 'ͳ������';
comment on column FACT_100131_DVID.channelid
  is '����';
comment on column FACT_100131_DVID.serverid
  is '����';
comment on column FACT_100131_DVID.appid
  is '��Ʒid';
comment on column FACT_100131_DVID.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_DVID.dvid_model
  is '����';
comment on column FACT_100131_DVID.dvid_res
  is '�豸�ֱ���';
comment on column FACT_100131_DVID.dvid_os
  is '�豸����ϵͳ';
comment on column FACT_100131_DVID.newcount
  is '�����û���';
comment on column FACT_100131_DVID.conncount
  is '�����û���';
comment on column FACT_100131_DVID.data_source
  is '������Դ';
create index IDX19_100131 on FACT_100131_DVID (CHANNELID);
create index IDX20_100131 on FACT_100131_DVID (SERVERID);
create index IDX21_100131 on FACT_100131_DVID (STATDATE);

prompt
prompt Creating table FACT_100131_FIRSTPAY
prompt ===================================
prompt
create table FACT_100131_FIRSTPAY
(
  statdate         VARCHAR2(10),
  firstpaydate     VARCHAR2(10),
  channelid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  datatype         VARCHAR2(50),
  appid            VARCHAR2(50),
  first_payfromreg NUMBER,
  first_paycount   NUMBER,
  payamount        NUMBER,
  loaddate         DATE default SYSDATE,
  data_source      VARCHAR2(100)
)
;
comment on table FACT_100131_FIRSTPAY
  is '�����û��״γ�ֵ������';
comment on column FACT_100131_FIRSTPAY.statdate
  is 'ͳ������';
comment on column FACT_100131_FIRSTPAY.firstpaydate
  is '�״θ�������';
comment on column FACT_100131_FIRSTPAY.channelid
  is '����';
comment on column FACT_100131_FIRSTPAY.serverid
  is '����';
comment on column FACT_100131_FIRSTPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100131_FIRSTPAY.appid
  is '��Ʒid';
comment on column FACT_100131_FIRSTPAY.first_payfromreg
  is 'ע���ڼ��쿪ʼ��ֵ(1��2��..7..30..)';
comment on column FACT_100131_FIRSTPAY.first_paycount
  is '���������û���';
comment on column FACT_100131_FIRSTPAY.payamount
  is '�ۼƵ��ڼ���ĳ�ֵ�ܶ�';
comment on column FACT_100131_FIRSTPAY.data_source
  is '������Դ';
create index IDX22_100131 on FACT_100131_FIRSTPAY (CHANNELID);
create index IDX23_100131 on FACT_100131_FIRSTPAY (SERVERID);
create index IDX24_100131 on FACT_100131_FIRSTPAY (STATDATE);

prompt
prompt Creating table FACT_100131_FIRSTPAY_AMOUNT
prompt ==========================================
prompt
create table FACT_100131_FIRSTPAY_AMOUNT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_FIRSTPAY_AMOUNT
  is '�״θ��ѽ�������';
comment on column FACT_100131_FIRSTPAY_AMOUNT.statdate
  is 'ͳ������';
comment on column FACT_100131_FIRSTPAY_AMOUNT.channelid
  is '����';
comment on column FACT_100131_FIRSTPAY_AMOUNT.serverid
  is '��������';
comment on column FACT_100131_FIRSTPAY_AMOUNT.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100131_FIRSTPAY_AMOUNT.appid
  is '��Ʒid';
comment on column FACT_100131_FIRSTPAY_AMOUNT.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_FIRSTPAY_AMOUNT.payamount
  is '�״θ��ѽ��';
comment on column FACT_100131_FIRSTPAY_AMOUNT.paycount
  is '�״θ��ѽ���Ӧ������';
create index IDX25_100131 on FACT_100131_FIRSTPAY_AMOUNT (CHANNELID);
create index IDX26_100131 on FACT_100131_FIRSTPAY_AMOUNT (SERVERID);
create index IDX27_100131 on FACT_100131_FIRSTPAY_AMOUNT (STATDATE);

prompt
prompt Creating table FACT_100131_GENERAL_DAY
prompt ======================================
prompt
create table FACT_100131_GENERAL_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_GENERAL_DAY
  is '�ջ���������';
comment on column FACT_100131_GENERAL_DAY.statdate
  is 'ͳ������';
comment on column FACT_100131_GENERAL_DAY.channelid
  is '����';
comment on column FACT_100131_GENERAL_DAY.serverid
  is '����';
comment on column FACT_100131_GENERAL_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100131_GENERAL_DAY.appid
  is '��Ʒid';
comment on column FACT_100131_GENERAL_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_GENERAL_DAY.newcount
  is '������';
comment on column FACT_100131_GENERAL_DAY.conncount
  is '������';
comment on column FACT_100131_GENERAL_DAY.paycount
  is '������';
comment on column FACT_100131_GENERAL_DAY.payamount
  is '���ѽ��';
comment on column FACT_100131_GENERAL_DAY.data_source
  is '������Դ';
create index IDX28_100131 on FACT_100131_GENERAL_DAY (CHANNELID);
create index IDX29_100131 on FACT_100131_GENERAL_DAY (SERVERID);
create index IDX30_100131 on FACT_100131_GENERAL_DAY (STATDATE);

prompt
prompt Creating table FACT_100131_GENERAL_DAY_DVID
prompt ===========================================
prompt
create table FACT_100131_GENERAL_DAY_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_GENERAL_DAY_DVID
  is '���豸����������';
comment on column FACT_100131_GENERAL_DAY_DVID.statdate
  is 'ͳ������';
comment on column FACT_100131_GENERAL_DAY_DVID.channelid
  is '����';
comment on column FACT_100131_GENERAL_DAY_DVID.appid
  is '��Ʒid';
comment on column FACT_100131_GENERAL_DAY_DVID.newcount
  is '������';
comment on column FACT_100131_GENERAL_DAY_DVID.conncount
  is '������';
comment on column FACT_100131_GENERAL_DAY_DVID.data_source
  is '������Դ';
create index IDX31_100131 on FACT_100131_GENERAL_DAY_DVID (CHANNELID);
create index IDX33_100131 on FACT_100131_GENERAL_DAY_DVID (STATDATE);

prompt
prompt Creating table FACT_100131_GENERAL_HOUR
prompt =======================================
prompt
create table FACT_100131_GENERAL_HOUR
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_GENERAL_HOUR
  is 'Сʱ����������';
comment on column FACT_100131_GENERAL_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100131_GENERAL_HOUR.channelid
  is '����';
comment on column FACT_100131_GENERAL_HOUR.serverid
  is '����';
comment on column FACT_100131_GENERAL_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100131_GENERAL_HOUR.appid
  is '��Ʒid';
comment on column FACT_100131_GENERAL_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_GENERAL_HOUR.newcount
  is '������';
comment on column FACT_100131_GENERAL_HOUR.conncount
  is '������';
comment on column FACT_100131_GENERAL_HOUR.paycount
  is '������';
comment on column FACT_100131_GENERAL_HOUR.payamount
  is '���ѽ��';
comment on column FACT_100131_GENERAL_HOUR.data_source
  is '������Դ';
create index IDX34_100131 on FACT_100131_GENERAL_HOUR (CHANNELID);
create index IDX35_100131 on FACT_100131_GENERAL_HOUR (SERVERID);
create index IDX36_100131 on FACT_100131_GENERAL_HOUR (STATDATE);

prompt
prompt Creating table FACT_100131_GENERAL_HOUR_DVID
prompt ============================================
prompt
create table FACT_100131_GENERAL_HOUR_DVID
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_GENERAL_HOUR_DVID
  is 'Сʱ�豸����������';
comment on column FACT_100131_GENERAL_HOUR_DVID.statdate
  is 'ͳ������';
comment on column FACT_100131_GENERAL_HOUR_DVID.channelid
  is '����';
comment on column FACT_100131_GENERAL_HOUR_DVID.appid
  is '��Ʒid';
comment on column FACT_100131_GENERAL_HOUR_DVID.newcount
  is '������';
comment on column FACT_100131_GENERAL_HOUR_DVID.conncount
  is '������';
comment on column FACT_100131_GENERAL_HOUR_DVID.data_source
  is '������Դ';
create index IDX37_100131 on FACT_100131_GENERAL_HOUR_DVID (CHANNELID);
create index IDX39_100131 on FACT_100131_GENERAL_HOUR_DVID (STATDATE);

prompt
prompt Creating table FACT_100131_GENERAL_LEVEL
prompt ========================================
prompt
create table FACT_100131_GENERAL_LEVEL
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  rolelevel   NUMBER,
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_GENERAL_LEVEL
  is '�û��ȼ�������';
comment on column FACT_100131_GENERAL_LEVEL.statdate
  is 'ͳ������';
comment on column FACT_100131_GENERAL_LEVEL.channelid
  is '����';
comment on column FACT_100131_GENERAL_LEVEL.serverid
  is '����';
comment on column FACT_100131_GENERAL_LEVEL.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100131_GENERAL_LEVEL.appid
  is '��Ʒid';
comment on column FACT_100131_GENERAL_LEVEL.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_GENERAL_LEVEL.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100131_GENERAL_LEVEL.newcount
  is '������';
comment on column FACT_100131_GENERAL_LEVEL.conncount
  is '������';
comment on column FACT_100131_GENERAL_LEVEL.paycount
  is '������';
comment on column FACT_100131_GENERAL_LEVEL.payamount
  is '���ѽ��';
comment on column FACT_100131_GENERAL_LEVEL.data_source
  is '������Դ';
create index IDX40_100131 on FACT_100131_GENERAL_LEVEL (CHANNELID);
create index IDX41_100131 on FACT_100131_GENERAL_LEVEL (SERVERID);
create index IDX42_100131 on FACT_100131_GENERAL_LEVEL (STATDATE);

prompt
prompt Creating table FACT_100131_GENERAL_MONTH
prompt ========================================
prompt
create table FACT_100131_GENERAL_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_GENERAL_MONTH
  is '�»���������';
comment on column FACT_100131_GENERAL_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100131_GENERAL_MONTH.channelid
  is '����';
comment on column FACT_100131_GENERAL_MONTH.serverid
  is '����';
comment on column FACT_100131_GENERAL_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100131_GENERAL_MONTH.appid
  is '��Ʒid';
comment on column FACT_100131_GENERAL_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_GENERAL_MONTH.newcount
  is '������';
comment on column FACT_100131_GENERAL_MONTH.conncount
  is '������';
comment on column FACT_100131_GENERAL_MONTH.paycount
  is '������';
comment on column FACT_100131_GENERAL_MONTH.payamount
  is '���ѽ��';
comment on column FACT_100131_GENERAL_MONTH.data_source
  is '������Դ';
create index IDX43_100131 on FACT_100131_GENERAL_MONTH (CHANNELID);
create index IDX44_100131 on FACT_100131_GENERAL_MONTH (SERVERID);
create index IDX45_100131 on FACT_100131_GENERAL_MONTH (STATDATE);

prompt
prompt Creating table FACT_100131_GENERAL_MONTH_DVID
prompt =============================================
prompt
create table FACT_100131_GENERAL_MONTH_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_GENERAL_MONTH_DVID
  is '���豸����������';
comment on column FACT_100131_GENERAL_MONTH_DVID.statdate
  is 'ͳ������';
comment on column FACT_100131_GENERAL_MONTH_DVID.channelid
  is '����';
comment on column FACT_100131_GENERAL_MONTH_DVID.appid
  is '��Ʒid';
comment on column FACT_100131_GENERAL_MONTH_DVID.newcount
  is '������';
comment on column FACT_100131_GENERAL_MONTH_DVID.conncount
  is '������';
comment on column FACT_100131_GENERAL_MONTH_DVID.data_source
  is '������Դ';
create index IDX46_100131 on FACT_100131_GENERAL_MONTH_DVID (CHANNELID);
create index IDX48_100131 on FACT_100131_GENERAL_MONTH_DVID (STATDATE);

prompt
prompt Creating table FACT_100131_GENERAL_WEEK
prompt =======================================
prompt
create table FACT_100131_GENERAL_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_GENERAL_WEEK
  is '�ܻ���������';
comment on column FACT_100131_GENERAL_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100131_GENERAL_WEEK.channelid
  is '����';
comment on column FACT_100131_GENERAL_WEEK.serverid
  is '����';
comment on column FACT_100131_GENERAL_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100131_GENERAL_WEEK.appid
  is '��Ʒid';
comment on column FACT_100131_GENERAL_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_GENERAL_WEEK.newcount
  is '������';
comment on column FACT_100131_GENERAL_WEEK.conncount
  is '������';
comment on column FACT_100131_GENERAL_WEEK.paycount
  is '������';
comment on column FACT_100131_GENERAL_WEEK.payamount
  is '���ѽ��';
comment on column FACT_100131_GENERAL_WEEK.data_source
  is '������Դ';
create index IDX52_100131 on FACT_100131_GENERAL_WEEK (CHANNELID);
create index IDX53_100131 on FACT_100131_GENERAL_WEEK (SERVERID);
create index IDX54_100131 on FACT_100131_GENERAL_WEEK (STATDATE);

prompt
prompt Creating table FACT_100131_GENERAL_WEEK_DVID
prompt ============================================
prompt
create table FACT_100131_GENERAL_WEEK_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_GENERAL_WEEK_DVID
  is '���豸����������';
comment on column FACT_100131_GENERAL_WEEK_DVID.statdate
  is 'ͳ������';
comment on column FACT_100131_GENERAL_WEEK_DVID.channelid
  is '����';
comment on column FACT_100131_GENERAL_WEEK_DVID.appid
  is '��Ʒid';
comment on column FACT_100131_GENERAL_WEEK_DVID.newcount
  is '������';
comment on column FACT_100131_GENERAL_WEEK_DVID.conncount
  is '������';
comment on column FACT_100131_GENERAL_WEEK_DVID.data_source
  is '������Դ';
create index IDX49_100131 on FACT_100131_GENERAL_WEEK_DVID (CHANNELID);
create index IDX51_100131 on FACT_100131_GENERAL_WEEK_DVID (STATDATE);

prompt
prompt Creating table FACT_100131_HOUR_REPORT
prompt ======================================
prompt
create table FACT_100131_HOUR_REPORT
(
  statdate    VARCHAR2(20),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_HOUR_REPORT
  is '�ձ�Сʱ����';
comment on column FACT_100131_HOUR_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100131_HOUR_REPORT.appid
  is '��ƷID';
comment on column FACT_100131_HOUR_REPORT.channelid
  is '����';
comment on column FACT_100131_HOUR_REPORT.serverid
  is '����';
comment on column FACT_100131_HOUR_REPORT.indexid
  is 'ָ��';
comment on column FACT_100131_HOUR_REPORT.indtype
  is 'ָ������';
comment on column FACT_100131_HOUR_REPORT.rpt_data
  is '����';

prompt
prompt Creating table FACT_100131_LEVELPAY
prompt ===================================
prompt
create table FACT_100131_LEVELPAY
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  datatype       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  rolelevel      NUMBER,
  paycount       NUMBER,
  first_paycount NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100131_LEVELPAY
  is '�û���ɫ�ȼ����ѷ�����';
comment on column FACT_100131_LEVELPAY.statdate
  is 'ͳ������';
comment on column FACT_100131_LEVELPAY.channelid
  is '����';
comment on column FACT_100131_LEVELPAY.serverid
  is '����';
comment on column FACT_100131_LEVELPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100131_LEVELPAY.appid
  is '��Ʒid';
comment on column FACT_100131_LEVELPAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_LEVELPAY.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100131_LEVELPAY.paycount
  is '�����û���';
comment on column FACT_100131_LEVELPAY.first_paycount
  is '���������û������״θ����û���';
comment on column FACT_100131_LEVELPAY.data_source
  is '������Դ';
create index IDX55_100131 on FACT_100131_LEVELPAY (CHANNELID);
create index IDX56_100131 on FACT_100131_LEVELPAY (SERVERID);
create index IDX57_100131 on FACT_100131_LEVELPAY (STATDATE);

prompt
prompt Creating table FACT_100131_LOST_MAC
prompt ===================================
prompt
create table FACT_100131_LOST_MAC
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_LOST_MAC
  is '�豸��ʧ������';
comment on column FACT_100131_LOST_MAC.statdate
  is 'ͳ������';
comment on column FACT_100131_LOST_MAC.lostdate
  is '��ʧ����';
comment on column FACT_100131_LOST_MAC.channelid
  is '����ID';
comment on column FACT_100131_LOST_MAC.serverid
  is '����ID';
comment on column FACT_100131_LOST_MAC.appid
  is '��ƷID';
comment on column FACT_100131_LOST_MAC.rolelevel
  is '��ʧʱ�ȼ�';
comment on column FACT_100131_LOST_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100131_LOST_MAC.lost_conn
  is '��Ծ�豸��ʧ';
comment on column FACT_100131_LOST_MAC.lost_pay
  is '�����豸��ʧ';
comment on column FACT_100131_LOST_MAC.data_source
  is '����Դ';
create index IDX58_100131 on FACT_100131_LOST_MAC (CHANNELID);
create index IDX59_100131 on FACT_100131_LOST_MAC (SERVERID);
create index IDX60_100131 on FACT_100131_LOST_MAC (STATDATE);

prompt
prompt Creating table FACT_100131_LOST_USER
prompt ====================================
prompt
create table FACT_100131_LOST_USER
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_LOST_USER
  is '�û���ʧ������';
comment on column FACT_100131_LOST_USER.statdate
  is 'ͳ������';
comment on column FACT_100131_LOST_USER.lostdate
  is '��ʧ����';
comment on column FACT_100131_LOST_USER.channelid
  is '����ID';
comment on column FACT_100131_LOST_USER.serverid
  is '����ID';
comment on column FACT_100131_LOST_USER.appid
  is '��ƷID';
comment on column FACT_100131_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column FACT_100131_LOST_USER.lost_days
  is '��ʧ����';
comment on column FACT_100131_LOST_USER.lost_conn
  is '��Ծ�û���ʧ';
comment on column FACT_100131_LOST_USER.lost_pay
  is '�����û���ʧ';
comment on column FACT_100131_LOST_USER.data_source
  is '����Դ';
create index IDX61_100131 on FACT_100131_LOST_USER (CHANNELID);
create index IDX62_100131 on FACT_100131_LOST_USER (SERVERID);
create index IDX63_100131 on FACT_100131_LOST_USER (STATDATE);

prompt
prompt Creating table FACT_100131_LTV_MAC
prompt ==================================
prompt
create table FACT_100131_LTV_MAC
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_LTV_MAC
  is '�豸LTV������';
comment on column FACT_100131_LTV_MAC.statdate
  is 'ͳ������';
comment on column FACT_100131_LTV_MAC.ltvdate
  is '��ֵ����';
comment on column FACT_100131_LTV_MAC.channelid
  is '����';
comment on column FACT_100131_LTV_MAC.serverid
  is '����';
comment on column FACT_100131_LTV_MAC.appid
  is '��Ʒid';
comment on column FACT_100131_LTV_MAC.ltv_days
  is 'ltv��';
comment on column FACT_100131_LTV_MAC.payamount
  is '���ѽ��';
comment on column FACT_100131_LTV_MAC.data_source
  is '������Դ';
create index IDX64_100131 on FACT_100131_LTV_MAC (CHANNELID);
create index IDX65_100131 on FACT_100131_LTV_MAC (SERVERID);
create index IDX66_100131 on FACT_100131_LTV_MAC (STATDATE);

prompt
prompt Creating table FACT_100131_LTV_USER
prompt ===================================
prompt
create table FACT_100131_LTV_USER
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
nologging;
comment on table FACT_100131_LTV_USER
  is '�û�LTV������';
comment on column FACT_100131_LTV_USER.statdate
  is 'ͳ������';
comment on column FACT_100131_LTV_USER.ltvdate
  is '��ֵ����';
comment on column FACT_100131_LTV_USER.channelid
  is '����';
comment on column FACT_100131_LTV_USER.serverid
  is '����';
comment on column FACT_100131_LTV_USER.appid
  is '��Ʒid';
comment on column FACT_100131_LTV_USER.ltv_days
  is 'ltv��';
comment on column FACT_100131_LTV_USER.payamount
  is '���ѽ��';
comment on column FACT_100131_LTV_USER.data_source
  is '������Դ';
create index IDX67_100131 on FACT_100131_LTV_USER (CHANNELID);
create index IDX68_100131 on FACT_100131_LTV_USER (SERVERID);
create index IDX69_100131 on FACT_100131_LTV_USER (STATDATE);

prompt
prompt Creating table FACT_100131_MISS_FIRST
prompt =====================================
prompt
create table FACT_100131_MISS_FIRST
(
  statdate        VARCHAR2(10),
  channelid       VARCHAR2(50),
  serverid        VARCHAR2(50),
  appid           VARCHAR2(50),
  versionid       VARCHAR2(50),
  missionid       VARCHAR2(50),
  rolelevel       NUMBER,
  rolejob         VARCHAR2(50) default '0',
  firstenter_succ NUMBER,
  firstenter_fail NUMBER,
  loaddate        DATE,
  data_source     VARCHAR2(100)
)
;
comment on table FACT_100131_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column FACT_100131_MISS_FIRST.statdate
  is 'ͳ������';
comment on column FACT_100131_MISS_FIRST.channelid
  is '����';
comment on column FACT_100131_MISS_FIRST.serverid
  is '����';
comment on column FACT_100131_MISS_FIRST.appid
  is '��ƷID';
comment on column FACT_100131_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_MISS_FIRST.missionid
  is '�ؿ�ID';
comment on column FACT_100131_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column FACT_100131_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column FACT_100131_MISS_FIRST.firstenter_succ
  is '��һ�ν���ؿ��ɹ���';
comment on column FACT_100131_MISS_FIRST.firstenter_fail
  is '��һ�ν���ؿ�ʧ����';
comment on column FACT_100131_MISS_FIRST.data_source
  is '������Դ';
create index IDX70_100131 on FACT_100131_MISS_FIRST (CHANNELID);
create index IDX71_100131 on FACT_100131_MISS_FIRST (SERVERID);
create index IDX72_100131 on FACT_100131_MISS_FIRST (STATDATE);

prompt
prompt Creating table FACT_100131_NET
prompt ==============================
prompt
create table FACT_100131_NET
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_net    VARCHAR2(50),
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_NET
  is '������ʽ������';
comment on column FACT_100131_NET.statdate
  is 'ͳ������';
comment on column FACT_100131_NET.channelid
  is '����';
comment on column FACT_100131_NET.serverid
  is '����';
comment on column FACT_100131_NET.appid
  is '��Ʒid';
comment on column FACT_100131_NET.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_NET.dvid_net
  is '������ʽ';
comment on column FACT_100131_NET.conncount
  is '������';
comment on column FACT_100131_NET.data_source
  is '������Դ';
create index IDX73_100131 on FACT_100131_NET (CHANNELID);
create index IDX74_100131 on FACT_100131_NET (SERVERID);
create index IDX75_100131 on FACT_100131_NET (STATDATE);

prompt
prompt Creating table FACT_100131_OPERATOR
prompt ===================================
prompt
create table FACT_100131_OPERATOR
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  dvid_operator VARCHAR2(50),
  conncount     NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100131_OPERATOR
  is '��Ӫ�̷�����';
comment on column FACT_100131_OPERATOR.statdate
  is 'ͳ������';
comment on column FACT_100131_OPERATOR.channelid
  is '����';
comment on column FACT_100131_OPERATOR.serverid
  is '����';
comment on column FACT_100131_OPERATOR.appid
  is '��Ʒid';
comment on column FACT_100131_OPERATOR.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_OPERATOR.dvid_operator
  is '������ʽ';
comment on column FACT_100131_OPERATOR.conncount
  is '������';
comment on column FACT_100131_OPERATOR.data_source
  is '������Դ';
create index IDX76_100131 on FACT_100131_OPERATOR (CHANNELID);
create index IDX77_100131 on FACT_100131_OPERATOR (SERVERID);
create index IDX78_100131 on FACT_100131_OPERATOR (STATDATE);

prompt
prompt Creating table FACT_100131_ORDER
prompt ================================
prompt
create table FACT_100131_ORDER
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100131_ORDER
  is '����������';
comment on column FACT_100131_ORDER.statdate
  is 'ͳ������';
comment on column FACT_100131_ORDER.channelid
  is '����';
comment on column FACT_100131_ORDER.serverid
  is '����';
comment on column FACT_100131_ORDER.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100131_ORDER.appid
  is '��Ʒid';
comment on column FACT_100131_ORDER.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_ORDER.paysucccount
  is '�ɹ�������';
comment on column FACT_100131_ORDER.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100131_ORDER.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100131_ORDER.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100131_ORDER.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100131_ORDER.payfailnum
  is '����ʧ������';
comment on column FACT_100131_ORDER.data_source
  is '������Դ';
create index IDX79_100131 on FACT_100131_ORDER (CHANNELID);
create index IDX80_100131 on FACT_100131_ORDER (SERVERID);
create index IDX81_100131 on FACT_100131_ORDER (STATDATE);

prompt
prompt Creating table FACT_100131_ORDER_HOUR
prompt =====================================
prompt
create table FACT_100131_ORDER_HOUR
(
  statdate      VARCHAR2(20),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100131_ORDER_HOUR
  is '����Сʱ������';
comment on column FACT_100131_ORDER_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100131_ORDER_HOUR.channelid
  is '����';
comment on column FACT_100131_ORDER_HOUR.serverid
  is '����';
comment on column FACT_100131_ORDER_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100131_ORDER_HOUR.appid
  is '��Ʒid';
comment on column FACT_100131_ORDER_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_ORDER_HOUR.paysucccount
  is '�ɹ�������';
comment on column FACT_100131_ORDER_HOUR.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100131_ORDER_HOUR.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100131_ORDER_HOUR.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100131_ORDER_HOUR.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100131_ORDER_HOUR.payfailnum
  is '����ʧ������';
comment on column FACT_100131_ORDER_HOUR.data_source
  is '������Դ';
create index IDX177_100131 on FACT_100131_ORDER_HOUR (CHANNELID);
create index IDX178_100131 on FACT_100131_ORDER_HOUR (SERVERID);
create index IDX179_100131 on FACT_100131_ORDER_HOUR (STATDATE);

prompt
prompt Creating table FACT_100131_ORDER_MONTH
prompt ======================================
prompt
create table FACT_100131_ORDER_MONTH
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100131_ORDER_MONTH
  is '�¶���������';
comment on column FACT_100131_ORDER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100131_ORDER_MONTH.channelid
  is '����';
comment on column FACT_100131_ORDER_MONTH.serverid
  is '����';
comment on column FACT_100131_ORDER_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100131_ORDER_MONTH.appid
  is '��Ʒid';
comment on column FACT_100131_ORDER_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_ORDER_MONTH.paysucccount
  is '�ɹ�������';
comment on column FACT_100131_ORDER_MONTH.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100131_ORDER_MONTH.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100131_ORDER_MONTH.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100131_ORDER_MONTH.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100131_ORDER_MONTH.payfailnum
  is '����ʧ������';
comment on column FACT_100131_ORDER_MONTH.data_source
  is '������Դ';
create index IDX191_100131 on FACT_100131_ORDER_MONTH (CHANNELID);
create index IDX192_100131 on FACT_100131_ORDER_MONTH (SERVERID);
create index IDX193_100131 on FACT_100131_ORDER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100131_ORDER_WEEK
prompt =====================================
prompt
create table FACT_100131_ORDER_WEEK
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100131_ORDER_WEEK
  is '�ܶ���������';
comment on column FACT_100131_ORDER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100131_ORDER_WEEK.channelid
  is '����';
comment on column FACT_100131_ORDER_WEEK.serverid
  is '����';
comment on column FACT_100131_ORDER_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100131_ORDER_WEEK.appid
  is '��Ʒid';
comment on column FACT_100131_ORDER_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_ORDER_WEEK.paysucccount
  is '�ɹ�������';
comment on column FACT_100131_ORDER_WEEK.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100131_ORDER_WEEK.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100131_ORDER_WEEK.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100131_ORDER_WEEK.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100131_ORDER_WEEK.payfailnum
  is '����ʧ������';
comment on column FACT_100131_ORDER_WEEK.data_source
  is '������Դ';
create index IDX188_100131 on FACT_100131_ORDER_WEEK (CHANNELID);
create index IDX189_100131 on FACT_100131_ORDER_WEEK (SERVERID);
create index IDX190_100131 on FACT_100131_ORDER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100131_PAYAMOUNT_DAY
prompt ========================================
prompt
create table FACT_100131_PAYAMOUNT_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_PAYAMOUNT_DAY
  is '�ճ�ֵ��������';
comment on column FACT_100131_PAYAMOUNT_DAY.statdate
  is 'ͳ������';
comment on column FACT_100131_PAYAMOUNT_DAY.channelid
  is '����';
comment on column FACT_100131_PAYAMOUNT_DAY.serverid
  is '����';
comment on column FACT_100131_PAYAMOUNT_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100131_PAYAMOUNT_DAY.appid
  is '��Ʒid';
comment on column FACT_100131_PAYAMOUNT_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_PAYAMOUNT_DAY.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100131_PAYAMOUNT_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100131_PAYAMOUNT_DAY.data_source
  is '������Դ';
create index IDX82_100131 on FACT_100131_PAYAMOUNT_DAY (CHANNELID);
create index IDX83_100131 on FACT_100131_PAYAMOUNT_DAY (SERVERID);
create index IDX84_100131 on FACT_100131_PAYAMOUNT_DAY (STATDATE);

prompt
prompt Creating table FACT_100131_PAYAMOUNT_MONTH
prompt ==========================================
prompt
create table FACT_100131_PAYAMOUNT_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_PAYAMOUNT_MONTH
  is '�³�ֵ��������';
comment on column FACT_100131_PAYAMOUNT_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100131_PAYAMOUNT_MONTH.channelid
  is '����';
comment on column FACT_100131_PAYAMOUNT_MONTH.serverid
  is '����';
comment on column FACT_100131_PAYAMOUNT_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100131_PAYAMOUNT_MONTH.appid
  is '��Ʒid';
comment on column FACT_100131_PAYAMOUNT_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_PAYAMOUNT_MONTH.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100131_PAYAMOUNT_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100131_PAYAMOUNT_MONTH.data_source
  is '������Դ';
create index IDX88_100131 on FACT_100131_PAYAMOUNT_MONTH (CHANNELID);
create index IDX89_100131 on FACT_100131_PAYAMOUNT_MONTH (SERVERID);
create index IDX90_100131 on FACT_100131_PAYAMOUNT_MONTH (STATDATE);

prompt
prompt Creating table FACT_100131_PAYAMOUNT_WEEK
prompt =========================================
prompt
create table FACT_100131_PAYAMOUNT_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_PAYAMOUNT_WEEK
  is '�ܳ�ֵ��������';
comment on column FACT_100131_PAYAMOUNT_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100131_PAYAMOUNT_WEEK.channelid
  is '����';
comment on column FACT_100131_PAYAMOUNT_WEEK.serverid
  is '����';
comment on column FACT_100131_PAYAMOUNT_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100131_PAYAMOUNT_WEEK.appid
  is '��Ʒid';
comment on column FACT_100131_PAYAMOUNT_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_PAYAMOUNT_WEEK.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100131_PAYAMOUNT_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100131_PAYAMOUNT_WEEK.data_source
  is '������Դ';
create index IDX85_100131 on FACT_100131_PAYAMOUNT_WEEK (CHANNELID);
create index IDX86_100131 on FACT_100131_PAYAMOUNT_WEEK (SERVERID);
create index IDX87_100131 on FACT_100131_PAYAMOUNT_WEEK (STATDATE);

prompt
prompt Creating table FACT_100131_PAYNUM_DAY
prompt =====================================
prompt
create table FACT_100131_PAYNUM_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_PAYNUM_DAY
  is '�ճ�ֵ����������';
comment on column FACT_100131_PAYNUM_DAY.statdate
  is 'ͳ������';
comment on column FACT_100131_PAYNUM_DAY.channelid
  is '����';
comment on column FACT_100131_PAYNUM_DAY.serverid
  is '����';
comment on column FACT_100131_PAYNUM_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100131_PAYNUM_DAY.appid
  is '��Ʒid';
comment on column FACT_100131_PAYNUM_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_PAYNUM_DAY.paynum
  is '��ֵ����';
comment on column FACT_100131_PAYNUM_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100131_PAYNUM_DAY.data_source
  is '������Դ';
create index IDX97_100131 on FACT_100131_PAYNUM_DAY (CHANNELID);
create index IDX98_100131 on FACT_100131_PAYNUM_DAY (SERVERID);
create index IDX99_100131 on FACT_100131_PAYNUM_DAY (STATDATE);

prompt
prompt Creating table FACT_100131_PAYNUM_MONTH
prompt =======================================
prompt
create table FACT_100131_PAYNUM_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_PAYNUM_MONTH
  is '�³�ֵ����������';
comment on column FACT_100131_PAYNUM_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100131_PAYNUM_MONTH.channelid
  is '����';
comment on column FACT_100131_PAYNUM_MONTH.serverid
  is '����';
comment on column FACT_100131_PAYNUM_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100131_PAYNUM_MONTH.appid
  is '��Ʒid';
comment on column FACT_100131_PAYNUM_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_PAYNUM_MONTH.paynum
  is '��ֵ����';
comment on column FACT_100131_PAYNUM_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100131_PAYNUM_MONTH.data_source
  is '������Դ';
create index IDX91_100131 on FACT_100131_PAYNUM_MONTH (CHANNELID);
create index IDX92_100131 on FACT_100131_PAYNUM_MONTH (SERVERID);
create index IDX93_100131 on FACT_100131_PAYNUM_MONTH (STATDATE);

prompt
prompt Creating table FACT_100131_PAYNUM_WEEK
prompt ======================================
prompt
create table FACT_100131_PAYNUM_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_PAYNUM_WEEK
  is '�ܳ�ֵ����������';
comment on column FACT_100131_PAYNUM_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100131_PAYNUM_WEEK.channelid
  is '����';
comment on column FACT_100131_PAYNUM_WEEK.serverid
  is '����';
comment on column FACT_100131_PAYNUM_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100131_PAYNUM_WEEK.appid
  is '��Ʒid';
comment on column FACT_100131_PAYNUM_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_PAYNUM_WEEK.paynum
  is '��ֵ����';
comment on column FACT_100131_PAYNUM_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100131_PAYNUM_WEEK.data_source
  is '������Դ';
create index IDX94_100131 on FACT_100131_PAYNUM_WEEK (CHANNELID);
create index IDX95_100131 on FACT_100131_PAYNUM_WEEK (SERVERID);
create index IDX96_100131 on FACT_100131_PAYNUM_WEEK (STATDATE);

prompt
prompt Creating table FACT_100131_PAYTYPE
prompt ==================================
prompt
create table FACT_100131_PAYTYPE
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paytypeid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_PAYTYPE
  is '��ֵ���ͷ�����';
comment on column FACT_100131_PAYTYPE.statdate
  is 'ͳ������';
comment on column FACT_100131_PAYTYPE.channelid
  is '����';
comment on column FACT_100131_PAYTYPE.serverid
  is '����';
comment on column FACT_100131_PAYTYPE.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100131_PAYTYPE.appid
  is '��Ʒid';
comment on column FACT_100131_PAYTYPE.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_PAYTYPE.paytypeid
  is '��ֵ����';
comment on column FACT_100131_PAYTYPE.payamount
  is '��ֵ���';
comment on column FACT_100131_PAYTYPE.paycount
  is '��ֵ����';
comment on column FACT_100131_PAYTYPE.paynum
  is '��ֵ����';
comment on column FACT_100131_PAYTYPE.data_source
  is '������Դ';
create index IDX100_100131 on FACT_100131_PAYTYPE (CHANNELID);
create index IDX101_100131 on FACT_100131_PAYTYPE (SERVERID);
create index IDX102_100131 on FACT_100131_PAYTYPE (STATDATE);

prompt
prompt Creating table FACT_100131_PAYWAY
prompt =================================
prompt
create table FACT_100131_PAYWAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paywayid    VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_PAYWAY
  is '��ֵ��ʽ������';
comment on column FACT_100131_PAYWAY.statdate
  is 'ͳ������';
comment on column FACT_100131_PAYWAY.channelid
  is '����';
comment on column FACT_100131_PAYWAY.serverid
  is '����';
comment on column FACT_100131_PAYWAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100131_PAYWAY.appid
  is '��Ʒid';
comment on column FACT_100131_PAYWAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_PAYWAY.paywayid
  is '��ֵ��ʽ';
comment on column FACT_100131_PAYWAY.payamount
  is '��ֵ���';
comment on column FACT_100131_PAYWAY.paycount
  is '��ֵ����';
comment on column FACT_100131_PAYWAY.paynum
  is '��ֵ����';
comment on column FACT_100131_PAYWAY.data_source
  is '������Դ';
create index IDX103_100131 on FACT_100131_PAYWAY (CHANNELID);
create index IDX104_100131 on FACT_100131_PAYWAY (SERVERID);
create index IDX105_100131 on FACT_100131_PAYWAY (STATDATE);

prompt
prompt Creating table FACT_100131_REGION
prompt =================================
prompt
create table FACT_100131_REGION
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  country     VARCHAR2(50),
  province    VARCHAR2(50),
  city        VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_REGION
  is '���������';
comment on column FACT_100131_REGION.statdate
  is 'ͳ������';
comment on column FACT_100131_REGION.channelid
  is '����';
comment on column FACT_100131_REGION.serverid
  is '����';
comment on column FACT_100131_REGION.appid
  is '��Ʒid';
comment on column FACT_100131_REGION.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_REGION.country
  is '����';
comment on column FACT_100131_REGION.province
  is 'ʡ';
comment on column FACT_100131_REGION.city
  is '��';
comment on column FACT_100131_REGION.newcount
  is '������';
comment on column FACT_100131_REGION.conncount
  is '������';
comment on column FACT_100131_REGION.paycount
  is '������';
comment on column FACT_100131_REGION.payamount
  is '���ѽ��';
comment on column FACT_100131_REGION.data_source
  is '������Դ';
create index IDX106_100131 on FACT_100131_REGION (CHANNELID);
create index IDX107_100131 on FACT_100131_REGION (SERVERID);
create index IDX108_100131 on FACT_100131_REGION (STATDATE);

prompt
prompt Creating table FACT_100131_REMAIN_MAC
prompt =====================================
prompt
create table FACT_100131_REMAIN_MAC
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_REMAIN_MAC
  is '�豸�����';
comment on column FACT_100131_REMAIN_MAC.statdate
  is 'ͳ������';
comment on column FACT_100131_REMAIN_MAC.conndate
  is '��������';
comment on column FACT_100131_REMAIN_MAC.channelid
  is '����ID';
comment on column FACT_100131_REMAIN_MAC.serverid
  is '����ID';
comment on column FACT_100131_REMAIN_MAC.appid
  is '��ƷID';
comment on column FACT_100131_REMAIN_MAC.remain_days
  is '��������';
comment on column FACT_100131_REMAIN_MAC.new_remain
  is '��������';
comment on column FACT_100131_REMAIN_MAC.conn_remain
  is '��������';
comment on column FACT_100131_REMAIN_MAC.pay_remain
  is '��������';
comment on column FACT_100131_REMAIN_MAC.data_source
  is '����Դ';
create index IDX109_100131 on FACT_100131_REMAIN_MAC (CHANNELID);
create index IDX110_100131 on FACT_100131_REMAIN_MAC (SERVERID);
create index IDX111_100131 on FACT_100131_REMAIN_MAC (STATDATE);

prompt
prompt Creating table FACT_100131_REMAIN_USER
prompt ======================================
prompt
create table FACT_100131_REMAIN_USER
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_REMAIN_USER
  is '�û������';
comment on column FACT_100131_REMAIN_USER.statdate
  is 'ͳ������';
comment on column FACT_100131_REMAIN_USER.conndate
  is '��������';
comment on column FACT_100131_REMAIN_USER.channelid
  is '����ID';
comment on column FACT_100131_REMAIN_USER.serverid
  is '����ID';
comment on column FACT_100131_REMAIN_USER.appid
  is '��ƷID';
comment on column FACT_100131_REMAIN_USER.remain_days
  is '��������';
comment on column FACT_100131_REMAIN_USER.new_remain
  is '��������';
comment on column FACT_100131_REMAIN_USER.conn_remain
  is '��������';
comment on column FACT_100131_REMAIN_USER.pay_remain
  is '��������';
comment on column FACT_100131_REMAIN_USER.data_source
  is '����Դ';
create index IDX112_100131 on FACT_100131_REMAIN_USER (CHANNELID);
create index IDX113_100131 on FACT_100131_REMAIN_USER (SERVERID);
create index IDX114_100131 on FACT_100131_REMAIN_USER (STATDATE);

prompt
prompt Creating table FACT_100131_VC
prompt =============================
prompt
create table FACT_100131_VC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcamount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100131_VC
  is '������ҷ�����';
comment on column FACT_100131_VC.statdate
  is 'ͳ������';
comment on column FACT_100131_VC.channelid
  is '����';
comment on column FACT_100131_VC.serverid
  is '����';
comment on column FACT_100131_VC.appid
  is '��Ʒid';
comment on column FACT_100131_VC.versionid
  is '��Ʒ�汾';
comment on column FACT_100131_VC.vctype
  is '�����������';
comment on column FACT_100131_VC.vcusetype
  is '�������ʹ������';
comment on column FACT_100131_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column FACT_100131_VC.vcamount
  is '������ҽ��';
comment on column FACT_100131_VC.data_source
  is '������Դ';
create index IDX115_100131 on FACT_100131_VC (CHANNELID);
create index IDX116_100131 on FACT_100131_VC (SERVERID);
create index IDX117_100131 on FACT_100131_VC (STATDATE);

prompt
prompt Creating table FACT_100132_BACK_MAC
prompt ===================================
prompt
create table FACT_100132_BACK_MAC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_BACK_MAC
  is '�豸����������';
comment on column FACT_100132_BACK_MAC.statdate
  is 'ͳ������';
comment on column FACT_100132_BACK_MAC.channelid
  is '����ID';
comment on column FACT_100132_BACK_MAC.serverid
  is '����ID';
comment on column FACT_100132_BACK_MAC.appid
  is '��ƷID';
comment on column FACT_100132_BACK_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100132_BACK_MAC.back_conn
  is '��Ծ�豸������';
comment on column FACT_100132_BACK_MAC.back_pay
  is '�����豸������';
comment on column FACT_100132_BACK_MAC.data_source
  is '����Դ';
create index IDX1_100132 on FACT_100132_BACK_MAC (CHANNELID);
create index IDX2_100132 on FACT_100132_BACK_MAC (SERVERID);
create index IDX3_100132 on FACT_100132_BACK_MAC (STATDATE);

prompt
prompt Creating table FACT_100132_BACK_MAC_MONTH
prompt =========================================
prompt
create table FACT_100132_BACK_MAC_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_BACK_MAC_MONTH
  is '�豸����������';
comment on column FACT_100132_BACK_MAC_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100132_BACK_MAC_MONTH.channelid
  is '����ID';
comment on column FACT_100132_BACK_MAC_MONTH.serverid
  is '����ID';
comment on column FACT_100132_BACK_MAC_MONTH.appid
  is '��ƷID';
comment on column FACT_100132_BACK_MAC_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100132_BACK_MAC_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100132_BACK_MAC_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100132_BACK_MAC_MONTH.data_source
  is '����Դ';
create index IDX4_100132 on FACT_100132_BACK_MAC_MONTH (CHANNELID);
create index IDX5_100132 on FACT_100132_BACK_MAC_MONTH (SERVERID);
create index IDX6_100132 on FACT_100132_BACK_MAC_MONTH (STATDATE);

prompt
prompt Creating table FACT_100132_BACK_MAC_WEEK
prompt ========================================
prompt
create table FACT_100132_BACK_MAC_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_BACK_MAC_WEEK
  is '�豸����������';
comment on column FACT_100132_BACK_MAC_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100132_BACK_MAC_WEEK.channelid
  is '����ID';
comment on column FACT_100132_BACK_MAC_WEEK.serverid
  is '����ID';
comment on column FACT_100132_BACK_MAC_WEEK.appid
  is '��ƷID';
comment on column FACT_100132_BACK_MAC_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100132_BACK_MAC_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100132_BACK_MAC_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100132_BACK_MAC_WEEK.data_source
  is '����Դ';
create index IDX7_100132 on FACT_100132_BACK_MAC_WEEK (CHANNELID);
create index IDX8_100132 on FACT_100132_BACK_MAC_WEEK (SERVERID);
create index IDX9_100132 on FACT_100132_BACK_MAC_WEEK (STATDATE);

prompt
prompt Creating table FACT_100132_BACK_USER
prompt ====================================
prompt
create table FACT_100132_BACK_USER
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_BACK_USER
  is '�û�����������';
comment on column FACT_100132_BACK_USER.statdate
  is 'ͳ������';
comment on column FACT_100132_BACK_USER.channelid
  is '����ID';
comment on column FACT_100132_BACK_USER.serverid
  is '����ID';
comment on column FACT_100132_BACK_USER.appid
  is '��ƷID';
comment on column FACT_100132_BACK_USER.lost_days
  is '��ʧ����';
comment on column FACT_100132_BACK_USER.back_conn
  is '��Ծ�û�������';
comment on column FACT_100132_BACK_USER.back_pay
  is '�����û�������';
comment on column FACT_100132_BACK_USER.data_source
  is '����Դ';
create index IDX16_100132 on FACT_100132_BACK_USER (CHANNELID);
create index IDX17_100132 on FACT_100132_BACK_USER (SERVERID);
create index IDX18_100132 on FACT_100132_BACK_USER (STATDATE);

prompt
prompt Creating table FACT_100132_BACK_USER_MONTH
prompt ==========================================
prompt
create table FACT_100132_BACK_USER_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_BACK_USER_MONTH
  is '�豸����������';
comment on column FACT_100132_BACK_USER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100132_BACK_USER_MONTH.channelid
  is '����ID';
comment on column FACT_100132_BACK_USER_MONTH.serverid
  is '����ID';
comment on column FACT_100132_BACK_USER_MONTH.appid
  is '��ƷID';
comment on column FACT_100132_BACK_USER_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100132_BACK_USER_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100132_BACK_USER_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100132_BACK_USER_MONTH.data_source
  is '����Դ';
create index IDX13_100132 on FACT_100132_BACK_USER_MONTH (CHANNELID);
create index IDX14_100132 on FACT_100132_BACK_USER_MONTH (SERVERID);
create index IDX15_100132 on FACT_100132_BACK_USER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100132_BACK_USER_WEEK
prompt =========================================
prompt
create table FACT_100132_BACK_USER_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_BACK_USER_WEEK
  is '�豸����������';
comment on column FACT_100132_BACK_USER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100132_BACK_USER_WEEK.channelid
  is '����ID';
comment on column FACT_100132_BACK_USER_WEEK.serverid
  is '����ID';
comment on column FACT_100132_BACK_USER_WEEK.appid
  is '��ƷID';
comment on column FACT_100132_BACK_USER_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100132_BACK_USER_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100132_BACK_USER_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100132_BACK_USER_WEEK.data_source
  is '����Դ';
create index IDX10_100132 on FACT_100132_BACK_USER_WEEK (CHANNELID);
create index IDX11_100132 on FACT_100132_BACK_USER_WEEK (SERVERID);
create index IDX12_100132 on FACT_100132_BACK_USER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100132_CEVENT
prompt =================================
prompt
create table FACT_100132_CEVENT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  eventkey    VARCHAR2(50),
  eventcount  NUMBER,
  eventnum    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_CEVENT
  is '�Զ��������';
comment on column FACT_100132_CEVENT.statdate
  is 'ͳ������';
comment on column FACT_100132_CEVENT.channelid
  is '����';
comment on column FACT_100132_CEVENT.serverid
  is '����';
comment on column FACT_100132_CEVENT.appid
  is '��Ʒid';
comment on column FACT_100132_CEVENT.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100132_CEVENT.eventcount
  is '�¼��û���';
comment on column FACT_100132_CEVENT.eventnum
  is '�¼�����';
comment on column FACT_100132_CEVENT.data_source
  is '������Դ';
create index IDX181_100132 on FACT_100132_CEVENT (CHANNELID);
create index IDX182_100132 on FACT_100132_CEVENT (SERVERID);
create index IDX183_100132 on FACT_100132_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100132_CEVENT_PAR
prompt =====================================
prompt
create table FACT_100132_CEVENT_PAR
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  ilevel         NUMBER,
  eventkey       VARCHAR2(100),
  eventpar_key   VARCHAR2(100),
  eventpar_value VARCHAR2(100),
  eventcount     NUMBER,
  eventnum       NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100132_CEVENT_PAR
  is '�Զ������������';
comment on column FACT_100132_CEVENT_PAR.statdate
  is 'ͳ������';
comment on column FACT_100132_CEVENT_PAR.channelid
  is '����';
comment on column FACT_100132_CEVENT_PAR.serverid
  is '����';
comment on column FACT_100132_CEVENT_PAR.appid
  is '��Ʒid';
comment on column FACT_100132_CEVENT_PAR.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_CEVENT_PAR.ilevel
  is '��ɫ�ȼ�';
comment on column FACT_100132_CEVENT_PAR.eventkey
  is '�¼�����';
comment on column FACT_100132_CEVENT_PAR.eventpar_key
  is '�¼�����';
comment on column FACT_100132_CEVENT_PAR.eventpar_value
  is '�¼�����ֵ';
comment on column FACT_100132_CEVENT_PAR.eventcount
  is '�¼��û���';
comment on column FACT_100132_CEVENT_PAR.eventnum
  is '�¼�����';
comment on column FACT_100132_CEVENT_PAR.data_source
  is '������Դ';
create index IDX185_100132 on FACT_100132_CEVENT_PAR (CHANNELID);
create index IDX186_100132 on FACT_100132_CEVENT_PAR (SERVERID);
create index IDX187_100132 on FACT_100132_CEVENT_PAR (STATDATE);

prompt
prompt Creating table FACT_100132_COMP_CEVENT
prompt ======================================
prompt
create table FACT_100132_COMP_CEVENT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(10),
  channelid   VARCHAR2(50),
  gameversion VARCHAR2(50),
  serverid    VARCHAR2(50),
  ilevel      NUMBER,
  eventkey    VARCHAR2(100),
  compid      VARCHAR2(50),
  caltype     VARCHAR2(50),
  dimpars     VARCHAR2(2000),
  comp_data   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_COMP_CEVENT
  is '�Զ����¼���Ϸ�����';
comment on column FACT_100132_COMP_CEVENT.statdate
  is '����';
comment on column FACT_100132_COMP_CEVENT.appid
  is '��Ϸ�� appid';
comment on column FACT_100132_COMP_CEVENT.channelid
  is '���� ID';
comment on column FACT_100132_COMP_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column FACT_100132_COMP_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column FACT_100132_COMP_CEVENT.ilevel
  is '��ҵȼ�';
comment on column FACT_100132_COMP_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100132_COMP_CEVENT.compid
  is '��ϼ����¼�ID';
comment on column FACT_100132_COMP_CEVENT.caltype
  is '��ϼ����¼���������';
comment on column FACT_100132_COMP_CEVENT.dimpars
  is '��ϲ���';
comment on column FACT_100132_COMP_CEVENT.comp_data
  is '��ϼ�����';
create index IDX184_100132 on FACT_100132_COMP_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100132_DAILY_REPORT
prompt =======================================
prompt
create table FACT_100132_DAILY_REPORT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_DAILY_REPORT
  is '�ձ�����';
comment on column FACT_100132_DAILY_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100132_DAILY_REPORT.appid
  is '��ƷID';
comment on column FACT_100132_DAILY_REPORT.channelid
  is '����';
comment on column FACT_100132_DAILY_REPORT.serverid
  is '����';
comment on column FACT_100132_DAILY_REPORT.indexid
  is 'ָ��';
comment on column FACT_100132_DAILY_REPORT.indtype
  is 'ָ������';
comment on column FACT_100132_DAILY_REPORT.rpt_data
  is '����';
create index IDX176_100132 on FACT_100132_DAILY_REPORT (STATDATE);

prompt
prompt Creating table FACT_100132_DVID
prompt ===============================
prompt
create table FACT_100132_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_model  VARCHAR2(200),
  dvid_res    VARCHAR2(50),
  dvid_os     VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_DVID
  is '�豸������';
comment on column FACT_100132_DVID.statdate
  is 'ͳ������';
comment on column FACT_100132_DVID.channelid
  is '����';
comment on column FACT_100132_DVID.serverid
  is '����';
comment on column FACT_100132_DVID.appid
  is '��Ʒid';
comment on column FACT_100132_DVID.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_DVID.dvid_model
  is '����';
comment on column FACT_100132_DVID.dvid_res
  is '�豸�ֱ���';
comment on column FACT_100132_DVID.dvid_os
  is '�豸����ϵͳ';
comment on column FACT_100132_DVID.newcount
  is '�����û���';
comment on column FACT_100132_DVID.conncount
  is '�����û���';
comment on column FACT_100132_DVID.data_source
  is '������Դ';
create index IDX19_100132 on FACT_100132_DVID (CHANNELID);
create index IDX20_100132 on FACT_100132_DVID (SERVERID);
create index IDX21_100132 on FACT_100132_DVID (STATDATE);

prompt
prompt Creating table FACT_100132_FIRSTPAY
prompt ===================================
prompt
create table FACT_100132_FIRSTPAY
(
  statdate         VARCHAR2(10),
  firstpaydate     VARCHAR2(10),
  channelid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  datatype         VARCHAR2(50),
  appid            VARCHAR2(50),
  first_payfromreg NUMBER,
  first_paycount   NUMBER,
  payamount        NUMBER,
  loaddate         DATE default SYSDATE,
  data_source      VARCHAR2(100)
)
;
comment on table FACT_100132_FIRSTPAY
  is '�����û��״γ�ֵ������';
comment on column FACT_100132_FIRSTPAY.statdate
  is 'ͳ������';
comment on column FACT_100132_FIRSTPAY.firstpaydate
  is '�״θ�������';
comment on column FACT_100132_FIRSTPAY.channelid
  is '����';
comment on column FACT_100132_FIRSTPAY.serverid
  is '����';
comment on column FACT_100132_FIRSTPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100132_FIRSTPAY.appid
  is '��Ʒid';
comment on column FACT_100132_FIRSTPAY.first_payfromreg
  is 'ע���ڼ��쿪ʼ��ֵ(1��2��..7..30..)';
comment on column FACT_100132_FIRSTPAY.first_paycount
  is '���������û���';
comment on column FACT_100132_FIRSTPAY.payamount
  is '�ۼƵ��ڼ���ĳ�ֵ�ܶ�';
comment on column FACT_100132_FIRSTPAY.data_source
  is '������Դ';
create index IDX22_100132 on FACT_100132_FIRSTPAY (CHANNELID);
create index IDX23_100132 on FACT_100132_FIRSTPAY (SERVERID);
create index IDX24_100132 on FACT_100132_FIRSTPAY (STATDATE);

prompt
prompt Creating table FACT_100132_FIRSTPAY_AMOUNT
prompt ==========================================
prompt
create table FACT_100132_FIRSTPAY_AMOUNT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_FIRSTPAY_AMOUNT
  is '�״θ��ѽ�������';
comment on column FACT_100132_FIRSTPAY_AMOUNT.statdate
  is 'ͳ������';
comment on column FACT_100132_FIRSTPAY_AMOUNT.channelid
  is '����';
comment on column FACT_100132_FIRSTPAY_AMOUNT.serverid
  is '��������';
comment on column FACT_100132_FIRSTPAY_AMOUNT.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100132_FIRSTPAY_AMOUNT.appid
  is '��Ʒid';
comment on column FACT_100132_FIRSTPAY_AMOUNT.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_FIRSTPAY_AMOUNT.payamount
  is '�״θ��ѽ��';
comment on column FACT_100132_FIRSTPAY_AMOUNT.paycount
  is '�״θ��ѽ���Ӧ������';
create index IDX25_100132 on FACT_100132_FIRSTPAY_AMOUNT (CHANNELID);
create index IDX26_100132 on FACT_100132_FIRSTPAY_AMOUNT (SERVERID);
create index IDX27_100132 on FACT_100132_FIRSTPAY_AMOUNT (STATDATE);

prompt
prompt Creating table FACT_100132_GENERAL_DAY
prompt ======================================
prompt
create table FACT_100132_GENERAL_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_GENERAL_DAY
  is '�ջ���������';
comment on column FACT_100132_GENERAL_DAY.statdate
  is 'ͳ������';
comment on column FACT_100132_GENERAL_DAY.channelid
  is '����';
comment on column FACT_100132_GENERAL_DAY.serverid
  is '����';
comment on column FACT_100132_GENERAL_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100132_GENERAL_DAY.appid
  is '��Ʒid';
comment on column FACT_100132_GENERAL_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_GENERAL_DAY.newcount
  is '������';
comment on column FACT_100132_GENERAL_DAY.conncount
  is '������';
comment on column FACT_100132_GENERAL_DAY.paycount
  is '������';
comment on column FACT_100132_GENERAL_DAY.payamount
  is '���ѽ��';
comment on column FACT_100132_GENERAL_DAY.data_source
  is '������Դ';
create index IDX28_100132 on FACT_100132_GENERAL_DAY (CHANNELID);
create index IDX29_100132 on FACT_100132_GENERAL_DAY (SERVERID);
create index IDX30_100132 on FACT_100132_GENERAL_DAY (STATDATE);

prompt
prompt Creating table FACT_100132_GENERAL_DAY_DVID
prompt ===========================================
prompt
create table FACT_100132_GENERAL_DAY_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_GENERAL_DAY_DVID
  is '���豸����������';
comment on column FACT_100132_GENERAL_DAY_DVID.statdate
  is 'ͳ������';
comment on column FACT_100132_GENERAL_DAY_DVID.channelid
  is '����';
comment on column FACT_100132_GENERAL_DAY_DVID.appid
  is '��Ʒid';
comment on column FACT_100132_GENERAL_DAY_DVID.newcount
  is '������';
comment on column FACT_100132_GENERAL_DAY_DVID.conncount
  is '������';
comment on column FACT_100132_GENERAL_DAY_DVID.data_source
  is '������Դ';
create index IDX31_100132 on FACT_100132_GENERAL_DAY_DVID (CHANNELID);
create index IDX33_100132 on FACT_100132_GENERAL_DAY_DVID (STATDATE);

prompt
prompt Creating table FACT_100132_GENERAL_HOUR
prompt =======================================
prompt
create table FACT_100132_GENERAL_HOUR
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_GENERAL_HOUR
  is 'Сʱ����������';
comment on column FACT_100132_GENERAL_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100132_GENERAL_HOUR.channelid
  is '����';
comment on column FACT_100132_GENERAL_HOUR.serverid
  is '����';
comment on column FACT_100132_GENERAL_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100132_GENERAL_HOUR.appid
  is '��Ʒid';
comment on column FACT_100132_GENERAL_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_GENERAL_HOUR.newcount
  is '������';
comment on column FACT_100132_GENERAL_HOUR.conncount
  is '������';
comment on column FACT_100132_GENERAL_HOUR.paycount
  is '������';
comment on column FACT_100132_GENERAL_HOUR.payamount
  is '���ѽ��';
comment on column FACT_100132_GENERAL_HOUR.data_source
  is '������Դ';
create index IDX34_100132 on FACT_100132_GENERAL_HOUR (CHANNELID);
create index IDX35_100132 on FACT_100132_GENERAL_HOUR (SERVERID);
create index IDX36_100132 on FACT_100132_GENERAL_HOUR (STATDATE);

prompt
prompt Creating table FACT_100132_GENERAL_HOUR_DVID
prompt ============================================
prompt
create table FACT_100132_GENERAL_HOUR_DVID
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_GENERAL_HOUR_DVID
  is 'Сʱ�豸����������';
comment on column FACT_100132_GENERAL_HOUR_DVID.statdate
  is 'ͳ������';
comment on column FACT_100132_GENERAL_HOUR_DVID.channelid
  is '����';
comment on column FACT_100132_GENERAL_HOUR_DVID.appid
  is '��Ʒid';
comment on column FACT_100132_GENERAL_HOUR_DVID.newcount
  is '������';
comment on column FACT_100132_GENERAL_HOUR_DVID.conncount
  is '������';
comment on column FACT_100132_GENERAL_HOUR_DVID.data_source
  is '������Դ';
create index IDX37_100132 on FACT_100132_GENERAL_HOUR_DVID (CHANNELID);
create index IDX39_100132 on FACT_100132_GENERAL_HOUR_DVID (STATDATE);

prompt
prompt Creating table FACT_100132_GENERAL_LEVEL
prompt ========================================
prompt
create table FACT_100132_GENERAL_LEVEL
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  rolelevel   NUMBER,
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_GENERAL_LEVEL
  is '�û��ȼ�������';
comment on column FACT_100132_GENERAL_LEVEL.statdate
  is 'ͳ������';
comment on column FACT_100132_GENERAL_LEVEL.channelid
  is '����';
comment on column FACT_100132_GENERAL_LEVEL.serverid
  is '����';
comment on column FACT_100132_GENERAL_LEVEL.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100132_GENERAL_LEVEL.appid
  is '��Ʒid';
comment on column FACT_100132_GENERAL_LEVEL.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_GENERAL_LEVEL.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100132_GENERAL_LEVEL.newcount
  is '������';
comment on column FACT_100132_GENERAL_LEVEL.conncount
  is '������';
comment on column FACT_100132_GENERAL_LEVEL.paycount
  is '������';
comment on column FACT_100132_GENERAL_LEVEL.payamount
  is '���ѽ��';
comment on column FACT_100132_GENERAL_LEVEL.data_source
  is '������Դ';
create index IDX40_100132 on FACT_100132_GENERAL_LEVEL (CHANNELID);
create index IDX41_100132 on FACT_100132_GENERAL_LEVEL (SERVERID);
create index IDX42_100132 on FACT_100132_GENERAL_LEVEL (STATDATE);

prompt
prompt Creating table FACT_100132_GENERAL_MONTH
prompt ========================================
prompt
create table FACT_100132_GENERAL_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_GENERAL_MONTH
  is '�»���������';
comment on column FACT_100132_GENERAL_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100132_GENERAL_MONTH.channelid
  is '����';
comment on column FACT_100132_GENERAL_MONTH.serverid
  is '����';
comment on column FACT_100132_GENERAL_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100132_GENERAL_MONTH.appid
  is '��Ʒid';
comment on column FACT_100132_GENERAL_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_GENERAL_MONTH.newcount
  is '������';
comment on column FACT_100132_GENERAL_MONTH.conncount
  is '������';
comment on column FACT_100132_GENERAL_MONTH.paycount
  is '������';
comment on column FACT_100132_GENERAL_MONTH.payamount
  is '���ѽ��';
comment on column FACT_100132_GENERAL_MONTH.data_source
  is '������Դ';
create index IDX43_100132 on FACT_100132_GENERAL_MONTH (CHANNELID);
create index IDX44_100132 on FACT_100132_GENERAL_MONTH (SERVERID);
create index IDX45_100132 on FACT_100132_GENERAL_MONTH (STATDATE);

prompt
prompt Creating table FACT_100132_GENERAL_MONTH_DVID
prompt =============================================
prompt
create table FACT_100132_GENERAL_MONTH_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_GENERAL_MONTH_DVID
  is '���豸����������';
comment on column FACT_100132_GENERAL_MONTH_DVID.statdate
  is 'ͳ������';
comment on column FACT_100132_GENERAL_MONTH_DVID.channelid
  is '����';
comment on column FACT_100132_GENERAL_MONTH_DVID.appid
  is '��Ʒid';
comment on column FACT_100132_GENERAL_MONTH_DVID.newcount
  is '������';
comment on column FACT_100132_GENERAL_MONTH_DVID.conncount
  is '������';
comment on column FACT_100132_GENERAL_MONTH_DVID.data_source
  is '������Դ';
create index IDX46_100132 on FACT_100132_GENERAL_MONTH_DVID (CHANNELID);
create index IDX48_100132 on FACT_100132_GENERAL_MONTH_DVID (STATDATE);

prompt
prompt Creating table FACT_100132_GENERAL_WEEK
prompt =======================================
prompt
create table FACT_100132_GENERAL_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_GENERAL_WEEK
  is '�ܻ���������';
comment on column FACT_100132_GENERAL_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100132_GENERAL_WEEK.channelid
  is '����';
comment on column FACT_100132_GENERAL_WEEK.serverid
  is '����';
comment on column FACT_100132_GENERAL_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100132_GENERAL_WEEK.appid
  is '��Ʒid';
comment on column FACT_100132_GENERAL_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_GENERAL_WEEK.newcount
  is '������';
comment on column FACT_100132_GENERAL_WEEK.conncount
  is '������';
comment on column FACT_100132_GENERAL_WEEK.paycount
  is '������';
comment on column FACT_100132_GENERAL_WEEK.payamount
  is '���ѽ��';
comment on column FACT_100132_GENERAL_WEEK.data_source
  is '������Դ';
create index IDX52_100132 on FACT_100132_GENERAL_WEEK (CHANNELID);
create index IDX53_100132 on FACT_100132_GENERAL_WEEK (SERVERID);
create index IDX54_100132 on FACT_100132_GENERAL_WEEK (STATDATE);

prompt
prompt Creating table FACT_100132_GENERAL_WEEK_DVID
prompt ============================================
prompt
create table FACT_100132_GENERAL_WEEK_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_GENERAL_WEEK_DVID
  is '���豸����������';
comment on column FACT_100132_GENERAL_WEEK_DVID.statdate
  is 'ͳ������';
comment on column FACT_100132_GENERAL_WEEK_DVID.channelid
  is '����';
comment on column FACT_100132_GENERAL_WEEK_DVID.appid
  is '��Ʒid';
comment on column FACT_100132_GENERAL_WEEK_DVID.newcount
  is '������';
comment on column FACT_100132_GENERAL_WEEK_DVID.conncount
  is '������';
comment on column FACT_100132_GENERAL_WEEK_DVID.data_source
  is '������Դ';
create index IDX49_100132 on FACT_100132_GENERAL_WEEK_DVID (CHANNELID);
create index IDX51_100132 on FACT_100132_GENERAL_WEEK_DVID (STATDATE);

prompt
prompt Creating table FACT_100132_HOUR_REPORT
prompt ======================================
prompt
create table FACT_100132_HOUR_REPORT
(
  statdate    VARCHAR2(20),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_HOUR_REPORT
  is '�ձ�Сʱ����';
comment on column FACT_100132_HOUR_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100132_HOUR_REPORT.appid
  is '��ƷID';
comment on column FACT_100132_HOUR_REPORT.channelid
  is '����';
comment on column FACT_100132_HOUR_REPORT.serverid
  is '����';
comment on column FACT_100132_HOUR_REPORT.indexid
  is 'ָ��';
comment on column FACT_100132_HOUR_REPORT.indtype
  is 'ָ������';
comment on column FACT_100132_HOUR_REPORT.rpt_data
  is '����';

prompt
prompt Creating table FACT_100132_LEVELPAY
prompt ===================================
prompt
create table FACT_100132_LEVELPAY
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  datatype       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  rolelevel      NUMBER,
  paycount       NUMBER,
  first_paycount NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100132_LEVELPAY
  is '�û���ɫ�ȼ����ѷ�����';
comment on column FACT_100132_LEVELPAY.statdate
  is 'ͳ������';
comment on column FACT_100132_LEVELPAY.channelid
  is '����';
comment on column FACT_100132_LEVELPAY.serverid
  is '����';
comment on column FACT_100132_LEVELPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100132_LEVELPAY.appid
  is '��Ʒid';
comment on column FACT_100132_LEVELPAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_LEVELPAY.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100132_LEVELPAY.paycount
  is '�����û���';
comment on column FACT_100132_LEVELPAY.first_paycount
  is '���������û������״θ����û���';
comment on column FACT_100132_LEVELPAY.data_source
  is '������Դ';
create index IDX55_100132 on FACT_100132_LEVELPAY (CHANNELID);
create index IDX56_100132 on FACT_100132_LEVELPAY (SERVERID);
create index IDX57_100132 on FACT_100132_LEVELPAY (STATDATE);

prompt
prompt Creating table FACT_100132_LOST_MAC
prompt ===================================
prompt
create table FACT_100132_LOST_MAC
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_LOST_MAC
  is '�豸��ʧ������';
comment on column FACT_100132_LOST_MAC.statdate
  is 'ͳ������';
comment on column FACT_100132_LOST_MAC.lostdate
  is '��ʧ����';
comment on column FACT_100132_LOST_MAC.channelid
  is '����ID';
comment on column FACT_100132_LOST_MAC.serverid
  is '����ID';
comment on column FACT_100132_LOST_MAC.appid
  is '��ƷID';
comment on column FACT_100132_LOST_MAC.rolelevel
  is '��ʧʱ�ȼ�';
comment on column FACT_100132_LOST_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100132_LOST_MAC.lost_conn
  is '��Ծ�豸��ʧ';
comment on column FACT_100132_LOST_MAC.lost_pay
  is '�����豸��ʧ';
comment on column FACT_100132_LOST_MAC.data_source
  is '����Դ';
create index IDX58_100132 on FACT_100132_LOST_MAC (CHANNELID);
create index IDX59_100132 on FACT_100132_LOST_MAC (SERVERID);
create index IDX60_100132 on FACT_100132_LOST_MAC (STATDATE);

prompt
prompt Creating table FACT_100132_LOST_USER
prompt ====================================
prompt
create table FACT_100132_LOST_USER
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_LOST_USER
  is '�û���ʧ������';
comment on column FACT_100132_LOST_USER.statdate
  is 'ͳ������';
comment on column FACT_100132_LOST_USER.lostdate
  is '��ʧ����';
comment on column FACT_100132_LOST_USER.channelid
  is '����ID';
comment on column FACT_100132_LOST_USER.serverid
  is '����ID';
comment on column FACT_100132_LOST_USER.appid
  is '��ƷID';
comment on column FACT_100132_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column FACT_100132_LOST_USER.lost_days
  is '��ʧ����';
comment on column FACT_100132_LOST_USER.lost_conn
  is '��Ծ�û���ʧ';
comment on column FACT_100132_LOST_USER.lost_pay
  is '�����û���ʧ';
comment on column FACT_100132_LOST_USER.data_source
  is '����Դ';
create index IDX61_100132 on FACT_100132_LOST_USER (CHANNELID);
create index IDX62_100132 on FACT_100132_LOST_USER (SERVERID);
create index IDX63_100132 on FACT_100132_LOST_USER (STATDATE);

prompt
prompt Creating table FACT_100132_LTV_MAC
prompt ==================================
prompt
create table FACT_100132_LTV_MAC
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_LTV_MAC
  is '�豸LTV������';
comment on column FACT_100132_LTV_MAC.statdate
  is 'ͳ������';
comment on column FACT_100132_LTV_MAC.ltvdate
  is '��ֵ����';
comment on column FACT_100132_LTV_MAC.channelid
  is '����';
comment on column FACT_100132_LTV_MAC.serverid
  is '����';
comment on column FACT_100132_LTV_MAC.appid
  is '��Ʒid';
comment on column FACT_100132_LTV_MAC.ltv_days
  is 'ltv��';
comment on column FACT_100132_LTV_MAC.payamount
  is '���ѽ��';
comment on column FACT_100132_LTV_MAC.data_source
  is '������Դ';
create index IDX64_100132 on FACT_100132_LTV_MAC (CHANNELID);
create index IDX65_100132 on FACT_100132_LTV_MAC (SERVERID);
create index IDX66_100132 on FACT_100132_LTV_MAC (STATDATE);

prompt
prompt Creating table FACT_100132_LTV_USER
prompt ===================================
prompt
create table FACT_100132_LTV_USER
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_LTV_USER
  is '�û�LTV������';
comment on column FACT_100132_LTV_USER.statdate
  is 'ͳ������';
comment on column FACT_100132_LTV_USER.ltvdate
  is '��ֵ����';
comment on column FACT_100132_LTV_USER.channelid
  is '����';
comment on column FACT_100132_LTV_USER.serverid
  is '����';
comment on column FACT_100132_LTV_USER.appid
  is '��Ʒid';
comment on column FACT_100132_LTV_USER.ltv_days
  is 'ltv��';
comment on column FACT_100132_LTV_USER.payamount
  is '���ѽ��';
comment on column FACT_100132_LTV_USER.data_source
  is '������Դ';
create index IDX67_100132 on FACT_100132_LTV_USER (CHANNELID);
create index IDX68_100132 on FACT_100132_LTV_USER (SERVERID);
create index IDX69_100132 on FACT_100132_LTV_USER (STATDATE);

prompt
prompt Creating table FACT_100132_MISS_FIRST
prompt =====================================
prompt
create table FACT_100132_MISS_FIRST
(
  statdate        VARCHAR2(10),
  channelid       VARCHAR2(50),
  serverid        VARCHAR2(50),
  appid           VARCHAR2(50),
  versionid       VARCHAR2(50),
  missionid       VARCHAR2(50),
  rolelevel       NUMBER,
  rolejob         VARCHAR2(50) default '0',
  firstenter_succ NUMBER,
  firstenter_fail NUMBER,
  loaddate        DATE,
  data_source     VARCHAR2(100)
)
;
comment on table FACT_100132_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column FACT_100132_MISS_FIRST.statdate
  is 'ͳ������';
comment on column FACT_100132_MISS_FIRST.channelid
  is '����';
comment on column FACT_100132_MISS_FIRST.serverid
  is '����';
comment on column FACT_100132_MISS_FIRST.appid
  is '��ƷID';
comment on column FACT_100132_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_MISS_FIRST.missionid
  is '�ؿ�ID';
comment on column FACT_100132_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column FACT_100132_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column FACT_100132_MISS_FIRST.firstenter_succ
  is '��һ�ν���ؿ��ɹ���';
comment on column FACT_100132_MISS_FIRST.firstenter_fail
  is '��һ�ν���ؿ�ʧ����';
comment on column FACT_100132_MISS_FIRST.data_source
  is '������Դ';
create index IDX70_100132 on FACT_100132_MISS_FIRST (CHANNELID);
create index IDX71_100132 on FACT_100132_MISS_FIRST (SERVERID);
create index IDX72_100132 on FACT_100132_MISS_FIRST (STATDATE);

prompt
prompt Creating table FACT_100132_NET
prompt ==============================
prompt
create table FACT_100132_NET
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_net    VARCHAR2(50),
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_NET
  is '������ʽ������';
comment on column FACT_100132_NET.statdate
  is 'ͳ������';
comment on column FACT_100132_NET.channelid
  is '����';
comment on column FACT_100132_NET.serverid
  is '����';
comment on column FACT_100132_NET.appid
  is '��Ʒid';
comment on column FACT_100132_NET.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_NET.dvid_net
  is '������ʽ';
comment on column FACT_100132_NET.conncount
  is '������';
comment on column FACT_100132_NET.data_source
  is '������Դ';
create index IDX73_100132 on FACT_100132_NET (CHANNELID);
create index IDX74_100132 on FACT_100132_NET (SERVERID);
create index IDX75_100132 on FACT_100132_NET (STATDATE);

prompt
prompt Creating table FACT_100132_OPERATOR
prompt ===================================
prompt
create table FACT_100132_OPERATOR
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  dvid_operator VARCHAR2(50),
  conncount     NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100132_OPERATOR
  is '��Ӫ�̷�����';
comment on column FACT_100132_OPERATOR.statdate
  is 'ͳ������';
comment on column FACT_100132_OPERATOR.channelid
  is '����';
comment on column FACT_100132_OPERATOR.serverid
  is '����';
comment on column FACT_100132_OPERATOR.appid
  is '��Ʒid';
comment on column FACT_100132_OPERATOR.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_OPERATOR.dvid_operator
  is '������ʽ';
comment on column FACT_100132_OPERATOR.conncount
  is '������';
comment on column FACT_100132_OPERATOR.data_source
  is '������Դ';
create index IDX76_100132 on FACT_100132_OPERATOR (CHANNELID);
create index IDX77_100132 on FACT_100132_OPERATOR (SERVERID);
create index IDX78_100132 on FACT_100132_OPERATOR (STATDATE);

prompt
prompt Creating table FACT_100132_ORDER
prompt ================================
prompt
create table FACT_100132_ORDER
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100132_ORDER
  is '����������';
comment on column FACT_100132_ORDER.statdate
  is 'ͳ������';
comment on column FACT_100132_ORDER.channelid
  is '����';
comment on column FACT_100132_ORDER.serverid
  is '����';
comment on column FACT_100132_ORDER.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100132_ORDER.appid
  is '��Ʒid';
comment on column FACT_100132_ORDER.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_ORDER.paysucccount
  is '�ɹ�������';
comment on column FACT_100132_ORDER.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100132_ORDER.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100132_ORDER.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100132_ORDER.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100132_ORDER.payfailnum
  is '����ʧ������';
comment on column FACT_100132_ORDER.data_source
  is '������Դ';
create index IDX79_100132 on FACT_100132_ORDER (CHANNELID);
create index IDX80_100132 on FACT_100132_ORDER (SERVERID);
create index IDX81_100132 on FACT_100132_ORDER (STATDATE);

prompt
prompt Creating table FACT_100132_ORDER_HOUR
prompt =====================================
prompt
create table FACT_100132_ORDER_HOUR
(
  statdate      VARCHAR2(20),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100132_ORDER_HOUR
  is '����Сʱ������';
comment on column FACT_100132_ORDER_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100132_ORDER_HOUR.channelid
  is '����';
comment on column FACT_100132_ORDER_HOUR.serverid
  is '����';
comment on column FACT_100132_ORDER_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100132_ORDER_HOUR.appid
  is '��Ʒid';
comment on column FACT_100132_ORDER_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_ORDER_HOUR.paysucccount
  is '�ɹ�������';
comment on column FACT_100132_ORDER_HOUR.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100132_ORDER_HOUR.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100132_ORDER_HOUR.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100132_ORDER_HOUR.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100132_ORDER_HOUR.payfailnum
  is '����ʧ������';
comment on column FACT_100132_ORDER_HOUR.data_source
  is '������Դ';
create index IDX177_100132 on FACT_100132_ORDER_HOUR (CHANNELID);
create index IDX178_100132 on FACT_100132_ORDER_HOUR (SERVERID);
create index IDX179_100132 on FACT_100132_ORDER_HOUR (STATDATE);

prompt
prompt Creating table FACT_100132_ORDER_MONTH
prompt ======================================
prompt
create table FACT_100132_ORDER_MONTH
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100132_ORDER_MONTH
  is '�¶���������';
comment on column FACT_100132_ORDER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100132_ORDER_MONTH.channelid
  is '����';
comment on column FACT_100132_ORDER_MONTH.serverid
  is '����';
comment on column FACT_100132_ORDER_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100132_ORDER_MONTH.appid
  is '��Ʒid';
comment on column FACT_100132_ORDER_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_ORDER_MONTH.paysucccount
  is '�ɹ�������';
comment on column FACT_100132_ORDER_MONTH.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100132_ORDER_MONTH.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100132_ORDER_MONTH.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100132_ORDER_MONTH.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100132_ORDER_MONTH.payfailnum
  is '����ʧ������';
comment on column FACT_100132_ORDER_MONTH.data_source
  is '������Դ';
create index IDX191_100132 on FACT_100132_ORDER_MONTH (CHANNELID);
create index IDX192_100132 on FACT_100132_ORDER_MONTH (SERVERID);
create index IDX193_100132 on FACT_100132_ORDER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100132_ORDER_WEEK
prompt =====================================
prompt
create table FACT_100132_ORDER_WEEK
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100132_ORDER_WEEK
  is '�ܶ���������';
comment on column FACT_100132_ORDER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100132_ORDER_WEEK.channelid
  is '����';
comment on column FACT_100132_ORDER_WEEK.serverid
  is '����';
comment on column FACT_100132_ORDER_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100132_ORDER_WEEK.appid
  is '��Ʒid';
comment on column FACT_100132_ORDER_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_ORDER_WEEK.paysucccount
  is '�ɹ�������';
comment on column FACT_100132_ORDER_WEEK.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100132_ORDER_WEEK.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100132_ORDER_WEEK.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100132_ORDER_WEEK.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100132_ORDER_WEEK.payfailnum
  is '����ʧ������';
comment on column FACT_100132_ORDER_WEEK.data_source
  is '������Դ';
create index IDX188_100132 on FACT_100132_ORDER_WEEK (CHANNELID);
create index IDX189_100132 on FACT_100132_ORDER_WEEK (SERVERID);
create index IDX190_100132 on FACT_100132_ORDER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100132_PAYAMOUNT_DAY
prompt ========================================
prompt
create table FACT_100132_PAYAMOUNT_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_PAYAMOUNT_DAY
  is '�ճ�ֵ��������';
comment on column FACT_100132_PAYAMOUNT_DAY.statdate
  is 'ͳ������';
comment on column FACT_100132_PAYAMOUNT_DAY.channelid
  is '����';
comment on column FACT_100132_PAYAMOUNT_DAY.serverid
  is '����';
comment on column FACT_100132_PAYAMOUNT_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100132_PAYAMOUNT_DAY.appid
  is '��Ʒid';
comment on column FACT_100132_PAYAMOUNT_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_PAYAMOUNT_DAY.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100132_PAYAMOUNT_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100132_PAYAMOUNT_DAY.data_source
  is '������Դ';
create index IDX82_100132 on FACT_100132_PAYAMOUNT_DAY (CHANNELID);
create index IDX83_100132 on FACT_100132_PAYAMOUNT_DAY (SERVERID);
create index IDX84_100132 on FACT_100132_PAYAMOUNT_DAY (STATDATE);

prompt
prompt Creating table FACT_100132_PAYAMOUNT_MONTH
prompt ==========================================
prompt
create table FACT_100132_PAYAMOUNT_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_PAYAMOUNT_MONTH
  is '�³�ֵ��������';
comment on column FACT_100132_PAYAMOUNT_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100132_PAYAMOUNT_MONTH.channelid
  is '����';
comment on column FACT_100132_PAYAMOUNT_MONTH.serverid
  is '����';
comment on column FACT_100132_PAYAMOUNT_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100132_PAYAMOUNT_MONTH.appid
  is '��Ʒid';
comment on column FACT_100132_PAYAMOUNT_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_PAYAMOUNT_MONTH.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100132_PAYAMOUNT_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100132_PAYAMOUNT_MONTH.data_source
  is '������Դ';
create index IDX88_100132 on FACT_100132_PAYAMOUNT_MONTH (CHANNELID);
create index IDX89_100132 on FACT_100132_PAYAMOUNT_MONTH (SERVERID);
create index IDX90_100132 on FACT_100132_PAYAMOUNT_MONTH (STATDATE);

prompt
prompt Creating table FACT_100132_PAYAMOUNT_WEEK
prompt =========================================
prompt
create table FACT_100132_PAYAMOUNT_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_PAYAMOUNT_WEEK
  is '�ܳ�ֵ��������';
comment on column FACT_100132_PAYAMOUNT_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100132_PAYAMOUNT_WEEK.channelid
  is '����';
comment on column FACT_100132_PAYAMOUNT_WEEK.serverid
  is '����';
comment on column FACT_100132_PAYAMOUNT_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100132_PAYAMOUNT_WEEK.appid
  is '��Ʒid';
comment on column FACT_100132_PAYAMOUNT_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_PAYAMOUNT_WEEK.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100132_PAYAMOUNT_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100132_PAYAMOUNT_WEEK.data_source
  is '������Դ';
create index IDX85_100132 on FACT_100132_PAYAMOUNT_WEEK (CHANNELID);
create index IDX86_100132 on FACT_100132_PAYAMOUNT_WEEK (SERVERID);
create index IDX87_100132 on FACT_100132_PAYAMOUNT_WEEK (STATDATE);

prompt
prompt Creating table FACT_100132_PAYNUM_DAY
prompt =====================================
prompt
create table FACT_100132_PAYNUM_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_PAYNUM_DAY
  is '�ճ�ֵ����������';
comment on column FACT_100132_PAYNUM_DAY.statdate
  is 'ͳ������';
comment on column FACT_100132_PAYNUM_DAY.channelid
  is '����';
comment on column FACT_100132_PAYNUM_DAY.serverid
  is '����';
comment on column FACT_100132_PAYNUM_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100132_PAYNUM_DAY.appid
  is '��Ʒid';
comment on column FACT_100132_PAYNUM_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_PAYNUM_DAY.paynum
  is '��ֵ����';
comment on column FACT_100132_PAYNUM_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100132_PAYNUM_DAY.data_source
  is '������Դ';
create index IDX97_100132 on FACT_100132_PAYNUM_DAY (CHANNELID);
create index IDX98_100132 on FACT_100132_PAYNUM_DAY (SERVERID);
create index IDX99_100132 on FACT_100132_PAYNUM_DAY (STATDATE);

prompt
prompt Creating table FACT_100132_PAYNUM_MONTH
prompt =======================================
prompt
create table FACT_100132_PAYNUM_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_PAYNUM_MONTH
  is '�³�ֵ����������';
comment on column FACT_100132_PAYNUM_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100132_PAYNUM_MONTH.channelid
  is '����';
comment on column FACT_100132_PAYNUM_MONTH.serverid
  is '����';
comment on column FACT_100132_PAYNUM_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100132_PAYNUM_MONTH.appid
  is '��Ʒid';
comment on column FACT_100132_PAYNUM_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_PAYNUM_MONTH.paynum
  is '��ֵ����';
comment on column FACT_100132_PAYNUM_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100132_PAYNUM_MONTH.data_source
  is '������Դ';
create index IDX91_100132 on FACT_100132_PAYNUM_MONTH (CHANNELID);
create index IDX92_100132 on FACT_100132_PAYNUM_MONTH (SERVERID);
create index IDX93_100132 on FACT_100132_PAYNUM_MONTH (STATDATE);

prompt
prompt Creating table FACT_100132_PAYNUM_WEEK
prompt ======================================
prompt
create table FACT_100132_PAYNUM_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_PAYNUM_WEEK
  is '�ܳ�ֵ����������';
comment on column FACT_100132_PAYNUM_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100132_PAYNUM_WEEK.channelid
  is '����';
comment on column FACT_100132_PAYNUM_WEEK.serverid
  is '����';
comment on column FACT_100132_PAYNUM_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100132_PAYNUM_WEEK.appid
  is '��Ʒid';
comment on column FACT_100132_PAYNUM_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_PAYNUM_WEEK.paynum
  is '��ֵ����';
comment on column FACT_100132_PAYNUM_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100132_PAYNUM_WEEK.data_source
  is '������Դ';
create index IDX94_100132 on FACT_100132_PAYNUM_WEEK (CHANNELID);
create index IDX95_100132 on FACT_100132_PAYNUM_WEEK (SERVERID);
create index IDX96_100132 on FACT_100132_PAYNUM_WEEK (STATDATE);

prompt
prompt Creating table FACT_100132_PAYTYPE
prompt ==================================
prompt
create table FACT_100132_PAYTYPE
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paytypeid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_PAYTYPE
  is '��ֵ���ͷ�����';
comment on column FACT_100132_PAYTYPE.statdate
  is 'ͳ������';
comment on column FACT_100132_PAYTYPE.channelid
  is '����';
comment on column FACT_100132_PAYTYPE.serverid
  is '����';
comment on column FACT_100132_PAYTYPE.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100132_PAYTYPE.appid
  is '��Ʒid';
comment on column FACT_100132_PAYTYPE.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_PAYTYPE.paytypeid
  is '��ֵ����';
comment on column FACT_100132_PAYTYPE.payamount
  is '��ֵ���';
comment on column FACT_100132_PAYTYPE.paycount
  is '��ֵ����';
comment on column FACT_100132_PAYTYPE.paynum
  is '��ֵ����';
comment on column FACT_100132_PAYTYPE.data_source
  is '������Դ';
create index IDX100_100132 on FACT_100132_PAYTYPE (CHANNELID);
create index IDX101_100132 on FACT_100132_PAYTYPE (SERVERID);
create index IDX102_100132 on FACT_100132_PAYTYPE (STATDATE);

prompt
prompt Creating table FACT_100132_PAYWAY
prompt =================================
prompt
create table FACT_100132_PAYWAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paywayid    VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_PAYWAY
  is '��ֵ��ʽ������';
comment on column FACT_100132_PAYWAY.statdate
  is 'ͳ������';
comment on column FACT_100132_PAYWAY.channelid
  is '����';
comment on column FACT_100132_PAYWAY.serverid
  is '����';
comment on column FACT_100132_PAYWAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100132_PAYWAY.appid
  is '��Ʒid';
comment on column FACT_100132_PAYWAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_PAYWAY.paywayid
  is '��ֵ��ʽ';
comment on column FACT_100132_PAYWAY.payamount
  is '��ֵ���';
comment on column FACT_100132_PAYWAY.paycount
  is '��ֵ����';
comment on column FACT_100132_PAYWAY.paynum
  is '��ֵ����';
comment on column FACT_100132_PAYWAY.data_source
  is '������Դ';
create index IDX103_100132 on FACT_100132_PAYWAY (CHANNELID);
create index IDX104_100132 on FACT_100132_PAYWAY (SERVERID);
create index IDX105_100132 on FACT_100132_PAYWAY (STATDATE);

prompt
prompt Creating table FACT_100132_REGION
prompt =================================
prompt
create table FACT_100132_REGION
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  country     VARCHAR2(50),
  province    VARCHAR2(50),
  city        VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_REGION
  is '���������';
comment on column FACT_100132_REGION.statdate
  is 'ͳ������';
comment on column FACT_100132_REGION.channelid
  is '����';
comment on column FACT_100132_REGION.serverid
  is '����';
comment on column FACT_100132_REGION.appid
  is '��Ʒid';
comment on column FACT_100132_REGION.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_REGION.country
  is '����';
comment on column FACT_100132_REGION.province
  is 'ʡ';
comment on column FACT_100132_REGION.city
  is '��';
comment on column FACT_100132_REGION.newcount
  is '������';
comment on column FACT_100132_REGION.conncount
  is '������';
comment on column FACT_100132_REGION.paycount
  is '������';
comment on column FACT_100132_REGION.payamount
  is '���ѽ��';
comment on column FACT_100132_REGION.data_source
  is '������Դ';
create index IDX106_100132 on FACT_100132_REGION (CHANNELID);
create index IDX107_100132 on FACT_100132_REGION (SERVERID);
create index IDX108_100132 on FACT_100132_REGION (STATDATE);

prompt
prompt Creating table FACT_100132_REMAIN_MAC
prompt =====================================
prompt
create table FACT_100132_REMAIN_MAC
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_REMAIN_MAC
  is '�豸�����';
comment on column FACT_100132_REMAIN_MAC.statdate
  is 'ͳ������';
comment on column FACT_100132_REMAIN_MAC.conndate
  is '��������';
comment on column FACT_100132_REMAIN_MAC.channelid
  is '����ID';
comment on column FACT_100132_REMAIN_MAC.serverid
  is '����ID';
comment on column FACT_100132_REMAIN_MAC.appid
  is '��ƷID';
comment on column FACT_100132_REMAIN_MAC.remain_days
  is '��������';
comment on column FACT_100132_REMAIN_MAC.new_remain
  is '��������';
comment on column FACT_100132_REMAIN_MAC.conn_remain
  is '��������';
comment on column FACT_100132_REMAIN_MAC.pay_remain
  is '��������';
comment on column FACT_100132_REMAIN_MAC.data_source
  is '����Դ';
create index IDX109_100132 on FACT_100132_REMAIN_MAC (CHANNELID);
create index IDX110_100132 on FACT_100132_REMAIN_MAC (SERVERID);
create index IDX111_100132 on FACT_100132_REMAIN_MAC (STATDATE);

prompt
prompt Creating table FACT_100132_REMAIN_USER
prompt ======================================
prompt
create table FACT_100132_REMAIN_USER
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_REMAIN_USER
  is '�û������';
comment on column FACT_100132_REMAIN_USER.statdate
  is 'ͳ������';
comment on column FACT_100132_REMAIN_USER.conndate
  is '��������';
comment on column FACT_100132_REMAIN_USER.channelid
  is '����ID';
comment on column FACT_100132_REMAIN_USER.serverid
  is '����ID';
comment on column FACT_100132_REMAIN_USER.appid
  is '��ƷID';
comment on column FACT_100132_REMAIN_USER.remain_days
  is '��������';
comment on column FACT_100132_REMAIN_USER.new_remain
  is '��������';
comment on column FACT_100132_REMAIN_USER.conn_remain
  is '��������';
comment on column FACT_100132_REMAIN_USER.pay_remain
  is '��������';
comment on column FACT_100132_REMAIN_USER.data_source
  is '����Դ';
create index IDX112_100132 on FACT_100132_REMAIN_USER (CHANNELID);
create index IDX113_100132 on FACT_100132_REMAIN_USER (SERVERID);
create index IDX114_100132 on FACT_100132_REMAIN_USER (STATDATE);

prompt
prompt Creating table FACT_100132_VC
prompt =============================
prompt
create table FACT_100132_VC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcamount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100132_VC
  is '������ҷ�����';
comment on column FACT_100132_VC.statdate
  is 'ͳ������';
comment on column FACT_100132_VC.channelid
  is '����';
comment on column FACT_100132_VC.serverid
  is '����';
comment on column FACT_100132_VC.appid
  is '��Ʒid';
comment on column FACT_100132_VC.versionid
  is '��Ʒ�汾';
comment on column FACT_100132_VC.vctype
  is '�����������';
comment on column FACT_100132_VC.vcusetype
  is '�������ʹ������';
comment on column FACT_100132_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column FACT_100132_VC.vcamount
  is '������ҽ��';
comment on column FACT_100132_VC.data_source
  is '������Դ';
create index IDX115_100132 on FACT_100132_VC (CHANNELID);
create index IDX116_100132 on FACT_100132_VC (SERVERID);
create index IDX117_100132 on FACT_100132_VC (STATDATE);

prompt
prompt Creating table FACT_100138_BACK_MAC
prompt ===================================
prompt
create table FACT_100138_BACK_MAC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_BACK_MAC
  is '�豸����������';
comment on column FACT_100138_BACK_MAC.statdate
  is 'ͳ������';
comment on column FACT_100138_BACK_MAC.channelid
  is '����ID';
comment on column FACT_100138_BACK_MAC.serverid
  is '����ID';
comment on column FACT_100138_BACK_MAC.appid
  is '��ƷID';
comment on column FACT_100138_BACK_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100138_BACK_MAC.back_conn
  is '��Ծ�豸������';
comment on column FACT_100138_BACK_MAC.back_pay
  is '�����豸������';
comment on column FACT_100138_BACK_MAC.data_source
  is '����Դ';
create index IDX1_100138 on FACT_100138_BACK_MAC (CHANNELID);
create index IDX2_100138 on FACT_100138_BACK_MAC (SERVERID);
create index IDX3_100138 on FACT_100138_BACK_MAC (STATDATE);

prompt
prompt Creating table FACT_100138_BACK_MAC_MONTH
prompt =========================================
prompt
create table FACT_100138_BACK_MAC_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_BACK_MAC_MONTH
  is '�豸����������';
comment on column FACT_100138_BACK_MAC_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100138_BACK_MAC_MONTH.channelid
  is '����ID';
comment on column FACT_100138_BACK_MAC_MONTH.serverid
  is '����ID';
comment on column FACT_100138_BACK_MAC_MONTH.appid
  is '��ƷID';
comment on column FACT_100138_BACK_MAC_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100138_BACK_MAC_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100138_BACK_MAC_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100138_BACK_MAC_MONTH.data_source
  is '����Դ';
create index IDX4_100138 on FACT_100138_BACK_MAC_MONTH (CHANNELID);
create index IDX5_100138 on FACT_100138_BACK_MAC_MONTH (SERVERID);
create index IDX6_100138 on FACT_100138_BACK_MAC_MONTH (STATDATE);

prompt
prompt Creating table FACT_100138_BACK_MAC_WEEK
prompt ========================================
prompt
create table FACT_100138_BACK_MAC_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_BACK_MAC_WEEK
  is '�豸����������';
comment on column FACT_100138_BACK_MAC_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100138_BACK_MAC_WEEK.channelid
  is '����ID';
comment on column FACT_100138_BACK_MAC_WEEK.serverid
  is '����ID';
comment on column FACT_100138_BACK_MAC_WEEK.appid
  is '��ƷID';
comment on column FACT_100138_BACK_MAC_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100138_BACK_MAC_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100138_BACK_MAC_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100138_BACK_MAC_WEEK.data_source
  is '����Դ';
create index IDX7_100138 on FACT_100138_BACK_MAC_WEEK (CHANNELID);
create index IDX8_100138 on FACT_100138_BACK_MAC_WEEK (SERVERID);
create index IDX9_100138 on FACT_100138_BACK_MAC_WEEK (STATDATE);

prompt
prompt Creating table FACT_100138_BACK_USER
prompt ====================================
prompt
create table FACT_100138_BACK_USER
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_days   NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_BACK_USER
  is '�û�����������';
comment on column FACT_100138_BACK_USER.statdate
  is 'ͳ������';
comment on column FACT_100138_BACK_USER.channelid
  is '����ID';
comment on column FACT_100138_BACK_USER.serverid
  is '����ID';
comment on column FACT_100138_BACK_USER.appid
  is '��ƷID';
comment on column FACT_100138_BACK_USER.lost_days
  is '��ʧ����';
comment on column FACT_100138_BACK_USER.back_conn
  is '��Ծ�û�������';
comment on column FACT_100138_BACK_USER.back_pay
  is '�����û�������';
comment on column FACT_100138_BACK_USER.data_source
  is '����Դ';
create index IDX16_100138 on FACT_100138_BACK_USER (CHANNELID);
create index IDX17_100138 on FACT_100138_BACK_USER (SERVERID);
create index IDX18_100138 on FACT_100138_BACK_USER (STATDATE);

prompt
prompt Creating table FACT_100138_BACK_USER_MONTH
prompt ==========================================
prompt
create table FACT_100138_BACK_USER_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_BACK_USER_MONTH
  is '�豸����������';
comment on column FACT_100138_BACK_USER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100138_BACK_USER_MONTH.channelid
  is '����ID';
comment on column FACT_100138_BACK_USER_MONTH.serverid
  is '����ID';
comment on column FACT_100138_BACK_USER_MONTH.appid
  is '��ƷID';
comment on column FACT_100138_BACK_USER_MONTH.lost_weeks
  is '��ʧ����';
comment on column FACT_100138_BACK_USER_MONTH.back_conn
  is '��Ծ�豸������';
comment on column FACT_100138_BACK_USER_MONTH.back_pay
  is '�����豸������';
comment on column FACT_100138_BACK_USER_MONTH.data_source
  is '����Դ';
create index IDX13_100138 on FACT_100138_BACK_USER_MONTH (CHANNELID);
create index IDX14_100138 on FACT_100138_BACK_USER_MONTH (SERVERID);
create index IDX15_100138 on FACT_100138_BACK_USER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100138_BACK_USER_WEEK
prompt =========================================
prompt
create table FACT_100138_BACK_USER_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  lost_weeks  NUMBER,
  back_conn   NUMBER,
  back_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_BACK_USER_WEEK
  is '�豸����������';
comment on column FACT_100138_BACK_USER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100138_BACK_USER_WEEK.channelid
  is '����ID';
comment on column FACT_100138_BACK_USER_WEEK.serverid
  is '����ID';
comment on column FACT_100138_BACK_USER_WEEK.appid
  is '��ƷID';
comment on column FACT_100138_BACK_USER_WEEK.lost_weeks
  is '��ʧ����';
comment on column FACT_100138_BACK_USER_WEEK.back_conn
  is '��Ծ�豸������';
comment on column FACT_100138_BACK_USER_WEEK.back_pay
  is '�����豸������';
comment on column FACT_100138_BACK_USER_WEEK.data_source
  is '����Դ';
create index IDX10_100138 on FACT_100138_BACK_USER_WEEK (CHANNELID);
create index IDX11_100138 on FACT_100138_BACK_USER_WEEK (SERVERID);
create index IDX12_100138 on FACT_100138_BACK_USER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100138_CEVENT
prompt =================================
prompt
create table FACT_100138_CEVENT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  eventkey    VARCHAR2(50),
  eventcount  NUMBER,
  eventnum    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_CEVENT
  is '�Զ��������';
comment on column FACT_100138_CEVENT.statdate
  is 'ͳ������';
comment on column FACT_100138_CEVENT.channelid
  is '����';
comment on column FACT_100138_CEVENT.serverid
  is '����';
comment on column FACT_100138_CEVENT.appid
  is '��Ʒid';
comment on column FACT_100138_CEVENT.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100138_CEVENT.eventcount
  is '�¼��û���';
comment on column FACT_100138_CEVENT.eventnum
  is '�¼�����';
comment on column FACT_100138_CEVENT.data_source
  is '������Դ';
create index IDX181_100138 on FACT_100138_CEVENT (CHANNELID);
create index IDX182_100138 on FACT_100138_CEVENT (SERVERID);
create index IDX183_100138 on FACT_100138_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100138_CEVENT_PAR
prompt =====================================
prompt
create table FACT_100138_CEVENT_PAR
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  ilevel         NUMBER,
  eventkey       VARCHAR2(100),
  eventpar_key   VARCHAR2(100),
  eventpar_value VARCHAR2(100),
  eventcount     NUMBER,
  eventnum       NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100138_CEVENT_PAR
  is '�Զ������������';
comment on column FACT_100138_CEVENT_PAR.statdate
  is 'ͳ������';
comment on column FACT_100138_CEVENT_PAR.channelid
  is '����';
comment on column FACT_100138_CEVENT_PAR.serverid
  is '����';
comment on column FACT_100138_CEVENT_PAR.appid
  is '��Ʒid';
comment on column FACT_100138_CEVENT_PAR.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_CEVENT_PAR.ilevel
  is '��ɫ�ȼ�';
comment on column FACT_100138_CEVENT_PAR.eventkey
  is '�¼�����';
comment on column FACT_100138_CEVENT_PAR.eventpar_key
  is '�¼�����';
comment on column FACT_100138_CEVENT_PAR.eventpar_value
  is '�¼�����ֵ';
comment on column FACT_100138_CEVENT_PAR.eventcount
  is '�¼��û���';
comment on column FACT_100138_CEVENT_PAR.eventnum
  is '�¼�����';
comment on column FACT_100138_CEVENT_PAR.data_source
  is '������Դ';
create index IDX185_100138 on FACT_100138_CEVENT_PAR (CHANNELID);
create index IDX186_100138 on FACT_100138_CEVENT_PAR (SERVERID);
create index IDX187_100138 on FACT_100138_CEVENT_PAR (STATDATE);

prompt
prompt Creating table FACT_100138_COMP_CEVENT
prompt ======================================
prompt
create table FACT_100138_COMP_CEVENT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(10),
  channelid   VARCHAR2(50),
  gameversion VARCHAR2(50),
  serverid    VARCHAR2(50),
  ilevel      NUMBER,
  eventkey    VARCHAR2(100),
  compid      VARCHAR2(50),
  caltype     VARCHAR2(50),
  dimpars     VARCHAR2(2000),
  comp_data   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_COMP_CEVENT
  is '�Զ����¼���Ϸ�����';
comment on column FACT_100138_COMP_CEVENT.statdate
  is '����';
comment on column FACT_100138_COMP_CEVENT.appid
  is '��Ϸ�� appid';
comment on column FACT_100138_COMP_CEVENT.channelid
  is '���� ID';
comment on column FACT_100138_COMP_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column FACT_100138_COMP_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column FACT_100138_COMP_CEVENT.ilevel
  is '��ҵȼ�';
comment on column FACT_100138_COMP_CEVENT.eventkey
  is '�¼�����';
comment on column FACT_100138_COMP_CEVENT.compid
  is '��ϼ����¼�ID';
comment on column FACT_100138_COMP_CEVENT.caltype
  is '��ϼ����¼���������';
comment on column FACT_100138_COMP_CEVENT.dimpars
  is '��ϲ���';
comment on column FACT_100138_COMP_CEVENT.comp_data
  is '��ϼ�����';
create index IDX184_100138 on FACT_100138_COMP_CEVENT (STATDATE);

prompt
prompt Creating table FACT_100138_DAILY_REPORT
prompt =======================================
prompt
create table FACT_100138_DAILY_REPORT
(
  statdate    VARCHAR2(10),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_DAILY_REPORT
  is '�ձ�����';
comment on column FACT_100138_DAILY_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100138_DAILY_REPORT.appid
  is '��ƷID';
comment on column FACT_100138_DAILY_REPORT.channelid
  is '����';
comment on column FACT_100138_DAILY_REPORT.serverid
  is '����';
comment on column FACT_100138_DAILY_REPORT.indexid
  is 'ָ��';
comment on column FACT_100138_DAILY_REPORT.indtype
  is 'ָ������';
comment on column FACT_100138_DAILY_REPORT.rpt_data
  is '����';
create index IDX176_100138 on FACT_100138_DAILY_REPORT (STATDATE);

prompt
prompt Creating table FACT_100138_DVID
prompt ===============================
prompt
create table FACT_100138_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_model  VARCHAR2(200),
  dvid_res    VARCHAR2(50),
  dvid_os     VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_DVID
  is '�豸������';
comment on column FACT_100138_DVID.statdate
  is 'ͳ������';
comment on column FACT_100138_DVID.channelid
  is '����';
comment on column FACT_100138_DVID.serverid
  is '����';
comment on column FACT_100138_DVID.appid
  is '��Ʒid';
comment on column FACT_100138_DVID.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_DVID.dvid_model
  is '����';
comment on column FACT_100138_DVID.dvid_res
  is '�豸�ֱ���';
comment on column FACT_100138_DVID.dvid_os
  is '�豸����ϵͳ';
comment on column FACT_100138_DVID.newcount
  is '�����û���';
comment on column FACT_100138_DVID.conncount
  is '�����û���';
comment on column FACT_100138_DVID.data_source
  is '������Դ';
create index IDX19_100138 on FACT_100138_DVID (CHANNELID);
create index IDX20_100138 on FACT_100138_DVID (SERVERID);
create index IDX21_100138 on FACT_100138_DVID (STATDATE);

prompt
prompt Creating table FACT_100138_FIRSTPAY
prompt ===================================
prompt
create table FACT_100138_FIRSTPAY
(
  statdate         VARCHAR2(10),
  firstpaydate     VARCHAR2(10),
  channelid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  datatype         VARCHAR2(50),
  appid            VARCHAR2(50),
  first_payfromreg NUMBER,
  first_paycount   NUMBER,
  payamount        NUMBER,
  loaddate         DATE default SYSDATE,
  data_source      VARCHAR2(100)
)
;
comment on table FACT_100138_FIRSTPAY
  is '�����û��״γ�ֵ������';
comment on column FACT_100138_FIRSTPAY.statdate
  is 'ͳ������';
comment on column FACT_100138_FIRSTPAY.firstpaydate
  is '�״θ�������';
comment on column FACT_100138_FIRSTPAY.channelid
  is '����';
comment on column FACT_100138_FIRSTPAY.serverid
  is '����';
comment on column FACT_100138_FIRSTPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100138_FIRSTPAY.appid
  is '��Ʒid';
comment on column FACT_100138_FIRSTPAY.first_payfromreg
  is 'ע���ڼ��쿪ʼ��ֵ(1��2��..7..30..)';
comment on column FACT_100138_FIRSTPAY.first_paycount
  is '���������û���';
comment on column FACT_100138_FIRSTPAY.payamount
  is '�ۼƵ��ڼ���ĳ�ֵ�ܶ�';
comment on column FACT_100138_FIRSTPAY.data_source
  is '������Դ';
create index IDX22_100138 on FACT_100138_FIRSTPAY (CHANNELID);
create index IDX23_100138 on FACT_100138_FIRSTPAY (SERVERID);
create index IDX24_100138 on FACT_100138_FIRSTPAY (STATDATE);

prompt
prompt Creating table FACT_100138_FIRSTPAY_AMOUNT
prompt ==========================================
prompt
create table FACT_100138_FIRSTPAY_AMOUNT
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_FIRSTPAY_AMOUNT
  is '�״θ��ѽ�������';
comment on column FACT_100138_FIRSTPAY_AMOUNT.statdate
  is 'ͳ������';
comment on column FACT_100138_FIRSTPAY_AMOUNT.channelid
  is '����';
comment on column FACT_100138_FIRSTPAY_AMOUNT.serverid
  is '��������';
comment on column FACT_100138_FIRSTPAY_AMOUNT.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100138_FIRSTPAY_AMOUNT.appid
  is '��Ʒid';
comment on column FACT_100138_FIRSTPAY_AMOUNT.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_FIRSTPAY_AMOUNT.payamount
  is '�״θ��ѽ��';
comment on column FACT_100138_FIRSTPAY_AMOUNT.paycount
  is '�״θ��ѽ���Ӧ������';
create index IDX25_100138 on FACT_100138_FIRSTPAY_AMOUNT (CHANNELID);
create index IDX26_100138 on FACT_100138_FIRSTPAY_AMOUNT (SERVERID);
create index IDX27_100138 on FACT_100138_FIRSTPAY_AMOUNT (STATDATE);

prompt
prompt Creating table FACT_100138_GENERAL_DAY
prompt ======================================
prompt
create table FACT_100138_GENERAL_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_GENERAL_DAY
  is '�ջ���������';
comment on column FACT_100138_GENERAL_DAY.statdate
  is 'ͳ������';
comment on column FACT_100138_GENERAL_DAY.channelid
  is '����';
comment on column FACT_100138_GENERAL_DAY.serverid
  is '����';
comment on column FACT_100138_GENERAL_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100138_GENERAL_DAY.appid
  is '��Ʒid';
comment on column FACT_100138_GENERAL_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_GENERAL_DAY.newcount
  is '������';
comment on column FACT_100138_GENERAL_DAY.conncount
  is '������';
comment on column FACT_100138_GENERAL_DAY.paycount
  is '������';
comment on column FACT_100138_GENERAL_DAY.payamount
  is '���ѽ��';
comment on column FACT_100138_GENERAL_DAY.data_source
  is '������Դ';
create index IDX28_100138 on FACT_100138_GENERAL_DAY (CHANNELID);
create index IDX29_100138 on FACT_100138_GENERAL_DAY (SERVERID);
create index IDX30_100138 on FACT_100138_GENERAL_DAY (STATDATE);

prompt
prompt Creating table FACT_100138_GENERAL_DAY_DVID
prompt ===========================================
prompt
create table FACT_100138_GENERAL_DAY_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_GENERAL_DAY_DVID
  is '���豸����������';
comment on column FACT_100138_GENERAL_DAY_DVID.statdate
  is 'ͳ������';
comment on column FACT_100138_GENERAL_DAY_DVID.channelid
  is '����';
comment on column FACT_100138_GENERAL_DAY_DVID.appid
  is '��Ʒid';
comment on column FACT_100138_GENERAL_DAY_DVID.newcount
  is '������';
comment on column FACT_100138_GENERAL_DAY_DVID.conncount
  is '������';
comment on column FACT_100138_GENERAL_DAY_DVID.data_source
  is '������Դ';
create index IDX31_100138 on FACT_100138_GENERAL_DAY_DVID (CHANNELID);
create index IDX33_100138 on FACT_100138_GENERAL_DAY_DVID (STATDATE);

prompt
prompt Creating table FACT_100138_GENERAL_HOUR
prompt =======================================
prompt
create table FACT_100138_GENERAL_HOUR
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_GENERAL_HOUR
  is 'Сʱ����������';
comment on column FACT_100138_GENERAL_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100138_GENERAL_HOUR.channelid
  is '����';
comment on column FACT_100138_GENERAL_HOUR.serverid
  is '����';
comment on column FACT_100138_GENERAL_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100138_GENERAL_HOUR.appid
  is '��Ʒid';
comment on column FACT_100138_GENERAL_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_GENERAL_HOUR.newcount
  is '������';
comment on column FACT_100138_GENERAL_HOUR.conncount
  is '������';
comment on column FACT_100138_GENERAL_HOUR.paycount
  is '������';
comment on column FACT_100138_GENERAL_HOUR.payamount
  is '���ѽ��';
comment on column FACT_100138_GENERAL_HOUR.data_source
  is '������Դ';
create index IDX34_100138 on FACT_100138_GENERAL_HOUR (CHANNELID);
create index IDX35_100138 on FACT_100138_GENERAL_HOUR (SERVERID);
create index IDX36_100138 on FACT_100138_GENERAL_HOUR (STATDATE);

prompt
prompt Creating table FACT_100138_GENERAL_HOUR_DVID
prompt ============================================
prompt
create table FACT_100138_GENERAL_HOUR_DVID
(
  statdate    VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_GENERAL_HOUR_DVID
  is 'Сʱ�豸����������';
comment on column FACT_100138_GENERAL_HOUR_DVID.statdate
  is 'ͳ������';
comment on column FACT_100138_GENERAL_HOUR_DVID.channelid
  is '����';
comment on column FACT_100138_GENERAL_HOUR_DVID.appid
  is '��Ʒid';
comment on column FACT_100138_GENERAL_HOUR_DVID.newcount
  is '������';
comment on column FACT_100138_GENERAL_HOUR_DVID.conncount
  is '������';
comment on column FACT_100138_GENERAL_HOUR_DVID.data_source
  is '������Դ';
create index IDX37_100138 on FACT_100138_GENERAL_HOUR_DVID (CHANNELID);
create index IDX39_100138 on FACT_100138_GENERAL_HOUR_DVID (STATDATE);

prompt
prompt Creating table FACT_100138_GENERAL_LEVEL
prompt ========================================
prompt
create table FACT_100138_GENERAL_LEVEL
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  rolelevel   NUMBER,
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_GENERAL_LEVEL
  is '�û��ȼ�������';
comment on column FACT_100138_GENERAL_LEVEL.statdate
  is 'ͳ������';
comment on column FACT_100138_GENERAL_LEVEL.channelid
  is '����';
comment on column FACT_100138_GENERAL_LEVEL.serverid
  is '����';
comment on column FACT_100138_GENERAL_LEVEL.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100138_GENERAL_LEVEL.appid
  is '��Ʒid';
comment on column FACT_100138_GENERAL_LEVEL.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_GENERAL_LEVEL.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100138_GENERAL_LEVEL.newcount
  is '������';
comment on column FACT_100138_GENERAL_LEVEL.conncount
  is '������';
comment on column FACT_100138_GENERAL_LEVEL.paycount
  is '������';
comment on column FACT_100138_GENERAL_LEVEL.payamount
  is '���ѽ��';
comment on column FACT_100138_GENERAL_LEVEL.data_source
  is '������Դ';
create index IDX40_100138 on FACT_100138_GENERAL_LEVEL (CHANNELID);
create index IDX41_100138 on FACT_100138_GENERAL_LEVEL (SERVERID);
create index IDX42_100138 on FACT_100138_GENERAL_LEVEL (STATDATE);

prompt
prompt Creating table FACT_100138_GENERAL_MONTH
prompt ========================================
prompt
create table FACT_100138_GENERAL_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_GENERAL_MONTH
  is '�»���������';
comment on column FACT_100138_GENERAL_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100138_GENERAL_MONTH.channelid
  is '����';
comment on column FACT_100138_GENERAL_MONTH.serverid
  is '����';
comment on column FACT_100138_GENERAL_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100138_GENERAL_MONTH.appid
  is '��Ʒid';
comment on column FACT_100138_GENERAL_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_GENERAL_MONTH.newcount
  is '������';
comment on column FACT_100138_GENERAL_MONTH.conncount
  is '������';
comment on column FACT_100138_GENERAL_MONTH.paycount
  is '������';
comment on column FACT_100138_GENERAL_MONTH.payamount
  is '���ѽ��';
comment on column FACT_100138_GENERAL_MONTH.data_source
  is '������Դ';
create index IDX43_100138 on FACT_100138_GENERAL_MONTH (CHANNELID);
create index IDX44_100138 on FACT_100138_GENERAL_MONTH (SERVERID);
create index IDX45_100138 on FACT_100138_GENERAL_MONTH (STATDATE);

prompt
prompt Creating table FACT_100138_GENERAL_MONTH_DVID
prompt =============================================
prompt
create table FACT_100138_GENERAL_MONTH_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_GENERAL_MONTH_DVID
  is '���豸����������';
comment on column FACT_100138_GENERAL_MONTH_DVID.statdate
  is 'ͳ������';
comment on column FACT_100138_GENERAL_MONTH_DVID.channelid
  is '����';
comment on column FACT_100138_GENERAL_MONTH_DVID.appid
  is '��Ʒid';
comment on column FACT_100138_GENERAL_MONTH_DVID.newcount
  is '������';
comment on column FACT_100138_GENERAL_MONTH_DVID.conncount
  is '������';
comment on column FACT_100138_GENERAL_MONTH_DVID.data_source
  is '������Դ';
create index IDX46_100138 on FACT_100138_GENERAL_MONTH_DVID (CHANNELID);
create index IDX48_100138 on FACT_100138_GENERAL_MONTH_DVID (STATDATE);

prompt
prompt Creating table FACT_100138_GENERAL_WEEK
prompt =======================================
prompt
create table FACT_100138_GENERAL_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_GENERAL_WEEK
  is '�ܻ���������';
comment on column FACT_100138_GENERAL_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100138_GENERAL_WEEK.channelid
  is '����';
comment on column FACT_100138_GENERAL_WEEK.serverid
  is '����';
comment on column FACT_100138_GENERAL_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100138_GENERAL_WEEK.appid
  is '��Ʒid';
comment on column FACT_100138_GENERAL_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_GENERAL_WEEK.newcount
  is '������';
comment on column FACT_100138_GENERAL_WEEK.conncount
  is '������';
comment on column FACT_100138_GENERAL_WEEK.paycount
  is '������';
comment on column FACT_100138_GENERAL_WEEK.payamount
  is '���ѽ��';
comment on column FACT_100138_GENERAL_WEEK.data_source
  is '������Դ';
create index IDX52_100138 on FACT_100138_GENERAL_WEEK (CHANNELID);
create index IDX53_100138 on FACT_100138_GENERAL_WEEK (SERVERID);
create index IDX54_100138 on FACT_100138_GENERAL_WEEK (STATDATE);

prompt
prompt Creating table FACT_100138_GENERAL_WEEK_DVID
prompt ============================================
prompt
create table FACT_100138_GENERAL_WEEK_DVID
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_GENERAL_WEEK_DVID
  is '���豸����������';
comment on column FACT_100138_GENERAL_WEEK_DVID.statdate
  is 'ͳ������';
comment on column FACT_100138_GENERAL_WEEK_DVID.channelid
  is '����';
comment on column FACT_100138_GENERAL_WEEK_DVID.appid
  is '��Ʒid';
comment on column FACT_100138_GENERAL_WEEK_DVID.newcount
  is '������';
comment on column FACT_100138_GENERAL_WEEK_DVID.conncount
  is '������';
comment on column FACT_100138_GENERAL_WEEK_DVID.data_source
  is '������Դ';
create index IDX49_100138 on FACT_100138_GENERAL_WEEK_DVID (CHANNELID);
create index IDX51_100138 on FACT_100138_GENERAL_WEEK_DVID (STATDATE);

prompt
prompt Creating table FACT_100138_HOUR_REPORT
prompt ======================================
prompt
create table FACT_100138_HOUR_REPORT
(
  statdate    VARCHAR2(20),
  appid       VARCHAR2(50),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  indexid     VARCHAR2(100),
  indtype     VARCHAR2(50),
  rpt_data    NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_HOUR_REPORT
  is '�ձ�Сʱ����';
comment on column FACT_100138_HOUR_REPORT.statdate
  is 'ͳ������';
comment on column FACT_100138_HOUR_REPORT.appid
  is '��ƷID';
comment on column FACT_100138_HOUR_REPORT.channelid
  is '����';
comment on column FACT_100138_HOUR_REPORT.serverid
  is '����';
comment on column FACT_100138_HOUR_REPORT.indexid
  is 'ָ��';
comment on column FACT_100138_HOUR_REPORT.indtype
  is 'ָ������';
comment on column FACT_100138_HOUR_REPORT.rpt_data
  is '����';

prompt
prompt Creating table FACT_100138_LEVELPAY
prompt ===================================
prompt
create table FACT_100138_LEVELPAY
(
  statdate       VARCHAR2(10),
  channelid      VARCHAR2(50),
  serverid       VARCHAR2(50),
  datatype       VARCHAR2(50),
  appid          VARCHAR2(50),
  versionid      VARCHAR2(50),
  rolelevel      NUMBER,
  paycount       NUMBER,
  first_paycount NUMBER,
  loaddate       DATE default SYSDATE,
  data_source    VARCHAR2(100)
)
;
comment on table FACT_100138_LEVELPAY
  is '�û���ɫ�ȼ����ѷ�����';
comment on column FACT_100138_LEVELPAY.statdate
  is 'ͳ������';
comment on column FACT_100138_LEVELPAY.channelid
  is '����';
comment on column FACT_100138_LEVELPAY.serverid
  is '����';
comment on column FACT_100138_LEVELPAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100138_LEVELPAY.appid
  is '��Ʒid';
comment on column FACT_100138_LEVELPAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_LEVELPAY.rolelevel
  is '�û���ɫ�ȼ�';
comment on column FACT_100138_LEVELPAY.paycount
  is '�����û���';
comment on column FACT_100138_LEVELPAY.first_paycount
  is '���������û������״θ����û���';
comment on column FACT_100138_LEVELPAY.data_source
  is '������Դ';
create index IDX55_100138 on FACT_100138_LEVELPAY (CHANNELID);
create index IDX56_100138 on FACT_100138_LEVELPAY (SERVERID);
create index IDX57_100138 on FACT_100138_LEVELPAY (STATDATE);

prompt
prompt Creating table FACT_100138_LOST_MAC
prompt ===================================
prompt
create table FACT_100138_LOST_MAC
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_LOST_MAC
  is '�豸��ʧ������';
comment on column FACT_100138_LOST_MAC.statdate
  is 'ͳ������';
comment on column FACT_100138_LOST_MAC.lostdate
  is '��ʧ����';
comment on column FACT_100138_LOST_MAC.channelid
  is '����ID';
comment on column FACT_100138_LOST_MAC.serverid
  is '����ID';
comment on column FACT_100138_LOST_MAC.appid
  is '��ƷID';
comment on column FACT_100138_LOST_MAC.rolelevel
  is '��ʧʱ�ȼ�';
comment on column FACT_100138_LOST_MAC.lost_days
  is '��ʧ����';
comment on column FACT_100138_LOST_MAC.lost_conn
  is '��Ծ�豸��ʧ';
comment on column FACT_100138_LOST_MAC.lost_pay
  is '�����豸��ʧ';
comment on column FACT_100138_LOST_MAC.data_source
  is '����Դ';
create index IDX58_100138 on FACT_100138_LOST_MAC (CHANNELID);
create index IDX59_100138 on FACT_100138_LOST_MAC (SERVERID);
create index IDX60_100138 on FACT_100138_LOST_MAC (STATDATE);

prompt
prompt Creating table FACT_100138_LOST_USER
prompt ====================================
prompt
create table FACT_100138_LOST_USER
(
  statdate    VARCHAR2(10),
  lostdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  lost_conn   NUMBER,
  lost_pay    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_LOST_USER
  is '�û���ʧ������';
comment on column FACT_100138_LOST_USER.statdate
  is 'ͳ������';
comment on column FACT_100138_LOST_USER.lostdate
  is '��ʧ����';
comment on column FACT_100138_LOST_USER.channelid
  is '����ID';
comment on column FACT_100138_LOST_USER.serverid
  is '����ID';
comment on column FACT_100138_LOST_USER.appid
  is '��ƷID';
comment on column FACT_100138_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column FACT_100138_LOST_USER.lost_days
  is '��ʧ����';
comment on column FACT_100138_LOST_USER.lost_conn
  is '��Ծ�û���ʧ';
comment on column FACT_100138_LOST_USER.lost_pay
  is '�����û���ʧ';
comment on column FACT_100138_LOST_USER.data_source
  is '����Դ';
create index IDX61_100138 on FACT_100138_LOST_USER (CHANNELID);
create index IDX62_100138 on FACT_100138_LOST_USER (SERVERID);
create index IDX63_100138 on FACT_100138_LOST_USER (STATDATE);

prompt
prompt Creating table FACT_100138_LTV_MAC
prompt ==================================
prompt
create table FACT_100138_LTV_MAC
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_LTV_MAC
  is '�豸LTV������';
comment on column FACT_100138_LTV_MAC.statdate
  is 'ͳ������';
comment on column FACT_100138_LTV_MAC.ltvdate
  is '��ֵ����';
comment on column FACT_100138_LTV_MAC.channelid
  is '����';
comment on column FACT_100138_LTV_MAC.serverid
  is '����';
comment on column FACT_100138_LTV_MAC.appid
  is '��Ʒid';
comment on column FACT_100138_LTV_MAC.ltv_days
  is 'ltv��';
comment on column FACT_100138_LTV_MAC.payamount
  is '���ѽ��';
comment on column FACT_100138_LTV_MAC.data_source
  is '������Դ';
create index IDX64_100138 on FACT_100138_LTV_MAC (CHANNELID);
create index IDX65_100138 on FACT_100138_LTV_MAC (SERVERID);
create index IDX66_100138 on FACT_100138_LTV_MAC (STATDATE);

prompt
prompt Creating table FACT_100138_LTV_USER
prompt ===================================
prompt
create table FACT_100138_LTV_USER
(
  statdate    VARCHAR2(10),
  ltvdate     VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  ltv_days    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_LTV_USER
  is '�û�LTV������';
comment on column FACT_100138_LTV_USER.statdate
  is 'ͳ������';
comment on column FACT_100138_LTV_USER.ltvdate
  is '��ֵ����';
comment on column FACT_100138_LTV_USER.channelid
  is '����';
comment on column FACT_100138_LTV_USER.serverid
  is '����';
comment on column FACT_100138_LTV_USER.appid
  is '��Ʒid';
comment on column FACT_100138_LTV_USER.ltv_days
  is 'ltv��';
comment on column FACT_100138_LTV_USER.payamount
  is '���ѽ��';
comment on column FACT_100138_LTV_USER.data_source
  is '������Դ';
create index IDX67_100138 on FACT_100138_LTV_USER (CHANNELID);
create index IDX68_100138 on FACT_100138_LTV_USER (SERVERID);
create index IDX69_100138 on FACT_100138_LTV_USER (STATDATE);

prompt
prompt Creating table FACT_100138_MISS_FIRST
prompt =====================================
prompt
create table FACT_100138_MISS_FIRST
(
  statdate        VARCHAR2(10),
  channelid       VARCHAR2(50),
  serverid        VARCHAR2(50),
  appid           VARCHAR2(50),
  versionid       VARCHAR2(50),
  missionid       VARCHAR2(50),
  rolelevel       NUMBER,
  rolejob         VARCHAR2(50) default '0',
  firstenter_succ NUMBER,
  firstenter_fail NUMBER,
  loaddate        DATE,
  data_source     VARCHAR2(100)
)
;
comment on table FACT_100138_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column FACT_100138_MISS_FIRST.statdate
  is 'ͳ������';
comment on column FACT_100138_MISS_FIRST.channelid
  is '����';
comment on column FACT_100138_MISS_FIRST.serverid
  is '����';
comment on column FACT_100138_MISS_FIRST.appid
  is '��ƷID';
comment on column FACT_100138_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_MISS_FIRST.missionid
  is '�ؿ�ID';
comment on column FACT_100138_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column FACT_100138_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column FACT_100138_MISS_FIRST.firstenter_succ
  is '��һ�ν���ؿ��ɹ���';
comment on column FACT_100138_MISS_FIRST.firstenter_fail
  is '��һ�ν���ؿ�ʧ����';
comment on column FACT_100138_MISS_FIRST.data_source
  is '������Դ';
create index IDX70_100138 on FACT_100138_MISS_FIRST (CHANNELID);
create index IDX71_100138 on FACT_100138_MISS_FIRST (SERVERID);
create index IDX72_100138 on FACT_100138_MISS_FIRST (STATDATE);

prompt
prompt Creating table FACT_100138_NET
prompt ==============================
prompt
create table FACT_100138_NET
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  dvid_net    VARCHAR2(50),
  conncount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_NET
  is '������ʽ������';
comment on column FACT_100138_NET.statdate
  is 'ͳ������';
comment on column FACT_100138_NET.channelid
  is '����';
comment on column FACT_100138_NET.serverid
  is '����';
comment on column FACT_100138_NET.appid
  is '��Ʒid';
comment on column FACT_100138_NET.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_NET.dvid_net
  is '������ʽ';
comment on column FACT_100138_NET.conncount
  is '������';
comment on column FACT_100138_NET.data_source
  is '������Դ';
create index IDX73_100138 on FACT_100138_NET (CHANNELID);
create index IDX74_100138 on FACT_100138_NET (SERVERID);
create index IDX75_100138 on FACT_100138_NET (STATDATE);

prompt
prompt Creating table FACT_100138_OPERATOR
prompt ===================================
prompt
create table FACT_100138_OPERATOR
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  dvid_operator VARCHAR2(50),
  conncount     NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100138_OPERATOR
  is '��Ӫ�̷�����';
comment on column FACT_100138_OPERATOR.statdate
  is 'ͳ������';
comment on column FACT_100138_OPERATOR.channelid
  is '����';
comment on column FACT_100138_OPERATOR.serverid
  is '����';
comment on column FACT_100138_OPERATOR.appid
  is '��Ʒid';
comment on column FACT_100138_OPERATOR.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_OPERATOR.dvid_operator
  is '������ʽ';
comment on column FACT_100138_OPERATOR.conncount
  is '������';
comment on column FACT_100138_OPERATOR.data_source
  is '������Դ';
create index IDX76_100138 on FACT_100138_OPERATOR (CHANNELID);
create index IDX77_100138 on FACT_100138_OPERATOR (SERVERID);
create index IDX78_100138 on FACT_100138_OPERATOR (STATDATE);

prompt
prompt Creating table FACT_100138_ORDER
prompt ================================
prompt
create table FACT_100138_ORDER
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100138_ORDER
  is '����������';
comment on column FACT_100138_ORDER.statdate
  is 'ͳ������';
comment on column FACT_100138_ORDER.channelid
  is '����';
comment on column FACT_100138_ORDER.serverid
  is '����';
comment on column FACT_100138_ORDER.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100138_ORDER.appid
  is '��Ʒid';
comment on column FACT_100138_ORDER.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_ORDER.paysucccount
  is '�ɹ�������';
comment on column FACT_100138_ORDER.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100138_ORDER.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100138_ORDER.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100138_ORDER.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100138_ORDER.payfailnum
  is '����ʧ������';
comment on column FACT_100138_ORDER.data_source
  is '������Դ';
create index IDX79_100138 on FACT_100138_ORDER (CHANNELID);
create index IDX80_100138 on FACT_100138_ORDER (SERVERID);
create index IDX81_100138 on FACT_100138_ORDER (STATDATE);

prompt
prompt Creating table FACT_100138_ORDER_HOUR
prompt =====================================
prompt
create table FACT_100138_ORDER_HOUR
(
  statdate      VARCHAR2(20),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100138_ORDER_HOUR
  is '����Сʱ������';
comment on column FACT_100138_ORDER_HOUR.statdate
  is 'ͳ������';
comment on column FACT_100138_ORDER_HOUR.channelid
  is '����';
comment on column FACT_100138_ORDER_HOUR.serverid
  is '����';
comment on column FACT_100138_ORDER_HOUR.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100138_ORDER_HOUR.appid
  is '��Ʒid';
comment on column FACT_100138_ORDER_HOUR.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_ORDER_HOUR.paysucccount
  is '�ɹ�������';
comment on column FACT_100138_ORDER_HOUR.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100138_ORDER_HOUR.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100138_ORDER_HOUR.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100138_ORDER_HOUR.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100138_ORDER_HOUR.payfailnum
  is '����ʧ������';
comment on column FACT_100138_ORDER_HOUR.data_source
  is '������Դ';
create index IDX177_100138 on FACT_100138_ORDER_HOUR (CHANNELID);
create index IDX178_100138 on FACT_100138_ORDER_HOUR (SERVERID);
create index IDX179_100138 on FACT_100138_ORDER_HOUR (STATDATE);

prompt
prompt Creating table FACT_100138_ORDER_MONTH
prompt ======================================
prompt
create table FACT_100138_ORDER_MONTH
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100138_ORDER_MONTH
  is '�¶���������';
comment on column FACT_100138_ORDER_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100138_ORDER_MONTH.channelid
  is '����';
comment on column FACT_100138_ORDER_MONTH.serverid
  is '����';
comment on column FACT_100138_ORDER_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100138_ORDER_MONTH.appid
  is '��Ʒid';
comment on column FACT_100138_ORDER_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_ORDER_MONTH.paysucccount
  is '�ɹ�������';
comment on column FACT_100138_ORDER_MONTH.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100138_ORDER_MONTH.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100138_ORDER_MONTH.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100138_ORDER_MONTH.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100138_ORDER_MONTH.payfailnum
  is '����ʧ������';
comment on column FACT_100138_ORDER_MONTH.data_source
  is '������Դ';
create index IDX191_100138 on FACT_100138_ORDER_MONTH (CHANNELID);
create index IDX192_100138 on FACT_100138_ORDER_MONTH (SERVERID);
create index IDX193_100138 on FACT_100138_ORDER_MONTH (STATDATE);

prompt
prompt Creating table FACT_100138_ORDER_WEEK
prompt =====================================
prompt
create table FACT_100138_ORDER_WEEK
(
  statdate      VARCHAR2(10),
  channelid     VARCHAR2(50),
  serverid      VARCHAR2(50),
  datatype      VARCHAR2(50),
  appid         VARCHAR2(50),
  versionid     VARCHAR2(50),
  paysucccount  NUMBER,
  payfailcount  NUMBER,
  paysuccamount NUMBER,
  payfailamount NUMBER,
  paysuccnum    NUMBER,
  payfailnum    NUMBER,
  loaddate      DATE default SYSDATE,
  data_source   VARCHAR2(100)
)
;
comment on table FACT_100138_ORDER_WEEK
  is '�ܶ���������';
comment on column FACT_100138_ORDER_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100138_ORDER_WEEK.channelid
  is '����';
comment on column FACT_100138_ORDER_WEEK.serverid
  is '����';
comment on column FACT_100138_ORDER_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100138_ORDER_WEEK.appid
  is '��Ʒid';
comment on column FACT_100138_ORDER_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_ORDER_WEEK.paysucccount
  is '�ɹ�������';
comment on column FACT_100138_ORDER_WEEK.payfailcount
  is 'ʧ�ܸ�����';
comment on column FACT_100138_ORDER_WEEK.paysuccamount
  is '�ɹ����ѽ��';
comment on column FACT_100138_ORDER_WEEK.payfailamount
  is 'ʧ�ܸ��ѽ��';
comment on column FACT_100138_ORDER_WEEK.paysuccnum
  is '�����ɹ�����';
comment on column FACT_100138_ORDER_WEEK.payfailnum
  is '����ʧ������';
comment on column FACT_100138_ORDER_WEEK.data_source
  is '������Դ';
create index IDX188_100138 on FACT_100138_ORDER_WEEK (CHANNELID);
create index IDX189_100138 on FACT_100138_ORDER_WEEK (SERVERID);
create index IDX190_100138 on FACT_100138_ORDER_WEEK (STATDATE);

prompt
prompt Creating table FACT_100138_PAYAMOUNT_DAY
prompt ========================================
prompt
create table FACT_100138_PAYAMOUNT_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_PAYAMOUNT_DAY
  is '�ճ�ֵ��������';
comment on column FACT_100138_PAYAMOUNT_DAY.statdate
  is 'ͳ������';
comment on column FACT_100138_PAYAMOUNT_DAY.channelid
  is '����';
comment on column FACT_100138_PAYAMOUNT_DAY.serverid
  is '����';
comment on column FACT_100138_PAYAMOUNT_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100138_PAYAMOUNT_DAY.appid
  is '��Ʒid';
comment on column FACT_100138_PAYAMOUNT_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_PAYAMOUNT_DAY.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100138_PAYAMOUNT_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100138_PAYAMOUNT_DAY.data_source
  is '������Դ';
create index IDX82_100138 on FACT_100138_PAYAMOUNT_DAY (CHANNELID);
create index IDX83_100138 on FACT_100138_PAYAMOUNT_DAY (SERVERID);
create index IDX84_100138 on FACT_100138_PAYAMOUNT_DAY (STATDATE);

prompt
prompt Creating table FACT_100138_PAYAMOUNT_MONTH
prompt ==========================================
prompt
create table FACT_100138_PAYAMOUNT_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_PAYAMOUNT_MONTH
  is '�³�ֵ��������';
comment on column FACT_100138_PAYAMOUNT_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100138_PAYAMOUNT_MONTH.channelid
  is '����';
comment on column FACT_100138_PAYAMOUNT_MONTH.serverid
  is '����';
comment on column FACT_100138_PAYAMOUNT_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100138_PAYAMOUNT_MONTH.appid
  is '��Ʒid';
comment on column FACT_100138_PAYAMOUNT_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_PAYAMOUNT_MONTH.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100138_PAYAMOUNT_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100138_PAYAMOUNT_MONTH.data_source
  is '������Դ';
create index IDX88_100138 on FACT_100138_PAYAMOUNT_MONTH (CHANNELID);
create index IDX89_100138 on FACT_100138_PAYAMOUNT_MONTH (SERVERID);
create index IDX90_100138 on FACT_100138_PAYAMOUNT_MONTH (STATDATE);

prompt
prompt Creating table FACT_100138_PAYAMOUNT_WEEK
prompt =========================================
prompt
create table FACT_100138_PAYAMOUNT_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_PAYAMOUNT_WEEK
  is '�ܳ�ֵ��������';
comment on column FACT_100138_PAYAMOUNT_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100138_PAYAMOUNT_WEEK.channelid
  is '����';
comment on column FACT_100138_PAYAMOUNT_WEEK.serverid
  is '����';
comment on column FACT_100138_PAYAMOUNT_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100138_PAYAMOUNT_WEEK.appid
  is '��Ʒid';
comment on column FACT_100138_PAYAMOUNT_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_PAYAMOUNT_WEEK.payamount
  is '��ֵ��ȡ����';
comment on column FACT_100138_PAYAMOUNT_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100138_PAYAMOUNT_WEEK.data_source
  is '������Դ';
create index IDX85_100138 on FACT_100138_PAYAMOUNT_WEEK (CHANNELID);
create index IDX86_100138 on FACT_100138_PAYAMOUNT_WEEK (SERVERID);
create index IDX87_100138 on FACT_100138_PAYAMOUNT_WEEK (STATDATE);

prompt
prompt Creating table FACT_100138_PAYNUM_DAY
prompt =====================================
prompt
create table FACT_100138_PAYNUM_DAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_PAYNUM_DAY
  is '�ճ�ֵ����������';
comment on column FACT_100138_PAYNUM_DAY.statdate
  is 'ͳ������';
comment on column FACT_100138_PAYNUM_DAY.channelid
  is '����';
comment on column FACT_100138_PAYNUM_DAY.serverid
  is '����';
comment on column FACT_100138_PAYNUM_DAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100138_PAYNUM_DAY.appid
  is '��Ʒid';
comment on column FACT_100138_PAYNUM_DAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_PAYNUM_DAY.paynum
  is '��ֵ����';
comment on column FACT_100138_PAYNUM_DAY.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100138_PAYNUM_DAY.data_source
  is '������Դ';
create index IDX97_100138 on FACT_100138_PAYNUM_DAY (CHANNELID);
create index IDX98_100138 on FACT_100138_PAYNUM_DAY (SERVERID);
create index IDX99_100138 on FACT_100138_PAYNUM_DAY (STATDATE);

prompt
prompt Creating table FACT_100138_PAYNUM_MONTH
prompt =======================================
prompt
create table FACT_100138_PAYNUM_MONTH
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_PAYNUM_MONTH
  is '�³�ֵ����������';
comment on column FACT_100138_PAYNUM_MONTH.statdate
  is 'ͳ������';
comment on column FACT_100138_PAYNUM_MONTH.channelid
  is '����';
comment on column FACT_100138_PAYNUM_MONTH.serverid
  is '����';
comment on column FACT_100138_PAYNUM_MONTH.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100138_PAYNUM_MONTH.appid
  is '��Ʒid';
comment on column FACT_100138_PAYNUM_MONTH.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_PAYNUM_MONTH.paynum
  is '��ֵ����';
comment on column FACT_100138_PAYNUM_MONTH.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100138_PAYNUM_MONTH.data_source
  is '������Դ';
create index IDX91_100138 on FACT_100138_PAYNUM_MONTH (CHANNELID);
create index IDX92_100138 on FACT_100138_PAYNUM_MONTH (SERVERID);
create index IDX93_100138 on FACT_100138_PAYNUM_MONTH (STATDATE);

prompt
prompt Creating table FACT_100138_PAYNUM_WEEK
prompt ======================================
prompt
create table FACT_100138_PAYNUM_WEEK
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paynum      NUMBER,
  paycount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_PAYNUM_WEEK
  is '�ܳ�ֵ����������';
comment on column FACT_100138_PAYNUM_WEEK.statdate
  is 'ͳ������';
comment on column FACT_100138_PAYNUM_WEEK.channelid
  is '����';
comment on column FACT_100138_PAYNUM_WEEK.serverid
  is '����';
comment on column FACT_100138_PAYNUM_WEEK.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100138_PAYNUM_WEEK.appid
  is '��Ʒid';
comment on column FACT_100138_PAYNUM_WEEK.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_PAYNUM_WEEK.paynum
  is '��ֵ����';
comment on column FACT_100138_PAYNUM_WEEK.paycount
  is '��ֵ�û������豸��';
comment on column FACT_100138_PAYNUM_WEEK.data_source
  is '������Դ';
create index IDX94_100138 on FACT_100138_PAYNUM_WEEK (CHANNELID);
create index IDX95_100138 on FACT_100138_PAYNUM_WEEK (SERVERID);
create index IDX96_100138 on FACT_100138_PAYNUM_WEEK (STATDATE);

prompt
prompt Creating table FACT_100138_PAYTYPE
prompt ==================================
prompt
create table FACT_100138_PAYTYPE
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paytypeid   VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_PAYTYPE
  is '��ֵ���ͷ�����';
comment on column FACT_100138_PAYTYPE.statdate
  is 'ͳ������';
comment on column FACT_100138_PAYTYPE.channelid
  is '����';
comment on column FACT_100138_PAYTYPE.serverid
  is '����';
comment on column FACT_100138_PAYTYPE.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100138_PAYTYPE.appid
  is '��Ʒid';
comment on column FACT_100138_PAYTYPE.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_PAYTYPE.paytypeid
  is '��ֵ����';
comment on column FACT_100138_PAYTYPE.payamount
  is '��ֵ���';
comment on column FACT_100138_PAYTYPE.paycount
  is '��ֵ����';
comment on column FACT_100138_PAYTYPE.paynum
  is '��ֵ����';
comment on column FACT_100138_PAYTYPE.data_source
  is '������Դ';
create index IDX100_100138 on FACT_100138_PAYTYPE (CHANNELID);
create index IDX101_100138 on FACT_100138_PAYTYPE (SERVERID);
create index IDX102_100138 on FACT_100138_PAYTYPE (STATDATE);

prompt
prompt Creating table FACT_100138_PAYWAY
prompt =================================
prompt
create table FACT_100138_PAYWAY
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  datatype    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  paywayid    VARCHAR2(50),
  payamount   NUMBER,
  paycount    NUMBER,
  paynum      NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_PAYWAY
  is '��ֵ��ʽ������';
comment on column FACT_100138_PAYWAY.statdate
  is 'ͳ������';
comment on column FACT_100138_PAYWAY.channelid
  is '����';
comment on column FACT_100138_PAYWAY.serverid
  is '����';
comment on column FACT_100138_PAYWAY.datatype
  is '���ͣ��û� 1���豸 2��';
comment on column FACT_100138_PAYWAY.appid
  is '��Ʒid';
comment on column FACT_100138_PAYWAY.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_PAYWAY.paywayid
  is '��ֵ��ʽ';
comment on column FACT_100138_PAYWAY.payamount
  is '��ֵ���';
comment on column FACT_100138_PAYWAY.paycount
  is '��ֵ����';
comment on column FACT_100138_PAYWAY.paynum
  is '��ֵ����';
comment on column FACT_100138_PAYWAY.data_source
  is '������Դ';
create index IDX103_100138 on FACT_100138_PAYWAY (CHANNELID);
create index IDX104_100138 on FACT_100138_PAYWAY (SERVERID);
create index IDX105_100138 on FACT_100138_PAYWAY (STATDATE);

prompt
prompt Creating table FACT_100138_REGION
prompt =================================
prompt
create table FACT_100138_REGION
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  country     VARCHAR2(50),
  province    VARCHAR2(50),
  city        VARCHAR2(50),
  newcount    NUMBER,
  conncount   NUMBER,
  paycount    NUMBER,
  payamount   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_REGION
  is '���������';
comment on column FACT_100138_REGION.statdate
  is 'ͳ������';
comment on column FACT_100138_REGION.channelid
  is '����';
comment on column FACT_100138_REGION.serverid
  is '����';
comment on column FACT_100138_REGION.appid
  is '��Ʒid';
comment on column FACT_100138_REGION.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_REGION.country
  is '����';
comment on column FACT_100138_REGION.province
  is 'ʡ';
comment on column FACT_100138_REGION.city
  is '��';
comment on column FACT_100138_REGION.newcount
  is '������';
comment on column FACT_100138_REGION.conncount
  is '������';
comment on column FACT_100138_REGION.paycount
  is '������';
comment on column FACT_100138_REGION.payamount
  is '���ѽ��';
comment on column FACT_100138_REGION.data_source
  is '������Դ';
create index IDX106_100138 on FACT_100138_REGION (CHANNELID);
create index IDX107_100138 on FACT_100138_REGION (SERVERID);
create index IDX108_100138 on FACT_100138_REGION (STATDATE);

prompt
prompt Creating table FACT_100138_REMAIN_MAC
prompt =====================================
prompt
create table FACT_100138_REMAIN_MAC
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_REMAIN_MAC
  is '�豸�����';
comment on column FACT_100138_REMAIN_MAC.statdate
  is 'ͳ������';
comment on column FACT_100138_REMAIN_MAC.conndate
  is '��������';
comment on column FACT_100138_REMAIN_MAC.channelid
  is '����ID';
comment on column FACT_100138_REMAIN_MAC.serverid
  is '����ID';
comment on column FACT_100138_REMAIN_MAC.appid
  is '��ƷID';
comment on column FACT_100138_REMAIN_MAC.remain_days
  is '��������';
comment on column FACT_100138_REMAIN_MAC.new_remain
  is '��������';
comment on column FACT_100138_REMAIN_MAC.conn_remain
  is '��������';
comment on column FACT_100138_REMAIN_MAC.pay_remain
  is '��������';
comment on column FACT_100138_REMAIN_MAC.data_source
  is '����Դ';
create index IDX109_100138 on FACT_100138_REMAIN_MAC (CHANNELID);
create index IDX110_100138 on FACT_100138_REMAIN_MAC (SERVERID);
create index IDX111_100138 on FACT_100138_REMAIN_MAC (STATDATE);

prompt
prompt Creating table FACT_100138_REMAIN_USER
prompt ======================================
prompt
create table FACT_100138_REMAIN_USER
(
  statdate    VARCHAR2(10),
  conndate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  remain_days NUMBER,
  new_remain  NUMBER,
  conn_remain NUMBER,
  pay_remain  NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_REMAIN_USER
  is '�û������';
comment on column FACT_100138_REMAIN_USER.statdate
  is 'ͳ������';
comment on column FACT_100138_REMAIN_USER.conndate
  is '��������';
comment on column FACT_100138_REMAIN_USER.channelid
  is '����ID';
comment on column FACT_100138_REMAIN_USER.serverid
  is '����ID';
comment on column FACT_100138_REMAIN_USER.appid
  is '��ƷID';
comment on column FACT_100138_REMAIN_USER.remain_days
  is '��������';
comment on column FACT_100138_REMAIN_USER.new_remain
  is '��������';
comment on column FACT_100138_REMAIN_USER.conn_remain
  is '��������';
comment on column FACT_100138_REMAIN_USER.pay_remain
  is '��������';
comment on column FACT_100138_REMAIN_USER.data_source
  is '����Դ';
create index IDX112_100138 on FACT_100138_REMAIN_USER (CHANNELID);
create index IDX113_100138 on FACT_100138_REMAIN_USER (SERVERID);
create index IDX114_100138 on FACT_100138_REMAIN_USER (STATDATE);

prompt
prompt Creating table FACT_100138_VC
prompt =============================
prompt
create table FACT_100138_VC
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcamount    NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table FACT_100138_VC
  is '������ҷ�����';
comment on column FACT_100138_VC.statdate
  is 'ͳ������';
comment on column FACT_100138_VC.channelid
  is '����';
comment on column FACT_100138_VC.serverid
  is '����';
comment on column FACT_100138_VC.appid
  is '��Ʒid';
comment on column FACT_100138_VC.versionid
  is '��Ʒ�汾';
comment on column FACT_100138_VC.vctype
  is '�����������';
comment on column FACT_100138_VC.vcusetype
  is '�������ʹ������';
comment on column FACT_100138_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column FACT_100138_VC.vcamount
  is '������ҽ��';
comment on column FACT_100138_VC.data_source
  is '������Դ';
create index IDX115_100138 on FACT_100138_VC (CHANNELID);
create index IDX116_100138 on FACT_100138_VC (SERVERID);
create index IDX117_100138 on FACT_100138_VC (STATDATE);


spool off
