------------------------------------------------------------
-- Export file for user DEVELOPER@BI_RACDB1_111.13.20.109 --
-- Created by Administrator on 2015/5/25, 18:28:40 ---------
------------------------------------------------------------

set define off
spool --��������T��2.log

prompt
prompt Creating table T_100169_CEVENT
prompt ==============================
prompt
create table T_100169_CEVENT
(
  thedate          VARCHAR2(10),
  datenum          NUMBER,
  appid            VARCHAR2(10),
  channelid        VARCHAR2(50),
  gameversion      VARCHAR2(50),
  dvid             VARCHAR2(50),
  accountid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  ilevel           NUMBER,
  roleid           VARCHAR2(50),
  eventkey         VARCHAR2(100),
  eventvalue_key   VARCHAR2(100),
  eventvalue_value VARCHAR2(100),
  ipaddr           VARCHAR2(50),
  prerowid         VARCHAR2(200)
)
;
comment on table T_100169_CEVENT
  is '�Զ����¼���ֱ�';
comment on column T_100169_CEVENT.thedate
  is '����';
comment on column T_100169_CEVENT.datenum
  is '�������ָ�ʽ';
comment on column T_100169_CEVENT.appid
  is '��Ϸ�� appid';
comment on column T_100169_CEVENT.channelid
  is '���� ID';
comment on column T_100169_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column T_100169_CEVENT.dvid
  is '�豸 ID��Ψһ�豸��';
comment on column T_100169_CEVENT.accountid
  is '�ʻ� id';
comment on column T_100169_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column T_100169_CEVENT.ilevel
  is '��ҵȼ�';
comment on column T_100169_CEVENT.roleid
  is '��ɫ id';
comment on column T_100169_CEVENT.eventkey
  is '�¼�����';
comment on column T_100169_CEVENT.eventvalue_key
  is '�¼�ֵ�е�key';
comment on column T_100169_CEVENT.eventvalue_value
  is '�¼�ֵ��key��Ӧ��ֵ';
comment on column T_100169_CEVENT.ipaddr
  is 'ip ��ַ';
comment on column T_100169_CEVENT.prerowid
  is 'ԭΨһ��ID';
create index IDX180_100169 on T_100169_CEVENT (THEDATE);

prompt
prompt Creating table T_100169_CONN
prompt ============================
prompt
create table T_100169_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100169_CONN
  is '����&��ʧ&������������������ע���˺ţ�ע���豸��';
comment on column T_100169_CONN.conndate
  is '����ʱ��';
comment on column T_100169_CONN.gameid
  is '��ϷID';
comment on column T_100169_CONN.channelid
  is '����ID';
comment on column T_100169_CONN.gameversion
  is '��Ϸ�汾';
comment on column T_100169_CONN.serverid
  is '����ID';
comment on column T_100169_CONN.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100169_CONN.position
  is 'λ����Ϣ';
comment on column T_100169_CONN.dvid
  is '�豸��';
comment on column T_100169_CONN.accountid
  is '�˺�ID';
comment on column T_100169_CONN.regdate
  is 'ע��ʱ��';
comment on column T_100169_CONN.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100169_CONN.regdate_as
  is '���з��������ע��ʱ��';
create index IDX118_100169 on T_100169_CONN (CHANNELID);
create index IDX119_100169 on T_100169_CONN (SERVERID);
create index IDX120_100169 on T_100169_CONN (CONNDATE);

prompt
prompt Creating table T_100169_CONN_ACT
prompt ================================
prompt
create table T_100169_CONN_ACT
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100169_CONN_ACT
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100169_CONN_ACT.basedate
  is '����ʱ��';
comment on column T_100169_CONN_ACT.gameid
  is '��ϷID';
comment on column T_100169_CONN_ACT.channelid
  is '����ID';
comment on column T_100169_CONN_ACT.gameversion
  is '��Ϸ�汾';
comment on column T_100169_CONN_ACT.serverid
  is '����ID';
comment on column T_100169_CONN_ACT.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100169_CONN_ACT.position
  is 'λ����Ϣ';
comment on column T_100169_CONN_ACT.dvid
  is '�豸��';
comment on column T_100169_CONN_ACT.accountid
  is '�˺�';
comment on column T_100169_CONN_ACT.conndate
  is '��Ծʱ��';
comment on column T_100169_CONN_ACT.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_100169 on T_100169_CONN_ACT (CHANNELID);
create index IDX122_100169 on T_100169_CONN_ACT (SERVERID);
create index IDX123_100169 on T_100169_CONN_ACT (CONNDATE);
create index IDX124_100169 on T_100169_CONN_ACT (BASEDATE);

prompt
prompt Creating table T_100169_CONN_ACT_AS
prompt ===================================
prompt
create table T_100169_CONN_ACT_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100169_CONN_ACT_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100169_CONN_ACT_AS.basedate
  is '����ʱ��';
comment on column T_100169_CONN_ACT_AS.gameid
  is '��ϷID';
comment on column T_100169_CONN_ACT_AS.channelid
  is '����ID';
comment on column T_100169_CONN_ACT_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100169_CONN_ACT_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100169_CONN_ACT_AS.position
  is 'λ����Ϣ';
comment on column T_100169_CONN_ACT_AS.dvid
  is '�豸��';
comment on column T_100169_CONN_ACT_AS.accountid
  is '�˺�';
comment on column T_100169_CONN_ACT_AS.conndate
  is '��Ծʱ��';
comment on column T_100169_CONN_ACT_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX205_100169 on T_100169_CONN_ACT_AS (CHANNELID);
create index IDX206_100169 on T_100169_CONN_ACT_AS (CONNDATE);
create index IDX207_100169 on T_100169_CONN_ACT_AS (BASEDATE);

prompt
prompt Creating table T_100169_CONN_ACT_MAC
prompt ====================================
prompt
create table T_100169_CONN_ACT_MAC
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100169_CONN_ACT_MAC
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100169_CONN_ACT_MAC.basedate
  is '����ʱ��';
comment on column T_100169_CONN_ACT_MAC.gameid
  is '��ϷID';
comment on column T_100169_CONN_ACT_MAC.channelid
  is '����ID';
comment on column T_100169_CONN_ACT_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100169_CONN_ACT_MAC.serverid
  is '����ID';
comment on column T_100169_CONN_ACT_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100169_CONN_ACT_MAC.position
  is 'λ����Ϣ';
comment on column T_100169_CONN_ACT_MAC.dvid
  is '�豸��';
comment on column T_100169_CONN_ACT_MAC.accountid
  is '�˺�';
comment on column T_100169_CONN_ACT_MAC.conndate
  is '��Ծʱ��';
comment on column T_100169_CONN_ACT_MAC.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_100169 on T_100169_CONN_ACT_MAC (CHANNELID);
create index IDX126_100169 on T_100169_CONN_ACT_MAC (SERVERID);
create index IDX127_100169 on T_100169_CONN_ACT_MAC (CONNDATE);
create index IDX128_100169 on T_100169_CONN_ACT_MAC (BASEDATE);

prompt
prompt Creating table T_100169_CONN_ACT_MAC_AS
prompt =======================================
prompt
create table T_100169_CONN_ACT_MAC_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100169_CONN_ACT_MAC_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100169_CONN_ACT_MAC_AS.basedate
  is '����ʱ��';
comment on column T_100169_CONN_ACT_MAC_AS.gameid
  is '��ϷID';
comment on column T_100169_CONN_ACT_MAC_AS.channelid
  is '����ID';
comment on column T_100169_CONN_ACT_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100169_CONN_ACT_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100169_CONN_ACT_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100169_CONN_ACT_MAC_AS.dvid
  is '�豸��';
comment on column T_100169_CONN_ACT_MAC_AS.accountid
  is '�˺�';
comment on column T_100169_CONN_ACT_MAC_AS.conndate
  is '��Ծʱ��';
comment on column T_100169_CONN_ACT_MAC_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX202_100169 on T_100169_CONN_ACT_MAC_AS (CHANNELID);
create index IDX203_100169 on T_100169_CONN_ACT_MAC_AS (CONNDATE);
create index IDX204_100169 on T_100169_CONN_ACT_MAC_AS (BASEDATE);

prompt
prompt Creating table T_100169_CONN_DVID
prompt =================================
prompt
create table T_100169_CONN_DVID
(
  conndate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  dvid      VARCHAR2(50),
  regdate   VARCHAR2(10)
)
;
comment on table T_100169_CONN_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100169_CONN_DVID.conndate
  is '����ʱ��';
comment on column T_100169_CONN_DVID.gameid
  is '��ϷID';
comment on column T_100169_CONN_DVID.channelid
  is '����ID';
comment on column T_100169_CONN_DVID.dvid
  is '�豸��';
comment on column T_100169_CONN_DVID.regdate
  is 'ע��ʱ��';
create index IDX129_100169 on T_100169_CONN_DVID (CHANNELID);
create index IDX130_100169 on T_100169_CONN_DVID (CONNDATE);

prompt
prompt Creating table T_100169_CONN_MAC
prompt ================================
prompt
create table T_100169_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100169_CONN_MAC
  is '���� ��ʧ ������������������ע���˺ţ�ע���豸��';
comment on column T_100169_CONN_MAC.conndate
  is '����ʱ��';
comment on column T_100169_CONN_MAC.gameid
  is '��ϷID';
comment on column T_100169_CONN_MAC.channelid
  is '����ID';
comment on column T_100169_CONN_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100169_CONN_MAC.serverid
  is '����ID';
comment on column T_100169_CONN_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100169_CONN_MAC.position
  is 'λ����Ϣ';
comment on column T_100169_CONN_MAC.dvid
  is '�豸��';
comment on column T_100169_CONN_MAC.accountid
  is '�˺�ID';
comment on column T_100169_CONN_MAC.regdate
  is 'ע��ʱ��';
comment on column T_100169_CONN_MAC.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100169_CONN_MAC.regdate_as
  is '���з��������ע��ʱ��';
create index IDX131_100169 on T_100169_CONN_MAC (CHANNELID);
create index IDX132_100169 on T_100169_CONN_MAC (SERVERID);
create index IDX133_100169 on T_100169_CONN_MAC (CONNDATE);

prompt
prompt Creating table T_100169_LOST_MAC
prompt ================================
prompt
create table T_100169_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100169_LOST_MAC
  is '�豸�ȼ���ʧ������';
comment on column T_100169_LOST_MAC.statdate
  is '�����������';
comment on column T_100169_LOST_MAC.lost_date
  is '��ʧ����';
comment on column T_100169_LOST_MAC.channelid
  is '����';
comment on column T_100169_LOST_MAC.serverid
  is '����';
comment on column T_100169_LOST_MAC.appid
  is '��Ʒid';
comment on column T_100169_LOST_MAC.macid
  is '�豸id';
comment on column T_100169_LOST_MAC.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100169_LOST_MAC.lost_days
  is '��ʧ����';
comment on column T_100169_LOST_MAC.data_source
  is '������Դ';
create index IDX134_100169 on T_100169_LOST_MAC (CHANNELID);
create index IDX135_100169 on T_100169_LOST_MAC (SERVERID);
create index IDX136_100169 on T_100169_LOST_MAC (STATDATE);

prompt
prompt Creating table T_100169_LOST_MAC_AS
prompt ===================================
prompt
create table T_100169_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100169_LOST_MAC_AS
  is '�豸�ȼ���ʧ������allserver';
comment on column T_100169_LOST_MAC_AS.statdate
  is '�����������';
comment on column T_100169_LOST_MAC_AS.lost_date
  is '��ʧ����';
comment on column T_100169_LOST_MAC_AS.channelid
  is '����';
comment on column T_100169_LOST_MAC_AS.appid
  is '��Ʒid';
comment on column T_100169_LOST_MAC_AS.macid
  is '�豸id';
comment on column T_100169_LOST_MAC_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100169_LOST_MAC_AS.lost_days
  is '��ʧ����';
comment on column T_100169_LOST_MAC_AS.data_source
  is '������Դ';
create index IDX210_100169 on T_100169_LOST_MAC_AS (CHANNELID);
create index IDX211_100169 on T_100169_LOST_MAC_AS (STATDATE);

prompt
prompt Creating table T_100169_LOST_USER
prompt =================================
prompt
create table T_100169_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100169_LOST_USER
  is '�û��ȼ���ʧ������';
comment on column T_100169_LOST_USER.statdate
  is '�����������';
comment on column T_100169_LOST_USER.lost_date
  is '��ʧ����';
comment on column T_100169_LOST_USER.channelid
  is '����';
comment on column T_100169_LOST_USER.serverid
  is '����';
comment on column T_100169_LOST_USER.appid
  is '��Ʒid';
comment on column T_100169_LOST_USER.userid
  is '�û�id';
comment on column T_100169_LOST_USER.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100169_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100169_LOST_USER.lost_days
  is '��ʧ����';
comment on column T_100169_LOST_USER.data_source
  is '������Դ';
create index IDX137_100169 on T_100169_LOST_USER (CHANNELID);
create index IDX138_100169 on T_100169_LOST_USER (SERVERID);
create index IDX139_100169 on T_100169_LOST_USER (STATDATE);

prompt
prompt Creating table T_100169_LOST_USER_AS
prompt ====================================
prompt
create table T_100169_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100169_LOST_USER_AS
  is '�û��ȼ���ʧ������allserver';
comment on column T_100169_LOST_USER_AS.statdate
  is '�����������';
comment on column T_100169_LOST_USER_AS.lost_date
  is '��ʧ����';
comment on column T_100169_LOST_USER_AS.channelid
  is '����';
comment on column T_100169_LOST_USER_AS.appid
  is '��Ʒid';
comment on column T_100169_LOST_USER_AS.userid
  is '�û�id';
comment on column T_100169_LOST_USER_AS.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100169_LOST_USER_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100169_LOST_USER_AS.lost_days
  is '��ʧ����';
comment on column T_100169_LOST_USER_AS.data_source
  is '������Դ';
create index IDX208_100169 on T_100169_LOST_USER_AS (CHANNELID);
create index IDX209_100169 on T_100169_LOST_USER_AS (STATDATE);

prompt
prompt Creating table T_100169_MISS_FIRST
prompt ==================================
prompt
create table T_100169_MISS_FIRST
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50) default '0',
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100169_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column T_100169_MISS_FIRST.statdate
  is 'ͳ������';
comment on column T_100169_MISS_FIRST.channelid
  is '����';
comment on column T_100169_MISS_FIRST.serverid
  is '����';
comment on column T_100169_MISS_FIRST.appid
  is '��ƷID';
comment on column T_100169_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column T_100169_MISS_FIRST.accountid
  is '�û�ID';
comment on column T_100169_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100169_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column T_100169_MISS_FIRST.issucc
  is '�Ƿ���ͨ��';
comment on column T_100169_MISS_FIRST.data_source
  is '������Դ';
create index IDX140_100169 on T_100169_MISS_FIRST (CHANNELID);
create index IDX141_100169 on T_100169_MISS_FIRST (SERVERID);
create index IDX142_100169 on T_100169_MISS_FIRST (STATDATE);

prompt
prompt Creating table T_100169_NU
prompt ==========================
prompt
create table T_100169_NU
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100169_NU
  is '�����û���Ϣ��';
comment on column T_100169_NU.thedate
  is '��������';
comment on column T_100169_NU.gameid
  is '��ϷID';
comment on column T_100169_NU.channelid
  is '����ID';
comment on column T_100169_NU.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100169_NU.serverid
  is '���ڷ�ID';
comment on column T_100169_NU.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100169_NU.position
  is '����λ��';
comment on column T_100169_NU.accountid
  is '�˺�ID';
create index IDX143_100169 on T_100169_NU (CHANNELID);
create index IDX144_100169 on T_100169_NU (SERVERID);
create index IDX145_100169 on T_100169_NU (THEDATE);

prompt
prompt Creating table T_100169_NU_ALLSERVER
prompt ====================================
prompt
create table T_100169_NU_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100169_NU_ALLSERVER
  is '�����û���Ϣ��ALLSERVER';
comment on column T_100169_NU_ALLSERVER.thedate
  is '��������';
comment on column T_100169_NU_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100169_NU_ALLSERVER.channelid
  is '����ID';
comment on column T_100169_NU_ALLSERVER.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100169_NU_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100169_NU_ALLSERVER.position
  is '����λ��';
comment on column T_100169_NU_ALLSERVER.accountid
  is '�˺�ID';
create index IDX194_100169 on T_100169_NU_ALLSERVER (CHANNELID);
create index IDX195_100169 on T_100169_NU_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100169_NU_DVID
prompt ===============================
prompt
create table T_100169_NU_DVID
(
  thedate   DATE not null,
  gameid    VARCHAR2(20) not null,
  channelid VARCHAR2(20) not null,
  dvid      VARCHAR2(50) not null,
  ipaddr    VARCHAR2(50)
)
;
comment on table T_100169_NU_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100169_NU_DVID.thedate
  is '����ʱ��';
comment on column T_100169_NU_DVID.gameid
  is '��ϷID';
comment on column T_100169_NU_DVID.channelid
  is '����ID';
comment on column T_100169_NU_DVID.dvid
  is '�豸ID';
comment on column T_100169_NU_DVID.ipaddr
  is 'IP';
create index IDX146_100169 on T_100169_NU_DVID (CHANNELID);
create index IDX147_100169 on T_100169_NU_DVID (THEDATE);

prompt
prompt Creating table T_100169_NU_MAC
prompt ==============================
prompt
create table T_100169_NU_MAC
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100169_NU_MAC
  is '�豸������';
comment on column T_100169_NU_MAC.thedate
  is '����ʱ��';
comment on column T_100169_NU_MAC.gameid
  is '��ϷID';
comment on column T_100169_NU_MAC.channelid
  is '����ID';
comment on column T_100169_NU_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100169_NU_MAC.serverid
  is '��������ID';
comment on column T_100169_NU_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100169_NU_MAC.position
  is 'λ����Ϣ';
comment on column T_100169_NU_MAC.dvid
  is '�豸ID';
create index IDX148_100169 on T_100169_NU_MAC (CHANNELID);
create index IDX149_100169 on T_100169_NU_MAC (SERVERID);
create index IDX150_100169 on T_100169_NU_MAC (THEDATE);

prompt
prompt Creating table T_100169_NU_MAC_ALLSERVER
prompt ========================================
prompt
create table T_100169_NU_MAC_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100169_NU_MAC_ALLSERVER
  is '�豸������ALLSERVER';
comment on column T_100169_NU_MAC_ALLSERVER.thedate
  is '����ʱ��';
comment on column T_100169_NU_MAC_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100169_NU_MAC_ALLSERVER.channelid
  is '����ID';
comment on column T_100169_NU_MAC_ALLSERVER.gameversion
  is '��Ϸ�汾';
comment on column T_100169_NU_MAC_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100169_NU_MAC_ALLSERVER.position
  is 'λ����Ϣ';
comment on column T_100169_NU_MAC_ALLSERVER.dvid
  is '�豸ID';
create index IDX196_100169 on T_100169_NU_MAC_ALLSERVER (CHANNELID);
create index IDX197_100169 on T_100169_NU_MAC_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100169_NU_PAY
prompt ==============================
prompt
create table T_100169_NU_PAY
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100169_NU_PAY
  is '�����û���';
comment on column T_100169_NU_PAY.thedate
  is '����ʱ��';
comment on column T_100169_NU_PAY.gameid
  is '��ϷID';
comment on column T_100169_NU_PAY.channelid
  is '����ID';
comment on column T_100169_NU_PAY.gameversion
  is '��Ϸ�汾';
comment on column T_100169_NU_PAY.serverid
  is '������Ϣ';
comment on column T_100169_NU_PAY.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100169_NU_PAY.position
  is 'λ����Ϣ';
comment on column T_100169_NU_PAY.accountid
  is '�˺�ID';
comment on column T_100169_NU_PAY.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100169_NU_PAY.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX151_100169 on T_100169_NU_PAY (CHANNELID);
create index IDX152_100169 on T_100169_NU_PAY (SERVERID);
create index IDX153_100169 on T_100169_NU_PAY (THEDATE);

prompt
prompt Creating table T_100169_NU_PAY_AS
prompt =================================
prompt
create table T_100169_NU_PAY_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100169_NU_PAY_AS
  is '�����û���allsever';
comment on column T_100169_NU_PAY_AS.thedate
  is '����ʱ��';
comment on column T_100169_NU_PAY_AS.gameid
  is '��ϷID';
comment on column T_100169_NU_PAY_AS.channelid
  is '����ID';
comment on column T_100169_NU_PAY_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100169_NU_PAY_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100169_NU_PAY_AS.position
  is 'λ����Ϣ';
comment on column T_100169_NU_PAY_AS.accountid
  is '�˺�ID';
comment on column T_100169_NU_PAY_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100169_NU_PAY_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX198_100169 on T_100169_NU_PAY_AS (CHANNELID);
create index IDX199_100169 on T_100169_NU_PAY_AS (THEDATE);

prompt
prompt Creating table T_100169_NU_PAY_MAC
prompt ==================================
prompt
create table T_100169_NU_PAY_MAC
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100169_NU_PAY_MAC
  is '�����û���';
comment on column T_100169_NU_PAY_MAC.thedate
  is '����ʱ��';
comment on column T_100169_NU_PAY_MAC.gameid
  is '��ϷID';
comment on column T_100169_NU_PAY_MAC.channelid
  is '����ID';
comment on column T_100169_NU_PAY_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100169_NU_PAY_MAC.serverid
  is '������Ϣ';
comment on column T_100169_NU_PAY_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100169_NU_PAY_MAC.position
  is 'λ����Ϣ';
comment on column T_100169_NU_PAY_MAC.dvid
  is '�豸ID';
comment on column T_100169_NU_PAY_MAC.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100169_NU_PAY_MAC.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX154_100169 on T_100169_NU_PAY_MAC (CHANNELID);
create index IDX155_100169 on T_100169_NU_PAY_MAC (SERVERID);
create index IDX156_100169 on T_100169_NU_PAY_MAC (THEDATE);

prompt
prompt Creating table T_100169_NU_PAY_MAC_AS
prompt =====================================
prompt
create table T_100169_NU_PAY_MAC_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100169_NU_PAY_MAC_AS
  is '�����û���ALLSERVER';
comment on column T_100169_NU_PAY_MAC_AS.thedate
  is '����ʱ��';
comment on column T_100169_NU_PAY_MAC_AS.gameid
  is '��ϷID';
comment on column T_100169_NU_PAY_MAC_AS.channelid
  is '����ID';
comment on column T_100169_NU_PAY_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100169_NU_PAY_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100169_NU_PAY_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100169_NU_PAY_MAC_AS.dvid
  is '�豸ID';
comment on column T_100169_NU_PAY_MAC_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100169_NU_PAY_MAC_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX200_100169 on T_100169_NU_PAY_MAC_AS (CHANNELID);
create index IDX201_100169 on T_100169_NU_PAY_MAC_AS (THEDATE);

prompt
prompt Creating table T_100169_ORDER_FAILURE
prompt =====================================
prompt
create table T_100169_ORDER_FAILURE
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100169_ORDER_FAILURE
  is '��ֵ�ɹ���¼��';
comment on column T_100169_ORDER_FAILURE.thedate
  is '��ֵʱ��';
comment on column T_100169_ORDER_FAILURE.gameid
  is '��ϷID';
comment on column T_100169_ORDER_FAILURE.channelid
  is '����ID';
comment on column T_100169_ORDER_FAILURE.gameversion
  is '��Ϸ�汾';
comment on column T_100169_ORDER_FAILURE.serverid
  is '��������';
comment on column T_100169_ORDER_FAILURE.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100169_ORDER_FAILURE.position
  is 'λ����Ϣ';
comment on column T_100169_ORDER_FAILURE.dvid
  is '�豸��';
comment on column T_100169_ORDER_FAILURE.accountid
  is '�˺�';
comment on column T_100169_ORDER_FAILURE.money
  is '��ֵ���';
comment on column T_100169_ORDER_FAILURE.vc
  is '��ֵ��õ����������';
comment on column T_100169_ORDER_FAILURE.orderid
  is '������';
comment on column T_100169_ORDER_FAILURE.paychannel
  is '֧������';
comment on column T_100169_ORDER_FAILURE.iapid
  is '��ֵ����  30  60';
create index IDX157_100169 on T_100169_ORDER_FAILURE (CHANNELID);
create index IDX158_100169 on T_100169_ORDER_FAILURE (SERVERID);
create index IDX159_100169 on T_100169_ORDER_FAILURE (THEDATE);

prompt
prompt Creating table T_100169_ORDER_SUCC
prompt ==================================
prompt
create table T_100169_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100169_ORDER_SUCC
  is '��ֵ�ɹ���¼��';
comment on column T_100169_ORDER_SUCC.thedate
  is '��ֵʱ��';
comment on column T_100169_ORDER_SUCC.gameid
  is '��ϷID';
comment on column T_100169_ORDER_SUCC.channelid
  is '����ID';
comment on column T_100169_ORDER_SUCC.gameversion
  is '��Ϸ�汾';
comment on column T_100169_ORDER_SUCC.serverid
  is '��������';
comment on column T_100169_ORDER_SUCC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100169_ORDER_SUCC.position
  is 'λ����Ϣ';
comment on column T_100169_ORDER_SUCC.dvid
  is '�豸��';
comment on column T_100169_ORDER_SUCC.accountid
  is '�˺�';
comment on column T_100169_ORDER_SUCC.money
  is '��ֵ���';
comment on column T_100169_ORDER_SUCC.vc
  is '��ֵ��õ����������';
comment on column T_100169_ORDER_SUCC.orderid
  is '������';
comment on column T_100169_ORDER_SUCC.paychannel
  is '֧������';
comment on column T_100169_ORDER_SUCC.iapid
  is '��ֵ����  30  60';
create index IDX160_100169 on T_100169_ORDER_SUCC (CHANNELID);
create index IDX161_100169 on T_100169_ORDER_SUCC (SERVERID);
create index IDX162_100169 on T_100169_ORDER_SUCC (THEDATE);

prompt
prompt Creating table T_100169_VC
prompt ==========================
prompt
create table T_100169_VC
(
  statdate    DATE,
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcchange    NUMBER,
  vcbefore    NUMBER,
  vcafter     NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100169_VC
  is '������ұ仯������';
comment on column T_100169_VC.statdate
  is 'ͳ������';
comment on column T_100169_VC.channelid
  is '����';
comment on column T_100169_VC.serverid
  is '����';
comment on column T_100169_VC.appid
  is '��Ʒid';
comment on column T_100169_VC.versionid
  is '��Ʒ�汾';
comment on column T_100169_VC.accountid
  is '�û�ID';
comment on column T_100169_VC.vctype
  is '�����������';
comment on column T_100169_VC.vcusetype
  is '�������ʹ������';
comment on column T_100169_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column T_100169_VC.vcchange
  is '������ұ仯���';
comment on column T_100169_VC.vcbefore
  is '������ұ仯ǰ���';
comment on column T_100169_VC.vcafter
  is '������ұ仯����';
comment on column T_100169_VC.data_source
  is '������Դ';
create index IDX163_100169 on T_100169_VC (CHANNELID);
create index IDX164_100169 on T_100169_VC (SERVERID);
create index IDX165_100169 on T_100169_VC (STATDATE);

prompt
prompt Creating table T_100172_CEVENT
prompt ==============================
prompt
create table T_100172_CEVENT
(
  thedate          VARCHAR2(10),
  datenum          NUMBER,
  appid            VARCHAR2(10),
  channelid        VARCHAR2(50),
  gameversion      VARCHAR2(50),
  dvid             VARCHAR2(50),
  accountid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  ilevel           NUMBER,
  roleid           VARCHAR2(50),
  eventkey         VARCHAR2(100),
  eventvalue_key   VARCHAR2(100),
  eventvalue_value VARCHAR2(100),
  ipaddr           VARCHAR2(50),
  prerowid         VARCHAR2(200)
)
;
comment on table T_100172_CEVENT
  is '�Զ����¼���ֱ�';
comment on column T_100172_CEVENT.thedate
  is '����';
comment on column T_100172_CEVENT.datenum
  is '�������ָ�ʽ';
comment on column T_100172_CEVENT.appid
  is '��Ϸ�� appid';
comment on column T_100172_CEVENT.channelid
  is '���� ID';
comment on column T_100172_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column T_100172_CEVENT.dvid
  is '�豸 ID��Ψһ�豸��';
comment on column T_100172_CEVENT.accountid
  is '�ʻ� id';
comment on column T_100172_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column T_100172_CEVENT.ilevel
  is '��ҵȼ�';
comment on column T_100172_CEVENT.roleid
  is '��ɫ id';
comment on column T_100172_CEVENT.eventkey
  is '�¼�����';
comment on column T_100172_CEVENT.eventvalue_key
  is '�¼�ֵ�е�key';
comment on column T_100172_CEVENT.eventvalue_value
  is '�¼�ֵ��key��Ӧ��ֵ';
comment on column T_100172_CEVENT.ipaddr
  is 'ip ��ַ';
comment on column T_100172_CEVENT.prerowid
  is 'ԭΨһ��ID';
create index IDX180_100172 on T_100172_CEVENT (THEDATE);

prompt
prompt Creating table T_100172_CONN
prompt ============================
prompt
create table T_100172_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100172_CONN
  is '����&��ʧ&������������������ע���˺ţ�ע���豸��';
comment on column T_100172_CONN.conndate
  is '����ʱ��';
comment on column T_100172_CONN.gameid
  is '��ϷID';
comment on column T_100172_CONN.channelid
  is '����ID';
comment on column T_100172_CONN.gameversion
  is '��Ϸ�汾';
comment on column T_100172_CONN.serverid
  is '����ID';
comment on column T_100172_CONN.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100172_CONN.position
  is 'λ����Ϣ';
comment on column T_100172_CONN.dvid
  is '�豸��';
comment on column T_100172_CONN.accountid
  is '�˺�ID';
comment on column T_100172_CONN.regdate
  is 'ע��ʱ��';
comment on column T_100172_CONN.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100172_CONN.regdate_as
  is '����ע��ʱ��';
create index IDX118_100172 on T_100172_CONN (CHANNELID);
create index IDX119_100172 on T_100172_CONN (SERVERID);
create index IDX120_100172 on T_100172_CONN (CONNDATE);

prompt
prompt Creating table T_100172_CONN_ACT
prompt ================================
prompt
create table T_100172_CONN_ACT
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100172_CONN_ACT
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100172_CONN_ACT.basedate
  is '����ʱ��';
comment on column T_100172_CONN_ACT.gameid
  is '��ϷID';
comment on column T_100172_CONN_ACT.channelid
  is '����ID';
comment on column T_100172_CONN_ACT.gameversion
  is '��Ϸ�汾';
comment on column T_100172_CONN_ACT.serverid
  is '����ID';
comment on column T_100172_CONN_ACT.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100172_CONN_ACT.position
  is 'λ����Ϣ';
comment on column T_100172_CONN_ACT.dvid
  is '�豸��';
comment on column T_100172_CONN_ACT.accountid
  is '�˺�';
comment on column T_100172_CONN_ACT.conndate
  is '��Ծʱ��';
comment on column T_100172_CONN_ACT.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_100172 on T_100172_CONN_ACT (CHANNELID);
create index IDX122_100172 on T_100172_CONN_ACT (SERVERID);
create index IDX123_100172 on T_100172_CONN_ACT (CONNDATE);
create index IDX124_100172 on T_100172_CONN_ACT (BASEDATE);

prompt
prompt Creating table T_100172_CONN_ACT_AS
prompt ===================================
prompt
create table T_100172_CONN_ACT_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100172_CONN_ACT_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100172_CONN_ACT_AS.basedate
  is '����ʱ��';
comment on column T_100172_CONN_ACT_AS.gameid
  is '��ϷID';
comment on column T_100172_CONN_ACT_AS.channelid
  is '����ID';
comment on column T_100172_CONN_ACT_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100172_CONN_ACT_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100172_CONN_ACT_AS.position
  is 'λ����Ϣ';
comment on column T_100172_CONN_ACT_AS.dvid
  is '�豸��';
comment on column T_100172_CONN_ACT_AS.accountid
  is '�˺�';
comment on column T_100172_CONN_ACT_AS.conndate
  is '��Ծʱ��';
comment on column T_100172_CONN_ACT_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX205_100172 on T_100172_CONN_ACT_AS (CHANNELID);
create index IDX206_100172 on T_100172_CONN_ACT_AS (CONNDATE);
create index IDX207_100172 on T_100172_CONN_ACT_AS (BASEDATE);

prompt
prompt Creating table T_100172_CONN_ACT_MAC
prompt ====================================
prompt
create table T_100172_CONN_ACT_MAC
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100172_CONN_ACT_MAC
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100172_CONN_ACT_MAC.basedate
  is '����ʱ��';
comment on column T_100172_CONN_ACT_MAC.gameid
  is '��ϷID';
comment on column T_100172_CONN_ACT_MAC.channelid
  is '����ID';
comment on column T_100172_CONN_ACT_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100172_CONN_ACT_MAC.serverid
  is '����ID';
comment on column T_100172_CONN_ACT_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100172_CONN_ACT_MAC.position
  is 'λ����Ϣ';
comment on column T_100172_CONN_ACT_MAC.dvid
  is '�豸��';
comment on column T_100172_CONN_ACT_MAC.accountid
  is '�˺�';
comment on column T_100172_CONN_ACT_MAC.conndate
  is '��Ծʱ��';
comment on column T_100172_CONN_ACT_MAC.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_100172 on T_100172_CONN_ACT_MAC (CHANNELID);
create index IDX126_100172 on T_100172_CONN_ACT_MAC (SERVERID);
create index IDX127_100172 on T_100172_CONN_ACT_MAC (CONNDATE);
create index IDX128_100172 on T_100172_CONN_ACT_MAC (BASEDATE);

prompt
prompt Creating table T_100172_CONN_ACT_MAC_AS
prompt =======================================
prompt
create table T_100172_CONN_ACT_MAC_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100172_CONN_ACT_MAC_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100172_CONN_ACT_MAC_AS.basedate
  is '����ʱ��';
comment on column T_100172_CONN_ACT_MAC_AS.gameid
  is '��ϷID';
comment on column T_100172_CONN_ACT_MAC_AS.channelid
  is '����ID';
comment on column T_100172_CONN_ACT_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100172_CONN_ACT_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100172_CONN_ACT_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100172_CONN_ACT_MAC_AS.dvid
  is '�豸��';
comment on column T_100172_CONN_ACT_MAC_AS.accountid
  is '�˺�';
comment on column T_100172_CONN_ACT_MAC_AS.conndate
  is '��Ծʱ��';
comment on column T_100172_CONN_ACT_MAC_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX202_100172 on T_100172_CONN_ACT_MAC_AS (CHANNELID);
create index IDX203_100172 on T_100172_CONN_ACT_MAC_AS (CONNDATE);
create index IDX204_100172 on T_100172_CONN_ACT_MAC_AS (BASEDATE);

prompt
prompt Creating table T_100172_CONN_DVID
prompt =================================
prompt
create table T_100172_CONN_DVID
(
  conndate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  dvid      VARCHAR2(50),
  regdate   VARCHAR2(10)
)
;
comment on table T_100172_CONN_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100172_CONN_DVID.conndate
  is '����ʱ��';
comment on column T_100172_CONN_DVID.gameid
  is '��ϷID';
comment on column T_100172_CONN_DVID.channelid
  is '����ID';
comment on column T_100172_CONN_DVID.dvid
  is '�豸��';
comment on column T_100172_CONN_DVID.regdate
  is 'ע��ʱ��';
create index IDX129_100172 on T_100172_CONN_DVID (CHANNELID);
create index IDX130_100172 on T_100172_CONN_DVID (CONNDATE);

prompt
prompt Creating table T_100172_CONN_MAC
prompt ================================
prompt
create table T_100172_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100172_CONN_MAC
  is '���� ��ʧ ������������������ע���˺ţ�ע���豸��';
comment on column T_100172_CONN_MAC.conndate
  is '����ʱ��';
comment on column T_100172_CONN_MAC.gameid
  is '��ϷID';
comment on column T_100172_CONN_MAC.channelid
  is '����ID';
comment on column T_100172_CONN_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100172_CONN_MAC.serverid
  is '����ID';
comment on column T_100172_CONN_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100172_CONN_MAC.position
  is 'λ����Ϣ';
comment on column T_100172_CONN_MAC.dvid
  is '�豸��';
comment on column T_100172_CONN_MAC.accountid
  is '�˺�ID';
comment on column T_100172_CONN_MAC.regdate
  is 'ע��ʱ��';
comment on column T_100172_CONN_MAC.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100172_CONN_MAC.regdate_as
  is '����ע��ʱ��';
create index IDX131_100172 on T_100172_CONN_MAC (CHANNELID);
create index IDX132_100172 on T_100172_CONN_MAC (SERVERID);
create index IDX133_100172 on T_100172_CONN_MAC (CONNDATE);

prompt
prompt Creating table T_100172_LOST_MAC
prompt ================================
prompt
create table T_100172_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100172_LOST_MAC
  is '�豸�ȼ���ʧ������';
comment on column T_100172_LOST_MAC.statdate
  is '�����������';
comment on column T_100172_LOST_MAC.lost_date
  is '��ʧ����';
comment on column T_100172_LOST_MAC.channelid
  is '����';
comment on column T_100172_LOST_MAC.serverid
  is '����';
comment on column T_100172_LOST_MAC.appid
  is '��Ʒid';
comment on column T_100172_LOST_MAC.macid
  is '�豸id';
comment on column T_100172_LOST_MAC.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100172_LOST_MAC.lost_days
  is '��ʧ����';
comment on column T_100172_LOST_MAC.data_source
  is '������Դ';
create index IDX134_100172 on T_100172_LOST_MAC (CHANNELID);
create index IDX135_100172 on T_100172_LOST_MAC (SERVERID);
create index IDX136_100172 on T_100172_LOST_MAC (STATDATE);

prompt
prompt Creating table T_100172_LOST_MAC_AS
prompt ===================================
prompt
create table T_100172_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table T_100172_LOST_MAC_AS
  is '�豸�ȼ���ʧ������allserver';
comment on column T_100172_LOST_MAC_AS.statdate
  is '�����������';
comment on column T_100172_LOST_MAC_AS.lost_date
  is '��ʧ����';
comment on column T_100172_LOST_MAC_AS.channelid
  is '����';
comment on column T_100172_LOST_MAC_AS.appid
  is '��Ʒid';
comment on column T_100172_LOST_MAC_AS.macid
  is '�豸id';
comment on column T_100172_LOST_MAC_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100172_LOST_MAC_AS.lost_days
  is '��ʧ����';
comment on column T_100172_LOST_MAC_AS.data_source
  is '������Դ';
create index IDX210_100172 on T_100172_LOST_MAC_AS (CHANNELID);
create index IDX211_100172 on T_100172_LOST_MAC_AS (STATDATE);

prompt
prompt Creating table T_100172_LOST_USER
prompt =================================
prompt
create table T_100172_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100172_LOST_USER
  is '�û��ȼ���ʧ������';
comment on column T_100172_LOST_USER.statdate
  is '�����������';
comment on column T_100172_LOST_USER.lost_date
  is '��ʧ����';
comment on column T_100172_LOST_USER.channelid
  is '����';
comment on column T_100172_LOST_USER.serverid
  is '����';
comment on column T_100172_LOST_USER.appid
  is '��Ʒid';
comment on column T_100172_LOST_USER.userid
  is '�û�id';
comment on column T_100172_LOST_USER.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100172_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100172_LOST_USER.lost_days
  is '��ʧ����';
comment on column T_100172_LOST_USER.data_source
  is '������Դ';
create index IDX137_100172 on T_100172_LOST_USER (CHANNELID);
create index IDX138_100172 on T_100172_LOST_USER (SERVERID);
create index IDX139_100172 on T_100172_LOST_USER (STATDATE);

prompt
prompt Creating table T_100172_LOST_USER_AS
prompt ====================================
prompt
create table T_100172_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table T_100172_LOST_USER_AS
  is '�û��ȼ���ʧ������allserver';
comment on column T_100172_LOST_USER_AS.statdate
  is '�����������';
comment on column T_100172_LOST_USER_AS.lost_date
  is '��ʧ����';
comment on column T_100172_LOST_USER_AS.channelid
  is '����';
comment on column T_100172_LOST_USER_AS.appid
  is '��Ʒid';
comment on column T_100172_LOST_USER_AS.userid
  is '�û�id';
comment on column T_100172_LOST_USER_AS.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100172_LOST_USER_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100172_LOST_USER_AS.lost_days
  is '��ʧ����';
comment on column T_100172_LOST_USER_AS.data_source
  is '������Դ';
create index IDX208_100172 on T_100172_LOST_USER_AS (CHANNELID);
create index IDX209_100172 on T_100172_LOST_USER_AS (STATDATE);

prompt
prompt Creating table T_100172_MISS_FIRST
prompt ==================================
prompt
create table T_100172_MISS_FIRST
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50) default '0',
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100172_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column T_100172_MISS_FIRST.statdate
  is 'ͳ������';
comment on column T_100172_MISS_FIRST.channelid
  is '����';
comment on column T_100172_MISS_FIRST.serverid
  is '����';
comment on column T_100172_MISS_FIRST.appid
  is '��ƷID';
comment on column T_100172_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column T_100172_MISS_FIRST.accountid
  is '�û�ID';
comment on column T_100172_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100172_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column T_100172_MISS_FIRST.issucc
  is '�Ƿ���ͨ��';
comment on column T_100172_MISS_FIRST.data_source
  is '������Դ';
create index IDX140_100172 on T_100172_MISS_FIRST (CHANNELID);
create index IDX141_100172 on T_100172_MISS_FIRST (SERVERID);
create index IDX142_100172 on T_100172_MISS_FIRST (STATDATE);

prompt
prompt Creating table T_100172_NU
prompt ==========================
prompt
create table T_100172_NU
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100172_NU
  is '�����û���Ϣ��';
comment on column T_100172_NU.thedate
  is '��������';
comment on column T_100172_NU.gameid
  is '��ϷID';
comment on column T_100172_NU.channelid
  is '����ID';
comment on column T_100172_NU.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100172_NU.serverid
  is '���ڷ�ID';
comment on column T_100172_NU.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100172_NU.position
  is '����λ��';
comment on column T_100172_NU.accountid
  is '�˺�ID';
create index IDX143_100172 on T_100172_NU (CHANNELID);
create index IDX144_100172 on T_100172_NU (SERVERID);
create index IDX145_100172 on T_100172_NU (THEDATE);

prompt
prompt Creating table T_100172_NU_ALLSERVER
prompt ====================================
prompt
create table T_100172_NU_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100172_NU_ALLSERVER
  is '�����û���Ϣ��ALLSERVER';
comment on column T_100172_NU_ALLSERVER.thedate
  is '��������';
comment on column T_100172_NU_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100172_NU_ALLSERVER.channelid
  is '����ID';
comment on column T_100172_NU_ALLSERVER.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100172_NU_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100172_NU_ALLSERVER.position
  is '����λ��';
comment on column T_100172_NU_ALLSERVER.accountid
  is '�˺�ID';
create index IDX194_100172 on T_100172_NU_ALLSERVER (CHANNELID);
create index IDX195_100172 on T_100172_NU_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100172_NU_DVID
prompt ===============================
prompt
create table T_100172_NU_DVID
(
  thedate   DATE not null,
  gameid    VARCHAR2(20) not null,
  channelid VARCHAR2(20) not null,
  dvid      VARCHAR2(50) not null,
  ipaddr    VARCHAR2(50)
)
;
comment on table T_100172_NU_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100172_NU_DVID.thedate
  is '����ʱ��';
comment on column T_100172_NU_DVID.gameid
  is '��ϷID';
comment on column T_100172_NU_DVID.channelid
  is '����ID';
comment on column T_100172_NU_DVID.dvid
  is '�豸ID';
comment on column T_100172_NU_DVID.ipaddr
  is 'IP';
create index IDX146_100172 on T_100172_NU_DVID (CHANNELID);
create index IDX147_100172 on T_100172_NU_DVID (THEDATE);

prompt
prompt Creating table T_100172_NU_MAC
prompt ==============================
prompt
create table T_100172_NU_MAC
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100172_NU_MAC
  is '�豸������';
comment on column T_100172_NU_MAC.thedate
  is '����ʱ��';
comment on column T_100172_NU_MAC.gameid
  is '��ϷID';
comment on column T_100172_NU_MAC.channelid
  is '����ID';
comment on column T_100172_NU_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100172_NU_MAC.serverid
  is '��������ID';
comment on column T_100172_NU_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100172_NU_MAC.position
  is 'λ����Ϣ';
comment on column T_100172_NU_MAC.dvid
  is '�豸ID';
create index IDX148_100172 on T_100172_NU_MAC (CHANNELID);
create index IDX149_100172 on T_100172_NU_MAC (SERVERID);
create index IDX150_100172 on T_100172_NU_MAC (THEDATE);

prompt
prompt Creating table T_100172_NU_MAC_ALLSERVER
prompt ========================================
prompt
create table T_100172_NU_MAC_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100172_NU_MAC_ALLSERVER
  is '�豸������ALLSERVER';
comment on column T_100172_NU_MAC_ALLSERVER.thedate
  is '����ʱ��';
comment on column T_100172_NU_MAC_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100172_NU_MAC_ALLSERVER.channelid
  is '����ID';
comment on column T_100172_NU_MAC_ALLSERVER.gameversion
  is '��Ϸ�汾';
comment on column T_100172_NU_MAC_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100172_NU_MAC_ALLSERVER.position
  is 'λ����Ϣ';
comment on column T_100172_NU_MAC_ALLSERVER.dvid
  is '�豸ID';
create index IDX196_100172 on T_100172_NU_MAC_ALLSERVER (CHANNELID);
create index IDX197_100172 on T_100172_NU_MAC_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100172_NU_PAY
prompt ==============================
prompt
create table T_100172_NU_PAY
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100172_NU_PAY
  is '�����û���';
comment on column T_100172_NU_PAY.thedate
  is '����ʱ��';
comment on column T_100172_NU_PAY.gameid
  is '��ϷID';
comment on column T_100172_NU_PAY.channelid
  is '����ID';
comment on column T_100172_NU_PAY.gameversion
  is '��Ϸ�汾';
comment on column T_100172_NU_PAY.serverid
  is '������Ϣ';
comment on column T_100172_NU_PAY.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100172_NU_PAY.position
  is 'λ����Ϣ';
comment on column T_100172_NU_PAY.accountid
  is '�˺�ID';
comment on column T_100172_NU_PAY.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100172_NU_PAY.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX151_100172 on T_100172_NU_PAY (CHANNELID);
create index IDX152_100172 on T_100172_NU_PAY (SERVERID);
create index IDX153_100172 on T_100172_NU_PAY (THEDATE);

prompt
prompt Creating table T_100172_NU_PAY_AS
prompt =================================
prompt
create table T_100172_NU_PAY_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100172_NU_PAY_AS
  is '�����û���allsever';
comment on column T_100172_NU_PAY_AS.thedate
  is '����ʱ��';
comment on column T_100172_NU_PAY_AS.gameid
  is '��ϷID';
comment on column T_100172_NU_PAY_AS.channelid
  is '����ID';
comment on column T_100172_NU_PAY_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100172_NU_PAY_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100172_NU_PAY_AS.position
  is 'λ����Ϣ';
comment on column T_100172_NU_PAY_AS.accountid
  is '�˺�ID';
comment on column T_100172_NU_PAY_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100172_NU_PAY_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX198_100172 on T_100172_NU_PAY_AS (CHANNELID);
create index IDX199_100172 on T_100172_NU_PAY_AS (THEDATE);

prompt
prompt Creating table T_100172_NU_PAY_MAC
prompt ==================================
prompt
create table T_100172_NU_PAY_MAC
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100172_NU_PAY_MAC
  is '�����û���';
comment on column T_100172_NU_PAY_MAC.thedate
  is '����ʱ��';
comment on column T_100172_NU_PAY_MAC.gameid
  is '��ϷID';
comment on column T_100172_NU_PAY_MAC.channelid
  is '����ID';
comment on column T_100172_NU_PAY_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100172_NU_PAY_MAC.serverid
  is '������Ϣ';
comment on column T_100172_NU_PAY_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100172_NU_PAY_MAC.position
  is 'λ����Ϣ';
comment on column T_100172_NU_PAY_MAC.dvid
  is '�豸ID';
comment on column T_100172_NU_PAY_MAC.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100172_NU_PAY_MAC.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX154_100172 on T_100172_NU_PAY_MAC (CHANNELID);
create index IDX155_100172 on T_100172_NU_PAY_MAC (SERVERID);
create index IDX156_100172 on T_100172_NU_PAY_MAC (THEDATE);

prompt
prompt Creating table T_100172_NU_PAY_MAC_AS
prompt =====================================
prompt
create table T_100172_NU_PAY_MAC_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100172_NU_PAY_MAC_AS
  is '�����û���ALLSERVER';
comment on column T_100172_NU_PAY_MAC_AS.thedate
  is '����ʱ��';
comment on column T_100172_NU_PAY_MAC_AS.gameid
  is '��ϷID';
comment on column T_100172_NU_PAY_MAC_AS.channelid
  is '����ID';
comment on column T_100172_NU_PAY_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100172_NU_PAY_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100172_NU_PAY_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100172_NU_PAY_MAC_AS.dvid
  is '�豸ID';
comment on column T_100172_NU_PAY_MAC_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100172_NU_PAY_MAC_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX200_100172 on T_100172_NU_PAY_MAC_AS (CHANNELID);
create index IDX201_100172 on T_100172_NU_PAY_MAC_AS (THEDATE);

prompt
prompt Creating table T_100172_ORDER_FAILURE
prompt =====================================
prompt
create table T_100172_ORDER_FAILURE
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100172_ORDER_FAILURE
  is '��ֵ�ɹ���¼��';
comment on column T_100172_ORDER_FAILURE.thedate
  is '��ֵʱ��';
comment on column T_100172_ORDER_FAILURE.gameid
  is '��ϷID';
comment on column T_100172_ORDER_FAILURE.channelid
  is '����ID';
comment on column T_100172_ORDER_FAILURE.gameversion
  is '��Ϸ�汾';
comment on column T_100172_ORDER_FAILURE.serverid
  is '��������';
comment on column T_100172_ORDER_FAILURE.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100172_ORDER_FAILURE.position
  is 'λ����Ϣ';
comment on column T_100172_ORDER_FAILURE.dvid
  is '�豸��';
comment on column T_100172_ORDER_FAILURE.accountid
  is '�˺�';
comment on column T_100172_ORDER_FAILURE.money
  is '��ֵ���';
comment on column T_100172_ORDER_FAILURE.vc
  is '��ֵ��õ����������';
comment on column T_100172_ORDER_FAILURE.orderid
  is '������';
comment on column T_100172_ORDER_FAILURE.paychannel
  is '֧������';
comment on column T_100172_ORDER_FAILURE.iapid
  is '��ֵ����  30  60';
create index IDX157_100172 on T_100172_ORDER_FAILURE (CHANNELID);
create index IDX158_100172 on T_100172_ORDER_FAILURE (SERVERID);
create index IDX159_100172 on T_100172_ORDER_FAILURE (THEDATE);

prompt
prompt Creating table T_100172_ORDER_SUCC
prompt ==================================
prompt
create table T_100172_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100172_ORDER_SUCC
  is '��ֵ�ɹ���¼��';
comment on column T_100172_ORDER_SUCC.thedate
  is '��ֵʱ��';
comment on column T_100172_ORDER_SUCC.gameid
  is '��ϷID';
comment on column T_100172_ORDER_SUCC.channelid
  is '����ID';
comment on column T_100172_ORDER_SUCC.gameversion
  is '��Ϸ�汾';
comment on column T_100172_ORDER_SUCC.serverid
  is '��������';
comment on column T_100172_ORDER_SUCC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100172_ORDER_SUCC.position
  is 'λ����Ϣ';
comment on column T_100172_ORDER_SUCC.dvid
  is '�豸��';
comment on column T_100172_ORDER_SUCC.accountid
  is '�˺�';
comment on column T_100172_ORDER_SUCC.money
  is '��ֵ���';
comment on column T_100172_ORDER_SUCC.vc
  is '��ֵ��õ����������';
comment on column T_100172_ORDER_SUCC.orderid
  is '������';
comment on column T_100172_ORDER_SUCC.paychannel
  is '֧������';
comment on column T_100172_ORDER_SUCC.iapid
  is '��ֵ����  30  60';
create index IDX160_100172 on T_100172_ORDER_SUCC (CHANNELID);
create index IDX161_100172 on T_100172_ORDER_SUCC (SERVERID);
create index IDX162_100172 on T_100172_ORDER_SUCC (THEDATE);

prompt
prompt Creating table T_100172_VC
prompt ==========================
prompt
create table T_100172_VC
(
  statdate    DATE,
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcchange    NUMBER,
  vcbefore    NUMBER,
  vcafter     NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100172_VC
  is '������ұ仯������';
comment on column T_100172_VC.statdate
  is 'ͳ������';
comment on column T_100172_VC.channelid
  is '����';
comment on column T_100172_VC.serverid
  is '����';
comment on column T_100172_VC.appid
  is '��Ʒid';
comment on column T_100172_VC.versionid
  is '��Ʒ�汾';
comment on column T_100172_VC.accountid
  is '�û�ID';
comment on column T_100172_VC.vctype
  is '�����������';
comment on column T_100172_VC.vcusetype
  is '�������ʹ������';
comment on column T_100172_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column T_100172_VC.vcchange
  is '������ұ仯���';
comment on column T_100172_VC.vcbefore
  is '������ұ仯ǰ���';
comment on column T_100172_VC.vcafter
  is '������ұ仯����';
comment on column T_100172_VC.data_source
  is '������Դ';
create index IDX163_100172 on T_100172_VC (CHANNELID);
create index IDX164_100172 on T_100172_VC (SERVERID);
create index IDX165_100172 on T_100172_VC (STATDATE);

prompt
prompt Creating table T_100173_CEVENT
prompt ==============================
prompt
create table T_100173_CEVENT
(
  thedate          VARCHAR2(10),
  datenum          NUMBER,
  appid            VARCHAR2(10),
  channelid        VARCHAR2(50),
  gameversion      VARCHAR2(50),
  dvid             VARCHAR2(50),
  accountid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  ilevel           NUMBER,
  roleid           VARCHAR2(50),
  eventkey         VARCHAR2(100),
  eventvalue_key   VARCHAR2(100),
  eventvalue_value VARCHAR2(100),
  ipaddr           VARCHAR2(50),
  prerowid         VARCHAR2(200)
)
;
comment on table T_100173_CEVENT
  is '�Զ����¼���ֱ�';
comment on column T_100173_CEVENT.thedate
  is '����';
comment on column T_100173_CEVENT.datenum
  is '�������ָ�ʽ';
comment on column T_100173_CEVENT.appid
  is '��Ϸ�� appid';
comment on column T_100173_CEVENT.channelid
  is '���� ID';
comment on column T_100173_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column T_100173_CEVENT.dvid
  is '�豸 ID��Ψһ�豸��';
comment on column T_100173_CEVENT.accountid
  is '�ʻ� id';
comment on column T_100173_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column T_100173_CEVENT.ilevel
  is '��ҵȼ�';
comment on column T_100173_CEVENT.roleid
  is '��ɫ id';
comment on column T_100173_CEVENT.eventkey
  is '�¼�����';
comment on column T_100173_CEVENT.eventvalue_key
  is '�¼�ֵ�е�key';
comment on column T_100173_CEVENT.eventvalue_value
  is '�¼�ֵ��key��Ӧ��ֵ';
comment on column T_100173_CEVENT.ipaddr
  is 'ip ��ַ';
comment on column T_100173_CEVENT.prerowid
  is 'ԭΨһ��ID';
create index IDX180_100173 on T_100173_CEVENT (THEDATE);

prompt
prompt Creating table T_100173_CONN
prompt ============================
prompt
create table T_100173_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100173_CONN
  is '����&��ʧ&������������������ע���˺ţ�ע���豸��';
comment on column T_100173_CONN.conndate
  is '����ʱ��';
comment on column T_100173_CONN.gameid
  is '��ϷID';
comment on column T_100173_CONN.channelid
  is '����ID';
comment on column T_100173_CONN.gameversion
  is '��Ϸ�汾';
comment on column T_100173_CONN.serverid
  is '����ID';
comment on column T_100173_CONN.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100173_CONN.position
  is 'λ����Ϣ';
comment on column T_100173_CONN.dvid
  is '�豸��';
comment on column T_100173_CONN.accountid
  is '�˺�ID';
comment on column T_100173_CONN.regdate
  is 'ע��ʱ��';
comment on column T_100173_CONN.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100173_CONN.regdate_as
  is '����ע��ʱ��';
create index IDX118_100173 on T_100173_CONN (CHANNELID);
create index IDX119_100173 on T_100173_CONN (SERVERID);
create index IDX120_100173 on T_100173_CONN (CONNDATE);

prompt
prompt Creating table T_100173_CONN_ACT
prompt ================================
prompt
create table T_100173_CONN_ACT
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100173_CONN_ACT
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100173_CONN_ACT.basedate
  is '����ʱ��';
comment on column T_100173_CONN_ACT.gameid
  is '��ϷID';
comment on column T_100173_CONN_ACT.channelid
  is '����ID';
comment on column T_100173_CONN_ACT.gameversion
  is '��Ϸ�汾';
comment on column T_100173_CONN_ACT.serverid
  is '����ID';
comment on column T_100173_CONN_ACT.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100173_CONN_ACT.position
  is 'λ����Ϣ';
comment on column T_100173_CONN_ACT.dvid
  is '�豸��';
comment on column T_100173_CONN_ACT.accountid
  is '�˺�';
comment on column T_100173_CONN_ACT.conndate
  is '��Ծʱ��';
comment on column T_100173_CONN_ACT.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_100173 on T_100173_CONN_ACT (CHANNELID);
create index IDX122_100173 on T_100173_CONN_ACT (SERVERID);
create index IDX123_100173 on T_100173_CONN_ACT (CONNDATE);
create index IDX124_100173 on T_100173_CONN_ACT (BASEDATE);

prompt
prompt Creating table T_100173_CONN_ACT_AS
prompt ===================================
prompt
create table T_100173_CONN_ACT_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100173_CONN_ACT_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100173_CONN_ACT_AS.basedate
  is '����ʱ��';
comment on column T_100173_CONN_ACT_AS.gameid
  is '��ϷID';
comment on column T_100173_CONN_ACT_AS.channelid
  is '����ID';
comment on column T_100173_CONN_ACT_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100173_CONN_ACT_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100173_CONN_ACT_AS.position
  is 'λ����Ϣ';
comment on column T_100173_CONN_ACT_AS.dvid
  is '�豸��';
comment on column T_100173_CONN_ACT_AS.accountid
  is '�˺�';
comment on column T_100173_CONN_ACT_AS.conndate
  is '��Ծʱ��';
comment on column T_100173_CONN_ACT_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX205_100173 on T_100173_CONN_ACT_AS (CHANNELID);
create index IDX206_100173 on T_100173_CONN_ACT_AS (CONNDATE);
create index IDX207_100173 on T_100173_CONN_ACT_AS (BASEDATE);

prompt
prompt Creating table T_100173_CONN_ACT_MAC
prompt ====================================
prompt
create table T_100173_CONN_ACT_MAC
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100173_CONN_ACT_MAC
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100173_CONN_ACT_MAC.basedate
  is '����ʱ��';
comment on column T_100173_CONN_ACT_MAC.gameid
  is '��ϷID';
comment on column T_100173_CONN_ACT_MAC.channelid
  is '����ID';
comment on column T_100173_CONN_ACT_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100173_CONN_ACT_MAC.serverid
  is '����ID';
comment on column T_100173_CONN_ACT_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100173_CONN_ACT_MAC.position
  is 'λ����Ϣ';
comment on column T_100173_CONN_ACT_MAC.dvid
  is '�豸��';
comment on column T_100173_CONN_ACT_MAC.accountid
  is '�˺�';
comment on column T_100173_CONN_ACT_MAC.conndate
  is '��Ծʱ��';
comment on column T_100173_CONN_ACT_MAC.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_100173 on T_100173_CONN_ACT_MAC (CHANNELID);
create index IDX126_100173 on T_100173_CONN_ACT_MAC (SERVERID);
create index IDX127_100173 on T_100173_CONN_ACT_MAC (CONNDATE);
create index IDX128_100173 on T_100173_CONN_ACT_MAC (BASEDATE);

prompt
prompt Creating table T_100173_CONN_ACT_MAC_AS
prompt =======================================
prompt
create table T_100173_CONN_ACT_MAC_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100173_CONN_ACT_MAC_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100173_CONN_ACT_MAC_AS.basedate
  is '����ʱ��';
comment on column T_100173_CONN_ACT_MAC_AS.gameid
  is '��ϷID';
comment on column T_100173_CONN_ACT_MAC_AS.channelid
  is '����ID';
comment on column T_100173_CONN_ACT_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100173_CONN_ACT_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100173_CONN_ACT_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100173_CONN_ACT_MAC_AS.dvid
  is '�豸��';
comment on column T_100173_CONN_ACT_MAC_AS.accountid
  is '�˺�';
comment on column T_100173_CONN_ACT_MAC_AS.conndate
  is '��Ծʱ��';
comment on column T_100173_CONN_ACT_MAC_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX202_100173 on T_100173_CONN_ACT_MAC_AS (CHANNELID);
create index IDX203_100173 on T_100173_CONN_ACT_MAC_AS (CONNDATE);
create index IDX204_100173 on T_100173_CONN_ACT_MAC_AS (BASEDATE);

prompt
prompt Creating table T_100173_CONN_DVID
prompt =================================
prompt
create table T_100173_CONN_DVID
(
  conndate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  dvid      VARCHAR2(50),
  regdate   VARCHAR2(10)
)
;
comment on table T_100173_CONN_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100173_CONN_DVID.conndate
  is '����ʱ��';
comment on column T_100173_CONN_DVID.gameid
  is '��ϷID';
comment on column T_100173_CONN_DVID.channelid
  is '����ID';
comment on column T_100173_CONN_DVID.dvid
  is '�豸��';
comment on column T_100173_CONN_DVID.regdate
  is 'ע��ʱ��';
create index IDX129_100173 on T_100173_CONN_DVID (CHANNELID);
create index IDX130_100173 on T_100173_CONN_DVID (CONNDATE);

prompt
prompt Creating table T_100173_CONN_MAC
prompt ================================
prompt
create table T_100173_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100173_CONN_MAC
  is '���� ��ʧ ������������������ע���˺ţ�ע���豸��';
comment on column T_100173_CONN_MAC.conndate
  is '����ʱ��';
comment on column T_100173_CONN_MAC.gameid
  is '��ϷID';
comment on column T_100173_CONN_MAC.channelid
  is '����ID';
comment on column T_100173_CONN_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100173_CONN_MAC.serverid
  is '����ID';
comment on column T_100173_CONN_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100173_CONN_MAC.position
  is 'λ����Ϣ';
comment on column T_100173_CONN_MAC.dvid
  is '�豸��';
comment on column T_100173_CONN_MAC.accountid
  is '�˺�ID';
comment on column T_100173_CONN_MAC.regdate
  is 'ע��ʱ��';
comment on column T_100173_CONN_MAC.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100173_CONN_MAC.regdate_as
  is '����ע��ʱ��';
create index IDX131_100173 on T_100173_CONN_MAC (CHANNELID);
create index IDX132_100173 on T_100173_CONN_MAC (SERVERID);
create index IDX133_100173 on T_100173_CONN_MAC (CONNDATE);

prompt
prompt Creating table T_100173_LOST_MAC
prompt ================================
prompt
create table T_100173_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100173_LOST_MAC
  is '�豸�ȼ���ʧ������';
comment on column T_100173_LOST_MAC.statdate
  is '�����������';
comment on column T_100173_LOST_MAC.lost_date
  is '��ʧ����';
comment on column T_100173_LOST_MAC.channelid
  is '����';
comment on column T_100173_LOST_MAC.serverid
  is '����';
comment on column T_100173_LOST_MAC.appid
  is '��Ʒid';
comment on column T_100173_LOST_MAC.macid
  is '�豸id';
comment on column T_100173_LOST_MAC.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100173_LOST_MAC.lost_days
  is '��ʧ����';
comment on column T_100173_LOST_MAC.data_source
  is '������Դ';
create index IDX134_100173 on T_100173_LOST_MAC (CHANNELID);
create index IDX135_100173 on T_100173_LOST_MAC (SERVERID);
create index IDX136_100173 on T_100173_LOST_MAC (STATDATE);

prompt
prompt Creating table T_100173_LOST_MAC_AS
prompt ===================================
prompt
create table T_100173_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table T_100173_LOST_MAC_AS
  is '�豸�ȼ���ʧ������allserver';
comment on column T_100173_LOST_MAC_AS.statdate
  is '�����������';
comment on column T_100173_LOST_MAC_AS.lost_date
  is '��ʧ����';
comment on column T_100173_LOST_MAC_AS.channelid
  is '����';
comment on column T_100173_LOST_MAC_AS.appid
  is '��Ʒid';
comment on column T_100173_LOST_MAC_AS.macid
  is '�豸id';
comment on column T_100173_LOST_MAC_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100173_LOST_MAC_AS.lost_days
  is '��ʧ����';
comment on column T_100173_LOST_MAC_AS.data_source
  is '������Դ';
create index IDX210_100173 on T_100173_LOST_MAC_AS (CHANNELID);
create index IDX211_100173 on T_100173_LOST_MAC_AS (STATDATE);

prompt
prompt Creating table T_100173_LOST_USER
prompt =================================
prompt
create table T_100173_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100173_LOST_USER
  is '�û��ȼ���ʧ������';
comment on column T_100173_LOST_USER.statdate
  is '�����������';
comment on column T_100173_LOST_USER.lost_date
  is '��ʧ����';
comment on column T_100173_LOST_USER.channelid
  is '����';
comment on column T_100173_LOST_USER.serverid
  is '����';
comment on column T_100173_LOST_USER.appid
  is '��Ʒid';
comment on column T_100173_LOST_USER.userid
  is '�û�id';
comment on column T_100173_LOST_USER.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100173_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100173_LOST_USER.lost_days
  is '��ʧ����';
comment on column T_100173_LOST_USER.data_source
  is '������Դ';
create index IDX137_100173 on T_100173_LOST_USER (CHANNELID);
create index IDX138_100173 on T_100173_LOST_USER (SERVERID);
create index IDX139_100173 on T_100173_LOST_USER (STATDATE);

prompt
prompt Creating table T_100173_LOST_USER_AS
prompt ====================================
prompt
create table T_100173_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table T_100173_LOST_USER_AS
  is '�û��ȼ���ʧ������allserver';
comment on column T_100173_LOST_USER_AS.statdate
  is '�����������';
comment on column T_100173_LOST_USER_AS.lost_date
  is '��ʧ����';
comment on column T_100173_LOST_USER_AS.channelid
  is '����';
comment on column T_100173_LOST_USER_AS.appid
  is '��Ʒid';
comment on column T_100173_LOST_USER_AS.userid
  is '�û�id';
comment on column T_100173_LOST_USER_AS.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100173_LOST_USER_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100173_LOST_USER_AS.lost_days
  is '��ʧ����';
comment on column T_100173_LOST_USER_AS.data_source
  is '������Դ';
create index IDX208_100173 on T_100173_LOST_USER_AS (CHANNELID);
create index IDX209_100173 on T_100173_LOST_USER_AS (STATDATE);

prompt
prompt Creating table T_100173_MISS_FIRST
prompt ==================================
prompt
create table T_100173_MISS_FIRST
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50) default '0',
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100173_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column T_100173_MISS_FIRST.statdate
  is 'ͳ������';
comment on column T_100173_MISS_FIRST.channelid
  is '����';
comment on column T_100173_MISS_FIRST.serverid
  is '����';
comment on column T_100173_MISS_FIRST.appid
  is '��ƷID';
comment on column T_100173_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column T_100173_MISS_FIRST.accountid
  is '�û�ID';
comment on column T_100173_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100173_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column T_100173_MISS_FIRST.issucc
  is '�Ƿ���ͨ��';
comment on column T_100173_MISS_FIRST.data_source
  is '������Դ';
create index IDX140_100173 on T_100173_MISS_FIRST (CHANNELID);
create index IDX141_100173 on T_100173_MISS_FIRST (SERVERID);
create index IDX142_100173 on T_100173_MISS_FIRST (STATDATE);

prompt
prompt Creating table T_100173_NU
prompt ==========================
prompt
create table T_100173_NU
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100173_NU
  is '�����û���Ϣ��';
comment on column T_100173_NU.thedate
  is '��������';
comment on column T_100173_NU.gameid
  is '��ϷID';
comment on column T_100173_NU.channelid
  is '����ID';
comment on column T_100173_NU.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100173_NU.serverid
  is '���ڷ�ID';
comment on column T_100173_NU.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100173_NU.position
  is '����λ��';
comment on column T_100173_NU.accountid
  is '�˺�ID';
create index IDX143_100173 on T_100173_NU (CHANNELID);
create index IDX144_100173 on T_100173_NU (SERVERID);
create index IDX145_100173 on T_100173_NU (THEDATE);

prompt
prompt Creating table T_100173_NU_ALLSERVER
prompt ====================================
prompt
create table T_100173_NU_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100173_NU_ALLSERVER
  is '�����û���Ϣ��ALLSERVER';
comment on column T_100173_NU_ALLSERVER.thedate
  is '��������';
comment on column T_100173_NU_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100173_NU_ALLSERVER.channelid
  is '����ID';
comment on column T_100173_NU_ALLSERVER.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100173_NU_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100173_NU_ALLSERVER.position
  is '����λ��';
comment on column T_100173_NU_ALLSERVER.accountid
  is '�˺�ID';
create index IDX194_100173 on T_100173_NU_ALLSERVER (CHANNELID);
create index IDX195_100173 on T_100173_NU_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100173_NU_DVID
prompt ===============================
prompt
create table T_100173_NU_DVID
(
  thedate   DATE not null,
  gameid    VARCHAR2(20) not null,
  channelid VARCHAR2(20) not null,
  dvid      VARCHAR2(50) not null,
  ipaddr    VARCHAR2(50)
)
;
comment on table T_100173_NU_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100173_NU_DVID.thedate
  is '����ʱ��';
comment on column T_100173_NU_DVID.gameid
  is '��ϷID';
comment on column T_100173_NU_DVID.channelid
  is '����ID';
comment on column T_100173_NU_DVID.dvid
  is '�豸ID';
comment on column T_100173_NU_DVID.ipaddr
  is 'IP';
create index IDX146_100173 on T_100173_NU_DVID (CHANNELID);
create index IDX147_100173 on T_100173_NU_DVID (THEDATE);

prompt
prompt Creating table T_100173_NU_MAC
prompt ==============================
prompt
create table T_100173_NU_MAC
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100173_NU_MAC
  is '�豸������';
comment on column T_100173_NU_MAC.thedate
  is '����ʱ��';
comment on column T_100173_NU_MAC.gameid
  is '��ϷID';
comment on column T_100173_NU_MAC.channelid
  is '����ID';
comment on column T_100173_NU_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100173_NU_MAC.serverid
  is '��������ID';
comment on column T_100173_NU_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100173_NU_MAC.position
  is 'λ����Ϣ';
comment on column T_100173_NU_MAC.dvid
  is '�豸ID';
create index IDX148_100173 on T_100173_NU_MAC (CHANNELID);
create index IDX149_100173 on T_100173_NU_MAC (SERVERID);
create index IDX150_100173 on T_100173_NU_MAC (THEDATE);

prompt
prompt Creating table T_100173_NU_MAC_ALLSERVER
prompt ========================================
prompt
create table T_100173_NU_MAC_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100173_NU_MAC_ALLSERVER
  is '�豸������ALLSERVER';
comment on column T_100173_NU_MAC_ALLSERVER.thedate
  is '����ʱ��';
comment on column T_100173_NU_MAC_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100173_NU_MAC_ALLSERVER.channelid
  is '����ID';
comment on column T_100173_NU_MAC_ALLSERVER.gameversion
  is '��Ϸ�汾';
comment on column T_100173_NU_MAC_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100173_NU_MAC_ALLSERVER.position
  is 'λ����Ϣ';
comment on column T_100173_NU_MAC_ALLSERVER.dvid
  is '�豸ID';
create index IDX196_100173 on T_100173_NU_MAC_ALLSERVER (CHANNELID);
create index IDX197_100173 on T_100173_NU_MAC_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100173_NU_PAY
prompt ==============================
prompt
create table T_100173_NU_PAY
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100173_NU_PAY
  is '�����û���';
comment on column T_100173_NU_PAY.thedate
  is '����ʱ��';
comment on column T_100173_NU_PAY.gameid
  is '��ϷID';
comment on column T_100173_NU_PAY.channelid
  is '����ID';
comment on column T_100173_NU_PAY.gameversion
  is '��Ϸ�汾';
comment on column T_100173_NU_PAY.serverid
  is '������Ϣ';
comment on column T_100173_NU_PAY.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100173_NU_PAY.position
  is 'λ����Ϣ';
comment on column T_100173_NU_PAY.accountid
  is '�˺�ID';
comment on column T_100173_NU_PAY.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100173_NU_PAY.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX151_100173 on T_100173_NU_PAY (CHANNELID);
create index IDX152_100173 on T_100173_NU_PAY (SERVERID);
create index IDX153_100173 on T_100173_NU_PAY (THEDATE);

prompt
prompt Creating table T_100173_NU_PAY_AS
prompt =================================
prompt
create table T_100173_NU_PAY_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100173_NU_PAY_AS
  is '�����û���allsever';
comment on column T_100173_NU_PAY_AS.thedate
  is '����ʱ��';
comment on column T_100173_NU_PAY_AS.gameid
  is '��ϷID';
comment on column T_100173_NU_PAY_AS.channelid
  is '����ID';
comment on column T_100173_NU_PAY_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100173_NU_PAY_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100173_NU_PAY_AS.position
  is 'λ����Ϣ';
comment on column T_100173_NU_PAY_AS.accountid
  is '�˺�ID';
comment on column T_100173_NU_PAY_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100173_NU_PAY_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX198_100173 on T_100173_NU_PAY_AS (CHANNELID);
create index IDX199_100173 on T_100173_NU_PAY_AS (THEDATE);

prompt
prompt Creating table T_100173_NU_PAY_MAC
prompt ==================================
prompt
create table T_100173_NU_PAY_MAC
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100173_NU_PAY_MAC
  is '�����û���';
comment on column T_100173_NU_PAY_MAC.thedate
  is '����ʱ��';
comment on column T_100173_NU_PAY_MAC.gameid
  is '��ϷID';
comment on column T_100173_NU_PAY_MAC.channelid
  is '����ID';
comment on column T_100173_NU_PAY_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100173_NU_PAY_MAC.serverid
  is '������Ϣ';
comment on column T_100173_NU_PAY_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100173_NU_PAY_MAC.position
  is 'λ����Ϣ';
comment on column T_100173_NU_PAY_MAC.dvid
  is '�豸ID';
comment on column T_100173_NU_PAY_MAC.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100173_NU_PAY_MAC.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX154_100173 on T_100173_NU_PAY_MAC (CHANNELID);
create index IDX155_100173 on T_100173_NU_PAY_MAC (SERVERID);
create index IDX156_100173 on T_100173_NU_PAY_MAC (THEDATE);

prompt
prompt Creating table T_100173_NU_PAY_MAC_AS
prompt =====================================
prompt
create table T_100173_NU_PAY_MAC_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100173_NU_PAY_MAC_AS
  is '�����û���ALLSERVER';
comment on column T_100173_NU_PAY_MAC_AS.thedate
  is '����ʱ��';
comment on column T_100173_NU_PAY_MAC_AS.gameid
  is '��ϷID';
comment on column T_100173_NU_PAY_MAC_AS.channelid
  is '����ID';
comment on column T_100173_NU_PAY_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100173_NU_PAY_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100173_NU_PAY_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100173_NU_PAY_MAC_AS.dvid
  is '�豸ID';
comment on column T_100173_NU_PAY_MAC_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100173_NU_PAY_MAC_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX200_100173 on T_100173_NU_PAY_MAC_AS (CHANNELID);
create index IDX201_100173 on T_100173_NU_PAY_MAC_AS (THEDATE);

prompt
prompt Creating table T_100173_ORDER_FAILURE
prompt =====================================
prompt
create table T_100173_ORDER_FAILURE
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100173_ORDER_FAILURE
  is '��ֵ�ɹ���¼��';
comment on column T_100173_ORDER_FAILURE.thedate
  is '��ֵʱ��';
comment on column T_100173_ORDER_FAILURE.gameid
  is '��ϷID';
comment on column T_100173_ORDER_FAILURE.channelid
  is '����ID';
comment on column T_100173_ORDER_FAILURE.gameversion
  is '��Ϸ�汾';
comment on column T_100173_ORDER_FAILURE.serverid
  is '��������';
comment on column T_100173_ORDER_FAILURE.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100173_ORDER_FAILURE.position
  is 'λ����Ϣ';
comment on column T_100173_ORDER_FAILURE.dvid
  is '�豸��';
comment on column T_100173_ORDER_FAILURE.accountid
  is '�˺�';
comment on column T_100173_ORDER_FAILURE.money
  is '��ֵ���';
comment on column T_100173_ORDER_FAILURE.vc
  is '��ֵ��õ����������';
comment on column T_100173_ORDER_FAILURE.orderid
  is '������';
comment on column T_100173_ORDER_FAILURE.paychannel
  is '֧������';
comment on column T_100173_ORDER_FAILURE.iapid
  is '��ֵ����  30  60';
create index IDX157_100173 on T_100173_ORDER_FAILURE (CHANNELID);
create index IDX158_100173 on T_100173_ORDER_FAILURE (SERVERID);
create index IDX159_100173 on T_100173_ORDER_FAILURE (THEDATE);

prompt
prompt Creating table T_100173_ORDER_SUCC
prompt ==================================
prompt
create table T_100173_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100173_ORDER_SUCC
  is '��ֵ�ɹ���¼��';
comment on column T_100173_ORDER_SUCC.thedate
  is '��ֵʱ��';
comment on column T_100173_ORDER_SUCC.gameid
  is '��ϷID';
comment on column T_100173_ORDER_SUCC.channelid
  is '����ID';
comment on column T_100173_ORDER_SUCC.gameversion
  is '��Ϸ�汾';
comment on column T_100173_ORDER_SUCC.serverid
  is '��������';
comment on column T_100173_ORDER_SUCC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100173_ORDER_SUCC.position
  is 'λ����Ϣ';
comment on column T_100173_ORDER_SUCC.dvid
  is '�豸��';
comment on column T_100173_ORDER_SUCC.accountid
  is '�˺�';
comment on column T_100173_ORDER_SUCC.money
  is '��ֵ���';
comment on column T_100173_ORDER_SUCC.vc
  is '��ֵ��õ����������';
comment on column T_100173_ORDER_SUCC.orderid
  is '������';
comment on column T_100173_ORDER_SUCC.paychannel
  is '֧������';
comment on column T_100173_ORDER_SUCC.iapid
  is '��ֵ����  30  60';
create index IDX160_100173 on T_100173_ORDER_SUCC (CHANNELID);
create index IDX161_100173 on T_100173_ORDER_SUCC (SERVERID);
create index IDX162_100173 on T_100173_ORDER_SUCC (THEDATE);

prompt
prompt Creating table T_100173_VC
prompt ==========================
prompt
create table T_100173_VC
(
  statdate    DATE,
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcchange    NUMBER,
  vcbefore    NUMBER,
  vcafter     NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100173_VC
  is '������ұ仯������';
comment on column T_100173_VC.statdate
  is 'ͳ������';
comment on column T_100173_VC.channelid
  is '����';
comment on column T_100173_VC.serverid
  is '����';
comment on column T_100173_VC.appid
  is '��Ʒid';
comment on column T_100173_VC.versionid
  is '��Ʒ�汾';
comment on column T_100173_VC.accountid
  is '�û�ID';
comment on column T_100173_VC.vctype
  is '�����������';
comment on column T_100173_VC.vcusetype
  is '�������ʹ������';
comment on column T_100173_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column T_100173_VC.vcchange
  is '������ұ仯���';
comment on column T_100173_VC.vcbefore
  is '������ұ仯ǰ���';
comment on column T_100173_VC.vcafter
  is '������ұ仯����';
comment on column T_100173_VC.data_source
  is '������Դ';
create index IDX163_100173 on T_100173_VC (CHANNELID);
create index IDX164_100173 on T_100173_VC (SERVERID);
create index IDX165_100173 on T_100173_VC (STATDATE);

prompt
prompt Creating table T_100174_CEVENT
prompt ==============================
prompt
create table T_100174_CEVENT
(
  thedate          VARCHAR2(10),
  datenum          NUMBER,
  appid            VARCHAR2(10),
  channelid        VARCHAR2(50),
  gameversion      VARCHAR2(50),
  dvid             VARCHAR2(50),
  accountid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  ilevel           NUMBER,
  roleid           VARCHAR2(50),
  eventkey         VARCHAR2(100),
  eventvalue_key   VARCHAR2(100),
  eventvalue_value VARCHAR2(100),
  ipaddr           VARCHAR2(50),
  prerowid         VARCHAR2(200)
)
;
comment on table T_100174_CEVENT
  is '�Զ����¼���ֱ�';
comment on column T_100174_CEVENT.thedate
  is '����';
comment on column T_100174_CEVENT.datenum
  is '�������ָ�ʽ';
comment on column T_100174_CEVENT.appid
  is '��Ϸ�� appid';
comment on column T_100174_CEVENT.channelid
  is '���� ID';
comment on column T_100174_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column T_100174_CEVENT.dvid
  is '�豸 ID��Ψһ�豸��';
comment on column T_100174_CEVENT.accountid
  is '�ʻ� id';
comment on column T_100174_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column T_100174_CEVENT.ilevel
  is '��ҵȼ�';
comment on column T_100174_CEVENT.roleid
  is '��ɫ id';
comment on column T_100174_CEVENT.eventkey
  is '�¼�����';
comment on column T_100174_CEVENT.eventvalue_key
  is '�¼�ֵ�е�key';
comment on column T_100174_CEVENT.eventvalue_value
  is '�¼�ֵ��key��Ӧ��ֵ';
comment on column T_100174_CEVENT.ipaddr
  is 'ip ��ַ';
comment on column T_100174_CEVENT.prerowid
  is 'ԭΨһ��ID';
create index IDX180_100174 on T_100174_CEVENT (THEDATE);

prompt
prompt Creating table T_100174_CONN
prompt ============================
prompt
create table T_100174_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100174_CONN
  is '����&��ʧ&������������������ע���˺ţ�ע���豸��';
comment on column T_100174_CONN.conndate
  is '����ʱ��';
comment on column T_100174_CONN.gameid
  is '��ϷID';
comment on column T_100174_CONN.channelid
  is '����ID';
comment on column T_100174_CONN.gameversion
  is '��Ϸ�汾';
comment on column T_100174_CONN.serverid
  is '����ID';
comment on column T_100174_CONN.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100174_CONN.position
  is 'λ����Ϣ';
comment on column T_100174_CONN.dvid
  is '�豸��';
comment on column T_100174_CONN.accountid
  is '�˺�ID';
comment on column T_100174_CONN.regdate
  is 'ע��ʱ��';
comment on column T_100174_CONN.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100174_CONN.regdate_as
  is '����ע��ʱ��';
create index IDX118_100174 on T_100174_CONN (CHANNELID);
create index IDX119_100174 on T_100174_CONN (SERVERID);
create index IDX120_100174 on T_100174_CONN (CONNDATE);

prompt
prompt Creating table T_100174_CONN_ACT
prompt ================================
prompt
create table T_100174_CONN_ACT
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100174_CONN_ACT
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100174_CONN_ACT.basedate
  is '����ʱ��';
comment on column T_100174_CONN_ACT.gameid
  is '��ϷID';
comment on column T_100174_CONN_ACT.channelid
  is '����ID';
comment on column T_100174_CONN_ACT.gameversion
  is '��Ϸ�汾';
comment on column T_100174_CONN_ACT.serverid
  is '����ID';
comment on column T_100174_CONN_ACT.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100174_CONN_ACT.position
  is 'λ����Ϣ';
comment on column T_100174_CONN_ACT.dvid
  is '�豸��';
comment on column T_100174_CONN_ACT.accountid
  is '�˺�';
comment on column T_100174_CONN_ACT.conndate
  is '��Ծʱ��';
comment on column T_100174_CONN_ACT.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_100174 on T_100174_CONN_ACT (CHANNELID);
create index IDX122_100174 on T_100174_CONN_ACT (SERVERID);
create index IDX123_100174 on T_100174_CONN_ACT (CONNDATE);
create index IDX124_100174 on T_100174_CONN_ACT (BASEDATE);

prompt
prompt Creating table T_100174_CONN_ACT_AS
prompt ===================================
prompt
create table T_100174_CONN_ACT_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100174_CONN_ACT_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100174_CONN_ACT_AS.basedate
  is '����ʱ��';
comment on column T_100174_CONN_ACT_AS.gameid
  is '��ϷID';
comment on column T_100174_CONN_ACT_AS.channelid
  is '����ID';
comment on column T_100174_CONN_ACT_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100174_CONN_ACT_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100174_CONN_ACT_AS.position
  is 'λ����Ϣ';
comment on column T_100174_CONN_ACT_AS.dvid
  is '�豸��';
comment on column T_100174_CONN_ACT_AS.accountid
  is '�˺�';
comment on column T_100174_CONN_ACT_AS.conndate
  is '��Ծʱ��';
comment on column T_100174_CONN_ACT_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX205_100174 on T_100174_CONN_ACT_AS (CHANNELID);
create index IDX206_100174 on T_100174_CONN_ACT_AS (CONNDATE);
create index IDX207_100174 on T_100174_CONN_ACT_AS (BASEDATE);

prompt
prompt Creating table T_100174_CONN_ACT_MAC
prompt ====================================
prompt
create table T_100174_CONN_ACT_MAC
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100174_CONN_ACT_MAC
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100174_CONN_ACT_MAC.basedate
  is '����ʱ��';
comment on column T_100174_CONN_ACT_MAC.gameid
  is '��ϷID';
comment on column T_100174_CONN_ACT_MAC.channelid
  is '����ID';
comment on column T_100174_CONN_ACT_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100174_CONN_ACT_MAC.serverid
  is '����ID';
comment on column T_100174_CONN_ACT_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100174_CONN_ACT_MAC.position
  is 'λ����Ϣ';
comment on column T_100174_CONN_ACT_MAC.dvid
  is '�豸��';
comment on column T_100174_CONN_ACT_MAC.accountid
  is '�˺�';
comment on column T_100174_CONN_ACT_MAC.conndate
  is '��Ծʱ��';
comment on column T_100174_CONN_ACT_MAC.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_100174 on T_100174_CONN_ACT_MAC (CHANNELID);
create index IDX126_100174 on T_100174_CONN_ACT_MAC (SERVERID);
create index IDX127_100174 on T_100174_CONN_ACT_MAC (CONNDATE);
create index IDX128_100174 on T_100174_CONN_ACT_MAC (BASEDATE);

prompt
prompt Creating table T_100174_CONN_ACT_MAC_AS
prompt =======================================
prompt
create table T_100174_CONN_ACT_MAC_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100174_CONN_ACT_MAC_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100174_CONN_ACT_MAC_AS.basedate
  is '����ʱ��';
comment on column T_100174_CONN_ACT_MAC_AS.gameid
  is '��ϷID';
comment on column T_100174_CONN_ACT_MAC_AS.channelid
  is '����ID';
comment on column T_100174_CONN_ACT_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100174_CONN_ACT_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100174_CONN_ACT_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100174_CONN_ACT_MAC_AS.dvid
  is '�豸��';
comment on column T_100174_CONN_ACT_MAC_AS.accountid
  is '�˺�';
comment on column T_100174_CONN_ACT_MAC_AS.conndate
  is '��Ծʱ��';
comment on column T_100174_CONN_ACT_MAC_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX202_100174 on T_100174_CONN_ACT_MAC_AS (CHANNELID);
create index IDX203_100174 on T_100174_CONN_ACT_MAC_AS (CONNDATE);
create index IDX204_100174 on T_100174_CONN_ACT_MAC_AS (BASEDATE);

prompt
prompt Creating table T_100174_CONN_DVID
prompt =================================
prompt
create table T_100174_CONN_DVID
(
  conndate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  dvid      VARCHAR2(50),
  regdate   VARCHAR2(10)
)
;
comment on table T_100174_CONN_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100174_CONN_DVID.conndate
  is '����ʱ��';
comment on column T_100174_CONN_DVID.gameid
  is '��ϷID';
comment on column T_100174_CONN_DVID.channelid
  is '����ID';
comment on column T_100174_CONN_DVID.dvid
  is '�豸��';
comment on column T_100174_CONN_DVID.regdate
  is 'ע��ʱ��';
create index IDX129_100174 on T_100174_CONN_DVID (CHANNELID);
create index IDX130_100174 on T_100174_CONN_DVID (CONNDATE);

prompt
prompt Creating table T_100174_CONN_MAC
prompt ================================
prompt
create table T_100174_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100174_CONN_MAC
  is '���� ��ʧ ������������������ע���˺ţ�ע���豸��';
comment on column T_100174_CONN_MAC.conndate
  is '����ʱ��';
comment on column T_100174_CONN_MAC.gameid
  is '��ϷID';
comment on column T_100174_CONN_MAC.channelid
  is '����ID';
comment on column T_100174_CONN_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100174_CONN_MAC.serverid
  is '����ID';
comment on column T_100174_CONN_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100174_CONN_MAC.position
  is 'λ����Ϣ';
comment on column T_100174_CONN_MAC.dvid
  is '�豸��';
comment on column T_100174_CONN_MAC.accountid
  is '�˺�ID';
comment on column T_100174_CONN_MAC.regdate
  is 'ע��ʱ��';
comment on column T_100174_CONN_MAC.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100174_CONN_MAC.regdate_as
  is '����ע��ʱ��';
create index IDX131_100174 on T_100174_CONN_MAC (CHANNELID);
create index IDX132_100174 on T_100174_CONN_MAC (SERVERID);
create index IDX133_100174 on T_100174_CONN_MAC (CONNDATE);

prompt
prompt Creating table T_100174_LOST_MAC
prompt ================================
prompt
create table T_100174_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100174_LOST_MAC
  is '�豸�ȼ���ʧ������';
comment on column T_100174_LOST_MAC.statdate
  is '�����������';
comment on column T_100174_LOST_MAC.lost_date
  is '��ʧ����';
comment on column T_100174_LOST_MAC.channelid
  is '����';
comment on column T_100174_LOST_MAC.serverid
  is '����';
comment on column T_100174_LOST_MAC.appid
  is '��Ʒid';
comment on column T_100174_LOST_MAC.macid
  is '�豸id';
comment on column T_100174_LOST_MAC.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100174_LOST_MAC.lost_days
  is '��ʧ����';
comment on column T_100174_LOST_MAC.data_source
  is '������Դ';
create index IDX134_100174 on T_100174_LOST_MAC (CHANNELID);
create index IDX135_100174 on T_100174_LOST_MAC (SERVERID);
create index IDX136_100174 on T_100174_LOST_MAC (STATDATE);

prompt
prompt Creating table T_100174_LOST_MAC_AS
prompt ===================================
prompt
create table T_100174_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table T_100174_LOST_MAC_AS
  is '�豸�ȼ���ʧ������allserver';
comment on column T_100174_LOST_MAC_AS.statdate
  is '�����������';
comment on column T_100174_LOST_MAC_AS.lost_date
  is '��ʧ����';
comment on column T_100174_LOST_MAC_AS.channelid
  is '����';
comment on column T_100174_LOST_MAC_AS.appid
  is '��Ʒid';
comment on column T_100174_LOST_MAC_AS.macid
  is '�豸id';
comment on column T_100174_LOST_MAC_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100174_LOST_MAC_AS.lost_days
  is '��ʧ����';
comment on column T_100174_LOST_MAC_AS.data_source
  is '������Դ';
create index IDX210_100174 on T_100174_LOST_MAC_AS (CHANNELID);
create index IDX211_100174 on T_100174_LOST_MAC_AS (STATDATE);

prompt
prompt Creating table T_100174_LOST_USER
prompt =================================
prompt
create table T_100174_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100174_LOST_USER
  is '�û��ȼ���ʧ������';
comment on column T_100174_LOST_USER.statdate
  is '�����������';
comment on column T_100174_LOST_USER.lost_date
  is '��ʧ����';
comment on column T_100174_LOST_USER.channelid
  is '����';
comment on column T_100174_LOST_USER.serverid
  is '����';
comment on column T_100174_LOST_USER.appid
  is '��Ʒid';
comment on column T_100174_LOST_USER.userid
  is '�û�id';
comment on column T_100174_LOST_USER.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100174_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100174_LOST_USER.lost_days
  is '��ʧ����';
comment on column T_100174_LOST_USER.data_source
  is '������Դ';
create index IDX137_100174 on T_100174_LOST_USER (CHANNELID);
create index IDX138_100174 on T_100174_LOST_USER (SERVERID);
create index IDX139_100174 on T_100174_LOST_USER (STATDATE);

prompt
prompt Creating table T_100174_LOST_USER_AS
prompt ====================================
prompt
create table T_100174_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table T_100174_LOST_USER_AS
  is '�û��ȼ���ʧ������allserver';
comment on column T_100174_LOST_USER_AS.statdate
  is '�����������';
comment on column T_100174_LOST_USER_AS.lost_date
  is '��ʧ����';
comment on column T_100174_LOST_USER_AS.channelid
  is '����';
comment on column T_100174_LOST_USER_AS.appid
  is '��Ʒid';
comment on column T_100174_LOST_USER_AS.userid
  is '�û�id';
comment on column T_100174_LOST_USER_AS.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100174_LOST_USER_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100174_LOST_USER_AS.lost_days
  is '��ʧ����';
comment on column T_100174_LOST_USER_AS.data_source
  is '������Դ';
create index IDX208_100174 on T_100174_LOST_USER_AS (CHANNELID);
create index IDX209_100174 on T_100174_LOST_USER_AS (STATDATE);

prompt
prompt Creating table T_100174_MISS_FIRST
prompt ==================================
prompt
create table T_100174_MISS_FIRST
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50) default '0',
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100174_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column T_100174_MISS_FIRST.statdate
  is 'ͳ������';
comment on column T_100174_MISS_FIRST.channelid
  is '����';
comment on column T_100174_MISS_FIRST.serverid
  is '����';
comment on column T_100174_MISS_FIRST.appid
  is '��ƷID';
comment on column T_100174_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column T_100174_MISS_FIRST.accountid
  is '�û�ID';
comment on column T_100174_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100174_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column T_100174_MISS_FIRST.issucc
  is '�Ƿ���ͨ��';
comment on column T_100174_MISS_FIRST.data_source
  is '������Դ';
create index IDX140_100174 on T_100174_MISS_FIRST (CHANNELID);
create index IDX141_100174 on T_100174_MISS_FIRST (SERVERID);
create index IDX142_100174 on T_100174_MISS_FIRST (STATDATE);

prompt
prompt Creating table T_100174_NU
prompt ==========================
prompt
create table T_100174_NU
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100174_NU
  is '�����û���Ϣ��';
comment on column T_100174_NU.thedate
  is '��������';
comment on column T_100174_NU.gameid
  is '��ϷID';
comment on column T_100174_NU.channelid
  is '����ID';
comment on column T_100174_NU.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100174_NU.serverid
  is '���ڷ�ID';
comment on column T_100174_NU.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100174_NU.position
  is '����λ��';
comment on column T_100174_NU.accountid
  is '�˺�ID';
create index IDX143_100174 on T_100174_NU (CHANNELID);
create index IDX144_100174 on T_100174_NU (SERVERID);
create index IDX145_100174 on T_100174_NU (THEDATE);

prompt
prompt Creating table T_100174_NU_ALLSERVER
prompt ====================================
prompt
create table T_100174_NU_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100174_NU_ALLSERVER
  is '�����û���Ϣ��ALLSERVER';
comment on column T_100174_NU_ALLSERVER.thedate
  is '��������';
comment on column T_100174_NU_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100174_NU_ALLSERVER.channelid
  is '����ID';
comment on column T_100174_NU_ALLSERVER.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100174_NU_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100174_NU_ALLSERVER.position
  is '����λ��';
comment on column T_100174_NU_ALLSERVER.accountid
  is '�˺�ID';
create index IDX194_100174 on T_100174_NU_ALLSERVER (CHANNELID);
create index IDX195_100174 on T_100174_NU_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100174_NU_DVID
prompt ===============================
prompt
create table T_100174_NU_DVID
(
  thedate   DATE not null,
  gameid    VARCHAR2(20) not null,
  channelid VARCHAR2(20) not null,
  dvid      VARCHAR2(50) not null,
  ipaddr    VARCHAR2(50)
)
;
comment on table T_100174_NU_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100174_NU_DVID.thedate
  is '����ʱ��';
comment on column T_100174_NU_DVID.gameid
  is '��ϷID';
comment on column T_100174_NU_DVID.channelid
  is '����ID';
comment on column T_100174_NU_DVID.dvid
  is '�豸ID';
comment on column T_100174_NU_DVID.ipaddr
  is 'IP';
create index IDX146_100174 on T_100174_NU_DVID (CHANNELID);
create index IDX147_100174 on T_100174_NU_DVID (THEDATE);

prompt
prompt Creating table T_100174_NU_MAC
prompt ==============================
prompt
create table T_100174_NU_MAC
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100174_NU_MAC
  is '�豸������';
comment on column T_100174_NU_MAC.thedate
  is '����ʱ��';
comment on column T_100174_NU_MAC.gameid
  is '��ϷID';
comment on column T_100174_NU_MAC.channelid
  is '����ID';
comment on column T_100174_NU_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100174_NU_MAC.serverid
  is '��������ID';
comment on column T_100174_NU_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100174_NU_MAC.position
  is 'λ����Ϣ';
comment on column T_100174_NU_MAC.dvid
  is '�豸ID';
create index IDX148_100174 on T_100174_NU_MAC (CHANNELID);
create index IDX149_100174 on T_100174_NU_MAC (SERVERID);
create index IDX150_100174 on T_100174_NU_MAC (THEDATE);

prompt
prompt Cre