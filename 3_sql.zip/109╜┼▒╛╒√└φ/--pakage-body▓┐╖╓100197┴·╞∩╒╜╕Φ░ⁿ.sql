------------------------------------------------------------
-- Export file for user DEVELOPER@BI_RACDB1_111.13.20.109 --
-- Created by Administrator on 2015/6/3, 14:36:18 ----------
------------------------------------------------------------

set define off
spool --pakage����100197����ս���.log

prompt
prompt Creating package body PKG_BASE_DATA_100197
prompt ==========================================
prompt
CREATE OR REPLACE PACKAGE BODY "PKG_BASE_DATA_100197" IS

  -- AUTHOR  : ZHANGBIAO
  -- CREATED : 2014-08-29 16:52:37
  -- PURPOSE : BI��������
  --��������
  PROCEDURE SP_ALL(P_LOGTIME IN VARCHAR2,
                   P_ERRCODE OUT NUMBER,
                   P_ERRSTR  OUT VARCHAR2) IS
  BEGIN
    PKG_BASE_DATA_100197.SP_NU(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_BASE_DATA_100197.SP_ORDER(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_BASE_DATA_100197.SP_NU_PAY(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_BASE_DATA_100197.SP_CONN(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_BASE_DATA_100197.SP_CONN_ACT(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_BASE_DATA_100197.SP_LOST(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_BASE_DATA_100197.SP_MISSION_FIRST(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_BASE_DATA_100197.SP_DVID(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_BASE_DATA_100197.SP_CEVENT(P_LOGTIME, P_ERRCODE, P_ERRSTR);
  END;

  --�����û���������
  PROCEDURE SP_NU(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2) IS
    /*
    ����ע���û���Ϣ��ȡ
    �ű�
    20140826
    */
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    INPUTDATE      NUMBER;
  BEGIN
    INPUTDATE := 0;
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO INPUTDATE
      FROM DUAL;
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_BASE_DATA_100197.SP_NU';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    V_ERRPOSITION := '1-1';
    --�˺�����
    DELETE FROM T_100197_NU T
     WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
       AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    V_ERRPOSITION := '1-2';
    --��¼LOGIN����ϴ��¼�û�
    MERGE INTO T_100197_NU N
    USING (SELECT *
             FROM (SELECT T.F_LOGTIME AS THEDATE,
                          T.APPID AS GAMEID,
                          T.CHANNELID AS CHANNELID,
                          NVL(T.GAMEVERSION, 0) AS GAMEVERSION,
                          NVL(T.SERVERID, 0) AS SERVERID,
                          0 AS ROLELEVEL,
                          NVL(T.ACCOUNTID, 0) ACCOUNTID,
                          T.IPADDR,
                          ROW_NUMBER() OVER(PARTITION BY T.APPID, T.CHANNELID, T.SERVERID, T.ACCOUNTID ORDER BY T.F_LOGTIME) RANKNUM
                     FROM T_DW_100197_LOGIN T
                    WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                      AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1))
            WHERE RANKNUM = 1) T
    ON (N.GAMEID = T.GAMEID AND N.CHANNELID = T.CHANNELID AND N.SERVERID = T.SERVERID AND N.ACCOUNTID = T.ACCOUNTID)
    WHEN NOT MATCHED THEN
      INSERT
        (THEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         SERVERID,
         ROLELEVEL,
         ACCOUNTID,
         POSITION)
      VALUES
        (T.THEDATE,
         T.GAMEID,
         T.CHANNELID,
         T.GAMEVERSION,
         T.SERVERID,
         T.ROLELEVEL,
         T.ACCOUNTID,
         T.IPADDR);
    COMMIT;

    V_ERRPOSITION := '1-3';
    --�ǳ�LOGOUT����ϴ��¼�û�
    MERGE INTO T_100197_NU N
    USING (SELECT *
             FROM (SELECT T.F_LOGTIME AS THEDATE,
                          T.APPID AS GAMEID,
                          T.CHANNELID AS CHANNELID,
                          NVL(T.GAMEVERSION, 0) AS GAMEVERSION,
                          NVL(T.SERVERID, 0) AS SERVERID,
                          0 AS ROLELEVEL,
                          NVL(T.ACCOUNTID, 0) ACCOUNTID,
                          T.IPADDR,
                          ROW_NUMBER() OVER(PARTITION BY T.APPID, T.CHANNELID, T.SERVERID, T.ACCOUNTID ORDER BY T.F_LOGTIME) RANKNUM
                     FROM T_DW_100197_LOGOUT T
                    WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                      AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1))
            WHERE RANKNUM = 1) T
    ON (N.GAMEID = T.GAMEID AND N.CHANNELID = T.CHANNELID AND N.SERVERID = T.SERVERID AND N.ACCOUNTID = T.ACCOUNTID)
    WHEN NOT MATCHED THEN
      INSERT
        (THEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         SERVERID,
         ROLELEVEL,
         ACCOUNTID,
         POSITION)
      VALUES
        (T.THEDATE,
         T.GAMEID,
         T.CHANNELID,
         T.GAMEVERSION,
         T.SERVERID,
         T.ROLELEVEL,
         T.ACCOUNTID,
         T.IPADDR);
    COMMIT;

    V_ERRPOSITION := '1-4';
    --����PAY����ϴ��¼�û�
    MERGE INTO T_100197_NU N
    USING (SELECT *
             FROM (SELECT T.F_LOGTIME AS THEDATE,
                          T.APPID AS GAMEID,
                          T.CHANNELID AS CHANNELID,
                          NVL(T.GAMEVERSION, 0) AS GAMEVERSION,
                          NVL(T.SERVERID, 0) AS SERVERID,
                          0 AS ROLELEVEL,
                          NVL(T.ACCOUNTID, 0) ACCOUNTID,
                          T.IPADDR,
                          ROW_NUMBER() OVER(PARTITION BY T.APPID, T.CHANNELID, T.SERVERID, T.ACCOUNTID ORDER BY T.F_LOGTIME) RANKNUM
                     FROM T_DW_100197_PAY T
                    WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                      AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1))
            WHERE RANKNUM = 1) T
    ON (N.GAMEID = T.GAMEID AND N.CHANNELID = T.CHANNELID AND N.SERVERID = T.SERVERID AND N.ACCOUNTID = T.ACCOUNTID)
    WHEN NOT MATCHED THEN
      INSERT
        (THEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         SERVERID,
         ROLELEVEL,
         ACCOUNTID,
         POSITION)
      VALUES
        (T.THEDATE,
         T.GAMEID,
         T.CHANNELID,
         T.GAMEVERSION,
         T.SERVERID,
         T.ROLELEVEL,
         T.ACCOUNTID,
         T.IPADDR);
    COMMIT;

    V_ERRPOSITION := '1-5';
    --���������REWARD����ϴ��¼�û�
    MERGE INTO T_100197_NU N
    USING (SELECT *
             FROM (SELECT T.F_LOGTIME AS THEDATE,
                          T.APPID AS GAMEID,
                          T.CHANNELID AS CHANNELID,
                          NVL(T.GAMEVERSION, 0) AS GAMEVERSION,
                          NVL(T.SERVERID, 0) AS SERVERID,
                          0 AS ROLELEVEL,
                          NVL(T.ACCOUNTID, 0) ACCOUNTID,
                          T.IPADDR,
                          ROW_NUMBER() OVER(PARTITION BY T.APPID, T.CHANNELID, T.SERVERID, T.ACCOUNTID ORDER BY T.F_LOGTIME) RANKNUM
                     FROM T_DW_100197_REWARD T
                    WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                      AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1))
            WHERE RANKNUM = 1) T
    ON (N.GAMEID = T.GAMEID AND N.CHANNELID = T.CHANNELID AND N.SERVERID = T.SERVERID AND N.ACCOUNTID = T.ACCOUNTID)
    WHEN NOT MATCHED THEN
      INSERT
        (THEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         SERVERID,
         ROLELEVEL,
         ACCOUNTID,
         POSITION)
      VALUES
        (T.THEDATE,
         T.GAMEID,
         T.CHANNELID,
         T.GAMEVERSION,
         T.SERVERID,
         T.ROLELEVEL,
         T.ACCOUNTID,
         T.IPADDR);
    COMMIT;

    V_ERRPOSITION := '1-6';
    --���ѵ�ͳ��CONSUME����ϴ��¼�û�
    MERGE INTO T_100197_NU N
    USING (SELECT *
             FROM (SELECT T.F_LOGTIME AS THEDATE,
                          T.APPID AS GAMEID,
                          T.CHANNELID AS CHANNELID,
                          NVL(T.GAMEVERSION, 0) AS GAMEVERSION,
                          NVL(T.SERVERID, 0) AS SERVERID,
                          0 AS ROLELEVEL,
                          NVL(T.ACCOUNTID, 0) ACCOUNTID,
                          T.IPADDR,
                          ROW_NUMBER() OVER(PARTITION BY T.APPID, T.CHANNELID, T.SERVERID, T.ACCOUNTID ORDER BY T.F_LOGTIME) RANKNUM
                     FROM T_DW_100197_CONSUME T
                    WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                      AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1))
            WHERE RANKNUM = 1) T
    ON (N.GAMEID = T.GAMEID AND N.CHANNELID = T.CHANNELID AND N.SERVERID = T.SERVERID AND N.ACCOUNTID = T.ACCOUNTID)
    WHEN NOT MATCHED THEN
      INSERT
        (THEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         SERVERID,
         ROLELEVEL,
         ACCOUNTID,
         POSITION)
      VALUES
        (T.THEDATE,
         T.GAMEID,
         T.CHANNELID,
         T.GAMEVERSION,
         T.SERVERID,
         T.ROLELEVEL,
         T.ACCOUNTID,
         T.IPADDR);
    COMMIT;

    V_ERRPOSITION := '1-7';
    --����ؿ�MISSION����ϴ��¼�û�
    MERGE INTO T_100197_NU N
    USING (SELECT *
             FROM (SELECT T.F_LOGTIME AS THEDATE,
                          T.APPID AS GAMEID,
                          T.CHANNELID AS CHANNELID,
                          NVL(T.GAMEVERSION, 0) AS GAMEVERSION,
                          NVL(T.SERVERID, 0) AS SERVERID,
                          0 AS ROLELEVEL,
                          NVL(T.ACCOUNTID, 0) ACCOUNTID,
                          T.IPADDR,
                          ROW_NUMBER() OVER(PARTITION BY T.APPID, T.CHANNELID, T.SERVERID, T.ACCOUNTID ORDER BY T.F_LOGTIME) RANKNUM
                     FROM T_DW_100197_MISSION T
                    WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                      AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1))
            WHERE RANKNUM = 1) T
    ON (N.GAMEID = T.GAMEID AND N.CHANNELID = T.CHANNELID AND N.SERVERID = T.SERVERID AND N.ACCOUNTID = T.ACCOUNTID)
    WHEN NOT MATCHED THEN
      INSERT
        (THEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         SERVERID,
         ROLELEVEL,
         ACCOUNTID,
         POSITION)
      VALUES
        (T.THEDATE,
         T.GAMEID,
         T.CHANNELID,
         T.GAMEVERSION,
         T.SERVERID,
         T.ROLELEVEL,
         T.ACCOUNTID,
         T.IPADDR);
    COMMIT;

    V_ERRPOSITION := '1-8';
    --�Զ���ͳ��CEVEN����ϴ��¼�û�
    MERGE INTO T_100197_NU N
    USING (SELECT *
             FROM (SELECT T.F_LOGTIME AS THEDATE,
                          T.APPID AS GAMEID,
                          T.CHANNELID AS CHANNELID,
                          NVL(T.GAMEVERSION, 0) AS GAMEVERSION,
                          NVL(T.SERVERID, 0) AS SERVERID,
                          0 AS ROLELEVEL,
                          NVL(T.ACCOUNTID, 0) ACCOUNTID,
                          T.IPADDR,
                          ROW_NUMBER() OVER(PARTITION BY T.APPID, T.CHANNELID, T.SERVERID, T.ACCOUNTID ORDER BY T.F_LOGTIME) RANKNUM
                     FROM T_DW_100197_CEVENT T
                    WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                      AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1))
            WHERE RANKNUM = 1) T
    ON (N.GAMEID = T.GAMEID AND N.CHANNELID = T.CHANNELID AND N.SERVERID = T.SERVERID AND N.ACCOUNTID = T.ACCOUNTID)
    WHEN NOT MATCHED THEN
      INSERT
        (THEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         SERVERID,
         ROLELEVEL,
         ACCOUNTID,
         POSITION)
      VALUES
        (T.THEDATE,
         T.GAMEID,
         T.CHANNELID,
         T.GAMEVERSION,
         T.SERVERID,
         T.ROLELEVEL,
         T.ACCOUNTID,
         T.IPADDR);
    COMMIT;

    --��������ɸѡ��������������������
    V_ERRPOSITION := '1-8-ALL';
    DELETE FROM T_100197_NU_ALLSERVER T
     WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
       AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    MERGE INTO T_100197_NU_ALLSERVER N
    USING (SELECT *
             FROM (SELECT T.THEDATE AS THEDATE,
                          T.GAMEID AS GAMEID,
                          T.CHANNELID AS CHANNELID,
                          NVL(T.GAMEVERSION, 0) AS GAMEVERSION,
                          0 AS ROLELEVEL,
                          NVL(T.ACCOUNTID, 0) ACCOUNTID,
                          T.POSITION,
                          ROW_NUMBER() OVER(PARTITION BY T.GAMEID, T.CHANNELID, T.ACCOUNTID ORDER BY T.THEDATE) RANKNUM
                     FROM T_100197_NU T
                    WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
                      AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1))
            WHERE RANKNUM = 1) T
    ON (N.GAMEID = T.GAMEID AND N.CHANNELID = T.CHANNELID AND N.ACCOUNTID = T.ACCOUNTID)
    WHEN NOT MATCHED THEN
      INSERT
        (THEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         ROLELEVEL,
         ACCOUNTID,
         POSITION)
      VALUES
        (T.THEDATE,
         T.GAMEID,
         T.CHANNELID,
         T.GAMEVERSION,
         T.ROLELEVEL,
         T.ACCOUNTID,
         T.POSITION);
    COMMIT;

    V_ERRPOSITION := '1-9';
    --�豸����
    DELETE FROM T_100197_NU_MAC T
     WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
       AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    V_ERRPOSITION := '1-10';
    --��¼LOGIN����ϴ��¼�豸
    MERGE INTO T_100197_NU_MAC N
    USING (SELECT *
             FROM (SELECT T.F_LOGTIME AS THEDATE,
                          T.APPID AS GAMEID,
                          T.CHANNELID AS CHANNELID,
                          NVL(T.GAMEVERSION, 0) AS GAMEVERSION,
                          NVL(T.SERVERID, 0) AS SERVERID,
                          0 AS ROLELEVEL,
                          T.DVID,
                          T.IPADDR,
                          ROW_NUMBER() OVER(PARTITION BY T.APPID, T.CHANNELID, T.SERVERID, T.DVID ORDER BY T.F_LOGTIME) RANKNUM
                     FROM T_DW_100197_LOGIN T
                    WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                      AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
                      AND T.DVID IS NOT NULL)
            WHERE RANKNUM = 1) T
    ON (N.GAMEID = T.GAMEID AND N.CHANNELID = T.CHANNELID AND N.SERVERID = T.SERVERID AND N.DVID = T.DVID)
    WHEN NOT MATCHED THEN
      INSERT
        (THEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         SERVERID,
         ROLELEVEL,
         DVID,
         POSITION)
      VALUES
        (T.THEDATE,
         T.GAMEID,
         T.CHANNELID,
         T.GAMEVERSION,
         T.SERVERID,
         T.ROLELEVEL,
         T.DVID,
         T.IPADDR);
    COMMIT;

    V_ERRPOSITION := '1-11';
    --�ǳ�LOGOUT����ϴ��¼�豸
    MERGE INTO T_100197_NU_MAC N
    USING (SELECT *
             FROM (SELECT T.F_LOGTIME AS THEDATE,
                          T.APPID AS GAMEID,
                          T.CHANNELID AS CHANNELID,
                          NVL(T.GAMEVERSION, 0) AS GAMEVERSION,
                          NVL(T.SERVERID, 0) AS SERVERID,
                          0 AS ROLELEVEL,
                          T.DVID,
                          T.IPADDR,
                          ROW_NUMBER() OVER(PARTITION BY T.APPID, T.CHANNELID, T.SERVERID, T.DVID ORDER BY T.F_LOGTIME) RANKNUM
                     FROM T_DW_100197_LOGOUT T
                    WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                      AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
                      AND T.DVID IS NOT NULL)
            WHERE RANKNUM = 1) T
    ON (N.GAMEID = T.GAMEID AND N.CHANNELID = T.CHANNELID AND N.SERVERID = T.SERVERID AND N.DVID = T.DVID)
    WHEN NOT MATCHED THEN
      INSERT
        (THEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         SERVERID,
         ROLELEVEL,
         DVID,
         POSITION)
      VALUES
        (T.THEDATE,
         T.GAMEID,
         T.CHANNELID,
         T.GAMEVERSION,
         T.SERVERID,
         T.ROLELEVEL,
         T.DVID,
         T.IPADDR);
    COMMIT;

    V_ERRPOSITION := '1-12';
    --����PAY����ϴ��¼�豸
    MERGE INTO T_100197_NU_MAC N
    USING (SELECT *
             FROM (SELECT T.F_LOGTIME AS THEDATE,
                          T.APPID AS GAMEID,
                          T.CHANNELID AS CHANNELID,
                          NVL(T.GAMEVERSION, 0) AS GAMEVERSION,
                          NVL(T.SERVERID, 0) AS SERVERID,
                          0 AS ROLELEVEL,
                          T.DVID,
                          T.IPADDR,
                          ROW_NUMBER() OVER(PARTITION BY T.APPID, T.CHANNELID, T.SERVERID, T.DVID ORDER BY T.F_LOGTIME) RANKNUM
                     FROM T_DW_100197_PAY T
                    WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                      AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
                      AND T.DVID IS NOT NULL)
            WHERE RANKNUM = 1) T
    ON (N.GAMEID = T.GAMEID AND N.CHANNELID = T.CHANNELID AND N.SERVERID = T.SERVERID AND N.DVID = T.DVID)
    WHEN NOT MATCHED THEN
      INSERT
        (THEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         SERVERID,
         ROLELEVEL,
         DVID,
         POSITION)
      VALUES
        (T.THEDATE,
         T.GAMEID,
         T.CHANNELID,
         T.GAMEVERSION,
         T.SERVERID,
         T.ROLELEVEL,
         T.DVID,
         T.IPADDR);
    COMMIT;

    V_ERRPOSITION := '1-13';
    --���������REWARD����ϴ��¼�豸
    MERGE INTO T_100197_NU_MAC N
    USING (SELECT *
             FROM (SELECT T.F_LOGTIME AS THEDATE,
                          T.APPID AS GAMEID,
                          T.CHANNELID AS CHANNELID,
                          NVL(T.GAMEVERSION, 0) AS GAMEVERSION,
                          NVL(T.SERVERID, 0) AS SERVERID,
                          0 AS ROLELEVEL,
                          T.DVID,
                          T.IPADDR,
                          ROW_NUMBER() OVER(PARTITION BY T.APPID, T.CHANNELID, T.SERVERID, T.DVID ORDER BY T.F_LOGTIME) RANKNUM
                     FROM T_DW_100197_REWARD T
                    WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                      AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
                      AND T.DVID IS NOT NULL)
            WHERE RANKNUM = 1) T
    ON (N.GAMEID = T.GAMEID AND N.CHANNELID = T.CHANNELID AND N.SERVERID = T.SERVERID AND N.DVID = T.DVID)
    WHEN NOT MATCHED THEN
      INSERT
        (THEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         SERVERID,
         ROLELEVEL,
         DVID,
         POSITION)
      VALUES
        (T.THEDATE,
         T.GAMEID,
         T.CHANNELID,
         T.GAMEVERSION,
         T.SERVERID,
         T.ROLELEVEL,
         T.DVID,
         T.IPADDR);
    COMMIT;

    V_ERRPOSITION := '1-14';
    --���ѵ�ͳ��CONSUME����ϴ��¼�豸
    MERGE INTO T_100197_NU_MAC N
    USING (SELECT *
             FROM (SELECT T.F_LOGTIME AS THEDATE,
                          T.APPID AS GAMEID,
                          T.CHANNELID AS CHANNELID,
                          NVL(T.GAMEVERSION, 0) AS GAMEVERSION,
                          NVL(T.SERVERID, 0) AS SERVERID,
                          0 AS ROLELEVEL,
                          T.DVID,
                          T.IPADDR,
                          ROW_NUMBER() OVER(PARTITION BY T.APPID, T.CHANNELID, T.SERVERID, T.DVID ORDER BY T.F_LOGTIME) RANKNUM
                     FROM T_DW_100197_CONSUME T
                    WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                      AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
                      AND T.DVID IS NOT NULL)
            WHERE RANKNUM = 1) T
    ON (N.GAMEID = T.GAMEID AND N.CHANNELID = T.CHANNELID AND N.SERVERID = T.SERVERID AND N.DVID = T.DVID)
    WHEN NOT MATCHED THEN
      INSERT
        (THEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         SERVERID,
         ROLELEVEL,
         DVID,
         POSITION)
      VALUES
        (T.THEDATE,
         T.GAMEID,
         T.CHANNELID,
         T.GAMEVERSION,
         T.SERVERID,
         T.ROLELEVEL,
         T.DVID,
         T.IPADDR);
    COMMIT;

    V_ERRPOSITION := '1-15';
    --����ؿ�MISSION����ϴ��¼�豸
    MERGE INTO T_100197_NU_MAC N
    USING (SELECT *
             FROM (SELECT T.F_LOGTIME AS THEDATE,
                          T.APPID AS GAMEID,
                          T.CHANNELID AS CHANNELID,
                          NVL(T.GAMEVERSION, 0) AS GAMEVERSION,
                          NVL(T.SERVERID, 0) AS SERVERID,
                          0 AS ROLELEVEL,
                          T.DVID,
                          T.IPADDR,
                          ROW_NUMBER() OVER(PARTITION BY T.APPID, T.CHANNELID, T.SERVERID, T.DVID ORDER BY T.F_LOGTIME) RANKNUM
                     FROM T_DW_100197_MISSION T
                    WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                      AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
                      AND T.DVID IS NOT NULL)
            WHERE RANKNUM = 1) T
    ON (N.GAMEID = T.GAMEID AND N.CHANNELID = T.CHANNELID AND N.SERVERID = T.SERVERID AND N.DVID = T.DVID)
    WHEN NOT MATCHED THEN
      INSERT
        (THEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         SERVERID,
         ROLELEVEL,
         DVID,
         POSITION)
      VALUES
        (T.THEDATE,
         T.GAMEID,
         T.CHANNELID,
         T.GAMEVERSION,
         T.SERVERID,
         T.ROLELEVEL,
         T.DVID,
         T.IPADDR);
    COMMIT;

    V_ERRPOSITION := '1-16';
    --�Զ���ͳ��CEVENT����ϴ��¼�豸
    MERGE INTO T_100197_NU_MAC N
    USING (SELECT *
             FROM (SELECT T.F_LOGTIME AS THEDATE,
                          T.APPID AS GAMEID,
                          T.CHANNELID AS CHANNELID,
                          NVL(T.GAMEVERSION, 0) AS GAMEVERSION,
                          NVL(T.SERVERID, 0) AS SERVERID,
                          0 AS ROLELEVEL,
                          T.DVID,
                          T.IPADDR,
                          ROW_NUMBER() OVER(PARTITION BY T.APPID, T.CHANNELID, T.SERVERID, T.DVID ORDER BY T.F_LOGTIME) RANKNUM
                     FROM T_DW_100197_CEVENT T
                    WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                      AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
                      AND T.DVID IS NOT NULL)
            WHERE RANKNUM = 1) T
    ON (N.GAMEID = T.GAMEID AND N.CHANNELID = T.CHANNELID AND N.SERVERID = T.SERVERID AND N.DVID = T.DVID)
    WHEN NOT MATCHED THEN
      INSERT
        (THEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         SERVERID,
         ROLELEVEL,
         DVID,
         POSITION)
      VALUES
        (T.THEDATE,
         T.GAMEID,
         T.CHANNELID,
         T.GAMEVERSION,
         T.SERVERID,
         T.ROLELEVEL,
         T.DVID,
         T.IPADDR);
    COMMIT;

    --��������ɸѡ��������������������
    V_ERRPOSITION := '1-16-ALL';
    DELETE FROM T_100197_NU_MAC_ALLSERVER T
     WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
       AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);

    MERGE INTO T_100197_NU_MAC_ALLSERVER N
    USING (SELECT *
             FROM (SELECT T.THEDATE AS THEDATE,
                          T.GAMEID AS GAMEID,
                          T.CHANNELID AS CHANNELID,
                          NVL(T.GAMEVERSION, 0) AS GAMEVERSION,
                          0 AS ROLELEVEL,
                          T.DVID,
                          T.POSITION,
                          ROW_NUMBER() OVER(PARTITION BY T.GAMEID, T.CHANNELID, T.DVID ORDER BY T.THEDATE) RANKNUM
                     FROM T_100197_NU_MAC T
                    WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
                      AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1)
                      AND T.DVID IS NOT NULL)
            WHERE RANKNUM = 1) T
    ON (N.GAMEID = T.GAMEID AND N.CHANNELID = T.CHANNELID AND N.DVID = T.DVID)
    WHEN NOT MATCHED THEN
      INSERT
        (THEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         ROLELEVEL,
         DVID,
         POSITION)
      VALUES
        (T.THEDATE,
         T.GAMEID,
         T.CHANNELID,
         T.GAMEVERSION,
         T.ROLELEVEL,
         T.DVID,
         T.POSITION);
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_100197_NU_MAC';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  --���������û�
  PROCEDURE SP_NU_PAY(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2) IS
    /*
    �״θ���ʱ��
    �ű�
    20140826
    */
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    INPUTDATE      NUMBER;
  BEGIN
    INPUTDATE := 0;
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO INPUTDATE
      FROM DUAL;
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_BASE_DATA_100197.SP_NU_PAY';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    V_ERRPOSITION := '1-1';
    --�豸
    DELETE FROM T_100197_NU_PAY_MAC T
     WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
       AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    V_ERRPOSITION := '1-2';
    MERGE INTO T_100197_NU_PAY_MAC NP
    USING (SELECT T.THEDATE,
                  S.GAMEID,
                  S.CHANNELID,
                  S.GAMEVERSION,
                  S.SERVERID,
                  S.ROLELEVEL,
                  S.POSITION,
                  S.DVID,
                  S.THEDATE     AS FIRSTPAYDATE,
                  S.ROLELEVEL   AS FIRSTPAYLEVEL,
                  S.MONEY
             FROM T_100197_NU_MAC T
            INNER JOIN (SELECT TOS.THEDATE,
                              TOS.GAMEID,
                              TOS.SERVERID,
                              TOS.CHANNELID,
                              TOS.GAMEVERSION,
                              TOS.POSITION,
                              TOS.ROLELEVEL,
                              TOS.DVID,
                              TOS.MONEY,
                              ROW_NUMBER() OVER(PARTITION BY TOS.SERVERID, TOS.CHANNELID, TOS.DVID ORDER BY TOS.THEDATE) NU
                         FROM T_100197_ORDER_SUCC TOS
                        WHERE TOS.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
                          AND TOS.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1)) S
               ON S.GAMEID = T.GAMEID
              AND S.CHANNELID = T.CHANNELID
              AND S.SERVERID = T.SERVERID
              AND S.DVID = T.DVID
            WHERE S.NU = 1) T
    ON (NP.GAMEID = T.GAMEID AND NP.CHANNELID = T.CHANNELID AND NP.SERVERID = T.SERVERID AND NP.DVID = T.DVID)
    WHEN NOT MATCHED THEN
      INSERT
        (THEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         SERVERID,
         ROLELEVEL,
         POSITION,
         DVID,
         FIRSTPAYDATE,
         FIRSTPAYLEVEL,
         FIRSTPAYMONEY)
      VALUES
        (T.THEDATE,
         T.GAMEID,
         T.CHANNELID,
         T.GAMEVERSION,
         T.SERVERID,
         T.ROLELEVEL,
         T.POSITION,
         T.DVID,
         T.FIRSTPAYDATE,
         T.FIRSTPAYLEVEL,
         T.MONEY);
    COMMIT;

    --�豸������������
    V_ERRPOSITION := '1-2-1';
    DELETE FROM T_100197_NU_PAY_MAC_AS T
     WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
       AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    MERGE INTO T_100197_NU_PAY_MAC_AS NP
    USING (SELECT T.THEDATE,
                  S.GAMEID,
                  S.CHANNELID,
                  S.GAMEVERSION,
                  S.ROLELEVEL,
                  S.POSITION,
                  S.DVID,
                  S.THEDATE     AS FIRSTPAYDATE,
                  S.ROLELEVEL   AS FIRSTPAYLEVEL,
                  S.MONEY
             FROM T_100197_NU_MAC_ALLSERVER T
            INNER JOIN (SELECT TOS.THEDATE,
                              TOS.GAMEID,
                              TOS.CHANNELID,
                              TOS.GAMEVERSION,
                              TOS.POSITION,
                              TOS.ROLELEVEL,
                              TOS.DVID,
                              TOS.MONEY,
                              ROW_NUMBER() OVER(PARTITION BY TOS.CHANNELID, TOS.DVID ORDER BY TOS.THEDATE) NU
                         FROM T_100197_ORDER_SUCC TOS
                        WHERE TOS.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
                          AND TOS.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1)) S
               ON S.GAMEID = T.GAMEID
              AND S.CHANNELID = T.CHANNELID
              AND S.DVID = T.DVID
            WHERE S.NU = 1) T
    ON (NP.GAMEID = T.GAMEID AND NP.CHANNELID = T.CHANNELID AND NP.DVID = T.DVID)
    WHEN NOT MATCHED THEN
      INSERT
        (THEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         ROLELEVEL,
         POSITION,
         DVID,
         FIRSTPAYDATE,
         FIRSTPAYLEVEL,
         FIRSTPAYMONEY)
      VALUES
        (T.THEDATE,
         T.GAMEID,
         T.CHANNELID,
         T.GAMEVERSION,
         T.ROLELEVEL,
         T.POSITION,
         T.DVID,
         T.FIRSTPAYDATE,
         T.FIRSTPAYLEVEL,
         T.MONEY);
    COMMIT;

    V_ERRPOSITION := '1-3';
    --�˺�
    DELETE FROM T_100197_NU_PAY T
     WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
       AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    V_ERRPOSITION := '1-4';
    MERGE INTO T_100197_NU_PAY NP
    USING (SELECT T.THEDATE,
                  S.GAMEID,
                  S.CHANNELID,
                  S.GAMEVERSION,
                  S.SERVERID,
                  S.ROLELEVEL,
                  S.POSITION,
                  S.ACCOUNTID,
                  S.THEDATE     AS FIRSTPAYDATE,
                  S.ROLELEVEL   AS FIRSTPAYLEVEL,
                  S.MONEY
             FROM T_100197_NU T
            INNER JOIN (SELECT TOS.THEDATE,
                              TOS.GAMEID,
                              TOS.SERVERID,
                              TOS.CHANNELID,
                              TOS.GAMEVERSION,
                              TOS.POSITION,
                              TOS.ROLELEVEL,
                              TOS.ACCOUNTID,
                              TOS.MONEY,
                              ROW_NUMBER() OVER(PARTITION BY TOS.SERVERID, TOS.CHANNELID, TOS.ACCOUNTID ORDER BY TOS.THEDATE) NU
                         FROM T_100197_ORDER_SUCC TOS
                        WHERE TOS.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
                          AND TOS.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1)) S
               ON S.GAMEID = T.GAMEID
              AND S.CHANNELID = T.CHANNELID
              AND S.SERVERID = T.SERVERID
              AND S.ACCOUNTID = T.ACCOUNTID
            WHERE S.NU = 1) T
    ON (NP.GAMEID = T.GAMEID AND NP.CHANNELID = T.CHANNELID AND NP.SERVERID = T.SERVERID AND NP.ACCOUNTID = T.ACCOUNTID)
    WHEN NOT MATCHED THEN
      INSERT
        (THEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         SERVERID,
         ROLELEVEL,
         POSITION,
         ACCOUNTID,
         FIRSTPAYDATE,
         FIRSTPAYLEVEL,
         FIRSTPAYMONEY)
      VALUES
        (T.THEDATE,
         T.GAMEID,
         T.CHANNELID,
         T.GAMEVERSION,
         T.SERVERID,
         T.ROLELEVEL,
         T.POSITION,
         T.ACCOUNTID,
         T.FIRSTPAYDATE,
         T.FIRSTPAYLEVEL,
         T.MONEY);
    COMMIT;

    --�˺ţ�����������
    V_ERRPOSITION := '1-4-1';
    DELETE FROM T_100197_NU_PAY_AS T
     WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
       AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    MERGE INTO T_100197_NU_PAY_AS NP
    USING (SELECT T.THEDATE,
                  S.GAMEID,
                  S.CHANNELID,
                  S.GAMEVERSION,
                  S.ROLELEVEL,
                  S.POSITION,
                  S.ACCOUNTID,
                  S.THEDATE     AS FIRSTPAYDATE,
                  S.ROLELEVEL   AS FIRSTPAYLEVEL,
                  S.MONEY
             FROM T_100197_NU_ALLSERVER T
            INNER JOIN (SELECT TOS.THEDATE,
                              TOS.GAMEID,
                              TOS.CHANNELID,
                              TOS.GAMEVERSION,
                              TOS.POSITION,
                              TOS.ROLELEVEL,
                              TOS.ACCOUNTID,
                              TOS.MONEY,
                              ROW_NUMBER() OVER(PARTITION BY TOS.CHANNELID, TOS.ACCOUNTID ORDER BY TOS.THEDATE) NU
                         FROM T_100197_ORDER_SUCC TOS
                        WHERE TOS.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
                          AND TOS.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1)) S
               ON S.GAMEID = T.GAMEID
              AND S.CHANNELID = T.CHANNELID
              AND S.ACCOUNTID = T.ACCOUNTID
            WHERE S.NU = 1) T
    ON (NP.GAMEID = T.GAMEID AND NP.CHANNELID = T.CHANNELID AND NP.ACCOUNTID = T.ACCOUNTID)
    WHEN NOT MATCHED THEN
      INSERT
        (THEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         ROLELEVEL,
         POSITION,
         ACCOUNTID,
         FIRSTPAYDATE,
         FIRSTPAYLEVEL,
         FIRSTPAYMONEY)
      VALUES
        (T.THEDATE,
         T.GAMEID,
         T.CHANNELID,
         T.GAMEVERSION,
         T.ROLELEVEL,
         T.POSITION,
         T.ACCOUNTID,
         T.FIRSTPAYDATE,
         T.FIRSTPAYLEVEL,
         T.MONEY);
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_100197_NU_PAY_MAC';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  --��������
  PROCEDURE SP_ORDER(P_LOGTIME IN VARCHAR2,
                     P_ERRCODE OUT NUMBER,
                     P_ERRSTR  OUT VARCHAR2) IS
    /*
    ������¼��������
    �ű�
    20140827
    */
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    INPUTDATE      NUMBER;
  BEGIN
    INPUTDATE := 0;
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO INPUTDATE
      FROM DUAL;
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_BASE_DATA_100197.SP_ORDER';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    V_ERRPOSITION := '1-1';
    --�ɹ�������¼
    DELETE FROM T_100197_ORDER_SUCC T
     WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
       AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    V_ERRPOSITION := '1-2';
    INSERT INTO T_100197_ORDER_SUCC
      (THEDATE,
       GAMEID,
       CHANNELID,
       GAMEVERSION,
       SERVERID,
       ROLELEVEL,
       POSITION,
       DVID,
       ACCOUNTID,
       MONEY,
       VC,
       ORDERID,
       PAYCHANNEL,
       IAPID)
      SELECT T1.F_LOGTIME,
             T1.APPID,
             T1.CHANNELID,
             NVL(T1.GAMEVERSION, 0) GAMEVERSION,
             NVL(T1.SERVERID, 0) SERVERID,
             0 AS ROLELEVEL,
             T1.IPADDR AS POSITION,
             T1.DVID,
             NVL(T1.ACCOUNTID, 0) ACCOUNTID,
             T2.CAMOUNT,
             T2.VCAMOUNT,
             T1.ORDERID,
             T1.PAYCHANNEL,
             T1.IAPID
        FROM (SELECT *
                FROM T_DW_100197_PAY T
               WHERE UPPER(T.LOGTYPE) = 'PAYSUCC'
                 AND T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                 AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)) T1
       INNER JOIN (SELECT *
                     FROM T_DW_100197_PAY D
                    WHERE UPPER(D.LOGTYPE) = 'PAYREQUEST' And d.camount>0) T2
          ON T1.ORDERID = T2.ORDERID;
    COMMIT;

    V_ERRPOSITION := '1-3';
    --ʧ�ܶ�����¼
    DELETE FROM T_100197_ORDER_FAILURE T
     WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
       AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    V_ERRPOSITION := '1-4';
    INSERT INTO T_100197_ORDER_FAILURE
      (THEDATE,
       GAMEID,
       CHANNELID,
       GAMEVERSION,
       SERVERID,
       ROLELEVEL,
       POSITION,
       DVID,
       ACCOUNTID,
       MONEY,
       VC,
       ORDERID,
       PAYCHANNEL,
       IAPID)
      SELECT T1.F_LOGTIME,
             T1.APPID,
             T1.CHANNELID,
             NVL(T1.GAMEVERSION, 0),
             NVL(T1.SERVERID, 0),
             0 AS ROLELEVEL,
             T1.IPADDR AS POSITION,
             T1.DVID,
             NVL(T1.ACCOUNTID, 0) ACCOUNTID,
             T2.CAMOUNT,
             T2.VCAMOUNT,
             T1.ORDERID,
             T1.PAYCHANNEL,
             T1.IAPID
        FROM (SELECT *
                FROM T_DW_100197_PAY T
               WHERE UPPER(T.LOGTYPE) = 'PAYFAILED'
                 AND T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                 AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)) T1
       INNER JOIN (SELECT *
                     FROM T_DW_100197_PAY D
                    WHERE UPPER(D.LOGTYPE) = 'PAYREQUEST' And d.camount>0) T2
          ON T1.ORDERID = T2.ORDERID;
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_100197_ORDER_SUCC';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  --�����˺ţ��豸����
  PROCEDURE SP_CONN(P_LOGTIME IN VARCHAR2,
                    P_ERRCODE OUT NUMBER,
                    P_ERRSTR  OUT VARCHAR2) IS
    /*
    ������ �������������˺ŵ� ���� ��ʧ  ����(����˺����豸)
    �ű�
    20140827
    20150529�޸�
    */
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    INPUTDATE      NUMBER;
    S_DATE         DATE;
    E_DATE         DATE;
  BEGIN
    INPUTDATE := 0;
    P_ERRCODE := 7100;

    IF SUBSTR(P_LOGTIME, 12, 2) = '23' THEN
      SELECT TRUNC(SYSDATE) -
             TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
        INTO INPUTDATE
        FROM DUAL;
      ------------------------------ִ����־��ʼ----------------------------------------------
      V_ERRSOURCE := 'PKG_BASE_DATA_100197.SP_CONN';
      PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', INPUTDATE);
      ------------------------------ִ����־��ʼ----------------------------------------------

      V_ERRPOSITION := '1-1';
      --�豸
      DELETE FROM T_100197_CONN_MAC T
       WHERE T.CONNDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
      COMMIT;

      V_ERRPOSITION := '1-2';
      S_DATE:=SYSDATE;
      --��¼LOGIN����ϴ�����豸
      MERGE INTO T_100197_CONN_MAC D
      USING (SELECT C.THEDATE AS CONNDATE,
                    C.APPID,
                    C.CHANNELID,
                    NVL(C.GAMEVERSION, 0) AS GAMEVERSION,
                    NVL(C.SERVERID, 0) SERVERID,
                    C.ROLELEVEL AS ROLELEVEL,
                    C.DVID,
                    TO_CHAR(N.THEDATE, 'YYYY-MM-DD') AS REGDATE,
                    CASE
                      WHEN NP.DVID IS NULL THEN
                       0
                      ELSE
                       1
                    END AS ISPAY,
                    TO_CHAR(NA.THEDATE, 'YYYY-MM-DD') AS REGDATE_AS
               FROM (SELECT TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD') AS THEDATE,
                            T.APPID,
                            T.CHANNELID,
                            MIN(T.GAMEVERSION) AS GAMEVERSION,
                            T.DVID,
                            NVL(T.SERVERID, 0) SERVERID,
                            NVL(MAX(T.ILEVEL), 0) AS ROLELEVEL
                       FROM T_DW_100197_LOGIN T
                      WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                        AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
                      GROUP BY TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD'),
                               T.APPID,
                               T.CHANNELID,
                               T.DVID,
                               T.SERVERID) C
              INNER JOIN T_100197_NU_MAC N
                 ON N.DVID = C.DVID
                AND N.SERVERID = C.SERVERID
                AND N.CHANNELID = C.CHANNELID
               LEFT JOIN T_100197_NU_PAY_MAC NP
                 ON NP.DVID = N.DVID
                AND N.SERVERID = NP.SERVERID
                AND N.CHANNELID = NP.CHANNELID
              INNER JOIN T_100197_NU_MAC_ALLSERVER NA
                 ON NA.DVID = C.DVID
                AND NA.CHANNELID = C.CHANNELID) T
      ON (D.GAMEID = T.APPID AND D.CHANNELID = T.CHANNELID AND D.SERVERID = T.SERVERID AND D.DVID = T.DVID AND D.CONNDATE = T.CONNDATE)
      WHEN NOT MATCHED THEN
        INSERT
          (CONNDATE,
           GAMEID,
           CHANNELID,
           GAMEVERSION,
           SERVERID,
           ROLELEVEL,
           DVID,
           REGDATE,
           ISPAY,
           REGDATE_AS)
        VALUES
          (T.CONNDATE,
           T.APPID,
           T.CHANNELID,
           T.GAMEVERSION,
           T.SERVERID,
           T.ROLELEVEL,
           T.DVID,
           T.REGDATE,
           T.ISPAY,
           T.REGDATE_AS);
      COMMIT;
      E_DATE:=SYSDATE;
      INSERT INTO temp_t_100197_recording(strat_date,end_date,errposition)
       VALUES(S_DATE,E_DATE,V_ERRPOSITION);
       COMMIT;

      V_ERRPOSITION := '1-3';
      S_DATE:=SYSDATE;
      --�ǳ�LOGOUT����ϴ�����豸
      MERGE INTO T_100197_CONN_MAC D
      USING (SELECT C.THEDATE AS CONNDATE,
                    C.APPID,
                    C.CHANNELID,
                    NVL(C.GAMEVERSION, 0) AS GAMEVERSION,
                    NVL(C.SERVERID, 0) SERVERID,
                    C.ROLELEVEL AS ROLELEVEL,
                    C.DVID,
                    TO_CHAR(N.THEDATE, 'YYYY-MM-DD') AS REGDATE,
                    CASE
                      WHEN NP.DVID IS NULL THEN
                       0
                      ELSE
                       1
                    END AS ISPAY,
                    TO_CHAR(NA.THEDATE, 'YYYY-MM-DD') AS REGDATE_AS
               FROM (SELECT TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD') AS THEDATE,
                            T.APPID,
                            T.CHANNELID,
                            MIN(T.GAMEVERSION) AS GAMEVERSION,
                            T.DVID,
                            NVL(T.SERVERID, 0) SERVERID,
                            NVL(MAX(T.ILEVEL), 0) AS ROLELEVEL
                       FROM T_DW_100197_LOGOUT T
                      WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                        AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
                      GROUP BY TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD'),
                               T.APPID,
                               T.CHANNELID,
                               T.DVID,
                               T.SERVERID) C
              INNER JOIN T_100197_NU_MAC N
                 ON N.DVID = C.DVID
                AND N.SERVERID = C.SERVERID
                AND N.CHANNELID = C.CHANNELID
               LEFT JOIN T_100197_NU_PAY_MAC NP
                 ON NP.DVID = N.DVID
                AND N.SERVERID = NP.SERVERID
                AND N.CHANNELID = NP.CHANNELID
              INNER JOIN T_100197_NU_MAC_ALLSERVER NA
                 ON NA.DVID = C.DVID
                AND NA.CHANNELID = C.CHANNELID) T
      ON (D.GAMEID = T.APPID AND D.CHANNELID = T.CHANNELID AND D.SERVERID = T.SERVERID AND D.DVID = T.DVID AND D.CONNDATE = T.CONNDATE)
      WHEN NOT MATCHED THEN
        INSERT
          (CONNDATE,
           GAMEID,
           CHANNELID,
           GAMEVERSION,
           SERVERID,
           ROLELEVEL,
           DVID,
           REGDATE,
           ISPAY,
           REGDATE_AS)
        VALUES
          (T.CONNDATE,
           T.APPID,
           T.CHANNELID,
           T.GAMEVERSION,
           T.SERVERID,
           T.ROLELEVEL,
           T.DVID,
           T.REGDATE,
           T.ISPAY,
           T.REGDATE_AS);
      COMMIT;
       E_DATE:=SYSDATE;
      INSERT INTO temp_t_100197_recording(strat_date,end_date,errposition)
       VALUES(S_DATE,E_DATE,V_ERRPOSITION);
       COMMIT;
       
      V_ERRPOSITION := '1-4';
      S_DATE:=SYSDATE;
      --����PAY����ϴ�����豸
      MERGE INTO T_100197_CONN_MAC D
      USING (SELECT C.THEDATE AS CONNDATE,
                    C.APPID,
                    C.CHANNELID,
                    NVL(C.GAMEVERSION, 0) AS GAMEVERSION,
                    NVL(C.SERVERID, 0) SERVERID,
                    C.ROLELEVEL AS ROLELEVEL,
                    C.DVID,
                    TO_CHAR(N.THEDATE, 'YYYY-MM-DD') AS REGDATE,
                    CASE
                      WHEN NP.DVID IS NULL THEN
                       0
                      ELSE
                       1
                    END AS ISPAY,
                    TO_CHAR(NA.THEDATE, 'YYYY-MM-DD') AS REGDATE_AS
               FROM (SELECT TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD') AS THEDATE,
                            T.APPID,
                            T.CHANNELID,
                            MIN(T.GAMEVERSION) AS GAMEVERSION,
                            T.DVID,
                            NVL(T.SERVERID, 0) SERVERID,
                            0 AS ROLELEVEL
                       FROM T_DW_100197_PAY T
                      WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                        AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
                      GROUP BY TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD'),
                               T.APPID,
                               T.CHANNELID,
                               T.DVID,
                               T.SERVERID) C
              INNER JOIN T_100197_NU_MAC N
                 ON N.DVID = C.DVID
                AND N.SERVERID = C.SERVERID
                AND N.CHANNELID = C.CHANNELID
               LEFT JOIN T_100197_NU_PAY_MAC NP
                 ON NP.DVID = N.DVID
                AND N.SERVERID = NP.SERVERID
                AND N.CHANNELID = NP.CHANNELID
              INNER JOIN T_100197_NU_MAC_ALLSERVER NA
                 ON NA.DVID = C.DVID
                AND NA.CHANNELID = C.CHANNELID) T
      ON (D.GAMEID = T.APPID AND D.CHANNELID = T.CHANNELID AND D.SERVERID = T.SERVERID AND D.DVID = T.DVID AND D.CONNDATE = T.CONNDATE)
      WHEN NOT MATCHED THEN
        INSERT
          (CONNDATE,
           GAMEID,
           CHANNELID,
           GAMEVERSION,
           SERVERID,
           ROLELEVEL,
           DVID,
           REGDATE,
           ISPAY,
           REGDATE_AS)
        VALUES
          (T.CONNDATE,
           T.APPID,
           T.CHANNELID,
           T.GAMEVERSION,
           T.SERVERID,
           T.ROLELEVEL,
           T.DVID,
           T.REGDATE,
           T.ISPAY,
           T.REGDATE_AS);
      COMMIT;
       E_DATE:=SYSDATE;
      INSERT INTO temp_t_100197_recording(strat_date,end_date,errposition)
       VALUES(S_DATE,E_DATE,V_ERRPOSITION);
       COMMIT;
       
      V_ERRPOSITION := '1-5';
      S_DATE:=SYSDATE;
      --���������REWARD����ϴ�����豸
      MERGE INTO T_100197_CONN_MAC D
      USING (SELECT C.THEDATE AS CONNDATE,
                    C.APPID,
                    C.CHANNELID,
                    NVL(C.GAMEVERSION, 0) AS GAMEVERSION,
                    NVL(C.SERVERID, 0) SERVERID,
                    C.ROLELEVEL AS ROLELEVEL,
                    C.DVID,
                    TO_CHAR(N.THEDATE, 'YYYY-MM-DD') AS REGDATE,
                    CASE
                      WHEN NP.DVID IS NULL THEN
                       0
                      ELSE
                       1
                    END AS ISPAY,
                    TO_CHAR(NA.THEDATE, 'YYYY-MM-DD') AS REGDATE_AS
               FROM (SELECT TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD') AS THEDATE,
                            T.APPID,
                            T.CHANNELID,
                            MIN(T.GAMEVERSION) AS GAMEVERSION,
                            T.DVID,
                            NVL(T.SERVERID, 0) SERVERID,
                            0 AS ROLELEVEL
                       FROM T_DW_100197_REWARD T
                      WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                        AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
                      GROUP BY TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD'),
                               T.APPID,
                               T.CHANNELID,
                               T.DVID,
                               T.SERVERID) C
              INNER JOIN T_100197_NU_MAC N
                 ON N.DVID = C.DVID
                AND N.SERVERID = C.SERVERID
                AND N.CHANNELID = C.CHANNELID
               LEFT JOIN T_100197_NU_PAY_MAC NP
                 ON NP.DVID = N.DVID
                AND N.SERVERID = NP.SERVERID
                AND N.CHANNELID = NP.CHANNELID
              INNER JOIN T_100197_NU_MAC_ALLSERVER NA
                 ON NA.DVID = C.DVID
                AND NA.CHANNELID = C.CHANNELID) T
      ON (D.GAMEID = T.APPID AND D.CHANNELID = T.CHANNELID AND D.SERVERID = T.SERVERID AND D.DVID = T.DVID AND D.CONNDATE = T.CONNDATE)
      WHEN NOT MATCHED THEN
        INSERT
          (CONNDATE,
           GAMEID,
           CHANNELID,
           GAMEVERSION,
           SERVERID,
           ROLELEVEL,
           DVID,
           REGDATE,
           ISPAY,
           REGDATE_AS)
        VALUES
          (T.CONNDATE,
           T.APPID,
           T.CHANNELID,
           T.GAMEVERSION,
           T.SERVERID,
           T.ROLELEVEL,
           T.DVID,
           T.REGDATE,
           T.ISPAY,
           T.REGDATE_AS);
      COMMIT;
       E_DATE:=SYSDATE;
      INSERT INTO temp_t_100197_recording(strat_date,end_date,errposition)
       VALUES(S_DATE,E_DATE,V_ERRPOSITION);
       COMMIT;
       
      V_ERRPOSITION := '1-6';
      S_DATE:=SYSDATE;
      --���ѵ�ͳ��CONSUME����ϴ�����豸
      MERGE INTO T_100197_CONN_MAC D
      USING (SELECT C.THEDATE AS CONNDATE,
                    C.APPID,
                    C.CHANNELID,
                    NVL(C.GAMEVERSION, 0) AS GAMEVERSION,
                    NVL(C.SERVERID, 0) SERVERID,
                    C.ROLELEVEL AS ROLELEVEL,
                    C.DVID,
                    TO_CHAR(N.THEDATE, 'YYYY-MM-DD') AS REGDATE,
                    CASE
                      WHEN NP.DVID IS NULL THEN
                       0
                      ELSE
                       1
                    END AS ISPAY,
                    TO_CHAR(NA.THEDATE, 'YYYY-MM-DD') AS REGDATE_AS
               FROM (SELECT /*+parallel(t,4)*/ 
                            TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD') AS THEDATE,
                            T.APPID,
                            T.CHANNELID,
                            MIN(T.GAMEVERSION) AS GAMEVERSION,
                            T.DVID,
                            NVL(T.SERVERID, 0) SERVERID,
                            0 AS ROLELEVEL
                       FROM T_DW_100197_CONSUME T
                      WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                        AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
                      GROUP BY TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD'),
                               T.APPID,
                               T.CHANNELID,
                               T.DVID,
                               T.SERVERID) C
              INNER JOIN T_100197_NU_MAC N
                 ON N.DVID = C.DVID
                AND N.SERVERID = C.SERVERID
                AND N.CHANNELID = C.CHANNELID
               LEFT JOIN T_100197_NU_PAY_MAC NP
                 ON NP.DVID = N.DVID
                AND N.SERVERID = NP.SERVERID
                AND N.CHANNELID = NP.CHANNELID
              INNER JOIN T_100197_NU_MAC_ALLSERVER NA
                 ON NA.DVID = C.DVID
                AND NA.CHANNELID = C.CHANNELID) T
      ON (D.GAMEID = T.APPID AND D.CHANNELID = T.CHANNELID AND D.SERVERID = T.SERVERID AND D.DVID = T.DVID AND D.CONNDATE = T.CONNDATE)
      WHEN NOT MATCHED THEN
        INSERT
          (CONNDATE,
           GAMEID,
           CHANNELID,
           GAMEVERSION,
           SERVERID,
           ROLELEVEL,
           DVID,
           REGDATE,
           ISPAY,
           REGDATE_AS)
        VALUES
          (T.CONNDATE,
           T.APPID,
           T.CHANNELID,
           T.GAMEVERSION,
           T.SERVERID,
           T.ROLELEVEL,
           T.DVID,
           T.REGDATE,
           T.ISPAY,
           T.REGDATE_AS);
      COMMIT;
       E_DATE:=SYSDATE;
      INSERT INTO temp_t_100197_recording(strat_date,end_date,errposition)
       VALUES(S_DATE,E_DATE,V_ERRPOSITION);
       COMMIT;
      V_ERRPOSITION := '1-7';
      S_DATE:=SYSDATE;
      --����ؿ�MISSION����ϴ�����豸
      MERGE INTO T_100197_CONN_MAC D
      USING (SELECT C.THEDATE AS CONNDATE,
                    C.APPID,
                    C.CHANNELID,
                    NVL(C.GAMEVERSION, 0) AS GAMEVERSION,
                    NVL(C.SERVERID, 0) SERVERID,
                    C.ROLELEVEL AS ROLELEVEL,
                    C.DVID,
                    TO_CHAR(N.THEDATE, 'YYYY-MM-DD') AS REGDATE,
                    CASE
                      WHEN NP.DVID IS NULL THEN
                       0
                      ELSE
                       1
                    END AS ISPAY,
                    TO_CHAR(NA.THEDATE, 'YYYY-MM-DD') AS REGDATE_AS
               FROM (SELECT /*+parallel(t,4)*/ 
                            TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD') AS THEDATE,
                            T.APPID,
                            T.CHANNELID,
                            MIN(T.GAMEVERSION) AS GAMEVERSION,
                            T.DVID,
                            NVL(T.SERVERID, 0) SERVERID,
                            0 AS ROLELEVEL
                       FROM T_DW_100197_MISSION T
                      WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                        AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
                      GROUP BY TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD'),
                               T.APPID,
                               T.CHANNELID,
                               T.DVID,
                               T.SERVERID) C
              INNER JOIN T_100197_NU_MAC N
                 ON N.DVID = C.DVID
                AND N.SERVERID = C.SERVERID
                AND N.CHANNELID = C.CHANNELID
               LEFT JOIN T_100197_NU_PAY_MAC NP
                 ON NP.DVID = N.DVID
                AND N.SERVERID = NP.SERVERID
                AND N.CHANNELID = NP.CHANNELID
              INNER JOIN T_100197_NU_MAC_ALLSERVER NA
                 ON NA.DVID = C.DVID
                AND NA.CHANNELID = C.CHANNELID) T
      ON (D.GAMEID = T.APPID AND D.CHANNELID = T.CHANNELID AND D.SERVERID = T.SERVERID AND D.DVID = T.DVID AND D.CONNDATE = T.CONNDATE)
      WHEN NOT MATCHED THEN
        INSERT
          (CONNDATE,
           GAMEID,
           CHANNELID,
           GAMEVERSION,
           SERVERID,
           ROLELEVEL,
           DVID,
           REGDATE,
           ISPAY,
           REGDATE_AS)
        VALUES
          (T.CONNDATE,
           T.APPID,
           T.CHANNELID,
           T.GAMEVERSION,
           T.SERVERID,
           T.ROLELEVEL,
           T.DVID,
           T.REGDATE,
           T.ISPAY,
           T.REGDATE_AS);
      COMMIT;
       E_DATE:=SYSDATE;
      INSERT INTO temp_t_100197_recording(strat_date,end_date,errposition)
       VALUES(S_DATE,E_DATE,V_ERRPOSITION);
       COMMIT;
       
      V_ERRPOSITION := '1-8';
      S_DATE:=SYSDATE;
      --�Զ���ͳ��CEVENT����ϴ�����豸
      MERGE INTO T_100197_CONN_MAC D
      USING (SELECT C.THEDATE AS CONNDATE,
                    C.APPID,
                    C.CHANNELID,
                    NVL(C.GAMEVERSION, 0) AS GAMEVERSION,
                    NVL(C.SERVERID, 0) SERVERID,
                    C.ROLELEVEL AS ROLELEVEL,
                    C.DVID,
                    TO_CHAR(N.THEDATE, 'YYYY-MM-DD') AS REGDATE,
                    CASE
                      WHEN NP.DVID IS NULL THEN
                       0
                      ELSE
                       1
                    END AS ISPAY,
                    TO_CHAR(NA.THEDATE, 'YYYY-MM-DD') AS REGDATE_AS
               FROM (SELECT TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD') AS THEDATE,
                            T.APPID,
                            T.CHANNELID,
                            MIN(T.GAMEVERSION) AS GAMEVERSION,
                            T.DVID,
                            NVL(T.SERVERID, 0) SERVERID,
                            NVL(MAX(T.ILEVEL), 0) AS ROLELEVEL
                       FROM T_DW_100197_CEVENT T
                      WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                        AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
                      GROUP BY TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD'),
                               T.APPID,
                               T.CHANNELID,
                               T.DVID,
                               T.SERVERID) C
              INNER JOIN T_100197_NU_MAC N
                 ON N.DVID = C.DVID
                AND N.SERVERID = C.SERVERID
                AND N.CHANNELID = C.CHANNELID
               LEFT JOIN T_100197_NU_PAY_MAC NP
                 ON NP.DVID = N.DVID
                AND N.SERVERID = NP.SERVERID
                AND N.CHANNELID = NP.CHANNELID
              INNER JOIN T_100197_NU_MAC_ALLSERVER NA
                 ON NA.DVID = C.DVID
                AND NA.CHANNELID = C.CHANNELID) T
      ON (D.GAMEID = T.APPID AND D.CHANNELID = T.CHANNELID AND D.SERVERID = T.SERVERID AND D.DVID = T.DVID AND D.CONNDATE = T.CONNDATE)
      WHEN NOT MATCHED THEN
        INSERT
          (CONNDATE,
           GAMEID,
           CHANNELID,
           GAMEVERSION,
           SERVERID,
           ROLELEVEL,
           DVID,
           REGDATE,
           ISPAY,
           REGDATE_AS)
        VALUES
          (T.CONNDATE,
           T.APPID,
           T.CHANNELID,
           T.GAMEVERSION,
           T.SERVERID,
           T.ROLELEVEL,
           T.DVID,
           T.REGDATE,
           T.ISPAY,
           T.REGDATE_AS);
      COMMIT;
      E_DATE:=SYSDATE;
      INSERT INTO temp_t_100197_recording(strat_date,end_date,errposition)
       VALUES(S_DATE,E_DATE,V_ERRPOSITION);
       COMMIT;
       
      V_ERRPOSITION :='1-9';
      --�˺�
      DELETE FROM T_100197_CONN T
       WHERE T.CONNDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
      COMMIT;

      V_ERRPOSITION := '1-10';
      S_DATE:=SYSDATE;
      --��¼LOGIN����ϴ�����û�
      execute immediate' TRUNCATE  TABLE TEMP_T_DW_100197_CONN';
      INSERT /*+append*/ INTO TEMP_T_DW_100197_CONN
      SELECT 
          TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD') AS THEDATE,
          T.APPID,
          T.CHANNELID,
          MIN(T.GAMEVERSION) AS GAMEVERSION,
          NVL(T.ACCOUNTID, 0) ACCOUNTID,
          NVL(T.SERVERID, 0) SERVERID,
          NVL(MAX(T.ILEVEL), 0) AS ROLELEVEL
     FROM T_DW_100197_LOGIN T
    WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
      AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
    GROUP BY TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD'),
             T.APPID,
             T.CHANNELID,
             T.ACCOUNTID,
             T.SERVERID
      ;
      COMMIT
      ;
      MERGE INTO T_100197_CONN D
      USING (SELECT C.THEDATE AS CONNDATE,
                    C.APPID,
                    C.CHANNELID,
                    NVL(C.GAMEVERSION, 0) AS GAMEVERSION,
                    NVL(C.SERVERID, 0) SERVERID,
                    C.ROLELEVEL AS ROLELEVEL,
                    C.ACCOUNTID,
                    TO_CHAR(N.THEDATE, 'YYYY-MM-DD') AS REGDATE,
                    CASE
                      WHEN NP.ACCOUNTID IS NULL THEN
                       0
                      ELSE
                       1
                    END AS ISPAY,
                    TO_CHAR(NA.THEDATE, 'YYYY-MM-DD') AS REGDATE_AS
               FROM TEMP_T_DW_100197_CONN C
              INNER JOIN T_100197_NU N
                 ON N.ACCOUNTID = C.ACCOUNTID
                AND N.SERVERID = C.SERVERID
                AND N.CHANNELID = C.CHANNELID
               LEFT JOIN T_100197_NU_PAY NP
                 ON NP.ACCOUNTID = N.ACCOUNTID
                AND N.SERVERID = NP.SERVERID
                AND N.CHANNELID = NP.CHANNELID
              INNER JOIN T_100197_NU_ALLSERVER NA
                 ON NA.ACCOUNTID = C.ACCOUNTID
                AND NA.CHANNELID = C.CHANNELID) T
      ON (D.GAMEID = T.APPID AND D.CHANNELID = T.CHANNELID AND D.SERVERID = T.SERVERID AND D.ACCOUNTID = T.ACCOUNTID AND D.CONNDATE = T.CONNDATE)
      WHEN NOT MATCHED THEN
        INSERT
          (CONNDATE,
           GAMEID,
           CHANNELID,
           GAMEVERSION,
           SERVERID,
           ROLELEVEL,
           ACCOUNTID,
           REGDATE,
           ISPAY,
           REGDATE_AS)
        VALUES
          (T.CONNDATE,
           T.APPID,
           T.CHANNELID,
           T.GAMEVERSION,
           T.SERVERID,
           T.ROLELEVEL,
           T.ACCOUNTID,
           T.REGDATE,
           T.ISPAY,
           T.REGDATE_AS);
      COMMIT;
       E_DATE:=SYSDATE;
      INSERT INTO temp_t_100197_recording(strat_date,end_date,errposition)
       VALUES(S_DATE,E_DATE,V_ERRPOSITION);
       COMMIT;
       
      V_ERRPOSITION := '1-11';
      S_DATE:=SYSDATE;
      --�ǳ�LOGOUT����ϴ�����û�
      MERGE INTO T_100197_CONN D
      USING (SELECT C.THEDATE AS CONNDATE,
                    C.APPID,
                    C.CHANNELID,
                    NVL(C.GAMEVERSION, 0) AS GAMEVERSION,
                    NVL(C.SERVERID, 0) SERVERID,
                    C.ROLELEVEL AS ROLELEVEL,
                    C.ACCOUNTID,
                    TO_CHAR(N.THEDATE, 'YYYY-MM-DD') AS REGDATE,
                    CASE
                      WHEN NP.ACCOUNTID IS NULL THEN
                       0
                      ELSE
                       1
                    END AS ISPAY,
                    TO_CHAR(NA.THEDATE, 'YYYY-MM-DD') AS REGDATE_AS
               FROM (SELECT TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD') AS THEDATE,
                            T.APPID,
                            T.CHANNELID,
                            MIN(T.GAMEVERSION) AS GAMEVERSION,
                            NVL(T.ACCOUNTID, 0) ACCOUNTID,
                            NVL(T.SERVERID, 0) SERVERID,
                            NVL(MAX(T.ILEVEL), 0) AS ROLELEVEL
                       FROM T_DW_100197_LOGOUT T
                      WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                        AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
                      GROUP BY TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD'),
                               T.APPID,
                               T.CHANNELID,
                               T.ACCOUNTID,
                               T.SERVERID) C
              INNER JOIN T_100197_NU N
                 ON N.ACCOUNTID = C.ACCOUNTID
                AND N.SERVERID = C.SERVERID
                AND N.CHANNELID = C.CHANNELID
               LEFT JOIN T_100197_NU_PAY NP
                 ON NP.ACCOUNTID = N.ACCOUNTID
                AND N.SERVERID = NP.SERVERID
                AND N.CHANNELID = NP.CHANNELID
              INNER JOIN T_100197_NU_ALLSERVER NA
                 ON NA.ACCOUNTID = C.ACCOUNTID
                AND NA.CHANNELID = C.CHANNELID) T
      ON (D.GAMEID = T.APPID AND D.CHANNELID = T.CHANNELID AND D.SERVERID = T.SERVERID AND D.ACCOUNTID = T.ACCOUNTID AND D.CONNDATE = T.CONNDATE)
      WHEN NOT MATCHED THEN
        INSERT
          (CONNDATE,
           GAMEID,
           CHANNELID,
           GAMEVERSION,
           SERVERID,
           ROLELEVEL,
           ACCOUNTID,
           REGDATE,
           ISPAY,
           REGDATE_AS)
        VALUES
          (T.CONNDATE,
           T.APPID,
           T.CHANNELID,
           T.GAMEVERSION,
           T.SERVERID,
           T.ROLELEVEL,
           T.ACCOUNTID,
           T.REGDATE,
           T.ISPAY,
           T.REGDATE_AS);
      COMMIT;
      E_DATE:=SYSDATE;
      INSERT INTO temp_t_100197_recording(strat_date,end_date,errposition)
       VALUES(S_DATE,E_DATE,V_ERRPOSITION);
       COMMIT;
       
      V_ERRPOSITION := '1-12';
      S_DATE:=SYSDATE;
      --����PAY����ϴ�����û�
      execute immediate' TRUNCATE  TABLE TEMP_T_DW_100197_CONN';
      INSERT /*+append*/ INTO TEMP_T_DW_100197_CONN
      SELECT  
          TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD') AS THEDATE,
          T.APPID,
          T.CHANNELID,
          MIN(T.GAMEVERSION) AS GAMEVERSION,
          NVL(T.ACCOUNTID, 0) ACCOUNTID,
          NVL(T.SERVERID, 0) SERVERID,
          0 AS ROLELEVEL
     FROM T_DW_100197_PAY T
    WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
      AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
    GROUP BY TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD'),
             T.APPID,
             T.CHANNELID,
             T.ACCOUNTID,
             T.SERVERID
     ;
     COMMIT
     ;
      MERGE INTO T_100197_CONN D
      USING (SELECT C.THEDATE AS CONNDATE,
                    C.APPID,
                    C.CHANNELID,
                    NVL(C.GAMEVERSION, 0) AS GAMEVERSION,
                    NVL(C.SERVERID, 0) SERVERID,
                    C.ROLELEVEL AS ROLELEVEL,
                    C.ACCOUNTID,
                    TO_CHAR(N.THEDATE, 'YYYY-MM-DD') AS REGDATE,
                    CASE
                      WHEN NP.ACCOUNTID IS NULL THEN
                       0
                      ELSE
                       1
                    END AS ISPAY,
                    TO_CHAR(NA.THEDATE, 'YYYY-MM-DD') AS REGDATE_AS
               FROM TEMP_T_DW_100197_CONN C
              INNER JOIN T_100197_NU N
                 ON N.ACCOUNTID = C.ACCOUNTID
                AND N.SERVERID = C.SERVERID
                AND N.CHANNELID = C.CHANNELID
               LEFT JOIN T_100197_NU_PAY NP
                 ON NP.ACCOUNTID = N.ACCOUNTID
                AND N.SERVERID = NP.SERVERID
                AND N.CHANNELID = NP.CHANNELID
              INNER JOIN T_100197_NU_ALLSERVER NA
                 ON NA.ACCOUNTID = C.ACCOUNTID
                AND NA.CHANNELID = C.CHANNELID) T
      ON (D.GAMEID = T.APPID AND D.CHANNELID = T.CHANNELID AND D.SERVERID = T.SERVERID AND D.ACCOUNTID = T.ACCOUNTID AND D.CONNDATE = T.CONNDATE)
      WHEN NOT MATCHED THEN
        INSERT
          (CONNDATE,
           GAMEID,
           CHANNELID,
           GAMEVERSION,
           SERVERID,
           ROLELEVEL,
           ACCOUNTID,
           REGDATE,
           ISPAY,
           REGDATE_AS)
        VALUES
          (T.CONNDATE,
           T.APPID,
           T.CHANNELID,
           T.GAMEVERSION,
           T.SERVERID,
           T.ROLELEVEL,
           T.ACCOUNTID,
           T.REGDATE,
           T.ISPAY,
           T.REGDATE_AS);
      COMMIT;
       E_DATE:=SYSDATE;
      INSERT INTO temp_t_100197_recording(strat_date,end_date,errposition)
       VALUES(S_DATE,E_DATE,V_ERRPOSITION);
       COMMIT;
       
      V_ERRPOSITION := '1-13';
      --���������REWARD����ϴ�����û�
      S_DATE:=SYSDATE;
      execute immediate' TRUNCATE  TABLE TEMP_T_DW_100197_CONN';
      INSERT /*+append*/ INTO TEMP_T_DW_100197_CONN
      SELECT 
          TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD') AS THEDATE,
          T.APPID,
          T.CHANNELID,
          MIN(T.GAMEVERSION) AS GAMEVERSION,
          NVL(T.ACCOUNTID, 0) ACCOUNTID,
          NVL(T.SERVERID, 0) SERVERID,
          0 AS ROLELEVEL
      FROM 
          T_DW_100197_REWARD T
      WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
        AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
      GROUP BY TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD'),
               T.APPID,
               T.CHANNELID,
               T.ACCOUNTID,
               T.SERVERID
      ;
      COMMIT
      ;       
      MERGE INTO T_100197_CONN D
      USING ( SELECT C.THEDATE AS CONNDATE,
                    C.APPID,
                    C.CHANNELID,
                    NVL(C.GAMEVERSION, 0) AS GAMEVERSION,
                    NVL(C.SERVERID, 0) SERVERID,
                    C.ROLELEVEL AS ROLELEVEL,
                    C.ACCOUNTID,
                    TO_CHAR(N.THEDATE, 'YYYY-MM-DD') AS REGDATE,
                    CASE
                      WHEN NP.ACCOUNTID IS NULL THEN
                       0
                      ELSE
                       1
                    END AS ISPAY,
                    TO_CHAR(NA.THEDATE, 'YYYY-MM-DD') AS REGDATE_AS
               FROM TEMP_T_DW_100197_CONN  C
              INNER JOIN T_100197_NU N
                 ON N.ACCOUNTID = C.ACCOUNTID
                AND N.SERVERID = C.SERVERID
                AND N.CHANNELID = C.CHANNELID
               LEFT JOIN T_100197_NU_PAY NP
                 ON NP.ACCOUNTID = N.ACCOUNTID
                AND N.SERVERID = NP.SERVERID
                AND N.CHANNELID = NP.CHANNELID
              INNER JOIN T_100197_NU_ALLSERVER NA
                 ON NA.ACCOUNTID = C.ACCOUNTID
                AND NA.CHANNELID = C.CHANNELID) T
      ON (D.GAMEID = T.APPID AND D.CHANNELID = T.CHANNELID AND D.SERVERID = T.SERVERID AND D.ACCOUNTID = T.ACCOUNTID AND D.CONNDATE = T.CONNDATE)
      WHEN NOT MATCHED THEN
        INSERT
          (CONNDATE,
           GAMEID,
           CHANNELID,
           GAMEVERSION,
           SERVERID,
           ROLELEVEL,
           ACCOUNTID,
           REGDATE,
           ISPAY,
           REGDATE_AS)
        VALUES
          (T.CONNDATE,
           T.APPID,
           T.CHANNELID,
           T.GAMEVERSION,
           T.SERVERID,
           T.ROLELEVEL,
           T.ACCOUNTID,
           T.REGDATE,
           T.ISPAY,
           T.REGDATE_AS);
      COMMIT;
       E_DATE:=SYSDATE;
      INSERT INTO temp_t_100197_recording(strat_date,end_date,errposition)
       VALUES(S_DATE,E_DATE,V_ERRPOSITION);
       COMMIT;
       
      V_ERRPOSITION := '1-14';
      S_DATE:=SYSDATE;
      --���ѵ�ͳ��CONSUME����ϴ�����û�
      execute immediate' TRUNCATE  TABLE TEMP_T_DW_100197_CONN';
      INSERT /*+append*/ INTO TEMP_T_DW_100197_CONN
          SELECT  
              TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD') AS THEDATE,
              T.APPID,
              T.CHANNELID,
              MIN(T.GAMEVERSION) AS GAMEVERSION,
              NVL(T.ACCOUNTID, 0) ACCOUNTID,
              NVL(T.SERVERID, 0) SERVERID,
              0 AS ROLELEVEL
         FROM T_DW_100197_CONSUME T
        WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
          AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
        GROUP BY TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD'),
                 T.APPID,
                 T.CHANNELID,
                 T.ACCOUNTID,
                 T.SERVERID
       ;
       COMMIT
       ;
      MERGE INTO T_100197_CONN D
      USING (SELECT C.THEDATE AS CONNDATE,
                    C.APPID,
                    C.CHANNELID,
                    NVL(C.GAMEVERSION, 0) AS GAMEVERSION,
                    NVL(C.SERVERID, 0) SERVERID,
                    C.ROLELEVEL AS ROLELEVEL,
                    C.ACCOUNTID,
                    TO_CHAR(N.THEDATE, 'YYYY-MM-DD') AS REGDATE,
                    CASE
                      WHEN NP.ACCOUNTID IS NULL THEN
                       0
                      ELSE
                       1
                    END AS ISPAY,
                    TO_CHAR(NA.THEDATE, 'YYYY-MM-DD') AS REGDATE_AS
               FROM TEMP_T_DW_100197_CONN C
              INNER JOIN T_100197_NU N
                 ON N.ACCOUNTID = C.ACCOUNTID
                AND N.SERVERID = C.SERVERID
                AND N.CHANNELID = C.CHANNELID
               LEFT JOIN T_100197_NU_PAY NP
                 ON NP.ACCOUNTID = N.ACCOUNTID
                AND N.SERVERID = NP.SERVERID
                AND N.CHANNELID = NP.CHANNELID
              INNER JOIN T_100197_NU_ALLSERVER NA
                 ON NA.ACCOUNTID = C.ACCOUNTID
                AND NA.CHANNELID = C.CHANNELID) T
      ON (D.GAMEID = T.APPID AND D.CHANNELID = T.CHANNELID AND D.SERVERID = T.SERVERID AND D.ACCOUNTID = T.ACCOUNTID AND D.CONNDATE = T.CONNDATE)
      WHEN NOT MATCHED THEN
        INSERT
          (CONNDATE,
           GAMEID,
           CHANNELID,
           GAMEVERSION,
           SERVERID,
           ROLELEVEL,
           ACCOUNTID,
           REGDATE,
           ISPAY,
           REGDATE_AS)
        VALUES
          (T.CONNDATE,
           T.APPID,
           T.CHANNELID,
           T.GAMEVERSION,
           T.SERVERID,
           T.ROLELEVEL,
           T.ACCOUNTID,
           T.REGDATE,
           T.ISPAY,
           T.REGDATE_AS);
      COMMIT;
       E_DATE:=SYSDATE;
      INSERT INTO temp_t_100197_recording(strat_date,end_date,errposition)
       VALUES(S_DATE,E_DATE,V_ERRPOSITION);
       COMMIT;
       
       
      V_ERRPOSITION := '1-15';
      S_DATE:=SYSDATE;
      --����ؿ�MISSION����ϴ�����û�
      execute immediate' TRUNCATE  TABLE TEMP_T_DW_100197_CONN';
      INSERT /*+append*/ INTO TEMP_T_DW_100197_CONN
          SELECT 
              TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD') AS THEDATE,
              T.APPID,
              T.CHANNELID,
              MIN(T.GAMEVERSION) AS GAMEVERSION,
              NVL(T.ACCOUNTID, 0) ACCOUNTID,
              NVL(T.SERVERID, 0) SERVERID,
              0 AS ROLELEVEL
         FROM T_DW_100197_MISSION T
        WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
          AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
        GROUP BY TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD'),
                 T.APPID,
                 T.CHANNELID,
                 T.ACCOUNTID,
                 T.SERVERID
      ;
      COMMIT
      ;
      MERGE INTO T_100197_CONN D
      USING (SELECT C.THEDATE AS CONNDATE,
                    C.APPID,
                    C.CHANNELID,
                    NVL(C.GAMEVERSION, 0) AS GAMEVERSION,
                    NVL(C.SERVERID, 0) SERVERID,
                    C.ROLELEVEL AS ROLELEVEL,
                    C.ACCOUNTID,
                    TO_CHAR(N.THEDATE, 'YYYY-MM-DD') AS REGDATE,
                    CASE
                      WHEN NP.ACCOUNTID IS NULL THEN
                       0
                      ELSE
                       1
                    END AS ISPAY,
                    TO_CHAR(NA.THEDATE, 'YYYY-MM-DD') AS REGDATE_AS
               FROM TEMP_T_DW_100197_CONN  C
              INNER JOIN T_100197_NU N
                 ON N.ACCOUNTID = C.ACCOUNTID
                AND N.SERVERID = C.SERVERID
                AND N.CHANNELID = C.CHANNELID
               LEFT JOIN T_100197_NU_PAY NP
                 ON NP.ACCOUNTID = N.ACCOUNTID
                AND N.SERVERID = NP.SERVERID
                AND N.CHANNELID = NP.CHANNELID
              INNER JOIN T_100197_NU_ALLSERVER NA
                 ON NA.ACCOUNTID = C.ACCOUNTID
                AND NA.CHANNELID = C.CHANNELID) T
      ON (D.GAMEID = T.APPID AND D.CHANNELID = T.CHANNELID AND D.SERVERID = T.SERVERID AND D.ACCOUNTID = T.ACCOUNTID AND D.CONNDATE = T.CONNDATE)
      WHEN NOT MATCHED THEN
        INSERT
          (CONNDATE,
           GAMEID,
           CHANNELID,
           GAMEVERSION,
           SERVERID,
           ROLELEVEL,
           ACCOUNTID,
           REGDATE,
           ISPAY,
           REGDATE_AS)
        VALUES
          (T.CONNDATE,
           T.APPID,
           T.CHANNELID,
           T.GAMEVERSION,
           T.SERVERID,
           T.ROLELEVEL,
           T.ACCOUNTID,
           T.REGDATE,
           T.ISPAY,
           T.REGDATE_AS);
      COMMIT;
       E_DATE:=SYSDATE;
      INSERT INTO temp_t_100197_recording(strat_date,end_date,errposition)
       VALUES(S_DATE,E_DATE,V_ERRPOSITION);
       COMMIT;
       
      V_ERRPOSITION := '1-16';
      S_DATE:=SYSDATE;
      --�Զ���ͳ��CEVENT����ϴ�����û�
      MERGE INTO T_100197_CONN D
      USING (SELECT C.THEDATE AS CONNDATE,
                    C.APPID,
                    C.CHANNELID,
                    NVL(C.GAMEVERSION, 0) AS GAMEVERSION,
                    NVL(C.SERVERID, 0) SERVERID,
                    C.ROLELEVEL AS ROLELEVEL,
                    C.ACCOUNTID,
                    TO_CHAR(N.THEDATE, 'YYYY-MM-DD') AS REGDATE,
                    CASE
                      WHEN NP.ACCOUNTID IS NULL THEN
                       0
                      ELSE
                       1
                    END AS ISPAY,
                    TO_CHAR(NA.THEDATE, 'YYYY-MM-DD') AS REGDATE_AS
               FROM (SELECT TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD') AS THEDATE,
                            T.APPID,
                            T.CHANNELID,
                            MIN(T.GAMEVERSION) AS GAMEVERSION,
                            NVL(T.ACCOUNTID, 0) ACCOUNTID,
                            NVL(T.SERVERID, 0) SERVERID,
                            NVL(MAX(T.ILEVEL), 0) AS ROLELEVEL
                       FROM T_DW_100197_CEVENT T
                      WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                        AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
                      GROUP BY TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD'),
                               T.APPID,
                               T.CHANNELID,
                               T.ACCOUNTID,
                               T.SERVERID) C
              INNER JOIN T_100197_NU N
                 ON N.ACCOUNTID = C.ACCOUNTID
                AND N.SERVERID = C.SERVERID
                AND N.CHANNELID = C.CHANNELID
               LEFT JOIN T_100197_NU_PAY NP
                 ON NP.ACCOUNTID = N.ACCOUNTID
                AND N.SERVERID = NP.SERVERID
                AND N.CHANNELID = NP.CHANNELID
              INNER JOIN T_100197_NU_ALLSERVER NA
                 ON NA.ACCOUNTID = C.ACCOUNTID
                AND NA.CHANNELID = C.CHANNELID) T
      ON (D.GAMEID = T.APPID AND D.CHANNELID = T.CHANNELID AND D.SERVERID = T.SERVERID AND D.ACCOUNTID = T.ACCOUNTID AND D.CONNDATE = T.CONNDATE)
      WHEN NOT MATCHED THEN
        INSERT
          (CONNDATE,
           GAMEID,
           CHANNELID,
           GAMEVERSION,
           SERVERID,
           ROLELEVEL,
           ACCOUNTID,
           REGDATE,
           ISPAY,
           REGDATE_AS)
        VALUES
          (T.CONNDATE,
           T.APPID,
           T.CHANNELID,
           T.GAMEVERSION,
           T.SERVERID,
           T.ROLELEVEL,
           T.ACCOUNTID,
           T.REGDATE,
           T.ISPAY,
           T.REGDATE_AS);
      COMMIT;
       E_DATE:=SYSDATE;
      INSERT INTO temp_t_100197_recording(strat_date,end_date,errposition)
       VALUES(S_DATE,E_DATE,V_ERRPOSITION);
       COMMIT;
    END IF;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_100197_CONN_MAC';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  --�����˺ţ��豸����
  PROCEDURE SP_CONN_ACT(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    INPUTDATE      NUMBER;
  BEGIN
    INPUTDATE := 0;
    P_ERRCODE := 7100;

    IF SUBSTR(P_LOGTIME, 12, 2) = '23' THEN
      SELECT TRUNC(SYSDATE) -
             TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
        INTO INPUTDATE
        FROM DUAL;
      ------------------------------ִ����־��ʼ----------------------------------------------
      V_ERRSOURCE := 'PKG_BASE_DATA_100197.SP_CONN_ACT';
      PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', INPUTDATE);
      ------------------------------ִ����־��ʼ----------------------------------------------

      V_ERRPOSITION := '1-1';
      --�豸
      DELETE FROM T_100197_CONN_ACT_MAC T
       WHERE T.CONNDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
      COMMIT;

      V_ERRPOSITION := '1-2';
      INSERT INTO T_100197_CONN_ACT_MAC
        (BASEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         SERVERID,
         ROLELEVEL,
         POSITION,
         DVID,
         CONNDATE,
         ISPAY)
        SELECT R.CONNDATE AS BASEDATE,
               R.GAMEID,
               R.CHANNELID,
               NVL(MAX(T.GAMEVERSION), 0) AS GAMEVERSION,
               NVL(R.SERVERID, 0),
               MAX(T.ROLELEVEL) AS ROLELEVEL,
               '' AS POSITION,
               T.DVID,
               T.CONNDATE AS CONNDATE,
               T.ISPAY
          FROM T_100197_CONN_MAC T
         INNER JOIN (SELECT T1.CONNDATE,
                            T1.GAMEID,
                            T1.CHANNELID,
                            T1.GAMEVERSION,
                            T1.SERVERID,
                            T1.ROLELEVEL,
                            T1.POSITION,
                            T1.DVID,
                            T1.ISPAY
                       FROM T_100197_CONN_MAC T1
                      WHERE T1.CONNDATE <=
                            TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
                        AND T1.CONNDATE >=
                            TO_CHAR(SYSDATE - INPUTDATE - 31, 'YYYY-MM-DD')) R
            ON R.DVID = T.DVID
           AND T.GAMEID = R.GAMEID
           AND T.SERVERID = R.SERVERID
           AND T.CHANNELID = R.CHANNELID
         WHERE T.CONNDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         GROUP BY R.CONNDATE,
                  R.GAMEID,
                  R.CHANNELID,
                  R.SERVERID,
                  T.CONNDATE,
                  T.ISPAY,
                  T.DVID;
      COMMIT;

      V_ERRPOSITION := '1-3';
      --�˺�
      DELETE FROM T_100197_CONN_ACT T
       WHERE T.CONNDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
      COMMIT;

      V_ERRPOSITION := '1-4';
      INSERT INTO T_100197_CONN_ACT
        (BASEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         SERVERID,
         ROLELEVEL,
         POSITION,
         ACCOUNTID,
         CONNDATE,
         ISPAY)
        SELECT R.CONNDATE AS BASEDATE,
               R.GAMEID,
               R.CHANNELID,
               MAX(T.GAMEVERSION) AS GAMEVERSION,
               NVL(R.SERVERID, 0),
               NVL(MAX(T.ROLELEVEL), 0) AS ROLELEVEL,
               '' AS POSITION,
               T.ACCOUNTID,
               T.CONNDATE AS CONNDATE,
               T.ISPAY
          FROM T_100197_CONN T
         INNER JOIN (SELECT T1.CONNDATE,
                            T1.GAMEID,
                            T1.CHANNELID,
                            T1.GAMEVERSION,
                            T1.SERVERID,
                            T1.ROLELEVEL,
                            T1.POSITION,
                            T1.ACCOUNTID,
                            T1.ISPAY
                       FROM T_100197_CONN T1
                      WHERE T1.CONNDATE <=
                            TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
                        AND T1.CONNDATE >=
                            TO_CHAR(SYSDATE - INPUTDATE - 31, 'YYYY-MM-DD')) R
            ON R.ACCOUNTID = T.ACCOUNTID
           AND T.GAMEID = R.GAMEID
           AND T.SERVERID = R.SERVERID
           AND T.CHANNELID = R.CHANNELID
         WHERE T.CONNDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         GROUP BY R.CONNDATE,
                  R.GAMEID,
                  R.CHANNELID,
                  R.SERVERID,
                  T.CONNDATE,
                  T.ISPAY,
                  T.ACCOUNTID;
      COMMIT;

      V_ERRPOSITION := '1-5';
      --�豸 ALLSERVER
      DELETE FROM T_100197_CONN_ACT_MAC_AS T
       WHERE T.CONNDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
      COMMIT;

      V_ERRPOSITION := '1-6';
      INSERT INTO T_100197_CONN_ACT_MAC_AS
        (BASEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         ROLELEVEL,
         POSITION,
         DVID,
         CONNDATE,
         ISPAY)
        SELECT R.CONNDATE AS BASEDATE,
               R.GAMEID,
               R.CHANNELID,
               NVL(MAX(T.GAMEVERSION), 0) AS GAMEVERSION,
               MAX(T.ROLELEVEL) AS ROLELEVEL,
               '' AS POSITION,
               T.DVID,
               T.CONNDATE AS CONNDATE,
               T.ISPAY
          FROM T_100197_CONN_MAC T
         INNER JOIN (SELECT T1.CONNDATE,
                            T1.GAMEID,
                            T1.CHANNELID,
                            T1.GAMEVERSION,
                            T1.ROLELEVEL,
                            T1.POSITION,
                            T1.DVID,
                            T1.ISPAY
                       FROM T_100197_CONN_MAC T1
                      WHERE T1.CONNDATE <=
                            TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
                        AND T1.CONNDATE >=
                            TO_CHAR(SYSDATE - INPUTDATE - 31, 'YYYY-MM-DD')) R
            ON R.DVID = T.DVID
           AND T.GAMEID = R.GAMEID
           AND T.CHANNELID = R.CHANNELID
         WHERE T.CONNDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         GROUP BY R.CONNDATE,
                  R.GAMEID,
                  R.CHANNELID,
                  T.CONNDATE,
                  T.ISPAY,
                  T.DVID;
      COMMIT;

      V_ERRPOSITION := '1-7';
      --�˺� ALLSERVER
      DELETE FROM T_100197_CONN_ACT_AS T
       WHERE T.CONNDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
      COMMIT;

      V_ERRPOSITION := '1-8';
      INSERT INTO T_100197_CONN_ACT_AS
        (BASEDATE,
         GAMEID,
         CHANNELID,
         GAMEVERSION,
         ROLELEVEL,
         POSITION,
         ACCOUNTID,
         CONNDATE,
         ISPAY)
        SELECT R.CONNDATE AS BASEDATE,
               R.GAMEID,
               R.CHANNELID,
               MAX(T.GAMEVERSION) AS GAMEVERSION,
               NVL(MAX(T.ROLELEVEL), 0) AS ROLELEVEL,
               '' AS POSITION,
               T.ACCOUNTID,
               T.CONNDATE AS CONNDATE,
               T.ISPAY
          FROM T_100197_CONN T
         INNER JOIN (SELECT T1.CONNDATE,
                            T1.GAMEID,
                            T1.CHANNELID,
                            T1.GAMEVERSION,
                            T1.ROLELEVEL,
                            T1.POSITION,
                            T1.ACCOUNTID,
                            T1.ISPAY
                       FROM T_100197_CONN T1
                      WHERE T1.CONNDATE <=
                            TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
                        AND T1.CONNDATE >=
                            TO_CHAR(SYSDATE - INPUTDATE - 31, 'YYYY-MM-DD')) R
            ON R.ACCOUNTID = T.ACCOUNTID
           AND T.GAMEID = R.GAMEID
           AND T.CHANNELID = R.CHANNELID
         WHERE T.CONNDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')
         GROUP BY R.CONNDATE,
                  R.GAMEID,
                  R.CHANNELID,
                  T.CONNDATE,
                  T.ISPAY,
                  T.ACCOUNTID;
      COMMIT;
    END IF;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_100197_CONN_ACT_MAC';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  --����  ��ʧ
  PROCEDURE SP_LOST(P_LOGTIME IN VARCHAR2,
                    P_ERRCODE OUT NUMBER,
                    P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    INPUTDATE      NUMBER;
  BEGIN
    INPUTDATE := 0;
    P_ERRCODE := 7100;

    IF SUBSTR(P_LOGTIME, 12, 2) = '23' THEN
      SELECT TRUNC(SYSDATE) -
             TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
        INTO INPUTDATE
        FROM DUAL;
      ------------------------------ִ����־��ʼ----------------------------------------------
      V_ERRSOURCE := 'PKG_BASE_DATA_100197.SP_LOST';
      PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', INPUTDATE);
      ------------------------------ִ����־��ʼ----------------------------------------------

      --�˺���ʧ
      V_ERRPOSITION := '1-1';
      DELETE FROM T_100197_LOST_USER T
       WHERE T.LOST_DATE =
             TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD');
      COMMIT;

      V_ERRPOSITION := '1-2';
      INSERT INTO T_100197_LOST_USER
        (STATDATE,
         LOST_DATE,
         CHANNELID,
         SERVERID,
         APPID,
         USERID,
         ISPAY,
         ROLELEVEL,
         LOST_DAYS,
         LOADDATE)
        SELECT *
          FROM (SELECT MAX(T.CONNDATE) CONNDATE,
                       TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD') LDATE,
                       T.CHANNELID,
                       NVL(T.SERVERID, 0),
                       T.GAMEID,
                       T.ACCOUNTID,
                       MAX(T.ISPAY) ISPAY,
                       MAX(T.ROLELEVEL) ROLELEVEL,
                       (TRUNC(SYSDATE - INPUTDATE) -
                       MAX(TO_DATE(T.CONNDATE, 'YYYY-MM-DD'))) LEAVE_DAYS,
                       SYSDATE
                  FROM T_100197_CONN T
                 WHERE T.CONNDATE <=
                       TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD')
                   AND T.CONNDATE >= TO_CHAR(TRUNC(SYSDATE - INPUTDATE - 100),
                                             'YYYY-MM-DD')
                 GROUP BY T.GAMEID, T.CHANNELID, T.SERVERID, T.ACCOUNTID)
         WHERE LEAVE_DAYS <> 0;
      COMMIT;

      --�豸��ʧ
      V_ERRPOSITION := '1-3';
      DELETE FROM T_100197_LOST_MAC T
       WHERE T.LOST_DATE =
             TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD');
      COMMIT;

      V_ERRPOSITION := '1-4';
      INSERT INTO T_100197_LOST_MAC
        (STATDATE,
         LOST_DATE,
         CHANNELID,
         SERVERID,
         APPID,
         MACID,
         ISPAY,
         ROLELEVEL,
         LOST_DAYS,
         LOADDATE)
        SELECT *
          FROM (SELECT MAX(T.CONNDATE) CONNDATE,
                       TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD') LDATE,
                       T.CHANNELID,
                       NVL(T.SERVERID, 0),
                       T.GAMEID,
                       T.DVID,
                       MAX(T.ISPAY) ISPAY,
                       MAX(T.ROLELEVEL) ROLELEVEL,
                       (TRUNC(SYSDATE - INPUTDATE) -
                       MAX(TO_DATE(T.CONNDATE, 'YYYY-MM-DD'))) LEAVE_DAYS,
                       SYSDATE
                  FROM T_100197_CONN_MAC T
                 WHERE T.CONNDATE <=
                       TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD')
                   AND T.CONNDATE >= TO_CHAR(TRUNC(SYSDATE - INPUTDATE - 100),
                                             'YYYY-MM-DD')
                 GROUP BY T.GAMEID, T.CHANNELID, T.SERVERID, T.DVID)
         WHERE LEAVE_DAYS <> 0;
      COMMIT;

      --ALLSERVER�˺�
      V_ERRPOSITION := '1-5';
      DELETE FROM T_100197_LOST_USER_AS T
       WHERE T.LOST_DATE =
             TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD');
      COMMIT;
      V_ERRPOSITION := '1-6';
      INSERT INTO T_100197_LOST_USER_AS
        (STATDATE,
         LOST_DATE,
         CHANNELID,
         APPID,
         USERID,
         ISPAY,
         ROLELEVEL,
         LOST_DAYS,
         LOADDATE)
        SELECT *
          FROM (SELECT MAX(T.CONNDATE) CONNDATE,
                       TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD') LDATE,
                       T.CHANNELID,
                       T.GAMEID,
                       T.ACCOUNTID,
                       MAX(T.ISPAY) ISPAY,
                       MAX(T.ROLELEVEL) ROLELEVEL,
                       (TRUNC(SYSDATE - INPUTDATE) -
                       MAX(TO_DATE(T.CONNDATE, 'YYYY-MM-DD'))) LEAVE_DAYS,
                       SYSDATE
                  FROM T_100197_CONN T
                 WHERE T.CONNDATE <=
                       TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD')
                   AND T.CONNDATE >= TO_CHAR(TRUNC(SYSDATE - INPUTDATE - 100),
                                             'YYYY-MM-DD')
                 GROUP BY T.GAMEID, T.CHANNELID, T.ACCOUNTID)
         WHERE LEAVE_DAYS <> 0;
      COMMIT;

      --ALLSERVER�豸
      V_ERRPOSITION := '1-7';
      DELETE FROM T_100197_LOST_MAC_AS T
       WHERE T.LOST_DATE =
             TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD');
      COMMIT;
      V_ERRPOSITION := '1-8';
      INSERT INTO T_100197_LOST_MAC_AS
        (STATDATE,
         LOST_DATE,
         CHANNELID,
         APPID,
         MACID,
         ISPAY,
         ROLELEVEL,
         LOST_DAYS,
         LOADDATE)
        SELECT *
          FROM (SELECT MAX(T.CONNDATE) CONNDATE,
                       TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD') LDATE,
                       T.CHANNELID,
                       T.GAMEID,
                       T.DVID,
                       MAX(T.ISPAY) ISPAY,
                       MAX(T.ROLELEVEL) ROLELEVEL,
                       (TRUNC(SYSDATE - INPUTDATE) -
                       MAX(TO_DATE(T.CONNDATE, 'YYYY-MM-DD'))) LEAVE_DAYS,
                       SYSDATE
                  FROM T_100197_CONN_MAC T
                 WHERE T.CONNDATE <=
                       TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD')
                   AND T.CONNDATE >= TO_CHAR(TRUNC(SYSDATE - INPUTDATE - 100),
                                             'YYYY-MM-DD')
                 GROUP BY T.GAMEID, T.CHANNELID, T.DVID)
         WHERE LEAVE_DAYS <> 0;
      COMMIT;
    END IF;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_100197_LOST_USER';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  --����ؿ��״ν���
  PROCEDURE SP_MISSION_FIRST(P_LOGTIME IN VARCHAR2,
                             P_ERRCODE OUT NUMBER,
                             P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    INPUTDATE      NUMBER;
  BEGIN
    INPUTDATE := 0;
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO INPUTDATE
      FROM DUAL;
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_BASE_DATA_100197.SP_MISSION_FIRST';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    V_ERRPOSITION := '1-1';
    DELETE FROM T_100197_MISS_FIRST T
     WHERE T.STATDATE = TO_CHAR(TRUNC(SYSDATE - INPUTDATE), 'YYYY-MM-DD');
    COMMIT;

    V_ERRPOSITION := '1-2';
    MERGE INTO T_100197_MISS_FIRST D
    USING (SELECT T1.STATDATE,
                  T1.CHANNELID,
                  T1.SERVERID,
                  T1.APPID,
                  T1.GAMEVERSION,
                  T1.MISSIONID,
                  T1.ACCOUNTID,
                  T2.ILEVEL,
                  '0' ROLEJOB,
                  CASE
                    WHEN T3.ACCOUNTID IS NULL THEN
                     '0'
                    ELSE
                     '1'
                  END ISSUCC
             FROM (SELECT TO_CHAR(TDM.F_LOGTIME, 'YYYY-MM-DD') STATDATE,
                          TDM.CHANNELID,
                          NVL(TDM.SERVERID, 0) SERVERID,
                          TDM.APPID,
                          NVL(MIN(TDM.GAMEVERSION), 0) GAMEVERSION,
                          TDM.MISSIONID,
                          TDM.ACCOUNTID
                     FROM T_DW_100197_MISSION TDM
                    WHERE TDM.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                      AND TDM.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
                      AND TDM.LOGTYPE = 'MISSION'
                    GROUP BY TO_CHAR(TDM.F_LOGTIME, 'YYYY-MM-DD'),
                             TDM.CHANNELID,
                             NVL(TDM.SERVERID, 0),
                             TDM.APPID,
                             TDM.MISSIONID,
                             TDM.ACCOUNTID) T1
            INNER JOIN (SELECT TO_CHAR(TDL.F_LOGTIME, 'YYYY-MM-DD') STATDATE,
                              TDL.CHANNELID,
                              NVL(TDL.SERVERID, 0) SERVERID,
                              TDL.APPID,
                              NVL(MIN(TDL.GAMEVERSION), 0) GAMEVERSION,
                              TDL.ACCOUNTID,
                              MAX(TDL.ILEVEL) ILEVEL
                         FROM T_DW_100197_LOGIN TDL
                        WHERE TDL.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                          AND TDL.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
                        GROUP BY TO_CHAR(TDL.F_LOGTIME, 'YYYY-MM-DD'),
                                 TDL.CHANNELID,
                                 NVL(TDL.SERVERID, 0),
                                 TDL.APPID,
                                 NVL(TDL.GAMEVERSION, 0),
                                 TDL.ACCOUNTID) T2
               ON T1.ACCOUNTID = T2.ACCOUNTID
            INNER JOIN (SELECT TO_CHAR(TDM.F_LOGTIME, 'YYYY-MM-DD') STATDATE,
                              TDM.CHANNELID,
                              NVL(TDM.SERVERID, 0) SERVERID,
                              TDM.APPID,
                              NVL(MIN(TDM.GAMEVERSION), 0) GAMEVERSION,
                              TDM.MISSIONID,
                              TDM.ACCOUNTID
                         FROM T_DW_100197_MISSION TDM
                        WHERE TDM.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                          AND TDM.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
                          AND TDM.LOGTYPE = 'MISSIONSUCC'
                        GROUP BY TO_CHAR(TDM.F_LOGTIME, 'YYYY-MM-DD'),
                                 TDM.CHANNELID,
                                 NVL(TDM.SERVERID, 0),
                                 TDM.APPID,
                                 TDM.MISSIONID,
                                 TDM.ACCOUNTID) T3
               ON T1.ACCOUNTID = T3.ACCOUNTID) T
    ON (D.APPID = T.APPID AND D.CHANNELID = T.CHANNELID AND D.SERVERID = T.SERVERID AND D.ACCOUNTID = T.ACCOUNTID AND D.MISSIONID = T.MISSIONID)
    WHEN NOT MATCHED THEN
      INSERT
      VALUES
        (T.STATDATE,
         T.CHANNELID,
         T.SERVERID,
         T.APPID,
         T.GAMEVERSION,
         T.MISSIONID,
         T.ACCOUNTID,
         T.ILEVEL,
         '0',
         T.ISSUCC,
         SYSDATE,
         V_ERRSOURCE);
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_100197_MISS_FIRST';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  --�豸����������
  PROCEDURE SP_DVID(P_LOGTIME IN VARCHAR2,
                    P_ERRCODE OUT NUMBER,
                    P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    INPUTDATE      NUMBER;
  BEGIN
    INPUTDATE := 0;
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO INPUTDATE
      FROM DUAL;
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_BASE_DATA_100197.SP_DVID';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    --����
    V_ERRPOSITION := '1-1';
    DELETE FROM T_100197_NU_DVID T
     WHERE T.THEDATE >= TRUNC(SYSDATE - INPUTDATE)
       AND T.THEDATE < TRUNC(SYSDATE - INPUTDATE + 1);
    COMMIT;

    V_ERRPOSITION := '1-2';
    MERGE INTO T_100197_NU_DVID N
    USING (SELECT *
             FROM (SELECT T.F_LOGTIME AS THEDATE,
                          --T.APPID AS GAMEID,
                          T.CHANNELID AS CHANNELID,
                          T.DVID,
                          T.IPADDR,
                          ROW_NUMBER() OVER(PARTITION BY T.CHANNELID, T.DVID ORDER BY T.F_LOGTIME) RANKNUM
                     FROM T_DW_100197_DEVICE T
                    WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                      AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
                      AND T.DVID IS NOT NULL)
            WHERE RANKNUM = 1) T
    ON (N.CHANNELID = T.CHANNELID AND N.DVID = T.DVID)
    WHEN NOT MATCHED THEN
      INSERT
        (THEDATE, GAMEID, CHANNELID, DVID, IPADDR)
      VALUES
        (T.THEDATE, '100197', T.CHANNELID, T.DVID, T.IPADDR);
    COMMIT;

    --����
    V_ERRPOSITION := '1-3';
    DELETE FROM T_100197_CONN_DVID T
     WHERE T.CONNDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    V_ERRPOSITION := '1-4';
    INSERT INTO T_100197_CONN_DVID
      (CONNDATE, GAMEID, CHANNELID, DVID, REGDATE)
      SELECT C.THEDATE AS CONNDATE,
             '100197',
             C.CHANNELID,
             C.DVID,
             TO_CHAR(N.THEDATE, 'YYYY-MM-DD') AS REGDATE
        FROM (SELECT TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD') AS THEDATE,
                     T.CHANNELID,
                     T.DVID
                FROM T_DW_100197_DEVICE T
               WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                 AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
               GROUP BY TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD'),
                        T.CHANNELID,
                        T.DVID) C
       INNER JOIN T_100197_NU_DVID N
          ON N.DVID = C.DVID;
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=T_100197_NU_DVID��T_100197_CONN_DVID';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  PROCEDURE SP_CEVENT(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2) IS

    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    INPUTDATE      NUMBER;
    V_PAR1         VARCHAR2(200);
    V_START_I      NUMBER := 1;
    V_END_I        NUMBER;
    V_KEY          VARCHAR2(200);
    V_VALUE        VARCHAR2(200);
  BEGIN
    INPUTDATE := 0;
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO INPUTDATE
      FROM DUAL;
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_BASE_DATA_100197.SP_CEVENT';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    V_ERRPOSITION := '1-1';
    DELETE FROM T_100197_CEVENT T
     WHERE T.THEDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    V_ERRPOSITION := '1-2';
    FOR C IN (SELECT TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD') THEDATE,
                     TO_NUMBER(TO_CHAR(T.F_LOGTIME, 'YYYYMMDDHH24MISS')) DD,
                     LENGTH(T.EVENTVALUE) -
                     LENGTH(REPLACE(T.EVENTVALUE, ',')) + 1 NUM,
                     T.*,
                     ROWID PREROWID
                FROM T_DW_100197_CEVENT T
               WHERE T.F_LOGTIME >= TRUNC(SYSDATE - INPUTDATE)
                 AND T.F_LOGTIME < TRUNC(SYSDATE - INPUTDATE + 1)
                 AND T.EVENTVALUE IS NOT NULL) LOOP

      FOR I IN 1 .. C.NUM LOOP

        V_END_I := INSTR(C.EVENTVALUE, ',', 1, I);

        IF I = C.NUM THEN
          V_PAR1 := SUBSTR(C.EVENTVALUE, V_START_I);
        ELSE
          V_PAR1 := SUBSTR(C.EVENTVALUE, V_START_I, V_END_I - V_START_I);
        END IF;

        V_START_I := V_END_I + 1;

        V_KEY   := SUBSTR(V_PAR1, 1, INSTR(V_PAR1, ':') - 1);
        V_VALUE := SUBSTR(V_PAR1, INSTR(V_PAR1, ':') + 1);

        INSERT INTO T_100197_CEVENT
        VALUES
          (C.THEDATE,
           C.DD,
           C.APPID,
           C.CHANNELID,
           NVL(C.GAMEVERSION, 0),
           C.DVID,
           C.ACCOUNTID,
           NVL(C.SERVERID, 0),
           C.ILEVEL,
           C.ROLEID,
           C.EVENTKEY,
           V_KEY,
           V_VALUE,
           C.IPADDR,
           C.PREROWID);
        COMMIT;

      END LOOP;

    END LOOP;

    V_ERRPOSITION := '1-3';
    MERGE INTO DIM_CEVENT N
    USING (SELECT DISTINCT D.APPID, D.EVENTKEY, D.EVENTVALUE_KEY
             FROM T_100197_CEVENT D
            WHERE D.THEDATE = TO_CHAR(SYSDATE - INPUTDATE, 'YYYY-MM-DD')) T
    ON (N.APPID = T.APPID AND N.CEVENTID = T.EVENTKEY AND N.CEVENTPAR = T.EVENTVALUE_KEY)
    WHEN NOT MATCHED THEN
      INSERT
        (APPID, CEVENTID, CEVENTPAR)
      VALUES
        (T.APPID, T.EVENTKEY, T.EVENTVALUE_KEY);
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  PROCEDURE SP_NULL(P_LOGTIME IN VARCHAR2,
                    P_ERRCODE OUT NUMBER,
                    P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    INPUTDATE      NUMBER;
  BEGIN
    INPUTDATE := 0;
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO INPUTDATE
      FROM DUAL;
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_BASE_DATA_100197.SP_NULL';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;
END PKG_BASE_DATA_100197;
/

prompt
prompt Creating package body PKG_FACT_100197
prompt =====================================
prompt
CREATE OR REPLACE PACKAGE BODY "PKG_FACT_100197" IS
  /******************************************����ȫ��***************************************************************/
  --����ȫ��
  PROCEDURE P_ALL(P_LOGTIME IN VARCHAR2,
                  P_ERRCODE OUT NUMBER,
                  P_ERRSTR  OUT VARCHAR2) IS
  BEGIN
    PKG_FACT_100197.P_DIM_OTHER(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_FACT_100197.P_FACT_GENERAL(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_FACT_100197.P_FACT_FIRSTPAY(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_FACT_100197.P_FACT_PAYHABIT(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_FACT_100197.P_FACT_ORDER(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_FACT_100197.P_FACT_REMAIN(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_FACT_100197.P_FACT_LOST(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_FACT_100197.P_FACT_LEVELPAY(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_FACT_100197.P_FACT_GENERAL_LEVEL(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_FACT_100197.P_FACT_LTV(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_FACT_100197.P_FACT_BACK(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_FACT_100197.P_FACT_MISS_FIRST(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_FACT_100197.P_FACT_DVID(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_FACT_100197.P_FACT_VC(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_FACT_100197.P_FACT_NET(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_FACT_100197.P_FACT_OPERATOR(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_FACT_100197.P_FACT_REGION(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_FACT_100197.P_FACT_GENERAL_DVID(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_FACT_100197.P_FACT_SUM_REP(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_FACT_100197.P_FACT_CEVENT(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_FACT_100197.P_FACT_COMP_CEVENT(P_LOGTIME, P_ERRCODE, P_ERRSTR);
    PKG_FACT_100197.P_FACT_DAILY_REPORT(P_LOGTIME, P_ERRCODE, P_ERRSTR);
  END;

  /******************************************����ά����Ϣ***************************************************************/
  --����ά����Ϣ
  PROCEDURE P_DIM_OTHER(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FACT_100197.P_DIM_OTHER';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    V_ERRPOSITION := '1-1';
    --����DIM_APPSERVER����ά����Ϣ
    MERGE INTO DIM_APPSERVER D
    USING (SELECT TN.GAMEID, DA.APPNAME, TN.SERVERID
             FROM (SELECT DISTINCT T.GAMEID, T.SERVERID
                     FROM T_100197_NU_MAC T
                    WHERE T.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND T.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)) TN
            INNER JOIN DIM_APP DA
               ON DA.APPID = TN.GAMEID) TT
    ON (D.APPID = TT.GAMEID AND D.SERVERID = TT.SERVERID)
    WHEN NOT MATCHED THEN
      INSERT
        (APPSERVERID, APPID, APPNAME, SERVERID, SERVERNAME)
      VALUES
        (TT.GAMEID || TT.SERVERID,
         TT.GAMEID,
         TT.APPNAME,
         TT.SERVERID,
         TT.SERVERID);
    COMMIT;
    --
    MERGE INTO DIM_APPSERVER D
    USING (SELECT TN.GAMEID, DA.APPNAME, TN.SERVERID
             FROM (SELECT DISTINCT T.GAMEID, T.SERVERID
                     FROM T_100197_NU T
                    WHERE T.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND T.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)) TN
            INNER JOIN DIM_APP DA
               ON DA.APPID = TN.GAMEID) TT
    ON (D.APPID = TT.GAMEID AND D.SERVERID = TT.SERVERID)
    WHEN NOT MATCHED THEN
      INSERT
        (APPSERVERID, APPID, APPNAME, SERVERID, SERVERNAME)
      VALUES
        (TT.GAMEID || TT.SERVERID,
         TT.GAMEID,
         TT.APPNAME,
         TT.SERVERID,
         TT.SERVERID);
    COMMIT;

    V_ERRPOSITION := '1-2';
    --����DIM_APPVERSION�汾ά����Ϣ
    MERGE INTO DIM_APPVERSION D
    USING (SELECT TN.GAMEID, DA.APPNAME, TN.GAMEVERSION
             FROM (SELECT DISTINCT T.GAMEID, T.GAMEVERSION
                     FROM T_100197_NU_MAC T
                    WHERE T.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND T.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)) TN
            INNER JOIN DIM_APP DA
               ON DA.APPID = TN.GAMEID) TT
    ON (D.APPID = TT.GAMEID AND D.VERSIONID = TT.GAMEVERSION)
    WHEN NOT MATCHED THEN
      INSERT
        (APPVERSIONID, APPID, APPNAME, VERSIONID, VERSIONNAME)
      VALUES
        (TT.GAMEID || TT.GAMEVERSION,
         TT.GAMEID,
         TT.APPNAME,
         TT.GAMEVERSION,
         TT.GAMEVERSION);
    COMMIT;
    --
    MERGE INTO DIM_APPVERSION D
    USING (SELECT TN.GAMEID, DA.APPNAME, TN.GAMEVERSION
             FROM (SELECT DISTINCT T.GAMEID, T.GAMEVERSION
                     FROM T_100197_NU T
                    WHERE T.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND T.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)) TN
            INNER JOIN DIM_APP DA
               ON DA.APPID = TN.GAMEID) TT
    ON (D.APPID = TT.GAMEID AND D.VERSIONID = TT.GAMEVERSION)
    WHEN NOT MATCHED THEN
      INSERT
        (APPVERSIONID, APPID, APPNAME, VERSIONID, VERSIONNAME)
      VALUES
        (TT.GAMEID || TT.GAMEVERSION,
         TT.GAMEID,
         TT.APPNAME,
         TT.GAMEVERSION,
         TT.GAMEVERSION);
    COMMIT;

    V_ERRPOSITION := '1-3';
    --����DIM_APPPAYTYPE��Ʒ-��ֵ����ά����Ϣ
    MERGE INTO DIM_APPPAYTYPE D
    USING (SELECT TN.GAMEID, DA.APPNAME, TN.IAPID, TN.MONEY
             FROM (SELECT DISTINCT T.GAMEID, NVL(T.IAPID, 0) IAPID, T.MONEY
                     FROM T_100197_ORDER_SUCC T
                    WHERE T.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND T.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)) TN
            INNER JOIN DIM_APP DA
               ON DA.APPID = TN.GAMEID) TT
    ON (D.APPID = TT.GAMEID AND D.PAYTYPEID = TT.IAPID)
    WHEN NOT MATCHED THEN
      INSERT
        (APPPAYTYPEID, APPID, APPNAME, PAYTYPEID, PAYTYPENAME)
      VALUES
        (TT.GAMEID || TT.IAPID, TT.GAMEID, TT.APPNAME, TT.IAPID, TT.MONEY);
    COMMIT;

    V_ERRPOSITION := '1-4';
    --����DIM_APPPAYWAY��Ʒ-��ֵ����ά�ȱ���Ϣ
    MERGE INTO DIM_APPPAYWAY D
    USING (SELECT TN.GAMEID, DA.APPNAME, TN.PAYCHANNEL
             FROM (SELECT DISTINCT T.GAMEID, NVL(T.PAYCHANNEL, 0) PAYCHANNEL
                     FROM T_100197_ORDER_SUCC T
                    WHERE T.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND T.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)) TN
            INNER JOIN DIM_APP DA
               ON DA.APPID = TN.GAMEID) TT
    ON (D.APPID = TT.GAMEID AND D.PAYWAYID = TT.PAYCHANNEL)
    WHEN NOT MATCHED THEN
      INSERT
        (APPPAYWAYID, APPID, APPNAME, PAYWAYID, PAYWAYNAME)
      VALUES
        (TT.GAMEID || TT.PAYCHANNEL,
         TT.GAMEID,
         TT.APPNAME,
         TT.PAYCHANNEL,
         TT.PAYCHANNEL);
    COMMIT;

    V_ERRPOSITION := '1-5';
    --����DIM_APPPCHANNEL��Ʒ-����ά����Ϣ
    MERGE INTO DIM_APPCHANNEL D
    USING (SELECT T.GAMEID,
                  DA.APPNAME,
                  DA.PLATFORM,
                  T.CHANNELID,
                  NVL(DC.CHANNELNAME, '����(' || T.CHANNELID || ')') CHANNELNAME
             FROM (SELECT DISTINCT TN.GAMEID, TN.CHANNELID
                     FROM T_100197_NU_MAC TN
                    WHERE TN.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TN.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)) T
             LEFT JOIN DIM_APP DA
               ON T.GAMEID = DA.APPID
             LEFT JOIN DIM_CHANNEL DC
               ON T.CHANNELID = DC.CHANNELID) TT
    ON (D.APPID = TT.GAMEID AND D.CHANNELID = TT.CHANNELID)
    WHEN MATCHED THEN
      UPDATE SET D.CHANNELNAME = TT.CHANNELNAME
    WHEN NOT MATCHED THEN
      INSERT
        (APPCHANNELID, APPID, APPNAME, PLATFORM, CHANNELID, CHANNELNAME)
      VALUES
        (TT.GAMEID || TT.CHANNELID,
         TT.GAMEID,
         TT.APPNAME,
         TT.PLATFORM,
         TT.CHANNELID,
         TT.CHANNELNAME);
    COMMIT;
    --
    MERGE INTO DIM_APPCHANNEL D
    USING (SELECT T.GAMEID,
                  DA.APPNAME,
                  DA.PLATFORM,
                  T.CHANNELID,
                  NVL(DC.CHANNELNAME, '����(' || T.CHANNELID || ')') CHANNELNAME
             FROM (SELECT DISTINCT TN.GAMEID, TN.CHANNELID
                     FROM T_100197_NU TN
                    WHERE TN.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TN.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)) T
             LEFT JOIN DIM_APP DA
               ON T.GAMEID = DA.APPID
             LEFT JOIN DIM_CHANNEL DC
               ON T.CHANNELID = DC.CHANNELID) TT
    ON (D.APPID = TT.GAMEID AND D.CHANNELID = TT.CHANNELID)
    WHEN MATCHED THEN
      UPDATE SET D.CHANNELNAME = TT.CHANNELNAME
    WHEN NOT MATCHED THEN
      INSERT
        (APPCHANNELID, APPID, APPNAME, PLATFORM, CHANNELID, CHANNELNAME)
      VALUES
        (TT.GAMEID || TT.CHANNELID,
         TT.GAMEID,
         TT.APPNAME,
         TT.PLATFORM,
         TT.CHANNELID,
         TT.CHANNELNAME);
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=DIM_APPPAYWAY,DIM_APPPAYTYPE,DIM_APPVERSION,DIM_APPSERVER';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_100197_GENERAL_HOUR����***************************************************************/
  --����FACT_100197_GENERAL_HOUR����
  PROCEDURE P_FACT_GENERAL_HOUR(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
      INTO V_INPUTDATE
      FROM DUAL;

    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_GENERAL_HOUR';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    V_ERRPOSITION := '1-1';
    DELETE FROM FACT_100197_GENERAL_HOUR T
     WHERE T.STATDATE =
           TO_CHAR(TRUNC(SYSDATE) - V_INPUTDATE, 'YYYY-MM-DD HH24');
    COMMIT;

    V_ERRPOSITION := '1-2';
    --�û���������
    INSERT INTO FACT_100197_GENERAL_HOUR
      SELECT T4.STATDATE,
             T4.CHANNELID,
             T4.SERVERID,
             '1' DATATYPE,
             '100197' APPID,
             T4.VERSIONID,
             NVL(T1.NEWCOUNT, 0),
             NVL(T2.CONNCOUNT, 0),
             NVL(T3.PAYCOUNT, 0),
             NVL(T3.PAYAMOUNT, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TRUNC(SYSDATE) - V_INPUTDATE, 'YYYY-MM-DD HH24') STATDATE,
                     DAC.CHANNELID,
                     DAS.SERVERID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC,
                     DIM_APPSERVER    DAS,
                     DIM_APPVERSION   DAV
               WHERE DAC.APPID = '100197'
                 AND DAS.APPID = '100197'
                 AND DAV.APPID = '100197') T4
        LEFT JOIN (SELECT TO_CHAR(TN.THEDATE, 'YYYY-MM-DD HH24') THEDATE,
                          TN.CHANNELID,
                          TN.SERVERID,
                          TN.GAMEID,
                          TN.GAMEVERSION,
                          COUNT(1) NEWCOUNT
                     FROM T_100197_NU TN
                    WHERE TN.THEDATE >= TRUNC(SYSDATE) - V_INPUTDATE
                      AND TN.THEDATE < TRUNC(SYSDATE) - V_INPUTDATE + 1 / 24
                    GROUP BY TO_CHAR(TN.THEDATE, 'YYYY-MM-DD HH24'),
                             TN.CHANNELID,
                             TN.SERVERID,
                             TN.GAMEID,
                             TN.GAMEVERSION) T1
          ON T1.THEDATE = T4.STATDATE
         AND T1.CHANNELID = T4.CHANNELID
         AND T1.SERVERID = T4.SERVERID
         AND T1.GAMEVERSION = T4.VERSIONID
        LEFT JOIN (SELECT TO_CHAR(TDL.F_LOGTIME, 'YYYY-MM-DD HH24') THEDATE,
                          TDL.CHANNELID,
                          NVL(TDL.SERVERID, 0) SERVERID,
                          TDL.APPID GAMEID,
                          NVL(TDL.GAMEVERSION, 0) GAMEVERSION,
                          COUNT(DISTINCT nvl(TDL.ACCOUNTID,0)) CONNCOUNT
                     FROM T_DW_100197_LOGIN TDL
                    WHERE TDL.F_LOGTIME >= TRUNC(SYSDATE) - V_INPUTDATE
                      AND TDL.F_LOGTIME <
                          TRUNC(SYSDATE) - V_INPUTDATE + 1 / 24
                    GROUP BY TO_CHAR(TDL.F_LOGTIME, 'YYYY-MM-DD HH24'),
                             TDL.CHANNELID,
                             TDL.SERVERID,
                             TDL.APPID,
                             TDL.GAMEVERSION) T2
          ON T4.STATDATE = T2.THEDATE
         AND T4.CHANNELID = T2.CHANNELID
         AND T4.SERVERID = T2.SERVERID
         AND T4.VERSIONID = T2.GAMEVERSION
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD HH24') THEDATE,
                          TOS.CHANNELID,
                          TOS.SERVERID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.ACCOUNTID) PAYCOUNT,
                          --COUNT(DISTINCT TOS.DVID) PAYCOUNT,
                          SUM(TOS.MONEY) PAYAMOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE) - V_INPUTDATE
                      AND TOS.THEDATE <
                          TRUNC(SYSDATE) - V_INPUTDATE + 1 / 24
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD HH24'),
                             TOS.CHANNELID,
                             TOS.SERVERID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T3
          ON T4.STATDATE = T3.THEDATE
         AND T4.CHANNELID = T3.CHANNELID
         AND T4.SERVERID = T3.SERVERID
         AND T4.VERSIONID = T3.GAMEVERSION;
    COMMIT;

    V_ERRPOSITION := '1-2-1';
    --ALL SERVER
    INSERT INTO FACT_100197_GENERAL_HOUR
      SELECT T4.STATDATE,
             T4.CHANNELID,
             LOWER('all'),
             '1' DATATYPE,
             '100197' APPID,
             T4.VERSIONID,
             NVL(T1.NEWCOUNT, 0),
             NVL(T2.CONNCOUNT, 0),
             NVL(T3.PAYCOUNT, 0),
             NVL(T3.PAYAMOUNT, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TRUNC(SYSDATE) - V_INPUTDATE, 'YYYY-MM-DD HH24') STATDATE,
                     DAC.CHANNELID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC, DIM_APPVERSION DAV
               WHERE DAC.APPID = '100197'
                 AND DAV.APPID = '100197') T4
        LEFT JOIN (SELECT TO_CHAR(TN.THEDATE, 'YYYY-MM-DD HH24') THEDATE,
                          TN.CHANNELID,
                          TN.GAMEID,
                          TN.GAMEVERSION,
                          COUNT(DISTINCT TN.ACCOUNTID) NEWCOUNT
                     FROM T_100197_NU_ALLSERVER TN
                    WHERE TN.THEDATE >= TRUNC(SYSDATE) - V_INPUTDATE
                      AND TN.THEDATE < TRUNC(SYSDATE) - V_INPUTDATE + 1 / 24
                    GROUP BY TO_CHAR(TN.THEDATE, 'YYYY-MM-DD HH24'),
                             TN.CHANNELID,
                             TN.GAMEID,
                             TN.GAMEVERSION) T1
          ON T1.THEDATE = T4.STATDATE
         AND T1.CHANNELID = T4.CHANNELID
         AND T1.GAMEVERSION = T4.VERSIONID
        LEFT JOIN (SELECT TO_CHAR(TDL.F_LOGTIME, 'YYYY-MM-DD HH24') THEDATE,
                          TDL.CHANNELID,
                          TDL.APPID GAMEID,
                          NVL(TDL.GAMEVERSION, 0) GAMEVERSION,
                          COUNT(DISTINCT nvl(TDL.ACCOUNTID,0)) CONNCOUNT
                     FROM T_DW_100197_LOGIN TDL
                    WHERE TDL.F_LOGTIME >= TRUNC(SYSDATE) - V_INPUTDATE
                      AND TDL.F_LOGTIME <
                          TRUNC(SYSDATE) - V_INPUTDATE + 1 / 24
                    GROUP BY TO_CHAR(TDL.F_LOGTIME, 'YYYY-MM-DD HH24'),
                             TDL.CHANNELID,
                             TDL.APPID,
                             TDL.GAMEVERSION) T2
          ON T4.STATDATE = T2.THEDATE
         AND T4.CHANNELID = T2.CHANNELID
         AND T4.VERSIONID = T2.GAMEVERSION
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD HH24') THEDATE,
                          TOS.CHANNELID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.ACCOUNTID) PAYCOUNT,
                          --COUNT(DISTINCT TOS.DVID) PAYCOUNT,
                          SUM(TOS.MONEY) PAYAMOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE) - V_INPUTDATE
                      AND TOS.THEDATE <
                          TRUNC(SYSDATE) - V_INPUTDATE + 1 / 24
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD HH24'),
                             TOS.CHANNELID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T3
          ON T4.STATDATE = T3.THEDATE
         AND T4.CHANNELID = T3.CHANNELID
         AND T4.VERSIONID = T3.GAMEVERSION;
    COMMIT;

    V_ERRPOSITION := '1-3';
    --�豸��������
    INSERT INTO FACT_100197_GENERAL_HOUR
      SELECT T4.STATDATE,
             T4.CHANNELID,
             T4.SERVERID,
             '2' DATATYPE,
             '100197' APPID,
             T4.VERSIONID,
             NVL(T1.NEWCOUNT, 0),
             NVL(T2.CONNCOUNT, 0),
             NVL(T3.PAYCOUNT, 0),
             NVL(T3.PAYAMOUNT, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TRUNC(SYSDATE) - V_INPUTDATE, 'YYYY-MM-DD HH24') STATDATE,
                     DAC.CHANNELID,
                     DAS.SERVERID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC,
                     DIM_APPSERVER    DAS,
                     DIM_APPVERSION   DAV
               WHERE DAC.APPID = '100197'
                 AND DAS.APPID = '100197'
                 AND DAV.APPID = '100197') T4
        LEFT JOIN (SELECT TO_CHAR(TN.THEDATE, 'YYYY-MM-DD HH24') THEDATE,
                          TN.CHANNELID,
                          TN.SERVERID,
                          TN.GAMEID,
                          TN.GAMEVERSION,
                          COUNT(1) NEWCOUNT
                     FROM T_100197_NU_MAC TN
                    WHERE TN.THEDATE >= TRUNC(SYSDATE) - V_INPUTDATE
                      AND TN.THEDATE < TRUNC(SYSDATE) - V_INPUTDATE + 1 / 24
                    GROUP BY TO_CHAR(TN.THEDATE, 'YYYY-MM-DD HH24'),
                             TN.CHANNELID,
                             TN.SERVERID,
                             TN.GAMEID,
                             TN.GAMEVERSION) T1
          ON T1.THEDATE = T4.STATDATE
         AND T1.CHANNELID = T4.CHANNELID
         AND T1.SERVERID = T4.SERVERID
         AND T1.GAMEVERSION = T4.VERSIONID
        LEFT JOIN (SELECT TO_CHAR(TDL.F_LOGTIME, 'YYYY-MM-DD HH24') THEDATE,
                          TDL.CHANNELID,
                          NVL(TDL.SERVERID, 0) SERVERID,
                          TDL.APPID GAMEID,
                          NVL(TDL.GAMEVERSION, 0) GAMEVERSION,
                          COUNT(DISTINCT TDL.DVID) CONNCOUNT
                     FROM T_DW_100197_LOGIN TDL
                    WHERE TDL.F_LOGTIME >= TRUNC(SYSDATE) - V_INPUTDATE
                      AND TDL.F_LOGTIME <
                          TRUNC(SYSDATE) - V_INPUTDATE + 1 / 24
                    GROUP BY TO_CHAR(TDL.F_LOGTIME, 'YYYY-MM-DD HH24'),
                             TDL.CHANNELID,
                             TDL.SERVERID,
                             TDL.APPID,
                             TDL.GAMEVERSION) T2
          ON T4.STATDATE = T2.THEDATE
         AND T4.CHANNELID = T2.CHANNELID
         AND T4.SERVERID = T2.SERVERID
         AND T4.VERSIONID = T2.GAMEVERSION
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD HH24') THEDATE,
                          TOS.CHANNELID,
                          TOS.SERVERID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          --COUNT(DISTINCT TOS.ACCOUNTID) PAYCOUNT,
                          COUNT(DISTINCT TOS.DVID) PAYCOUNT,
                          SUM(TOS.MONEY) PAYAMOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE) - V_INPUTDATE
                      AND TOS.THEDATE <
                          TRUNC(SYSDATE) - V_INPUTDATE + 1 / 24
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD HH24'),
                             TOS.CHANNELID,
                             TOS.SERVERID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T3
          ON T4.STATDATE = T3.THEDATE
         AND T4.CHANNELID = T3.CHANNELID
         AND T4.SERVERID = T3.SERVERID
         AND T4.VERSIONID = T3.GAMEVERSION;
    COMMIT;

    V_ERRPOSITION := '1-3-1';
    --ALL SERVER
    INSERT INTO FACT_100197_GENERAL_HOUR
      SELECT T4.STATDATE,
             T4.CHANNELID,
             LOWER('all'),
             '2' DATATYPE,
             '100197' APPID,
             T4.VERSIONID,
             NVL(T1.NEWCOUNT, 0),
             NVL(T2.CONNCOUNT, 0),
             NVL(T3.PAYCOUNT, 0),
             NVL(T3.PAYAMOUNT, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TRUNC(SYSDATE) - V_INPUTDATE, 'YYYY-MM-DD HH24') STATDATE,
                     DAC.CHANNELID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC, DIM_APPVERSION DAV
               WHERE DAC.APPID = '100197'
                 AND DAV.APPID = '100197') T4
        LEFT JOIN (SELECT TO_CHAR(TN.THEDATE, 'YYYY-MM-DD HH24') THEDATE,
                          TN.CHANNELID,
                          TN.GAMEID,
                          TN.GAMEVERSION,
                          COUNT(DISTINCT TN.DVID) NEWCOUNT
                     FROM T_100197_NU_MAC_ALLSERVER TN
                    WHERE TN.THEDATE >= TRUNC(SYSDATE) - V_INPUTDATE
                      AND TN.THEDATE < TRUNC(SYSDATE) - V_INPUTDATE + 1 / 24
                    GROUP BY TO_CHAR(TN.THEDATE, 'YYYY-MM-DD HH24'),
                             TN.CHANNELID,
                             TN.GAMEID,
                             TN.GAMEVERSION) T1
          ON T1.THEDATE = T4.STATDATE
         AND T1.CHANNELID = T4.CHANNELID
         AND T1.GAMEVERSION = T4.VERSIONID
        LEFT JOIN (SELECT TO_CHAR(TDL.F_LOGTIME, 'YYYY-MM-DD HH24') THEDATE,
                          TDL.CHANNELID,
                          TDL.APPID GAMEID,
                          NVL(TDL.GAMEVERSION, 0) GAMEVERSION,
                          COUNT(DISTINCT TDL.DVID) CONNCOUNT
                     FROM T_DW_100197_LOGIN TDL
                    WHERE TDL.F_LOGTIME >= TRUNC(SYSDATE) - V_INPUTDATE
                      AND TDL.F_LOGTIME <
                          TRUNC(SYSDATE) - V_INPUTDATE + 1 / 24
                    GROUP BY TO_CHAR(TDL.F_LOGTIME, 'YYYY-MM-DD HH24'),
                             TDL.CHANNELID,
                             TDL.APPID,
                             TDL.GAMEVERSION) T2
          ON T4.STATDATE = T2.THEDATE
         AND T4.CHANNELID = T2.CHANNELID
         AND T4.VERSIONID = T2.GAMEVERSION
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD HH24') THEDATE,
                          TOS.CHANNELID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          --COUNT(DISTINCT TOS.ACCOUNTID) PAYCOUNT,
                          COUNT(DISTINCT TOS.DVID) PAYCOUNT,
                          SUM(TOS.MONEY) PAYAMOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE) - V_INPUTDATE
                      AND TOS.THEDATE <
                          TRUNC(SYSDATE) - V_INPUTDATE + 1 / 24
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD HH24'),
                             TOS.CHANNELID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T3
          ON T4.STATDATE = T3.THEDATE
         AND T4.CHANNELID = T3.CHANNELID
         AND T4.VERSIONID = T3.GAMEVERSION;
    COMMIT;

    --����
    V_ERRPOSITION := '1-4';
    DELETE FROM FACT_100197_ORDER_HOUR T
     WHERE T.STATDATE =
           TO_CHAR(TRUNC(SYSDATE) - V_INPUTDATE, 'YYYY-MM-DD HH24');
    COMMIT;

    --�˻�
    V_ERRPOSITION := '1-5';
    INSERT INTO FACT_100197_ORDER_HOUR
      SELECT T3.STATDATE,
             T3.CHANNELID,
             T3.SERVERID,
             '1',
             '100197',
             T3.VERSIONID,
             NVL(T1.PAYSUCCCOUNT, 0),
             NVL(T2.PAYFAILCOUNT, 0),
             NVL(T1.PAYSUCCAMOUNT, 0),
             NVL(T2.PAYFAILAMOUNT, 0),
             NVL(T1.PAYSUCCNUM, 0),
             NVL(T2.PAYFAILNUM, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TRUNC(SYSDATE) - V_INPUTDATE, 'YYYY-MM-DD HH24') STATDATE,
                     DAC.CHANNELID,
                     DAS.SERVERID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC,
                     DIM_APPSERVER    DAS,
                     DIM_APPVERSION   DAV
               WHERE DAC.APPID = '100197'
                 AND DAS.APPID = '100197'
                 AND DAV.APPID = '100197') T3
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD HH24') STATDATE,
                          TOS.CHANNELID,
                          TOS.SERVERID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.ACCOUNTID) PAYSUCCCOUNT,
                          SUM(TOS.MONEY) PAYSUCCAMOUNT,
                          COUNT(TOS.ORDERID) PAYSUCCNUM
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE) - V_INPUTDATE
                      AND TOS.THEDATE <
                          TRUNC(SYSDATE) - V_INPUTDATE + 1 / 24
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD HH24'),
                             TOS.CHANNELID,
                             TOS.SERVERID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T1
          ON T1.STATDATE = T3.STATDATE
         AND T1.CHANNELID = T3.CHANNELID
         AND T1.SERVERID = T3.SERVERID
         AND T1.GAMEVERSION = T3.VERSIONID
        LEFT JOIN (SELECT TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD HH24') STATDATE,
                          TOF.CHANNELID,
                          TOF.SERVERID,
                          TOF.GAMEID,
                          TOF.GAMEVERSION,
                          COUNT(DISTINCT TOF.ACCOUNTID) PAYFAILCOUNT,
                          SUM(TOF.MONEY) PAYFAILAMOUNT,
                          COUNT(TOF.ORDERID) PAYFAILNUM
                     FROM T_100197_ORDER_FAILURE TOF
                    WHERE TOF.THEDATE >= TRUNC(SYSDATE) - V_INPUTDATE
                      AND TOF.THEDATE <
                          TRUNC(SYSDATE) - V_INPUTDATE + 1 / 24
                    GROUP BY TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD HH24'),
                             TOF.CHANNELID,
                             TOF.SERVERID,
                             TOF.GAMEID,
                             TOF.GAMEVERSION) T2
          ON T3.STATDATE = T2.STATDATE
         AND T3.CHANNELID = T2.CHANNELID
         AND T3.SERVERID = T2.SERVERID
         AND T3.VERSIONID = T2.GAMEVERSION;
    COMMIT;

    V_ERRPOSITION := '1-5-1';
    --ALL SERVER
    INSERT INTO FACT_100197_ORDER_HOUR
      SELECT T3.STATDATE,
             T3.CHANNELID,
             LOWER('all'),
             '1',
             '100197',
             T3.VERSIONID,
             NVL(T1.PAYSUCCCOUNT, 0),
             NVL(T2.PAYFAILCOUNT, 0),
             NVL(T1.PAYSUCCAMOUNT, 0),
             NVL(T2.PAYFAILAMOUNT, 0),
             NVL(T1.PAYSUCCNUM, 0),
             NVL(T2.PAYFAILNUM, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TRUNC(SYSDATE) - V_INPUTDATE, 'YYYY-MM-DD HH24') STATDATE,
                     DAC.CHANNELID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC, DIM_APPVERSION DAV
               WHERE DAC.APPID = '100197'
                 AND DAV.APPID = '100197') T3
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD HH24') STATDATE,
                          TOS.CHANNELID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.ACCOUNTID) PAYSUCCCOUNT,
                          SUM(TOS.MONEY) PAYSUCCAMOUNT,
                          COUNT(TOS.ORDERID) PAYSUCCNUM
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE) - V_INPUTDATE
                      AND TOS.THEDATE <
                          TRUNC(SYSDATE) - V_INPUTDATE + 1 / 24
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD HH24'),
                             TOS.CHANNELID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T1
          ON T1.STATDATE = T3.STATDATE
         AND T1.CHANNELID = T3.CHANNELID
         AND T1.GAMEVERSION = T3.VERSIONID
        LEFT JOIN (SELECT TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD HH24') STATDATE,
                          TOF.CHANNELID,
                          TOF.GAMEID,
                          TOF.GAMEVERSION,
                          COUNT(DISTINCT TOF.ACCOUNTID) PAYFAILCOUNT,
                          SUM(TOF.MONEY) PAYFAILAMOUNT,
                          COUNT(TOF.ORDERID) PAYFAILNUM
                     FROM T_100197_ORDER_FAILURE TOF
                    WHERE TOF.THEDATE >= TRUNC(SYSDATE) - V_INPUTDATE
                      AND TOF.THEDATE <
                          TRUNC(SYSDATE) - V_INPUTDATE + 1 / 24
                    GROUP BY TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD HH24'),
                             TOF.CHANNELID,
                             TOF.GAMEID,
                             TOF.GAMEVERSION) T2
          ON T3.STATDATE = T2.STATDATE
         AND T3.CHANNELID = T2.CHANNELID
         AND T3.VERSIONID = T2.GAMEVERSION;
    COMMIT;

    --�豸
    V_ERRPOSITION := '1-6';
    INSERT INTO FACT_100197_ORDER_HOUR
      SELECT T3.STATDATE,
             T3.CHANNELID,
             T3.SERVERID,
             '2',
             '100197',
             T3.VERSIONID,
             NVL(T1.PAYSUCCCOUNT, 0),
             NVL(T2.PAYFAILCOUNT, 0),
             NVL(T1.PAYSUCCAMOUNT, 0),
             NVL(T2.PAYFAILAMOUNT, 0),
             NVL(T1.PAYSUCCNUM, 0),
             NVL(T2.PAYFAILNUM, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TRUNC(SYSDATE) - V_INPUTDATE, 'YYYY-MM-DD HH24') STATDATE,
                     DAC.CHANNELID,
                     DAS.SERVERID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC,
                     DIM_APPSERVER    DAS,
                     DIM_APPVERSION   DAV
               WHERE DAC.APPID = '100197'
                 AND DAS.APPID = '100197'
                 AND DAV.APPID = '100197') T3
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD HH24') STATDATE,
                          TOS.CHANNELID,
                          TOS.SERVERID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.DVID) PAYSUCCCOUNT,
                          SUM(TOS.MONEY) PAYSUCCAMOUNT,
                          COUNT(TOS.ORDERID) PAYSUCCNUM
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE) - V_INPUTDATE
                      AND TOS.THEDATE <
                          TRUNC(SYSDATE) - V_INPUTDATE + 1 / 24
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD HH24'),
                             TOS.CHANNELID,
                             TOS.SERVERID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T1
          ON T1.STATDATE = T3.STATDATE
         AND T1.CHANNELID = T3.CHANNELID
         AND T1.SERVERID = T3.SERVERID
         AND T1.GAMEVERSION = T3.VERSIONID
        LEFT JOIN (SELECT TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD HH24') STATDATE,
                          TOF.CHANNELID,
                          TOF.SERVERID,
                          TOF.GAMEID,
                          TOF.GAMEVERSION,
                          COUNT(DISTINCT TOF.DVID) PAYFAILCOUNT,
                          SUM(TOF.MONEY) PAYFAILAMOUNT,
                          COUNT(TOF.ORDERID) PAYFAILNUM
                     FROM T_100197_ORDER_FAILURE TOF
                    WHERE TOF.THEDATE >= TRUNC(SYSDATE) - V_INPUTDATE
                      AND TOF.THEDATE <
                          TRUNC(SYSDATE) - V_INPUTDATE + 1 / 24
                    GROUP BY TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD HH24'),
                             TOF.CHANNELID,
                             TOF.SERVERID,
                             TOF.GAMEID,
                             TOF.GAMEVERSION) T2
          ON T3.STATDATE = T2.STATDATE
         AND T3.CHANNELID = T2.CHANNELID
         AND T3.SERVERID = T2.SERVERID
         AND T3.VERSIONID = T2.GAMEVERSION;
    COMMIT;

    V_ERRPOSITION := '1-6-1';
    --ALL SERVER
    INSERT INTO FACT_100197_ORDER_HOUR
      SELECT T3.STATDATE,
             T3.CHANNELID,
             LOWER('all'),
             '2',
             '100197',
             T3.VERSIONID,
             NVL(T1.PAYSUCCCOUNT, 0),
             NVL(T2.PAYFAILCOUNT, 0),
             NVL(T1.PAYSUCCAMOUNT, 0),
             NVL(T2.PAYFAILAMOUNT, 0),
             NVL(T1.PAYSUCCNUM, 0),
             NVL(T2.PAYFAILNUM, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TRUNC(SYSDATE) - V_INPUTDATE, 'YYYY-MM-DD HH24') STATDATE,
                     DAC.CHANNELID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC, DIM_APPVERSION DAV
               WHERE DAC.APPID = '100197'
                 AND DAV.APPID = '100197') T3
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD HH24') STATDATE,
                          TOS.CHANNELID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.DVID) PAYSUCCCOUNT,
                          SUM(TOS.MONEY) PAYSUCCAMOUNT,
                          COUNT(TOS.ORDERID) PAYSUCCNUM
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE) - V_INPUTDATE
                      AND TOS.THEDATE <
                          TRUNC(SYSDATE) - V_INPUTDATE + 1 / 24
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD HH24'),
                             TOS.CHANNELID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T1
          ON T1.STATDATE = T3.STATDATE
         AND T1.CHANNELID = T3.CHANNELID
         AND T1.GAMEVERSION = T3.VERSIONID
        LEFT JOIN (SELECT TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD HH24') STATDATE,
                          TOF.CHANNELID,
                          TOF.GAMEID,
                          TOF.GAMEVERSION,
                          COUNT(DISTINCT TOF.DVID) PAYFAILCOUNT,
                          SUM(TOF.MONEY) PAYFAILAMOUNT,
                          COUNT(TOF.ORDERID) PAYFAILNUM
                     FROM T_100197_ORDER_FAILURE TOF
                    WHERE TOF.THEDATE >= TRUNC(SYSDATE) - V_INPUTDATE
                      AND TOF.THEDATE <
                          TRUNC(SYSDATE) - V_INPUTDATE + 1 / 24
                    GROUP BY TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD HH24'),
                             TOF.CHANNELID,
                             TOF.GAMEID,
                             TOF.GAMEVERSION) T2
          ON T3.STATDATE = T2.STATDATE
         AND T3.CHANNELID = T2.CHANNELID
         AND T3.VERSIONID = T2.GAMEVERSION;
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_100197_GENERAL_HOUR';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_100197_GENERAL_DAY����***************************************************************/
  --����FACT_100197_GENERAL_DAY����
  PROCEDURE P_FACT_GENERAL(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
    V_WEEKFIRSTDAY VARCHAR2(10); --���������ҳ� ������������ܵĵ�һ��
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;
    --�ܵ�һ��ļ��㷽�� TRUNC(SYSDATE)-(TO_CHAR(SYSDATE-1, 'D')-1)����������һ�ǵ�һ��
    --��ȡ�ܵ�һ��
    SELECT TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE + 1) -
                   DECODE((TO_CHAR(SYSDATE - V_INPUTDATE, 'D') - 1),
                          0,
                          7,
                          (TO_CHAR(SYSDATE - V_INPUTDATE, 'D') - 1)),
                   'YYYY-MM-DD')
      INTO V_WEEKFIRSTDAY
      FROM DUAL;
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_GENERAL';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    ---------------------------------------------------FACT_100197_GENERAL_DAY----------------------------------------------------------------------------------
    V_ERRPOSITION := '1-1';
    DELETE FROM FACT_100197_GENERAL_DAY T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    V_ERRPOSITION := '1-2';
    --�û���������
    INSERT INTO FACT_100197_GENERAL_DAY
      SELECT T4.STATDATE,
             T4.CHANNELID,
             T4.SERVERID,
             '1' DATATYPE,
             '100197' APPID,
             T4.VERSIONID,
             NVL(T1.NEWCOUNT, 0),
             NVL(T2.CONNCOUNT, 0),
             NVL(T3.PAYCOUNT, 0),
             NVL(T3.PAYAMOUNT, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') STATDATE,
                     DAC.CHANNELID,
                     DAS.SERVERID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC,
                     DIM_APPSERVER    DAS,
                     DIM_APPVERSION   DAV
               WHERE DAC.APPID = '100197'
                 AND DAS.APPID = '100197'
                 AND DAV.APPID = '100197') T4
        LEFT JOIN (SELECT TO_CHAR(TN.THEDATE, 'YYYY-MM-DD') THEDATE,
                          TN.CHANNELID,
                          TN.SERVERID,
                          TN.GAMEID,
                          TN.GAMEVERSION,
                          COUNT(1) NEWCOUNT
                     FROM T_100197_NU TN
                    WHERE TN.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TN.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TN.THEDATE, 'YYYY-MM-DD'),
                             TN.CHANNELID,
                             TN.SERVERID,
                             TN.GAMEID,
                             TN.GAMEVERSION) T1
          ON T1.THEDATE = T4.STATDATE
         AND T1.CHANNELID = T4.CHANNELID
         AND T1.SERVERID = T4.SERVERID
         AND T1.GAMEVERSION = T4.VERSIONID
        LEFT JOIN (SELECT TC.CONNDATE THEDATE,
                          TC.CHANNELID,
                          TC.SERVERID,
                          TC.GAMEID,
                          TC.GAMEVERSION,
                          COUNT(DISTINCT TC.ACCOUNTID) CONNCOUNT
                   --COUNT(DISTINCT TC.DVID) CONNCOUNT
                     FROM T_100197_CONN TC
                    WHERE TC.CONNDATE =
                          TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                    GROUP BY TC.CONNDATE,
                             TC.CHANNELID,
                             TC.SERVERID,
                             TC.GAMEID,
                             TC.GAMEVERSION) T2
          ON T4.STATDATE = T2.THEDATE
         AND T4.CHANNELID = T2.CHANNELID
         AND T4.SERVERID = T2.SERVERID
         AND T4.VERSIONID = T2.GAMEVERSION
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') THEDATE,
                          TOS.CHANNELID,
                          TOS.SERVERID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.ACCOUNTID) PAYCOUNT,
                          --COUNT(DISTINCT TOS.DVID) PAYCOUNT,
                          SUM(TOS.MONEY) PAYAMOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.SERVERID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T3
          ON T4.STATDATE = T3.THEDATE
         AND T4.CHANNELID = T3.CHANNELID
         AND T4.SERVERID = T3.SERVERID
         AND T4.VERSIONID = T3.GAMEVERSION;
    COMMIT;

    V_ERRPOSITION := '1-2-1';
    --ALL SERVER
    INSERT INTO FACT_100197_GENERAL_DAY
      SELECT T4.STATDATE,
             T4.CHANNELID,
             LOWER('all'),
             '1' DATATYPE,
             '100197' APPID,
             T4.VERSIONID,
             NVL(T1.NEWCOUNT, 0),
             NVL(T2.CONNCOUNT, 0),
             NVL(T3.PAYCOUNT, 0),
             NVL(T3.PAYAMOUNT, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') STATDATE,
                     DAC.CHANNELID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC, DIM_APPVERSION DAV
               WHERE DAC.APPID = '100197'
                 AND DAV.APPID = '100197') T4
        LEFT JOIN (SELECT TO_CHAR(TN.THEDATE, 'YYYY-MM-DD') THEDATE,
                          TN.CHANNELID,
                          TN.GAMEID,
                          TN.GAMEVERSION,
                          COUNT(DISTINCT TN.ACCOUNTID) NEWCOUNT
                     FROM T_100197_NU_ALLSERVER TN
                    WHERE TN.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TN.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TN.THEDATE, 'YYYY-MM-DD'),
                             TN.CHANNELID,
                             TN.GAMEID,
                             TN.GAMEVERSION) T1
          ON T1.THEDATE = T4.STATDATE
         AND T1.CHANNELID = T4.CHANNELID
         AND T1.GAMEVERSION = T4.VERSIONID
        LEFT JOIN (SELECT TC.CONNDATE THEDATE,
                          TC.CHANNELID,
                          TC.GAMEID,
                          TC.GAMEVERSION,
                          COUNT(DISTINCT TC.ACCOUNTID) CONNCOUNT
                   --COUNT(DISTINCT TC.DVID) CONNCOUNT
                     FROM T_100197_CONN TC
                    WHERE TC.CONNDATE =
                          TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                    GROUP BY TC.CONNDATE,
                             TC.CHANNELID,
                             TC.GAMEID,
                             TC.GAMEVERSION) T2
          ON T4.STATDATE = T2.THEDATE
         AND T4.CHANNELID = T2.CHANNELID
         AND T4.VERSIONID = T2.GAMEVERSION
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') THEDATE,
                          TOS.CHANNELID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.ACCOUNTID) PAYCOUNT,
                          --COUNT(DISTINCT TOS.DVID) PAYCOUNT,
                          SUM(TOS.MONEY) PAYAMOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T3
          ON T4.STATDATE = T3.THEDATE
         AND T4.CHANNELID = T3.CHANNELID
         AND T4.VERSIONID = T3.GAMEVERSION;
    COMMIT;

    V_ERRPOSITION := '1-3';
    --�豸��������
    INSERT INTO FACT_100197_GENERAL_DAY
      SELECT T4.STATDATE,
             T4.CHANNELID,
             T4.SERVERID,
             '2' DATATYPE,
             '100197' APPID,
             T4.VERSIONID,
             NVL(T1.NEWCOUNT, 0),
             NVL(T2.CONNCOUNT, 0),
             NVL(T3.PAYCOUNT, 0),
             NVL(T3.PAYAMOUNT, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') STATDATE,
                     DAC.CHANNELID,
                     DAS.SERVERID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC,
                     DIM_APPSERVER    DAS,
                     DIM_APPVERSION   DAV
               WHERE DAC.APPID = '100197'
                 AND DAS.APPID = '100197'
                 AND DAV.APPID = '100197') T4
        LEFT JOIN (SELECT TO_CHAR(TN.THEDATE, 'YYYY-MM-DD') THEDATE,
                          TN.CHANNELID,
                          TN.SERVERID,
                          TN.GAMEID,
                          TN.GAMEVERSION,
                          COUNT(1) NEWCOUNT
                     FROM T_100197_NU_MAC TN
                    WHERE TN.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TN.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TN.THEDATE, 'YYYY-MM-DD'),
                             TN.CHANNELID,
                             TN.SERVERID,
                             TN.GAMEID,
                             TN.GAMEVERSION) T1
          ON T1.THEDATE = T4.STATDATE
         AND T1.CHANNELID = T4.CHANNELID
         AND T1.SERVERID = T4.SERVERID
         AND T1.GAMEVERSION = T4.VERSIONID
        LEFT JOIN (SELECT TC.CONNDATE THEDATE,
                          TC.CHANNELID,
                          TC.SERVERID,
                          TC.GAMEID,
                          TC.GAMEVERSION,
                          --COUNT(DISTINCT TC.ACCOUNTID) CONNCOUNT,
                          COUNT(DISTINCT TC.DVID) CONNCOUNT
                     FROM T_100197_CONN_MAC TC
                    WHERE TC.CONNDATE =
                          TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                    GROUP BY TC.CONNDATE,
                             TC.CHANNELID,
                             TC.SERVERID,
                             TC.GAMEID,
                             TC.GAMEVERSION) T2
          ON T4.STATDATE = T2.THEDATE
         AND T4.CHANNELID = T2.CHANNELID
         AND T4.SERVERID = T2.SERVERID
         AND T4.VERSIONID = T2.GAMEVERSION
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') THEDATE,
                          TOS.CHANNELID,
                          TOS.SERVERID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          --COUNT(DISTINCT TOS.ACCOUNTID) PAYCOUNT,
                          COUNT(DISTINCT TOS.DVID) PAYCOUNT,
                          SUM(TOS.MONEY) PAYAMOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.SERVERID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T3
          ON T4.STATDATE = T3.THEDATE
         AND T4.CHANNELID = T3.CHANNELID
         AND T4.SERVERID = T3.SERVERID
         AND T4.VERSIONID = T3.GAMEVERSION;
    COMMIT;

    V_ERRPOSITION := '1-3-1';
    --ALL SERVER
    INSERT INTO FACT_100197_GENERAL_DAY
      SELECT T4.STATDATE,
             T4.CHANNELID,
             LOWER('all'),
             '2' DATATYPE,
             '100197' APPID,
             T4.VERSIONID,
             NVL(T1.NEWCOUNT, 0),
             NVL(T2.CONNCOUNT, 0),
             NVL(T3.PAYCOUNT, 0),
             NVL(T3.PAYAMOUNT, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') STATDATE,
                     DAC.CHANNELID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC, DIM_APPVERSION DAV
               WHERE DAC.APPID = '100197'
                 AND DAV.APPID = '100197') T4
        LEFT JOIN (SELECT TO_CHAR(TN.THEDATE, 'YYYY-MM-DD') THEDATE,
                          TN.CHANNELID,
                          TN.GAMEID,
                          TN.GAMEVERSION,
                          COUNT(DISTINCT TN.DVID) NEWCOUNT
                     FROM T_100197_NU_MAC_ALLSERVER TN
                    WHERE TN.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TN.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TN.THEDATE, 'YYYY-MM-DD'),
                             TN.CHANNELID,
                             TN.GAMEID,
                             TN.GAMEVERSION) T1
          ON T1.THEDATE = T4.STATDATE
         AND T1.CHANNELID = T4.CHANNELID
         AND T1.GAMEVERSION = T4.VERSIONID
        LEFT JOIN (SELECT TC.CONNDATE THEDATE,
                          TC.CHANNELID,
                          TC.GAMEID,
                          TC.GAMEVERSION,
                          --COUNT(DISTINCT TC.ACCOUNTID) CONNCOUNT,
                          COUNT(DISTINCT TC.DVID) CONNCOUNT
                     FROM T_100197_CONN_MAC TC
                    WHERE TC.CONNDATE =
                          TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                    GROUP BY TC.CONNDATE,
                             TC.CHANNELID,
                             TC.GAMEID,
                             TC.GAMEVERSION) T2
          ON T4.STATDATE = T2.THEDATE
         AND T4.CHANNELID = T2.CHANNELID
         AND T4.VERSIONID = T2.GAMEVERSION
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') THEDATE,
                          TOS.CHANNELID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          --COUNT(DISTINCT TOS.ACCOUNTID) PAYCOUNT,
                          COUNT(DISTINCT TOS.DVID) PAYCOUNT,
                          SUM(TOS.MONEY) PAYAMOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T3
          ON T4.STATDATE = T3.THEDATE
         AND T4.CHANNELID = T3.CHANNELID
         AND T4.VERSIONID = T3.GAMEVERSION;
    COMMIT;

    ---------------------------------------------------FACT_100197_GENERAL_WEEK----------------------------------------------------------------------------------
    V_ERRPOSITION := '1-4';
    DELETE FROM FACT_100197_GENERAL_WEEK T
     WHERE T.STATDATE = V_WEEKFIRSTDAY;
    COMMIT;

    V_ERRPOSITION := '1-5';
    --�û���������
    INSERT INTO FACT_100197_GENERAL_WEEK
      SELECT T4.STATDATE,
             T4.CHANNELID,
             T4.SERVERID,
             '1' DATATYPE,
             '100197' APPID,
             T4.VERSIONID,
             NVL(T1.NEWCOUNT, 0),
             NVL(T2.CONNCOUNT, 0),
             NVL(T3.PAYCOUNT, 0),
             NVL(T3.PAYAMOUNT, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT V_WEEKFIRSTDAY STATDATE,
                     DAC.CHANNELID,
                     DAS.SERVERID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC,
                     DIM_APPSERVER    DAS,
                     DIM_APPVERSION   DAV
               WHERE DAC.APPID = '100197'
                 AND DAS.APPID = '100197'
                 AND DAV.APPID = '100197') T4
        LEFT JOIN (SELECT V_WEEKFIRSTDAY THEDATE,
                          TN.CHANNELID,
                          TN.SERVERID,
                          TN.GAMEID,
                          TN.GAMEVERSION,
                          COUNT(1) NEWCOUNT
                     FROM T_100197_NU TN
                    WHERE TN.THEDATE >=
                          TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                      AND TN.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TN.CHANNELID,
                             TN.SERVERID,
                             TN.GAMEID,
                             TN.GAMEVERSION) T1
          ON T1.THEDATE = T4.STATDATE
         AND T1.CHANNELID = T4.CHANNELID
         AND T1.SERVERID = T4.SERVERID
         AND T1.GAMEVERSION = T4.VERSIONID
        LEFT JOIN (SELECT V_WEEKFIRSTDAY THEDATE,
                          TC.CHANNELID,
                          TC.SERVERID,
                          TC.GAMEID,
                          TC.GAMEVERSION,
                          COUNT(DISTINCT TC.ACCOUNTID) CONNCOUNT
                   --COUNT(DISTINCT TC.DVID) CONNCOUNT
                     FROM T_100197_CONN TC
                    WHERE TC.CONNDATE >= V_WEEKFIRSTDAY
                      AND TC.CONNDATE <
                          TO_CHAR(SYSDATE - V_INPUTDATE + 1, 'YYYY-MM-DD')
                    GROUP BY TC.CHANNELID,
                             TC.SERVERID,
                             TC.GAMEID,
                             TC.GAMEVERSION) T2
          ON T4.STATDATE = T2.THEDATE
         AND T4.CHANNELID = T2.CHANNELID
         AND T4.SERVERID = T2.SERVERID
         AND T4.VERSIONID = T2.GAMEVERSION
        LEFT JOIN (SELECT V_WEEKFIRSTDAY THEDATE,
                          TOS.CHANNELID,
                          TOS.SERVERID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.ACCOUNTID) PAYCOUNT,
                          --COUNT(DISTINCT TOS.DVID) PAYCOUNT,
                          SUM(TOS.MONEY) PAYAMOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >=
                          TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TOS.CHANNELID,
                             TOS.SERVERID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T3
          ON T4.STATDATE = T3.THEDATE
         AND T4.CHANNELID = T3.CHANNELID
         AND T4.SERVERID = T3.SERVERID
         AND T4.VERSIONID = T3.GAMEVERSION;
    COMMIT;

    V_ERRPOSITION := '1-5-1';
    --ALL SERVER
    INSERT INTO FACT_100197_GENERAL_WEEK
      SELECT T4.STATDATE,
             T4.CHANNELID,
             LOWER('all'),
             '1' DATATYPE,
             '100197' APPID,
             T4.VERSIONID,
             NVL(T1.NEWCOUNT, 0),
             NVL(T2.CONNCOUNT, 0),
             NVL(T3.PAYCOUNT, 0),
             NVL(T3.PAYAMOUNT, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT V_WEEKFIRSTDAY STATDATE, DAC.CHANNELID, DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC, DIM_APPVERSION DAV
               WHERE DAC.APPID = '100197'
                 AND DAV.APPID = '100197') T4
        LEFT JOIN (SELECT V_WEEKFIRSTDAY THEDATE,
                          TN.CHANNELID,
                          TN.GAMEID,
                          TN.GAMEVERSION,
                          COUNT(DISTINCT TN.ACCOUNTID) NEWCOUNT
                     FROM T_100197_NU_ALLSERVER TN
                    WHERE TN.THEDATE >=
                          TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                      AND TN.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TN.CHANNELID, TN.GAMEID, TN.GAMEVERSION) T1
          ON T1.THEDATE = T4.STATDATE
         AND T1.CHANNELID = T4.CHANNELID
         AND T1.GAMEVERSION = T4.VERSIONID
        LEFT JOIN (SELECT V_WEEKFIRSTDAY THEDATE,
                          TC.CHANNELID,
                          TC.GAMEID,
                          TC.GAMEVERSION,
                          COUNT(DISTINCT TC.ACCOUNTID) CONNCOUNT
                   --COUNT(DISTINCT TC.DVID) CONNCOUNT
                     FROM T_100197_CONN TC
                    WHERE TC.CONNDATE >= V_WEEKFIRSTDAY
                      AND TC.CONNDATE <
                          TO_CHAR(SYSDATE - V_INPUTDATE + 1, 'YYYY-MM-DD')
                    GROUP BY TC.CHANNELID, TC.GAMEID, TC.GAMEVERSION) T2
          ON T4.STATDATE = T2.THEDATE
         AND T4.CHANNELID = T2.CHANNELID
         AND T4.VERSIONID = T2.GAMEVERSION
        LEFT JOIN (SELECT V_WEEKFIRSTDAY THEDATE,
                          TOS.CHANNELID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.ACCOUNTID) PAYCOUNT,
                          --COUNT(DISTINCT TOS.DVID) PAYCOUNT,
                          SUM(TOS.MONEY) PAYAMOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >=
                          TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TOS.CHANNELID, TOS.GAMEID, TOS.GAMEVERSION) T3
          ON T4.STATDATE = T3.THEDATE
         AND T4.CHANNELID = T3.CHANNELID
         AND T4.VERSIONID = T3.GAMEVERSION;
    COMMIT;

    V_ERRPOSITION := '1-6';
    --�豸��������
    INSERT INTO FACT_100197_GENERAL_WEEK
      SELECT T4.STATDATE,
             T4.CHANNELID,
             T4.SERVERID,
             '2' DATATYPE,
             '100197' APPID,
             T4.VERSIONID,
             NVL(T1.NEWCOUNT, 0),
             NVL(T2.CONNCOUNT, 0),
             NVL(T3.PAYCOUNT, 0),
             NVL(T3.PAYAMOUNT, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT V_WEEKFIRSTDAY STATDATE,
                     DAC.CHANNELID,
                     DAS.SERVERID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC,
                     DIM_APPSERVER    DAS,
                     DIM_APPVERSION   DAV
               WHERE DAC.APPID = '100197'
                 AND DAS.APPID = '100197'
                 AND DAV.APPID = '100197') T4
        LEFT JOIN (SELECT V_WEEKFIRSTDAY THEDATE,
                          TN.CHANNELID,
                          TN.SERVERID,
                          TN.GAMEID,
                          TN.GAMEVERSION,
                          COUNT(1) NEWCOUNT
                     FROM T_100197_NU_MAC TN
                    WHERE TN.THEDATE >=
                          TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                      AND TN.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TN.CHANNELID,
                             TN.SERVERID,
                             TN.GAMEID,
                             TN.GAMEVERSION) T1
          ON T1.THEDATE = T4.STATDATE
         AND T1.CHANNELID = T4.CHANNELID
         AND T1.SERVERID = T4.SERVERID
         AND T1.GAMEVERSION = T4.VERSIONID
        LEFT JOIN (SELECT V_WEEKFIRSTDAY THEDATE,
                          TC.CHANNELID,
                          TC.SERVERID,
                          TC.GAMEID,
                          TC.GAMEVERSION,
                          --COUNT(DISTINCT TC.ACCOUNTID) CONNCOUNT,
                          COUNT(DISTINCT TC.DVID) CONNCOUNT
                     FROM T_100197_CONN_MAC TC
                    WHERE TC.CONNDATE >= V_WEEKFIRSTDAY
                      AND TC.CONNDATE <
                          TO_CHAR(SYSDATE - V_INPUTDATE + 1, 'YYYY-MM-DD')
                    GROUP BY TC.CHANNELID,
                             TC.SERVERID,
                             TC.GAMEID,
                             TC.GAMEVERSION) T2
          ON T4.STATDATE = T2.THEDATE
         AND T4.CHANNELID = T2.CHANNELID
         AND T4.SERVERID = T2.SERVERID
         AND T4.VERSIONID = T2.GAMEVERSION
        LEFT JOIN (SELECT V_WEEKFIRSTDAY THEDATE,
                          TOS.CHANNELID,
                          TOS.SERVERID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          --COUNT(DISTINCT TOS.ACCOUNTID) PAYCOUNT,
                          COUNT(DISTINCT TOS.DVID) PAYCOUNT,
                          SUM(TOS.MONEY) PAYAMOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >=
                          TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TOS.CHANNELID,
                             TOS.SERVERID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T3
          ON T4.STATDATE = T3.THEDATE
         AND T4.CHANNELID = T3.CHANNELID
         AND T4.SERVERID = T3.SERVERID
         AND T4.VERSIONID = T3.GAMEVERSION;
    COMMIT;

    V_ERRPOSITION := '1-6-1';
    --ALL SERVER
    INSERT INTO FACT_100197_GENERAL_WEEK
      SELECT T4.STATDATE,
             T4.CHANNELID,
             LOWER('all'),
             '2' DATATYPE,
             '100197' APPID,
             T4.VERSIONID,
             NVL(T1.NEWCOUNT, 0),
             NVL(T2.CONNCOUNT, 0),
             NVL(T3.PAYCOUNT, 0),
             NVL(T3.PAYAMOUNT, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT V_WEEKFIRSTDAY STATDATE, DAC.CHANNELID, DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC, DIM_APPVERSION DAV
               WHERE DAC.APPID = '100197'
                 AND DAV.APPID = '100197') T4
        LEFT JOIN (SELECT V_WEEKFIRSTDAY THEDATE,
                          TN.CHANNELID,
                          TN.GAMEID,
                          TN.GAMEVERSION,
                          COUNT(DISTINCT TN.DVID) NEWCOUNT
                     FROM T_100197_NU_MAC_ALLSERVER TN
                    WHERE TN.THEDATE >=
                          TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                      AND TN.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TN.CHANNELID, TN.GAMEID, TN.GAMEVERSION) T1
          ON T1.THEDATE = T4.STATDATE
         AND T1.CHANNELID = T4.CHANNELID
         AND T1.GAMEVERSION = T4.VERSIONID
        LEFT JOIN (SELECT V_WEEKFIRSTDAY THEDATE,
                          TC.CHANNELID,
                          TC.GAMEID,
                          TC.GAMEVERSION,
                          --COUNT(DISTINCT TC.ACCOUNTID) CONNCOUNT,
                          COUNT(DISTINCT TC.DVID) CONNCOUNT
                     FROM T_100197_CONN_MAC TC
                    WHERE TC.CONNDATE >= V_WEEKFIRSTDAY
                      AND TC.CONNDATE <
                          TO_CHAR(SYSDATE - V_INPUTDATE + 1, 'YYYY-MM-DD')
                    GROUP BY TC.CHANNELID, TC.GAMEID, TC.GAMEVERSION) T2
          ON T4.STATDATE = T2.THEDATE
         AND T4.CHANNELID = T2.CHANNELID
         AND T4.VERSIONID = T2.GAMEVERSION
        LEFT JOIN (SELECT V_WEEKFIRSTDAY THEDATE,
                          TOS.CHANNELID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          --COUNT(DISTINCT TOS.ACCOUNTID) PAYCOUNT,
                          COUNT(DISTINCT TOS.DVID) PAYCOUNT,
                          SUM(TOS.MONEY) PAYAMOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >=
                          TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TOS.CHANNELID, TOS.GAMEID, TOS.GAMEVERSION) T3
          ON T4.STATDATE = T3.THEDATE
         AND T4.CHANNELID = T3.CHANNELID
         AND T4.VERSIONID = T3.GAMEVERSION;
    COMMIT;

    ---------------------------------------------------FACT_100197_GENERAL_MONTH----------------------------------------------------------------------------------
    V_ERRPOSITION := '1-7';
    DELETE FROM FACT_100197_GENERAL_MONTH T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM');
    COMMIT;

    V_ERRPOSITION := '1-8';
    --�û���������
    INSERT INTO FACT_100197_GENERAL_MONTH
      SELECT T4.STATDATE,
             T4.CHANNELID,
             T4.SERVERID,
             '1' DATATYPE,
             '100197' APPID,
             T4.VERSIONID,
             NVL(T1.NEWCOUNT, 0),
             NVL(T2.CONNCOUNT, 0),
             NVL(T3.PAYCOUNT, 0),
             NVL(T3.PAYAMOUNT, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM') STATDATE,
                     DAC.CHANNELID,
                     DAS.SERVERID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC,
                     DIM_APPSERVER    DAS,
                     DIM_APPVERSION   DAV
               WHERE DAC.APPID = '100197'
                 AND DAS.APPID = '100197'
                 AND DAV.APPID = '100197') T4
        LEFT JOIN (SELECT TO_CHAR(TN.THEDATE, 'YYYY-MM') THEDATE,
                          TN.CHANNELID,
                          TN.SERVERID,
                          TN.GAMEID,
                          TN.GAMEVERSION,
                          COUNT(1) NEWCOUNT
                     FROM T_100197_NU TN
                    WHERE TN.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                      AND TN.THEDATE <
                          TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
                    GROUP BY TO_CHAR(TN.THEDATE, 'YYYY-MM'),
                             TN.CHANNELID,
                             TN.SERVERID,
                             TN.GAMEID,
                             TN.GAMEVERSION) T1
          ON T1.THEDATE = T4.STATDATE
         AND T1.CHANNELID = T4.CHANNELID
         AND T1.SERVERID = T4.SERVERID
         AND T1.GAMEVERSION = T4.VERSIONID
        LEFT JOIN (SELECT SUBSTR(TC.CONNDATE, 0, 7) THEDATE,
                          TC.CHANNELID,
                          TC.SERVERID,
                          TC.GAMEID,
                          TC.GAMEVERSION,
                          COUNT(DISTINCT TC.ACCOUNTID) CONNCOUNT
                   --COUNT(DISTINCT TC.DVID) CONNCOUNT
                     FROM T_100197_CONN TC
                    WHERE TC.CONNDATE >=
                          TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE, 'MM'),
                                  'YYYY-MM-DD')
                      AND TC.CONNDATE <=
                          TO_CHAR(LAST_DAY(SYSDATE - V_INPUTDATE),
                                  'YYYY-MM-DD')
                    GROUP BY SUBSTR(TC.CONNDATE, 0, 7),
                             TC.CHANNELID,
                             TC.SERVERID,
                             TC.GAMEID,
                             TC.GAMEVERSION) T2
          ON T4.STATDATE = T2.THEDATE
         AND T4.CHANNELID = T2.CHANNELID
         AND T4.SERVERID = T2.SERVERID
         AND T4.VERSIONID = T2.GAMEVERSION
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM') THEDATE,
                          TOS.CHANNELID,
                          TOS.SERVERID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.ACCOUNTID) PAYCOUNT,
                          --COUNT(DISTINCT TOS.DVID) PAYCOUNT,
                          SUM(TOS.MONEY) PAYAMOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                      AND TOS.THEDATE <
                          TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM'),
                             TOS.CHANNELID,
                             TOS.SERVERID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T3
          ON T4.STATDATE = T3.THEDATE
         AND T4.CHANNELID = T3.CHANNELID
         AND T4.SERVERID = T3.SERVERID
         AND T4.VERSIONID = T3.GAMEVERSION;
    COMMIT;

    V_ERRPOSITION := '1-8-1';
    --ALL SERVER
    INSERT INTO FACT_100197_GENERAL_MONTH
      SELECT T4.STATDATE,
             T4.CHANNELID,
             LOWER('all'),
             '1' DATATYPE,
             '100197' APPID,
             T4.VERSIONID,
             NVL(T1.NEWCOUNT, 0),
             NVL(T2.CONNCOUNT, 0),
             NVL(T3.PAYCOUNT, 0),
             NVL(T3.PAYAMOUNT, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM') STATDATE,
                     DAC.CHANNELID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC, DIM_APPVERSION DAV
               WHERE DAC.APPID = '100197'
                 AND DAV.APPID = '100197') T4
        LEFT JOIN (SELECT TO_CHAR(TN.THEDATE, 'YYYY-MM') THEDATE,
                          TN.CHANNELID,
                          TN.GAMEID,
                          TN.GAMEVERSION,
                          COUNT(DISTINCT TN.ACCOUNTID) NEWCOUNT
                     FROM T_100197_NU_ALLSERVER TN
                    WHERE TN.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                      AND TN.THEDATE <
                          TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
                    GROUP BY TO_CHAR(TN.THEDATE, 'YYYY-MM'),
                             TN.CHANNELID,
                             TN.GAMEID,
                             TN.GAMEVERSION) T1
          ON T1.THEDATE = T4.STATDATE
         AND T1.CHANNELID = T4.CHANNELID
         AND T1.GAMEVERSION = T4.VERSIONID
        LEFT JOIN (SELECT SUBSTR(TC.CONNDATE, 0, 7) THEDATE,
                          TC.CHANNELID,
                          TC.GAMEID,
                          TC.GAMEVERSION,
                          COUNT(DISTINCT TC.ACCOUNTID) CONNCOUNT
                   --COUNT(DISTINCT TC.DVID) CONNCOUNT
                     FROM T_100197_CONN TC
                    WHERE TC.CONNDATE >=
                          TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE, 'MM'),
                                  'YYYY-MM-DD')
                      AND TC.CONNDATE <=
                          TO_CHAR(LAST_DAY(SYSDATE - V_INPUTDATE),
                                  'YYYY-MM-DD')
                    GROUP BY SUBSTR(TC.CONNDATE, 0, 7),
                             TC.CHANNELID,
                             TC.GAMEID,
                             TC.GAMEVERSION) T2
          ON T4.STATDATE = T2.THEDATE
         AND T4.CHANNELID = T2.CHANNELID
         AND T4.VERSIONID = T2.GAMEVERSION
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM') THEDATE,
                          TOS.CHANNELID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.ACCOUNTID) PAYCOUNT,
                          --COUNT(DISTINCT TOS.DVID) PAYCOUNT,
                          SUM(TOS.MONEY) PAYAMOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                      AND TOS.THEDATE <
                          TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM'),
                             TOS.CHANNELID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T3
          ON T4.STATDATE = T3.THEDATE
         AND T4.CHANNELID = T3.CHANNELID
         AND T4.VERSIONID = T3.GAMEVERSION;
    COMMIT;

    V_ERRPOSITION := '1-9';
    --�豸��������
    INSERT INTO FACT_100197_GENERAL_MONTH
      SELECT T4.STATDATE,
             T4.CHANNELID,
             T4.SERVERID,
             '2' DATATYPE,
             '100197' APPID,
             T4.VERSIONID,
             NVL(T1.NEWCOUNT, 0),
             NVL(T2.CONNCOUNT, 0),
             NVL(T3.PAYCOUNT, 0),
             NVL(T3.PAYAMOUNT, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM') STATDATE,
                     DAC.CHANNELID,
                     DAS.SERVERID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC,
                     DIM_APPSERVER    DAS,
                     DIM_APPVERSION   DAV
               WHERE DAC.APPID = '100197'
                 AND DAS.APPID = '100197'
                 AND DAV.APPID = '100197') T4
        LEFT JOIN (SELECT TO_CHAR(TN.THEDATE, 'YYYY-MM') THEDATE,
                          TN.CHANNELID,
                          TN.SERVERID,
                          TN.GAMEID,
                          TN.GAMEVERSION,
                          COUNT(1) NEWCOUNT
                     FROM T_100197_NU_MAC TN
                    WHERE TN.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                      AND TN.THEDATE <
                          TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
                    GROUP BY TO_CHAR(TN.THEDATE, 'YYYY-MM'),
                             TN.CHANNELID,
                             TN.SERVERID,
                             TN.GAMEID,
                             TN.GAMEVERSION) T1
          ON T1.THEDATE = T4.STATDATE
         AND T1.CHANNELID = T4.CHANNELID
         AND T1.SERVERID = T4.SERVERID
         AND T1.GAMEVERSION = T4.VERSIONID
        LEFT JOIN (SELECT SUBSTR(TC.CONNDATE, 0, 7) THEDATE,
                          TC.CHANNELID,
                          TC.SERVERID,
                          TC.GAMEID,
                          TC.GAMEVERSION,
                          --COUNT(DISTINCT TC.ACCOUNTID) CONNCOUNT,
                          COUNT(DISTINCT TC.DVID) CONNCOUNT
                     FROM T_100197_CONN_MAC TC
                    WHERE TC.CONNDATE >=
                          TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE, 'MM'),
                                  'YYYY-MM-DD')
                      AND TC.CONNDATE <=
                          TO_CHAR(LAST_DAY(SYSDATE - V_INPUTDATE),
                                  'YYYY-MM-DD')
                    GROUP BY SUBSTR(TC.CONNDATE, 0, 7),
                             TC.CHANNELID,
                             TC.SERVERID,
                             TC.GAMEID,
                             TC.GAMEVERSION) T2
          ON T4.STATDATE = T2.THEDATE
         AND T4.CHANNELID = T2.CHANNELID
         AND T4.SERVERID = T2.SERVERID
         AND T4.VERSIONID = T2.GAMEVERSION
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM') THEDATE,
                          TOS.CHANNELID,
                          TOS.SERVERID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          --COUNT(DISTINCT TOS.ACCOUNTID) PAYCOUNT,
                          COUNT(DISTINCT TOS.DVID) PAYCOUNT,
                          SUM(TOS.MONEY) PAYAMOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                      AND TOS.THEDATE <
                          TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM'),
                             TOS.CHANNELID,
                             TOS.SERVERID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T3
          ON T4.STATDATE = T3.THEDATE
         AND T4.CHANNELID = T3.CHANNELID
         AND T4.SERVERID = T3.SERVERID
         AND T4.VERSIONID = T3.GAMEVERSION;
    COMMIT;

    V_ERRPOSITION := '1-9-1';
    --ALL SERVER
    INSERT INTO FACT_100197_GENERAL_MONTH
      SELECT T4.STATDATE,
             T4.CHANNELID,
             LOWER('all'),
             '2' DATATYPE,
             '100197' APPID,
             T4.VERSIONID,
             NVL(T1.NEWCOUNT, 0),
             NVL(T2.CONNCOUNT, 0),
             NVL(T3.PAYCOUNT, 0),
             NVL(T3.PAYAMOUNT, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM') STATDATE,
                     DAC.CHANNELID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC, DIM_APPVERSION DAV
               WHERE DAC.APPID = '100197'
                 AND DAV.APPID = '100197') T4
        LEFT JOIN (SELECT TO_CHAR(TN.THEDATE, 'YYYY-MM') THEDATE,
                          TN.CHANNELID,
                          TN.GAMEID,
                          TN.GAMEVERSION,
                          COUNT(DISTINCT TN.DVID) NEWCOUNT
                     FROM T_100197_NU_MAC_ALLSERVER TN
                    WHERE TN.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                      AND TN.THEDATE <
                          TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
                    GROUP BY TO_CHAR(TN.THEDATE, 'YYYY-MM'),
                             TN.CHANNELID,
                             TN.GAMEID,
                             TN.GAMEVERSION) T1
          ON T1.THEDATE = T4.STATDATE
         AND T1.CHANNELID = T4.CHANNELID
         AND T1.GAMEVERSION = T4.VERSIONID
        LEFT JOIN (SELECT SUBSTR(TC.CONNDATE, 0, 7) THEDATE,
                          TC.CHANNELID,
                          TC.GAMEID,
                          TC.GAMEVERSION,
                          --COUNT(DISTINCT TC.ACCOUNTID) CONNCOUNT,
                          COUNT(DISTINCT TC.DVID) CONNCOUNT
                     FROM T_100197_CONN_MAC TC
                    WHERE TC.CONNDATE >=
                          TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE, 'MM'),
                                  'YYYY-MM-DD')
                      AND TC.CONNDATE <=
                          TO_CHAR(LAST_DAY(SYSDATE - V_INPUTDATE),
                                  'YYYY-MM-DD')
                    GROUP BY SUBSTR(TC.CONNDATE, 0, 7),
                             TC.CHANNELID,
                             TC.GAMEID,
                             TC.GAMEVERSION) T2
          ON T4.STATDATE = T2.THEDATE
         AND T4.CHANNELID = T2.CHANNELID
         AND T4.VERSIONID = T2.GAMEVERSION
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM') THEDATE,
                          TOS.CHANNELID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          --COUNT(DISTINCT TOS.ACCOUNTID) PAYCOUNT,
                          COUNT(DISTINCT TOS.DVID) PAYCOUNT,
                          SUM(TOS.MONEY) PAYAMOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                      AND TOS.THEDATE <
                          TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM'),
                             TOS.CHANNELID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T3
          ON T4.STATDATE = T3.THEDATE
         AND T4.CHANNELID = T3.CHANNELID
         AND T4.VERSIONID = T3.GAMEVERSION;
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_100197_GENERAL_DAY��FACT_100197_GENERAL_WEEK��FACT_100197_GENERAL_MONTH';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_100197_FIRSTPAY����***************************************************************/
  --����FACT_100197_FIRSTPAY����
  PROCEDURE P_FACT_FIRSTPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;

  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_FIRSTPAY';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    --�����û��״γ�ֵ������
    V_ERRPOSITION := '1-1';
    DELETE FROM FACT_100197_FIRSTPAY T
     WHERE T.FIRSTPAYDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    V_ERRPOSITION := '1-2';
    INSERT INTO FACT_100197_FIRSTPAY
      SELECT TO_CHAR(T.THEDATE, 'YYYY-MM-DD'),
             TO_CHAR(T.FIRSTPAYDATE, 'YYYY-MM-DD'),
             T.CHANNELID,
             T.SERVERID,
             '1',
             T.GAMEID,
             T.FIRST_PAYFROMREG,
             COUNT(DISTINCT T.ACCOUNTID) FIRST_PAYCOUNT,
             SUM(T.FIRSTPAYMONEY) FIRST_PAYAMOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TNP.THEDATE,
                     TNP.FIRSTPAYDATE,
                     TNP.CHANNELID,
                     TNP.SERVERID,
                     TNP.GAMEID,
                     TNP.ACCOUNTID,
                     TRUNC(TNP.FIRSTPAYDATE) - TRUNC(TNP.THEDATE) FIRST_PAYFROMREG,
                     TNP.FIRSTPAYMONEY
                FROM T_100197_NU_PAY TNP
               WHERE TNP.FIRSTPAYDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                 AND TNP.FIRSTPAYDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)) T
       WHERE T.FIRST_PAYFROMREG <= 30
       GROUP BY TO_CHAR(T.THEDATE, 'YYYY-MM-DD'),
                TO_CHAR(T.FIRSTPAYDATE, 'YYYY-MM-DD'),
                T.CHANNELID,
                T.SERVERID,
                T.GAMEID,
                T.FIRST_PAYFROMREG;
    COMMIT;

    V_ERRPOSITION := '1-2-1';
    --ALL SERVER
    INSERT INTO FACT_100197_FIRSTPAY
      SELECT TO_CHAR(T.THEDATE, 'YYYY-MM-DD'),
             TO_CHAR(T.FIRSTPAYDATE, 'YYYY-MM-DD'),
             T.CHANNELID,
             LOWER('all'),
             '1',
             T.GAMEID,
             T.FIRST_PAYFROMREG,
             COUNT(DISTINCT T.ACCOUNTID) FIRST_PAYCOUNT,
             SUM(T.FIRSTPAYMONEY) FIRST_PAYAMOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TNP.THEDATE,
                     TNP.FIRSTPAYDATE,
                     TNP.CHANNELID,
                     TNP.GAMEID,
                     TNP.ACCOUNTID,
                     TRUNC(TNP.FIRSTPAYDATE) - TRUNC(TNP.THEDATE) FIRST_PAYFROMREG,
                     TNP.FIRSTPAYMONEY
                FROM T_100197_NU_PAY_AS TNP
               WHERE TNP.FIRSTPAYDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                 AND TNP.FIRSTPAYDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)) T
       WHERE T.FIRST_PAYFROMREG <= 30
       GROUP BY TO_CHAR(T.THEDATE, 'YYYY-MM-DD'),
                TO_CHAR(T.FIRSTPAYDATE, 'YYYY-MM-DD'),
                T.CHANNELID,
                T.GAMEID,
                T.FIRST_PAYFROMREG;
    COMMIT;

    --�״θ��ѽ�������
    V_ERRPOSITION := '1-3';
    DELETE FROM FACT_100197_FIRSTPAY_AMOUNT T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    V_ERRPOSITION := '1-4';
    INSERT INTO FACT_100197_FIRSTPAY_AMOUNT
      SELECT TO_CHAR(T.FIRSTPAYDATE, 'YYYY-MM-DD') STATDATE,
             T.CHANNELID,
             T.SERVERID,
             '1',
             T.GAMEID,
             T.GAMEVERSION,
             T.FIRSTPAYMONEY,
             COUNT(1) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM T_100197_NU_PAY T
       WHERE T.FIRSTPAYDATE >= TRUNC(SYSDATE - V_INPUTDATE)
         AND T.FIRSTPAYDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
       GROUP BY TO_CHAR(T.FIRSTPAYDATE, 'YYYY-MM-DD'),
                T.GAMEID,
                T.CHANNELID,
                T.SERVERID,
                T.GAMEVERSION,
                T.FIRSTPAYMONEY;
    COMMIT;

    V_ERRPOSITION := '1-4-1';
    --ALL SERVER
    INSERT INTO FACT_100197_FIRSTPAY_AMOUNT
      SELECT TO_CHAR(T.FIRSTPAYDATE, 'YYYY-MM-DD') STATDATE,
             T.CHANNELID,
             LOWER('all'),
             '1',
             T.GAMEID,
             T.GAMEVERSION,
             T.FIRSTPAYMONEY,
             COUNT(DISTINCT T.ACCOUNTID) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM T_100197_NU_PAY_AS T
       WHERE T.FIRSTPAYDATE >= TRUNC(SYSDATE - V_INPUTDATE)
         AND T.FIRSTPAYDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
       GROUP BY TO_CHAR(T.FIRSTPAYDATE, 'YYYY-MM-DD'),
                T.GAMEID,
                T.CHANNELID,
                T.GAMEVERSION,
                T.FIRSTPAYMONEY;
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_100197_FIRSTPAY��FACT_100197_FIRSTPAY_AMOUNT';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_100197_PAYHABIT����***************************************************************/
  --����FACT_100197_PAYHABIT����
  PROCEDURE P_FACT_PAYHABIT(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
    V_WEEKFIRSTDAY VARCHAR2(10); --���������ҳ� ������������ܵĵ�һ��
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;

    --��ȡ�ܵ�һ��
    SELECT TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE + 1) -
                   DECODE((TO_CHAR(SYSDATE - V_INPUTDATE, 'D') - 1),
                          0,
                          7,
                          (TO_CHAR(SYSDATE - V_INPUTDATE, 'D') - 1)),
                   'YYYY-MM-DD')
      INTO V_WEEKFIRSTDAY
      FROM DUAL;

    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_PAYHABIT';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    ---------------------------------------------------FACT_100197_PAYTYPE----------------------------------------------------------------------------------
    V_ERRPOSITION := '1-1';
    DELETE FROM FACT_100197_PAYTYPE T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    V_ERRPOSITION := '1-2';
    --��ֵ���ͱ�
    INSERT INTO FACT_100197_PAYTYPE
      SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATEID,
             TOS.CHANNELID,
             TOS.SERVERID,
             '1' DATATYPE,
             TOS.GAMEID APPID,
             TOS.GAMEVERSION VERSIONID,
             TOS.IAPID PAYTYPEID,
             SUM(TOS.MONEY) PAYAMOUNT,
             COUNT(DISTINCT TOS.ACCOUNTID) PAYCOUNT,
             COUNT(TOS.IAPID) PAYNUM,
             SYSDATE,
             V_ERRSOURCE
        FROM T_100197_ORDER_SUCC TOS
       WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
         AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
       GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                TOS.CHANNELID,
                TOS.SERVERID,
                TOS.GAMEID,
                TOS.GAMEVERSION,
                TOS.IAPID;
    COMMIT;

    V_ERRPOSITION := '1-2-1';
    --ALL SERVER
    INSERT INTO FACT_100197_PAYTYPE
      SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATEID,
             TOS.CHANNELID,
             LOWER('all'),
             '1' DATATYPE,
             TOS.GAMEID APPID,
             TOS.GAMEVERSION VERSIONID,
             TOS.IAPID PAYTYPEID,
             SUM(TOS.MONEY) PAYAMOUNT,
             COUNT(DISTINCT TOS.ACCOUNTID) PAYCOUNT,
             COUNT(TOS.IAPID) PAYNUM,
             SYSDATE,
             V_ERRSOURCE
        FROM T_100197_ORDER_SUCC TOS
       WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
         AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
       GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                TOS.CHANNELID,
                TOS.GAMEID,
                TOS.GAMEVERSION,
                TOS.IAPID;
    COMMIT;

    ---------------------------------------------------FACT_100197_PAYWAY----------------------------------------------------------------------------------
    V_ERRPOSITION := '1-3';
    DELETE FROM FACT_100197_PAYWAY T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    V_ERRPOSITION := '1-4';
    --��ֵ��ʽ��
    INSERT INTO FACT_100197_PAYWAY
      SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
             TOS.CHANNELID,
             TOS.SERVERID,
             '1' DATATYPE,
             TOS.GAMEID APPID,
             TOS.GAMEVERSION VERSIONID,
             TOS.PAYCHANNEL PAYWAYID,
             SUM(TOS.MONEY) PAYAMOUNT,
             COUNT(DISTINCT TOS.ACCOUNTID) PAYCOUNT,
             COUNT(TOS.PAYCHANNEL) PAYNUM,
             SYSDATE,
             V_ERRSOURCE
        FROM T_100197_ORDER_SUCC TOS
       WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
         AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
       GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                TOS.CHANNELID,
                TOS.SERVERID,
                TOS.GAMEID,
                TOS.GAMEVERSION,
                TOS.PAYCHANNEL;
    COMMIT;

    V_ERRPOSITION := '1-4-1';
    --ALL SERVER
    INSERT INTO FACT_100197_PAYWAY
      SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
             TOS.CHANNELID,
             LOWER('all'),
             '1' DATATYPE,
             TOS.GAMEID APPID,
             TOS.GAMEVERSION VERSIONID,
             TOS.PAYCHANNEL PAYWAYID,
             SUM(TOS.MONEY) PAYAMOUNT,
             COUNT(DISTINCT TOS.ACCOUNTID) PAYCOUNT,
             COUNT(TOS.PAYCHANNEL) PAYNUM,
             SYSDATE,
             V_ERRSOURCE
        FROM T_100197_ORDER_SUCC TOS
       WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
         AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
       GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                TOS.CHANNELID,
                TOS.GAMEID,
                TOS.GAMEVERSION,
                TOS.PAYCHANNEL;
    COMMIT;

    ---------------------------------------------------FACT_100197_PAYNUM_DAY----------------------------------------------------------------------------------
    V_ERRPOSITION := '1-5';
    DELETE FROM FACT_100197_PAYNUM_DAY T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    V_ERRPOSITION := '1-6';
    --�����û����Ѵ������û���
    INSERT INTO FACT_100197_PAYNUM_DAY
      SELECT T.STATDATE,
             T.CHANNELID,
             T.SERVERID,
             '1',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYNUM,
             COUNT(1) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                     TOS.CHANNELID,
                     TOS.SERVERID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.ACCOUNTID,
                     COUNT(1) PAYNUM
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                 AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                        TOS.CHANNELID,
                        TOS.SERVERID,
                        TOS.GAMEID,
                        TOS.GAMEVERSION,
                        TOS.ACCOUNTID) T
       GROUP BY T.STATDATE,
                T.CHANNELID,
                T.SERVERID,
                T.GAMEID,
                T.GAMEVERSION,
                T.PAYNUM;
    COMMIT;

    V_ERRPOSITION := '1-6-1';
    --ALL SERVER
    INSERT INTO FACT_100197_PAYNUM_DAY
      SELECT T.STATDATE,
             T.CHANNELID,
             LOWER('all'),
             '1',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYNUM,
             COUNT(DISTINCT T.ACCOUNTID) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                     TOS.CHANNELID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.ACCOUNTID,
                     COUNT(1) PAYNUM
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                 AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                        TOS.CHANNELID,
                        TOS.GAMEID,
                        TOS.GAMEVERSION,
                        TOS.ACCOUNTID) T
       GROUP BY T.STATDATE, T.CHANNELID, T.GAMEID, T.GAMEVERSION, T.PAYNUM;
    COMMIT;

    V_ERRPOSITION := '1-7';
    --�����豸���Ѵ���
    INSERT INTO FACT_100197_PAYNUM_DAY
      SELECT T.STATDATE,
             T.CHANNELID,
             T.SERVERID,
             '2',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYNUM,
             COUNT(1) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                     TOS.CHANNELID,
                     TOS.SERVERID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.DVID,
                     COUNT(1) PAYNUM
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                 AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                        TOS.CHANNELID,
                        TOS.SERVERID,
                        TOS.GAMEID,
                        TOS.GAMEVERSION,
                        TOS.DVID) T
       GROUP BY T.STATDATE,
                T.CHANNELID,
                T.SERVERID,
                T.GAMEID,
                T.GAMEVERSION,
                T.PAYNUM;
    COMMIT;

    V_ERRPOSITION := '1-7-1';
    --ALL SRVER
    INSERT INTO FACT_100197_PAYNUM_DAY
      SELECT T.STATDATE,
             T.CHANNELID,
             LOWER('all'),
             '2',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYNUM,
             COUNT(DISTINCT T.DVID) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                     TOS.CHANNELID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.DVID,
                     COUNT(1) PAYNUM
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                 AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                        TOS.CHANNELID,
                        TOS.GAMEID,
                        TOS.GAMEVERSION,
                        TOS.DVID) T
       GROUP BY T.STATDATE, T.CHANNELID, T.GAMEID, T.GAMEVERSION, T.PAYNUM;
    COMMIT;

    ---------------------------------------------------FACT_100197_PAYNUM_WEEK----------------------------------------------------------------------------------
    V_ERRPOSITION := '1-8';
    DELETE FROM FACT_100197_PAYNUM_WEEK T
     WHERE T.STATDATE = V_WEEKFIRSTDAY;
    COMMIT;

    V_ERRPOSITION := '1-9';
    --�����û����Ѵ������û������ܣ�
    INSERT INTO FACT_100197_PAYNUM_WEEK
      SELECT T.STATDATE,
             T.CHANNELID,
             T.SERVERID,
             '1',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYNUM,
             COUNT(1) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT V_WEEKFIRSTDAY STATDATE,
                     TOS.CHANNELID,
                     TOS.SERVERID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.ACCOUNTID,
                     COUNT(1) PAYNUM
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                 AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TOS.CHANNELID,
                        TOS.SERVERID,
                        TOS.GAMEID,
                        TOS.GAMEVERSION,
                        TOS.ACCOUNTID) T
       GROUP BY T.STATDATE,
                T.CHANNELID,
                T.SERVERID,
                T.GAMEID,
                T.GAMEVERSION,
                T.PAYNUM;
    COMMIT;

    V_ERRPOSITION := '1-9-1';
    --ALL SERVER
    INSERT INTO FACT_100197_PAYNUM_WEEK
      SELECT T.STATDATE,
             T.CHANNELID,
             LOWER('all'),
             '1',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYNUM,
             COUNT(DISTINCT T.ACCOUNTID) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT V_WEEKFIRSTDAY STATDATE,
                     TOS.CHANNELID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.ACCOUNTID,
                     COUNT(1) PAYNUM
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                 AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TOS.CHANNELID,
                        TOS.GAMEID,
                        TOS.GAMEVERSION,
                        TOS.ACCOUNTID) T
       GROUP BY T.STATDATE, T.CHANNELID, T.GAMEID, T.GAMEVERSION, T.PAYNUM;
    COMMIT;

    V_ERRPOSITION := '1-10';
    --�����豸���Ѵ������ܣ�
    INSERT INTO FACT_100197_PAYNUM_WEEK
      SELECT T.STATDATE,
             T.CHANNELID,
             T.SERVERID,
             '2',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYNUM,
             COUNT(1) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT V_WEEKFIRSTDAY STATDATE,
                     TOS.CHANNELID,
                     TOS.SERVERID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.DVID,
                     COUNT(1) PAYNUM
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                 AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TOS.CHANNELID,
                        TOS.SERVERID,
                        TOS.GAMEID,
                        TOS.GAMEVERSION,
                        TOS.DVID) T
       GROUP BY T.STATDATE,
                T.CHANNELID,
                T.SERVERID,
                T.GAMEID,
                T.GAMEVERSION,
                T.PAYNUM;
    COMMIT;

    V_ERRPOSITION := '1-10-1';
    --ALL SERVER
    INSERT INTO FACT_100197_PAYNUM_WEEK
      SELECT T.STATDATE,
             T.CHANNELID,
             LOWER('all'),
             '2',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYNUM,
             COUNT(DISTINCT T.DVID) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT V_WEEKFIRSTDAY STATDATE,
                     TOS.CHANNELID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.DVID,
                     COUNT(1) PAYNUM
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                 AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TOS.CHANNELID, TOS.GAMEID, TOS.GAMEVERSION, TOS.DVID) T
       GROUP BY T.STATDATE, T.CHANNELID, T.GAMEID, T.GAMEVERSION, T.PAYNUM;
    COMMIT;

    ---------------------------------------------------FACT_100197_PAYNUM_MONTH----------------------------------------------------------------------------------
    V_ERRPOSITION := '1-11';
    DELETE FROM FACT_100197_PAYNUM_MONTH T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM');
    COMMIT;

    V_ERRPOSITION := '1-12';
    --�����û����Ѵ������û���(��)
    INSERT INTO FACT_100197_PAYNUM_MONTH
      SELECT T.STATDATE,
             T.CHANNELID,
             T.SERVERID,
             '1',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYNUM,
             COUNT(1) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM') STATDATE,
                     TOS.CHANNELID,
                     TOS.SERVERID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.ACCOUNTID,
                     COUNT(1) PAYNUM
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                 AND TOS.THEDATE <
                     TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
               GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM'),
                        TOS.CHANNELID,
                        TOS.SERVERID,
                        TOS.GAMEID,
                        TOS.GAMEVERSION,
                        TOS.ACCOUNTID) T
       GROUP BY T.STATDATE,
                T.CHANNELID,
                T.SERVERID,
                T.GAMEID,
                T.GAMEVERSION,
                T.PAYNUM;
    COMMIT;

    V_ERRPOSITION := '1-12-1';
    --ALL SERVER
    INSERT INTO FACT_100197_PAYNUM_MONTH
      SELECT T.STATDATE,
             T.CHANNELID,
             LOWER('all'),
             '1',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYNUM,
             COUNT(DISTINCT T.ACCOUNTID) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM') STATDATE,
                     TOS.CHANNELID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.ACCOUNTID,
                     COUNT(1) PAYNUM
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                 AND TOS.THEDATE <
                     TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
               GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM'),
                        TOS.CHANNELID,
                        TOS.GAMEID,
                        TOS.GAMEVERSION,
                        TOS.ACCOUNTID) T
       GROUP BY T.STATDATE, T.CHANNELID, T.GAMEID, T.GAMEVERSION, T.PAYNUM;
    COMMIT;

    V_ERRPOSITION := '1-13';
    --�����豸���Ѵ������£�
    INSERT INTO FACT_100197_PAYNUM_MONTH
      SELECT T.STATDATE,
             T.CHANNELID,
             T.SERVERID,
             '2',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYNUM,
             COUNT(1) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM') STATDATE,
                     TOS.CHANNELID,
                     TOS.SERVERID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.DVID,
                     COUNT(1) PAYNUM
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                 AND TOS.THEDATE <
                     TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
               GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM'),
                        TOS.CHANNELID,
                        TOS.SERVERID,
                        TOS.GAMEID,
                        TOS.GAMEVERSION,
                        TOS.DVID) T
       GROUP BY T.STATDATE,
                T.CHANNELID,
                T.SERVERID,
                T.GAMEID,
                T.GAMEVERSION,
                T.PAYNUM;
    COMMIT;

    V_ERRPOSITION := '1-13-1';
    --ALL SERCER
    INSERT INTO FACT_100197_PAYNUM_MONTH
      SELECT T.STATDATE,
             T.CHANNELID,
             LOWER('all'),
             '2',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYNUM,
             COUNT(DISTINCT T.DVID) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM') STATDATE,
                     TOS.CHANNELID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.DVID,
                     COUNT(1) PAYNUM
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                 AND TOS.THEDATE <
                     TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
               GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM'),
                        TOS.CHANNELID,
                        TOS.GAMEID,
                        TOS.GAMEVERSION,
                        TOS.DVID) T
       GROUP BY T.STATDATE, T.CHANNELID, T.GAMEID, T.GAMEVERSION, T.PAYNUM;
    COMMIT;

    ---------------------------------------------------FACT_100197_PAYAMOUNT_DAY----------------------------------------------------------------------------------
    V_ERRPOSITION := '1-14';
    DELETE FROM FACT_100197_PAYAMOUNT_DAY T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    --���븶�ѽ��ĸ����û���
    V_ERRPOSITION := '1-15';
    INSERT INTO FACT_100197_PAYAMOUNT_DAY
      SELECT T.STATDATE,
             T.CHANNELID,
             T.SERVERID,
             '1',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYAMOUNT,
             COUNT(1) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                     TOS.CHANNELID,
                     TOS.SERVERID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.ACCOUNTID,
                     TRUNC(SUM(TOS.MONEY), -1) PAYAMOUNT
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                 AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                        TOS.CHANNELID,
                        TOS.SERVERID,
                        TOS.GAMEID,
                        TOS.GAMEVERSION,
                        TOS.ACCOUNTID) T
       GROUP BY T.STATDATE,
                T.CHANNELID,
                T.SERVERID,
                T.GAMEID,
                T.GAMEVERSION,
                T.PAYAMOUNT;
    COMMIT;

    --ALL SERVER
    V_ERRPOSITION := '1-15-1';
    INSERT INTO FACT_100197_PAYAMOUNT_DAY
      SELECT T.STATDATE,
             T.CHANNELID,
             LOWER('all'),
             '1',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYAMOUNT,
             COUNT(DISTINCT T.ACCOUNTID) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                     TOS.CHANNELID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.ACCOUNTID,
                     TRUNC(SUM(TOS.MONEY), -1) PAYAMOUNT
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                 AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                        TOS.CHANNELID,
                        TOS.GAMEID,
                        TOS.GAMEVERSION,
                        TOS.ACCOUNTID) T
       GROUP BY T.STATDATE,
                T.CHANNELID,
                T.GAMEID,
                T.GAMEVERSION,
                T.PAYAMOUNT;
    COMMIT;

    --���븶�ѽ��ĸ����豸��
    V_ERRPOSITION := '1-16';
    INSERT INTO FACT_100197_PAYAMOUNT_DAY
      SELECT T.STATDATE,
             T.CHANNELID,
             T.SERVERID,
             '2',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYAMOUNT,
             COUNT(1) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                     TOS.CHANNELID,
                     TOS.SERVERID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.DVID,
                     TRUNC(SUM(TOS.MONEY), -1) PAYAMOUNT
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                 AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                        TOS.CHANNELID,
                        TOS.SERVERID,
                        TOS.GAMEID,
                        TOS.GAMEVERSION,
                        TOS.DVID) T
       GROUP BY T.STATDATE,
                T.CHANNELID,
                T.SERVERID,
                T.GAMEID,
                T.GAMEVERSION,
                T.PAYAMOUNT;
    COMMIT;

    --ALL SERVER
    V_ERRPOSITION := '1-16-1';
    INSERT INTO FACT_100197_PAYAMOUNT_DAY
      SELECT T.STATDATE,
             T.CHANNELID,
             LOWER('all'),
             '2',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYAMOUNT,
             COUNT(DISTINCT T.DVID) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                     TOS.CHANNELID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.DVID,
                     TRUNC(SUM(TOS.MONEY), -1) PAYAMOUNT
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                 AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                        TOS.CHANNELID,
                        TOS.GAMEID,
                        TOS.GAMEVERSION,
                        TOS.DVID) T
       GROUP BY T.STATDATE,
                T.CHANNELID,
                T.GAMEID,
                T.GAMEVERSION,
                T.PAYAMOUNT;
    COMMIT;

    ---------------------------------------------------FACT_100197_PAYAMOUNT_WEEK----------------------------------------------------------------------------------
    V_ERRPOSITION := '1-17';
    DELETE FROM FACT_100197_PAYAMOUNT_WEEK T
     WHERE T.STATDATE = V_WEEKFIRSTDAY;
    COMMIT;

    --���븶�ѽ��ĸ����û���
    V_ERRPOSITION := '1-18';
    INSERT INTO FACT_100197_PAYAMOUNT_WEEK
      SELECT T.STATDATE,
             T.CHANNELID,
             T.SERVERID,
             '1',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYAMOUNT,
             COUNT(1) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT V_WEEKFIRSTDAY STATDATE,
                     TOS.CHANNELID,
                     TOS.SERVERID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.ACCOUNTID,
                     TRUNC(SUM(TOS.MONEY), -1) PAYAMOUNT
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                 AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TOS.CHANNELID,
                        TOS.SERVERID,
                        TOS.GAMEID,
                        TOS.GAMEVERSION,
                        TOS.ACCOUNTID) T
       GROUP BY T.STATDATE,
                T.CHANNELID,
                T.SERVERID,
                T.GAMEID,
                T.GAMEVERSION,
                T.PAYAMOUNT;
    COMMIT;

    --ALL SERVER
    V_ERRPOSITION := '1-18-1';
    INSERT INTO FACT_100197_PAYAMOUNT_WEEK
      SELECT T.STATDATE,
             T.CHANNELID,
             LOWER('all'),
             '1',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYAMOUNT,
             COUNT(DISTINCT T.ACCOUNTID) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT V_WEEKFIRSTDAY STATDATE,
                     TOS.CHANNELID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.ACCOUNTID,
                     TRUNC(SUM(TOS.MONEY), -1) PAYAMOUNT
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                 AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TOS.CHANNELID,
                        TOS.GAMEID,
                        TOS.GAMEVERSION,
                        TOS.ACCOUNTID) T
       GROUP BY T.STATDATE,
                T.CHANNELID,
                T.GAMEID,
                T.GAMEVERSION,
                T.PAYAMOUNT;
    COMMIT;

    --���븶�ѽ��ĸ����豸��
    V_ERRPOSITION := '1-19';
    INSERT INTO FACT_100197_PAYAMOUNT_WEEK
      SELECT T.STATDATE,
             T.CHANNELID,
             T.SERVERID,
             '2',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYAMOUNT,
             COUNT(1) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT V_WEEKFIRSTDAY STATDATE,
                     TOS.CHANNELID,
                     TOS.SERVERID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.DVID,
                     TRUNC(SUM(TOS.MONEY), -1) PAYAMOUNT
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                 AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TOS.CHANNELID,
                        TOS.SERVERID,
                        TOS.GAMEID,
                        TOS.GAMEVERSION,
                        TOS.DVID) T
       GROUP BY T.STATDATE,
                T.CHANNELID,
                T.SERVERID,
                T.GAMEID,
                T.GAMEVERSION,
                T.PAYAMOUNT;
    COMMIT;

    --ALL SERVER
    V_ERRPOSITION := '1-19-1';
    INSERT INTO FACT_100197_PAYAMOUNT_WEEK
      SELECT T.STATDATE,
             T.CHANNELID,
             LOWER('all'),
             '2',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYAMOUNT,
             COUNT(DISTINCT T.DVID) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT V_WEEKFIRSTDAY STATDATE,
                     TOS.CHANNELID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.DVID,
                     TRUNC(SUM(TOS.MONEY), -1) PAYAMOUNT
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                 AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TOS.CHANNELID, TOS.GAMEID, TOS.GAMEVERSION, TOS.DVID) T
       GROUP BY T.STATDATE,
                T.CHANNELID,
                T.GAMEID,
                T.GAMEVERSION,
                T.PAYAMOUNT;
    COMMIT;

    ---------------------------------------------------FACT_100197_PAYAMOUNT_MONTH----------------------------------------------------------------------------------
    V_ERRPOSITION := '1-20';
    DELETE FROM FACT_100197_PAYAMOUNT_MONTH T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM');
    COMMIT;

    --���븶�ѽ��ĸ����û���
    V_ERRPOSITION := '1-21';
    INSERT INTO FACT_100197_PAYAMOUNT_MONTH
      SELECT T.STATDATE,
             T.CHANNELID,
             T.SERVERID,
             '1',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYAMOUNT,
             COUNT(1) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM') STATDATE,
                     TOS.CHANNELID,
                     TOS.SERVERID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.ACCOUNTID,
                     TRUNC(SUM(TOS.MONEY), -1) PAYAMOUNT
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                 AND TOS.THEDATE <
                     TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
               GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM'),
                        TOS.CHANNELID,
                        TOS.SERVERID,
                        TOS.GAMEID,
                        TOS.GAMEVERSION,
                        TOS.ACCOUNTID) T
       GROUP BY T.STATDATE,
                T.CHANNELID,
                T.SERVERID,
                T.GAMEID,
                T.GAMEVERSION,
                T.PAYAMOUNT;
    COMMIT;

    --ALL SERVER
    V_ERRPOSITION := '1-21-1';
    INSERT INTO FACT_100197_PAYAMOUNT_MONTH
      SELECT T.STATDATE,
             T.CHANNELID,
             LOWER('all'),
             '1',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYAMOUNT,
             COUNT(DISTINCT T.ACCOUNTID) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM') STATDATE,
                     TOS.CHANNELID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.ACCOUNTID,
                     TRUNC(SUM(TOS.MONEY), -1) PAYAMOUNT
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                 AND TOS.THEDATE <
                     TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
               GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM'),
                        TOS.CHANNELID,
                        TOS.GAMEID,
                        TOS.GAMEVERSION,
                        TOS.ACCOUNTID) T
       GROUP BY T.STATDATE,
                T.CHANNELID,
                T.GAMEID,
                T.GAMEVERSION,
                T.PAYAMOUNT;
    COMMIT;

    --���븶�ѽ��ĸ����豸��
    V_ERRPOSITION := '1-22';
    INSERT INTO FACT_100197_PAYAMOUNT_MONTH
      SELECT T.STATDATE,
             T.CHANNELID,
             T.SERVERID,
             '2',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYAMOUNT,
             COUNT(1) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM') STATDATE,
                     TOS.CHANNELID,
                     TOS.SERVERID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.DVID,
                     TRUNC(SUM(TOS.MONEY), -1) PAYAMOUNT
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                 AND TOS.THEDATE <
                     TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
               GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM'),
                        TOS.CHANNELID,
                        TOS.SERVERID,
                        TOS.GAMEID,
                        TOS.GAMEVERSION,
                        TOS.DVID) T
       GROUP BY T.STATDATE,
                T.CHANNELID,
                T.SERVERID,
                T.GAMEID,
                T.GAMEVERSION,
                T.PAYAMOUNT;
    COMMIT;

    --ALL SERVER
    V_ERRPOSITION := '1-22-1';
    INSERT INTO FACT_100197_PAYAMOUNT_MONTH
      SELECT T.STATDATE,
             T.CHANNELID,
             LOWER('all'),
             '2',
             T.GAMEID,
             T.GAMEVERSION,
             T.PAYAMOUNT,
             COUNT(DISTINCT T.DVID) PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM') STATDATE,
                     TOS.CHANNELID,
                     TOS.GAMEID,
                     TOS.GAMEVERSION,
                     TOS.DVID,
                     TRUNC(SUM(TOS.MONEY), -1) PAYAMOUNT
                FROM T_100197_ORDER_SUCC TOS
               WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                 AND TOS.THEDATE <
                     TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
               GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM'),
                        TOS.CHANNELID,
                        TOS.GAMEID,
                        TOS.GAMEVERSION,
                        TOS.DVID) T
       GROUP BY T.STATDATE,
                T.CHANNELID,
                T.GAMEID,
                T.GAMEVERSION,
                T.PAYAMOUNT;
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_100197_PAYTYPE��FACT_100197_PAYWAY��FACT_100197_PAYNUM_DAY
      ��FACT_100197_PAYNUM_WEEK��FACT_100197_PAYNUM_MONTH��FACT_100197_PAYAMOUNT_DAY��FACT_100197_PAYAMOUNT_WEEK��FACT_100197_PAYAMOUNT_MONTH';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_100197_ORDER����***************************************************************/
  --����FACT_100197_ORDER����
  PROCEDURE P_FACT_ORDER(P_LOGTIME IN VARCHAR2,
                         P_ERRCODE OUT NUMBER,
                         P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
    V_WEEKFIRSTDAY VARCHAR2(10); --���������ҳ� ������������ܵĵ�һ��
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;

    --�ܵ�һ��ļ��㷽�� TRUNC(SYSDATE)-(TO_CHAR(SYSDATE-1, 'D')-1)����������һ�ǵ�һ��
    --��ȡ�ܵ�һ��
    SELECT TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE + 1) -
                   DECODE((TO_CHAR(SYSDATE - V_INPUTDATE, 'D') - 1),
                          0,
                          7,
                          (TO_CHAR(SYSDATE - V_INPUTDATE, 'D') - 1)),
                   'YYYY-MM-DD')
      INTO V_WEEKFIRSTDAY
      FROM DUAL;

    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_ORDER';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRPOSITION := '1-1';
    DELETE FROM FACT_100197_ORDER T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    --�û�
    V_ERRPOSITION := '1-2';
    INSERT INTO FACT_100197_ORDER
      SELECT T3.STATDATE,
             T3.CHANNELID,
             T3.SERVERID,
             '1',
             '100197',
             T3.VERSIONID,
             NVL(T1.PAYSUCCCOUNT, 0),
             NVL(T2.PAYFAILCOUNT, 0),
             NVL(T1.PAYSUCCAMOUNT, 0),
             NVL(T2.PAYFAILAMOUNT, 0),
             NVL(T1.PAYSUCCNUM, 0),
             NVL(T2.PAYFAILNUM, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') STATDATE,
                     DAC.CHANNELID,
                     DAS.SERVERID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC,
                     DIM_APPSERVER    DAS,
                     DIM_APPVERSION   DAV
               WHERE DAC.APPID = '100197'
                 AND DAS.APPID = '100197'
                 AND DAV.APPID = '100197') T3
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOS.CHANNELID,
                          TOS.SERVERID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.ACCOUNTID) PAYSUCCCOUNT,
                          SUM(TOS.MONEY) PAYSUCCAMOUNT,
                          COUNT(TOS.ORDERID) PAYSUCCNUM
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.SERVERID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T1
          ON T1.STATDATE = T3.STATDATE
         AND T1.CHANNELID = T3.CHANNELID
         AND T1.SERVERID = T3.SERVERID
         AND T1.GAMEVERSION = T3.VERSIONID
        LEFT JOIN (SELECT TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOF.CHANNELID,
                          TOF.SERVERID,
                          TOF.GAMEID,
                          TOF.GAMEVERSION,
                          COUNT(DISTINCT TOF.ACCOUNTID) PAYFAILCOUNT,
                          SUM(TOF.MONEY) PAYFAILAMOUNT,
                          COUNT(TOF.ORDERID) PAYFAILNUM
                     FROM T_100197_ORDER_FAILURE TOF
                    WHERE TOF.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TOF.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD'),
                             TOF.CHANNELID,
                             TOF.SERVERID,
                             TOF.GAMEID,
                             TOF.GAMEVERSION) T2
          ON T3.STATDATE = T2.STATDATE
         AND T3.CHANNELID = T2.CHANNELID
         AND T3.SERVERID = T2.SERVERID
         AND T3.VERSIONID = T2.GAMEVERSION;
    COMMIT;

    V_ERRPOSITION := '1-2-1';
    --ALL SERVER
    INSERT INTO FACT_100197_ORDER
      SELECT T3.STATDATE,
             T3.CHANNELID,
             LOWER('all'),
             '1',
             '100197',
             T3.VERSIONID,
             NVL(T1.PAYSUCCCOUNT, 0),
             NVL(T2.PAYFAILCOUNT, 0),
             NVL(T1.PAYSUCCAMOUNT, 0),
             NVL(T2.PAYFAILAMOUNT, 0),
             NVL(T1.PAYSUCCNUM, 0),
             NVL(T2.PAYFAILNUM, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') STATDATE,
                     DAC.CHANNELID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC, DIM_APPVERSION DAV
               WHERE DAC.APPID = '100197'
                 AND DAV.APPID = '100197') T3
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOS.CHANNELID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.ACCOUNTID) PAYSUCCCOUNT,
                          SUM(TOS.MONEY) PAYSUCCAMOUNT,
                          COUNT(TOS.ORDERID) PAYSUCCNUM
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T1
          ON T1.STATDATE = T3.STATDATE
         AND T1.CHANNELID = T3.CHANNELID
         AND T1.GAMEVERSION = T3.VERSIONID
        LEFT JOIN (SELECT TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOF.CHANNELID,
                          TOF.GAMEID,
                          TOF.GAMEVERSION,
                          COUNT(DISTINCT TOF.ACCOUNTID) PAYFAILCOUNT,
                          SUM(TOF.MONEY) PAYFAILAMOUNT,
                          COUNT(TOF.ORDERID) PAYFAILNUM
                     FROM T_100197_ORDER_FAILURE TOF
                    WHERE TOF.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TOF.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD'),
                             TOF.CHANNELID,
                             TOF.GAMEID,
                             TOF.GAMEVERSION) T2
          ON T3.STATDATE = T2.STATDATE
         AND T3.CHANNELID = T2.CHANNELID
         AND T3.VERSIONID = T2.GAMEVERSION;
    COMMIT;

    --�豸
    V_ERRPOSITION := '1-3';
    INSERT INTO FACT_100197_ORDER
      SELECT T3.STATDATE,
             T3.CHANNELID,
             T3.SERVERID,
             '2',
             '100197',
             T3.VERSIONID,
             NVL(T1.PAYSUCCCOUNT, 0),
             NVL(T2.PAYFAILCOUNT, 0),
             NVL(T1.PAYSUCCAMOUNT, 0),
             NVL(T2.PAYFAILAMOUNT, 0),
             NVL(T1.PAYSUCCNUM, 0),
             NVL(T2.PAYFAILNUM, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') STATDATE,
                     DAC.CHANNELID,
                     DAS.SERVERID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC,
                     DIM_APPSERVER    DAS,
                     DIM_APPVERSION   DAV
               WHERE DAC.APPID = '100197'
                 AND DAS.APPID = '100197'
                 AND DAV.APPID = '100197') T3
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOS.CHANNELID,
                          TOS.SERVERID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.DVID) PAYSUCCCOUNT,
                          SUM(TOS.MONEY) PAYSUCCAMOUNT,
                          COUNT(TOS.ORDERID) PAYSUCCNUM
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.SERVERID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T1
          ON T1.STATDATE = T3.STATDATE
         AND T1.CHANNELID = T3.CHANNELID
         AND T1.SERVERID = T3.SERVERID
         AND T1.GAMEVERSION = T3.VERSIONID
        LEFT JOIN (SELECT TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOF.CHANNELID,
                          TOF.SERVERID,
                          TOF.GAMEID,
                          TOF.GAMEVERSION,
                          COUNT(DISTINCT TOF.DVID) PAYFAILCOUNT,
                          SUM(TOF.MONEY) PAYFAILAMOUNT,
                          COUNT(TOF.ORDERID) PAYFAILNUM
                     FROM T_100197_ORDER_FAILURE TOF
                    WHERE TOF.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TOF.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD'),
                             TOF.CHANNELID,
                             TOF.SERVERID,
                             TOF.GAMEID,
                             TOF.GAMEVERSION) T2
          ON T3.STATDATE = T2.STATDATE
         AND T3.CHANNELID = T2.CHANNELID
         AND T3.SERVERID = T2.SERVERID
         AND T3.VERSIONID = T2.GAMEVERSION;
    COMMIT;

    V_ERRPOSITION := '1-3-1';
    --ALL SERVER
    INSERT INTO FACT_100197_ORDER
      SELECT T3.STATDATE,
             T3.CHANNELID,
             LOWER('all'),
             '2',
             '100197',
             T3.VERSIONID,
             NVL(T1.PAYSUCCCOUNT, 0),
             NVL(T2.PAYFAILCOUNT, 0),
             NVL(T1.PAYSUCCAMOUNT, 0),
             NVL(T2.PAYFAILAMOUNT, 0),
             NVL(T1.PAYSUCCNUM, 0),
             NVL(T2.PAYFAILNUM, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') STATDATE,
                     DAC.CHANNELID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC, DIM_APPVERSION DAV
               WHERE DAC.APPID = '100197'
                 AND DAV.APPID = '100197') T3
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOS.CHANNELID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.DVID) PAYSUCCCOUNT,
                          SUM(TOS.MONEY) PAYSUCCAMOUNT,
                          COUNT(TOS.ORDERID) PAYSUCCNUM
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T1
          ON T1.STATDATE = T3.STATDATE
         AND T1.CHANNELID = T3.CHANNELID
         AND T1.GAMEVERSION = T3.VERSIONID
        LEFT JOIN (SELECT TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOF.CHANNELID,
                          TOF.GAMEID,
                          TOF.GAMEVERSION,
                          COUNT(DISTINCT TOF.DVID) PAYFAILCOUNT,
                          SUM(TOF.MONEY) PAYFAILAMOUNT,
                          COUNT(TOF.ORDERID) PAYFAILNUM
                     FROM T_100197_ORDER_FAILURE TOF
                    WHERE TOF.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TOF.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD'),
                             TOF.CHANNELID,
                             TOF.GAMEID,
                             TOF.GAMEVERSION) T2
          ON T3.STATDATE = T2.STATDATE
         AND T3.CHANNELID = T2.CHANNELID
         AND T3.VERSIONID = T2.GAMEVERSION;
    COMMIT;

    --����ͳ��
    V_ERRPOSITION := '1-4';
    DELETE FROM FACT_100197_ORDER_WEEK T WHERE T.STATDATE = V_WEEKFIRSTDAY;
    COMMIT;

    --�˻�
    V_ERRPOSITION := '1-5';
    INSERT INTO FACT_100197_ORDER_WEEK
      SELECT T3.STATDATE,
             T3.CHANNELID,
             T3.SERVERID,
             '1',
             '100197',
             T3.VERSIONID,
             NVL(T1.PAYSUCCCOUNT, 0),
             NVL(T2.PAYFAILCOUNT, 0),
             NVL(T1.PAYSUCCAMOUNT, 0),
             NVL(T2.PAYFAILAMOUNT, 0),
             NVL(T1.PAYSUCCNUM, 0),
             NVL(T2.PAYFAILNUM, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT V_WEEKFIRSTDAY STATDATE,
                     DAC.CHANNELID,
                     DAS.SERVERID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC,
                     DIM_APPSERVER    DAS,
                     DIM_APPVERSION   DAV
               WHERE DAC.APPID = '100197'
                 AND DAS.APPID = '100197'
                 AND DAV.APPID = '100197') T3
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOS.CHANNELID,
                          TOS.SERVERID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.ACCOUNTID) PAYSUCCCOUNT,
                          SUM(TOS.MONEY) PAYSUCCAMOUNT,
                          COUNT(TOS.ORDERID) PAYSUCCNUM
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >=
                          TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.SERVERID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T1
          ON T1.STATDATE = T3.STATDATE
         AND T1.CHANNELID = T3.CHANNELID
         AND T1.SERVERID = T3.SERVERID
         AND T1.GAMEVERSION = T3.VERSIONID
        LEFT JOIN (SELECT TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOF.CHANNELID,
                          TOF.SERVERID,
                          TOF.GAMEID,
                          TOF.GAMEVERSION,
                          COUNT(DISTINCT TOF.ACCOUNTID) PAYFAILCOUNT,
                          SUM(TOF.MONEY) PAYFAILAMOUNT,
                          COUNT(TOF.ORDERID) PAYFAILNUM
                     FROM T_100197_ORDER_FAILURE TOF
                    WHERE TOF.THEDATE >=
                          TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                      AND TOF.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD'),
                             TOF.CHANNELID,
                             TOF.SERVERID,
                             TOF.GAMEID,
                             TOF.GAMEVERSION) T2
          ON T3.STATDATE = T2.STATDATE
         AND T3.CHANNELID = T2.CHANNELID
         AND T3.SERVERID = T2.SERVERID
         AND T3.VERSIONID = T2.GAMEVERSION;
    COMMIT;

    V_ERRPOSITION := '1-5-1';
    --ALL SERVER
    INSERT INTO FACT_100197_ORDER_WEEK
      SELECT T3.STATDATE,
             T3.CHANNELID,
             LOWER('all'),
             '1',
             '100197',
             T3.VERSIONID,
             NVL(T1.PAYSUCCCOUNT, 0),
             NVL(T2.PAYFAILCOUNT, 0),
             NVL(T1.PAYSUCCAMOUNT, 0),
             NVL(T2.PAYFAILAMOUNT, 0),
             NVL(T1.PAYSUCCNUM, 0),
             NVL(T2.PAYFAILNUM, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT V_WEEKFIRSTDAY STATDATE, DAC.CHANNELID, DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC, DIM_APPVERSION DAV
               WHERE DAC.APPID = '100197'
                 AND DAV.APPID = '100197') T3
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOS.CHANNELID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.ACCOUNTID) PAYSUCCCOUNT,
                          SUM(TOS.MONEY) PAYSUCCAMOUNT,
                          COUNT(TOS.ORDERID) PAYSUCCNUM
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >=
                          TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T1
          ON T1.STATDATE = T3.STATDATE
         AND T1.CHANNELID = T3.CHANNELID
         AND T1.GAMEVERSION = T3.VERSIONID
        LEFT JOIN (SELECT TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOF.CHANNELID,
                          TOF.GAMEID,
                          TOF.GAMEVERSION,
                          COUNT(DISTINCT TOF.ACCOUNTID) PAYFAILCOUNT,
                          SUM(TOF.MONEY) PAYFAILAMOUNT,
                          COUNT(TOF.ORDERID) PAYFAILNUM
                     FROM T_100197_ORDER_FAILURE TOF
                    WHERE TOF.THEDATE >=
                          TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                      AND TOF.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD'),
                             TOF.CHANNELID,
                             TOF.GAMEID,
                             TOF.GAMEVERSION) T2
          ON T3.STATDATE = T2.STATDATE
         AND T3.CHANNELID = T2.CHANNELID
         AND T3.VERSIONID = T2.GAMEVERSION;
    COMMIT;

    --�豸
    V_ERRPOSITION := '1-6';
    INSERT INTO FACT_100197_ORDER_WEEK
      SELECT T3.STATDATE,
             T3.CHANNELID,
             T3.SERVERID,
             '2',
             '100197',
             T3.VERSIONID,
             NVL(T1.PAYSUCCCOUNT, 0),
             NVL(T2.PAYFAILCOUNT, 0),
             NVL(T1.PAYSUCCAMOUNT, 0),
             NVL(T2.PAYFAILAMOUNT, 0),
             NVL(T1.PAYSUCCNUM, 0),
             NVL(T2.PAYFAILNUM, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT V_WEEKFIRSTDAY STATDATE,
                     DAC.CHANNELID,
                     DAS.SERVERID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC,
                     DIM_APPSERVER    DAS,
                     DIM_APPVERSION   DAV
               WHERE DAC.APPID = '100197'
                 AND DAS.APPID = '100197'
                 AND DAV.APPID = '100197') T3
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOS.CHANNELID,
                          TOS.SERVERID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.DVID) PAYSUCCCOUNT,
                          SUM(TOS.MONEY) PAYSUCCAMOUNT,
                          COUNT(TOS.ORDERID) PAYSUCCNUM
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >=
                          TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.SERVERID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T1
          ON T1.STATDATE = T3.STATDATE
         AND T1.CHANNELID = T3.CHANNELID
         AND T1.SERVERID = T3.SERVERID
         AND T1.GAMEVERSION = T3.VERSIONID
        LEFT JOIN (SELECT TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOF.CHANNELID,
                          TOF.SERVERID,
                          TOF.GAMEID,
                          TOF.GAMEVERSION,
                          COUNT(DISTINCT TOF.DVID) PAYFAILCOUNT,
                          SUM(TOF.MONEY) PAYFAILAMOUNT,
                          COUNT(TOF.ORDERID) PAYFAILNUM
                     FROM T_100197_ORDER_FAILURE TOF
                    WHERE TOF.THEDATE >=
                          TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                      AND TOF.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD'),
                             TOF.CHANNELID,
                             TOF.SERVERID,
                             TOF.GAMEID,
                             TOF.GAMEVERSION) T2
          ON T3.STATDATE = T2.STATDATE
         AND T3.CHANNELID = T2.CHANNELID
         AND T3.SERVERID = T2.SERVERID
         AND T3.VERSIONID = T2.GAMEVERSION;
    COMMIT;

    V_ERRPOSITION := '1-6-1';
    --ALL SERVER
    INSERT INTO FACT_100197_ORDER_WEEK
      SELECT T3.STATDATE,
             T3.CHANNELID,
             LOWER('all'),
             '2',
             '100197',
             T3.VERSIONID,
             NVL(T1.PAYSUCCCOUNT, 0),
             NVL(T2.PAYFAILCOUNT, 0),
             NVL(T1.PAYSUCCAMOUNT, 0),
             NVL(T2.PAYFAILAMOUNT, 0),
             NVL(T1.PAYSUCCNUM, 0),
             NVL(T2.PAYFAILNUM, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT V_WEEKFIRSTDAY STATDATE, DAC.CHANNELID, DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC, DIM_APPVERSION DAV
               WHERE DAC.APPID = '100197'
                 AND DAV.APPID = '100197') T3
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOS.CHANNELID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.DVID) PAYSUCCCOUNT,
                          SUM(TOS.MONEY) PAYSUCCAMOUNT,
                          COUNT(TOS.ORDERID) PAYSUCCNUM
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >=
                          TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T1
          ON T1.STATDATE = T3.STATDATE
         AND T1.CHANNELID = T3.CHANNELID
         AND T1.GAMEVERSION = T3.VERSIONID
        LEFT JOIN (SELECT TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOF.CHANNELID,
                          TOF.GAMEID,
                          TOF.GAMEVERSION,
                          COUNT(DISTINCT TOF.DVID) PAYFAILCOUNT,
                          SUM(TOF.MONEY) PAYFAILAMOUNT,
                          COUNT(TOF.ORDERID) PAYFAILNUM
                     FROM T_100197_ORDER_FAILURE TOF
                    WHERE TOF.THEDATE >=
                          TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                      AND TOF.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD'),
                             TOF.CHANNELID,
                             TOF.GAMEID,
                             TOF.GAMEVERSION) T2
          ON T3.STATDATE = T2.STATDATE
         AND T3.CHANNELID = T2.CHANNELID
         AND T3.VERSIONID = T2.GAMEVERSION;
    COMMIT;

    --����ͳ��
    V_ERRPOSITION := '1-7';
    DELETE FROM FACT_100197_ORDER_MONTH T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM');
    COMMIT;

    --�˻�
    V_ERRPOSITION := '1-8';
    INSERT INTO FACT_100197_ORDER_MONTH
      SELECT T3.STATDATE,
             T3.CHANNELID,
             T3.SERVERID,
             '1',
             '100197',
             T3.VERSIONID,
             NVL(T1.PAYSUCCCOUNT, 0),
             NVL(T2.PAYFAILCOUNT, 0),
             NVL(T1.PAYSUCCAMOUNT, 0),
             NVL(T2.PAYFAILAMOUNT, 0),
             NVL(T1.PAYSUCCNUM, 0),
             NVL(T2.PAYFAILNUM, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM') STATDATE,
                     DAC.CHANNELID,
                     DAS.SERVERID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC,
                     DIM_APPSERVER    DAS,
                     DIM_APPVERSION   DAV
               WHERE DAC.APPID = '100197'
                 AND DAS.APPID = '100197'
                 AND DAV.APPID = '100197') T3
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOS.CHANNELID,
                          TOS.SERVERID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.ACCOUNTID) PAYSUCCCOUNT,
                          SUM(TOS.MONEY) PAYSUCCAMOUNT,
                          COUNT(TOS.ORDERID) PAYSUCCNUM
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                      AND TOS.THEDATE <
                          TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.SERVERID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T1
          ON T1.STATDATE = T3.STATDATE
         AND T1.CHANNELID = T3.CHANNELID
         AND T1.SERVERID = T3.SERVERID
         AND T1.GAMEVERSION = T3.VERSIONID
        LEFT JOIN (SELECT TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOF.CHANNELID,
                          TOF.SERVERID,
                          TOF.GAMEID,
                          TOF.GAMEVERSION,
                          COUNT(DISTINCT TOF.ACCOUNTID) PAYFAILCOUNT,
                          SUM(TOF.MONEY) PAYFAILAMOUNT,
                          COUNT(TOF.ORDERID) PAYFAILNUM
                     FROM T_100197_ORDER_FAILURE TOF
                    WHERE TOF.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                      AND TOF.THEDATE <
                          TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
                    GROUP BY TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD'),
                             TOF.CHANNELID,
                             TOF.SERVERID,
                             TOF.GAMEID,
                             TOF.GAMEVERSION) T2
          ON T3.STATDATE = T2.STATDATE
         AND T3.CHANNELID = T2.CHANNELID
         AND T3.SERVERID = T2.SERVERID
         AND T3.VERSIONID = T2.GAMEVERSION;
    COMMIT;

    V_ERRPOSITION := '1-8-1';
    --ALL SERVER
    INSERT INTO FACT_100197_ORDER_MONTH
      SELECT T3.STATDATE,
             T3.CHANNELID,
             LOWER('all'),
             '1',
             '100197',
             T3.VERSIONID,
             NVL(T1.PAYSUCCCOUNT, 0),
             NVL(T2.PAYFAILCOUNT, 0),
             NVL(T1.PAYSUCCAMOUNT, 0),
             NVL(T2.PAYFAILAMOUNT, 0),
             NVL(T1.PAYSUCCNUM, 0),
             NVL(T2.PAYFAILNUM, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM') STATDATE,
                     DAC.CHANNELID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC, DIM_APPVERSION DAV
               WHERE DAC.APPID = '100197'
                 AND DAV.APPID = '100197') T3
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOS.CHANNELID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.ACCOUNTID) PAYSUCCCOUNT,
                          SUM(TOS.MONEY) PAYSUCCAMOUNT,
                          COUNT(TOS.ORDERID) PAYSUCCNUM
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                      AND TOS.THEDATE <
                          TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T1
          ON T1.STATDATE = T3.STATDATE
         AND T1.CHANNELID = T3.CHANNELID
         AND T1.GAMEVERSION = T3.VERSIONID
        LEFT JOIN (SELECT TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOF.CHANNELID,
                          TOF.GAMEID,
                          TOF.GAMEVERSION,
                          COUNT(DISTINCT TOF.ACCOUNTID) PAYFAILCOUNT,
                          SUM(TOF.MONEY) PAYFAILAMOUNT,
                          COUNT(TOF.ORDERID) PAYFAILNUM
                     FROM T_100197_ORDER_FAILURE TOF
                    WHERE TOF.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                      AND TOF.THEDATE <
                          TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
                    GROUP BY TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD'),
                             TOF.CHANNELID,
                             TOF.GAMEID,
                             TOF.GAMEVERSION) T2
          ON T3.STATDATE = T2.STATDATE
         AND T3.CHANNELID = T2.CHANNELID
         AND T3.VERSIONID = T2.GAMEVERSION;
    COMMIT;

    --�豸
    V_ERRPOSITION := '1-9';
    INSERT INTO FACT_100197_ORDER_MONTH
      SELECT T3.STATDATE,
             T3.CHANNELID,
             T3.SERVERID,
             '2',
             '100197',
             T3.VERSIONID,
             NVL(T1.PAYSUCCCOUNT, 0),
             NVL(T2.PAYFAILCOUNT, 0),
             NVL(T1.PAYSUCCAMOUNT, 0),
             NVL(T2.PAYFAILAMOUNT, 0),
             NVL(T1.PAYSUCCNUM, 0),
             NVL(T2.PAYFAILNUM, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM') STATDATE,
                     DAC.CHANNELID,
                     DAS.SERVERID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC,
                     DIM_APPSERVER    DAS,
                     DIM_APPVERSION   DAV
               WHERE DAC.APPID = '100197'
                 AND DAS.APPID = '100197'
                 AND DAV.APPID = '100197') T3
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOS.CHANNELID,
                          TOS.SERVERID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.DVID) PAYSUCCCOUNT,
                          SUM(TOS.MONEY) PAYSUCCAMOUNT,
                          COUNT(TOS.ORDERID) PAYSUCCNUM
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                      AND TOS.THEDATE <
                          TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.SERVERID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T1
          ON T1.STATDATE = T3.STATDATE
         AND T1.CHANNELID = T3.CHANNELID
         AND T1.SERVERID = T3.SERVERID
         AND T1.GAMEVERSION = T3.VERSIONID
        LEFT JOIN (SELECT TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOF.CHANNELID,
                          TOF.SERVERID,
                          TOF.GAMEID,
                          TOF.GAMEVERSION,
                          COUNT(DISTINCT TOF.DVID) PAYFAILCOUNT,
                          SUM(TOF.MONEY) PAYFAILAMOUNT,
                          COUNT(TOF.ORDERID) PAYFAILNUM
                     FROM T_100197_ORDER_FAILURE TOF
                    WHERE TOF.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                      AND TOF.THEDATE <
                          TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
                    GROUP BY TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD'),
                             TOF.CHANNELID,
                             TOF.SERVERID,
                             TOF.GAMEID,
                             TOF.GAMEVERSION) T2
          ON T3.STATDATE = T2.STATDATE
         AND T3.CHANNELID = T2.CHANNELID
         AND T3.SERVERID = T2.SERVERID
         AND T3.VERSIONID = T2.GAMEVERSION;
    COMMIT;

    V_ERRPOSITION := '1-9-1';
    --ALL SERVER
    INSERT INTO FACT_100197_ORDER_MONTH
      SELECT T3.STATDATE,
             T3.CHANNELID,
             LOWER('all'),
             '2',
             '100197',
             T3.VERSIONID,
             NVL(T1.PAYSUCCCOUNT, 0),
             NVL(T2.PAYFAILCOUNT, 0),
             NVL(T1.PAYSUCCAMOUNT, 0),
             NVL(T2.PAYFAILAMOUNT, 0),
             NVL(T1.PAYSUCCNUM, 0),
             NVL(T2.PAYFAILNUM, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM') STATDATE,
                     DAC.CHANNELID,
                     DAV.VERSIONID
                FROM V_DIM_APPCHANNEL DAC, DIM_APPVERSION DAV
               WHERE DAC.APPID = '100197'
                 AND DAV.APPID = '100197') T3
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOS.CHANNELID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          COUNT(DISTINCT TOS.DVID) PAYSUCCCOUNT,
                          SUM(TOS.MONEY) PAYSUCCAMOUNT,
                          COUNT(TOS.ORDERID) PAYSUCCNUM
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                      AND TOS.THEDATE <
                          TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION) T1
          ON T1.STATDATE = T3.STATDATE
         AND T1.CHANNELID = T3.CHANNELID
         AND T1.GAMEVERSION = T3.VERSIONID
        LEFT JOIN (SELECT TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOF.CHANNELID,
                          TOF.GAMEID,
                          TOF.GAMEVERSION,
                          COUNT(DISTINCT TOF.DVID) PAYFAILCOUNT,
                          SUM(TOF.MONEY) PAYFAILAMOUNT,
                          COUNT(TOF.ORDERID) PAYFAILNUM
                     FROM T_100197_ORDER_FAILURE TOF
                    WHERE TOF.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                      AND TOF.THEDATE <
                          TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
                    GROUP BY TO_CHAR(TOF.THEDATE, 'YYYY-MM-DD'),
                             TOF.CHANNELID,
                             TOF.GAMEID,
                             TOF.GAMEVERSION) T2
          ON T3.STATDATE = T2.STATDATE
         AND T3.CHANNELID = T2.CHANNELID
         AND T3.VERSIONID = T2.GAMEVERSION;
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_100197_ORDER';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_REMAIN����***************************************************************/
  --����FACT_REMAIN����
  PROCEDURE P_FACT_REMAIN(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;

  BEGIN
    P_ERRCODE := 7100;

    IF SUBSTR(P_LOGTIME, 12, 2) = '23' THEN
      SELECT TRUNC(SYSDATE) -
             TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
        INTO V_INPUTDATE
        FROM DUAL;
      ------------------------------ִ����־��ʼ----------------------------------------------
      V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_REMAIN';
      PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------ִ����־��ʼ----------------------------------------------
      V_ERRPOSITION := '1-1';
      DELETE FROM FACT_100197_REMAIN_USER T
       WHERE T.CONNDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
      COMMIT;

      V_ERRPOSITION := '1-2';
      --�û�����
      INSERT INTO FACT_100197_REMAIN_USER
        SELECT T4.STATDATE,
               T4.CONNDATE,
               T4.CHANNELID,
               T4.SERVERID,
               '100197',
               T4.REMAIN_DAY,
               NVL(T1.NEW_REMAIN, 0) NEW_REMAIN,
               NVL(T2.CONN_REMAIN, 0) CONN_REMAIN,
               NVL(T3.PAY_REMAIN, 0) PAY_REMAIN,
               SYSDATE,
               V_ERRSOURCE
          FROM (SELECT TO_CHAR(SYSDATE - V_INPUTDATE - DRD.REMAIN_DAY,
                               'YYYY-MM-DD') STATDATE,
                       TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') CONNDATE,
                       DRD.REMAIN_DAY,
                       DAC.CHANNELID,
                       DAS.SERVERID
                  FROM V_DIM_APPCHANNEL DAC,
                       DIM_APPSERVER    DAS,
                       DIM_REMAIN_DAY   DRD
                 WHERE DAC.APPID = '100197'
                   AND DAS.APPID = '100197') T4
          LEFT JOIN (SELECT TC.REGDATE STATDATE,
                            TC.CONNDATE CONNDATE,
                            TC.CHANNELID,
                            TC.SERVERID,
                            TC.GAMEID,
                            TO_DATE(TC.CONNDATE, 'YYYY-MM-DD') -
                            TO_DATE(TC.REGDATE, 'YYYY-MM-DD') REMAIN_DAYS,
                            COUNT(TC.ACCOUNTID) NEW_REMAIN
                       FROM T_100197_CONN TC
                      WHERE TC.CONNDATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                      GROUP BY TC.REGDATE,
                               TC.CONNDATE,
                               TC.CHANNELID,
                               TC.SERVERID,
                               TC.GAMEID,
                               TO_DATE(TC.CONNDATE, 'YYYY-MM-DD') -
                               TO_DATE(TC.REGDATE, 'YYYY-MM-DD')) T1
            ON T1.STATDATE = T4.STATDATE
           AND T1.CONNDATE = T4.CONNDATE
           AND T1.CHANNELID = T4.CHANNELID
           AND T1.SERVERID = T4.SERVERID
           AND T1.REMAIN_DAYS = T4.REMAIN_DAY
          LEFT JOIN (SELECT TCT.BASEDATE STATDATE,
                            TCT.CONNDATE,
                            TCT.CHANNELID,
                            TCT.SERVERID,
                            TCT.GAMEID,
                            TO_DATE(TCT.CONNDATE, 'YYYY-MM-DD') -
                            TO_DATE(TCT.BASEDATE, 'YYYY-MM-DD') REMAIN_DAYS,
                            COUNT(TCT.ACCOUNTID) CONN_REMAIN
                       FROM T_100197_CONN_ACT TCT
                      WHERE TCT.CONNDATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                      GROUP BY TCT.BASEDATE,
                               TCT.CONNDATE,
                               TCT.CHANNELID,
                               TCT.SERVERID,
                               TCT.GAMEID,
                               TO_DATE(TCT.CONNDATE, 'YYYY-MM-DD') -
                               TO_DATE(TCT.BASEDATE, 'YYYY-MM-DD')) T2
            ON T4.STATDATE = T2.STATDATE
           AND T4.CONNDATE = T2.CONNDATE
           AND T4.CHANNELID = T2.CHANNELID
           AND T4.SERVERID = T2.SERVERID
           AND T4.REMAIN_DAY = T2.REMAIN_DAYS
          LEFT JOIN (SELECT TCT.BASEDATE STATDATE,
                            TCT.CONNDATE,
                            TCT.CHANNELID,
                            TCT.SERVERID,
                            TCT.GAMEID,
                            TO_DATE(TCT.CONNDATE, 'YYYY-MM-DD') -
                            TO_DATE(TCT.BASEDATE, 'YYYY-MM-DD') REMAIN_DAYS,
                            COUNT(TCT.ACCOUNTID) PAY_REMAIN
                       FROM T_100197_CONN_ACT TCT
                      WHERE TCT.CONNDATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                        AND TCT.ISPAY = '1'
                      GROUP BY TCT.BASEDATE,
                               TCT.CONNDATE,
                               TCT.CHANNELID,
                               TCT.SERVERID,
                               TCT.GAMEID,
                               TO_DATE(TCT.CONNDATE, 'YYYY-MM-DD') -
                               TO_DATE(TCT.BASEDATE, 'YYYY-MM-DD')) T3
            ON T4.STATDATE = T3.STATDATE
           AND T4.CONNDATE = T3.CONNDATE
           AND T4.CHANNELID = T3.CHANNELID
           AND T4.SERVERID = T3.SERVERID
           AND T4.REMAIN_DAY = T3.REMAIN_DAYS;
      COMMIT;

      V_ERRPOSITION := '1-2-1';
      --�û����� ALLSERVER
      INSERT INTO FACT_100197_REMAIN_USER
        SELECT T4.STATDATE,
               T4.CONNDATE,
               T4.CHANNELID,
               LOWER('all'),
               '100197',
               T4.REMAIN_DAY,
               NVL(T1.NEW_REMAIN, 0) NEW_REMAIN,
               NVL(T2.CONN_REMAIN, 0) CONN_REMAIN,
               NVL(T3.PAY_REMAIN, 0) PAY_REMAIN,
               SYSDATE,
               V_ERRSOURCE
          FROM (SELECT TO_CHAR(SYSDATE - V_INPUTDATE - DRD.REMAIN_DAY,
                               'YYYY-MM-DD') STATDATE,
                       TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') CONNDATE,
                       DRD.REMAIN_DAY,
                       DAC.CHANNELID
                  FROM V_DIM_APPCHANNEL DAC, DIM_REMAIN_DAY DRD
                 WHERE DAC.APPID = '100197') T4
          LEFT JOIN (SELECT TC.REGDATE_AS STATDATE,
                            TC.CONNDATE CONNDATE,
                            TC.CHANNELID,
                            TC.GAMEID,
                            TO_DATE(TC.CONNDATE, 'YYYY-MM-DD') -
                            TO_DATE(TC.REGDATE_AS, 'YYYY-MM-DD') REMAIN_DAYS,
                            COUNT(DISTINCT TC.ACCOUNTID) NEW_REMAIN
                       FROM T_100197_CONN TC
                      WHERE TC.CONNDATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                      GROUP BY TC.REGDATE_AS,
                               TC.CONNDATE,
                               TC.CHANNELID,
                               TC.GAMEID,
                               TO_DATE(TC.CONNDATE, 'YYYY-MM-DD') -
                               TO_DATE(TC.REGDATE_AS, 'YYYY-MM-DD')) T1
            ON T1.STATDATE = T4.STATDATE
           AND T1.CONNDATE = T4.CONNDATE
           AND T1.CHANNELID = T4.CHANNELID
           AND T1.REMAIN_DAYS = T4.REMAIN_DAY
          LEFT JOIN (SELECT TCT.BASEDATE STATDATE,
                            TCT.CONNDATE,
                            TCT.CHANNELID,
                            TCT.GAMEID,
                            TO_DATE(TCT.CONNDATE, 'YYYY-MM-DD') -
                            TO_DATE(TCT.BASEDATE, 'YYYY-MM-DD') REMAIN_DAYS,
                            COUNT(DISTINCT TCT.ACCOUNTID) CONN_REMAIN
                       FROM T_100197_CONN_ACT_AS TCT
                      WHERE TCT.CONNDATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                      GROUP BY TCT.BASEDATE,
                               TCT.CONNDATE,
                               TCT.CHANNELID,
                               TCT.GAMEID,
                               TO_DATE(TCT.CONNDATE, 'YYYY-MM-DD') -
                               TO_DATE(TCT.BASEDATE, 'YYYY-MM-DD')) T2
            ON T4.STATDATE = T2.STATDATE
           AND T4.CONNDATE = T2.CONNDATE
           AND T4.CHANNELID = T2.CHANNELID
           AND T4.REMAIN_DAY = T2.REMAIN_DAYS
          LEFT JOIN (SELECT TCT.BASEDATE STATDATE,
                            TCT.CONNDATE,
                            TCT.CHANNELID,
                            TCT.GAMEID,
                            TO_DATE(TCT.CONNDATE, 'YYYY-MM-DD') -
                            TO_DATE(TCT.BASEDATE, 'YYYY-MM-DD') REMAIN_DAYS,
                            COUNT(DISTINCT TCT.ACCOUNTID) PAY_REMAIN
                       FROM T_100197_CONN_ACT_AS TCT
                      WHERE TCT.CONNDATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                        AND TCT.ISPAY = '1'
                      GROUP BY TCT.BASEDATE,
                               TCT.CONNDATE,
                               TCT.CHANNELID,
                               TCT.GAMEID,
                               TO_DATE(TCT.CONNDATE, 'YYYY-MM-DD') -
                               TO_DATE(TCT.BASEDATE, 'YYYY-MM-DD')) T3
            ON T4.STATDATE = T3.STATDATE
           AND T4.CONNDATE = T3.CONNDATE
           AND T4.CHANNELID = T3.CHANNELID
           AND T4.REMAIN_DAY = T3.REMAIN_DAYS;
      COMMIT;

      V_ERRPOSITION := '1-3';
      DELETE FROM FACT_100197_REMAIN_MAC T
       WHERE T.CONNDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
      COMMIT;

      V_ERRPOSITION := '1-4';
      --�豸����
      INSERT INTO FACT_100197_REMAIN_MAC
        SELECT T4.STATDATE,
               T4.CONNDATE,
               T4.CHANNELID,
               T4.SERVERID,
               '100197',
               T4.REMAIN_DAY,
               NVL(T1.NEW_REMAIN, 0) NEW_REMAIN,
               NVL(T2.CONN_REMAIN, 0) CONN_REMAIN,
               NVL(T3.PAY_REMAIN, 0) PAY_REMAIN,
               SYSDATE,
               V_ERRSOURCE
          FROM (SELECT TO_CHAR(SYSDATE - V_INPUTDATE - DRD.REMAIN_DAY,
                               'YYYY-MM-DD') STATDATE,
                       TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') CONNDATE,
                       DRD.REMAIN_DAY,
                       DAC.CHANNELID,
                       DAS.SERVERID
                  FROM V_DIM_APPCHANNEL DAC,
                       DIM_APPSERVER    DAS,
                       DIM_REMAIN_DAY   DRD
                 WHERE DAC.APPID = '100197'
                   AND DAS.APPID = '100197') T4
          LEFT JOIN (SELECT TC.REGDATE STATDATE,
                            TC.CONNDATE CONNDATE,
                            TC.CHANNELID,
                            TC.SERVERID,
                            TC.GAMEID,
                            TO_DATE(TC.CONNDATE, 'YYYY-MM-DD') -
                            TO_DATE(TC.REGDATE, 'YYYY-MM-DD') REMAIN_DAYS,
                            COUNT(DISTINCT TC.DVID) NEW_REMAIN
                       FROM T_100197_CONN_MAC TC
                      WHERE TC.CONNDATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                      GROUP BY TC.REGDATE,
                               TC.CONNDATE,
                               TC.CHANNELID,
                               TC.SERVERID,
                               TC.GAMEID,
                               TO_DATE(TC.CONNDATE, 'YYYY-MM-DD') -
                               TO_DATE(TC.REGDATE, 'YYYY-MM-DD')) T1
            ON T1.STATDATE = T4.STATDATE
           AND T1.CONNDATE = T4.CONNDATE
           AND T1.CHANNELID = T4.CHANNELID
           AND T1.SERVERID = T4.SERVERID
           AND T1.REMAIN_DAYS = T4.REMAIN_DAY
          LEFT JOIN (SELECT TCT.BASEDATE STATDATE,
                            TCT.CONNDATE,
                            TCT.CHANNELID,
                            TCT.SERVERID,
                            TCT.GAMEID,
                            TO_DATE(TCT.CONNDATE, 'YYYY-MM-DD') -
                            TO_DATE(TCT.BASEDATE, 'YYYY-MM-DD') REMAIN_DAYS,
                            COUNT(DISTINCT TCT.DVID) CONN_REMAIN
                       FROM T_100197_CONN_ACT_MAC TCT
                      WHERE TCT.CONNDATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                      GROUP BY TCT.BASEDATE,
                               TCT.CONNDATE,
                               TCT.CHANNELID,
                               TCT.SERVERID,
                               TCT.GAMEID,
                               TO_DATE(TCT.CONNDATE, 'YYYY-MM-DD') -
                               TO_DATE(TCT.BASEDATE, 'YYYY-MM-DD')) T2
            ON T4.STATDATE = T2.STATDATE
           AND T4.CONNDATE = T2.CONNDATE
           AND T4.CHANNELID = T2.CHANNELID
           AND T4.SERVERID = T2.SERVERID
           AND T4.REMAIN_DAY = T2.REMAIN_DAYS
          LEFT JOIN (SELECT TCT.BASEDATE STATDATE,
                            TCT.CONNDATE,
                            TCT.CHANNELID,
                            TCT.SERVERID,
                            TCT.GAMEID,
                            TO_DATE(TCT.CONNDATE, 'YYYY-MM-DD') -
                            TO_DATE(TCT.BASEDATE, 'YYYY-MM-DD') REMAIN_DAYS,
                            COUNT(DISTINCT TCT.DVID) PAY_REMAIN
                       FROM T_100197_CONN_ACT_MAC TCT
                      WHERE TCT.CONNDATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                        AND TCT.ISPAY = '1'
                      GROUP BY TCT.BASEDATE,
                               TCT.CONNDATE,
                               TCT.CHANNELID,
                               TCT.SERVERID,
                               TCT.GAMEID,
                               TO_DATE(TCT.CONNDATE, 'YYYY-MM-DD') -
                               TO_DATE(TCT.BASEDATE, 'YYYY-MM-DD')) T3
            ON T4.STATDATE = T3.STATDATE
           AND T4.CONNDATE = T3.CONNDATE
           AND T4.CHANNELID = T3.CHANNELID
           AND T4.SERVERID = T3.SERVERID
           AND T4.REMAIN_DAY = T3.REMAIN_DAYS;
      COMMIT;

      V_ERRPOSITION := '1-4-1';
      --�豸���� ALLSERVER
      INSERT INTO FACT_100197_REMAIN_MAC
        SELECT T4.STATDATE,
               T4.CONNDATE,
               T4.CHANNELID,
               LOWER('all'),
               '100197',
               T4.REMAIN_DAY,
               NVL(T1.NEW_REMAIN, 0) NEW_REMAIN,
               NVL(T2.CONN_REMAIN, 0) CONN_REMAIN,
               NVL(T3.PAY_REMAIN, 0) PAY_REMAIN,
               SYSDATE,
               V_ERRSOURCE
          FROM (SELECT TO_CHAR(SYSDATE - V_INPUTDATE - DRD.REMAIN_DAY,
                               'YYYY-MM-DD') STATDATE,
                       TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') CONNDATE,
                       DRD.REMAIN_DAY,
                       DAC.CHANNELID
                  FROM V_DIM_APPCHANNEL DAC, DIM_REMAIN_DAY DRD
                 WHERE DAC.APPID = '100197') T4
          LEFT JOIN (SELECT TC.REGDATE_AS STATDATE,
                            TC.CONNDATE CONNDATE,
                            TC.CHANNELID,
                            TC.GAMEID,
                            TO_DATE(TC.CONNDATE, 'YYYY-MM-DD') -
                            TO_DATE(TC.REGDATE_AS, 'YYYY-MM-DD') REMAIN_DAYS,
                            COUNT(DISTINCT TC.DVID) NEW_REMAIN
                       FROM T_100197_CONN_MAC TC
                      WHERE TC.CONNDATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                      GROUP BY TC.REGDATE_AS,
                               TC.CONNDATE,
                               TC.CHANNELID,
                               TC.GAMEID,
                               TO_DATE(TC.CONNDATE, 'YYYY-MM-DD') -
                               TO_DATE(TC.REGDATE_AS, 'YYYY-MM-DD')) T1
            ON T1.STATDATE = T4.STATDATE
           AND T1.CONNDATE = T4.CONNDATE
           AND T1.CHANNELID = T4.CHANNELID
           AND T1.REMAIN_DAYS = T4.REMAIN_DAY
          LEFT JOIN (SELECT TCT.BASEDATE STATDATE,
                            TCT.CONNDATE,
                            TCT.CHANNELID,
                            TCT.GAMEID,
                            TO_DATE(TCT.CONNDATE, 'YYYY-MM-DD') -
                            TO_DATE(TCT.BASEDATE, 'YYYY-MM-DD') REMAIN_DAYS,
                            COUNT(DISTINCT TCT.DVID) CONN_REMAIN
                       FROM T_100197_CONN_ACT_MAC_AS TCT
                      WHERE TCT.CONNDATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                      GROUP BY TCT.BASEDATE,
                               TCT.CONNDATE,
                               TCT.CHANNELID,
                               TCT.GAMEID,
                               TO_DATE(TCT.CONNDATE, 'YYYY-MM-DD') -
                               TO_DATE(TCT.BASEDATE, 'YYYY-MM-DD')) T2
            ON T4.STATDATE = T2.STATDATE
           AND T4.CONNDATE = T2.CONNDATE
           AND T4.CHANNELID = T2.CHANNELID
           AND T4.REMAIN_DAY = T2.REMAIN_DAYS
          LEFT JOIN (SELECT TCT.BASEDATE STATDATE,
                            TCT.CONNDATE,
                            TCT.CHANNELID,
                            TCT.GAMEID,
                            TO_DATE(TCT.CONNDATE, 'YYYY-MM-DD') -
                            TO_DATE(TCT.BASEDATE, 'YYYY-MM-DD') REMAIN_DAYS,
                            COUNT(DISTINCT TCT.DVID) PAY_REMAIN
                       FROM T_100197_CONN_ACT_MAC_AS TCT
                      WHERE TCT.CONNDATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                        AND TCT.ISPAY = '1'
                      GROUP BY TCT.BASEDATE,
                               TCT.CONNDATE,
                               TCT.CHANNELID,
                               TCT.GAMEID,
                               TO_DATE(TCT.CONNDATE, 'YYYY-MM-DD') -
                               TO_DATE(TCT.BASEDATE, 'YYYY-MM-DD')) T3
            ON T4.STATDATE = T3.STATDATE
           AND T4.CONNDATE = T3.CONNDATE
           AND T4.CHANNELID = T3.CHANNELID
           AND T4.REMAIN_DAY = T3.REMAIN_DAYS;
      COMMIT;
    END IF;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_REMAIN';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_LOST����***************************************************************/
  --����FACT_LOST����
  PROCEDURE P_FACT_LOST(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;

  BEGIN
    P_ERRCODE := 7100;

    IF SUBSTR(P_LOGTIME, 12, 2) = '23' THEN
      SELECT TRUNC(SYSDATE) -
             TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
        INTO V_INPUTDATE
        FROM DUAL;

      ------------------------------ִ����־��ʼ----------------------------------------------
      V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_LOST';
      PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------ִ����־��ʼ----------------------------------------------

      V_ERRPOSITION := '1-1';
      DELETE FROM FACT_100197_LOST_MAC T
       WHERE T.LOSTDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
      COMMIT;

      V_ERRPOSITION := '1-2';
      --�����豸��ʧ������
      INSERT INTO FACT_100197_LOST_MAC
        SELECT T1.STATDATE,
               T1.LOST_DATE,
               T1.CHANNELID,
               T1.SERVERID,
               T1.APPID,
               T1.ROLELEVEL,
               T1.LOST_DAYS,
               T1.LOST_CONN,
               NVL(T2.LOST_PAY, 0) LOST_PAY,
               SYSDATE,
               V_ERRSOURCE
          FROM (SELECT TLM.STATDATE,
                       TLM.LOST_DATE,
                       TLM.CHANNELID,
                       TLM.SERVERID,
                       TLM.APPID,
                       TLM.ROLELEVEL,
                       TLM.LOST_DAYS,
                       COUNT(TLM.MACID) LOST_CONN
                  FROM T_100197_LOST_MAC TLM
                 WHERE TLM.LOST_DATE =
                       TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                 GROUP BY TLM.STATDATE,
                          TLM.LOST_DATE,
                          TLM.CHANNELID,
                          TLM.SERVERID,
                          TLM.APPID,
                          TLM.ROLELEVEL,
                          TLM.LOST_DAYS) T1
          LEFT JOIN (SELECT TLM.STATDATE,
                            TLM.LOST_DATE,
                            TLM.CHANNELID,
                            TLM.SERVERID,
                            TLM.APPID,
                            TLM.ROLELEVEL,
                            TLM.LOST_DAYS,
                            COUNT(TLM.MACID) LOST_PAY
                       FROM T_100197_LOST_MAC TLM
                      WHERE TLM.ISPAY = '1'
                        AND TLM.LOST_DATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                      GROUP BY TLM.STATDATE,
                               TLM.LOST_DATE,
                               TLM.CHANNELID,
                               TLM.SERVERID,
                               TLM.APPID,
                               TLM.ROLELEVEL,
                               TLM.LOST_DAYS) T2
            ON T1.STATDATE = T2.STATDATE
           AND T1.LOST_DATE = T2.LOST_DATE
           AND T1.CHANNELID = T2.CHANNELID
           AND T1.SERVERID = T2.SERVERID
           AND T1.APPID = T2.APPID
           AND T1.ROLELEVEL = T2.ROLELEVEL;
      COMMIT;

      V_ERRPOSITION := '1-2-1';
      --�����豸��ʧ������ ALLSERVER
      INSERT INTO FACT_100197_LOST_MAC
        SELECT T1.STATDATE,
               T1.LOST_DATE,
               T1.CHANNELID,
               LOWER('all'),
               T1.APPID,
               T1.ROLELEVEL,
               T1.LOST_DAYS,
               T1.LOST_CONN,
               NVL(T2.LOST_PAY, 0) LOST_PAY,
               SYSDATE,
               V_ERRSOURCE
          FROM (SELECT TLM.STATDATE,
                       TLM.LOST_DATE,
                       TLM.CHANNELID,
                       TLM.APPID,
                       TLM.ROLELEVEL,
                       TLM.LOST_DAYS,
                       COUNT(TLM.MACID) LOST_CONN
                  FROM T_100197_LOST_MAC_AS TLM
                 WHERE TLM.LOST_DATE =
                       TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                 GROUP BY TLM.STATDATE,
                          TLM.LOST_DATE,
                          TLM.CHANNELID,
                          TLM.APPID,
                          TLM.ROLELEVEL,
                          TLM.LOST_DAYS) T1
          LEFT JOIN (SELECT TLM.STATDATE,
                            TLM.LOST_DATE,
                            TLM.CHANNELID,
                            TLM.APPID,
                            TLM.ROLELEVEL,
                            TLM.LOST_DAYS,
                            COUNT(TLM.MACID) LOST_PAY
                       FROM T_100197_LOST_MAC_AS TLM
                      WHERE TLM.ISPAY = '1'
                        AND TLM.LOST_DATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                      GROUP BY TLM.STATDATE,
                               TLM.LOST_DATE,
                               TLM.CHANNELID,
                               TLM.APPID,
                               TLM.ROLELEVEL,
                               TLM.LOST_DAYS) T2
            ON T1.STATDATE = T2.STATDATE
           AND T1.LOST_DATE = T2.LOST_DATE
           AND T1.CHANNELID = T2.CHANNELID
           AND T1.APPID = T2.APPID
           AND T1.ROLELEVEL = T2.ROLELEVEL;
      COMMIT;

      V_ERRPOSITION := '1-3';
      DELETE FROM FACT_100197_LOST_USER T
       WHERE T.LOSTDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
      COMMIT;

      V_ERRPOSITION := '1-4';
      --�����û���ʧ������
      INSERT INTO FACT_100197_LOST_USER
        SELECT T1.STATDATE,
               T1.LOST_DATE,
               T1.CHANNELID,
               T1.SERVERID,
               T1.APPID,
               T1.ROLELEVEL,
               T1.LOST_DAYS,
               T1.LOST_CONN,
               NVL(T2.LOST_PAY, 0) LOST_PAY,
               SYSDATE,
               V_ERRSOURCE
          FROM (SELECT TLM.STATDATE,
                       TLM.LOST_DATE,
                       TLM.CHANNELID,
                       TLM.SERVERID,
                       TLM.APPID,
                       TLM.ROLELEVEL,
                       TLM.LOST_DAYS,
                       COUNT(TLM.USERID) LOST_CONN
                  FROM T_100197_LOST_USER TLM
                 WHERE TLM.LOST_DATE =
                       TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                 GROUP BY TLM.STATDATE,
                          TLM.LOST_DATE,
                          TLM.CHANNELID,
                          TLM.SERVERID,
                          TLM.APPID,
                          TLM.ROLELEVEL,
                          TLM.LOST_DAYS) T1
          LEFT JOIN (SELECT TLM.STATDATE,
                            TLM.LOST_DATE,
                            TLM.CHANNELID,
                            TLM.SERVERID,
                            TLM.APPID,
                            TLM.ROLELEVEL,
                            TLM.LOST_DAYS,
                            COUNT(TLM.USERID) LOST_PAY
                       FROM T_100197_LOST_USER TLM
                      WHERE TLM.ISPAY = '1'
                        AND TLM.LOST_DATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                      GROUP BY TLM.STATDATE,
                               TLM.LOST_DATE,
                               TLM.CHANNELID,
                               TLM.SERVERID,
                               TLM.APPID,
                               TLM.ROLELEVEL,
                               TLM.LOST_DAYS) T2
            ON T1.STATDATE = T2.STATDATE
           AND T1.LOST_DATE = T2.LOST_DATE
           AND T1.CHANNELID = T2.CHANNELID
           AND T1.SERVERID = T2.SERVERID
           AND T1.APPID = T2.APPID
           AND T1.ROLELEVEL = T2.ROLELEVEL;
      COMMIT;

      V_ERRPOSITION := '1-4-1';
      --�����û���ʧ������ ALLSERVER
      INSERT INTO FACT_100197_LOST_USER
        SELECT T1.STATDATE,
               T1.LOST_DATE,
               T1.CHANNELID,
               LOWER('all'),
               T1.APPID,
               T1.ROLELEVEL,
               T1.LOST_DAYS,
               T1.LOST_CONN,
               NVL(T2.LOST_PAY, 0) LOST_PAY,
               SYSDATE,
               V_ERRSOURCE
          FROM (SELECT TLM.STATDATE,
                       TLM.LOST_DATE,
                       TLM.CHANNELID,
                       TLM.APPID,
                       TLM.ROLELEVEL,
                       TLM.LOST_DAYS,
                       COUNT(TLM.USERID) LOST_CONN
                  FROM T_100197_LOST_USER_AS TLM
                 WHERE TLM.LOST_DATE =
                       TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                 GROUP BY TLM.STATDATE,
                          TLM.LOST_DATE,
                          TLM.CHANNELID,
                          TLM.APPID,
                          TLM.ROLELEVEL,
                          TLM.LOST_DAYS) T1
          LEFT JOIN (SELECT TLM.STATDATE,
                            TLM.LOST_DATE,
                            TLM.CHANNELID,
                            TLM.APPID,
                            TLM.ROLELEVEL,
                            TLM.LOST_DAYS,
                            COUNT(TLM.USERID) LOST_PAY
                       FROM T_100197_LOST_USER_AS TLM
                      WHERE TLM.ISPAY = '1'
                        AND TLM.LOST_DATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                      GROUP BY TLM.STATDATE,
                               TLM.LOST_DATE,
                               TLM.CHANNELID,
                               TLM.APPID,
                               TLM.ROLELEVEL,
                               TLM.LOST_DAYS) T2
            ON T1.STATDATE = T2.STATDATE
           AND T1.LOST_DATE = T2.LOST_DATE
           AND T1.CHANNELID = T2.CHANNELID
           AND T1.APPID = T2.APPID
           AND T1.ROLELEVEL = T2.ROLELEVEL;
      COMMIT;
    END IF;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_LOST';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_100197_LEVELPAY����***************************************************************/
  --����FACT_100197_LEVELPAY����
  PROCEDURE P_FACT_LEVELPAY(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;

  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;

    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_LEVELPAY';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    --�û���ɫ�ȼ����ѷ���
    V_ERRPOSITION := '1-1';
    DELETE FROM FACT_100197_LEVELPAY T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    V_ERRPOSITION := '1-2';
    --����FACT_100197_LEVELPAY���û�����
    INSERT INTO FACT_100197_LEVELPAY
      SELECT T2.STATDATE,
             T2.CHANNELID,
             T2.SERVERID,
             '1',
             T2.GAMEID,
             T2.GAMEVERSION,
             T2.ROLELEVEL,
             NVL(T1.FIRST_PAYCOUNT, 0) FIRST_PAYCOUNT,
             T2.PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TNP.FIRSTPAYDATE, 'YYYY-MM-DD') STATDATE,
                     TNP.CHANNELID,
                     TNP.SERVERID,
                     TNP.GAMEID,
                     TNP.GAMEVERSION,
                     TNP.ROLELEVEL,
                     COUNT(1) FIRST_PAYCOUNT
                FROM T_100197_NU_PAY TNP
               WHERE TNP.FIRSTPAYDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                 AND TNP.FIRSTPAYDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TO_CHAR(TNP.FIRSTPAYDATE, 'YYYY-MM-DD'),
                        TNP.CHANNELID,
                        TNP.SERVERID,
                        TNP.GAMEID,
                        TNP.GAMEVERSION,
                        TNP.ROLELEVEL) T1
       RIGHT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOS.CHANNELID,
                          TOS.SERVERID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          TOS.ROLELEVEL,
                          COUNT(DISTINCT TOS.ACCOUNTID) PAYCOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.SERVERID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION,
                             TOS.ROLELEVEL) T2
          ON T1.STATDATE = T2.STATDATE
         AND T1.CHANNELID = T2.CHANNELID
         AND T1.SERVERID = T2.SERVERID
         AND T1.GAMEVERSION = T2.GAMEVERSION
         AND T1.ROLELEVEL = T2.ROLELEVEL;
    COMMIT;

    V_ERRPOSITION := '1-2-1';
    --ALL SERVER
    INSERT INTO FACT_100197_LEVELPAY
      SELECT T2.STATDATE,
             T2.CHANNELID,
             LOWER('all'),
             '1',
             T2.GAMEID,
             T2.GAMEVERSION,
             T2.ROLELEVEL,
             NVL(T1.FIRST_PAYCOUNT, 0) FIRST_PAYCOUNT,
             T2.PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TNP.FIRSTPAYDATE, 'YYYY-MM-DD') STATDATE,
                     TNP.CHANNELID,
                     TNP.GAMEID,
                     TNP.GAMEVERSION,
                     TNP.ROLELEVEL,
                     COUNT(DISTINCT TNP.ACCOUNTID) FIRST_PAYCOUNT
                FROM T_100197_NU_PAY TNP
               WHERE TNP.FIRSTPAYDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                 AND TNP.FIRSTPAYDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TO_CHAR(TNP.FIRSTPAYDATE, 'YYYY-MM-DD'),
                        TNP.CHANNELID,
                        TNP.GAMEID,
                        TNP.GAMEVERSION,
                        TNP.ROLELEVEL) T1
       RIGHT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOS.CHANNELID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          TOS.ROLELEVEL,
                          COUNT(DISTINCT TOS.ACCOUNTID) PAYCOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION,
                             TOS.ROLELEVEL) T2
          ON T1.STATDATE = T2.STATDATE
         AND T1.CHANNELID = T2.CHANNELID
         AND T1.GAMEVERSION = T2.GAMEVERSION
         AND T1.ROLELEVEL = T2.ROLELEVEL;
    COMMIT;

    V_ERRPOSITION := '1-3';
    --����FACT_100197_LEVELPAY���豸����
    INSERT INTO FACT_100197_LEVELPAY
      SELECT T2.STATDATE,
             T2.CHANNELID,
             T2.SERVERID,
             '2',
             T2.GAMEID,
             T2.GAMEVERSION,
             T2.ROLELEVEL,
             NVL(T1.FIRST_PAYCOUNT, 0) FIRST_PAYCOUNT,
             T2.PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TNP.FIRSTPAYDATE, 'YYYY-MM-DD') STATDATE,
                     TNP.CHANNELID,
                     TNP.SERVERID,
                     TNP.GAMEID,
                     TNP.GAMEVERSION,
                     TNP.ROLELEVEL,
                     COUNT(1) FIRST_PAYCOUNT
                FROM T_100197_NU_PAY_MAC TNP
               WHERE TNP.FIRSTPAYDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                 AND TNP.FIRSTPAYDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TO_CHAR(TNP.FIRSTPAYDATE, 'YYYY-MM-DD'),
                        TNP.CHANNELID,
                        TNP.SERVERID,
                        TNP.GAMEID,
                        TNP.GAMEVERSION,
                        TNP.ROLELEVEL) T1
       RIGHT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOS.CHANNELID,
                          TOS.SERVERID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          TOS.ROLELEVEL,
                          COUNT(DISTINCT TOS.DVID) PAYCOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.SERVERID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION,
                             TOS.ROLELEVEL) T2
          ON T1.STATDATE = T2.STATDATE
         AND T1.CHANNELID = T2.CHANNELID
         AND T1.SERVERID = T2.SERVERID
         AND T1.GAMEVERSION = T2.GAMEVERSION
         AND T1.ROLELEVEL = T2.ROLELEVEL;
    COMMIT;

    V_ERRPOSITION := '1-3-1';
    --ALL SERVER
    INSERT INTO FACT_100197_LEVELPAY
      SELECT T2.STATDATE,
             T2.CHANNELID,
             LOWER('all'),
             '2',
             T2.GAMEID,
             T2.GAMEVERSION,
             T2.ROLELEVEL,
             NVL(T1.FIRST_PAYCOUNT, 0) FIRST_PAYCOUNT,
             T2.PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TNP.FIRSTPAYDATE, 'YYYY-MM-DD') STATDATE,
                     TNP.CHANNELID,
                     TNP.GAMEID,
                     TNP.GAMEVERSION,
                     TNP.ROLELEVEL,
                     COUNT(DISTINCT TNP.DVID) FIRST_PAYCOUNT
                FROM T_100197_NU_PAY_MAC TNP
               WHERE TNP.FIRSTPAYDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                 AND TNP.FIRSTPAYDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TO_CHAR(TNP.FIRSTPAYDATE, 'YYYY-MM-DD'),
                        TNP.CHANNELID,
                        TNP.GAMEID,
                        TNP.GAMEVERSION,
                        TNP.ROLELEVEL) T1
       RIGHT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TOS.CHANNELID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          TOS.ROLELEVEL,
                          COUNT(DISTINCT TOS.DVID) PAYCOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION,
                             TOS.ROLELEVEL) T2
          ON T1.STATDATE = T2.STATDATE
         AND T1.CHANNELID = T2.CHANNELID
         AND T1.GAMEVERSION = T2.GAMEVERSION
         AND T1.ROLELEVEL = T2.ROLELEVEL;
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_100197_LEVELPAY';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_100197_GENERAL_LEVEL����***************************************************************/
  --����FACT_100197_GENERAL_LEVEL����
  PROCEDURE P_FACT_GENERAL_LEVEL(P_LOGTIME IN VARCHAR2,
                                 P_ERRCODE OUT NUMBER,
                                 P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;

  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;

    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_GENERAL_LEVEL';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    V_ERRPOSITION := '1-1';
    DELETE FROM FACT_100197_GENERAL_LEVEL T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    V_ERRPOSITION := '1-2';
    --�û��ȼ�������Ϣ��
    INSERT INTO FACT_100197_GENERAL_LEVEL
      SELECT T2.THEDATE STATDATE,
             T2.CHANNELID CHANNELID,
             T2.SERVERID SERVERID,
             '1' DATATYPE,
             T2.GAMEID APPID,
             T2.GAMEVERSION VERSIONID,
             T2.ROLELEVEL,
             NVL(T1.NEWCOUNT, 0),
             T2.CONNCOUNT,
             NVL(T4.PAYCOUNT, 0),
             NVL(T3.PAYAMOUNT, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TC.CONNDATE THEDATE,
                     TC.CHANNELID,
                     TC.SERVERID,
                     TC.GAMEID,
                     TC.GAMEVERSION,
                     TC.ROLELEVEL,
                     COUNT(DISTINCT TC.ACCOUNTID) CONNCOUNT
                FROM T_100197_CONN TC
               WHERE TC.CONNDATE =
                     TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
               GROUP BY TC.CONNDATE,
                        TC.CHANNELID,
                        TC.SERVERID,
                        TC.GAMEID,
                        TC.GAMEVERSION,
                        TC.ROLELEVEL) T2
        LEFT JOIN (SELECT T.THEDATE,
                          T.CHANNELID,
                          T.SERVERID,
                          T.GAMEID,
                          T.GAMEVERSION,
                          TC.ROLELEVEL,
                          COUNT(1) NEWCOUNT
                     FROM (SELECT TO_CHAR(TN.THEDATE, 'YYYY-MM-DD') THEDATE,
                                  TN.CHANNELID,
                                  TN.SERVERID,
                                  TN.GAMEID,
                                  TN.GAMEVERSION,
                                  TN.ACCOUNTID
                             FROM T_100197_NU TN
                            WHERE TN.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                              AND TN.THEDATE <
                                  TRUNC(SYSDATE - V_INPUTDATE + 1)) T
                    INNER JOIN T_100197_CONN TC
                       ON T.THEDATE = TC.CONNDATE
                      AND T.CHANNELID = TC.CHANNELID
                      AND T.SERVERID = TC.SERVERID
                      AND T.GAMEVERSION = TC.GAMEVERSION
                      AND T.ACCOUNTID = TC.ACCOUNTID
                    GROUP BY T.THEDATE,
                             T.CHANNELID,
                             T.SERVERID,
                             T.GAMEID,
                             T.GAMEVERSION,
                             TC.ROLELEVEL) T1
          ON T1.THEDATE = T2.THEDATE
         AND T1.CHANNELID = T2.CHANNELID
         AND T1.SERVERID = T2.SERVERID
         AND T1.GAMEVERSION = T2.GAMEVERSION
         AND T1.ROLELEVEL = T2.ROLELEVEL
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') THEDATE,
                          TOS.CHANNELID,
                          TOS.SERVERID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          TOS.ROLELEVEL,
                          SUM(TOS.MONEY) PAYAMOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.SERVERID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION,
                             TOS.ROLELEVEL) T3
          ON T2.THEDATE = T3.THEDATE
         AND T2.CHANNELID = T3.CHANNELID
         AND T2.SERVERID = T3.SERVERID
         AND T2.GAMEVERSION = T3.GAMEVERSION
         AND T2.ROLELEVEL = T3.ROLELEVEL
        LEFT JOIN (SELECT TC.CONNDATE THEDATE,
                          TC.CHANNELID,
                          TC.SERVERID,
                          TC.GAMEID,
                          TC.GAMEVERSION,
                          TC.ROLELEVEL,
                          COUNT(DISTINCT TC.ACCOUNTID) PAYCOUNT
                     FROM T_100197_CONN TC
                    WHERE TC.CONNDATE =
                          TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                      AND TC.ISPAY = '1'
                    GROUP BY TC.CONNDATE,
                             TC.CHANNELID,
                             TC.SERVERID,
                             TC.GAMEID,
                             TC.GAMEVERSION,
                             TC.ROLELEVEL) T4
          ON T4.THEDATE = T2.THEDATE
         AND T4.CHANNELID = T2.CHANNELID
         AND T4.SERVERID = T2.SERVERID
         AND T4.GAMEVERSION = T2.GAMEVERSION
         AND T4.ROLELEVEL = T2.ROLELEVEL;
    COMMIT;

    V_ERRPOSITION := '1-2-1';
    --ALL SERVER
    INSERT INTO FACT_100197_GENERAL_LEVEL
      SELECT T2.THEDATE STATDATE,
             T2.CHANNELID CHANNELID,
             LOWER('all'),
             '1' DATATYPE,
             T2.GAMEID APPID,
             T2.GAMEVERSION VERSIONID,
             T2.ROLELEVEL,
             NVL(T1.NEWCOUNT, 0),
             T2.CONNCOUNT,
             NVL(T4.PAYCOUNT, 0),
             NVL(T3.PAYAMOUNT, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TC.CONNDATE THEDATE,
                     TC.CHANNELID,
                     TC.GAMEID,
                     TC.GAMEVERSION,
                     TC.ROLELEVEL,
                     COUNT(DISTINCT TC.ACCOUNTID) CONNCOUNT
                FROM T_100197_CONN TC
               WHERE TC.CONNDATE =
                     TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
               GROUP BY TC.CONNDATE,
                        TC.CHANNELID,
                        TC.GAMEID,
                        TC.GAMEVERSION,
                        TC.ROLELEVEL) T2
        LEFT JOIN (SELECT T.THEDATE,
                          T.CHANNELID,
                          T.GAMEID,
                          T.GAMEVERSION,
                          TC.ROLELEVEL,
                          COUNT(DISTINCT T.ACCOUNTID) NEWCOUNT
                     FROM (SELECT TO_CHAR(TN.THEDATE, 'YYYY-MM-DD') THEDATE,
                                  TN.CHANNELID,
                                  TN.SERVERID,
                                  TN.GAMEID,
                                  TN.GAMEVERSION,
                                  TN.ACCOUNTID
                             FROM T_100197_NU TN
                            WHERE TN.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                              AND TN.THEDATE <
                                  TRUNC(SYSDATE - V_INPUTDATE + 1)) T
                    INNER JOIN T_100197_CONN TC
                       ON T.THEDATE = TC.CONNDATE
                      AND T.CHANNELID = TC.CHANNELID
                      AND T.GAMEVERSION = TC.GAMEVERSION
                      AND T.ACCOUNTID = TC.ACCOUNTID
                    GROUP BY T.THEDATE,
                             T.CHANNELID,
                             T.GAMEID,
                             T.GAMEVERSION,
                             TC.ROLELEVEL) T1
          ON T1.THEDATE = T2.THEDATE
         AND T1.CHANNELID = T2.CHANNELID
         AND T1.GAMEVERSION = T2.GAMEVERSION
         AND T1.ROLELEVEL = T2.ROLELEVEL
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') THEDATE,
                          TOS.CHANNELID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          TOS.ROLELEVEL,
                          SUM(TOS.MONEY) PAYAMOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION,
                             TOS.ROLELEVEL) T3
          ON T2.THEDATE = T3.THEDATE
         AND T2.CHANNELID = T3.CHANNELID
         AND T2.GAMEVERSION = T3.GAMEVERSION
         AND T2.ROLELEVEL = T3.ROLELEVEL
        LEFT JOIN (SELECT TC.CONNDATE THEDATE,
                          TC.CHANNELID,
                          TC.GAMEID,
                          TC.GAMEVERSION,
                          TC.ROLELEVEL,
                          COUNT(DISTINCT TC.ACCOUNTID) PAYCOUNT
                     FROM T_100197_CONN TC
                    WHERE TC.CONNDATE =
                          TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                      AND TC.ISPAY = '1'
                    GROUP BY TC.CONNDATE,
                             TC.CHANNELID,
                             TC.GAMEID,
                             TC.GAMEVERSION,
                             TC.ROLELEVEL) T4
          ON T4.THEDATE = T2.THEDATE
         AND T4.CHANNELID = T2.CHANNELID
         AND T4.GAMEVERSION = T2.GAMEVERSION
         AND T4.ROLELEVEL = T2.ROLELEVEL;
    COMMIT;

    V_ERRPOSITION := '1-3';
    --�豸�ȼ�������Ϣ��
    INSERT INTO FACT_100197_GENERAL_LEVEL
      SELECT T2.THEDATE STATDATE,
             T2.CHANNELID CHANNELID,
             T2.SERVERID SERVERID,
             '2' DATATYPE,
             T2.GAMEID APPID,
             T2.GAMEVERSION VERSIONID,
             T2.ROLELEVEL,
             NVL(T1.NEWCOUNT, 0),
             T2.CONNCOUNT,
             NVL(T4.PAYCOUNT, 0),
             NVL(T3.PAYAMOUNT, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TC.CONNDATE THEDATE,
                     TC.CHANNELID,
                     TC.SERVERID,
                     TC.GAMEID,
                     TC.GAMEVERSION,
                     TC.ROLELEVEL,
                     --COUNT(DISTINCT TC.ACCOUNTID) CONNCOUNT,
                     COUNT(DISTINCT TC.DVID) CONNCOUNT
                FROM T_100197_CONN_MAC TC
               WHERE TC.CONNDATE =
                     TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
               GROUP BY TC.CONNDATE,
                        TC.CHANNELID,
                        TC.SERVERID,
                        TC.GAMEID,
                        TC.GAMEVERSION,
                        TC.ROLELEVEL) T2
        LEFT JOIN (SELECT T.THEDATE,
                          T.CHANNELID,
                          T.SERVERID,
                          T.GAMEID,
                          T.GAMEVERSION,
                          TC.ROLELEVEL,
                          COUNT(1) NEWCOUNT
                     FROM (SELECT TO_CHAR(TN.THEDATE, 'YYYY-MM-DD') THEDATE,
                                  TN.CHANNELID,
                                  TN.SERVERID,
                                  TN.GAMEID,
                                  TN.GAMEVERSION,
                                  TN.DVID
                             FROM T_100197_NU_MAC TN
                            WHERE TN.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                              AND TN.THEDATE <
                                  TRUNC(SYSDATE - V_INPUTDATE + 1)) T
                    INNER JOIN T_100197_CONN_MAC TC
                       ON T.THEDATE = TC.CONNDATE
                      AND T.CHANNELID = TC.CHANNELID
                      AND T.SERVERID = TC.SERVERID
                      AND T.GAMEVERSION = TC.GAMEVERSION
                      AND T.DVID = TC.DVID
                    GROUP BY T.THEDATE,
                             T.CHANNELID,
                             T.SERVERID,
                             T.GAMEID,
                             T.GAMEVERSION,
                             TC.ROLELEVEL) T1
          ON T1.THEDATE = T2.THEDATE
         AND T1.CHANNELID = T2.CHANNELID
         AND T1.SERVERID = T2.SERVERID
         AND T1.GAMEVERSION = T2.GAMEVERSION
         AND T1.ROLELEVEL = T2.ROLELEVEL
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') THEDATE,
                          TOS.CHANNELID,
                          TOS.SERVERID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          TOS.ROLELEVEL,
                          SUM(TOS.MONEY) PAYAMOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.SERVERID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION,
                             TOS.ROLELEVEL) T3
          ON T2.THEDATE = T3.THEDATE
         AND T2.CHANNELID = T3.CHANNELID
         AND T2.SERVERID = T3.SERVERID
         AND T2.GAMEVERSION = T3.GAMEVERSION
         AND T2.ROLELEVEL = T3.ROLELEVEL
        LEFT JOIN (SELECT TC.CONNDATE THEDATE,
                          TC.CHANNELID,
                          TC.SERVERID,
                          TC.GAMEID,
                          TC.GAMEVERSION,
                          TC.ROLELEVEL,
                          COUNT(DISTINCT TC.DVID) PAYCOUNT
                     FROM T_100197_CONN_MAC TC
                    WHERE TC.CONNDATE =
                          TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                      AND TC.ISPAY = '1'
                    GROUP BY TC.CONNDATE,
                             TC.CHANNELID,
                             TC.SERVERID,
                             TC.GAMEID,
                             TC.GAMEVERSION,
                             TC.ROLELEVEL) T4
          ON T4.THEDATE = T2.THEDATE
         AND T4.CHANNELID = T2.CHANNELID
         AND T4.SERVERID = T2.SERVERID
         AND T4.GAMEVERSION = T2.GAMEVERSION
         AND T4.ROLELEVEL = T2.ROLELEVEL;
    COMMIT;

    V_ERRPOSITION := '1-3-1';
    --ALL SERVER
    INSERT INTO FACT_100197_GENERAL_LEVEL
      SELECT T2.THEDATE STATDATE,
             T2.CHANNELID CHANNELID,
             LOWER('all'),
             '2' DATATYPE,
             T2.GAMEID APPID,
             T2.GAMEVERSION VERSIONID,
             T2.ROLELEVEL,
             NVL(T1.NEWCOUNT, 0),
             T2.CONNCOUNT,
             NVL(T4.PAYCOUNT, 0),
             NVL(T3.PAYAMOUNT, 0),
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TC.CONNDATE THEDATE,
                     TC.CHANNELID,
                     TC.GAMEID,
                     TC.GAMEVERSION,
                     TC.ROLELEVEL,
                     --COUNT(DISTINCT TC.ACCOUNTID) CONNCOUNT,
                     COUNT(DISTINCT TC.DVID) CONNCOUNT
                FROM T_100197_CONN_MAC TC
               WHERE TC.CONNDATE =
                     TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
               GROUP BY TC.CONNDATE,
                        TC.CHANNELID,
                        TC.GAMEID,
                        TC.GAMEVERSION,
                        TC.ROLELEVEL) T2
        LEFT JOIN (SELECT T.THEDATE,
                          T.CHANNELID,
                          T.GAMEID,
                          T.GAMEVERSION,
                          TC.ROLELEVEL,
                          COUNT(DISTINCT T.DVID) NEWCOUNT
                     FROM (SELECT TO_CHAR(TN.THEDATE, 'YYYY-MM-DD') THEDATE,
                                  TN.CHANNELID,
                                  TN.GAMEID,
                                  TN.GAMEVERSION,
                                  TN.DVID
                             FROM T_100197_NU_MAC TN
                            WHERE TN.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                              AND TN.THEDATE <
                                  TRUNC(SYSDATE - V_INPUTDATE + 1)) T
                    INNER JOIN T_100197_CONN_MAC TC
                       ON T.THEDATE = TC.CONNDATE
                      AND T.CHANNELID = TC.CHANNELID
                      AND T.GAMEVERSION = TC.GAMEVERSION
                      AND T.DVID = TC.DVID
                    GROUP BY T.THEDATE,
                             T.CHANNELID,
                             T.GAMEID,
                             T.GAMEVERSION,
                             TC.ROLELEVEL) T1
          ON T1.THEDATE = T2.THEDATE
         AND T1.CHANNELID = T2.CHANNELID
         AND T1.GAMEVERSION = T2.GAMEVERSION
         AND T1.ROLELEVEL = T2.ROLELEVEL
        LEFT JOIN (SELECT TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD') THEDATE,
                          TOS.CHANNELID,
                          TOS.GAMEID,
                          TOS.GAMEVERSION,
                          TOS.ROLELEVEL,
                          SUM(TOS.MONEY) PAYAMOUNT
                     FROM T_100197_ORDER_SUCC TOS
                    WHERE TOS.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TOS.THEDATE, 'YYYY-MM-DD'),
                             TOS.CHANNELID,
                             TOS.GAMEID,
                             TOS.GAMEVERSION,
                             TOS.ROLELEVEL) T3
          ON T2.THEDATE = T3.THEDATE
         AND T2.CHANNELID = T3.CHANNELID
         AND T2.GAMEVERSION = T3.GAMEVERSION
         AND T2.ROLELEVEL = T3.ROLELEVEL
        LEFT JOIN (SELECT TC.CONNDATE THEDATE,
                          TC.CHANNELID,
                          TC.GAMEID,
                          TC.GAMEVERSION,
                          TC.ROLELEVEL,
                          COUNT(DISTINCT TC.DVID) PAYCOUNT
                     FROM T_100197_CONN_MAC TC
                    WHERE TC.CONNDATE =
                          TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                      AND TC.ISPAY = '1'
                    GROUP BY TC.CONNDATE,
                             TC.CHANNELID,
                             TC.GAMEID,
                             TC.GAMEVERSION,
                             TC.ROLELEVEL) T4
          ON T4.THEDATE = T2.THEDATE
         AND T4.CHANNELID = T2.CHANNELID
         AND T4.GAMEVERSION = T2.GAMEVERSION
         AND T4.ROLELEVEL = T2.ROLELEVEL;
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_100197_GENERAL_LEVEL';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_LTV����***************************************************************/
  --����FACT_LTV����
  PROCEDURE P_FACT_LTV(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;

    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_LTV';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    V_ERRPOSITION := '1-1';
    DELETE FROM FACT_100197_LTV_MAC T
     WHERE T.LTVDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    V_ERRPOSITION := '1-2';
    --�����豸ÿ��LTV
    INSERT INTO FACT_100197_LTV_MAC
      SELECT *
        FROM (SELECT T2.STATDATE,
                     T1.LTVDATE,
                     T1.CHANNELID,
                     T1.SERVERID,
                     T1.GAMEID,
                     TO_DATE(T1.LTVDATE, 'YYYY-MM-DD') -
                     TO_DATE(T2.STATDATE, 'YYYY-MM-DD') + 1 LTV_DAYS,
                     SUM(T1.PAYMOUNT) PAYMOUNT,
                     SYSDATE,
                     V_ERRSOURCE
                FROM (SELECT TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE), 'YYYY-MM-DD') LTVDATE,
                             TOS.CHANNELID,
                             TOS.SERVERID,
                             TOS.GAMEID,
                             TOS.DVID,
                             SUM(TOS.MONEY) PAYMOUNT
                        FROM T_100197_ORDER_SUCC TOS
                       WHERE TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                       GROUP BY TOS.CHANNELID,
                                TOS.SERVERID,
                                TOS.GAMEID,
                                TOS.DVID) T1
               INNER JOIN (SELECT TO_CHAR(TNM.THEDATE, 'YYYY-MM-DD') STATDATE,
                                 TNM.CHANNELID,
                                 TNM.SERVERID,
                                 TNM.GAMEID,
                                 TNM.DVID
                            FROM T_100197_NU_MAC TNM
                           WHERE TNM.GAMEID = '100197') T2
                  ON T1.CHANNELID = T2.CHANNELID
                 AND T1.SERVERID = T2.SERVERID
                 AND T1.DVID = T2.DVID
               GROUP BY T2.STATDATE,
                        T1.LTVDATE,
                        T1.CHANNELID,
                        T1.SERVERID,
                        T1.GAMEID,
                        TO_DATE(T1.LTVDATE, 'YYYY-MM-DD') -
                        TO_DATE(T2.STATDATE, 'YYYY-MM-DD') + 1) T
       WHERE T.LTV_DAYS <= 90;
    COMMIT;

    V_ERRPOSITION := '1-2-1';
    --ALL SERVER
    INSERT INTO FACT_100197_LTV_MAC
      SELECT *
        FROM (SELECT T2.STATDATE,
                     T1.LTVDATE,
                     T1.CHANNELID,
                     LOWER('all'),
                     T1.GAMEID,
                     TO_DATE(T1.LTVDATE, 'YYYY-MM-DD') -
                     TO_DATE(T2.STATDATE, 'YYYY-MM-DD') + 1 LTV_DAYS,
                     SUM(T1.PAYMOUNT) PAYMOUNT,
                     SYSDATE,
                     V_ERRSOURCE
                FROM (SELECT TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE), 'YYYY-MM-DD') LTVDATE,
                             TOS.CHANNELID,
                             TOS.GAMEID,
                             TOS.DVID,
                             SUM(TOS.MONEY) PAYMOUNT
                        FROM T_100197_ORDER_SUCC TOS
                       WHERE TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                       GROUP BY TOS.CHANNELID,
                                TOS.GAMEID,
                                TOS.DVID) T1
               INNER JOIN (SELECT TO_CHAR(MIN(TNM.THEDATE), 'YYYY-MM-DD') STATDATE,
                                 TNM.CHANNELID,
                                 TNM.GAMEID,
                                 TNM.DVID
                            FROM T_100197_NU_MAC_ALLSERVER TNM
                           WHERE TNM.GAMEID = '100197'
                           GROUP BY TNM.CHANNELID, TNM.GAMEID, TNM.DVID) T2
                  ON T1.CHANNELID = T2.CHANNELID
                 AND T1.DVID = T2.DVID
               GROUP BY T2.STATDATE,
                        T1.LTVDATE,
                        T1.CHANNELID,
                        T1.GAMEID,
                        TO_DATE(T1.LTVDATE, 'YYYY-MM-DD') -
                        TO_DATE(T2.STATDATE, 'YYYY-MM-DD') + 1) T
       WHERE T.LTV_DAYS <= 90;
    COMMIT;

    V_ERRPOSITION := '1-3';
    DELETE FROM FACT_100197_LTV_USER T
     WHERE T.APPID = '100197'
       AND T.LTVDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    V_ERRPOSITION := '1-4';
    --�����û�ÿ��LTV
    INSERT INTO FACT_100197_LTV_USER
      SELECT *
        FROM (SELECT T2.STATDATE,
                     T1.LTVDATE,
                     T1.CHANNELID,
                     T1.SERVERID,
                     T1.GAMEID,
                     TO_DATE(T1.LTVDATE, 'YYYY-MM-DD') -
                     TO_DATE(T2.STATDATE, 'YYYY-MM-DD') + 1 LTV_DAYS,
                     SUM(T1.PAYMOUNT) PAYMOUNT,
                     SYSDATE,
                     V_ERRSOURCE
                FROM (SELECT TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE), 'YYYY-MM-DD') LTVDATE,
                             TOS.CHANNELID,
                             TOS.SERVERID,
                             TOS.GAMEID,
                             TOS.ACCOUNTID,
                             SUM(TOS.MONEY) PAYMOUNT
                        FROM T_100197_ORDER_SUCC TOS
                       WHERE TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                       GROUP BY TOS.CHANNELID,
                                TOS.SERVERID,
                                TOS.GAMEID,
                                TOS.ACCOUNTID) T1
               INNER JOIN (SELECT TO_CHAR(TNM.THEDATE, 'YYYY-MM-DD') STATDATE,
                                 TNM.CHANNELID,
                                 TNM.SERVERID,
                                 TNM.GAMEID,
                                 TNM.ACCOUNTID
                            FROM T_100197_NU TNM) T2
                  ON T1.CHANNELID = T2.CHANNELID
                 AND T1.SERVERID = T2.SERVERID
                 AND T1.ACCOUNTID = T2.ACCOUNTID
               GROUP BY T2.STATDATE,
                        T1.LTVDATE,
                        T1.CHANNELID,
                        T1.SERVERID,
                        T1.GAMEID,
                        TO_DATE(T1.LTVDATE, 'YYYY-MM-DD') -
                        TO_DATE(T2.STATDATE, 'YYYY-MM-DD') + 1) T
       WHERE T.LTV_DAYS <= 90;
    COMMIT;

    V_ERRPOSITION := '1-4-1';
    --ALL SERVER
    INSERT INTO FACT_100197_LTV_USER
      SELECT *
        FROM (SELECT T2.STATDATE,
                     T1.LTVDATE,
                     T1.CHANNELID,
                     LOWER('all'),
                     T1.GAMEID,
                     TO_DATE(T1.LTVDATE, 'YYYY-MM-DD') -
                     TO_DATE(T2.STATDATE, 'YYYY-MM-DD') + 1 LTV_DAYS,
                     SUM(T1.PAYMOUNT) PAYMOUNT,
                     SYSDATE,
                     V_ERRSOURCE
                FROM (SELECT TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE), 'YYYY-MM-DD') LTVDATE,
                             TOS.CHANNELID,
                             TOS.GAMEID,
                             TOS.ACCOUNTID,
                             SUM(TOS.MONEY) PAYMOUNT
                        FROM T_100197_ORDER_SUCC TOS
                       WHERE TOS.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                       GROUP BY TOS.CHANNELID,
                                TOS.GAMEID,
                                TOS.ACCOUNTID) T1
               INNER JOIN (SELECT TO_CHAR(MIN(TNM.THEDATE), 'YYYY-MM-DD') STATDATE,
                                 TNM.CHANNELID,
                                 TNM.GAMEID,
                                 TNM.ACCOUNTID
                            FROM T_100197_NU_ALLSERVER TNM
                           GROUP BY TNM.CHANNELID, TNM.GAMEID, TNM.ACCOUNTID) T2
                  ON T1.CHANNELID = T2.CHANNELID
                 AND T1.ACCOUNTID = T2.ACCOUNTID
               GROUP BY T2.STATDATE,
                        T1.LTVDATE,
                        T1.CHANNELID,
                        T1.GAMEID,
                        TO_DATE(T1.LTVDATE, 'YYYY-MM-DD') -
                        TO_DATE(T2.STATDATE, 'YYYY-MM-DD') + 1) T
       WHERE T.LTV_DAYS <= 90;
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_LTV';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_100197_BACK����***************************************************************/
  --����FACT_100197_BACK����
  PROCEDURE P_FACT_BACK(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
    V_WEEKFIRSTDAY VARCHAR2(10); --���������ҳ� ������������ܵĵ�һ��
  BEGIN
    P_ERRCODE := 7100;

    IF SUBSTR(P_LOGTIME, 12, 2) = '23' THEN
      SELECT TRUNC(SYSDATE) -
             TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
        INTO V_INPUTDATE
        FROM DUAL;

      --��ȡ�ܵ�һ��
      SELECT TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE + 1) -
                     DECODE((TO_CHAR(SYSDATE - V_INPUTDATE, 'D') - 1),
                            0,
                            7,
                            (TO_CHAR(SYSDATE - V_INPUTDATE, 'D') - 1)),
                     'YYYY-MM-DD')
        INTO V_WEEKFIRSTDAY
        FROM DUAL;

      ------------------------------ִ����־��ʼ----------------------------------------------
      V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_BACK';
      PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------ִ����־��ʼ----------------------------------------------

      ---------------------------------------------------FACT_100197_BACK_MAC----------------------------------------------------------------------------------
      --�豸
      V_ERRPOSITION := '1-1';
      DELETE FROM FACT_100197_BACK_MAC T
       WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
      COMMIT;

      V_ERRPOSITION := '1-2';
      INSERT INTO FACT_100197_BACK_MAC
        SELECT T2.CONNDATE,
               T2.CHANNELID,
               T2.SERVERID,
               T2.GAMEID,
               T1.LOST_DAYS,
               COUNT(T1.MACID) BACK_CONN,
               COUNT(T3.MACID) BACK_PAY,
               SYSDATE,
               V_ERRSOURCE
          FROM (SELECT TLM.CHANNELID,
                       TLM.SERVERID,
                       TLM.APPID,
                       TLM.MACID,
                       MAX(TLM.LOST_DAYS) LOST_DAYS
                  FROM T_100197_LOST_MAC TLM
                 WHERE TLM.LOST_DATE =
                       TO_CHAR(SYSDATE - V_INPUTDATE - 1, 'YYYY-MM-DD')
                 GROUP BY TLM.CHANNELID, TLM.SERVERID, TLM.APPID, TLM.MACID) T1

         INNER JOIN (SELECT TCM.CONNDATE,
                            TCM.CHANNELID,
                            TCM.SERVERID,
                            TCM.GAMEID,
                            TCM.DVID
                       FROM T_100197_CONN_MAC TCM
                      WHERE TCM.CONNDATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')) T2
            ON T1.CHANNELID = T2.CHANNELID
           AND T1.SERVERID = T2.SERVERID
           AND T1.MACID = T2.DVID

          LEFT JOIN (SELECT TLM.CHANNELID,
                            TLM.SERVERID,
                            TLM.APPID,
                            TLM.MACID,
                            MAX(TLM.LOST_DAYS) LOST_DAYS
                       FROM T_100197_LOST_MAC TLM
                      WHERE TLM.ISPAY = '1'
                        AND TLM.LOST_DATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE - 1, 'YYYY-MM-DD')
                      GROUP BY TLM.CHANNELID,
                               TLM.SERVERID,
                               TLM.APPID,
                               TLM.MACID) T3
            ON T3.CHANNELID = T2.CHANNELID
           AND T3.SERVERID = T2.SERVERID
           AND T3.MACID = T2.DVID
         GROUP BY T2.CONNDATE,
                  T2.CHANNELID,
                  T2.SERVERID,
                  T2.GAMEID,
                  T1.LOST_DAYS;
      COMMIT;

      V_ERRPOSITION := '1-2-1';
      --ALLSERVER
      INSERT INTO FACT_100197_BACK_MAC
        SELECT T2.CONNDATE,
               T2.CHANNELID,
               LOWER('all'),
               T2.GAMEID,
               T1.LOST_DAYS,
               COUNT(T1.MACID) BACK_CONN,
               COUNT(T3.MACID) BACK_PAY,
               SYSDATE,
               V_ERRSOURCE
          FROM (SELECT TLM.CHANNELID,
                       TLM.APPID,
                       TLM.MACID,
                       MAX(TLM.LOST_DAYS) LOST_DAYS
                  FROM T_100197_LOST_MAC_AS TLM
                 WHERE TLM.LOST_DATE =
                       TO_CHAR(SYSDATE - V_INPUTDATE - 1, 'YYYY-MM-DD')
                 GROUP BY TLM.CHANNELID, TLM.APPID, TLM.MACID) T1

         INNER JOIN (SELECT DISTINCT TCM.CONNDATE,
                                     TCM.CHANNELID,
                                     TCM.GAMEID,
                                     TCM.DVID
                       FROM T_100197_CONN_MAC TCM
                      WHERE TCM.CONNDATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')) T2
            ON T1.CHANNELID = T2.CHANNELID
           AND T1.MACID = T2.DVID

          LEFT JOIN (SELECT TLM.CHANNELID,
                            TLM.APPID,
                            TLM.MACID,
                            MAX(TLM.LOST_DAYS) LOST_DAYS
                       FROM T_100197_LOST_MAC_AS TLM
                      WHERE TLM.ISPAY = '1'
                        AND TLM.LOST_DATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE - 1, 'YYYY-MM-DD')
                      GROUP BY TLM.CHANNELID, TLM.APPID, TLM.MACID) T3
            ON T3.CHANNELID = T2.CHANNELID
           AND T3.MACID = T2.DVID
         GROUP BY T2.CONNDATE, T2.CHANNELID, T2.GAMEID, T1.LOST_DAYS;
      COMMIT;

      ---------------------------------------------------FACT_100197_BACK_USER----------------------------------------------------------------------------------
      V_ERRPOSITION := '1-3';
      DELETE FROM FACT_100197_BACK_USER T
       WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
      COMMIT;

      V_ERRPOSITION := '1-4';
      INSERT INTO FACT_100197_BACK_USER
        SELECT T2.CONNDATE,
               T2.CHANNELID,
               T2.SERVERID,
               T2.GAMEID,
               T1.LOST_DAYS,
               COUNT(T1.USERID) BACK_CONN,
               COUNT(T3.USERID) BACK_PAY,
               SYSDATE,
               V_ERRSOURCE
          FROM (SELECT TLM.CHANNELID,
                       TLM.SERVERID,
                       TLM.APPID,
                       TLM.USERID,
                       MAX(TLM.LOST_DAYS) LOST_DAYS
                  FROM T_100197_LOST_USER TLM
                 WHERE TLM.LOST_DATE =
                       TO_CHAR(SYSDATE - V_INPUTDATE - 1, 'YYYY-MM-DD')
                 GROUP BY TLM.CHANNELID, TLM.SERVERID, TLM.APPID, TLM.USERID) T1

         INNER JOIN (SELECT TCM.CONNDATE,
                            TCM.CHANNELID,
                            TCM.SERVERID,
                            TCM.GAMEID,
                            TCM.ACCOUNTID
                       FROM T_100197_CONN TCM
                      WHERE TCM.CONNDATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')) T2
            ON T1.CHANNELID = T2.CHANNELID
           AND T1.SERVERID = T2.SERVERID
           AND T1.USERID = T2.ACCOUNTID

          LEFT JOIN (SELECT TLM.CHANNELID,
                            TLM.SERVERID,
                            TLM.APPID,
                            TLM.USERID,
                            MAX(TLM.LOST_DAYS) LOST_DAYS
                       FROM T_100197_LOST_USER TLM
                      WHERE TLM.ISPAY = '1'
                        AND TLM.LOST_DATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE - 1, 'YYYY-MM-DD')
                      GROUP BY TLM.CHANNELID,
                               TLM.SERVERID,
                               TLM.APPID,
                               TLM.USERID) T3
            ON T3.CHANNELID = T2.CHANNELID
           AND T3.SERVERID = T2.SERVERID
           AND T3.USERID = T2.ACCOUNTID
         GROUP BY T2.CONNDATE,
                  T2.CHANNELID,
                  T2.SERVERID,
                  T2.GAMEID,
                  T1.LOST_DAYS;
      COMMIT;

      V_ERRPOSITION := '1-4-1';
      --ALLSERVER
      INSERT INTO FACT_100197_BACK_USER
        SELECT T2.CONNDATE,
               T2.CHANNELID,
               LOWER('all'),
               T2.GAMEID,
               T1.LOST_DAYS,
               COUNT(T1.USERID) BACK_CONN,
               COUNT(T3.USERID) BACK_PAY,
               SYSDATE,
               V_ERRSOURCE
          FROM (SELECT TLM.CHANNELID,
                       TLM.APPID,
                       TLM.USERID,
                       MAX(TLM.LOST_DAYS) LOST_DAYS
                  FROM T_100197_LOST_USER_AS TLM
                 WHERE TLM.LOST_DATE =
                       TO_CHAR(SYSDATE - V_INPUTDATE - 1, 'YYYY-MM-DD')
                 GROUP BY TLM.CHANNELID, TLM.APPID, TLM.USERID) T1

         INNER JOIN (SELECT DISTINCT TCM.CONNDATE,
                                     TCM.CHANNELID,
                                     TCM.GAMEID,
                                     TCM.ACCOUNTID
                       FROM T_100197_CONN TCM
                      WHERE TCM.CONNDATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')) T2
            ON T1.CHANNELID = T2.CHANNELID
           AND T1.USERID = T2.ACCOUNTID

          LEFT JOIN (SELECT TLM.CHANNELID,
                            TLM.APPID,
                            TLM.USERID,
                            MAX(TLM.LOST_DAYS) LOST_DAYS
                       FROM T_100197_LOST_USER_AS TLM
                      WHERE TLM.ISPAY = '1'
                        AND TLM.LOST_DATE =
                            TO_CHAR(SYSDATE - V_INPUTDATE - 1, 'YYYY-MM-DD')
                      GROUP BY TLM.CHANNELID, TLM.APPID, TLM.USERID) T3
            ON T3.CHANNELID = T2.CHANNELID
           AND T3.USERID = T2.ACCOUNTID
         GROUP BY T2.CONNDATE, T2.CHANNELID, T2.GAMEID, T1.LOST_DAYS;
      COMMIT;

      ---------------------------------------------------FACT_100197_BACK_MAC_WEEK----------------------------------------------------------------------------------
      V_ERRPOSITION := '1-5';
      DELETE FROM FACT_100197_BACK_MAC_WEEK T
       WHERE T.STATDATE = V_WEEKFIRSTDAY;
      COMMIT;

      V_ERRPOSITION := '1-6';
      INSERT INTO FACT_100197_BACK_MAC_WEEK
        (STATDATE,
         CHANNELID,
         SERVERID,
         APPID,
         BACK_CONN,
         BACK_PAY,
         LOADDATE,
         DATA_SOURCE)
        SELECT T2.CONNDATE,
               T2.CHANNELID,
               T2.SERVERID,
               T2.GAMEID,
               COUNT(T1.MACID) BACK_CONN,
               COUNT(T3.MACID) BACK_PAY,
               SYSDATE,
               V_ERRSOURCE
          FROM (SELECT TLM.CHANNELID,
                       TLM.SERVERID,
                       TLM.APPID,
                       TLM.MACID,
                       MAX(TLM.STATDATE) LOST_DAY --�����������
                  FROM T_100197_LOST_MAC TLM
                 WHERE TLM.LOST_DATE =
                       TO_CHAR(TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD') - 1,
                               'YYYY-MM-DD')
                 GROUP BY TLM.CHANNELID, TLM.SERVERID, TLM.APPID, TLM.MACID) T1

         INNER JOIN (SELECT V_WEEKFIRSTDAY CONNDATE, --�ܵ�һ��
                            TCM.CHANNELID,
                            TCM.SERVERID,
                            TCM.GAMEID,
                            TCM.DVID
                       FROM T_100197_CONN_MAC TCM
                      WHERE TCM.CONNDATE >= V_WEEKFIRSTDAY
                        AND TCM.CONNDATE <=
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')) T2
            ON T1.CHANNELID = T2.CHANNELID
           AND T1.SERVERID = T2.SERVERID
           AND T1.MACID = T2.DVID
        /*AND TO_DATE(T2.CONNDATE, 'YYYY-MM-DD') -
        TO_DATE(T1.LOST_DAY, 'YYYY-MM-DD') > 7*/
          LEFT JOIN (SELECT TLM.CHANNELID,
                            TLM.SERVERID,
                            TLM.APPID,
                            TLM.MACID,
                            MAX(TLM.STATDATE) LOST_DAY
                       FROM T_100197_LOST_MAC TLM
                      WHERE TLM.ISPAY = '1'
                        AND TLM.LOST_DATE =
                            TO_CHAR(TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD') - 1,
                                    'YYYY-MM-DD')
                      GROUP BY TLM.CHANNELID,
                               TLM.SERVERID,
                               TLM.APPID,
                               TLM.MACID) T3
            ON T3.CHANNELID = T2.CHANNELID
           AND T3.SERVERID = T2.SERVERID
           AND T3.MACID = T2.DVID
        /*AND TO_DATE(T2.CONNDATE, 'YYYY-MM-DD') -
        TO_DATE(T3.LOST_DAY, 'YYYY-MM-DD') > 7*/
         GROUP BY T2.CONNDATE, T2.CHANNELID, T2.SERVERID, T2.GAMEID;
      COMMIT;

      V_ERRPOSITION := '1-6-1';
      --ALLSERVER
      INSERT INTO FACT_100197_BACK_MAC_WEEK
        (STATDATE,
         CHANNELID,
         SERVERID,
         APPID,
         BACK_CONN,
         BACK_PAY,
         LOADDATE,
         DATA_SOURCE)
        SELECT T2.CONNDATE,
               T2.CHANNELID,
               LOWER('all'),
               T2.GAMEID,
               COUNT(T1.MACID) BACK_CONN,
               COUNT(T3.MACID) BACK_PAY,
               SYSDATE,
               V_ERRSOURCE
          FROM (SELECT TLM.CHANNELID,
                       TLM.APPID,
                       TLM.MACID,
                       MAX(TLM.STATDATE) LOST_DAY --�����������
                  FROM T_100197_LOST_MAC_AS TLM
                 WHERE TLM.LOST_DATE =
                       TO_CHAR(TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD') - 1,
                               'YYYY-MM-DD')
                 GROUP BY TLM.CHANNELID, TLM.APPID, TLM.MACID) T1

         INNER JOIN (SELECT DISTINCT V_WEEKFIRSTDAY CONNDATE, --�ܵ�һ��
                                     TCM.CHANNELID,
                                     TCM.GAMEID,
                                     TCM.DVID
                       FROM T_100197_CONN_MAC TCM
                      WHERE TCM.CONNDATE >= V_WEEKFIRSTDAY
                        AND TCM.CONNDATE <=
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')) T2
            ON T1.CHANNELID = T2.CHANNELID
           AND T1.MACID = T2.DVID
        /*AND TO_DATE(T2.CONNDATE, 'YYYY-MM-DD') -
        TO_DATE(T1.LOST_DAY, 'YYYY-MM-DD') > 7*/
          LEFT JOIN (SELECT TLM.CHANNELID,
                            TLM.APPID,
                            TLM.MACID,
                            MAX(TLM.STATDATE) LOST_DAY
                       FROM T_100197_LOST_MAC_AS TLM
                      WHERE TLM.ISPAY = '1'
                        AND TLM.LOST_DATE =
                            TO_CHAR(TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD') - 1,
                                    'YYYY-MM-DD')
                      GROUP BY TLM.CHANNELID, TLM.APPID, TLM.MACID) T3
            ON T3.CHANNELID = T2.CHANNELID
           AND T3.MACID = T2.DVID
        /*AND TO_DATE(T2.CONNDATE, 'YYYY-MM-DD') -
        TO_DATE(T3.LOST_DAY, 'YYYY-MM-DD') > 7*/
         GROUP BY T2.CONNDATE, T2.CHANNELID, T2.GAMEID;
      COMMIT;

      ---------------------------------------------------FACT_100197_BACK_USER_WEEK----------------------------------------------------------------------------------
      V_ERRPOSITION := '1-7';
      DELETE FROM FACT_100197_BACK_USER_WEEK T
       WHERE T.STATDATE = V_WEEKFIRSTDAY;
      COMMIT;

      V_ERRPOSITION := '1-8';
      INSERT INTO FACT_100197_BACK_USER_WEEK
        (STATDATE,
         CHANNELID,
         SERVERID,
         APPID,
         BACK_CONN,
         BACK_PAY,
         LOADDATE,
         DATA_SOURCE)
        SELECT T2.CONNDATE,
               T2.CHANNELID,
               T2.SERVERID,
               T2.GAMEID,
               COUNT(T1.USERID) BACK_CONN,
               COUNT(T3.USERID) BACK_PAY,
               SYSDATE,
               V_ERRSOURCE
          FROM (SELECT TLM.CHANNELID,
                       TLM.SERVERID,
                       TLM.APPID,
                       TLM.USERID,
                       MAX(TLM.STATDATE) LOST_DAY --�����������
                  FROM T_100197_LOST_USER TLM
                 WHERE TLM.LOST_DATE =
                       TO_CHAR(TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD') - 1,
                               'YYYY-MM-DD')
                 GROUP BY TLM.CHANNELID, TLM.SERVERID, TLM.APPID, TLM.USERID) T1
         INNER JOIN (SELECT V_WEEKFIRSTDAY CONNDATE, --�ܵ�һ��
                            TCM.CHANNELID,
                            TCM.SERVERID,
                            TCM.GAMEID,
                            TCM.ACCOUNTID  DVID
                       FROM T_100197_CONN TCM
                      WHERE TCM.CONNDATE >= V_WEEKFIRSTDAY
                        AND TCM.CONNDATE <=
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')) T2
            ON T1.CHANNELID = T2.CHANNELID
           AND T1.SERVERID = T2.SERVERID
           AND T1.USERID = T2.DVID
        /*AND TO_DATE(T2.CONNDATE, 'YYYY-MM-DD') -
        TO_DATE(T1.LOST_DAY, 'YYYY-MM-DD') > 7*/
          LEFT JOIN (SELECT TLM.CHANNELID,
                            TLM.SERVERID,
                            TLM.APPID,
                            TLM.USERID,
                            MAX(TLM.STATDATE) LOST_DAY
                       FROM T_100197_LOST_USER TLM
                      WHERE TLM.ISPAY = '1'
                        AND TLM.LOST_DATE =
                            TO_CHAR(TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD') - 1,
                                    'YYYY-MM-DD')
                      GROUP BY TLM.CHANNELID,
                               TLM.SERVERID,
                               TLM.APPID,
                               TLM.USERID) T3
            ON T3.CHANNELID = T2.CHANNELID
           AND T3.SERVERID = T2.SERVERID
           AND T3.USERID = T2.DVID
        /*AND TO_DATE(T2.CONNDATE, 'YYYY-MM-DD') -
        TO_DATE(T3.LOST_DAY, 'YYYY-MM-DD') > 7*/
         GROUP BY T2.CONNDATE, T2.CHANNELID, T2.SERVERID, T2.GAMEID;
      COMMIT;

      V_ERRPOSITION := '1-8-1';
      --ALLSERVER
      INSERT INTO FACT_100197_BACK_USER_WEEK
        (STATDATE,
         CHANNELID,
         SERVERID,
         APPID,
         BACK_CONN,
         BACK_PAY,
         LOADDATE,
         DATA_SOURCE)
        SELECT T2.CONNDATE,
               T2.CHANNELID,
               LOWER('all'),
               T2.GAMEID,
               COUNT(T1.USERID) BACK_CONN,
               COUNT(T3.USERID) BACK_PAY,
               SYSDATE,
               V_ERRSOURCE
          FROM (SELECT TLM.CHANNELID,
                       TLM.APPID,
                       TLM.USERID,
                       MAX(TLM.STATDATE) LOST_DAY --�����������
                  FROM T_100197_LOST_USER_AS TLM
                 WHERE TLM.LOST_DATE =
                       TO_CHAR(TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD') - 1,
                               'YYYY-MM-DD')
                 GROUP BY TLM.CHANNELID, TLM.APPID, TLM.USERID) T1

         INNER JOIN (SELECT DISTINCT V_WEEKFIRSTDAY CONNDATE, --�ܵ�һ��
                                     TCM.CHANNELID,
                                     TCM.GAMEID,
                                     TCM.ACCOUNTID  DVID
                       FROM T_100197_CONN TCM
                      WHERE TCM.CONNDATE >= V_WEEKFIRSTDAY
                        AND TCM.CONNDATE <=
                            TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')) T2
            ON T1.CHANNELID = T2.CHANNELID
           AND T1.USERID = T2.DVID
        /*AND TO_DATE(T2.CONNDATE, 'YYYY-MM-DD') -
        TO_DATE(T1.LOST_DAY, 'YYYY-MM-DD') > 7*/
          LEFT JOIN (SELECT TLM.CHANNELID,
                            TLM.APPID,
                            TLM.USERID,
                            MAX(TLM.STATDATE) LOST_DAY
                       FROM T_100197_LOST_USER_AS TLM
                      WHERE TLM.ISPAY = '1'
                        AND TLM.LOST_DATE =
                            TO_CHAR(TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD') - 1,
                                    'YYYY-MM-DD')
                      GROUP BY TLM.CHANNELID, TLM.APPID, TLM.USERID) T3
            ON T3.CHANNELID = T2.CHANNELID
           AND T3.USERID = T2.DVID
        /*AND TO_DATE(T2.CONNDATE, 'YYYY-MM-DD') -
        TO_DATE(T3.LOST_DAY, 'YYYY-MM-DD') > 7*/
         GROUP BY T2.CONNDATE, T2.CHANNELID, T2.GAMEID;
      COMMIT;

      ---------------------------------------------------FACT_100197_BACK_MAC_MONTH----------------------------------------------------------------------------------
      V_ERRPOSITION := '1-9';
      DELETE FROM FACT_100197_BACK_MAC_MONTH T
       WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM');
      COMMIT;

      V_ERRPOSITION := '1-10';
      INSERT INTO FACT_100197_BACK_MAC_MONTH
        (STATDATE,
         CHANNELID,
         SERVERID,
         APPID,
         BACK_CONN,
         BACK_PAY,
         LOADDATE,
         DATA_SOURCE)
        SELECT CONNDATE,
               T2.CHANNELID,
               T2.SERVERID,
               T2.GAMEID,
               COUNT(T1.MACID) BACK_CONN,
               COUNT(T3.MACID) BACK_PAY,
               SYSDATE,
               V_ERRSOURCE
          FROM (SELECT TLM.CHANNELID,
                       TLM.SERVERID,
                       TLM.APPID,
                       TLM.MACID,
                       MAX(TLM.STATDATE) LOST_DAY --�����������
                  FROM T_100197_LOST_MAC TLM
                 WHERE TLM.LOST_DATE =
                       TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE, 'MM') - 1,
                               'YYYY-MM-DD')
                 GROUP BY TLM.CHANNELID, TLM.SERVERID, TLM.APPID, TLM.MACID) T1
         INNER JOIN (SELECT DISTINCT TO_CHAR(SYSDATE - V_INPUTDATE,
                                             'YYYY-MM') CONNDATE,
                                     TCM.CHANNELID,
                                     TCM.SERVERID,
                                     TCM.GAMEID,
                                     TCM.DVID
                       FROM T_100197_CONN_MAC TCM
                      WHERE TCM.CONNDATE >=
                            TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE, 'MM'),
                                    'YYYY-MM-DD')
                        AND TCM.CONNDATE <
                            TO_CHAR(TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE,
                                                     1),
                                          'MM'),
                                    'YYYY-MM-DD')) T2
            ON T1.CHANNELID = T2.CHANNELID
           AND T1.SERVERID = T2.SERVERID
           AND T1.MACID = T2.DVID
        /*
        AND TO_DATE(T2.CONNDATE, 'YYYY-MM-DD') -
            TO_DATE(T1.LOST_DAY, 'YYYY-MM-DD') > 30*/
          LEFT JOIN (SELECT TLM.CHANNELID,
                            TLM.SERVERID,
                            TLM.APPID,
                            TLM.MACID,
                            MAX(TLM.STATDATE) LOST_DAY
                       FROM T_100197_LOST_MAC TLM
                      WHERE TLM.ISPAY = '1'
                        AND TLM.LOST_DATE =
                            TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE, 'MM') - 1,
                                    'YYYY-MM-DD')
                      GROUP BY TLM.CHANNELID,
                               TLM.SERVERID,
                               TLM.APPID,
                               TLM.MACID) T3
            ON T3.CHANNELID = T2.CHANNELID
           AND T3.SERVERID = T2.SERVERID
           AND T3.MACID = T2.DVID
        /*
        AND TO_DATE(T2.CONNDATE, 'YYYY-MM-DD') -
            TO_DATE(T3.LOST_DAY, 'YYYY-MM-DD') > 30*/
         GROUP BY T2.CONNDATE, T2.CHANNELID, T2.SERVERID, T2.GAMEID;
      COMMIT;

      V_ERRPOSITION := '1-10-1';
      --ALLSERVER
      INSERT INTO FACT_100197_BACK_MAC_MONTH
        (STATDATE,
         CHANNELID,
         SERVERID,
         APPID,
         BACK_CONN,
         BACK_PAY,
         LOADDATE,
         DATA_SOURCE)
        SELECT CONNDATE,
               T2.CHANNELID,
               LOWER('all'),
               T2.GAMEID,
               COUNT(T1.MACID) BACK_CONN,
               COUNT(T3.MACID) BACK_PAY,
               SYSDATE,
               V_ERRSOURCE
          FROM (SELECT TLM.CHANNELID,
                       TLM.APPID,
                       TLM.MACID,
                       MAX(TLM.STATDATE) LOST_DAY --�����������
                  FROM T_100197_LOST_MAC_AS TLM
                 WHERE TLM.LOST_DATE =
                       TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE, 'MM') - 1,
                               'YYYY-MM-DD')
                 GROUP BY TLM.CHANNELID, TLM.APPID, TLM.MACID) T1

         INNER JOIN (SELECT DISTINCT TO_CHAR(SYSDATE - V_INPUTDATE,
                                             'YYYY-MM') CONNDATE,
                                     TCM.CHANNELID,
                                     TCM.GAMEID,
                                     TCM.DVID
                       FROM T_100197_CONN_MAC TCM
                      WHERE TCM.CONNDATE >=
                            TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE, 'MM'),
                                    'YYYY-MM-DD')
                        AND TCM.CONNDATE <
                            TO_CHAR(TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE,
                                                     1),
                                          'MM'),
                                    'YYYY-MM-DD')) T2
            ON T1.CHANNELID = T2.CHANNELID
           AND T1.MACID = T2.DVID
        /*
        AND TO_DATE(T2.CONNDATE, 'YYYY-MM-DD') -
            TO_DATE(T1.LOST_DAY, 'YYYY-MM-DD') > 30*/
          LEFT JOIN (SELECT TLM.CHANNELID,
                            TLM.APPID,
                            TLM.MACID,
                            MAX(TLM.STATDATE) LOST_DAY
                       FROM T_100197_LOST_MAC_AS TLM
                      WHERE TLM.ISPAY = '1'
                        AND TLM.LOST_DATE =
                            TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE, 'MM') - 1,
                                    'YYYY-MM-DD')
                      GROUP BY TLM.CHANNELID, TLM.APPID, TLM.MACID) T3
            ON T3.CHANNELID = T2.CHANNELID
           AND T3.MACID = T2.DVID
        /*
        AND TO_DATE(T2.CONNDATE, 'YYYY-MM-DD') -
            TO_DATE(T3.LOST_DAY, 'YYYY-MM-DD') > 30*/
         GROUP BY T2.CONNDATE, T2.CHANNELID, T2.GAMEID;
      COMMIT;

      ---------------------------------------------------FACT_100197_BACK_USER_MONTH----------------------------------------------------------------------------------
      V_ERRPOSITION := '1-11';
      DELETE FROM FACT_100197_BACK_USER_MONTH T
       WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM');
      COMMIT;

      V_ERRPOSITION := '1-12';
      INSERT INTO FACT_100197_BACK_USER_MONTH
        (STATDATE,
         CHANNELID,
         SERVERID,
         APPID,
         BACK_CONN,
         BACK_PAY,
         LOADDATE,
         DATA_SOURCE)
        SELECT CONNDATE,
               T2.CHANNELID,
               T2.SERVERID,
               T2.GAMEID,
               COUNT(T1.USERID) BACK_CONN,
               COUNT(T3.USERID) BACK_PAY,
               SYSDATE,
               V_ERRSOURCE
          FROM (SELECT TLM.CHANNELID,
                       TLM.SERVERID,
                       TLM.APPID,
                       TLM.USERID,
                       MAX(TLM.STATDATE) LOST_DAY --�����������
                  FROM T_100197_LOST_USER TLM
                 WHERE TLM.LOST_DATE =
                       TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE, 'MM') - 1,
                               'YYYY-MM-DD')
                 GROUP BY TLM.CHANNELID, TLM.SERVERID, TLM.APPID, TLM.USERID) T1
         INNER JOIN (SELECT DISTINCT TO_CHAR(SYSDATE - V_INPUTDATE,
                                             'YYYY-MM') CONNDATE,
                                     TCM.CHANNELID,
                                     TCM.SERVERID,
                                     TCM.GAMEID,
                                     TCM.ACCOUNTID DVID
                       FROM T_100197_CONN TCM
                      WHERE TCM.CONNDATE >=
                            TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE, 'MM'),
                                    'YYYY-MM-DD')
                        AND TCM.CONNDATE <
                            TO_CHAR(TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE,
                                                     1),
                                          'MM'),
                                    'YYYY-MM-DD')) T2
            ON T1.CHANNELID = T2.CHANNELID
           AND T1.SERVERID = T2.SERVERID
           AND T1.USERID = T2.DVID
        /*
        AND TO_DATE(T2.CONNDATE, 'YYYY-MM-DD') -
            TO_DATE(T1.LOST_DAY, 'YYYY-MM-DD') > 30*/
          LEFT JOIN (SELECT TLM.CHANNELID,
                            TLM.SERVERID,
                            TLM.APPID,
                            TLM.USERID,
                            MAX(TLM.STATDATE) LOST_DAY
                       FROM T_100197_LOST_USER TLM
                      WHERE TLM.ISPAY = '1'
                        AND TLM.LOST_DATE =
                            TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE, 'MM') - 1,
                                    'YYYY-MM-DD')
                      GROUP BY TLM.CHANNELID,
                               TLM.SERVERID,
                               TLM.APPID,
                               TLM.USERID) T3
            ON T3.CHANNELID = T2.CHANNELID
           AND T3.SERVERID = T2.SERVERID
           AND T3.USERID = T2.DVID
        /*
        AND TO_DATE(T2.CONNDATE, 'YYYY-MM-DD') -
            TO_DATE(T3.LOST_DAY, 'YYYY-MM-DD') > 30*/
         GROUP BY T2.CONNDATE, T2.CHANNELID, T2.SERVERID, T2.GAMEID;
      COMMIT;

      V_ERRPOSITION := '1-12-1';
      --ALLSERVER
      INSERT INTO FACT_100197_BACK_USER_MONTH
        (STATDATE,
         CHANNELID,
         SERVERID,
         APPID,
         BACK_CONN,
         BACK_PAY,
         LOADDATE,
         DATA_SOURCE)
        SELECT CONNDATE,
               T2.CHANNELID,
               LOWER('all'),
               T2.GAMEID,
               COUNT(T1.USERID) BACK_CONN,
               COUNT(T3.USERID) BACK_PAY,
               SYSDATE,
               V_ERRSOURCE
          FROM (SELECT TLM.CHANNELID,
                       TLM.APPID,
                       TLM.USERID,
                       MAX(TLM.STATDATE) LOST_DAY --�����������
                  FROM T_100197_LOST_USER_AS TLM
                 WHERE TLM.LOST_DATE =
                       TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE, 'MM') - 1,
                               'YYYY-MM-DD')
                 GROUP BY TLM.CHANNELID, TLM.APPID, TLM.USERID) T1
         INNER JOIN (SELECT DISTINCT TO_CHAR(SYSDATE - V_INPUTDATE,
                                             'YYYY-MM') CONNDATE,
                                     TCM.CHANNELID,
                                     TCM.GAMEID,
                                     TCM.ACCOUNTID DVID
                       FROM T_100197_CONN TCM
                      WHERE TCM.CONNDATE >=
                            TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE, 'MM'),
                                    'YYYY-MM-DD')
                        AND TCM.CONNDATE <
                            TO_CHAR(TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE,
                                                     1),
                                          'MM'),
                                    'YYYY-MM-DD')) T2
            ON T1.CHANNELID = T2.CHANNELID
           AND T1.USERID = T2.DVID
        /*
        AND TO_DATE(T2.CONNDATE, 'YYYY-MM-DD') -
            TO_DATE(T1.LOST_DAY, 'YYYY-MM-DD') > 30*/
          LEFT JOIN (SELECT TLM.CHANNELID,
                            TLM.APPID,
                            TLM.USERID,
                            MAX(TLM.STATDATE) LOST_DAY
                       FROM T_100197_LOST_USER_AS TLM
                      WHERE TLM.ISPAY = '1'
                        AND TLM.LOST_DATE =
                            TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE, 'MM') - 1,
                                    'YYYY-MM-DD')
                      GROUP BY TLM.CHANNELID, TLM.APPID, TLM.USERID) T3
            ON T3.CHANNELID = T2.CHANNELID
           AND T3.USERID = T2.DVID
        /*
        AND TO_DATE(T2.CONNDATE, 'YYYY-MM-DD') -
            TO_DATE(T3.LOST_DAY, 'YYYY-MM-DD') > 30*/
         GROUP BY T2.CONNDATE, T2.CHANNELID, T2.GAMEID;
      COMMIT;
    END IF;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_100197_BACK_MAC��FACT_100197_BACK_USER��
      FACT_100197_BACK_MAC_WEEK��FACT_100197_BACK_USER_WEEK��FACT_100197_BACK_MAC_MONTH��
      FACT_100197_BACK_USER_MONTH';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_MISS_FIRST����***************************************************************/
  --����FACT_MISS_FIRST����
  PROCEDURE P_FACT_MISS_FIRST(P_LOGTIME IN VARCHAR2,
                              P_ERRCODE OUT NUMBER,
                              P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;

    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_MISS_FIRST';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    V_ERRPOSITION := '1-1';
    DELETE FROM FACT_100197_MISS_FIRST T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    --�״ν�������ؿ�����
    V_ERRPOSITION := '1-2';
    INSERT INTO FACT_100197_MISS_FIRST
      SELECT T.STATDATE,
             T.CHANNELID,
             T.SERVERID,
             T.APPID,
             T.VERSIONID,
             T.MISSIONID,
             T.ROLELEVEL,
             T.ROLEJOB,
             SUM(DECODE(T.ISSUCC, '1', 1, 0)) FIRSTENTER_SUCC,
             SUM(DECODE(T.ISSUCC, '0', 1, 0)) FIRSTENTER_FAIL,
             SYSDATE,
             V_ERRSOURCE
        FROM T_100197_MISS_FIRST T
       WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
       GROUP BY T.STATDATE,
                T.CHANNELID,
                T.SERVERID,
                T.APPID,
                T.VERSIONID,
                T.MISSIONID,
                T.ROLELEVEL,
                T.ROLEJOB;
    COMMIT;

    V_ERRPOSITION := '1-3';
    --ALLSERVER
    INSERT INTO FACT_100197_MISS_FIRST
      SELECT T.STATDATE,
             T.CHANNELID,
             LOWER('all'),
             T.APPID,
             T.VERSIONID,
             T.MISSIONID,
             T.ROLELEVEL,
             T.ROLEJOB,
             SUM(DECODE(T.ISSUCC, '1', 1, 0)) FIRSTENTER_SUCC,
             SUM(DECODE(T.ISSUCC, '0', 1, 0)) FIRSTENTER_FAIL,
             SYSDATE,
             V_ERRSOURCE
        FROM T_100197_MISS_FIRST T
       WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
       GROUP BY T.STATDATE,
                T.CHANNELID,
                T.APPID,
                T.VERSIONID,
                T.MISSIONID,
                T.ROLELEVEL,
                T.ROLEJOB;
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_100197_MISS_FIRST';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_DVID����***************************************************************/
  --����FACT_DVID����
  PROCEDURE P_FACT_DVID(P_LOGTIME IN VARCHAR2,
                        P_ERRCODE OUT NUMBER,
                        P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;

    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_DVID';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    V_ERRPOSITION := '1-1';
    DELETE FROM FACT_100197_DVID T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    --�豸����
    V_ERRPOSITION := '1-2';
    INSERT INTO FACT_100197_DVID
      SELECT T3.CONNDATE,
             T3.CHANNELID,
             T3.SERVERID,
             T3.GAMEID,
             T3.GAMEVERSION,
             T1.DTN,
             T1.SCREENRESOLUTION,
             T1.OS,
             COUNT(T2.DVID) NEWCOUNT,
             COUNT(T3.DVID) CONNCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TCM.CONNDATE,
                     TCM.CHANNELID,
                     TCM.SERVERID,
                     TCM.GAMEID,
                     TCM.GAMEVERSION,
                     TCM.DVID
                FROM T_100197_CONN_MAC TCM
               WHERE TCM.CONNDATE =
                     TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')) T3
        LEFT JOIN (SELECT TO_CHAR(TDD.F_LOGTIME, 'YYYY-MM-DD') STATDATE,
                          TDD.DVID,
                          TDD.OS || MIN(TDD.OSVERSION) OS,
                          MIN(TDD.SCREENRESOLUTION) SCREENRESOLUTION,
                          TDD.BRANDNAME || '/' || TDD.DTN DTN
                     FROM T_DW_100197_DEVICE TDD
                    WHERE TDD.F_LOGTIME >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TDD.F_LOGTIME < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TDD.F_LOGTIME, 'YYYY-MM-DD'),
                             TDD.DVID,
                             TDD.OS,
                             TDD.DTN,
                             TDD.BRANDNAME) T1
          ON T1.STATDATE = T3.CONNDATE
         AND T1.DVID = T3.DVID
        LEFT JOIN (SELECT TO_CHAR(TNM.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TNM.CHANNELID,
                          TNM.SERVERID,
                          TNM.GAMEID,
                          TNM.GAMEVERSION,
                          TNM.DVID
                     FROM T_100197_NU_MAC TNM
                    WHERE TNM.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TNM.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)) T2
          ON T3.CONNDATE = T2.STATDATE
         AND T3.DVID = T2.DVID
       GROUP BY T3.CONNDATE,
                T3.CHANNELID,
                T3.SERVERID,
                T3.GAMEID,
                T3.GAMEVERSION,
                T1.DTN,
                T1.SCREENRESOLUTION,
                T1.OS;
    COMMIT;

    V_ERRPOSITION := '1-3';
    --ALLSERVER
    INSERT INTO FACT_100197_DVID
      SELECT T3.CONNDATE,
             T3.CHANNELID,
             LOWER('all'),
             T3.GAMEID,
             T3.GAMEVERSION,
             T1.DTN,
             T1.SCREENRESOLUTION,
             T1.OS,
             COUNT(T2.DVID) NEWCOUNT,
             COUNT(T3.DVID) CONNCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT DISTINCT TCM.CONNDATE,
                              TCM.CHANNELID,
                              TCM.GAMEID,
                              TCM.GAMEVERSION,
                              TCM.DVID
                FROM T_100197_CONN_MAC TCM
               WHERE TCM.CONNDATE =
                     TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')) T3
        LEFT JOIN (SELECT TO_CHAR(TDD.F_LOGTIME, 'YYYY-MM-DD') STATDATE,
                          TDD.DVID,
                          TDD.OS || MIN(TDD.OSVERSION) OS,
                          MIN(TDD.SCREENRESOLUTION) SCREENRESOLUTION,
                          TDD.BRANDNAME || '/' || TDD.DTN DTN
                     FROM T_DW_100197_DEVICE TDD
                    WHERE TDD.F_LOGTIME >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TDD.F_LOGTIME < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY TO_CHAR(TDD.F_LOGTIME, 'YYYY-MM-DD'),
                             TDD.DVID,
                             TDD.OS,
                             TDD.DTN,
                             TDD.BRANDNAME) T1
          ON T1.STATDATE = T3.CONNDATE
         AND T1.DVID = T3.DVID
        LEFT JOIN (SELECT TO_CHAR(TNM.THEDATE, 'YYYY-MM-DD') STATDATE,
                          TNM.CHANNELID,
                          TNM.GAMEID,
                          TNM.GAMEVERSION,
                          TNM.DVID
                     FROM T_100197_NU_MAC_ALLSERVER TNM
                    WHERE TNM.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                      AND TNM.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)) T2
          ON T3.CONNDATE = T2.STATDATE
         AND T3.DVID = T2.DVID
       GROUP BY T3.CONNDATE,
                T3.CHANNELID,
                T3.GAMEID,
                T3.GAMEVERSION,
                T1.DTN,
                T1.SCREENRESOLUTION,
                T1.OS;
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_100197_DVID';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_VC����***************************************************************/
  --����FACT_VC����
  PROCEDURE P_FACT_VC(P_LOGTIME IN VARCHAR2,
                      P_ERRCODE OUT NUMBER,
                      P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;

    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_VC';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    V_ERRPOSITION := '1-1';
    DELETE FROM FACT_100197_VC T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    V_ERRPOSITION := '1-2';
    INSERT INTO FACT_100197_VC
      SELECT TO_CHAR(TDC.F_LOGTIME, 'YYYY-MM-DD') STATDATE,
             TDC.CHANNELID,
             NVL(TDC.SERVERID, 0) SERVERID,
             TDC.APPID,
             NVL(TDC.GAMEVERSION, 0) GAMEVERSION,
             TDC.VCTYPE,
             '2', --����
             '0', --ʹ�÷�ʽ����
             SUM(TDC.INUMBER * TDC.PRICEINVC) VCAMOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM T_DW_100197_CONSUME TDC
       WHERE TDC.F_LOGTIME >= TRUNC(SYSDATE - V_INPUTDATE)
         AND TDC.F_LOGTIME < TRUNC(SYSDATE - V_INPUTDATE + 1)
         AND TDC.LOGTYPE = 'PURCHASE'
       GROUP BY TO_CHAR(TDC.F_LOGTIME, 'YYYY-MM-DD'),
                TDC.CHANNELID,
                TDC.SERVERID,
                TDC.APPID,
                TDC.GAMEVERSION,
                TDC.VCTYPE;
    COMMIT;

    V_ERRPOSITION := '1-3';
    --ALLSERVER
    INSERT INTO FACT_100197_VC
      SELECT TO_CHAR(TDC.F_LOGTIME, 'YYYY-MM-DD') STATDATE,
             TDC.CHANNELID,
             LOWER('all'),
             TDC.APPID,
             NVL(TDC.GAMEVERSION, 0) GAMEVERSION,
             TDC.VCTYPE,
             '2', --����
             '0', --ʹ�÷�ʽ����
             SUM(TDC.INUMBER * TDC.PRICEINVC) VCAMOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM T_DW_100197_CONSUME TDC
       WHERE TDC.F_LOGTIME >= TRUNC(SYSDATE - V_INPUTDATE)
         AND TDC.F_LOGTIME < TRUNC(SYSDATE - V_INPUTDATE + 1)
         AND TDC.LOGTYPE = 'PURCHASE'
       GROUP BY TO_CHAR(TDC.F_LOGTIME, 'YYYY-MM-DD'),
                TDC.CHANNELID,
                TDC.APPID,
                TDC.GAMEVERSION,
                TDC.VCTYPE;
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_100197_VC';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_NET����***************************************************************/
  --����FACT_NET����
  PROCEDURE P_FACT_NET(P_LOGTIME IN VARCHAR2,
                       P_ERRCODE OUT NUMBER,
                       P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;

    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_NET';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    V_ERRPOSITION := '1-1';
    DELETE FROM FACT_100197_NET T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    --������ʽ����
    V_ERRPOSITION := '1-2';
    INSERT INTO FACT_100197_NET
      SELECT T1.STATDATE,
             T2.CHANNELID,
             T2.SERVERID,
             T2.GAMEID,
             T2.GAMEVERSION,
             T1.NET,
             COUNT(T2.DVID) CONNCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT DISTINCT TO_CHAR(TDD.F_LOGTIME, 'YYYY-MM-DD') STATDATE,
                              TDD.DVID,
                              TDD.NET
                FROM T_DW_100197_DEVICE TDD
               WHERE TDD.F_LOGTIME >= TRUNC(SYSDATE - V_INPUTDATE)
                 AND TDD.F_LOGTIME < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TO_CHAR(TDD.F_LOGTIME, 'YYYY-MM-DD'),
                        TDD.DVID,
                        TDD.NET) T1
       RIGHT JOIN (SELECT TCM.CONNDATE,
                          TCM.CHANNELID,
                          TCM.SERVERID,
                          TCM.GAMEID,
                          TCM.GAMEVERSION,
                          TCM.DVID
                     FROM T_100197_CONN_MAC TCM
                    WHERE TCM.CONNDATE =
                          TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')) T2
          ON T1.STATDATE = T2.CONNDATE
         AND T1.DVID = T2.DVID
       WHERE T1.DVID IS NOT NULL
       GROUP BY T1.STATDATE,
                T2.CHANNELID,
                T2.SERVERID,
                T2.GAMEID,
                T2.GAMEVERSION,
                T1.NET;
    COMMIT;

    V_ERRPOSITION := '1-3';
    --ALLSERVER
    INSERT INTO FACT_100197_NET
      SELECT T1.STATDATE,
             T2.CHANNELID,
             LOWER('all'),
             T2.GAMEID,
             T2.GAMEVERSION,
             T1.NET,
             COUNT(T2.DVID) CONNCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT DISTINCT TO_CHAR(TDD.F_LOGTIME, 'YYYY-MM-DD') STATDATE,
                              TDD.DVID,
                              TDD.NET
                FROM T_DW_100197_DEVICE TDD
               WHERE TDD.F_LOGTIME >= TRUNC(SYSDATE - V_INPUTDATE)
                 AND TDD.F_LOGTIME < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TO_CHAR(TDD.F_LOGTIME, 'YYYY-MM-DD'),
                        TDD.DVID,
                        TDD.NET) T1
       RIGHT JOIN (SELECT DISTINCT TCM.CONNDATE,
                                   TCM.CHANNELID,
                                   TCM.GAMEID,
                                   TCM.GAMEVERSION,
                                   TCM.DVID
                     FROM T_100197_CONN_MAC TCM
                    WHERE TCM.CONNDATE =
                          TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')) T2
          ON T1.STATDATE = T2.CONNDATE
         AND T1.DVID = T2.DVID
       WHERE T1.DVID IS NOT NULL
       GROUP BY T1.STATDATE,
                T2.CHANNELID,
                T2.GAMEID,
                T2.GAMEVERSION,
                T1.NET;
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_100197_NET';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_OPERATOR����***************************************************************/
  --����FACT_OPERATOR����
  PROCEDURE P_FACT_OPERATOR(P_LOGTIME IN VARCHAR2,
                            P_ERRCODE OUT NUMBER,
                            P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;

    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_OPERATOR';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    V_ERRPOSITION := '1-1';
    DELETE FROM FACT_100197_OPERATOR T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    --��Ӫ�̷���
    V_ERRPOSITION := '1-2';
    INSERT INTO FACT_100197_OPERATOR
      SELECT T1.STATDATE,
             T2.CHANNELID,
             T2.SERVERID,
             T2.GAMEID,
             T2.GAMEVERSION,
             T1.SERVICEPROVIDER,
             COUNT(T2.DVID) CONNCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT DISTINCT TO_CHAR(TDD.F_LOGTIME, 'YYYY-MM-DD') STATDATE,
                              TDD.DVID,
                              TDD.SERVICEPROVIDER
                FROM T_DW_100197_DEVICE TDD
               WHERE TDD.F_LOGTIME >= TRUNC(SYSDATE - V_INPUTDATE)
                 AND TDD.F_LOGTIME < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TO_CHAR(TDD.F_LOGTIME, 'YYYY-MM-DD'),
                        TDD.DVID,
                        TDD.SERVICEPROVIDER) T1
       RIGHT JOIN (SELECT TCM.CONNDATE,
                          TCM.CHANNELID,
                          TCM.SERVERID,
                          TCM.GAMEID,
                          TCM.GAMEVERSION,
                          TCM.DVID
                     FROM T_100197_CONN_MAC TCM
                    WHERE TCM.CONNDATE =
                          TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')) T2
          ON T1.STATDATE = T2.CONNDATE
         AND T1.DVID = T2.DVID
       WHERE T1.DVID IS NOT NULL
       GROUP BY T1.STATDATE,
                T2.CHANNELID,
                T2.SERVERID,
                T2.GAMEID,
                T2.GAMEVERSION,
                T1.SERVICEPROVIDER;
    COMMIT;

    V_ERRPOSITION := '1-3';
    --ALLSERVER
    INSERT INTO FACT_100197_OPERATOR
      SELECT T1.STATDATE,
             T2.CHANNELID,
             LOWER('all'),
             T2.GAMEID,
             T2.GAMEVERSION,
             T1.SERVICEPROVIDER,
             COUNT(T2.DVID) CONNCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT DISTINCT TO_CHAR(TDD.F_LOGTIME, 'YYYY-MM-DD') STATDATE,
                              TDD.DVID,
                              TDD.SERVICEPROVIDER
                FROM T_DW_100197_DEVICE TDD
               WHERE TDD.F_LOGTIME >= TRUNC(SYSDATE - V_INPUTDATE)
                 AND TDD.F_LOGTIME < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TO_CHAR(TDD.F_LOGTIME, 'YYYY-MM-DD'),
                        TDD.DVID,
                        TDD.SERVICEPROVIDER) T1
       RIGHT JOIN (SELECT DISTINCT TCM.CONNDATE,
                                   TCM.CHANNELID,
                                   TCM.GAMEID,
                                   TCM.GAMEVERSION,
                                   TCM.DVID
                     FROM T_100197_CONN_MAC TCM
                    WHERE TCM.CONNDATE =
                          TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')) T2
          ON T1.STATDATE = T2.CONNDATE
         AND T1.DVID = T2.DVID
       WHERE T1.DVID IS NOT NULL
       GROUP BY T1.STATDATE,
                T2.CHANNELID,
                T2.GAMEID,
                T2.GAMEVERSION,
                T1.SERVICEPROVIDER;
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_100197_OPERATOR';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_REGION����***************************************************************/
  --����FACT_REGION����
  PROCEDURE P_FACT_REGION(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;

    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_REGION';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    V_ERRPOSITION := '1-1';
    DELETE FROM FACT_100197_REGION T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    --�������
    V_ERRPOSITION := '1-2';
    INSERT INTO FACT_100197_REGION
      SELECT T.STATDATE,
             T.CHANNELID,
             T.SERVERID,
             T.GAMEID,
             T.GAMEVERSION,
             D.COUNTRYNAME,
             D.PROVINCENAME,
             D.CITYNAME,
             SUM(T.IPCOUNT) NEWCOUNT,
             0,
             0,
             0,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TNM.THEDATE, 'YYYY-MM-DD') STATDATE,
                     TNM.CHANNELID,
                     TNM.SERVERID,
                     TNM.GAMEID,
                     TNM.GAMEVERSION,
                     F_IP_TO_NUM(TNM.POSITION) IPNUM,
                     COUNT(1) IPCOUNT
                FROM T_100197_NU_MAC TNM
               WHERE TNM.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                 AND TNM.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TO_CHAR(TNM.THEDATE, 'YYYY-MM-DD'),
                        TNM.CHANNELID,
                        TNM.SERVERID,
                        TNM.GAMEID,
                        TNM.GAMEVERSION,
                        F_IP_TO_NUM(TNM.POSITION)) T,
             DIM_IP D
       WHERE T.IPNUM BETWEEN D.IPBEGIN AND D.IPEND
       GROUP BY T.STATDATE,
                T.CHANNELID,
                T.SERVERID,
                T.GAMEID,
                T.GAMEVERSION,
                D.COUNTRYNAME,
                D.PROVINCENAME,
                D.CITYNAME;
    COMMIT;

    V_ERRPOSITION := '1-3';
    --ALLSERVER
    INSERT INTO FACT_100197_REGION
      SELECT T.STATDATE,
             T.CHANNELID,
             LOWER('all'),
             T.GAMEID,
             T.GAMEVERSION,
             D.COUNTRYNAME,
             D.PROVINCENAME,
             D.CITYNAME,
             SUM(T.IPCOUNT) NEWCOUNT,
             0,
             0,
             0,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TNM.THEDATE, 'YYYY-MM-DD') STATDATE,
                     TNM.CHANNELID,
                     TNM.GAMEID,
                     TNM.GAMEVERSION,
                     F_IP_TO_NUM(TNM.POSITION) IPNUM,
                     COUNT(1) IPCOUNT
                FROM T_100197_NU_MAC_ALLSERVER TNM
               WHERE TNM.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                 AND TNM.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TO_CHAR(TNM.THEDATE, 'YYYY-MM-DD'),
                        TNM.CHANNELID,
                        TNM.GAMEID,
                        TNM.GAMEVERSION,
                        F_IP_TO_NUM(TNM.POSITION)) T,
             DIM_IP D
       WHERE T.IPNUM BETWEEN D.IPBEGIN AND D.IPEND
       GROUP BY T.STATDATE,
                T.CHANNELID,
                T.GAMEID,
                T.GAMEVERSION,
                D.COUNTRYNAME,
                D.PROVINCENAME,
                D.CITYNAME;
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_100197_REGION';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_SUM_REP����***************************************************************/
  --����FACT_SUM_REP����
  PROCEDURE P_FACT_SUM_REP(P_LOGTIME IN VARCHAR2,
                           P_ERRCODE OUT NUMBER,
                           P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;

    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_SUM_REP';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    V_ERRPOSITION := '1-1';
    DELETE FROM FACT_SUM_REP T
     WHERE /*T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')                                                                                                                                                                                                     AND*/
     UPPER(T.APPID) = UPPER('100197');
    COMMIT;

    --���в�Ʒ���ܱ���
    V_ERRPOSITION := '1-2';
    INSERT INTO FACT_SUM_REP
      SELECT TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD') STATDATE,
             T1.APPID,
             T1.NEWCOUNT NEWCOUNT_USER,
             T3.NEWCOUNT NEWCOUNT_DVID,
             0 CONNCOUNT_USER,
             0 CONNCOUNT_DVID,
             T1.PAYAMOUNT PAYAMOUNT,
             NVL(T6.PAYCOUNT, 0) PAYCOUNT,
             T5.NEW_REMAIN,
             0 FIRST_PAYCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT T.APPID,
                     SUM(T.NEWCOUNT) NEWCOUNT,
                     --SUM(T.CONNCOUNT) CONNCOUNT,
                     SUM(T.PAYAMOUNT) PAYAMOUNT
              --SUM(T.PAYCOUNT) PAYCOUNT
                FROM FACT_100197_GENERAL_DAY T
               WHERE DATATYPE = '1'
                 AND SERVERID = LOWER('all')
                 AND STATDATE < TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
               GROUP BY T.APPID) T1
       INNER JOIN (SELECT T.APPID, SUM(T.NEWCOUNT) NEWCOUNT
                   --SUM(T.CONNCOUNT) CONNCOUNT
                     FROM FACT_100197_GENERAL_DAY T
                    WHERE DATATYPE = '2'
                      AND SERVERID = LOWER('all')
                      AND STATDATE <
                          TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                    GROUP BY T.APPID) T3
          ON T1.APPID = T3.APPID
        LEFT JOIN (SELECT T.APPID, SUM(T.NEW_REMAIN) NEW_REMAIN
                     FROM FACT_100197_REMAIN_USER T
                    WHERE T.REMAIN_DAYS = 1
                      AND SERVERID = LOWER('all')
                      AND STATDATE <
                          TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                    GROUP BY T.APPID) T5
          ON T1.APPID = T5.APPID
        LEFT JOIN (SELECT T.GAMEID APPID,
                          COUNT(DISTINCT T.ACCOUNTID) PAYCOUNT
                     FROM T_100197_NU_PAY T
                    WHERE T.FIRSTPAYDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
                    GROUP BY T.GAMEID) T6
          ON T1.APPID = T6.APPID;
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_SUM_REP';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_GENERAL_DAY_DVID����***************************************************************/
  --����FACT_GENERAL_DAY_DVID����
  PROCEDURE P_FACT_GENERAL_DVID(P_LOGTIME IN VARCHAR2,
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
    V_WEEKFIRSTDAY VARCHAR2(10); --���������ҳ� ������������ܵĵ�һ��
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;

    --�ܵ�һ��ļ��㷽�� TRUNC(SYSDATE)-(TO_CHAR(SYSDATE-1, 'D')-1)����������һ�ǵ�һ��
    --��ȡ�ܵ�һ��
    SELECT TO_CHAR(TRUNC(SYSDATE - V_INPUTDATE + 1) -
                   DECODE((TO_CHAR(SYSDATE - V_INPUTDATE, 'D') - 1),
                          0,
                          7,
                          (TO_CHAR(SYSDATE - V_INPUTDATE, 'D') - 1)),
                   'YYYY-MM-DD')
      INTO V_WEEKFIRSTDAY
      FROM DUAL;

    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_GENERAL_DVID';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    V_ERRPOSITION := '1-1';
    DELETE FROM FACT_100197_GENERAL_DAY_DVID T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    --���豸��������
    V_ERRPOSITION := '1-2';
    INSERT INTO FACT_100197_GENERAL_DAY_DVID
      SELECT T2.THEDATE STATDATE,
             T2.CHANNELID CHANNELID,
             T2.GAMEID APPID,
             NVL(T1.NEWCOUNT, 0),
             T2.CONNCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TN.THEDATE, 'YYYY-MM-DD') THEDATE,
                     TN.CHANNELID,
                     TN.GAMEID,
                     COUNT(1) NEWCOUNT
                FROM T_100197_NU_DVID TN
               WHERE TN.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE)
                 AND TN.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TO_CHAR(TN.THEDATE, 'YYYY-MM-DD'),
                        TN.CHANNELID,
                        TN.GAMEID) T1
       RIGHT JOIN (SELECT TC.CONNDATE THEDATE,
                          TC.CHANNELID,
                          TC.GAMEID,
                          COUNT(DISTINCT TC.DVID) CONNCOUNT
                     FROM T_100197_CONN_DVID TC
                    WHERE TC.CONNDATE =
                          TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
                    GROUP BY TC.CONNDATE, TC.CHANNELID, TC.GAMEID) T2
          ON T1.THEDATE = T2.THEDATE
         AND T1.CHANNELID = T2.CHANNELID;
    COMMIT;

    V_ERRPOSITION := '1-3';
    DELETE FROM FACT_100197_GENERAL_WEEK_DVID T
     WHERE T.STATDATE = V_WEEKFIRSTDAY;
    COMMIT;

    --���豸��������
    V_ERRPOSITION := '1-4';
    --�豸��������
    INSERT INTO FACT_100197_GENERAL_WEEK_DVID
      SELECT T2.THEDATE STATDATE,
             T2.CHANNELID CHANNELID,
             T2.GAMEID APPID,
             NVL(T1.NEWCOUNT, 0),
             T2.CONNCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT V_WEEKFIRSTDAY THEDATE,
                     TN.CHANNELID,
                     TN.GAMEID,
                     COUNT(1) NEWCOUNT
                FROM T_100197_NU_DVID TN
               WHERE TN.THEDATE >= TO_DATE(V_WEEKFIRSTDAY, 'YYYY-MM-DD')
                 AND TN.THEDATE < TRUNC(SYSDATE - V_INPUTDATE + 1)
               GROUP BY TN.CHANNELID, TN.GAMEID) T1
       RIGHT JOIN (SELECT V_WEEKFIRSTDAY THEDATE,
                          TC.CHANNELID,
                          TC.GAMEID,
                          COUNT(DISTINCT TC.DVID) CONNCOUNT
                     FROM T_100197_CONN_DVID TC
                    WHERE TC.CONNDATE >= V_WEEKFIRSTDAY
                      AND TC.CONNDATE <
                          TO_CHAR(SYSDATE - V_INPUTDATE + 1, 'YYYY-MM-DD')
                    GROUP BY TC.CHANNELID, TC.GAMEID) T2
          ON T1.THEDATE = T2.THEDATE
         AND T1.CHANNELID = T2.CHANNELID;
    COMMIT;

    V_ERRPOSITION := '1-5';
    DELETE FROM FACT_100197_GENERAL_MONTH_DVID T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM');
    COMMIT;

    --���豸��������
    V_ERRPOSITION := '1-6';
    --�豸��������
    INSERT INTO FACT_100197_GENERAL_MONTH_DVID
      SELECT T2.THEDATE STATDATE,
             T2.CHANNELID CHANNELID,
             T2.GAMEID APPID,
             NVL(T1.NEWCOUNT, 0),
             T2.CONNCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TN.THEDATE, 'YYYY-MM') THEDATE,
                     TN.CHANNELID,
                     TN.GAMEID,
                     COUNT(1) NEWCOUNT
                FROM T_100197_NU_MAC TN
               WHERE TN.THEDATE >= TRUNC(SYSDATE - V_INPUTDATE, 'MM')
                 AND TN.THEDATE <
                     TRUNC(ADD_MONTHS(SYSDATE - V_INPUTDATE, 1), 'MM')
               GROUP BY TO_CHAR(TN.THEDATE, 'YYYY-MM'),
                        TN.CHANNELID,
                        TN.GAMEID) T1
       RIGHT JOIN (SELECT SUBSTR(TC.CONNDATE, 0, 7) THEDATE,
                          TC.CHANNELID,
                          TC.GAMEID,
                          COUNT(DISTINCT TC.DVID) CONNCOUNT
                     FROM T_100197_CONN_DVID TC
                    WHERE TC.CONNDATE >=
                          TO_CHAR(TRUNC(SYSDATE - 16, 'MM'), 'YYYY-MM-DD')
                      AND TC.CONNDATE <=
                          TO_CHAR(LAST_DAY(SYSDATE - 16), 'YYYY-MM-DD')
                    GROUP BY SUBSTR(TC.CONNDATE, 0, 7),
                             TC.CHANNELID,
                             TC.GAMEID) T2
          ON T1.THEDATE = T2.THEDATE
         AND T1.CHANNELID = T2.CHANNELID;
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_GENERAL_DAY_DVID��FACT_100197_GENERAL_WEEK_DVID��FACT_100197_GENERAL_MONTH_DVID';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_GENERAL_HOUR_DVID����***************************************************************/
  --����FACT_GENERAL_HOUR_DVID����
  PROCEDURE P_FACT_GENERAL_HOUR_DVID(P_LOGTIME IN VARCHAR2,
                                     P_ERRCODE OUT NUMBER,
                                     P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'), 'HH24')
      INTO V_INPUTDATE
      FROM DUAL;

    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_GENERAL_HOUR_DVID';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    V_ERRPOSITION := '1-1';
    DELETE FROM FACT_100197_GENERAL_HOUR_DVID T
     WHERE T.STATDATE =
           TO_CHAR(TRUNC(SYSDATE) - V_INPUTDATE, 'YYYY-MM-DD HH24');
    COMMIT;

    --Сʱ�豸��������
    V_ERRPOSITION := '1-2';
    --�豸��������
    INSERT INTO FACT_100197_GENERAL_HOUR_DVID
      SELECT T2.THEDATE STATDATE,
             T2.CHANNELID CHANNELID,
             T2.GAMEID APPID,
             NVL(T1.NEWCOUNT, 0),
             T2.CONNCOUNT,
             SYSDATE,
             V_ERRSOURCE
        FROM (SELECT TO_CHAR(TN.THEDATE, 'YYYY-MM-DD HH24') THEDATE,
                     TN.CHANNELID,
                     TN.GAMEID,
                     COUNT(1) NEWCOUNT
                FROM T_100197_NU_DVID TN
               WHERE TN.THEDATE >= TRUNC(SYSDATE) + V_INPUTDATE
                 AND TN.THEDATE < TRUNC(SYSDATE) - V_INPUTDATE + 1 / 24
               GROUP BY TO_CHAR(TN.THEDATE, 'YYYY-MM-DD HH24'),
                        TN.CHANNELID,
                        TN.GAMEID) T1
       RIGHT JOIN (SELECT TO_CHAR(TDL.F_LOGTIME, 'YYYY-MM-DD HH24') THEDATE,
                          TDL.CHANNELID,
                          '100197' GAMEID,
                          COUNT(DISTINCT TDL.DVID) CONNCOUNT
                     FROM T_DW_100197_DEVICE TDL
                    WHERE TDL.F_LOGTIME >= TRUNC(SYSDATE) - V_INPUTDATE
                      AND TDL.F_LOGTIME <
                          TRUNC(SYSDATE) - V_INPUTDATE + 1 / 24
                    GROUP BY TO_CHAR(TDL.F_LOGTIME, 'YYYY-MM-DD HH24'),
                             TDL.CHANNELID) T2
          ON T1.THEDATE = T2.THEDATE
         AND T1.CHANNELID = T2.CHANNELID;
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_100197_GENERAL_HOUR_DVID';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_CEVENT����***************************************************************/
  --����FACT_CEVENT����
  PROCEDURE P_FACT_CEVENT(P_LOGTIME IN VARCHAR2,
                          P_ERRCODE OUT NUMBER,
                          P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;

    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_CEVENT';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    V_ERRPOSITION := '1-1';
    DELETE FROM FACT_100197_CEVENT T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    --�Զ������
    V_ERRPOSITION := '1-2';
    INSERT INTO FACT_100197_CEVENT
      SELECT TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD') STATDATE,
             T.CHANNELID,
             NVL(T.SERVERID, 0),
             T.APPID,
             NVL(T.GAMEVERSION, 0),
             T.EVENTKEY,
             COUNT(DISTINCT T.ACCOUNTID),
             COUNT(1),
             SYSDATE,
             V_ERRSOURCE
        FROM T_DW_100197_CEVENT T
       WHERE T.F_LOGTIME >= TRUNC(SYSDATE - V_INPUTDATE)
         AND T.F_LOGTIME < TRUNC(SYSDATE - V_INPUTDATE + 1)
       GROUP BY TO_CHAR(T.F_LOGTIME, 'YYYY-MM-DD'),
                T.CHANNELID,
                T.SERVERID,
                T.APPID,
                T.GAMEVERSION,
                T.EVENTKEY;
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_100197_CEVENT';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_COMP_CEVENT����***************************************************************/
  --����FACT_COMP_CEVENT����
  PROCEDURE P_FACT_COMP_CEVENT(P_LOGTIME IN VARCHAR2,
                               P_ERRCODE OUT NUMBER,
                               P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
    --�����¼���ϲ���ά������
    CURSOR CUR IS
      SELECT * FROM DIM_COMP_CEVENT T WHERE T.APPID = '100197';

    V_SQL     VARCHAR2(2000);
    V_L       NUMBER;
    V_START_I NUMBER := 1;
    V_END_I   NUMBER;
    V_PAR1    VARCHAR2(2000);
    V_PAR2    VARCHAR2(2000);
    V_PAR3    VARCHAR2(2000);
    V_PAR4    VARCHAR2(2000);
    V_ERR     VARCHAR2(2000);
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;

    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_COMP_CEVENT';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    V_ERRPOSITION := '1-1';
    DELETE FROM FACT_100197_COMP_CEVENT T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    --�Զ����¼���Ϸ���
    V_ERRPOSITION := '1-2';
    FOR C IN CUR LOOP
      BEGIN
        V_SQL  := 'INSERT INTO FACT_100197_COMP_CEVENT SELECT D.THEDATE,D.APPID,D.CHANNELID,D.GAMEVERSION,D.SERVERID,D.ILEVEL,D.EVENTKEY,''' ||
                  C.COMPID || ''',''' || C.CALTYPE || ''',';
        V_PAR2 := '';
        V_PAR3 := '';
        V_PAR4 := '';
        V_L    := LENGTH(C.DIMPARS) - LENGTH(REPLACE(C.DIMPARS, ',')) + 1;
        --DBMS_OUTPUT.PUT_LINE(V_L);
        FOR I IN 1 .. V_L LOOP
          V_END_I := INSTR(C.DIMPARS, ',', 1, I);
          IF I = V_L THEN
            V_PAR1 := SUBSTR(C.DIMPARS, V_START_I);
          ELSE
            V_PAR1 := SUBSTR(C.DIMPARS, V_START_I, V_END_I - V_START_I);
          END IF;
          --DBMS_OUTPUT.PUT_LINE(V_PAR1);
          IF I = 1 THEN
            V_SQL := V_SQL || 'D.' || V_PAR1;
          ELSE
            V_SQL := V_SQL || '||'',''||D.' || V_PAR1;
          END IF;
          V_PAR2 := V_PAR2 || ',MAX(DECODE(T.EVENTVALUE_KEY, ''' || V_PAR1 ||
                    ''', T.EVENTVALUE_VALUE,NULL)) ' || V_PAR1;
          IF I = 1 THEN
            V_PAR3 := V_PAR3 || '''' || V_PAR1 || '''';
          ELSE
            V_PAR3 := V_PAR3 || ',''' || V_PAR1 || '''';
          END IF;
          V_PAR4    := V_PAR4 || ',D.' || V_PAR1;
          V_START_I := V_END_I + 1;
        END LOOP;

        IF C.CALTYPE = 'COUNT_DISTINCT' THEN
          V_SQL := V_SQL || ',COUNT(DISTINCT D.' || C.CALPARS || ') ' ||
                   C.CALTYPE;
        END IF;
        IF C.CALTYPE = 'SUM' THEN
          V_SQL := V_SQL || ',SUM(D.' || C.CALPARS || ') ' || C.CALTYPE;
        END IF;
        IF C.CALTYPE = 'MAX' THEN
          V_SQL := V_SQL || ',MAX(D.' || C.CALPARS || ') ' || C.CALTYPE;
        END IF;
        IF C.CALTYPE = 'MIN' THEN
          V_SQL := V_SQL || ',MIN(D.' || C.CALPARS || ') ' || C.CALTYPE;
        END IF;

        V_SQL := V_SQL || ',SYSDATE,''' || V_ERRSOURCE ||
                 ''' FROM (SELECT T.THEDATE,T.APPID,T.CHANNELID,T.GAMEVERSION, T.ACCOUNTID,T.SERVERID,T.ILEVEL,T.EVENTKEY,T.PREROWID' ||
                 V_PAR2 || ',MAX(DECODE(T.EVENTVALUE_KEY, ''' || C.CALPARS ||
                 ''', T.EVENTVALUE_VALUE,NULL)) ' || C.CALPARS ||
                 ' FROM T_100197_CEVENT T WHERE  T.EVENTVALUE_KEY IN (' ||
                 V_PAR3 || ',''' || C.CALPARS ||
                 ''') AND T.THEDATE = TO_CHAR(SYSDATE - ' || V_INPUTDATE ||
                 ', ''YYYY-MM-DD'')
               GROUP BY T.THEDATE,T.APPID,T.CHANNELID,T.GAMEVERSION,T.ACCOUNTID,T.SERVERID,T.ILEVEL,T.EVENTKEY,T.PREROWID) D
               GROUP BY D.THEDATE,D.APPID,D.CHANNELID,D.GAMEVERSION,D.SERVERID,D.ILEVEL,D.EVENTKEY' ||
                 V_PAR4;
        --DBMS_OUTPUT.PUT_LINE(V_SQL);
        EXECUTE IMMEDIATE V_SQL;
        COMMIT;

      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
          --DBMS_OUTPUT.PUT_LINE(SQLCODE||','||SQLERRM||','||C.COMPID);
          V_ERR := SQLERRM;
          UPDATE DIM_COMP_CEVENT T
             SET T.ERROR_INFO = V_ERR
           WHERE T.APPID = C.APPID
             AND T.COMPID = C.COMPID
             AND T.CALTYPE = C.CALTYPE;
          COMMIT;
      END;

    END LOOP;

    V_ERRPOSITION := '1-3';
    DELETE FROM FACT_100197_CEVENT_PAR T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    --�Զ����������
    V_ERRPOSITION := '1-4';
    INSERT INTO FACT_100197_CEVENT_PAR
      SELECT T.THEDATE,
             T.CHANNELID,
             T.SERVERID,
             T.APPID,
             T.GAMEVERSION,
             T.ILEVEL,
             T.EVENTKEY,
             T.EVENTVALUE_KEY,
             T.EVENTVALUE_VALUE,
             COUNT(DISTINCT T.ACCOUNTID),
             COUNT(1),
             SYSDATE,
             V_ERRSOURCE
        FROM T_100197_CEVENT T
       WHERE T.THEDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
       GROUP BY T.THEDATE,
                T.APPID,
                T.CHANNELID,
                T.GAMEVERSION,
                T.SERVERID,
                T.ILEVEL,
                T.EVENTKEY,
                T.EVENTVALUE_KEY,
                T.EVENTVALUE_VALUE;
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_100197_COMP_CEVENT,FACT_100197_CEVENT_PAR';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

  /******************************************����FACT_DAILY_REPORT����***************************************************************/
  --����FACT_DAILY_REPORT����
  PROCEDURE P_FACT_DAILY_REPORT(P_LOGTIME IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE - 1,
                                                                      'YYYY-MM-DD'),
                                P_ERRCODE OUT NUMBER,
                                P_ERRSTR  OUT VARCHAR2) IS
    V_ERRPOSITION  VARCHAR2(100); --λ��
    V_ERRLOCALINFO VARCHAR2(200); --���ػ���Ϣ
    V_ERRSOURCE    VARCHAR2(100); --��Դ
    V_ERRCODE      VARCHAR2(200); --���ݿ�������
    V_INPUTDATE    NUMBER := 0;
  BEGIN
    P_ERRCODE := 7100;
    SELECT TRUNC(SYSDATE) -
           TRUNC(TO_DATE(P_LOGTIME, 'YYYY-MM-DD HH24:MI:SS'))
      INTO V_INPUTDATE
      FROM DUAL;

    ------------------------------ִ����־��ʼ----------------------------------------------
    V_ERRSOURCE := 'PKG_FACT_100197.P_FACT_DAILY_REPORT';
    PKG_LOG.SP_RUN_LOG_START(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־��ʼ----------------------------------------------

    V_ERRPOSITION := '1-1';
    DELETE FROM FACT_100197_DAILY_REPORT T
     WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD');
    COMMIT;

    --�ձ�����
    DELETE FROM FACT_100197_DAILY_REPORT T
     WHERE T.STATDATE <= TO_CHAR(SYSDATE - 30, 'YYYY-MM-DD');
    COMMIT;

    --ָ��������û���,�����豸��,��Ծ�û���,��Ծ�豸��,�����û���,�����豸��,���ѽ��,�����û���������,�����û�3������,�����û�7������,
    --�����豸��������,�����豸3������,�����豸7������,ʧ�ܸ����û���,�����ɹ���,����ʧ������
    V_ERRPOSITION := '1-2';
    --������ָ������
    INSERT INTO FACT_100197_DAILY_REPORT
      SELECT T.STATDATE,
             T.APPID,
             T.CHANNELID,
             T.SERVERID,
             CASE
               WHEN T.DATATYPE = '1' THEN
                '�����û���'
               ELSE
                '�����豸��'
             END INDEXID,
             '��ָ��' INDTYPE,
             SUM(T.NEWCOUNT) RPT_DATA,
             SYSDATE,
             V_ERRSOURCE
        FROM FACT_100197_GENERAL_DAY T
       WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
       GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
      UNION ALL
      SELECT T.STATDATE,
             T.APPID,
             T.CHANNELID,
             T.SERVERID,
             CASE
               WHEN T.DATATYPE = '1' THEN
                '��Ծ�û���'
               ELSE
                '��Ծ�豸��'
             END INDEXID,
             '��ָ��' INDTYPE,
             SUM(T.CONNCOUNT) RPT_DATA,
             SYSDATE,
             V_ERRSOURCE
        FROM FACT_100197_GENERAL_DAY T
       WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
       GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
      UNION ALL
      SELECT T.STATDATE,
             T.APPID,
             T.CHANNELID,
             T.SERVERID,
             CASE
               WHEN T.DATATYPE = '1' THEN
                '�����û���'
               ELSE
                '�����豸��'
             END INDEXID,
             '��ָ��' INDTYPE,
             SUM(T.PAYCOUNT) RPT_DATA,
             SYSDATE,
             V_ERRSOURCE
        FROM FACT_100197_GENERAL_DAY T
       WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
       GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID, T.DATATYPE
      UNION ALL
      SELECT T.STATDATE,
             T.APPID,
             T.CHANNELID,
             T.SERVERID,
             '���ѽ��' INDEXID,
             '��ָ��' INDTYPE,
             SUM(T.PAYAMOUNT) RPT_DATA,
             SYSDATE,
             V_ERRSOURCE
        FROM FACT_100197_GENERAL_DAY T
       WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
         AND T.DATATYPE = '1'
       GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
      UNION ALL
      SELECT T.STATDATE,
             T.APPID,
             T.CHANNELID,
             T.SERVERID,
             CASE
               WHEN T.REMAIN_DAYS = 1 THEN
                '�����û���������'
               WHEN T.REMAIN_DAYS = 3 THEN
                '�����û�3������'
               ELSE
                '�����û�7������'
             END INDEXID,
             '��ָ��' INDTYPE,
             T.NEW_REMAIN RPT_DATA,
             SYSDATE,
             V_ERRSOURCE
        FROM FACT_100197_REMAIN_USER T
       WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
         AND T.REMAIN_DAYS IN (1, 3, 7)
      UNION ALL
      SELECT T.STATDATE,
             T.APPID,
             T.CHANNELID,
             T.SERVERID,
             CASE
               WHEN T.REMAIN_DAYS = 1 THEN
                '�����豸��������'
               WHEN T.REMAIN_DAYS = 3 THEN
                '�����豸3������'
               ELSE
                '�����豸7������'
             END INDEXID,
             '��ָ��' INDTYPE,
             T.NEW_REMAIN RPT_DATA,
             SYSDATE,
             V_ERRSOURCE
        FROM FACT_100197_REMAIN_MAC T
       WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
         AND T.REMAIN_DAYS IN (1, 3, 7)
      UNION ALL
      SELECT T.STATDATE,
             T.APPID,
             T.CHANNELID,
             T.SERVERID,
             'ʧ�ܸ����û���' INDEXID,
             '��ָ��' INDTYPE,
             SUM(T.PAYFAILCOUNT) RPT_DATA,
             SYSDATE,
             V_ERRSOURCE
        FROM FACT_100197_ORDER T
       WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
         AND T.DATATYPE = '1'
       GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
      UNION ALL
      SELECT T.STATDATE,
             T.APPID,
             T.CHANNELID,
             T.SERVERID,
             '�����ɹ���' INDEXID,
             '��ָ��' INDTYPE,
             SUM(T.PAYSUCCNUM) RPT_DATA,
             SYSDATE,
             V_ERRSOURCE
        FROM FACT_100197_ORDER T
       WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
         AND T.DATATYPE = '1'
       GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID
      UNION ALL
      SELECT T.STATDATE,
             T.APPID,
             T.CHANNELID,
             T.SERVERID,
             '����ʧ����' INDEXID,
             '��ָ��' INDTYPE,
             SUM(T.PAYFAILNUM) RPT_DATA,
             SYSDATE,
             V_ERRSOURCE
        FROM FACT_100197_ORDER T
       WHERE T.STATDATE = TO_CHAR(SYSDATE - V_INPUTDATE, 'YYYY-MM-DD')
         AND T.DATATYPE = '1'
       GROUP BY T.STATDATE, T.APPID, T.CHANNELID, T.SERVERID;
    COMMIT;

    ------------------------------ִ����־����----------------------------------------------
    PKG_LOG.SP_RUN_LOG_END(V_ERRSOURCE, '100197', V_INPUTDATE);
    ------------------------------ִ����־����----------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      P_ERRCODE      := 8100;
      P_ERRSTR       := 'SQLCODE:' || SQLCODE || ' SQLERRM:' || SQLERRM;
      V_ERRLOCALINFO := 'TABLE NAME=FACT_100197_DAILY_REPORT';
      V_ERRCODE      := SUBSTR(SQLERRM, 1, 200);
      PKG_LOG.SP_ERROR_LOG(V_ERRCODE,
                           V_ERRSOURCE,
                           V_ERRLOCALINFO,
                           V_ERRPOSITION,
                           '100197');
      PKG_LOG.SP_RUN_LOG_ERROR(V_ERRSOURCE, '100197', V_INPUTDATE);
      ------------------------------�쳣����----------------------------------------------
  END;

END PKG_FACT_100197;
/


spool off
