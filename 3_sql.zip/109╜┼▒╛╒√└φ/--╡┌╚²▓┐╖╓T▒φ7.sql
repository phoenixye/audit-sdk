------------------------------------------------------------
-- Export file for user DEVELOPER@BI_RACDB1_111.13.20.109 --
-- Created by Administrator on 2015/6/2, 17:31:48 ----------
------------------------------------------------------------

set define off
spool --��������T��7.log

prompt
prompt Creating table T_100228_CEVENT
prompt ==============================
prompt
create table T_100228_CEVENT
(
  thedate          VARCHAR2(10),
  datenum          NUMBER,
  appid            VARCHAR2(10),
  channelid        VARCHAR2(50),
  gameversion      VARCHAR2(50),
  dvid             VARCHAR2(50),
  accountid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  ilevel           NUMBER,
  roleid           VARCHAR2(50),
  eventkey         VARCHAR2(100),
  eventvalue_key   VARCHAR2(100),
  eventvalue_value VARCHAR2(100),
  ipaddr           VARCHAR2(50),
  prerowid         VARCHAR2(200)
)
;
comment on table T_100228_CEVENT
  is '�Զ����¼���ֱ�';
comment on column T_100228_CEVENT.thedate
  is '����';
comment on column T_100228_CEVENT.datenum
  is '�������ָ�ʽ';
comment on column T_100228_CEVENT.appid
  is '��Ϸ�� appid';
comment on column T_100228_CEVENT.channelid
  is '���� ID';
comment on column T_100228_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column T_100228_CEVENT.dvid
  is '�豸 ID��Ψһ�豸��';
comment on column T_100228_CEVENT.accountid
  is '�ʻ� id';
comment on column T_100228_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column T_100228_CEVENT.ilevel
  is '��ҵȼ�';
comment on column T_100228_CEVENT.roleid
  is '��ɫ id';
comment on column T_100228_CEVENT.eventkey
  is '�¼�����';
comment on column T_100228_CEVENT.eventvalue_key
  is '�¼�ֵ�е�key';
comment on column T_100228_CEVENT.eventvalue_value
  is '�¼�ֵ��key��Ӧ��ֵ';
comment on column T_100228_CEVENT.ipaddr
  is 'ip ��ַ';
comment on column T_100228_CEVENT.prerowid
  is 'ԭΨһ��ID';
create index IDX180_100228 on T_100228_CEVENT (THEDATE);

prompt
prompt Creating table T_100228_CONN
prompt ============================
prompt
create table T_100228_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100228_CONN
  is '����&��ʧ&������������������ע���˺ţ�ע���豸��';
comment on column T_100228_CONN.conndate
  is '����ʱ��';
comment on column T_100228_CONN.gameid
  is '��ϷID';
comment on column T_100228_CONN.channelid
  is '����ID';
comment on column T_100228_CONN.gameversion
  is '��Ϸ�汾';
comment on column T_100228_CONN.serverid
  is '����ID';
comment on column T_100228_CONN.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100228_CONN.position
  is 'λ����Ϣ';
comment on column T_100228_CONN.dvid
  is '�豸��';
comment on column T_100228_CONN.accountid
  is '�˺�ID';
comment on column T_100228_CONN.regdate
  is 'ע��ʱ��';
comment on column T_100228_CONN.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100228_CONN.regdate_as
  is '���з��������ע��ʱ��';
create index IDX118_100228 on T_100228_CONN (CHANNELID);
create index IDX119_100228 on T_100228_CONN (SERVERID);
create index IDX120_100228 on T_100228_CONN (CONNDATE);

prompt
prompt Creating table T_100228_CONN_ACT
prompt ================================
prompt
create table T_100228_CONN_ACT
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100228_CONN_ACT
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100228_CONN_ACT.basedate
  is '����ʱ��';
comment on column T_100228_CONN_ACT.gameid
  is '��ϷID';
comment on column T_100228_CONN_ACT.channelid
  is '����ID';
comment on column T_100228_CONN_ACT.gameversion
  is '��Ϸ�汾';
comment on column T_100228_CONN_ACT.serverid
  is '����ID';
comment on column T_100228_CONN_ACT.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100228_CONN_ACT.position
  is 'λ����Ϣ';
comment on column T_100228_CONN_ACT.dvid
  is '�豸��';
comment on column T_100228_CONN_ACT.accountid
  is '�˺�';
comment on column T_100228_CONN_ACT.conndate
  is '��Ծʱ��';
comment on column T_100228_CONN_ACT.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_100228 on T_100228_CONN_ACT (CHANNELID);
create index IDX122_100228 on T_100228_CONN_ACT (SERVERID);
create index IDX123_100228 on T_100228_CONN_ACT (CONNDATE);
create index IDX124_100228 on T_100228_CONN_ACT (BASEDATE);

prompt
prompt Creating table T_100228_CONN_ACT_AS
prompt ===================================
prompt
create table T_100228_CONN_ACT_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100228_CONN_ACT_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100228_CONN_ACT_AS.basedate
  is '����ʱ��';
comment on column T_100228_CONN_ACT_AS.gameid
  is '��ϷID';
comment on column T_100228_CONN_ACT_AS.channelid
  is '����ID';
comment on column T_100228_CONN_ACT_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100228_CONN_ACT_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100228_CONN_ACT_AS.position
  is 'λ����Ϣ';
comment on column T_100228_CONN_ACT_AS.dvid
  is '�豸��';
comment on column T_100228_CONN_ACT_AS.accountid
  is '�˺�';
comment on column T_100228_CONN_ACT_AS.conndate
  is '��Ծʱ��';
comment on column T_100228_CONN_ACT_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX205_100228 on T_100228_CONN_ACT_AS (CHANNELID);
create index IDX206_100228 on T_100228_CONN_ACT_AS (CONNDATE);
create index IDX207_100228 on T_100228_CONN_ACT_AS (BASEDATE);

prompt
prompt Creating table T_100228_CONN_ACT_MAC
prompt ====================================
prompt
create table T_100228_CONN_ACT_MAC
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100228_CONN_ACT_MAC
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100228_CONN_ACT_MAC.basedate
  is '����ʱ��';
comment on column T_100228_CONN_ACT_MAC.gameid
  is '��ϷID';
comment on column T_100228_CONN_ACT_MAC.channelid
  is '����ID';
comment on column T_100228_CONN_ACT_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100228_CONN_ACT_MAC.serverid
  is '����ID';
comment on column T_100228_CONN_ACT_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100228_CONN_ACT_MAC.position
  is 'λ����Ϣ';
comment on column T_100228_CONN_ACT_MAC.dvid
  is '�豸��';
comment on column T_100228_CONN_ACT_MAC.accountid
  is '�˺�';
comment on column T_100228_CONN_ACT_MAC.conndate
  is '��Ծʱ��';
comment on column T_100228_CONN_ACT_MAC.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_100228 on T_100228_CONN_ACT_MAC (CHANNELID);
create index IDX126_100228 on T_100228_CONN_ACT_MAC (SERVERID);
create index IDX127_100228 on T_100228_CONN_ACT_MAC (CONNDATE);
create index IDX128_100228 on T_100228_CONN_ACT_MAC (BASEDATE);

prompt
prompt Creating table T_100228_CONN_ACT_MAC_AS
prompt =======================================
prompt
create table T_100228_CONN_ACT_MAC_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100228_CONN_ACT_MAC_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100228_CONN_ACT_MAC_AS.basedate
  is '����ʱ��';
comment on column T_100228_CONN_ACT_MAC_AS.gameid
  is '��ϷID';
comment on column T_100228_CONN_ACT_MAC_AS.channelid
  is '����ID';
comment on column T_100228_CONN_ACT_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100228_CONN_ACT_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100228_CONN_ACT_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100228_CONN_ACT_MAC_AS.dvid
  is '�豸��';
comment on column T_100228_CONN_ACT_MAC_AS.accountid
  is '�˺�';
comment on column T_100228_CONN_ACT_MAC_AS.conndate
  is '��Ծʱ��';
comment on column T_100228_CONN_ACT_MAC_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX202_100228 on T_100228_CONN_ACT_MAC_AS (CHANNELID);
create index IDX203_100228 on T_100228_CONN_ACT_MAC_AS (CONNDATE);
create index IDX204_100228 on T_100228_CONN_ACT_MAC_AS (BASEDATE);

prompt
prompt Creating table T_100228_CONN_DVID
prompt =================================
prompt
create table T_100228_CONN_DVID
(
  conndate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  dvid      VARCHAR2(50),
  regdate   VARCHAR2(10)
)
;
comment on table T_100228_CONN_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100228_CONN_DVID.conndate
  is '����ʱ��';
comment on column T_100228_CONN_DVID.gameid
  is '��ϷID';
comment on column T_100228_CONN_DVID.channelid
  is '����ID';
comment on column T_100228_CONN_DVID.dvid
  is '�豸��';
comment on column T_100228_CONN_DVID.regdate
  is 'ע��ʱ��';
create index IDX129_100228 on T_100228_CONN_DVID (CHANNELID);
create index IDX130_100228 on T_100228_CONN_DVID (CONNDATE);

prompt
prompt Creating table T_100228_CONN_MAC
prompt ================================
prompt
create table T_100228_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100228_CONN_MAC
  is '���� ��ʧ ������������������ע���˺ţ�ע���豸��';
comment on column T_100228_CONN_MAC.conndate
  is '����ʱ��';
comment on column T_100228_CONN_MAC.gameid
  is '��ϷID';
comment on column T_100228_CONN_MAC.channelid
  is '����ID';
comment on column T_100228_CONN_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100228_CONN_MAC.serverid
  is '����ID';
comment on column T_100228_CONN_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100228_CONN_MAC.position
  is 'λ����Ϣ';
comment on column T_100228_CONN_MAC.dvid
  is '�豸��';
comment on column T_100228_CONN_MAC.accountid
  is '�˺�ID';
comment on column T_100228_CONN_MAC.regdate
  is 'ע��ʱ��';
comment on column T_100228_CONN_MAC.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100228_CONN_MAC.regdate_as
  is '���з��������ע��ʱ��';
create index IDX131_100228 on T_100228_CONN_MAC (CHANNELID);
create index IDX132_100228 on T_100228_CONN_MAC (SERVERID);
create index IDX133_100228 on T_100228_CONN_MAC (CONNDATE);

prompt
prompt Creating table T_100228_LOST_MAC
prompt ================================
prompt
create table T_100228_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100228_LOST_MAC
  is '�豸�ȼ���ʧ������';
comment on column T_100228_LOST_MAC.statdate
  is '�����������';
comment on column T_100228_LOST_MAC.lost_date
  is '��ʧ����';
comment on column T_100228_LOST_MAC.channelid
  is '����';
comment on column T_100228_LOST_MAC.serverid
  is '����';
comment on column T_100228_LOST_MAC.appid
  is '��Ʒid';
comment on column T_100228_LOST_MAC.macid
  is '�豸id';
comment on column T_100228_LOST_MAC.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100228_LOST_MAC.lost_days
  is '��ʧ����';
comment on column T_100228_LOST_MAC.data_source
  is '������Դ';
create index IDX134_100228 on T_100228_LOST_MAC (CHANNELID);
create index IDX135_100228 on T_100228_LOST_MAC (SERVERID);
create index IDX136_100228 on T_100228_LOST_MAC (STATDATE);

prompt
prompt Creating table T_100228_LOST_MAC_AS
prompt ===================================
prompt
create table T_100228_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100228_LOST_MAC_AS
  is '�豸�ȼ���ʧ������allserver';
comment on column T_100228_LOST_MAC_AS.statdate
  is '�����������';
comment on column T_100228_LOST_MAC_AS.lost_date
  is '��ʧ����';
comment on column T_100228_LOST_MAC_AS.channelid
  is '����';
comment on column T_100228_LOST_MAC_AS.appid
  is '��Ʒid';
comment on column T_100228_LOST_MAC_AS.macid
  is '�豸id';
comment on column T_100228_LOST_MAC_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100228_LOST_MAC_AS.lost_days
  is '��ʧ����';
comment on column T_100228_LOST_MAC_AS.data_source
  is '������Դ';
create index IDX210_100228 on T_100228_LOST_MAC_AS (CHANNELID);
create index IDX211_100228 on T_100228_LOST_MAC_AS (STATDATE);

prompt
prompt Creating table T_100228_LOST_USER
prompt =================================
prompt
create table T_100228_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100228_LOST_USER
  is '�û��ȼ���ʧ������';
comment on column T_100228_LOST_USER.statdate
  is '�����������';
comment on column T_100228_LOST_USER.lost_date
  is '��ʧ����';
comment on column T_100228_LOST_USER.channelid
  is '����';
comment on column T_100228_LOST_USER.serverid
  is '����';
comment on column T_100228_LOST_USER.appid
  is '��Ʒid';
comment on column T_100228_LOST_USER.userid
  is '�û�id';
comment on column T_100228_LOST_USER.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100228_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100228_LOST_USER.lost_days
  is '��ʧ����';
comment on column T_100228_LOST_USER.data_source
  is '������Դ';
create index IDX137_100228 on T_100228_LOST_USER (CHANNELID);
create index IDX138_100228 on T_100228_LOST_USER (SERVERID);
create index IDX139_100228 on T_100228_LOST_USER (STATDATE);

prompt
prompt Creating table T_100228_LOST_USER_AS
prompt ====================================
prompt
create table T_100228_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100228_LOST_USER_AS
  is '�û��ȼ���ʧ������allserver';
comment on column T_100228_LOST_USER_AS.statdate
  is '�����������';
comment on column T_100228_LOST_USER_AS.lost_date
  is '��ʧ����';
comment on column T_100228_LOST_USER_AS.channelid
  is '����';
comment on column T_100228_LOST_USER_AS.appid
  is '��Ʒid';
comment on column T_100228_LOST_USER_AS.userid
  is '�û�id';
comment on column T_100228_LOST_USER_AS.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100228_LOST_USER_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100228_LOST_USER_AS.lost_days
  is '��ʧ����';
comment on column T_100228_LOST_USER_AS.data_source
  is '������Դ';
create index IDX208_100228 on T_100228_LOST_USER_AS (CHANNELID);
create index IDX209_100228 on T_100228_LOST_USER_AS (STATDATE);

prompt
prompt Creating table T_100228_MISS_FIRST
prompt ==================================
prompt
create table T_100228_MISS_FIRST
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50) default '0',
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100228_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column T_100228_MISS_FIRST.statdate
  is 'ͳ������';
comment on column T_100228_MISS_FIRST.channelid
  is '����';
comment on column T_100228_MISS_FIRST.serverid
  is '����';
comment on column T_100228_MISS_FIRST.appid
  is '��ƷID';
comment on column T_100228_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column T_100228_MISS_FIRST.accountid
  is '�û�ID';
comment on column T_100228_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100228_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column T_100228_MISS_FIRST.issucc
  is '�Ƿ���ͨ��';
comment on column T_100228_MISS_FIRST.data_source
  is '������Դ';
create index IDX140_100228 on T_100228_MISS_FIRST (CHANNELID);
create index IDX141_100228 on T_100228_MISS_FIRST (SERVERID);
create index IDX142_100228 on T_100228_MISS_FIRST (STATDATE);

prompt
prompt Creating table T_100228_NU
prompt ==========================
prompt
create table T_100228_NU
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100228_NU
  is '�����û���Ϣ��';
comment on column T_100228_NU.thedate
  is '��������';
comment on column T_100228_NU.gameid
  is '��ϷID';
comment on column T_100228_NU.channelid
  is '����ID';
comment on column T_100228_NU.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100228_NU.serverid
  is '���ڷ�ID';
comment on column T_100228_NU.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100228_NU.position
  is '����λ��';
comment on column T_100228_NU.accountid
  is '�˺�ID';
create index IDX143_100228 on T_100228_NU (CHANNELID);
create index IDX144_100228 on T_100228_NU (SERVERID);
create index IDX145_100228 on T_100228_NU (THEDATE);

prompt
prompt Creating table T_100228_NU_ALLSERVER
prompt ====================================
prompt
create table T_100228_NU_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100228_NU_ALLSERVER
  is '�����û���Ϣ��ALLSERVER';
comment on column T_100228_NU_ALLSERVER.thedate
  is '��������';
comment on column T_100228_NU_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100228_NU_ALLSERVER.channelid
  is '����ID';
comment on column T_100228_NU_ALLSERVER.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100228_NU_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100228_NU_ALLSERVER.position
  is '����λ��';
comment on column T_100228_NU_ALLSERVER.accountid
  is '�˺�ID';
create index IDX194_100228 on T_100228_NU_ALLSERVER (CHANNELID);
create index IDX195_100228 on T_100228_NU_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100228_NU_DVID
prompt ===============================
prompt
create table T_100228_NU_DVID
(
  thedate   DATE not null,
  gameid    VARCHAR2(20) not null,
  channelid VARCHAR2(20) not null,
  dvid      VARCHAR2(50) not null,
  ipaddr    VARCHAR2(50)
)
;
comment on table T_100228_NU_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100228_NU_DVID.thedate
  is '����ʱ��';
comment on column T_100228_NU_DVID.gameid
  is '��ϷID';
comment on column T_100228_NU_DVID.channelid
  is '����ID';
comment on column T_100228_NU_DVID.dvid
  is '�豸ID';
comment on column T_100228_NU_DVID.ipaddr
  is 'IP';
create index IDX146_100228 on T_100228_NU_DVID (CHANNELID);
create index IDX147_100228 on T_100228_NU_DVID (THEDATE);

prompt
prompt Creating table T_100228_NU_MAC
prompt ==============================
prompt
create table T_100228_NU_MAC
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100228_NU_MAC
  is '�豸������';
comment on column T_100228_NU_MAC.thedate
  is '����ʱ��';
comment on column T_100228_NU_MAC.gameid
  is '��ϷID';
comment on column T_100228_NU_MAC.channelid
  is '����ID';
comment on column T_100228_NU_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100228_NU_MAC.serverid
  is '��������ID';
comment on column T_100228_NU_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100228_NU_MAC.position
  is 'λ����Ϣ';
comment on column T_100228_NU_MAC.dvid
  is '�豸ID';
create index IDX148_100228 on T_100228_NU_MAC (CHANNELID);
create index IDX149_100228 on T_100228_NU_MAC (SERVERID);
create index IDX150_100228 on T_100228_NU_MAC (THEDATE);

prompt
prompt Creating table T_100228_NU_MAC_ALLSERVER
prompt ========================================
prompt
create table T_100228_NU_MAC_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100228_NU_MAC_ALLSERVER
  is '�豸������ALLSERVER';
comment on column T_100228_NU_MAC_ALLSERVER.thedate
  is '����ʱ��';
comment on column T_100228_NU_MAC_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100228_NU_MAC_ALLSERVER.channelid
  is '����ID';
comment on column T_100228_NU_MAC_ALLSERVER.gameversion
  is '��Ϸ�汾';
comment on column T_100228_NU_MAC_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100228_NU_MAC_ALLSERVER.position
  is 'λ����Ϣ';
comment on column T_100228_NU_MAC_ALLSERVER.dvid
  is '�豸ID';
create index IDX196_100228 on T_100228_NU_MAC_ALLSERVER (CHANNELID);
create index IDX197_100228 on T_100228_NU_MAC_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100228_NU_PAY
prompt ==============================
prompt
create table T_100228_NU_PAY
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100228_NU_PAY
  is '�����û���';
comment on column T_100228_NU_PAY.thedate
  is '����ʱ��';
comment on column T_100228_NU_PAY.gameid
  is '��ϷID';
comment on column T_100228_NU_PAY.channelid
  is '����ID';
comment on column T_100228_NU_PAY.gameversion
  is '��Ϸ�汾';
comment on column T_100228_NU_PAY.serverid
  is '������Ϣ';
comment on column T_100228_NU_PAY.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100228_NU_PAY.position
  is 'λ����Ϣ';
comment on column T_100228_NU_PAY.accountid
  is '�˺�ID';
comment on column T_100228_NU_PAY.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100228_NU_PAY.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX151_100228 on T_100228_NU_PAY (CHANNELID);
create index IDX152_100228 on T_100228_NU_PAY (SERVERID);
create index IDX153_100228 on T_100228_NU_PAY (THEDATE);

prompt
prompt Creating table T_100228_NU_PAY_AS
prompt =================================
prompt
create table T_100228_NU_PAY_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100228_NU_PAY_AS
  is '�����û���allsever';
comment on column T_100228_NU_PAY_AS.thedate
  is '����ʱ��';
comment on column T_100228_NU_PAY_AS.gameid
  is '��ϷID';
comment on column T_100228_NU_PAY_AS.channelid
  is '����ID';
comment on column T_100228_NU_PAY_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100228_NU_PAY_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100228_NU_PAY_AS.position
  is 'λ����Ϣ';
comment on column T_100228_NU_PAY_AS.accountid
  is '�˺�ID';
comment on column T_100228_NU_PAY_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100228_NU_PAY_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX198_100228 on T_100228_NU_PAY_AS (CHANNELID);
create index IDX199_100228 on T_100228_NU_PAY_AS (THEDATE);

prompt
prompt Creating table T_100228_NU_PAY_MAC
prompt ==================================
prompt
create table T_100228_NU_PAY_MAC
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100228_NU_PAY_MAC
  is '�����û���';
comment on column T_100228_NU_PAY_MAC.thedate
  is '����ʱ��';
comment on column T_100228_NU_PAY_MAC.gameid
  is '��ϷID';
comment on column T_100228_NU_PAY_MAC.channelid
  is '����ID';
comment on column T_100228_NU_PAY_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100228_NU_PAY_MAC.serverid
  is '������Ϣ';
comment on column T_100228_NU_PAY_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100228_NU_PAY_MAC.position
  is 'λ����Ϣ';
comment on column T_100228_NU_PAY_MAC.dvid
  is '�豸ID';
comment on column T_100228_NU_PAY_MAC.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100228_NU_PAY_MAC.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX154_100228 on T_100228_NU_PAY_MAC (CHANNELID);
create index IDX155_100228 on T_100228_NU_PAY_MAC (SERVERID);
create index IDX156_100228 on T_100228_NU_PAY_MAC (THEDATE);

prompt
prompt Creating table T_100228_NU_PAY_MAC_AS
prompt =====================================
prompt
create table T_100228_NU_PAY_MAC_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100228_NU_PAY_MAC_AS
  is '�����û���ALLSERVER';
comment on column T_100228_NU_PAY_MAC_AS.thedate
  is '����ʱ��';
comment on column T_100228_NU_PAY_MAC_AS.gameid
  is '��ϷID';
comment on column T_100228_NU_PAY_MAC_AS.channelid
  is '����ID';
comment on column T_100228_NU_PAY_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100228_NU_PAY_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100228_NU_PAY_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100228_NU_PAY_MAC_AS.dvid
  is '�豸ID';
comment on column T_100228_NU_PAY_MAC_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100228_NU_PAY_MAC_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX200_100228 on T_100228_NU_PAY_MAC_AS (CHANNELID);
create index IDX201_100228 on T_100228_NU_PAY_MAC_AS (THEDATE);

prompt
prompt Creating table T_100228_ORDER_FAILURE
prompt =====================================
prompt
create table T_100228_ORDER_FAILURE
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100228_ORDER_FAILURE
  is '��ֵ�ɹ���¼��';
comment on column T_100228_ORDER_FAILURE.thedate
  is '��ֵʱ��';
comment on column T_100228_ORDER_FAILURE.gameid
  is '��ϷID';
comment on column T_100228_ORDER_FAILURE.channelid
  is '����ID';
comment on column T_100228_ORDER_FAILURE.gameversion
  is '��Ϸ�汾';
comment on column T_100228_ORDER_FAILURE.serverid
  is '��������';
comment on column T_100228_ORDER_FAILURE.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100228_ORDER_FAILURE.position
  is 'λ����Ϣ';
comment on column T_100228_ORDER_FAILURE.dvid
  is '�豸��';
comment on column T_100228_ORDER_FAILURE.accountid
  is '�˺�';
comment on column T_100228_ORDER_FAILURE.money
  is '��ֵ���';
comment on column T_100228_ORDER_FAILURE.vc
  is '��ֵ��õ����������';
comment on column T_100228_ORDER_FAILURE.orderid
  is '������';
comment on column T_100228_ORDER_FAILURE.paychannel
  is '֧������';
comment on column T_100228_ORDER_FAILURE.iapid
  is '��ֵ����  30  60';
create index IDX157_100228 on T_100228_ORDER_FAILURE (CHANNELID);
create index IDX158_100228 on T_100228_ORDER_FAILURE (SERVERID);
create index IDX159_100228 on T_100228_ORDER_FAILURE (THEDATE);

prompt
prompt Creating table T_100228_ORDER_SUCC
prompt ==================================
prompt
create table T_100228_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100228_ORDER_SUCC
  is '��ֵ�ɹ���¼��';
comment on column T_100228_ORDER_SUCC.thedate
  is '��ֵʱ��';
comment on column T_100228_ORDER_SUCC.gameid
  is '��ϷID';
comment on column T_100228_ORDER_SUCC.channelid
  is '����ID';
comment on column T_100228_ORDER_SUCC.gameversion
  is '��Ϸ�汾';
comment on column T_100228_ORDER_SUCC.serverid
  is '��������';
comment on column T_100228_ORDER_SUCC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100228_ORDER_SUCC.position
  is 'λ����Ϣ';
comment on column T_100228_ORDER_SUCC.dvid
  is '�豸��';
comment on column T_100228_ORDER_SUCC.accountid
  is '�˺�';
comment on column T_100228_ORDER_SUCC.money
  is '��ֵ���';
comment on column T_100228_ORDER_SUCC.vc
  is '��ֵ��õ����������';
comment on column T_100228_ORDER_SUCC.orderid
  is '������';
comment on column T_100228_ORDER_SUCC.paychannel
  is '֧������';
comment on column T_100228_ORDER_SUCC.iapid
  is '��ֵ����  30  60';
create index IDX160_100228 on T_100228_ORDER_SUCC (CHANNELID);
create index IDX161_100228 on T_100228_ORDER_SUCC (SERVERID);
create index IDX162_100228 on T_100228_ORDER_SUCC (THEDATE);

prompt
prompt Creating table T_100228_VC
prompt ==========================
prompt
create table T_100228_VC
(
  statdate    DATE,
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcchange    NUMBER,
  vcbefore    NUMBER,
  vcafter     NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100228_VC
  is '������ұ仯������';
comment on column T_100228_VC.statdate
  is 'ͳ������';
comment on column T_100228_VC.channelid
  is '����';
comment on column T_100228_VC.serverid
  is '����';
comment on column T_100228_VC.appid
  is '��Ʒid';
comment on column T_100228_VC.versionid
  is '��Ʒ�汾';
comment on column T_100228_VC.accountid
  is '�û�ID';
comment on column T_100228_VC.vctype
  is '�����������';
comment on column T_100228_VC.vcusetype
  is '�������ʹ������';
comment on column T_100228_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column T_100228_VC.vcchange
  is '������ұ仯���';
comment on column T_100228_VC.vcbefore
  is '������ұ仯ǰ���';
comment on column T_100228_VC.vcafter
  is '������ұ仯����';
comment on column T_100228_VC.data_source
  is '������Դ';
create index IDX163_100228 on T_100228_VC (CHANNELID);
create index IDX164_100228 on T_100228_VC (SERVERID);
create index IDX165_100228 on T_100228_VC (STATDATE);

prompt
prompt Creating table T_100230_CEVENT
prompt ==============================
prompt
create table T_100230_CEVENT
(
  thedate          VARCHAR2(10),
  datenum          NUMBER,
  appid            VARCHAR2(10),
  channelid        VARCHAR2(50),
  gameversion      VARCHAR2(50),
  dvid             VARCHAR2(50),
  accountid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  ilevel           NUMBER,
  roleid           VARCHAR2(50),
  eventkey         VARCHAR2(100),
  eventvalue_key   VARCHAR2(100),
  eventvalue_value VARCHAR2(100),
  ipaddr           VARCHAR2(50),
  prerowid         VARCHAR2(200)
)
;
comment on table T_100230_CEVENT
  is '�Զ����¼���ֱ�';
comment on column T_100230_CEVENT.thedate
  is '����';
comment on column T_100230_CEVENT.datenum
  is '�������ָ�ʽ';
comment on column T_100230_CEVENT.appid
  is '��Ϸ�� appid';
comment on column T_100230_CEVENT.channelid
  is '���� ID';
comment on column T_100230_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column T_100230_CEVENT.dvid
  is '�豸 ID��Ψһ�豸��';
comment on column T_100230_CEVENT.accountid
  is '�ʻ� id';
comment on column T_100230_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column T_100230_CEVENT.ilevel
  is '��ҵȼ�';
comment on column T_100230_CEVENT.roleid
  is '��ɫ id';
comment on column T_100230_CEVENT.eventkey
  is '�¼�����';
comment on column T_100230_CEVENT.eventvalue_key
  is '�¼�ֵ�е�key';
comment on column T_100230_CEVENT.eventvalue_value
  is '�¼�ֵ��key��Ӧ��ֵ';
comment on column T_100230_CEVENT.ipaddr
  is 'ip ��ַ';
comment on column T_100230_CEVENT.prerowid
  is 'ԭΨһ��ID';
create index IDX180_100230 on T_100230_CEVENT (THEDATE);

prompt
prompt Creating table T_100230_CONN
prompt ============================
prompt
create table T_100230_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100230_CONN
  is '����&��ʧ&������������������ע���˺ţ�ע���豸��';
comment on column T_100230_CONN.conndate
  is '����ʱ��';
comment on column T_100230_CONN.gameid
  is '��ϷID';
comment on column T_100230_CONN.channelid
  is '����ID';
comment on column T_100230_CONN.gameversion
  is '��Ϸ�汾';
comment on column T_100230_CONN.serverid
  is '����ID';
comment on column T_100230_CONN.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100230_CONN.position
  is 'λ����Ϣ';
comment on column T_100230_CONN.dvid
  is '�豸��';
comment on column T_100230_CONN.accountid
  is '�˺�ID';
comment on column T_100230_CONN.regdate
  is 'ע��ʱ��';
comment on column T_100230_CONN.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100230_CONN.regdate_as
  is '���з��������ע��ʱ��';
create index IDX118_100230 on T_100230_CONN (CHANNELID);
create index IDX119_100230 on T_100230_CONN (SERVERID);
create index IDX120_100230 on T_100230_CONN (CONNDATE);

prompt
prompt Creating table T_100230_CONN_ACT
prompt ================================
prompt
create table T_100230_CONN_ACT
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100230_CONN_ACT
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100230_CONN_ACT.basedate
  is '����ʱ��';
comment on column T_100230_CONN_ACT.gameid
  is '��ϷID';
comment on column T_100230_CONN_ACT.channelid
  is '����ID';
comment on column T_100230_CONN_ACT.gameversion
  is '��Ϸ�汾';
comment on column T_100230_CONN_ACT.serverid
  is '����ID';
comment on column T_100230_CONN_ACT.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100230_CONN_ACT.position
  is 'λ����Ϣ';
comment on column T_100230_CONN_ACT.dvid
  is '�豸��';
comment on column T_100230_CONN_ACT.accountid
  is '�˺�';
comment on column T_100230_CONN_ACT.conndate
  is '��Ծʱ��';
comment on column T_100230_CONN_ACT.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_100230 on T_100230_CONN_ACT (CHANNELID);
create index IDX122_100230 on T_100230_CONN_ACT (SERVERID);
create index IDX123_100230 on T_100230_CONN_ACT (CONNDATE);
create index IDX124_100230 on T_100230_CONN_ACT (BASEDATE);

prompt
prompt Creating table T_100230_CONN_ACT_AS
prompt ===================================
prompt
create table T_100230_CONN_ACT_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100230_CONN_ACT_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100230_CONN_ACT_AS.basedate
  is '����ʱ��';
comment on column T_100230_CONN_ACT_AS.gameid
  is '��ϷID';
comment on column T_100230_CONN_ACT_AS.channelid
  is '����ID';
comment on column T_100230_CONN_ACT_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100230_CONN_ACT_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100230_CONN_ACT_AS.position
  is 'λ����Ϣ';
comment on column T_100230_CONN_ACT_AS.dvid
  is '�豸��';
comment on column T_100230_CONN_ACT_AS.accountid
  is '�˺�';
comment on column T_100230_CONN_ACT_AS.conndate
  is '��Ծʱ��';
comment on column T_100230_CONN_ACT_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX205_100230 on T_100230_CONN_ACT_AS (CHANNELID);
create index IDX206_100230 on T_100230_CONN_ACT_AS (CONNDATE);
create index IDX207_100230 on T_100230_CONN_ACT_AS (BASEDATE);

prompt
prompt Creating table T_100230_CONN_ACT_MAC
prompt ====================================
prompt
create table T_100230_CONN_ACT_MAC
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100230_CONN_ACT_MAC
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100230_CONN_ACT_MAC.basedate
  is '����ʱ��';
comment on column T_100230_CONN_ACT_MAC.gameid
  is '��ϷID';
comment on column T_100230_CONN_ACT_MAC.channelid
  is '����ID';
comment on column T_100230_CONN_ACT_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100230_CONN_ACT_MAC.serverid
  is '����ID';
comment on column T_100230_CONN_ACT_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100230_CONN_ACT_MAC.position
  is 'λ����Ϣ';
comment on column T_100230_CONN_ACT_MAC.dvid
  is '�豸��';
comment on column T_100230_CONN_ACT_MAC.accountid
  is '�˺�';
comment on column T_100230_CONN_ACT_MAC.conndate
  is '��Ծʱ��';
comment on column T_100230_CONN_ACT_MAC.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_100230 on T_100230_CONN_ACT_MAC (CHANNELID);
create index IDX126_100230 on T_100230_CONN_ACT_MAC (SERVERID);
create index IDX127_100230 on T_100230_CONN_ACT_MAC (CONNDATE);
create index IDX128_100230 on T_100230_CONN_ACT_MAC (BASEDATE);

prompt
prompt Creating table T_100230_CONN_ACT_MAC_AS
prompt =======================================
prompt
create table T_100230_CONN_ACT_MAC_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100230_CONN_ACT_MAC_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100230_CONN_ACT_MAC_AS.basedate
  is '����ʱ��';
comment on column T_100230_CONN_ACT_MAC_AS.gameid
  is '��ϷID';
comment on column T_100230_CONN_ACT_MAC_AS.channelid
  is '����ID';
comment on column T_100230_CONN_ACT_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100230_CONN_ACT_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100230_CONN_ACT_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100230_CONN_ACT_MAC_AS.dvid
  is '�豸��';
comment on column T_100230_CONN_ACT_MAC_AS.accountid
  is '�˺�';
comment on column T_100230_CONN_ACT_MAC_AS.conndate
  is '��Ծʱ��';
comment on column T_100230_CONN_ACT_MAC_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX202_100230 on T_100230_CONN_ACT_MAC_AS (CHANNELID);
create index IDX203_100230 on T_100230_CONN_ACT_MAC_AS (CONNDATE);
create index IDX204_100230 on T_100230_CONN_ACT_MAC_AS (BASEDATE);

prompt
prompt Creating table T_100230_CONN_DVID
prompt =================================
prompt
create table T_100230_CONN_DVID
(
  conndate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  dvid      VARCHAR2(50),
  regdate   VARCHAR2(10)
)
;
comment on table T_100230_CONN_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100230_CONN_DVID.conndate
  is '����ʱ��';
comment on column T_100230_CONN_DVID.gameid
  is '��ϷID';
comment on column T_100230_CONN_DVID.channelid
  is '����ID';
comment on column T_100230_CONN_DVID.dvid
  is '�豸��';
comment on column T_100230_CONN_DVID.regdate
  is 'ע��ʱ��';
create index IDX129_100230 on T_100230_CONN_DVID (CHANNELID);
create index IDX130_100230 on T_100230_CONN_DVID (CONNDATE);

prompt
prompt Creating table T_100230_CONN_MAC
prompt ================================
prompt
create table T_100230_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100230_CONN_MAC
  is '���� ��ʧ ������������������ע���˺ţ�ע���豸��';
comment on column T_100230_CONN_MAC.conndate
  is '����ʱ��';
comment on column T_100230_CONN_MAC.gameid
  is '��ϷID';
comment on column T_100230_CONN_MAC.channelid
  is '����ID';
comment on column T_100230_CONN_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100230_CONN_MAC.serverid
  is '����ID';
comment on column T_100230_CONN_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100230_CONN_MAC.position
  is 'λ����Ϣ';
comment on column T_100230_CONN_MAC.dvid
  is '�豸��';
comment on column T_100230_CONN_MAC.accountid
  is '�˺�ID';
comment on column T_100230_CONN_MAC.regdate
  is 'ע��ʱ��';
comment on column T_100230_CONN_MAC.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100230_CONN_MAC.regdate_as
  is '���з��������ע��ʱ��';
create index IDX131_100230 on T_100230_CONN_MAC (CHANNELID);
create index IDX132_100230 on T_100230_CONN_MAC (SERVERID);
create index IDX133_100230 on T_100230_CONN_MAC (CONNDATE);

prompt
prompt Creating table T_100230_LOST_MAC
prompt ================================
prompt
create table T_100230_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100230_LOST_MAC
  is '�豸�ȼ���ʧ������';
comment on column T_100230_LOST_MAC.statdate
  is '�����������';
comment on column T_100230_LOST_MAC.lost_date
  is '��ʧ����';
comment on column T_100230_LOST_MAC.channelid
  is '����';
comment on column T_100230_LOST_MAC.serverid
  is '����';
comment on column T_100230_LOST_MAC.appid
  is '��Ʒid';
comment on column T_100230_LOST_MAC.macid
  is '�豸id';
comment on column T_100230_LOST_MAC.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100230_LOST_MAC.lost_days
  is '��ʧ����';
comment on column T_100230_LOST_MAC.data_source
  is '������Դ';
create index IDX134_100230 on T_100230_LOST_MAC (CHANNELID);
create index IDX135_100230 on T_100230_LOST_MAC (SERVERID);
create index IDX136_100230 on T_100230_LOST_MAC (STATDATE);

prompt
prompt Creating table T_100230_LOST_MAC_AS
prompt ===================================
prompt
create table T_100230_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100230_LOST_MAC_AS
  is '�豸�ȼ���ʧ������allserver';
comment on column T_100230_LOST_MAC_AS.statdate
  is '�����������';
comment on column T_100230_LOST_MAC_AS.lost_date
  is '��ʧ����';
comment on column T_100230_LOST_MAC_AS.channelid
  is '����';
comment on column T_100230_LOST_MAC_AS.appid
  is '��Ʒid';
comment on column T_100230_LOST_MAC_AS.macid
  is '�豸id';
comment on column T_100230_LOST_MAC_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100230_LOST_MAC_AS.lost_days
  is '��ʧ����';
comment on column T_100230_LOST_MAC_AS.data_source
  is '������Դ';
create index IDX210_100230 on T_100230_LOST_MAC_AS (CHANNELID);
create index IDX211_100230 on T_100230_LOST_MAC_AS (STATDATE);

prompt
prompt Creating table T_100230_LOST_USER
prompt =================================
prompt
create table T_100230_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100230_LOST_USER
  is '�û��ȼ���ʧ������';
comment on column T_100230_LOST_USER.statdate
  is '�����������';
comment on column T_100230_LOST_USER.lost_date
  is '��ʧ����';
comment on column T_100230_LOST_USER.channelid
  is '����';
comment on column T_100230_LOST_USER.serverid
  is '����';
comment on column T_100230_LOST_USER.appid
  is '��Ʒid';
comment on column T_100230_LOST_USER.userid
  is '�û�id';
comment on column T_100230_LOST_USER.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100230_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100230_LOST_USER.lost_days
  is '��ʧ����';
comment on column T_100230_LOST_USER.data_source
  is '������Դ';
create index IDX137_100230 on T_100230_LOST_USER (CHANNELID);
create index IDX138_100230 on T_100230_LOST_USER (SERVERID);
create index IDX139_100230 on T_100230_LOST_USER (STATDATE);

prompt
prompt Creating table T_100230_LOST_USER_AS
prompt ====================================
prompt
create table T_100230_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100230_LOST_USER_AS
  is '�û��ȼ���ʧ������allserver';
comment on column T_100230_LOST_USER_AS.statdate
  is '�����������';
comment on column T_100230_LOST_USER_AS.lost_date
  is '��ʧ����';
comment on column T_100230_LOST_USER_AS.channelid
  is '����';
comment on column T_100230_LOST_USER_AS.appid
  is '��Ʒid';
comment on column T_100230_LOST_USER_AS.userid
  is '�û�id';
comment on column T_100230_LOST_USER_AS.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100230_LOST_USER_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100230_LOST_USER_AS.lost_days
  is '��ʧ����';
comment on column T_100230_LOST_USER_AS.data_source
  is '������Դ';
create index IDX208_100230 on T_100230_LOST_USER_AS (CHANNELID);
create index IDX209_100230 on T_100230_LOST_USER_AS (STATDATE);

prompt
prompt Creating table T_100230_MISS_FIRST
prompt ==================================
prompt
create table T_100230_MISS_FIRST
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50) default '0',
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100230_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column T_100230_MISS_FIRST.statdate
  is 'ͳ������';
comment on column T_100230_MISS_FIRST.channelid
  is '����';
comment on column T_100230_MISS_FIRST.serverid
  is '����';
comment on column T_100230_MISS_FIRST.appid
  is '��ƷID';
comment on column T_100230_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column T_100230_MISS_FIRST.accountid
  is '�û�ID';
comment on column T_100230_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100230_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column T_100230_MISS_FIRST.issucc
  is '�Ƿ���ͨ��';
comment on column T_100230_MISS_FIRST.data_source
  is '������Դ';
create index IDX140_100230 on T_100230_MISS_FIRST (CHANNELID);
create index IDX141_100230 on T_100230_MISS_FIRST (SERVERID);
create index IDX142_100230 on T_100230_MISS_FIRST (STATDATE);

prompt
prompt Creating table T_100230_NU
prompt ==========================
prompt
create table T_100230_NU
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100230_NU
  is '�����û���Ϣ��';
comment on column T_100230_NU.thedate
  is '��������';
comment on column T_100230_NU.gameid
  is '��ϷID';
comment on column T_100230_NU.channelid
  is '����ID';
comment on column T_100230_NU.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100230_NU.serverid
  is '���ڷ�ID';
comment on column T_100230_NU.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100230_NU.position
  is '����λ��';
comment on column T_100230_NU.accountid
  is '�˺�ID';
create index IDX143_100230 on T_100230_NU (CHANNELID);
create index IDX144_100230 on T_100230_NU (SERVERID);
create index IDX145_100230 on T_100230_NU (THEDATE);

prompt
prompt Creating table T_100230_NU_ALLSERVER
prompt ====================================
prompt
create table T_100230_NU_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100230_NU_ALLSERVER
  is '�����û���Ϣ��ALLSERVER';
comment on column T_100230_NU_ALLSERVER.thedate
  is '��������';
comment on column T_100230_NU_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100230_NU_ALLSERVER.channelid
  is '����ID';
comment on column T_100230_NU_ALLSERVER.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100230_NU_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100230_NU_ALLSERVER.position
  is '����λ��';
comment on column T_100230_NU_ALLSERVER.accountid
  is '�˺�ID';
create index IDX194_100230 on T_100230_NU_ALLSERVER (CHANNELID);
create index IDX195_100230 on T_100230_NU_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100230_NU_DVID
prompt ===============================
prompt
create table T_100230_NU_DVID
(
  thedate   DATE not null,
  gameid    VARCHAR2(20) not null,
  channelid VARCHAR2(20) not null,
  dvid      VARCHAR2(50) not null,
  ipaddr    VARCHAR2(50)
)
;
comment on table T_100230_NU_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100230_NU_DVID.thedate
  is '����ʱ��';
comment on column T_100230_NU_DVID.gameid
  is '��ϷID';
comment on column T_100230_NU_DVID.channelid
  is '����ID';
comment on column T_100230_NU_DVID.dvid
  is '�豸ID';
comment on column T_100230_NU_DVID.ipaddr
  is 'IP';
create index IDX146_100230 on T_100230_NU_DVID (CHANNELID);
create index IDX147_100230 on T_100230_NU_DVID (THEDATE);

prompt
prompt Creating table T_100230_NU_MAC
prompt ==============================
prompt
create table T_100230_NU_MAC
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100230_NU_MAC
  is '�豸������';
comment on column T_100230_NU_MAC.thedate
  is '����ʱ��';
comment on column T_100230_NU_MAC.gameid
  is '��ϷID';
comment on column T_100230_NU_MAC.channelid
  is '����ID';
comment on column T_100230_NU_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100230_NU_MAC.serverid
  is '��������ID';
comment on column T_100230_NU_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100230_NU_MAC.position
  is 'λ����Ϣ';
comment on column T_100230_NU_MAC.dvid
  is '�豸ID';
create index IDX148_100230 on T_100230_NU_MAC (CHANNELID);
create index IDX149_100230 on T_100230_NU_MAC (SERVERID);
create index IDX150_100230 on T_100230_NU_MAC (THEDATE);

prompt
prompt Creating table T_100230_NU_MAC_ALLSERVER
prompt ========================================
prompt
create table T_100230_NU_MAC_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100230_NU_MAC_ALLSERVER
  is '�豸������ALLSERVER';
comment on column T_100230_NU_MAC_ALLSERVER.thedate
  is '����ʱ��';
comment on column T_100230_NU_MAC_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100230_NU_MAC_ALLSERVER.channelid
  is '����ID';
comment on column T_100230_NU_MAC_ALLSERVER.gameversion
  is '��Ϸ�汾';
comment on column T_100230_NU_MAC_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100230_NU_MAC_ALLSERVER.position
  is 'λ����Ϣ';
comment on column T_100230_NU_MAC_ALLSERVER.dvid
  is '�豸ID';
create index IDX196_100230 on T_100230_NU_MAC_ALLSERVER (CHANNELID);
create index IDX197_100230 on T_100230_NU_MAC_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100230_NU_PAY
prompt ==============================
prompt
create table T_100230_NU_PAY
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100230_NU_PAY
  is '�����û���';
comment on column T_100230_NU_PAY.thedate
  is '����ʱ��';
comment on column T_100230_NU_PAY.gameid
  is '��ϷID';
comment on column T_100230_NU_PAY.channelid
  is '����ID';
comment on column T_100230_NU_PAY.gameversion
  is '��Ϸ�汾';
comment on column T_100230_NU_PAY.serverid
  is '������Ϣ';
comment on column T_100230_NU_PAY.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100230_NU_PAY.position
  is 'λ����Ϣ';
comment on column T_100230_NU_PAY.accountid
  is '�˺�ID';
comment on column T_100230_NU_PAY.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100230_NU_PAY.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX151_100230 on T_100230_NU_PAY (CHANNELID);
create index IDX152_100230 on T_100230_NU_PAY (SERVERID);
create index IDX153_100230 on T_100230_NU_PAY (THEDATE);

prompt
prompt Creating table T_100230_NU_PAY_AS
prompt =================================
prompt
create table T_100230_NU_PAY_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100230_NU_PAY_AS
  is '�����û���allsever';
comment on column T_100230_NU_PAY_AS.thedate
  is '����ʱ��';
comment on column T_100230_NU_PAY_AS.gameid
  is '��ϷID';
comment on column T_100230_NU_PAY_AS.channelid
  is '����ID';
comment on column T_100230_NU_PAY_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100230_NU_PAY_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100230_NU_PAY_AS.position
  is 'λ����Ϣ';
comment on column T_100230_NU_PAY_AS.accountid
  is '�˺�ID';
comment on column T_100230_NU_PAY_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100230_NU_PAY_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX198_100230 on T_100230_NU_PAY_AS (CHANNELID);
create index IDX199_100230 on T_100230_NU_PAY_AS (THEDATE);

prompt
prompt Creating table T_100230_NU_PAY_MAC
prompt ==================================
prompt
create table T_100230_NU_PAY_MAC
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100230_NU_PAY_MAC
  is '�����û���';
comment on column T_100230_NU_PAY_MAC.thedate
  is '����ʱ��';
comment on column T_100230_NU_PAY_MAC.gameid
  is '��ϷID';
comment on column T_100230_NU_PAY_MAC.channelid
  is '����ID';
comment on column T_100230_NU_PAY_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100230_NU_PAY_MAC.serverid
  is '������Ϣ';
comment on column T_100230_NU_PAY_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100230_NU_PAY_MAC.position
  is 'λ����Ϣ';
comment on column T_100230_NU_PAY_MAC.dvid
  is '�豸ID';
comment on column T_100230_NU_PAY_MAC.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100230_NU_PAY_MAC.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX154_100230 on T_100230_NU_PAY_MAC (CHANNELID);
create index IDX155_100230 on T_100230_NU_PAY_MAC (SERVERID);
create index IDX156_100230 on T_100230_NU_PAY_MAC (THEDATE);

prompt
prompt Creating table T_100230_NU_PAY_MAC_AS
prompt =====================================
prompt
create table T_100230_NU_PAY_MAC_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100230_NU_PAY_MAC_AS
  is '�����û���ALLSERVER';
comment on column T_100230_NU_PAY_MAC_AS.thedate
  is '����ʱ��';
comment on column T_100230_NU_PAY_MAC_AS.gameid
  is '��ϷID';
comment on column T_100230_NU_PAY_MAC_AS.channelid
  is '����ID';
comment on column T_100230_NU_PAY_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100230_NU_PAY_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100230_NU_PAY_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100230_NU_PAY_MAC_AS.dvid
  is '�豸ID';
comment on column T_100230_NU_PAY_MAC_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100230_NU_PAY_MAC_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX200_100230 on T_100230_NU_PAY_MAC_AS (CHANNELID);
create index IDX201_100230 on T_100230_NU_PAY_MAC_AS (THEDATE);

prompt
prompt Creating table T_100230_ORDER_FAILURE
prompt =====================================
prompt
create table T_100230_ORDER_FAILURE
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100230_ORDER_FAILURE
  is '��ֵ�ɹ���¼��';
comment on column T_100230_ORDER_FAILURE.thedate
  is '��ֵʱ��';
comment on column T_100230_ORDER_FAILURE.gameid
  is '��ϷID';
comment on column T_100230_ORDER_FAILURE.channelid
  is '����ID';
comment on column T_100230_ORDER_FAILURE.gameversion
  is '��Ϸ�汾';
comment on column T_100230_ORDER_FAILURE.serverid
  is '��������';
comment on column T_100230_ORDER_FAILURE.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100230_ORDER_FAILURE.position
  is 'λ����Ϣ';
comment on column T_100230_ORDER_FAILURE.dvid
  is '�豸��';
comment on column T_100230_ORDER_FAILURE.accountid
  is '�˺�';
comment on column T_100230_ORDER_FAILURE.money
  is '��ֵ���';
comment on column T_100230_ORDER_FAILURE.vc
  is '��ֵ��õ����������';
comment on column T_100230_ORDER_FAILURE.orderid
  is '������';
comment on column T_100230_ORDER_FAILURE.paychannel
  is '֧������';
comment on column T_100230_ORDER_FAILURE.iapid
  is '��ֵ����  30  60';
create index IDX157_100230 on T_100230_ORDER_FAILURE (CHANNELID);
create index IDX158_100230 on T_100230_ORDER_FAILURE (SERVERID);
create index IDX159_100230 on T_100230_ORDER_FAILURE (THEDATE);

prompt
prompt Creating table T_100230_ORDER_SUCC
prompt ==================================
prompt
create table T_100230_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100230_ORDER_SUCC
  is '��ֵ�ɹ���¼��';
comment on column T_100230_ORDER_SUCC.thedate
  is '��ֵʱ��';
comment on column T_100230_ORDER_SUCC.gameid
  is '��ϷID';
comment on column T_100230_ORDER_SUCC.channelid
  is '����ID';
comment on column T_100230_ORDER_SUCC.gameversion
  is '��Ϸ�汾';
comment on column T_100230_ORDER_SUCC.serverid
  is '��������';
comment on column T_100230_ORDER_SUCC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100230_ORDER_SUCC.position
  is 'λ����Ϣ';
comment on column T_100230_ORDER_SUCC.dvid
  is '�豸��';
comment on column T_100230_ORDER_SUCC.accountid
  is '�˺�';
comment on column T_100230_ORDER_SUCC.money
  is '��ֵ���';
comment on column T_100230_ORDER_SUCC.vc
  is '��ֵ��õ����������';
comment on column T_100230_ORDER_SUCC.orderid
  is '������';
comment on column T_100230_ORDER_SUCC.paychannel
  is '֧������';
comment on column T_100230_ORDER_SUCC.iapid
  is '��ֵ����  30  60';
create index IDX160_100230 on T_100230_ORDER_SUCC (CHANNELID);
create index IDX161_100230 on T_100230_ORDER_SUCC (SERVERID);
create index IDX162_100230 on T_100230_ORDER_SUCC (THEDATE);

prompt
prompt Creating table T_100230_VC
prompt ==========================
prompt
create table T_100230_VC
(
  statdate    DATE,
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcchange    NUMBER,
  vcbefore    NUMBER,
  vcafter     NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100230_VC
  is '������ұ仯������';
comment on column T_100230_VC.statdate
  is 'ͳ������';
comment on column T_100230_VC.channelid
  is '����';
comment on column T_100230_VC.serverid
  is '����';
comment on column T_100230_VC.appid
  is '��Ʒid';
comment on column T_100230_VC.versionid
  is '��Ʒ�汾';
comment on column T_100230_VC.accountid
  is '�û�ID';
comment on column T_100230_VC.vctype
  is '�����������';
comment on column T_100230_VC.vcusetype
  is '�������ʹ������';
comment on column T_100230_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column T_100230_VC.vcchange
  is '������ұ仯���';
comment on column T_100230_VC.vcbefore
  is '������ұ仯ǰ���';
comment on column T_100230_VC.vcafter
  is '������ұ仯����';
comment on column T_100230_VC.data_source
  is '������Դ';
create index IDX163_100230 on T_100230_VC (CHANNELID);
create index IDX164_100230 on T_100230_VC (SERVERID);
create index IDX165_100230 on T_100230_VC (STATDATE);

prompt
prompt Creating table T_100231_CEVENT
prompt ==============================
prompt
create table T_100231_CEVENT
(
  thedate          VARCHAR2(10),
  datenum          NUMBER,
  appid            VARCHAR2(10),
  channelid        VARCHAR2(50),
  gameversion      VARCHAR2(50),
  dvid             VARCHAR2(50),
  accountid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  ilevel           NUMBER,
  roleid           VARCHAR2(50),
  eventkey         VARCHAR2(100),
  eventvalue_key   VARCHAR2(100),
  eventvalue_value VARCHAR2(100),
  ipaddr           VARCHAR2(50),
  prerowid         VARCHAR2(200)
)
;
comment on table T_100231_CEVENT
  is '�Զ����¼���ֱ�';
comment on column T_100231_CEVENT.thedate
  is '����';
comment on column T_100231_CEVENT.datenum
  is '�������ָ�ʽ';
comment on column T_100231_CEVENT.appid
  is '��Ϸ�� appid';
comment on column T_100231_CEVENT.channelid
  is '���� ID';
comment on column T_100231_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column T_100231_CEVENT.dvid
  is '�豸 ID��Ψһ�豸��';
comment on column T_100231_CEVENT.accountid
  is '�ʻ� id';
comment on column T_100231_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column T_100231_CEVENT.ilevel
  is '��ҵȼ�';
comment on column T_100231_CEVENT.roleid
  is '��ɫ id';
comment on column T_100231_CEVENT.eventkey
  is '�¼�����';
comment on column T_100231_CEVENT.eventvalue_key
  is '�¼�ֵ�е�key';
comment on column T_100231_CEVENT.eventvalue_value
  is '�¼�ֵ��key��Ӧ��ֵ';
comment on column T_100231_CEVENT.ipaddr
  is 'ip ��ַ';
comment on column T_100231_CEVENT.prerowid
  is 'ԭΨһ��ID';
create index IDX180_100231 on T_100231_CEVENT (THEDATE);

prompt
prompt Creating table T_100231_CONN
prompt ============================
prompt
create table T_100231_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100231_CONN
  is '����&��ʧ&������������������ע���˺ţ�ע���豸��';
comment on column T_100231_CONN.conndate
  is '����ʱ��';
comment on column T_100231_CONN.gameid
  is '��ϷID';
comment on column T_100231_CONN.channelid
  is '����ID';
comment on column T_100231_CONN.gameversion
  is '��Ϸ�汾';
comment on column T_100231_CONN.serverid
  is '����ID';
comment on column T_100231_CONN.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100231_CONN.position
  is 'λ����Ϣ';
comment on column T_100231_CONN.dvid
  is '�豸��';
comment on column T_100231_CONN.accountid
  is '�˺�ID';
comment on column T_100231_CONN.regdate
  is 'ע��ʱ��';
comment on column T_100231_CONN.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100231_CONN.regdate_as
  is '���з��������ע��ʱ��';
create index IDX118_100231 on T_100231_CONN (CHANNELID);
create index IDX119_100231 on T_100231_CONN (SERVERID);
create index IDX120_100231 on T_100231_CONN (CONNDATE);

prompt
prompt Creating table T_100231_CONN_ACT
prompt ================================
prompt
create table T_100231_CONN_ACT
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100231_CONN_ACT
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100231_CONN_ACT.basedate
  is '����ʱ��';
comment on column T_100231_CONN_ACT.gameid
  is '��ϷID';
comment on column T_100231_CONN_ACT.channelid
  is '����ID';
comment on column T_100231_CONN_ACT.gameversion
  is '��Ϸ�汾';
comment on column T_100231_CONN_ACT.serverid
  is '����ID';
comment on column T_100231_CONN_ACT.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100231_CONN_ACT.position
  is 'λ����Ϣ';
comment on column T_100231_CONN_ACT.dvid
  is '�豸��';
comment on column T_100231_CONN_ACT.accountid
  is '�˺�';
comment on column T_100231_CONN_ACT.conndate
  is '��Ծʱ��';
comment on column T_100231_CONN_ACT.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_100231 on T_100231_CONN_ACT (CHANNELID);
create index IDX122_100231 on T_100231_CONN_ACT (SERVERID);
create index IDX123_100231 on T_100231_CONN_ACT (CONNDATE);
create index IDX124_100231 on T_100231_CONN_ACT (BASEDATE);

prompt
prompt Creating table T_100231_CONN_ACT_AS
prompt ===================================
prompt
create table T_100231_CONN_ACT_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100231_CONN_ACT_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100231_CONN_ACT_AS.basedate
  is '����ʱ��';
comment on column T_100231_CONN_ACT_AS.gameid
  is '��ϷID';
comment on column T_100231_CONN_ACT_AS.channelid
  is '����ID';
comment on column T_100231_CONN_ACT_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100231_CONN_ACT_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100231_CONN_ACT_AS.position
  is 'λ����Ϣ';
comment on column T_100231_CONN_ACT_AS.dvid
  is '�豸��';
comment on column T_100231_CONN_ACT_AS.accountid
  is '�˺�';
comment on column T_100231_CONN_ACT_AS.conndate
  is '��Ծʱ��';
comment on column T_100231_CONN_ACT_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX205_100231 on T_100231_CONN_ACT_AS (CHANNELID);
create index IDX206_100231 on T_100231_CONN_ACT_AS (CONNDATE);
create index IDX207_100231 on T_100231_CONN_ACT_AS (BASEDATE);

prompt
prompt Creating table T_100231_CONN_ACT_MAC
prompt ====================================
prompt
create table T_100231_CONN_ACT_MAC
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100231_CONN_ACT_MAC
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100231_CONN_ACT_MAC.basedate
  is '����ʱ��';
comment on column T_100231_CONN_ACT_MAC.gameid
  is '��ϷID';
comment on column T_100231_CONN_ACT_MAC.channelid
  is '����ID';
comment on column T_100231_CONN_ACT_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100231_CONN_ACT_MAC.serverid
  is '����ID';
comment on column T_100231_CONN_ACT_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100231_CONN_ACT_MAC.position
  is 'λ����Ϣ';
comment on column T_100231_CONN_ACT_MAC.dvid
  is '�豸��';
comment on column T_100231_CONN_ACT_MAC.accountid
  is '�˺�';
comment on column T_100231_CONN_ACT_MAC.conndate
  is '��Ծʱ��';
comment on column T_100231_CONN_ACT_MAC.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_100231 on T_100231_CONN_ACT_MAC (CHANNELID);
create index IDX126_100231 on T_100231_CONN_ACT_MAC (SERVERID);
create index IDX127_100231 on T_100231_CONN_ACT_MAC (CONNDATE);
create index IDX128_100231 on T_100231_CONN_ACT_MAC (BASEDATE);

prompt
prompt Creating table T_100231_CONN_ACT_MAC_AS
prompt =======================================
prompt
create table T_100231_CONN_ACT_MAC_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100231_CONN_ACT_MAC_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100231_CONN_ACT_MAC_AS.basedate
  is '����ʱ��';
comment on column T_100231_CONN_ACT_MAC_AS.gameid
  is '��ϷID';
comment on column T_100231_CONN_ACT_MAC_AS.channelid
  is '����ID';
comment on column T_100231_CONN_ACT_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100231_CONN_ACT_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100231_CONN_ACT_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100231_CONN_ACT_MAC_AS.dvid
  is '�豸��';
comment on column T_100231_CONN_ACT_MAC_AS.accountid
  is '�˺�';
comment on column T_100231_CONN_ACT_MAC_AS.conndate
  is '��Ծʱ��';
comment on column T_100231_CONN_ACT_MAC_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX202_100231 on T_100231_CONN_ACT_MAC_AS (CHANNELID);
create index IDX203_100231 on T_100231_CONN_ACT_MAC_AS (CONNDATE);
create index IDX204_100231 on T_100231_CONN_ACT_MAC_AS (BASEDATE);

prompt
prompt Creating table T_100231_CONN_DVID
prompt =================================
prompt
create table T_100231_CONN_DVID
(
  conndate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  dvid      VARCHAR2(50),
  regdate   VARCHAR2(10)
)
;
comment on table T_100231_CONN_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100231_CONN_DVID.conndate
  is '����ʱ��';
comment on column T_100231_CONN_DVID.gameid
  is '��ϷID';
comment on column T_100231_CONN_DVID.channelid
  is '����ID';
comment on column T_100231_CONN_DVID.dvid
  is '�豸��';
comment on column T_100231_CONN_DVID.regdate
  is 'ע��ʱ��';
create index IDX129_100231 on T_100231_CONN_DVID (CHANNELID);
create index IDX130_100231 on T_100231_CONN_DVID (CONNDATE);

prompt
prompt Creating table T_100231_CONN_MAC
prompt ================================
prompt
create table T_100231_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100231_CONN_MAC
  is '���� ��ʧ ������������������ע���˺ţ�ע���豸��';
comment on column T_100231_CONN_MAC.conndate
  is '����ʱ��';
comment on column T_100231_CONN_MAC.gameid
  is '��ϷID';
comment on column T_100231_CONN_MAC.channelid
  is '����ID';
comment on column T_100231_CONN_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100231_CONN_MAC.serverid
  is '����ID';
comment on column T_100231_CONN_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100231_CONN_MAC.position
  is 'λ����Ϣ';
comment on column T_100231_CONN_MAC.dvid
  is '�豸��';
comment on column T_100231_CONN_MAC.accountid
  is '�˺�ID';
comment on column T_100231_CONN_MAC.regdate
  is 'ע��ʱ��';
comment on column T_100231_CONN_MAC.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100231_CONN_MAC.regdate_as
  is '���з��������ע��ʱ��';
create index IDX131_100231 on T_100231_CONN_MAC (CHANNELID);
create index IDX132_100231 on T_100231_CONN_MAC (SERVERID);
create index IDX133_100231 on T_100231_CONN_MAC (CONNDATE);

prompt
prompt Creating table T_100231_LOST_MAC
prompt ================================
prompt
create table T_100231_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100231_LOST_MAC
  is '�豸�ȼ���ʧ������';
comment on column T_100231_LOST_MAC.statdate
  is '�����������';
comment on column T_100231_LOST_MAC.lost_date
  is '��ʧ����';
comment on column T_100231_LOST_MAC.channelid
  is '����';
comment on column T_100231_LOST_MAC.serverid
  is '����';
comment on column T_100231_LOST_MAC.appid
  is '��Ʒid';
comment on column T_100231_LOST_MAC.macid
  is '�豸id';
comment on column T_100231_LOST_MAC.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100231_LOST_MAC.lost_days
  is '��ʧ����';
comment on column T_100231_LOST_MAC.data_source
  is '������Դ';
create index IDX134_100231 on T_100231_LOST_MAC (CHANNELID);
create index IDX135_100231 on T_100231_LOST_MAC (SERVERID);
create index IDX136_100231 on T_100231_LOST_MAC (STATDATE);

prompt
prompt Creating table T_100231_LOST_MAC_AS
prompt ===================================
prompt
create table T_100231_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100231_LOST_MAC_AS
  is '�豸�ȼ���ʧ������allserver';
comment on column T_100231_LOST_MAC_AS.statdate
  is '�����������';
comment on column T_100231_LOST_MAC_AS.lost_date
  is '��ʧ����';
comment on column T_100231_LOST_MAC_AS.channelid
  is '����';
comment on column T_100231_LOST_MAC_AS.appid
  is '��Ʒid';
comment on column T_100231_LOST_MAC_AS.macid
  is '�豸id';
comment on column T_100231_LOST_MAC_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100231_LOST_MAC_AS.lost_days
  is '��ʧ����';
comment on column T_100231_LOST_MAC_AS.data_source
  is '������Դ';
create index IDX210_100231 on T_100231_LOST_MAC_AS (CHANNELID);
create index IDX211_100231 on T_100231_LOST_MAC_AS (STATDATE);

prompt
prompt Creating table T_100231_LOST_USER
prompt =================================
prompt
create table T_100231_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100231_LOST_USER
  is '�û��ȼ���ʧ������';
comment on column T_100231_LOST_USER.statdate
  is '�����������';
comment on column T_100231_LOST_USER.lost_date
  is '��ʧ����';
comment on column T_100231_LOST_USER.channelid
  is '����';
comment on column T_100231_LOST_USER.serverid
  is '����';
comment on column T_100231_LOST_USER.appid
  is '��Ʒid';
comment on column T_100231_LOST_USER.userid
  is '�û�id';
comment on column T_100231_LOST_USER.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100231_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100231_LOST_USER.lost_days
  is '��ʧ����';
comment on column T_100231_LOST_USER.data_source
  is '������Դ';
create index IDX137_100231 on T_100231_LOST_USER (CHANNELID);
create index IDX138_100231 on T_100231_LOST_USER (SERVERID);
create index IDX139_100231 on T_100231_LOST_USER (STATDATE);

prompt
prompt Creating table T_100231_LOST_USER_AS
prompt ====================================
prompt
create table T_100231_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100231_LOST_USER_AS
  is '�û��ȼ���ʧ������allserver';
comment on column T_100231_LOST_USER_AS.statdate
  is '�����������';
comment on column T_100231_LOST_USER_AS.lost_date
  is '��ʧ����';
comment on column T_100231_LOST_USER_AS.channelid
  is '����';
comment on column T_100231_LOST_USER_AS.appid
  is '��Ʒid';
comment on column T_100231_LOST_USER_AS.userid
  is '�û�id';
comment on column T_100231_LOST_USER_AS.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100231_LOST_USER_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100231_LOST_USER_AS.lost_days
  is '��ʧ����';
comment on column T_100231_LOST_USER_AS.data_source
  is '������Դ';
create index IDX208_100231 on T_100231_LOST_USER_AS (CHANNELID);
create index IDX209_100231 on T_100231_LOST_USER_AS (STATDATE);

prompt
prompt Creating table T_100231_MISS_FIRST
prompt ==================================
prompt
create table T_100231_MISS_FIRST
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50) default '0',
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100231_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column T_100231_MISS_FIRST.statdate
  is 'ͳ������';
comment on column T_100231_MISS_FIRST.channelid
  is '����';
comment on column T_100231_MISS_FIRST.serverid
  is '����';
comment on column T_100231_MISS_FIRST.appid
  is '��ƷID';
comment on column T_100231_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column T_100231_MISS_FIRST.accountid
  is '�û�ID';
comment on column T_100231_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100231_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column T_100231_MISS_FIRST.issucc
  is '�Ƿ���ͨ��';
comment on column T_100231_MISS_FIRST.data_source
  is '������Դ';
create index IDX140_100231 on T_100231_MISS_FIRST (CHANNELID);
create index IDX141_100231 on T_100231_MISS_FIRST (SERVERID);
create index IDX142_100231 on T_100231_MISS_FIRST (STATDATE);

prompt
prompt Creating table T_100231_NU
prompt ==========================
prompt
create table T_100231_NU
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100231_NU
  is '�����û���Ϣ��';
comment on column T_100231_NU.thedate
  is '��������';
comment on column T_100231_NU.gameid
  is '��ϷID';
comment on column T_100231_NU.channelid
  is '����ID';
comment on column T_100231_NU.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100231_NU.serverid
  is '���ڷ�ID';
comment on column T_100231_NU.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100231_NU.position
  is '����λ��';
comment on column T_100231_NU.accountid
  is '�˺�ID';
create index IDX143_100231 on T_100231_NU (CHANNELID);
create index IDX144_100231 on T_100231_NU (SERVERID);
create index IDX145_100231 on T_100231_NU (THEDATE);

prompt
prompt Creating table T_100231_NU_ALLSERVER
prompt ====================================
prompt
create table T_100231_NU_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100231_NU_ALLSERVER
  is '�����û���Ϣ��ALLSERVER';
comment on column T_100231_NU_ALLSERVER.thedate
  is '��������';
comment on column T_100231_NU_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100231_NU_ALLSERVER.channelid
  is '����ID';
comment on column T_100231_NU_ALLSERVER.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100231_NU_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100231_NU_ALLSERVER.position
  is '����λ��';
comment on column T_100231_NU_ALLSERVER.accountid
  is '�˺�ID';
create index IDX194_100231 on T_100231_NU_ALLSERVER (CHANNELID);
create index IDX195_100231 on T_100231_NU_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100231_NU_DVID
prompt ===============================
prompt
create table T_100231_NU_DVID
(
  thedate   DATE not null,
  gameid    VARCHAR2(20) not null,
  channelid VARCHAR2(20) not null,
  dvid      VARCHAR2(50) not null,
  ipaddr    VARCHAR2(50)
)
;
comment on table T_100231_NU_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100231_NU_DVID.thedate
  is '����ʱ��';
comment on column T_100231_NU_DVID.gameid
  is '��ϷID';
comment on column T_100231_NU_DVID.channelid
  is '����ID';
comment on column T_100231_NU_DVID.dvid
  is '�豸ID';
comment on column T_100231_NU_DVID.ipaddr
  is 'IP';
create index IDX146_100231 on T_100231_NU_DVID (CHANNELID);
create index IDX147_100231 on T_100231_NU_DVID (THEDATE);

prompt
prompt Creating table T_100231_NU_MAC
prompt ==============================
prompt
create table T_100231_NU_MAC
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100231_NU_MAC
  is '�豸������';
comment on column T_100231_NU_MAC.thedate
  is '����ʱ��';
comment on column T_100231_NU_MAC.gameid
  is '��ϷID';
comment on column T_100231_NU_MAC.channelid
  is '����ID';
comment on column T_100231_NU_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100231_NU_MAC.serverid
  is '��������ID';
comment on column T_100231_NU_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100231_NU_MAC.position
  is 'λ����Ϣ';
comment on column T_100231_NU_MAC.dvid
  is '�豸ID';
create index IDX148_100231 on T_100231_NU_MAC (CHANNELID);
create index IDX149_100231 on T_100231_NU_MAC (SERVERID);
create index IDX150_100231 on T_100231_NU_MAC (THEDATE);

prompt
prompt Creating table T_100231_NU_MAC_ALLSERVER
prompt ========================================
prompt
create table T_100231_NU_MAC_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100231_NU_MAC_ALLSERVER
  is '�豸������ALLSERVER';
comment on column T_100231_NU_MAC_ALLSERVER.thedate
  is '����ʱ��';
comment on column T_100231_NU_MAC_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100231_NU_MAC_ALLSERVER.channelid
  is '����ID';
comment on column T_100231_NU_MAC_ALLSERVER.gameversion
  is '��Ϸ�汾';
comment on column T_100231_NU_MAC_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100231_NU_MAC_ALLSERVER.position
  is 'λ����Ϣ';
comment on column T_100231_NU_MAC_ALLSERVER.dvid
  is '�豸ID';
create index IDX196_100231 on T_100231_NU_MAC_ALLSERVER (CHANNELID);
create index IDX197_100231 on T_100231_NU_MAC_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100231_NU_PAY
prompt ==============================
prompt
create table T_100231_NU_PAY
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100231_NU_PAY
  is '�����û���';
comment on column T_100231_NU_PAY.thedate
  is '����ʱ��';
comment on column T_100231_NU_PAY.gameid
  is '��ϷID';
comment on column T_100231_NU_PAY.channelid
  is '����ID';
comment on column T_100231_NU_PAY.gameversion
  is '��Ϸ�汾';
comment on column T_100231_NU_PAY.serverid
  is '������Ϣ';
comment on column T_100231_NU_PAY.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100231_NU_PAY.position
  is 'λ����Ϣ';
comment on column T_100231_NU_PAY.accountid
  is '�˺�ID';
comment on column T_100231_NU_PAY.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100231_NU_PAY.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX151_100231 on T_100231_NU_PAY (CHANNELID);
create index IDX152_100231 on T_100231_NU_PAY (SERVERID);
create index IDX153_100231 on T_100231_NU_PAY (THEDATE);

prompt
prompt Creating table T_100231_NU_PAY_AS
prompt =================================
prompt
create table T_100231_NU_PAY_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100231_NU_PAY_AS
  is '�����û���allsever';
comment on column T_100231_NU_PAY_AS.thedate
  is '����ʱ��';
comment on column T_100231_NU_PAY_AS.gameid
  is '��ϷID';
comment on column T_100231_NU_PAY_AS.channelid
  is '����ID';
comment on column T_100231_NU_PAY_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100231_NU_PAY_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100231_NU_PAY_AS.position
  is 'λ����Ϣ';
comment on column T_100231_NU_PAY_AS.accountid
  is '�˺�ID';
comment on column T_100231_NU_PAY_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100231_NU_PAY_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX198_100231 on T_100231_NU_PAY_AS (CHANNELID);
create index IDX199_100231 on T_100231_NU_PAY_AS (THEDATE);

prompt
prompt Creating table T_100231_NU_PAY_MAC
prompt ==================================
prompt
create table T_100231_NU_PAY_MAC
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100231_NU_PAY_MAC
  is '�����û���';
comment on column T_100231_NU_PAY_MAC.thedate
  is '����ʱ��';
comment on column T_100231_NU_PAY_MAC.gameid
  is '��ϷID';
comment on column T_100231_NU_PAY_MAC.channelid
  is '����ID';
comment on column T_100231_NU_PAY_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100231_NU_PAY_MAC.serverid
  is '������Ϣ';
comment on column T_100231_NU_PAY_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100231_NU_PAY_MAC.position
  is 'λ����Ϣ';
comment on column T_100231_NU_PAY_MAC.dvid
  is '�豸ID';
comment on column T_100231_NU_PAY_MAC.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100231_NU_PAY_MAC.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX154_100231 on T_100231_NU_PAY_MAC (CHANNELID);
create index IDX155_100231 on T_100231_NU_PAY_MAC (SERVERID);
create index IDX156_100231 on T_100231_NU_PAY_MAC (THEDATE);

prompt
prompt Creating table T_100231_NU_PAY_MAC_AS
prompt =====================================
prompt
create table T_100231_NU_PAY_MAC_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100231_NU_PAY_MAC_AS
  is '�����û���ALLSERVER';
comment on column T_100231_NU_PAY_MAC_AS.thedate
  is '����ʱ��';
comment on column T_100231_NU_PAY_MAC_AS.gameid
  is '��ϷID';
comment on column T_100231_NU_PAY_MAC_AS.channelid
  is '����ID';
comment on column T_100231_NU_PAY_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100231_NU_PAY_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100231_NU_PAY_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100231_NU_PAY_MAC_AS.dvid
  is '�豸ID';
comment on column T_100231_NU_PAY_MAC_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100231_NU_PAY_MAC_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX200_100231 on T_100231_NU_PAY_MAC_AS (CHANNELID);
create index IDX201_100231 on T_100231_NU_PAY_MAC_AS (THEDATE);

prompt
prompt Creating table T_100231_ORDER_FAILURE
prompt =====================================
prompt
create table T_100231_ORDER_FAILURE
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100231_ORDER_FAILURE
  is '��ֵ�ɹ���¼��';
comment on column T_100231_ORDER_FAILURE.thedate
  is '��ֵʱ��';
comment on column T_100231_ORDER_FAILURE.gameid
  is '��ϷID';
comment on column T_100231_ORDER_FAILURE.channelid
  is '����ID';
comment on column T_100231_ORDER_FAILURE.gameversion
  is '��Ϸ�汾';
comment on column T_100231_ORDER_FAILURE.serverid
  is '��������';
comment on column T_100231_ORDER_FAILURE.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100231_ORDER_FAILURE.position
  is 'λ����Ϣ';
comment on column T_100231_ORDER_FAILURE.dvid
  is '�豸��';
comment on column T_100231_ORDER_FAILURE.accountid
  is '�˺�';
comment on column T_100231_ORDER_FAILURE.money
  is '��ֵ���';
comment on column T_100231_ORDER_FAILURE.vc
  is '��ֵ��õ����������';
comment on column T_100231_ORDER_FAILURE.orderid
  is '������';
comment on column T_100231_ORDER_FAILURE.paychannel
  is '֧������';
comment on column T_100231_ORDER_FAILURE.iapid
  is '��ֵ����  30  60';
create index IDX157_100231 on T_100231_ORDER_FAILURE (CHANNELID);
create index IDX158_100231 on T_100231_ORDER_FAILURE (SERVERID);
create index IDX159_100231 on T_100231_ORDER_FAILURE (THEDATE);

prompt
prompt Creating table T_100231_ORDER_SUCC
prompt ==================================
prompt
create table T_100231_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100231_ORDER_SUCC
  is '��ֵ�ɹ���¼��';
comment on column T_100231_ORDER_SUCC.thedate
  is '��ֵʱ��';
comment on column T_100231_ORDER_SUCC.gameid
  is '��ϷID';
comment on column T_100231_ORDER_SUCC.channelid
  is '����ID';
comment on column T_100231_ORDER_SUCC.gameversion
  is '��Ϸ�汾';
comment on column T_100231_ORDER_SUCC.serverid
  is '��������';
comment on column T_100231_ORDER_SUCC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100231_ORDER_SUCC.position
  is 'λ����Ϣ';
comment on column T_100231_ORDER_SUCC.dvid
  is '�豸��';
comment on column T_100231_ORDER_SUCC.accountid
  is '�˺�';
comment on column T_100231_ORDER_SUCC.money
  is '��ֵ���';
comment on column T_100231_ORDER_SUCC.vc
  is '��ֵ��õ����������';
comment on column T_100231_ORDER_SUCC.orderid
  is '������';
comment on column T_100231_ORDER_SUCC.paychannel
  is '֧������';
comment on column T_100231_ORDER_SUCC.iapid
  is '��ֵ����  30  60';
create index IDX160_100231 on T_100231_ORDER_SUCC (CHANNELID);
create index IDX161_100231 on T_100231_ORDER_SUCC (SERVERID);
create index IDX162_100231 on T_100231_ORDER_SUCC (THEDATE);

prompt
prompt Creating table T_100231_VC
prompt ==========================
prompt
create table T_100231_VC
(
  statdate    DATE,
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcchange    NUMBER,
  vcbefore    NUMBER,
  vcafter     NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100231_VC
  is '������ұ仯������';
comment on column T_100231_VC.statdate
  is 'ͳ������';
comment on column T_100231_VC.channelid
  is '����';
comment on column T_100231_VC.serverid
  is '����';
comment on column T_100231_VC.appid
  is '��Ʒid';
comment on column T_100231_VC.versionid
  is '��Ʒ�汾';
comment on column T_100231_VC.accountid
  is '�û�ID';
comment on column T_100231_VC.vctype
  is '�����������';
comment on column T_100231_VC.vcusetype
  is '�������ʹ������';
comment on column T_100231_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column T_100231_VC.vcchange
  is '������ұ仯���';
comment on column T_100231_VC.vcbefore
  is '������ұ仯ǰ���';
comment on column T_100231_VC.vcafter
  is '������ұ仯����';
comment on column T_100231_VC.data_source
  is '������Դ';
create index IDX163_100231 on T_100231_VC (CHANNELID);
create index IDX164_100231 on T_100231_VC (SERVERID);
create index IDX165_100231 on T_100231_VC (STATDATE);

prompt
prompt Creating table T_100241_CEVENT
prompt ==============================
prompt
create table T_100241_CEVENT
(
  thedate          VARCHAR2(10),
  datenum          NUMBER,
  appid            VARCHAR2(10),
  channelid        VARCHAR2(50),
  gameversion      VARCHAR2(50),
  dvid             VARCHAR2(50),
  accountid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  ilevel           NUMBER,
  roleid           VARCHAR2(50),
  eventkey         VARCHAR2(100),
  eventvalue_key   VARCHAR2(100),
  eventvalue_value VARCHAR2(100),
  ipaddr           VARCHAR2(50),
  prerowid         VARCHAR2(200)
)
;
comment on table T_100241_CEVENT
  is '�Զ����¼���ֱ�';
comment on column T_100241_CEVENT.thedate
  is '����';
comment on column T_100241_CEVENT.datenum
  is '�������ָ�ʽ';
comment on column T_100241_CEVENT.appid
  is '��Ϸ�� appid';
comment on column T_100241_CEVENT.channelid
  is '���� ID';
comment on column T_100241_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column T_100241_CEVENT.dvid
  is '�豸 ID��Ψһ�豸��';
comment on column T_100241_CEVENT.accountid
  is '�ʻ� id';
comment on column T_100241_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column T_100241_CEVENT.ilevel
  is '��ҵȼ�';
comment on column T_100241_CEVENT.roleid
  is '��ɫ id';
comment on column T_100241_CEVENT.eventkey
  is '�¼�����';
comment on column T_100241_CEVENT.eventvalue_key
  is '�¼�ֵ�е�key';
comment on column T_100241_CEVENT.eventvalue_value
  is '�¼�ֵ��key��Ӧ��ֵ';
comment on column T_100241_CEVENT.ipaddr
  is 'ip ��ַ';
comment on column T_100241_CEVENT.prerowid
  is 'ԭΨһ��ID';
create index IDX180_100241 on T_100241_CEVENT (THEDATE);

prompt
prompt Creating table T_100241_CONN
prompt ============================
prompt
create table T_100241_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100241_CONN
  is '����&��ʧ&������������������ע���˺ţ�ע���豸��';
comment on column T_100241_CONN.conndate
  is '����ʱ��';
comment on column T_100241_CONN.gameid
  is '��ϷID';
comment on column T_100241_CONN.channelid
  is '����ID';
comment on column T_100241_CONN.gameversion
  is '��Ϸ�汾';
comment on column T_100241_CONN.serverid
  is '����ID';
comment on column T_100241_CONN.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100241_CONN.position
  is 'λ����Ϣ';
comment on column T_100241_CONN.dvid
  is '�豸��';
comment on column T_100241_CONN.accountid
  is '�˺�ID';
comment on column T_100241_CONN.regdate
  is 'ע��ʱ��';
comment on column T_100241_CONN.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100241_CONN.regdate_as
  is '���з��������ע��ʱ��';
create index IDX118_100241 on T_100241_CONN (CHANNELID);
create index IDX119_100241 on T_100241_CONN (SERVERID);
create index IDX120_100241 on T_100241_CONN (CONNDATE);

prompt
prompt Creating table T_100241_CONN_ACT
prompt ================================
prompt
create table T_100241_CONN_ACT
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100241_CONN_ACT
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100241_CONN_ACT.basedate
  is '����ʱ��';
comment on column T_100241_CONN_ACT.gameid
  is '��ϷID';
comment on column T_100241_CONN_ACT.channelid
  is '����ID';
comment on column T_100241_CONN_ACT.gameversion
  is '��Ϸ�汾';
comment on column T_100241_CONN_ACT.serverid
  is '����ID';
comment on column T_100241_CONN_ACT.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100241_CONN_ACT.position
  is 'λ����Ϣ';
comment on column T_100241_CONN_ACT.dvid
  is '�豸��';
comment on column T_100241_CONN_ACT.accountid
  is '�˺�';
comment on column T_100241_CONN_ACT.conndate
  is '��Ծʱ��';
comment on column T_100241_CONN_ACT.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_100241 on T_100241_CONN_ACT (CHANNELID);
create index IDX122_100241 on T_100241_CONN_ACT (SERVERID);
create index IDX123_100241 on T_100241_CONN_ACT (CONNDATE);
create index IDX124_100241 on T_100241_CONN_ACT (BASEDATE);

prompt
prompt Creating table T_100241_CONN_ACT_AS
prompt ===================================
prompt
create table T_100241_CONN_ACT_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100241_CONN_ACT_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100241_CONN_ACT_AS.basedate
  is '����ʱ��';
comment on column T_100241_CONN_ACT_AS.gameid
  is '��ϷID';
comment on column T_100241_CONN_ACT_AS.channelid
  is '����ID';
comment on column T_100241_CONN_ACT_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100241_CONN_ACT_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100241_CONN_ACT_AS.position
  is 'λ����Ϣ';
comment on column T_100241_CONN_ACT_AS.dvid
  is '�豸��';
comment on column T_100241_CONN_ACT_AS.accountid
  is '�˺�';
comment on column T_100241_CONN_ACT_AS.conndate
  is '��Ծʱ��';
comment on column T_100241_CONN_ACT_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX205_100241 on T_100241_CONN_ACT_AS (CHANNELID);
create index IDX206_100241 on T_100241_CONN_ACT_AS (CONNDATE);
create index IDX207_100241 on T_100241_CONN_ACT_AS (BASEDATE);

prompt
prompt Creating table T_100241_CONN_ACT_MAC
prompt ====================================
prompt
create table T_100241_CONN_ACT_MAC
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100241_CONN_ACT_MAC
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100241_CONN_ACT_MAC.basedate
  is '����ʱ��';
comment on column T_100241_CONN_ACT_MAC.gameid
  is '��ϷID';
comment on column T_100241_CONN_ACT_MAC.channelid
  is '����ID';
comment on column T_100241_CONN_ACT_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100241_CONN_ACT_MAC.serverid
  is '����ID';
comment on column T_100241_CONN_ACT_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100241_CONN_ACT_MAC.position
  is 'λ����Ϣ';
comment on column T_100241_CONN_ACT_MAC.dvid
  is '�豸��';
comment on column T_100241_CONN_ACT_MAC.accountid
  is '�˺�';
comment on column T_100241_CONN_ACT_MAC.conndate
  is '��Ծʱ��';
comment on column T_100241_CONN_ACT_MAC.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_100241 on T_100241_CONN_ACT_MAC (CHANNELID);
create index IDX126_100241 on T_100241_CONN_ACT_MAC (SERVERID);
create index IDX127_100241 on T_100241_CONN_ACT_MAC (CONNDATE);
create index IDX128_100241 on T_100241_CONN_ACT_MAC (BASEDATE);

prompt
prompt Creating table T_100241_CONN_ACT_MAC_AS
prompt =======================================
prompt
create table T_100241_CONN_ACT_MAC_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100241_CONN_ACT_MAC_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100241_CONN_ACT_MAC_AS.basedate
  is '����ʱ��';
comment on column T_100241_CONN_ACT_MAC_AS.gameid
  is '��ϷID';
comment on column T_100241_CONN_ACT_MAC_AS.channelid
  is '����ID';
comment on column T_100241_CONN_ACT_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100241_CONN_ACT_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100241_CONN_ACT_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100241_CONN_ACT_MAC_AS.dvid
  is '�豸��';
comment on column T_100241_CONN_ACT_MAC_AS.accountid
  is '�˺�';
comment on column T_100241_CONN_ACT_MAC_AS.conndate
  is '��Ծʱ��';
comment on column T_100241_CONN_ACT_MAC_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX202_100241 on T_100241_CONN_ACT_MAC_AS (CHANNELID);
create index IDX203_100241 on T_100241_CONN_ACT_MAC_AS (CONNDATE);
create index IDX204_100241 on T_100241_CONN_ACT_MAC_AS (BASEDATE);

prompt
prompt Creating table T_100241_CONN_DVID
prompt =================================
prompt
create table T_100241_CONN_DVID
(
  conndate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  dvid      VARCHAR2(50),
  regdate   VARCHAR2(10)
)
;
comment on table T_100241_CONN_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100241_CONN_DVID.conndate
  is '����ʱ��';
comment on column T_100241_CONN_DVID.gameid
  is '��ϷID';
comment on column T_100241_CONN_DVID.channelid
  is '����ID';
comment on column T_100241_CONN_DVID.dvid
  is '�豸��';
comment on column T_100241_CONN_DVID.regdate
  is 'ע��ʱ��';
create index IDX129_100241 on T_100241_CONN_DVID (CHANNELID);
create index IDX130_100241 on T_100241_CONN_DVID (CONNDATE);

prompt
prompt Creating table T_100241_CONN_MAC
prompt ================================
prompt
create table T_100241_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100241_CONN_MAC
  is '���� ��ʧ ������������������ע���˺ţ�ע���豸��';
comment on column T_100241_CONN_MAC.conndate
  is '����ʱ��';
comment on column T_100241_CONN_MAC.gameid
  is '��ϷID';
comment on column T_100241_CONN_MAC.channelid
  is '����ID';
comment on column T_100241_CONN_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100241_CONN_MAC.serverid
  is '����ID';
comment on column T_100241_CONN_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100241_CONN_MAC.position
  is 'λ����Ϣ';
comment on column T_100241_CONN_MAC.dvid
  is '�豸��';
comment on column T_100241_CONN_MAC.accountid
  is '�˺�ID';
comment on column T_100241_CONN_MAC.regdate
  is 'ע��ʱ��';
comment on column T_100241_CONN_MAC.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100241_CONN_MAC.regdate_as
  is '���з��������ע��ʱ��';
create index IDX131_100241 on T_100241_CONN_MAC (CHANNELID);
create index IDX132_100241 on T_100241_CONN_MAC (SERVERID);
create index IDX133_100241 on T_100241_CONN_MAC (CONNDATE);

prompt
prompt Creating table T_100241_LOST_MAC
prompt ================================
prompt
create table T_100241_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100241_LOST_MAC
  is '�豸�ȼ���ʧ������';
comment on column T_100241_LOST_MAC.statdate
  is '�����������';
comment on column T_100241_LOST_MAC.lost_date
  is '��ʧ����';
comment on column T_100241_LOST_MAC.channelid
  is '����';
comment on column T_100241_LOST_MAC.serverid
  is '����';
comment on column T_100241_LOST_MAC.appid
  is '��Ʒid';
comment on column T_100241_LOST_MAC.macid
  is '�豸id';
comment on column T_100241_LOST_MAC.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100241_LOST_MAC.lost_days
  is '��ʧ����';
comment on column T_100241_LOST_MAC.data_source
  is '������Դ';
create index IDX134_100241 on T_100241_LOST_MAC (CHANNELID);
create index IDX135_100241 on T_100241_LOST_MAC (SERVERID);
create index IDX136_100241 on T_100241_LOST_MAC (STATDATE);

prompt
prompt Creating table T_100241_LOST_MAC_AS
prompt ===================================
prompt
create table T_100241_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100241_LOST_MAC_AS
  is '�豸�ȼ���ʧ������allserver';
comment on column T_100241_LOST_MAC_AS.statdate
  is '�����������';
comment on column T_100241_LOST_MAC_AS.lost_date
  is '��ʧ����';
comment on column T_100241_LOST_MAC_AS.channelid
  is '����';
comment on column T_100241_LOST_MAC_AS.appid
  is '��Ʒid';
comment on column T_100241_LOST_MAC_AS.macid
  is '�豸id';
comment on column T_100241_LOST_MAC_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100241_LOST_MAC_AS.lost_days
  is '��ʧ����';
comment on column T_100241_LOST_MAC_AS.data_source
  is '������Դ';
create index IDX210_100241 on T_100241_LOST_MAC_AS (CHANNELID);
create index IDX211_100241 on T_100241_LOST_MAC_AS (STATDATE);

prompt
prompt Creating table T_100241_LOST_USER
prompt =================================
prompt
create table T_100241_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100241_LOST_USER
  is '�û��ȼ���ʧ������';
comment on column T_100241_LOST_USER.statdate
  is '�����������';
comment on column T_100241_LOST_USER.lost_date
  is '��ʧ����';
comment on column T_100241_LOST_USER.channelid
  is '����';
comment on column T_100241_LOST_USER.serverid
  is '����';
comment on column T_100241_LOST_USER.appid
  is '��Ʒid';
comment on column T_100241_LOST_USER.userid
  is '�û�id';
comment on column T_100241_LOST_USER.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100241_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100241_LOST_USER.lost_days
  is '��ʧ����';
comment on column T_100241_LOST_USER.data_source
  is '������Դ';
create index IDX137_100241 on T_100241_LOST_USER (CHANNELID);
create index IDX138_100241 on T_100241_LOST_USER (SERVERID);
create index IDX139_100241 on T_100241_LOST_USER (STATDATE);

prompt
prompt Creating table T_100241_LOST_USER_AS
prompt ====================================
prompt
create table T_100241_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100241_LOST_USER_AS
  is '�û��ȼ���ʧ������allserver';
comment on column T_100241_LOST_USER_AS.statdate
  is '�����������';
comment on column T_100241_LOST_USER_AS.lost_date
  is '��ʧ����';
comment on column T_100241_LOST_USER_AS.channelid
  is '����';
comment on column T_100241_LOST_USER_AS.appid
  is '��Ʒid';
comment on column T_100241_LOST_USER_AS.userid
  is '�û�id';
comment on column T_100241_LOST_USER_AS.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100241_LOST_USER_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100241_LOST_USER_AS.lost_days
  is '��ʧ����';
comment on column T_100241_LOST_USER_AS.data_source
  is '������Դ';
create index IDX208_100241 on T_100241_LOST_USER_AS (CHANNELID);
create index IDX209_100241 on T_100241_LOST_USER_AS (STATDATE);

prompt
prompt Creating table T_100241_MISS_FIRST
prompt ==================================
prompt
create table T_100241_MISS_FIRST
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50) default '0',
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100241_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column T_100241_MISS_FIRST.statdate
  is 'ͳ������';
comment on column T_100241_MISS_FIRST.channelid
  is '����';
comment on column T_100241_MISS_FIRST.serverid
  is '����';
comment on column T_100241_MISS_FIRST.appid
  is '��ƷID';
comment on column T_100241_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column T_100241_MISS_FIRST.accountid
  is '�û�ID';
comment on column T_100241_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100241_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column T_100241_MISS_FIRST.issucc
  is '�Ƿ���ͨ��';
comment on column T_100241_MISS_FIRST.data_source
  is '������Դ';
create index IDX140_100241 on T_100241_MISS_FIRST (CHANNELID);
create index IDX141_100241 on T_100241_MISS_FIRST (SERVERID);
create index IDX142_100241 on T_100241_MISS_FIRST (STATDATE);

prompt
prompt Creating table T_100241_NU
prompt ==========================
prompt
create table T_100241_NU
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100241_NU
  is '�����û���Ϣ��';
comment on column T_100241_NU.thedate
  is '��������';
comment on column T_100241_NU.gameid
  is '��ϷID';
comment on column T_100241_NU.channelid
  is '����ID';
comment on column T_100241_NU.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100241_NU.serverid
  is '���ڷ�ID';
comment on column T_100241_NU.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100241_NU.position
  is '����λ��';
comment on column T_100241_NU.accountid
  is '�˺�ID';
create index IDX143_100241 on T_100241_NU (CHANNELID);
create index IDX144_100241 on T_100241_NU (SERVERID);
create index IDX145_100241 on T_100241_NU (THEDATE);

prompt
prompt Creating table T_100241_NU_ALLSERVER
prompt ====================================
prompt
create table T_100241_NU_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100241_NU_ALLSERVER
  is '�����û���Ϣ��ALLSERVER';
comment on column T_100241_NU_ALLSERVER.thedate
  is '��������';
comment on column T_100241_NU_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100241_NU_ALLSERVER.channelid
  is '����ID';
comment on column T_100241_NU_ALLSERVER.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100241_NU_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100241_NU_ALLSERVER.position
  is '����λ��';
comment on column T_100241_NU_ALLSERVER.accountid
  is '�˺�ID';
create index IDX194_100241 on T_100241_NU_ALLSERVER (CHANNELID);
create index IDX195_100241 on T_100241_NU_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100241_NU_DVID
prompt ===============================
prompt
create table T_100241_NU_DVID
(
  thedate   DATE not null,
  gameid    VARCHAR2(20) not null,
  channelid VARCHAR2(20) not null,
  dvid      VARCHAR2(50) not null,
  ipaddr    VARCHAR2(50)
)
;
comment on table T_100241_NU_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100241_NU_DVID.thedate
  is '����ʱ��';
comment on column T_100241_NU_DVID.gameid
  is '��ϷID';
comment on column T_100241_NU_DVID.channelid
  is '����ID';
comment on column T_100241_NU_DVID.dvid
  is '�豸ID';
comment on column T_100241_NU_DVID.ipaddr
  is 'IP';
create index IDX146_100241 on T_100241_NU_DVID (CHANNELID);
create index IDX147_100241 on T_100241_NU_DVID (THEDATE);

prompt
prompt Creating table T_100241_NU_MAC
prompt ==============================
prompt
create table T_100241_NU_MAC
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100241_NU_MAC
  is '�豸������';
comment on column T_100241_NU_MAC.thedate
  is '����ʱ��';
comment on column T_100241_NU_MAC.gameid
  is '��ϷID';
comment on column T_100241_NU_MAC.channelid
  is '����ID';
comment on column T_100241_NU_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100241_NU_MAC.serverid
  is '��������ID';
comment on column T_100241_NU_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100241_NU_MAC.position
  is 'λ����Ϣ';
comment on column T_100241_NU_MAC.dvid
  is '�豸ID';
create index IDX148_100241 on T_100241_NU_MAC (CHANNELID);
create index IDX149_100241 on T_100241_NU_MAC (SERVERID);
create index IDX150_100241 on T_100241_NU_MAC (THEDATE);

prompt
prompt Creating table T_100241_NU_MAC_ALLSERVER
prompt ========================================
prompt
create table T_100241_NU_MAC_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100241_NU_MAC_ALLSERVER
  is '�豸������ALLSERVER';
comment on column T_100241_NU_MAC_ALLSERVER.thedate
  is '����ʱ��';
comment on column T_100241_NU_MAC_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100241_NU_MAC_ALLSERVER.channelid
  is '����ID';
comment on column T_100241_NU_MAC_ALLSERVER.gameversion
  is '��Ϸ�汾';
comment on column T_100241_NU_MAC_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100241_NU_MAC_ALLSERVER.position
  is 'λ����Ϣ';
comment on column T_100241_NU_MAC_ALLSERVER.dvid
  is '�豸ID';
create index IDX196_100241 on T_100241_NU_MAC_ALLSERVER (CHANNELID);
create index IDX197_100241 on T_100241_NU_MAC_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100241_NU_PAY
prompt ==============================
prompt
create table T_100241_NU_PAY
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100241_NU_PAY
  is '�����û���';
comment on column T_100241_NU_PAY.thedate
  is '����ʱ��';
comment on column T_100241_NU_PAY.gameid
  is '��ϷID';
comment on column T_100241_NU_PAY.channelid
  is '����ID';
comment on column T_100241_NU_PAY.gameversion
  is '��Ϸ�汾';
comment on column T_100241_NU_PAY.serverid
  is '������Ϣ';
comment on column T_100241_NU_PAY.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100241_NU_PAY.position
  is 'λ����Ϣ';
comment on column T_100241_NU_PAY.accountid
  is '�˺�ID';
comment on column T_100241_NU_PAY.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100241_NU_PAY.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX151_100241 on T_100241_NU_PAY (CHANNELID);
create index IDX152_100241 on T_100241_NU_PAY (SERVERID);
create index IDX153_100241 on T_100241_NU_PAY (THEDATE);

prompt
prompt Creating table T_100241_NU_PAY_AS
prompt =================================
prompt
create table T_100241_NU_PAY_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100241_NU_PAY_AS
  is '�����û���allsever';
comment on column T_100241_NU_PAY_AS.thedate
  is '����ʱ��';
comment on column T_100241_NU_PAY_AS.gameid
  is '��ϷID';
comment on column T_100241_NU_PAY_AS.channelid
  is '����ID';
comment on column T_100241_NU_PAY_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100241_NU_PAY_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100241_NU_PAY_AS.position
  is 'λ����Ϣ';
comment on column T_100241_NU_PAY_AS.accountid
  is '�˺�ID';
comment on column T_100241_NU_PAY_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100241_NU_PAY_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX198_100241 on T_100241_NU_PAY_AS (CHANNELID);
create index IDX199_100241 on T_100241_NU_PAY_AS (THEDATE);

prompt
prompt Creating table T_100241_NU_PAY_MAC
prompt ==================================
prompt
create table T_100241_NU_PAY_MAC
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100241_NU_PAY_MAC
  is '�����û���';
comment on column T_100241_NU_PAY_MAC.thedate
  is '����ʱ��';
comment on column T_100241_NU_PAY_MAC.gameid
  is '��ϷID';
comment on column T_100241_NU_PAY_MAC.channelid
  is '����ID';
comment on column T_100241_NU_PAY_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100241_NU_PAY_MAC.serverid
  is '������Ϣ';
comment on column T_100241_NU_PAY_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100241_NU_PAY_MAC.position
  is 'λ����Ϣ';
comment on column T_100241_NU_PAY_MAC.dvid
  is '�豸ID';
comment on column T_100241_NU_PAY_MAC.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100241_NU_PAY_MAC.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX154_100241 on T_100241_NU_PAY_MAC (CHANNELID);
create index IDX155_100241 on T_100241_NU_PAY_MAC (SERVERID);
create index IDX156_100241 on T_100241_NU_PAY_MAC (THEDATE);

prompt
prompt Creating table T_100241_NU_PAY_MAC_AS
prompt =====================================
prompt
create table T_100241_NU_PAY_MAC_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100241_NU_PAY_MAC_AS
  is '�����û���ALLSERVER';
comment on column T_100241_NU_PAY_MAC_AS.thedate
  is '����ʱ��';
comment on column T_100241_NU_PAY_MAC_AS.gameid
  is '��ϷID';
comment on column T_100241_NU_PAY_MAC_AS.channelid
  is '����ID';
comment on column T_100241_NU_PAY_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100241_NU_PAY_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100241_NU_PAY_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100241_NU_PAY_MAC_AS.dvid
  is '�豸ID';
comment on column T_100241_NU_PAY_MAC_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100241_NU_PAY_MAC_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX200_100241 on T_100241_NU_PAY_MAC_AS (CHANNELID);
create index IDX201_100241 on T_100241_NU_PAY_MAC_AS (THEDATE);

prompt
prompt Creating table T_100241_ORDER_FAILURE
prompt =====================================
prompt
create table T_100241_ORDER_FAILURE
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100241_ORDER_FAILURE
  is '��ֵ�ɹ���¼��';
comment on column T_100241_ORDER_FAILURE.thedate
  is '��ֵʱ��';
comment on column T_100241_ORDER_FAILURE.gameid
  is '��ϷID';
comment on column T_100241_ORDER_FAILURE.channelid
  is '����ID';
comment on column T_100241_ORDER_FAILURE.gameversion
  is '��Ϸ�汾';
comment on column T_100241_ORDER_FAILURE.serverid
  is '��������';
comment on column T_100241_ORDER_FAILURE.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100241_ORDER_FAILURE.position
  is 'λ����Ϣ';
comment on column T_100241_ORDER_FAILURE.dvid
  is '�豸��';
comment on column T_100241_ORDER_FAILURE.accountid
  is '�˺�';
comment on column T_100241_ORDER_FAILURE.money
  is '��ֵ���';
comment on column T_100241_ORDER_FAILURE.vc
  is '��ֵ��õ����������';
comment on column T_100241_ORDER_FAILURE.orderid
  is '������';
comment on column T_100241_ORDER_FAILURE.paychannel
  is '֧������';
comment on column T_100241_ORDER_FAILURE.iapid
  is '��ֵ����  30  60';
create index IDX157_100241 on T_100241_ORDER_FAILURE (CHANNELID);
create index IDX158_100241 on T_100241_ORDER_FAILURE (SERVERID);
create index IDX159_100241 on T_100241_ORDER_FAILURE (THEDATE);

prompt
prompt Creating table T_100241_ORDER_SUCC
prompt ==================================
prompt
create table T_100241_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100241_ORDER_SUCC
  is '��ֵ�ɹ���¼��';
comment on column T_100241_ORDER_SUCC.thedate
  is '��ֵʱ��';
comment on column T_100241_ORDER_SUCC.gameid
  is '��ϷID';
comment on column T_100241_ORDER_SUCC.channelid
  is '����ID';
comment on column T_100241_ORDER_SUCC.gameversion
  is '��Ϸ�汾';
comment on column T_100241_ORDER_SUCC.serverid
  is '��������';
comment on column T_100241_ORDER_SUCC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100241_ORDER_SUCC.position
  is 'λ����Ϣ';
comment on column T_100241_ORDER_SUCC.dvid
  is '�豸��';
comment on column T_100241_ORDER_SUCC.accountid
  is '�˺�';
comment on column T_100241_ORDER_SUCC.money
  is '��ֵ���';
comment on column T_100241_ORDER_SUCC.vc
  is '��ֵ��õ����������';
comment on column T_100241_ORDER_SUCC.orderid
  is '������';
comment on column T_100241_ORDER_SUCC.paychannel
  is '֧������';
comment on column T_100241_ORDER_SUCC.iapid
  is '��ֵ����  30  60';
create index IDX160_100241 on T_100241_ORDER_SUCC (CHANNELID);
create index IDX161_100241 on T_100241_ORDER_SUCC (SERVERID);
create index IDX162_100241 on T_100241_ORDER_SUCC (THEDATE);

prompt
prompt Creating table T_100241_VC
prompt ==========================
prompt
create table T_100241_VC
(
  statdate    DATE,
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcchange    NUMBER,
  vcbefore    NUMBER,
  vcafter     NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100241_VC
  is '������ұ仯������';
comment on column T_100241_VC.statdate
  is 'ͳ������';
comment on column T_100241_VC.channelid
  is '����';
comment on column T_100241_VC.serverid
  is '����';
comment on column T_100241_VC.appid
  is '��Ʒid';
comment on column T_100241_VC.versionid
  is '��Ʒ�汾';
comment on column T_100241_VC.accountid
  is '�û�ID';
comment on column T_100241_VC.vctype
  is '�����������';
comment on column T_100241_VC.vcusetype
  is '�������ʹ������';
comment on column T_100241_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column T_100241_VC.vcchange
  is '������ұ仯���';
comment on column T_100241_VC.vcbefore
  is '������ұ仯ǰ���';
comment on column T_100241_VC.vcafter
  is '������ұ仯����';
comment on column T_100241_VC.data_source
  is '������Դ';
create index IDX163_100241 on T_100241_VC (CHANNELID);
create index IDX164_100241 on T_100241_VC (SERVERID);
create index IDX165_100241 on T_100241_VC (STATDATE);

prompt
prompt Creating table T_20002_CEVENT
prompt =============================
prompt
create table T_20002_CEVENT
(
  thedate          VARCHAR2(10),
  datenum          NUMBER,
  appid            VARCHAR2(10),
  channelid        VARCHAR2(50),
  gameversion      VARCHAR2(50),
  dvid             VARCHAR2(50),
  accountid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  ilevel           NUMBER,
  roleid           VARCHAR2(50),
  eventkey         VARCHAR2(100),
  eventvalue_key   VARCHAR2(100),
  eventvalue_value VARCHAR2(100),
  ipaddr           VARCHAR2(50),
  prerowid         VARCHAR2(200)
)
;
comment on table T_20002_CEVENT
  is '�Զ����¼���ֱ�';
comment on column T_20002_CEVENT.thedate
  is '����';
comment on column T_20002_CEVENT.datenum
  is '�������ָ�ʽ';
comment on column T_20002_CEVENT.appid
  is '��Ϸ�� appid';
comment on column T_20002_CEVENT.channelid
  is '���� ID';
comment on column T_20002_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column T_20002_CEVENT.dvid
  is '�豸 ID��Ψһ�豸��';
comment on column T_20002_CEVENT.accountid
  is '�ʻ� id';
comment on column T_20002_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column T_20002_CEVENT.ilevel
  is '��ҵȼ�';
comment on column T_20002_CEVENT.roleid
  is '��ɫ id';
comment on column T_20002_CEVENT.eventkey
  is '�¼�����';
comment on column T_20002_CEVENT.eventvalue_key
  is '�¼�ֵ�е�key';
comment on column T_20002_CEVENT.eventvalue_value
  is '�¼�ֵ��key��Ӧ��ֵ';
comment on column T_20002_CEVENT.ipaddr
  is 'ip ��ַ';
comment on column T_20002_CEVENT.prerowid
  is 'ԭΨһ��ID';
create index IDX180_20002 on T_20002_CEVENT (THEDATE);

prompt
prompt Creating table T_20002_CONN
prompt ===========================
prompt
create table T_20002_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_20002_CONN
  is '����&��ʧ&������������������ע���˺ţ�ע���豸��';
comment on column T_20002_CONN.conndate
  is '����ʱ��';
comment on column T_20002_CONN.gameid
  is '��ϷID';
comment on column T_20002_CONN.channelid
  is '����ID';
comment on column T_20002_CONN.gameversion
  is '��Ϸ�汾';
comment on column T_20002_CONN.serverid
  is '����ID';
comment on column T_20002_CONN.rolelevel
  is '��ɫ�ȼ�';
comment on column T_20002_CONN.position
  is 'λ����Ϣ';
comment on column T_20002_CONN.dvid
  is '�豸��';
comment on column T_20002_CONN.accountid
  is '�˺�ID';
comment on column T_20002_CONN.regdate
  is 'ע��ʱ��';
comment on column T_20002_CONN.ispay
  is '�Ƿ��Ǹ����û�';
create index IDX118_20002 on T_20002_CONN (CHANNELID);
create index IDX119_20002 on T_20002_CONN (SERVERID);
create index IDX120_20002 on T_20002_CONN (CONNDATE);

prompt
prompt Creating table T_20002_CONN_ACT
prompt ===============================
prompt
create table T_20002_CONN_ACT
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_20002_CONN_ACT
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_20002_CONN_ACT.basedate
  is '����ʱ��';
comment on column T_20002_CONN_ACT.gameid
  is '��ϷID';
comment on column T_20002_CONN_ACT.channelid
  is '����ID';
comment on column T_20002_CONN_ACT.gameversion
  is '��Ϸ�汾';
comment on column T_20002_CONN_ACT.serverid
  is '����ID';
comment on column T_20002_CONN_ACT.rolelevel
  is '��ɫ�ȼ�';
comment on column T_20002_CONN_ACT.position
  is 'λ����Ϣ';
comment on column T_20002_CONN_ACT.dvid
  is '�豸��';
comment on column T_20002_CONN_ACT.accountid
  is '�˺�';
comment on column T_20002_CONN_ACT.conndate
  is '��Ծʱ��';
comment on column T_20002_CONN_ACT.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_20002 on T_20002_CONN_ACT (CHANNELID);
create index IDX122_20002 on T_20002_CONN_ACT (SERVERID);
create index IDX123_20002 on T_20002_CONN_ACT (CONNDATE);
create index IDX124_20002 on T_20002_CONN_ACT (BASEDATE);

prompt
prompt Creating table T_20002_CONN_ACT_MAC
prompt ===================================
prompt
create table T_20002_CONN_ACT_MAC
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_20002_CONN_ACT_MAC
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_20002_CONN_ACT_MAC.basedate
  is '����ʱ��';
comment on column T_20002_CONN_ACT_MAC.gameid
  is '��ϷID';
comment on column T_20002_CONN_ACT_MAC.channelid
  is '����ID';
comment on column T_20002_CONN_ACT_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_20002_CONN_ACT_MAC.serverid
  is '����ID';
comment on column T_20002_CONN_ACT_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_20002_CONN_ACT_MAC.position
  is 'λ����Ϣ';
comment on column T_20002_CONN_ACT_MAC.dvid
  is '�豸��';
comment on column T_20002_CONN_ACT_MAC.accountid
  is '�˺�';
comment on column T_20002_CONN_ACT_MAC.conndate
  is '��Ծʱ��';
comment on column T_20002_CONN_ACT_MAC.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_20002 on T_20002_CONN_ACT_MAC (CHANNELID);
create index IDX126_20002 on T_20002_CONN_ACT_MAC (SERVERID);
create index IDX127_20002 on T_20002_CONN_ACT_MAC (CONNDATE);
create index IDX128_20002 on T_20002_CONN_ACT_MAC (BASEDATE);

prompt
prompt Creating table T_20002_CONN_DVID
prompt ================================
prompt
create table T_20002_CONN_DVID
(
  conndate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  dvid      VARCHAR2(50),
  regdate   VARCHAR2(10)
)
;
comment on table T_20002_CONN_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_20002_CONN_DVID.conndate
  is '����ʱ��';
comment on column T_20002_CONN_DVID.gameid
  is '��ϷID';
comment on column T_20002_CONN_DVID.channelid
  is '����ID';
comment on column T_20002_CONN_DVID.dvid
  is '�豸��';
comment on column T_20002_CONN_DVID.regdate
  is 'ע��ʱ��';
create index IDX129_20002 on T_20002_CONN_DVID (CHANNELID);
create index IDX130_20002 on T_20002_CONN_DVID (CONNDATE);

prompt
prompt Creating table T_20002_CONN_MAC
prompt ===============================
prompt
create table T_20002_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_20002_CONN_MAC
  is '���� ��ʧ ������������������ע���˺ţ�ע���豸��';
comment on column T_20002_CONN_MAC.conndate
  is '����ʱ��';
comment on column T_20002_CONN_MAC.gameid
  is '��ϷID';
comment on column T_20002_CONN_MAC.channelid
  is '����ID';
comment on column T_20002_CONN_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_20002_CONN_MAC.serverid
  is '����ID';
comment on column T_20002_CONN_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_20002_CONN_MAC.position
  is 'λ����Ϣ';
comment on column T_20002_CONN_MAC.dvid
  is '�豸��';
comment on column T_20002_CONN_MAC.accountid
  is '�˺�ID';
comment on column T_20002_CONN_MAC.regdate
  is 'ע��ʱ��';
comment on column T_20002_CONN_MAC.ispay
  is '�Ƿ��Ǹ����û�';
create index IDX131_20002 on T_20002_CONN_MAC (CHANNELID);
create index IDX132_20002 on T_20002_CONN_MAC (SERVERID);
create index IDX133_20002 on T_20002_CONN_MAC (CONNDATE);

prompt
prompt Creating table T_20002_LOST_MAC
prompt ===============================
prompt
create table T_20002_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table T_20002_LOST_MAC
  is '�豸�ȼ���ʧ������';
comment on column T_20002_LOST_MAC.statdate
  is '�����������';
comment on column T_20002_LOST_MAC.lost_date
  is '��ʧ����';
comment on column T_20002_LOST_MAC.channelid
  is '����';
comment on column T_20002_LOST_MAC.serverid
  is '����';
comment on column T_20002_LOST_MAC.appid
  is '��Ʒid';
comment on column T_20002_LOST_MAC.macid
  is '�豸id';
comment on column T_20002_LOST_MAC.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_20002_LOST_MAC.lost_days
  is '��ʧ����';
comment on column T_20002_LOST_MAC.data_source
  is '������Դ';
create index IDX134_20002 on T_20002_LOST_MAC (CHANNELID);
create index IDX135_20002 on T_20002_LOST_MAC (SERVERID);
create index IDX136_20002 on T_20002_LOST_MAC (STATDATE);

prompt
prompt Creating table T_20002_LOST_USER
prompt ================================
prompt
create table T_20002_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table T_20002_LOST_USER
  is '�û��ȼ���ʧ������';
comment on column T_20002_LOST_USER.statdate
  is '�����������';
comment on column T_20002_LOST_USER.lost_date
  is '��ʧ����';
comment on column T_20002_LOST_USER.channelid
  is '����';
comment on column T_20002_LOST_USER.serverid
  is '����';
comment on column T_20002_LOST_USER.appid
  is '��Ʒid';
comment on column T_20002_LOST_USER.userid
  is '�û�id';
comment on column T_20002_LOST_USER.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_20002_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_20002_LOST_USER.lost_days
  is '��ʧ����';
comment on column T_20002_LOST_USER.data_source
  is '������Դ';
create index IDX137_20002 on T_20002_LOST_USER (CHANNELID);
create index IDX138_20002 on T_20002_LOST_USER (SERVERID);
create index IDX139_20002 on T_20002_LOST_USER (STATDATE);

prompt
prompt Creating table T_20002_MISS_FIRST
prompt =================================
prompt
create table T_20002_MISS_FIRST
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50) default '0',
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table T_20002_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column T_20002_MISS_FIRST.statdate
  is 'ͳ������';
comment on column T_20002_MISS_FIRST.channelid
  is '����';
comment on column T_20002_MISS_FIRST.serverid
  is '����';
comment on column T_20002_MISS_FIRST.appid
  is '��ƷID';
comment on column T_20002_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column T_20002_MISS_FIRST.accountid
  is '�û�ID';
comment on column T_20002_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column T_20002_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column T_20002_MISS_FIRST.issucc
  is '�Ƿ���ͨ��';
comment on column T_20002_MISS_FIRST.data_source
  is '������Դ';
create index IDX140_20002 on T_20002_MISS_FIRST (CHANNELID);
create index IDX141_20002 on T_20002_MISS_FIRST (SERVERID);
create index IDX142_20002 on T_20002_MISS_FIRST (STATDATE);

prompt
prompt Creating table T_20002_NU
prompt =========================
prompt
create table T_20002_NU
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_20002_NU
  is '�����û���Ϣ��';
comment on column T_20002_NU.thedate
  is '��������';
comment on column T_20002_NU.gameid
  is '��ϷID';
comment on column T_20002_NU.channelid
  is '����ID';
comment on column T_20002_NU.gameversion
  is 'ע����Ϸ�汾';
comment on column T_20002_NU.serverid
  is '���ڷ�ID';
comment on column T_20002_NU.rolelevel
  is '��ɫ�ȼ�';
comment on column T_20002_NU.position
  is '����λ��';
comment on column T_20002_NU.accountid
  is '�˺�ID';
create index IDX143_20002 on T_20002_NU (CHANNELID);
create index IDX144_20002 on T_20002_NU (SERVERID);
create index IDX145_20002 on T_20002_NU (THEDATE);

prompt
prompt Creating table T_20002_NU_DVID
prompt ==============================
prompt
create table T_20002_NU_DVID
(
  thedate   DATE not null,
  gameid    VARCHAR2(20) not null,
  channelid VARCHAR2(20) not null,
  dvid      VARCHAR2(50) not null,
  ipaddr    VARCHAR2(50)
)
;
comment on table T_20002_NU_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_20002_NU_DVID.thedate
  is '����ʱ��';
comment on column T_20002_NU_DVID.gameid
  is '��ϷID';
comment on column T_20002_NU_DVID.channelid
  is '����ID';
comment on column T_20002_NU_DVID.dvid
  is '�豸ID';
create index IDX146_20002 on T_20002_NU_DVID (CHANNELID);
create index IDX147_20002 on T_20002_NU_DVID (THEDATE);

prompt
prompt Creating table T_20002_NU_MAC
prompt =============================
prompt
create table T_20002_NU_MAC
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_20002_NU_MAC
  is '�豸������';
comment on column T_20002_NU_MAC.thedate
  is '����ʱ��';
comment on column T_20002_NU_MAC.gameid
  is '��ϷID';
comment on column T_20002_NU_MAC.channelid
  is '����ID';
comment on column T_20002_NU_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_20002_NU_MAC.serverid
  is '��������ID';
comment on column T_20002_NU_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_20002_NU_MAC.position
  is 'λ����Ϣ';
comment on column T_20002_NU_MAC.dvid
  is '�豸ID';
create index IDX148_20002 on T_20002_NU_MAC (CHANNELID);
create index IDX149_20002 on T_20002_NU_MAC (SERVERID);
create index IDX150_20002 on T_20002_NU_MAC (THEDATE);

prompt
prompt Creating table T_20002_NU_PAY
prompt =============================
prompt
create table T_20002_NU_PAY
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_20002_NU_PAY
  is '�����û���';
comment on column T_20002_NU_PAY.thedate
  is '����ʱ��';
comment on column T_20002_NU_PAY.gameid
  is '��ϷID';
comment on column T_20002_NU_PAY.channelid
  is '����ID';
comment on column T_20002_NU_PAY.gameversion
  is '��Ϸ�汾';
comment on column T_20002_NU_PAY.serverid
  is '������Ϣ';
comment on column T_20002_NU_PAY.rolelevel
  is '��ɫ�ȼ�';
comment on column T_20002_NU_PAY.position
  is 'λ����Ϣ';
comment on column T_20002_NU_PAY.accountid
  is '�˺�ID';
comment on column T_20002_NU_PAY.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_20002_NU_PAY.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX151_20002 on T_20002_NU_PAY (CHANNELID);
create index IDX152_20002 on T_20002_NU_PAY (SERVERID);
create index IDX153_20002 on T_20002_NU_PAY (THEDATE);

prompt
prompt Creating table T_20002_NU_PAY_MAC
prompt =================================
prompt
create table T_20002_NU_PAY_MAC
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_20002_NU_PAY_MAC
  is '�����û���';
comment on column T_20002_NU_PAY_MAC.thedate
  is '����ʱ��';
comment on column T_20002_NU_PAY_MAC.gameid
  is '��ϷID';
comment on column T_20002_NU_PAY_MAC.channelid
  is '����ID';
comment on column T_20002_NU_PAY_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_20002_NU_PAY_MAC.serverid
  is '������Ϣ';
comment on column T_20002_NU_PAY_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_20002_NU_PAY_MAC.position
  is 'λ����Ϣ';
comment on column T_20002_NU_PAY_MAC.dvid
  is '�豸ID';
comment on column T_20002_NU_PAY_MAC.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_20002_NU_PAY_MAC.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX154_20002 on T_20002_NU_PAY_MAC (CHANNELID);
create index IDX155_20002 on T_20002_NU_PAY_MAC (SERVERID);
create index IDX156_20002 on T_20002_NU_PAY_MAC (THEDATE);

prompt
prompt Creating table T_20002_ORDER_FAILURE
prompt ====================================
prompt
create table T_20002_ORDER_FAILURE
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_20002_ORDER_FAILURE
  is '��ֵ�ɹ���¼��';
comment on column T_20002_ORDER_FAILURE.thedate
  is '��ֵʱ��';
comment on column T_20002_ORDER_FAILURE.gameid
  is '��ϷID';
comment on column T_20002_ORDER_FAILURE.channelid
  is '����ID';
comment on column T_20002_ORDER_FAILURE.gameversion
  is '��Ϸ�汾';
comment on column T_20002_ORDER_FAILURE.serverid
  is '��������';
comment on column T_20002_ORDER_FAILURE.rolelevel
  is '��ɫ�ȼ�';
comment on column T_20002_ORDER_FAILURE.position
  is 'λ����Ϣ';
comment on column T_20002_ORDER_FAILURE.dvid
  is '�豸��';
comment on column T_20002_ORDER_FAILURE.accountid
  is '�˺�';
comment on column T_20002_ORDER_FAILURE.money
  is '��ֵ���';
comment on column T_20002_ORDER_FAILURE.vc
  is '��ֵ��õ����������';
comment on column T_20002_ORDER_FAILURE.orderid
  is '������';
comment on column T_20002_ORDER_FAILURE.paychannel
  is '֧������';
comment on column T_20002_ORDER_FAILURE.iapid
  is '��ֵ����  30  60';
create index IDX157_20002 on T_20002_ORDER_FAILURE (CHANNELID);
create index IDX158_20002 on T_20002_ORDER_FAILURE (SERVERID);
create index IDX159_20002 on T_20002_ORDER_FAILURE (THEDATE);

prompt
prompt Creating table T_20002_ORDER_SUCC
prompt =================================
prompt
create table T_20002_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_20002_ORDER_SUCC
  is '��ֵ�ɹ���¼��';
comment on column T_20002_ORDER_SUCC.thedate
  is '��ֵʱ��';
comment on column T_20002_ORDER_SUCC.gameid
  is '��ϷID';
comment on column T_20002_ORDER_SUCC.channelid
  is '����ID';
comment on column T_20002_ORDER_SUCC.gameversion
  is '��Ϸ�汾';
comment on column T_20002_ORDER_SUCC.serverid
  is '��������';
comment on column T_20002_ORDER_SUCC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_20002_ORDER_SUCC.position
  is 'λ����Ϣ';
comment on column T_20002_ORDER_SUCC.dvid
  is '�豸��';
comment on column T_20002_ORDER_SUCC.accountid
  is '�˺�';
comment on column T_20002_ORDER_SUCC.money
  is '��ֵ���';
comment on column T_20002_ORDER_SUCC.vc
  is '��ֵ��õ����������';
comment on column T_20002_ORDER_SUCC.orderid
  is '������';
comment on column T_20002_ORDER_SUCC.paychannel
  is '֧������';
comment on column T_20002_ORDER_SUCC.iapid
  is '��ֵ����  30  60';
create index IDX160_20002 on T_20002_ORDER_SUCC (CHANNELID);
create index IDX161_20002 on T_20002_ORDER_SUCC (SERVERID);
create index IDX162_20002 on T_20002_ORDER_SUCC (THEDATE);

prompt
prompt Creating table T_20002_VC
prompt =========================
prompt
create table T_20002_VC
(
  statdate    DATE,
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcchange    NUMBER,
  vcbefore    NUMBER,
  vcafter     NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table T_20002_VC
  is '������ұ仯������';
comment on column T_20002_VC.statdate
  is 'ͳ������';
comment on column T_20002_VC.channelid
  is '����';
comment on column T_20002_VC.serverid
  is '����';
comment on column T_20002_VC.appid
  is '��Ʒid';
comment on column T_20002_VC.versionid
  is '��Ʒ�汾';
comment on column T_20002_VC.accountid
  is '�û�ID';
comment on column T_20002_VC.vctype
  is '�����������';
comment on column T_20002_VC.vcusetype
  is '�������ʹ������';
comment on column T_20002_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column T_20002_VC.vcchange
  is '������ұ仯���';
comment on column T_20002_VC.vcbefore
  is '������ұ仯ǰ���';
comment on column T_20002_VC.vcafter
  is '������ұ仯����';
comment on column T_20002_VC.data_source
  is '������Դ';
create index IDX163_20002 on T_20002_VC (CHANNELID);
create index IDX164_20002 on T_20002_VC (SERVERID);
create index IDX165_20002 on T_20002_VC (STATDATE);

prompt
prompt Creating table T_20003_CONN
prompt ===========================
prompt
create table T_20003_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER
)
;

prompt
prompt Creating table T_20003_CONN_ACT
prompt ===============================
prompt
create table T_20003_CONN_ACT
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;

prompt
prompt Creating table T_20003_CONN_ACT_MAC
prompt ===================================
prompt
create table T_20003_CONN_ACT_MAC
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;

prompt
prompt Creating table T_20003_CONN_MAC
prompt ===============================
prompt
create table T_20003_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER
)
;

prompt
prompt Creating table T_20003_LOST_MAC
prompt ===============================
prompt
create table T_20003_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table T_20003_LOST_USER
prompt ================================
prompt
create table T_20003_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table T_20003_MISS_FIRST
prompt =================================
prompt
create table T_20003_MISS_FIRST
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50) default '0',
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table T_20003_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column T_20003_MISS_FIRST.statdate
  is 'ͳ������';
comment on column T_20003_MISS_FIRST.channelid
  is '����';
comment on column T_20003_MISS_FIRST.serverid
  is '����';
comment on column T_20003_MISS_FIRST.appid
  is '��ƷID';
comment on column T_20003_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column T_20003_MISS_FIRST.accountid
  is '�û�ID';
comment on column T_20003_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column T_20003_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column T_20003_MISS_FIRST.issucc
  is '�Ƿ���ͨ��';
comment on column T_20003_MISS_FIRST.data_source
  is '������Դ';

prompt
prompt Creating table T_20003_NU
prompt =========================
prompt
create table T_20003_NU
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;

prompt
prompt Creating table T_20003_NU_MAC
prompt =============================
prompt
create table T_20003_NU_MAC
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;

prompt
prompt Creating table T_20003_NU_PAY
prompt =============================
prompt
create table T_20003_NU_PAY
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;

prompt
prompt Creating table T_20003_NU_PAY_MAC
prompt =================================
prompt
create table T_20003_NU_PAY_MAC
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;

prompt
prompt Creating table T_20003_ORDER_FAILURE
prompt ====================================
prompt
create table T_20003_ORDER_FAILURE
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;

prompt
prompt Creating table T_20003_ORDER_SUCC
prompt =================================
prompt
create table T_20003_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;

prompt
prompt Creating table T_DEMO_CEVENT
prompt ============================
prompt
create table T_DEMO_CEVENT
(
  thedate          VARCHAR2(10),
  datenum          NUMBER,
  appid            VARCHAR2(10),
  channelid        VARCHAR2(50),
  gameversion      VARCHAR2(50),
  dvid             VARCHAR2(50),
  accountid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  ilevel           NUMBER,
  roleid           VARCHAR2(50),
  eventkey         VARCHAR2(100),
  eventvalue_key   VARCHAR2(100),
  eventvalue_value VARCHAR2(100),
  ipaddr           VARCHAR2(50),
  prerowid         VARCHAR2(200)
)
;
comment on table T_DEMO_CEVENT
  is '�Զ����¼���ֱ�';
comment on column T_DEMO_CEVENT.thedate
  is '����';
comment on column T_DEMO_CEVENT.datenum
  is '�������ָ�ʽ';
comment on column T_DEMO_CEVENT.appid
  is '��Ϸ�� appid';
comment on column T_DEMO_CEVENT.channelid
  is '���� ID';
comment on column T_DEMO_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column T_DEMO_CEVENT.dvid
  is '�豸 ID��Ψһ�豸��';
comment on column T_DEMO_CEVENT.accountid
  is '�ʻ� id';
comment on column T_DEMO_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column T_DEMO_CEVENT.ilevel
  is '��ҵȼ�';
comment on column T_DEMO_CEVENT.roleid
  is '��ɫ id';
comment on column T_DEMO_CEVENT.eventkey
  is '�¼�����';
comment on column T_DEMO_CEVENT.eventvalue_key
  is '�¼�ֵ�е�key';
comment on column T_DEMO_CEVENT.eventvalue_value
  is '�¼�ֵ��key��Ӧ��ֵ';
comment on column T_DEMO_CEVENT.ipaddr
  is 'ip ��ַ';
comment on column T_DEMO_CEVENT.prerowid
  is 'ԭΨһ��ID';
create index IDX180_DEMO on T_DEMO_CEVENT (THEDATE);

prompt
prompt Creating table T_DEMO_CONN
prompt ==========================
prompt
create table T_DEMO_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_DEMO_CONN
  is '����&��ʧ&������������������ע���˺ţ�ע���豸��';
comment on column T_DEMO_CONN.conndate
  is '����ʱ��';
comment on column T_DEMO_CONN.gameid
  is '��ϷID';
comment on column T_DEMO_CONN.channelid
  is '����ID';
comment on column T_DEMO_CONN.gameversion
  is '��Ϸ�汾';
comment on column T_DEMO_CONN.serverid
  is '����ID';
comment on column T_DEMO_CONN.rolelevel
  is '��ɫ�ȼ�';
comment on column T_DEMO_CONN.position
  is 'λ����Ϣ';
comment on column T_DEMO_CONN.dvid
  is '�豸��';
comment on column T_DEMO_CONN.accountid
  is '�˺�ID';
comment on column T_DEMO_CONN.regdate
  is 'ע��ʱ��';
comment on column T_DEMO_CONN.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_DEMO_CONN.regdate_as
  is '���з��������ע��ʱ��';
create index IDX118_DEMO on T_DEMO_CONN (CHANNELID);
create index IDX119_DEMO on T_DEMO_CONN (SERVERID);
create index IDX120_DEMO on T_DEMO_CONN (CONNDATE);

prompt
prompt Creating table T_DEMO_CONN_ACT
prompt ==============================
prompt
create table T_DEMO_CONN_ACT
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_DEMO_CONN_ACT
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_DEMO_CONN_ACT.basedate
  is '����ʱ��';
comment on column T_DEMO_CONN_ACT.gameid
  is '��ϷID';
comment on column T_DEMO_CONN_ACT.channelid
  is '����ID';
comment on column T_DEMO_CONN_ACT.gameversion
  is '��Ϸ�汾';
comment on column T_DEMO_CONN_ACT.serverid
  is '����ID';
comment on column T_DEMO_CONN_ACT.rolelevel
  is '��ɫ�ȼ�';
comment on column T_DEMO_CONN_ACT.position
  is 'λ����Ϣ';
comment on column T_DEMO_CONN_ACT.dvid
  is '�豸��';
comment on column T_DEMO_CONN_ACT.accountid
  is '�˺�';
comment on column T_DEMO_CONN_ACT.conndate
  is '��Ծʱ��';
comment on column T_DEMO_CONN_ACT.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_DEMO on T_DEMO_CONN_ACT (CHANNELID);
create index IDX122_DEMO on T_DEMO_CONN_ACT (SERVERID);
create index IDX123_DEMO on T_DEMO_CONN_ACT (CONNDATE);
create index IDX124_DEMO on T_DEMO_CONN_ACT (BASEDATE);

prompt
prompt Creating table T_DEMO_CONN_ACT_AS
prompt =================================
prompt
create table T_DEMO_CONN_ACT_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_DEMO_CONN_ACT_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_DEMO_CONN_ACT_AS.basedate
  is '����ʱ��';
comment on column T_DEMO_CONN_ACT_AS.gameid
  is '��ϷID';
comment on column T_DEMO_CONN_ACT_AS.channelid
  is '����ID';
comment on column T_DEMO_CONN_ACT_AS.gameversion
  is '��Ϸ�汾';
comment on column T_DEMO_CONN_ACT_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_DEMO_CONN_ACT_AS.position
  is 'λ����Ϣ';
comment on column T_DEMO_CONN_ACT_AS.dvid
  is '�豸��';
comment on column T_DEMO_CONN_ACT_AS.accountid
  is '�˺�';
comment on column T_DEMO_CONN_ACT_AS.conndate
  is '��Ծʱ��';
comment on column T_DEMO_CONN_ACT_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX205_DEMO on T_DEMO_CONN_ACT_AS (CHANNELID);
create index IDX206_DEMO on T_DEMO_CONN_ACT_AS (CONNDATE);
create index IDX207_DEMO on T_DEMO_CONN_ACT_AS (BASEDATE);

prompt
prompt Creating table T_DEMO_CONN_ACT_MAC
prompt ==================================
prompt
create table T_DEMO_CONN_ACT_MAC
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_DEMO_CONN_ACT_MAC
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_DEMO_CONN_ACT_MAC.basedate
  is '����ʱ��';
comment on column T_DEMO_CONN_ACT_MAC.gameid
  is '��ϷID';
comment on column T_DEMO_CONN_ACT_MAC.channelid
  is '����ID';
comment on column T_DEMO_CONN_ACT_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_DEMO_CONN_ACT_MAC.serverid
  is '����ID';
comment on column T_DEMO_CONN_ACT_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_DEMO_CONN_ACT_MAC.position
  is 'λ����Ϣ';
comment on column T_DEMO_CONN_ACT_MAC.dvid
  is '�豸��';
comment on column T_DEMO_CONN_ACT_MAC.accountid
  is '�˺�';
comment on column T_DEMO_CONN_ACT_MAC.conndate
  is '��Ծʱ��';
comment on column T_DEMO_CONN_ACT_MAC.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_DEMO on T_DEMO_CONN_ACT_MAC (CHANNELID);
create index IDX126_DEMO on T_DEMO_CONN_ACT_MAC (SERVERID);
create index IDX127_DEMO on T_DEMO_CONN_ACT_MAC (CONNDATE);
create index IDX128_DEMO on T_DEMO_CONN_ACT_MAC (BASEDATE);

prompt
prompt Creating table T_DEMO_CONN_ACT_MAC_AS
prompt =====================================
prompt
create table T_DEMO_CONN_ACT_MAC_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_DEMO_CONN_ACT_MAC_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_DEMO_CONN_ACT_MAC_AS.basedate
  is '����ʱ��';
comment on column T_DEMO_CONN_ACT_MAC_AS.gameid
  is '��ϷID';
comment on column T_DEMO_CONN_ACT_MAC_AS.channelid
  is '����ID';
comment on column T_DEMO_CONN_ACT_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_DEMO_CONN_ACT_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_DEMO_CONN_ACT_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_DEMO_CONN_ACT_MAC_AS.dvid
  is '�豸��';
comment on column T_DEMO_CONN_ACT_MAC_AS.accountid
  is '�˺�';
comment on column T_DEMO_CONN_ACT_MAC_AS.conndate
  is '��Ծʱ��';
comment on column T_DEMO_CONN_ACT_MAC_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX202_DEMO on T_DEMO_CONN_ACT_MAC_AS (CHANNELID);
create index IDX203_DEMO on T_DEMO_CONN_ACT_MAC_AS (CONNDATE);
create index IDX204_DEMO on T_DEMO_CONN_ACT_MAC_AS (BASEDATE);

prompt
prompt Creating table T_DEMO_CONN_DVID
prompt ===============================
prompt
create table T_DEMO_CONN_DVID
(
  conndate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  dvid      VARCHAR2(50),
  regdate   VARCHAR2(10)
)
;
comment on table T_DEMO_CONN_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_DEMO_CONN_DVID.conndate
  is '����ʱ��';
comment on column T_DEMO_CONN_DVID.gameid
  is '��ϷID';
comment on column T_DEMO_CONN_DVID.channelid
  is '����ID';
comment on column T_DEMO_CONN_DVID.dvid
  is '�豸��';
comment on column T_DEMO_CONN_DVID.regdate
  is 'ע��ʱ��';
create index IDX129_DEMO on T_DEMO_CONN_DVID (CHANNELID);
create index IDX130_DEMO on T_DEMO_CONN_DVID (CONNDATE);

prompt
prompt Creating table T_DEMO_CONN_MAC
prompt ==============================
prompt
create table T_DEMO_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_DEMO_CONN_MAC
  is '���� ��ʧ ������������������ע���˺ţ�ע���豸��';
comment on column T_DEMO_CONN_MAC.conndate
  is '����ʱ��';
comment on column T_DEMO_CONN_MAC.gameid
  is '��ϷID';
comment on column T_DEMO_CONN_MAC.channelid
  is '����ID';
comment on column T_DEMO_CONN_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_DEMO_CONN_MAC.serverid
  is '����ID';
comment on column T_DEMO_CONN_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_DEMO_CONN_MAC.position
  is 'λ����Ϣ';
comment on column T_DEMO_CONN_MAC.dvid
  is '�豸��';
comment on column T_DEMO_CONN_MAC.accountid
  is '�˺�ID';
comment on column T_DEMO_CONN_MAC.regdate
  is 'ע��ʱ��';
comment on column T_DEMO_CONN_MAC.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_DEMO_CONN_MAC.regdate_as
  is '���з��������ע��ʱ��';
create index IDX131_DEMO on T_DEMO_CONN_MAC (CHANNELID);
create index IDX132_DEMO on T_DEMO_CONN_MAC (SERVERID);
create index IDX133_DEMO on T_DEMO_CONN_MAC (CONNDATE);

prompt
prompt Creating table T_DEMO_LOST_MAC
prompt ==============================
prompt
create table T_DEMO_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table T_DEMO_LOST_MAC
  is '�豸�ȼ���ʧ������';
comment on column T_DEMO_LOST_MAC.statdate
  is '�����������';
comment on column T_DEMO_LOST_MAC.lost_date
  is '��ʧ����';
comment on column T_DEMO_LOST_MAC.channelid
  is '����';
comment on column T_DEMO_LOST_MAC.serverid
  is '����';
comment on column T_DEMO_LOST_MAC.appid
  is '��Ʒid';
comment on column T_DEMO_LOST_MAC.macid
  is '�豸id';
comment on column T_DEMO_LOST_MAC.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_DEMO_LOST_MAC.lost_days
  is '��ʧ����';
comment on column T_DEMO_LOST_MAC.data_source
  is '������Դ';
create index IDX134_DEMO on T_DEMO_LOST_MAC (CHANNELID);
create index IDX135_DEMO on T_DEMO_LOST_MAC (SERVERID);
create index IDX136_DEMO on T_DEMO_LOST_MAC (STATDATE);

prompt
prompt Creating table T_DEMO_LOST_MAC_AS
prompt =================================
prompt
create table T_DEMO_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table T_DEMO_LOST_MAC_AS
  is '�豸�ȼ���ʧ������allserver';
comment on column T_DEMO_LOST_MAC_AS.statdate
  is '�����������';
comment on column T_DEMO_LOST_MAC_AS.lost_date
  is '��ʧ����';
comment on column T_DEMO_LOST_MAC_AS.channelid
  is '����';
comment on column T_DEMO_LOST_MAC_AS.appid
  is '��Ʒid';
comment on column T_DEMO_LOST_MAC_AS.macid
  is '�豸id';
comment on column T_DEMO_LOST_MAC_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_DEMO_LOST_MAC_AS.lost_days
  is '��ʧ����';
comment on column T_DEMO_LOST_MAC_AS.data_source
  is '������Դ';
create index IDX210_DEMO on T_DEMO_LOST_MAC_AS (CHANNELID);
create index IDX211_DEMO on T_DEMO_LOST_MAC_AS (STATDATE);

prompt
prompt Creating table T_DEMO_LOST_USER
prompt ===============================
prompt
create table T_DEMO_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table T_DEMO_LOST_USER
  is '�û��ȼ���ʧ������';
comment on column T_DEMO_LOST_USER.statdate
  is '�����������';
comment on column T_DEMO_LOST_USER.lost_date
  is '��ʧ����';
comment on column T_DEMO_LOST_USER.channelid
  is '����';
comment on column T_DEMO_LOST_USER.serverid
  is '����';
comment on column T_DEMO_LOST_USER.appid
  is '��Ʒid';
comment on column T_DEMO_LOST_USER.userid
  is '�û�id';
comment on column T_DEMO_LOST_USER.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_DEMO_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_DEMO_LOST_USER.lost_days
  is '��ʧ����';
comment on column T_DEMO_LOST_USER.data_source
  is '������Դ';
create index IDX137_DEMO on T_DEMO_LOST_USER (CHANNELID);
create index IDX138_DEMO on T_DEMO_LOST_USER (SERVERID);
create index IDX139_DEMO on T_DEMO_LOST_USER (STATDATE);

prompt
prompt Creating table T_DEMO_LOST_USER_AS
prompt ==================================
prompt
create table T_DEMO_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table T_DEMO_LOST_USER_AS
  is '�û��ȼ���ʧ������allserver';
comment on column T_DEMO_LOST_USER_AS.statdate
  is '�����������';
comment on column T_DEMO_LOST_USER_AS.lost_date
  is '��ʧ����';
comment on column T_DEMO_LOST_USER_AS.channelid
  is '����';
comment on column T_DEMO_LOST_USER_AS.appid
  is '��Ʒid';
comment on column T_DEMO_LOST_USER_AS.userid
  is '�û�id';
comment on column T_DEMO_LOST_USER_AS.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_DEMO_LOST_USER_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_DEMO_LOST_USER_AS.lost_days
  is '��ʧ����';
comment on column T_DEMO_LOST_USER_AS.data_source
  is '������Դ';
create index IDX208_DEMO on T_DEMO_LOST_USER_AS (CHANNELID);
create index IDX209_DEMO on T_DEMO_LOST_USER_AS (STATDATE);

prompt
prompt Creating table T_DEMO_MISS_FIRST
prompt ================================
prompt
create table T_DEMO_MISS_FIRST
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50) default '0',
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table T_DEMO_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column T_DEMO_MISS_FIRST.statdate
  is 'ͳ������';
comment on column T_DEMO_MISS_FIRST.channelid
  is '����';
comment on column T_DEMO_MISS_FIRST.serverid
  is '����';
comment on column T_DEMO_MISS_FIRST.appid
  is '��ƷID';
comment on column T_DEMO_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column T_DEMO_MISS_FIRST.accountid
  is '�û�ID';
comment on column T_DEMO_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column T_DEMO_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column T_DEMO_MISS_FIRST.issucc
  is '�Ƿ���ͨ��';
comment on column T_DEMO_MISS_FIRST.data_source
  is '������Դ';
create index IDX140_DEMO on T_DEMO_MISS_FIRST (CHANNELID);
create index IDX141_DEMO on T_DEMO_MISS_FIRST (SERVERID);
create index IDX142_DEMO on T_DEMO_MISS_FIRST (STATDATE);

prompt
prompt Creating table T_DEMO_NU
prompt ========================
prompt
create table T_DEMO_NU
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_DEMO_NU
  is '�����û���Ϣ��';
comment on column T_DEMO_NU.thedate
  is '��������';
comment on column T_DEMO_NU.gameid
  is '��ϷID';
comment on column T_DEMO_NU.channelid
  is '����ID';
comment on column T_DEMO_NU.gameversion
  is 'ע����Ϸ�汾';
comment on column T_DEMO_NU.serverid
  is '���ڷ�ID';
comment on column T_DEMO_NU.rolelevel
  is '��ɫ�ȼ�';
comment on column T_DEMO_NU.position
  is '����λ��';
comment on column T_DEMO_NU.accountid
  is '�˺�ID';
create index IDX143_DEMO on T_DEMO_NU (CHANNELID);
create index IDX144_DEMO on T_DEMO_NU (SERVERID);
create index IDX145_DEMO on T_DEMO_NU (THEDATE);

prompt
prompt Creating table T_DEMO_NU_ALLSERVER
prompt ==================================
prompt
create table T_DEMO_NU_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_DEMO_NU_ALLSERVER
  is '�����û���Ϣ��ALLSERVER';
comment on column T_DEMO_NU_ALLSERVER.thedate
  is '��������';
comment on column T_DEMO_NU_ALLSERVER.gameid
  is '��ϷID';
comment on column T_DEMO_NU_ALLSERVER.channelid
  is '����ID';
comment on column T_DEMO_NU_ALLSERVER.gameversion
  is 'ע����Ϸ�汾';
comment on column T_DEMO_NU_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_DEMO_NU_ALLSERVER.position
  is '����λ��';
comment on column T_DEMO_NU_ALLSERVER.accountid
  is '�˺�ID';
create index IDX194_DEMO on T_DEMO_NU_ALLSERVER (CHANNELID);
create index IDX195_DEMO on T_DEMO_NU_ALLSERVER (THEDATE);

prompt
prompt Creating table T_DEMO_NU_DVID
prompt =============================
prompt
create table T_DEMO_NU_DVID
(
  thedate   DATE not null,
  gameid    VARCHAR2(20) not null,
  channelid VARCHAR2(20) not null,
  dvid      VARCHAR2(50) not null,
  ipaddr    VARCHAR2(50)
)
;
comment on table T_DEMO_NU_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_DEMO_NU_DVID.thedate
  is '����ʱ��';
comment on column T_DEMO_NU_DVID.gameid
  is '��ϷID';
comment on column T_DEMO_NU_DVID.channelid
  is '����ID';
comment on column T_DEMO_NU_DVID.dvid
  is '�豸ID';
comment on column T_DEMO_NU_DVID.ipaddr
  is 'IP';
create index IDX146_DEMO on T_DEMO_NU_DVID (CHANNELID);
create index IDX147_DEMO on T_DEMO_NU_DVID (THEDATE);

prompt
prompt Creating table T_DEMO_NU_MAC
prompt ============================
prompt
create table T_DEMO_NU_MAC
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_DEMO_NU_MAC
  is '�豸������';
comment on column T_DEMO_NU_MAC.thedate
  is '����ʱ��';
comment on column T_DEMO_NU_MAC.gameid
  is '��ϷID';
comment on column T_DEMO_NU_MAC.channelid
  is '����ID';
comment on column T_DEMO_NU_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_DEMO_NU_MAC.serverid
  is '��������ID';
comment on column T_DEMO_NU_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_DEMO_NU_MAC.position
  is 'λ����Ϣ';
comment on column T_DEMO_NU_MAC.dvid
  is '�豸ID';
create index IDX148_DEMO on T_DEMO_NU_MAC (CHANNELID);
create index IDX149_DEMO on T_DEMO_NU_MAC (SERVERID);
create index IDX150_DEMO on T_DEMO_NU_MAC (THEDATE);

prompt
prompt Creating table T_DEMO_NU_MAC_ALLSERVER
prompt ======================================
prompt
create table T_DEMO_NU_MAC_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_DEMO_NU_MAC_ALLSERVER
  is '�豸������ALLSERVER';
comment on column T_DEMO_NU_MAC_ALLSERVER.thedate
  is '����ʱ��';
comment on column T_DEMO_NU_MAC_ALLSERVER.gameid
  is '��ϷID';
comment on column T_DEMO_NU_MAC_ALLSERVER.channelid
  is '����ID';
comment on column T_DEMO_NU_MAC_ALLSERVER.gameversion
  is '��Ϸ�汾';
comment on column T_DEMO_NU_MAC_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_DEMO_NU_MAC_ALLSERVER.position
  is 'λ����Ϣ';
comment on column T_DEMO_NU_MAC_ALLSERVER.dvid
  is '�豸ID';
create index IDX196_DEMO on T_DEMO_NU_MAC_ALLSERVER (CHANNELID);
create index IDX197_DEMO on T_DEMO_NU_MAC_ALLSERVER (THEDATE);

prompt
prompt Creating table T_DEMO_NU_PAY
prompt ============================
prompt
create table T_DEMO_NU_PAY
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_DEMO_NU_PAY
  is '�����û���';
comment on column T_DEMO_NU_PAY.thedate
  is '����ʱ��';
comment on column T_DEMO_NU_PAY.gameid
  is '��ϷID';
comment on column T_DEMO_NU_PAY.channelid
  is '����ID';
comment on column T_DEMO_NU_PAY.gameversion
  is '��Ϸ�汾';
comment on column T_DEMO_NU_PAY.serverid
  is '������Ϣ';
comment on column T_DEMO_NU_PAY.rolelevel
  is '��ɫ�ȼ�';
comment on column T_DEMO_NU_PAY.position
  is 'λ����Ϣ';
comment on column T_DEMO_NU_PAY.accountid
  is '�˺�ID';
comment on column T_DEMO_NU_PAY.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_DEMO_NU_PAY.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX151_DEMO on T_DEMO_NU_PAY (CHANNELID);
create index IDX152_DEMO on T_DEMO_NU_PAY (SERVERID);
create index IDX153_DEMO on T_DEMO_NU_PAY (THEDATE);

prompt
prompt Creating table T_DEMO_NU_PAY_AS
prompt ===============================
prompt
create table T_DEMO_NU_PAY_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_DEMO_NU_PAY_AS
  is '�����û���allsever';
comment on column T_DEMO_NU_PAY_AS.thedate
  is '����ʱ��';
comment on column T_DEMO_NU_PAY_AS.gameid
  is '��ϷID';
comment on column T_DEMO_NU_PAY_AS.channelid
  is '����ID';
comment on column T_DEMO_NU_PAY_AS.gameversion
  is '��Ϸ�汾';
comment on column T_DEMO_NU_PAY_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_DEMO_NU_PAY_AS.position
  is 'λ����Ϣ';
comment on column T_DEMO_NU_PAY_AS.accountid
  is '�˺�ID';
comment on column T_DEMO_NU_PAY_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_DEMO_NU_PAY_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX198_DEMO on T_DEMO_NU_PAY_AS (CHANNELID);
create index IDX199_DEMO on T_DEMO_NU_PAY_AS (THEDATE);

prompt
prompt Creating table T_DEMO_NU_PAY_MAC
prompt ================================
prompt
create table T_DEMO_NU_PAY_MAC
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_DEMO_NU_PAY_MAC
  is '�����û���';
comment on column T_DEMO_NU_PAY_MAC.thedate
  is '����ʱ��';
comment on column T_DEMO_NU_PAY_MAC.gameid
  is '��ϷID';
comment on column T_DEMO_NU_PAY_MAC.channelid
  is '����ID';
comment on column T_DEMO_NU_PAY_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_DEMO_NU_PAY_MAC.serverid
  is '������Ϣ';
comment on column T_DEMO_NU_PAY_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_DEMO_NU_PAY_MAC.position
  is 'λ����Ϣ';
comment on column T_DEMO_NU_PAY_MAC.dvid
  is '�豸ID';
comment on column T_DEMO_NU_PAY_MAC.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_DEMO_NU_PAY_MAC.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX154_DEMO on T_DEMO_NU_PAY_MAC (CHANNELID);
create index IDX155_DEMO on T_DEMO_NU_PAY_MAC (SERVERID);
create index IDX156_DEMO on T_DEMO_NU_PAY_MAC (THEDATE);

prompt
prompt Creating table T_DEMO_NU_PAY_MAC_AS
prompt ===================================
prompt
create table T_DEMO_NU_PAY_MAC_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_DEMO_NU_PAY_MAC_AS
  is '�����û���ALLSERVER';
comment on column T_DEMO_NU_PAY_MAC_AS.thedate
  is '����ʱ��';
comment on column T_DEMO_NU_PAY_MAC_AS.gameid
  is '��ϷID';
comment on column T_DEMO_NU_PAY_MAC_AS.channelid
  is '����ID';
comment on column T_DEMO_NU_PAY_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_DEMO_NU_PAY_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_DEMO_NU_PAY_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_DEMO_NU_PAY_MAC_AS.dvid
  is '�豸ID';
comment on column T_DEMO_NU_PAY_MAC_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_DEMO_NU_PAY_MAC_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX200_DEMO on T_DEMO_NU_PAY_MAC_AS (CHANNELID);
create index IDX201_DEMO on T_DEMO_NU_PAY_MAC_AS (THEDATE);

prompt
prompt Creating table T_DEMO_ORDER_FAILURE
prompt ===================================
prompt
create table T_DEMO_ORDER_FAILURE
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_DEMO_ORDER_FAILURE
  is '��ֵ�ɹ���¼��';
comment on column T_DEMO_ORDER_FAILURE.thedate
  is '��ֵʱ��';
comment on column T_DEMO_ORDER_FAILURE.gameid
  is '��ϷID';
comment on column T_DEMO_ORDER_FAILURE.channelid
  is '����ID';
comment on column T_DEMO_ORDER_FAILURE.gameversion
  is '��Ϸ�汾';
comment on column T_DEMO_ORDER_FAILURE.serverid
  is '��������';
comment on column T_DEMO_ORDER_FAILURE.rolelevel
  is '��ɫ�ȼ�';
comment on column T_DEMO_ORDER_FAILURE.position
  is 'λ����Ϣ';
comment on column T_DEMO_ORDER_FAILURE.dvid
  is '�豸��';
comment on column T_DEMO_ORDER_FAILURE.accountid
  is '�˺�';
comment on column T_DEMO_ORDER_FAILURE.money
  is '��ֵ���';
comment on column T_DEMO_ORDER_FAILURE.vc
  is '��ֵ��õ����������';
comment on column T_DEMO_ORDER_FAILURE.orderid
  is '������';
comment on column T_DEMO_ORDER_FAILURE.paychannel
  is '֧������';
comment on column T_DEMO_ORDER_FAILURE.iapid
  is '��ֵ����  30  60';
create index IDX157_DEMO on T_DEMO_ORDER_FAILURE (CHANNELID);
create index IDX158_DEMO on T_DEMO_ORDER_FAILURE (SERVERID);
create index IDX159_DEMO on T_DEMO_ORDER_FAILURE (THEDATE);

prompt
prompt Creating table T_DEMO_ORDER_SUCC
prompt ================================
prompt
create table T_DEMO_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_DEMO_ORDER_SUCC
  is '��ֵ�ɹ���¼��';
comment on column T_DEMO_ORDER_SUCC.thedate
  is '��ֵʱ��';
comment on column T_DEMO_ORDER_SUCC.gameid
  is '��ϷID';
comment on column T_DEMO_ORDER_SUCC.channelid
  is '����ID';
comment on column T_DEMO_ORDER_SUCC.gameversion
  is '��Ϸ�汾';
comment on column T_DEMO_ORDER_SUCC.serverid
  is '��������';
comment on column T_DEMO_ORDER_SUCC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_DEMO_ORDER_SUCC.position
  is 'λ����Ϣ';
comment on column T_DEMO_ORDER_SUCC.dvid
  is '�豸��';
comment on column T_DEMO_ORDER_SUCC.accountid
  is '�˺�';
comment on column T_DEMO_ORDER_SUCC.money
  is '��ֵ���';
comment on column T_DEMO_ORDER_SUCC.vc
  is '��ֵ��õ����������';
comment on column T_DEMO_ORDER_SUCC.orderid
  is '������';
comment on column T_DEMO_ORDER_SUCC.paychannel
  is '֧������';
comment on column T_DEMO_ORDER_SUCC.iapid
  is '��ֵ����  30  60';
create index IDX160_DEMO on T_DEMO_ORDER_SUCC (CHANNELID);
create index IDX161_DEMO on T_DEMO_ORDER_SUCC (SERVERID);
create index IDX162_DEMO on T_DEMO_ORDER_SUCC (THEDATE);

prompt
prompt Creating table T_DEMO_VC
prompt ========================
prompt
create table T_DEMO_VC
(
  statdate    DATE,
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcchange    NUMBER,
  vcbefore    NUMBER,
  vcafter     NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table T_DEMO_VC
  is '������ұ仯������';
comment on column T_DEMO_VC.statdate
  is 'ͳ������';
comment on column T_DEMO_VC.channelid
  is '����';
comment on column T_DEMO_VC.serverid
  is '����';
comment on column T_DEMO_VC.appid
  is '��Ʒid';
comment on column T_DEMO_VC.versionid
  is '��Ʒ�汾';
comment on column T_DEMO_VC.accountid
  is '�û�ID';
comment on column T_DEMO_VC.vctype
  is '�����������';
comment on column T_DEMO_VC.vcusetype
  is '�������ʹ������';
comment on column T_DEMO_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column T_DEMO_VC.vcchange
  is '������ұ仯���';
comment on column T_DEMO_VC.vcbefore
  is '������ұ仯ǰ���';
comment on column T_DEMO_VC.vcafter
  is '������ұ仯����';
comment on column T_DEMO_VC.data_source
  is '������Դ';
create index IDX163_DEMO on T_DEMO_VC (CHANNELID);
create index IDX164_DEMO on T_DEMO_VC (SERVERID);
create index IDX165_DEMO on T_DEMO_VC (STATDATE);

prompt
prompt Creating table T_DICT_CLEARDATA_MAPPING
prompt =======================================
prompt
create table T_DICT_CLEARDATA_MAPPING
(
  f_resource_name       VARCHAR2(255),
  f_table_name          VARCHAR2(30),
  f_col_name            VARCHAR2(30),
  f_table_type          NUMBER(6),
  f_clear_data_procname VARCHAR2(30),
  f_description         VARCHAR2(2000)
)
;
comment on column T_DICT_CLEARDATA_MAPPING.f_table_type
  is '10:do nothing 20:trunc normal table 30:trunc partition table';


spool off
