------------------------------------------------------------
-- Export file for user DEVELOPER@BI_RACDB1_111.13.20.109 --
-- Created by Administrator on 2015/6/3, 15:39:58 ----------
------------------------------------------------------------

set define off
spool ---Pkg_Log_HOUR_SUN.log

prompt
prompt Creating package PKG_LOG_HOUR_SUN
prompt =================================
prompt
CREATE OR REPLACE Package Pkg_Log_HOUR_SUN Is

  -- Author  :
  -- Created :
  -- Purpose : ��־��
  --��־��ʼ
  Procedure Sp_Run_Log_Start(p_Errsource Varchar2,
                             p_Appid     Varchar2,
                             Inputdate   Number);
  --��־������
  Procedure Sp_Run_Log_End(p_Errsource Varchar2,
                           p_Appid     Varchar2,
                           Inputdate   Number);
  --��־����״̬
  Procedure Sp_Run_Log_Error(p_Errsource Varchar2,
                             p_Appid     Varchar2,
                             Inputdate   Number);
  --������־��Ϣ
  Procedure Sp_Error_Log(p_Errcode     Varchar2,
                         p_Errsource   Varchar2,
                         p_Errinfo     Varchar2,
                         p_Errposition Varchar2,
                         p_Appid       Varchar2);
End Pkg_Log_HOUR_SUN;
/

prompt
prompt Creating package body PKG_LOG_HOUR_SUN
prompt ======================================
prompt
CREATE OR REPLACE Package Body Pkg_Log_HOUR_SUN Is
  /*********************************************************************************************************/
  --��־��ʼ
  Procedure Sp_Run_Log_Start(p_Errsource Varchar2,
                             p_Appid     Varchar2,
                             Inputdate   Number) Is
  Begin
    --ɾ��������־��Ϣ
    Delete From PRO_LOG_HOUR t
     Where t.Pro_Name = Upper(p_Errsource)
       And t.Data_Date = To_Char(Sysdate - Inputdate, 'yyyy-mm-dd HH24')
       And t.Appid = p_Appid;
    Commit;
    --�ڹ���ִ�п�ʼ������־һ����Ϣ ���ݰ������洢�������ƺͿ�ʼʱ�䣩
    Insert Into PRO_LOG_HOUR
      (Id, Pro_Name, Start_Time, Status, Appid, Data_Date)
    Values
      (Seq_Pro_Log.Nextval,
       Upper(p_Errsource),
       Sysdate,
       'RUNING',
       p_Appid,
       To_Char(Sysdate - Inputdate, 'yyyy-mm-dd HH24'));
    Commit;
  End;
  /*********************************************************************************************************/
  --��־������
  Procedure Sp_Run_Log_End(p_Errsource Varchar2,
                           p_Appid     Varchar2,
                           Inputdate   Number) Is
  Begin
    Update PRO_LOG_HOUR t
       Set t.End_Time = Sysdate,
           t.Exe_Time =
           (Sysdate - t.Start_Time) * 24 * 60 * 60,
           t.Status   = 'SUCCESS'
     Where t.Pro_Name = Upper(p_Errsource)
       And t.Appid = p_Appid
       And t.Data_Date = To_Char(Sysdate - Inputdate, 'yyyy-mm-dd HH24');
    Commit;
  End;
  /*********************************************************************************************************/
  --��־����״̬
  Procedure Sp_Run_Log_Error(p_Errsource Varchar2,
                             p_Appid     Varchar2,
                             Inputdate   Number) Is
  Begin
    Update PRO_LOG_HOUR t
       Set t.Status = 'ERROR'
     Where t.Pro_Name = Upper(p_Errsource)
       And t.Appid = p_Appid
       And t.Data_Date = To_Char(Sysdate - Inputdate, 'yyyy-mm-dd HH24');
    Commit;
  End;
  /*********************************************************************************************************/
  --������־��Ϣ
  Procedure Sp_Error_Log(p_Errcode     Varchar2,
                         p_Errsource   Varchar2,
                         p_Errinfo     Varchar2,
                         p_Errposition Varchar2,
                         p_Appid       Varchar2) Is
  Begin
    Insert Into Error_Log_HOUR
      (Error_Id,
       Error_Createtime,
       Error_Code,
       Error_Source,
       Error_Localinfo,
       Error_Position,
       Error_Appid)
    Values
      (Seq_Error_Log.Nextval,
       Sysdate,
       p_Errcode,
       p_Errsource,
       p_Errinfo,
       p_Errposition,
       p_Appid);
    Commit;
  End;
End Pkg_Log_HOUR_SUN;
/


spool off
