------------------------------------------------------------
-- Export file for user DEVELOPER@BI_RACDB1_111.13.20.109 --
-- Created by Administrator on 2015/6/4, 17:10:15 ----------
------------------------------------------------------------

set define off
spool --pakage-bodyPkg_Fact_Firm.log

prompt
prompt Creating package PKG_FACT_FIRM
prompt ==============================
prompt
CREATE OR REPLACE Package Pkg_Fact_Firm Is

  -- Author  : ADMINISTRATOR
  -- Created : 2014-11-04 16:49:46
  -- Purpose : ��˾���ݻ���

  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2);
  --��˾�����豸����
  Procedure p_Fact_Mac(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2);
  --��˾�����豸����
  Procedure p_Fact_Dvid(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2);
  --��˾SDK�������
  Procedure p_Fact_Sdk_Income(p_Logtime In Varchar2,
                              p_Errcode Out Number,
                              p_Errstr  Out Varchar2);
End Pkg_Fact_Firm;
/

prompt
prompt Creating package body PKG_FACT_FIRM
prompt ===================================
prompt
CREATE OR REPLACE Package Body Pkg_Fact_Firm Is
  /******************************************ִ������***************************************************************/
  --ִ������
  Procedure p_All(p_Logtime In Varchar2,
                  p_Errcode Out Number,
                  p_Errstr  Out Varchar2) Is
  Begin
    p_Fact_Mac(p_Logtime, p_Errcode, p_Errstr);
    p_Fact_Dvid(p_Logtime, p_Errcode, p_Errstr);
  End;
  /******************************************��˾�����豸����***************************************************************/
  --��˾�����豸����
  Procedure p_Fact_Mac(p_Logtime In Varchar2,
                       p_Errcode Out Number,
                       p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
    v_Weekfirstday Varchar2(10); --���������ҳ� ������������ܵĵ�һ��
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    --�ܵ�һ��ļ��㷽�� TRUNC(SYSDATE)-(TO_CHAR(SYSDATE-1, 'D')-1)����������һ�ǵ�һ��
    --��ȡ�ܵ�һ��
    Select To_Char(Trunc(Sysdate - v_Inputdate + 1) -
                   Decode((To_Char(Sysdate - v_Inputdate, 'D') - 1),
                          0,
                          7,
                          (To_Char(Sysdate - v_Inputdate, 'D') - 1)),
                   'YYYY-MM-DD')
      Into v_Weekfirstday
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Fact_Firm.p_Fact_Mac';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, 'firm', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From Fact_Firm_Dvid t
     Where t.Statdate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD')
       And t.Date_Type = 'D'
       And t.Dvid_Tpye = '1';
    Commit;
    v_Errposition := '1-2';
    Insert Into Fact_Firm_Dvid
      Select T2.Statdate,
             'D',
             '1',
             T2.Channelid,
             T2.Platform,
             T2.Country_Type,
             T2.Online_Type,
             Nvl(T1.Cc, 0),
             Sysdate,
             v_Errsource
        From (Select t.Thedate,
                     t.Channelid,
                     t.Platform,
                     t.Country_Type,
                     t.Online_Type,
                     Count(1) Cc
                From t_Firm_Nu_Mac t
               Where t.Thedate =
                     To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD')
               Group By t.Thedate,
                        t.Channelid,
                        t.Platform,
                        t.Country_Type,
                        t.Online_Type) T1
       Right Join (Select To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') Statdate,
                          Da.Channelid,
                          Da.Platform,
                          Do.Online_Type,
                          Dc.Country_Type
                     From Dim_Onlinetype Do,
                          Dim_Countrytype Dc,
                          (Select Distinct t.Channelid, t.Platform
                             From Dim_Appchannel t) Da) T2
          On T1.Channelid = T2.Channelid
         And T1.Platform = T2.Platform
         And T1.Online_Type = T2.Online_Type
         And T1.Country_Type = T2.Country_Type;
    Commit;
    v_Errposition := '1-3';
    Delete From Fact_Firm_Dvid t
     Where t.Statdate = v_Weekfirstday
       And t.Date_Type = 'W'
       And t.Dvid_Tpye = '1';
    Commit;
    v_Errposition := '1-4';
    Insert Into Fact_Firm_Dvid
      Select v_Weekfirstday,
             'W',
             '1',
             t.Channelid,
             t.Platform,
             t.Country_Type,
             t.Online_Type,
             Sum(t.Dvid_Data),
             Sysdate,
             v_Errsource
        From Fact_Firm_Dvid t
       Where t.Statdate >= v_Weekfirstday
         And t.Statdate < To_Char(Sysdate - v_Inputdate + 1, 'YYYY-MM-DD')
         And t.Date_Type = 'D'
         And t.Dvid_Tpye = '1'
       Group By t.Channelid, t.Platform, t.Country_Type, t.Online_Type;
    Commit;
    v_Errposition := '1-5';
    Delete From Fact_Firm_Dvid t
     Where t.Statdate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM')
       And t.Date_Type = 'M'
       And t.Dvid_Tpye = '1';
    Commit;
    v_Errposition := '1-6';
    Insert Into Fact_Firm_Dvid
      Select To_Char(Sysdate - v_Inputdate, 'YYYY-MM'),
             'M',
             '1',
             t.Channelid,
             t.Platform,
             t.Country_Type,
             t.Online_Type,
             Sum(t.Dvid_Data),
             Sysdate,
             v_Errsource
        From Fact_Firm_Dvid t
       Where t.Statdate >=
             To_Char(Trunc(Sysdate - v_Inputdate, 'MM'), 'YYYY-MM-DD')
         And t.Statdate <=
             To_Char(Last_Day(Sysdate - v_Inputdate), 'YYYY-MM-DD')
         And t.Date_Type = 'D'
         And t.Dvid_Tpye = '1'
       Group By t.Channelid, t.Platform, t.Country_Type, t.Online_Type;
    Commit;
    v_Errposition := '1-5';
    Delete From Fact_Firm_Dvid t
     Where t.Statdate = To_Char(Sysdate - v_Inputdate, 'YYYY')
       And t.Date_Type = 'Y'
       And t.Dvid_Tpye = '1';
    Commit;
    v_Errposition := '1-6';
    Insert Into Fact_Firm_Dvid
      Select To_Char(Sysdate - v_Inputdate, 'YYYY'),
             'Y',
             '1',
             t.Channelid,
             t.Platform,
             t.Country_Type,
             t.Online_Type,
             Sum(t.Dvid_Data),
             Sysdate,
             v_Errsource
        From Fact_Firm_Dvid t
       Where t.Statdate >= To_Char(Sysdate - v_Inputdate, 'yyyy') || '-01'
         And t.Statdate <= To_Char(Sysdate - v_Inputdate, 'yyyy') || '-12'
         And t.Date_Type = 'M'
         And t.Dvid_Tpye = '1'
       Group By t.Channelid, t.Platform, t.Country_Type, t.Online_Type;
    Commit;
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, 'firm', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=Fact_Firm_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           'firm');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, 'firm', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾�����豸����***************************************************************/
  --��˾�����豸����
  Procedure p_Fact_Dvid(p_Logtime In Varchar2,
                        p_Errcode Out Number,
                        p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
    v_Weekfirstday Varchar2(10); --���������ҳ� ������������ܵĵ�һ��
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    --�ܵ�һ��ļ��㷽�� TRUNC(SYSDATE)-(TO_CHAR(SYSDATE-1, 'D')-1)����������һ�ǵ�һ��
    --��ȡ�ܵ�һ��
    Select To_Char(Trunc(Sysdate - v_Inputdate + 1) -
                   Decode((To_Char(Sysdate - v_Inputdate, 'D') - 1),
                          0,
                          7,
                          (To_Char(Sysdate - v_Inputdate, 'D') - 1)),
                   'YYYY-MM-DD')
      Into v_Weekfirstday
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Fact_Firm.p_Fact_Dvid';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, 'firm', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From Fact_Firm_Dvid t
     Where t.Statdate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD')
       And t.Date_Type = 'D'
       And t.Dvid_Tpye = '2';
    Commit;
    v_Errposition := '1-2';
    Insert Into Fact_Firm_Dvid
      Select T2.Statdate,
             'D',
             '2',
             T2.Channelid,
             T2.Platform,
             T2.Country_Type,
             T2.Online_Type,
             Nvl(T1.Cc, 0),
             Sysdate,
             v_Errsource
        From (Select t.Thedate,
                     t.Channelid,
                     t.Platform,
                     t.Country_Type,
                     t.Online_Type,
                     Count(1) Cc
                From t_Firm_Nu_Dvid t
               Where t.Thedate =
                     To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD')
               Group By t.Thedate,
                        t.Channelid,
                        t.Platform,
                        t.Country_Type,
                        t.Online_Type) T1
       Right Join (Select To_Char(Sysdate - v_Inputdate, 'yyyy-mm-dd') Statdate,
                          Da.Channelid,
                          Da.Platform,
                          Do.Online_Type,
                          Dc.Country_Type
                     From Dim_Onlinetype Do,
                          Dim_Countrytype Dc,
                          (Select Distinct t.Channelid, t.Platform
                             From Dim_Appchannel t) Da) T2
          On T1.Channelid = T2.Channelid
         And T1.Platform = T2.Platform
         And T1.Online_Type = T2.Online_Type
         And T1.Country_Type = T2.Country_Type;
    Commit;
    v_Errposition := '1-3';
    Delete From Fact_Firm_Dvid t
     Where t.Statdate = v_Weekfirstday
       And t.Date_Type = 'W'
       And t.Dvid_Tpye = '2';
    Commit;
    v_Errposition := '1-4';
    Insert Into Fact_Firm_Dvid
      Select v_Weekfirstday,
             'W',
             '2',
             t.Channelid,
             t.Platform,
             t.Country_Type,
             t.Online_Type,
             Sum(t.Dvid_Data),
             Sysdate,
             v_Errsource
        From Fact_Firm_Dvid t
       Where t.Statdate >= v_Weekfirstday
         And t.Statdate < To_Char(Sysdate - v_Inputdate + 1, 'YYYY-MM-DD')
         And t.Date_Type = 'D'
         And t.Dvid_Tpye = '2'
       Group By t.Channelid, t.Platform, t.Country_Type, t.Online_Type;
    Commit;
    v_Errposition := '1-5';
    Delete From Fact_Firm_Dvid t
     Where t.Statdate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM')
       And t.Date_Type = 'M'
       And t.Dvid_Tpye = '2';
    Commit;
    v_Errposition := '1-6';
    Insert Into Fact_Firm_Dvid
      Select To_Char(Sysdate - v_Inputdate, 'YYYY-MM'),
             'M',
             '2',
             t.Channelid,
             t.Platform,
             t.Country_Type,
             t.Online_Type,
             Sum(t.Dvid_Data),
             Sysdate,
             v_Errsource
        From Fact_Firm_Dvid t
       Where t.Statdate >=
             To_Char(Trunc(Sysdate - v_Inputdate, 'MM'), 'YYYY-MM-DD')
         And t.Statdate <=
             To_Char(Last_Day(Sysdate - v_Inputdate), 'YYYY-MM-DD')
         And t.Date_Type = 'D'
         And t.Dvid_Tpye = '2'
       Group By t.Channelid, t.Platform, t.Country_Type, t.Online_Type;
    Commit;
    v_Errposition := '1-5';
    Delete From Fact_Firm_Dvid t
     Where t.Statdate = To_Char(Sysdate - v_Inputdate, 'YYYY')
       And t.Date_Type = 'Y'
       And t.Dvid_Tpye = '2';
    Commit;
    v_Errposition := '1-6';
    Insert Into Fact_Firm_Dvid
      Select To_Char(Sysdate - v_Inputdate, 'YYYY'),
             'Y',
             '2',
             t.Channelid,
             t.Platform,
             t.Country_Type,
             t.Online_Type,
             Sum(t.Dvid_Data),
             Sysdate,
             v_Errsource
        From Fact_Firm_Dvid t
       Where t.Statdate >= To_Char(Sysdate - v_Inputdate, 'yyyy') || '-01'
         And t.Statdate <= To_Char(Sysdate - v_Inputdate, 'yyyy') || '-12'
         And t.Date_Type = 'M'
         And t.Dvid_Tpye = '2'
       Group By t.Channelid, t.Platform, t.Country_Type, t.Online_Type;
    Commit;
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, 'firm', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=Fact_Firm_Dvid';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           'firm');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, 'firm', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
  /******************************************��˾SDK�������***************************************************************/
  --��˾SDK�������
  Procedure p_Fact_Sdk_Income(p_Logtime In Varchar2,
                              p_Errcode Out Number,
                              p_Errstr  Out Varchar2) Is
    v_Errposition  Varchar2(100); --λ��
    v_Errlocalinfo Varchar2(200); --���ػ���Ϣ
    v_Errsource    Varchar2(100); --��Դ
    v_Errcode      Varchar2(200); --���ݿ�������
    v_Inputdate    Number := 0;
    v_Weekfirstday Varchar2(10); --���������ҳ� ������������ܵĵ�һ��
  Begin
    p_Errcode := 7100;
    Select Trunc(Sysdate) -
           Trunc(To_Date(p_Logtime, 'YYYY-MM-DD HH24:MI:SS'))
      Into v_Inputdate
      From Dual;
    --�ܵ�һ��ļ��㷽�� TRUNC(SYSDATE)-(TO_CHAR(SYSDATE-1, 'D')-1)����������һ�ǵ�һ��
    --��ȡ�ܵ�һ��
    Select To_Char(Trunc(Sysdate - v_Inputdate + 1) -
                   Decode((To_Char(Sysdate - v_Inputdate, 'D') - 1),
                          0,
                          7,
                          (To_Char(Sysdate - v_Inputdate, 'D') - 1)),
                   'YYYY-MM-DD')
      Into v_Weekfirstday
      From Dual;
    ------------------------------ִ����־��ʼ----------------------------------------------
    v_Errsource := 'Pkg_Fact_Firm.p_Fact_Sdk_Income';
    Pkg_Log.Sp_Run_Log_Start(v_Errsource, 'firm', v_Inputdate);
    ------------------------------ִ����־��ʼ----------------------------------------------
  
    v_Errposition := '1-1';
    Delete From Fact_Firm_Sdk_Income t
     Where t.Statdate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD')
       And t.Date_Type = 'D';
    Commit;
    v_Errposition := '1-2';
    Insert Into Fact_Firm_Sdk_Income
      Select t.Thedate,
             'D',
             t.Channelid,
             d.Platform,
             d.Country_Type,
             d.Online_Type,
             Sum(t.Amount) Amount,
             Sysdate,
             v_Errsource
        From (Select *
                From t_Firm_Sdk_Income Tt
               Where Tt.Thedate =
                     To_Char(Sysdate - v_Inputdate, 'YYYY-MM-DD')) t
       Inner Join Dim_App d
          On t.Appid = d.Appid
       Group By t.Thedate,
                t.Channelid,
                d.Platform,
                d.Country_Type,
                d.Online_Type;
    Commit;
    v_Errposition := '1-3';
    Delete From Fact_Firm_Sdk_Income t
     Where t.Statdate = v_Weekfirstday
       And t.Date_Type = 'W';
    Commit;
    v_Errposition := '1-4';
    Insert Into Fact_Firm_Sdk_Income
      Select v_Weekfirstday,
             'W',
             t.Channelid,
             t.Platform,
             t.Country_Type,
             t.Online_Type,
             Sum(t.Amount),
             Sysdate,
             v_Errsource
        From Fact_Firm_Sdk_Income t
       Where t.Statdate >= v_Weekfirstday
         And t.Statdate < To_Char(Sysdate - v_Inputdate + 1, 'YYYY-MM-DD')
         And t.Date_Type = 'D'
       Group By t.Channelid, t.Platform, t.Country_Type, t.Online_Type;
    Commit;
    v_Errposition := '1-5';
    Delete From Fact_Firm_Sdk_Income t
     Where t.Statdate = To_Char(Sysdate - v_Inputdate, 'YYYY-MM')
       And t.Date_Type = 'M';
    Commit;
    v_Errposition := '1-6';
    Insert Into Fact_Firm_Sdk_Income
      Select To_Char(Sysdate - v_Inputdate, 'YYYY-MM'),
             'M',
             t.Channelid,
             t.Platform,
             t.Country_Type,
             t.Online_Type,
             Sum(t.Amount),
             Sysdate,
             v_Errsource
        From Fact_Firm_Sdk_Income t
       Where t.Statdate >=
             To_Char(Trunc(Sysdate - v_Inputdate, 'MM'), 'YYYY-MM-DD')
         And t.Statdate <=
             To_Char(Last_Day(Sysdate - v_Inputdate), 'YYYY-MM-DD')
         And t.Date_Type = 'D'
       Group By t.Channelid, t.Platform, t.Country_Type, t.Online_Type;
    Commit;
    v_Errposition := '1-5';
    Delete From Fact_Firm_Sdk_Income t
     Where t.Statdate = To_Char(Sysdate - v_Inputdate, 'YYYY')
       And t.Date_Type = 'Y';
    Commit;
    v_Errposition := '1-6';
    Insert Into Fact_Firm_Sdk_Income
      Select To_Char(Sysdate - v_Inputdate, 'YYYY'),
             'Y',
             t.Channelid,
             t.Platform,
             t.Country_Type,
             t.Online_Type,
             Sum(t.Amount),
             Sysdate,
             v_Errsource
        From Fact_Firm_Sdk_Income t
       Where t.Statdate >= To_Char(Sysdate - v_Inputdate, 'yyyy') || '-01'
         And t.Statdate <= To_Char(Sysdate - v_Inputdate, 'yyyy') || '-12'
         And t.Date_Type = 'M'
       Group By t.Channelid, t.Platform, t.Country_Type, t.Online_Type;
    Commit;
    ------------------------------ִ����־����----------------------------------------------
    Pkg_Log.Sp_Run_Log_End(v_Errsource, 'firm', v_Inputdate);
    ------------------------------ִ����־����----------------------------------------------
  Exception
    When Others Then
      Rollback;
      p_Errcode      := 8100;
      p_Errstr       := 'SQLCODE:' || Sqlcode || ' SQLERRM:' || Sqlerrm;
      v_Errlocalinfo := 'TABLE NAME=Fact_Firm_Sdk_Income';
      v_Errcode      := Substr(Sqlerrm, 1, 200);
      Pkg_Log.Sp_Error_Log(v_Errcode,
                           v_Errsource,
                           v_Errlocalinfo,
                           v_Errposition,
                           'firm');
      Pkg_Log.Sp_Run_Log_Error(v_Errsource, 'firm', v_Inputdate);
      ------------------------------�쳣����----------------------------------------------
  End;
End Pkg_Fact_Firm;
/


spool off
