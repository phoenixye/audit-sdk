Select t.Statdate,
       Sum(t.Payamount) Payamount,
       Sum(t.Newcount) Newcount_Dvid,
       Sum(t.Conncount) Conncount_Dvid,
       Sum(t4.Newcount) Newcount_user,
       Sum(t4.Conncount) Conncount_user,
       Sum(T2.Paysuccnum) Paysuccnum,
       Sum(T3.Payfailnum) Payfailnum,
       Sum(t.Paycount) Paycount_Dvid,
       Sum(t.Payamount) Payamount_Dvid,
       Sum(t4.Paycount) Paycount_user
  From (Select *
          From Developer.v_Fact_100197_General_Hour
         Where Datatype = '2'
           And serverid = 'all') t
  Left Join (Select To_Char(Tos.Thedate, 'yyyy-mm-dd hh24') Statdate,
                    Tos.Channelid,
                    Tos.Gameid Appid,
                    Tos.Gameversion Versionid,
                    Count(Tos.Orderid) Paysuccnum
               From Developer.t_100197_Order_Succ@Racdb2_Dev Tos
              Group By To_Char(Tos.Thedate, 'yyyy-mm-dd hh24'),
                       Tos.Channelid,
                       Tos.Gameid,
                       Tos.Gameversion) T2
    On T2.Statdate = t.Statdate
   And t.Channelid = T2.Channelid
   And t.Appid = T2.Appid
   And t.Versionid = T2.Versionid
  Left Join (Select To_Char(Tos.Thedate, 'yyyy-mm-dd hh24') Statdate,
                    Tos.Channelid,
                    Tos.Gameid Appid,
                    Tos.Gameversion Versionid,
                    Count(Tos.Orderid) Payfailnum
               From Developer.t_100197_Order_Failure/*@Racdb2_Dev*/ Tos
              Group By To_Char(Tos.Thedate, 'yyyy-mm-dd hh24'),
                       Tos.Channelid,
                       Tos.Gameid,
                       Tos.Gameversion) T3
    On T3.Statdate = t.Statdate
   And t.Channelid = T3.Channelid
   And t.Appid = T3.Appid
   And t.Versionid = T3.Versionid
 RIGHT Join (Select *
               From Developer.v_Fact_100197_General_Hour
              Where Datatype = '1'
                And serverid = 'all') t4
    On t4.Statdate = t.Statdate
   And t.Channelid = t4.Channelid
   And t.Appid = t4.Appid
   And t.Versionid = t4.Versionid
 Where t.statdate >= '2015-06-05 00'
   and t.statdate <= '2015-06-05 23'
   and t.serverid = 'all'
 Group By t.Statdate
 Order By t.Statdate
