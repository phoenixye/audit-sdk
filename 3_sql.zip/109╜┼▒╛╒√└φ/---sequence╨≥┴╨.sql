------------------------------------------------------------
-- Export file for user DEVELOPER@BI_RACDB1_111.13.20.109 --
-- Created by Administrator on 2015/6/3, 16:00:35 ----------
------------------------------------------------------------

set define off
spool ---sequence����.log

prompt
prompt Creating sequence PLSQL_PROFILER_RUNNUMBER
prompt ==========================================
prompt
create sequence PLSQL_PROFILER_RUNNUMBER
minvalue 1
maxvalue 9999999999999999999999999999
start with 1
increment by 1
nocache;

prompt
prompt Creating sequence SEQ_ERROR_LOG
prompt ===============================
prompt
create sequence SEQ_ERROR_LOG
minvalue 1
maxvalue 99999999999999
start with 6425
increment by 1
cache 20;

prompt
prompt Creating sequence SEQ_PRO_LOG
prompt =============================
prompt
create sequence SEQ_PRO_LOG
minvalue 1
maxvalue 99999999999999
start with 7956518
increment by 1
cache 20;

prompt
prompt Creating sequence SEQ_TASK_FILE_TRANTS
prompt ======================================
prompt
create sequence SEQ_TASK_FILE_TRANTS
minvalue 1
maxvalue 99999999999999
start with 1265333
increment by 1
cache 20;

prompt
prompt Creating sequence S_TASK_PROC_RUN
prompt =================================
prompt
create sequence S_TASK_PROC_RUN
minvalue 1
maxvalue 9999999999999999999
start with 10279371
increment by 1
cache 20;


spool off
