------------------------------------------------------------
-- Export file for user DEVELOPER@BI_RACDB1_111.13.20.109 --
-- Created by Administrator on 2015/6/4, 10:53:15 ----------
------------------------------------------------------------

set define off
spool ---��ͼ����1.log

prompt
prompt Creating view V_DIM_APP
prompt =======================
prompt
create or replace force view v_dim_app as
Select "APPID","APPNAME","PLATFORM","LOADDATE","ISDISPLAY" From dim_app;

prompt
prompt Creating view V_DIM_APPCHANNEL
prompt ==============================
prompt
create or replace force view v_dim_appchannel as
Select "APPCHANNELID","APPID","APPNAME","PLATFORM","CHANNELID","OLDCHANNELNAME","CHANNELNAME","LOADDATE" From dim_appchannel;

prompt
prompt Creating view V_DIM_APPSERVER
prompt =============================
prompt
create or replace force view v_dim_appserver as
Select "APPSERVERID","APPID","APPNAME","SERVERID","SERVERNAME","LOADDATE" From dim_appserver;

prompt
prompt Creating view V_DIM_APPVERSION
prompt ==============================
prompt
create or replace force view v_dim_appversion as
Select "APPVERSIONID","APPID","APPNAME","VERSIONID","VERSIONNAME","LOADDATE" From dim_appversion;

prompt
prompt Creating view V_DIM_NET
prompt =======================
prompt
create or replace force view v_dim_net as
Select "NETID","NETNAME","LOADDATE" From DIM_NET;

prompt
prompt Creating view V_DIM_OPERATOR
prompt ============================
prompt
create or replace force view v_dim_operator as
Select "OPERATORID","OPERATORNAME","LOADDATE" From DIM_OPERATOR;

prompt
prompt Creating view V_FACT_100091_BACK_MAC
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_BACK_MAC AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","LOST_DAYS","BACK_CONN","BACK_PAY","LOADDATE","DATA_SOURCE" FROM FACT_100091_BACK_MAC;

prompt
prompt Creating view V_FACT_100091_BACK_MAC_MONTH
prompt ==========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_BACK_MAC_MONTH AS
SELECT T1.STATDATE,
       T1.CHANNELID,
       T1.SERVERID,
       T1.APPID,
       T2.CONNCOUNT,
       T2.PAYCOUNT,
       T1.BACK_CONN,
       T1.BACK_PAY
  FROM FACT_100091_BACK_MAC_MONTH T1
 INNER JOIN (SELECT FGW.STATDATE,
                    FGW.CHANNELID,
                    FGW.SERVERID,
                    FGW.APPID,
                    SUM(FGW.NEWCOUNT) NEWCOUNT,
                    SUM(FGW.CONNCOUNT) CONNCOUNT,
                    SUM(FGW.PAYCOUNT) PAYCOUNT,
                    SUM(FGW.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100091_GENERAL_MONTH FGW
              WHERE FGW.DATATYPE = '2'
              GROUP BY FGW.STATDATE, FGW.CHANNELID, FGW.SERVERID, FGW.APPID) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID;

prompt
prompt Creating view V_FACT_100091_BACK_MAC_WEEK
prompt =========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_BACK_MAC_WEEK AS
SELECT T1.STATDATE,
       T1.CHANNELID,
       T1.SERVERID,
       T1.APPID,
       T2.CONNCOUNT,
       T2.PAYCOUNT,
       T1.BACK_CONN,
       T1.BACK_PAY
  FROM FACT_100091_BACK_MAC_WEEK T1
 INNER JOIN (SELECT FGW.STATDATE,
                    FGW.CHANNELID,
                    FGW.SERVERID,
                    FGW.APPID,
                    SUM(FGW.NEWCOUNT) NEWCOUNT,
                    SUM(FGW.CONNCOUNT) CONNCOUNT,
                    SUM(FGW.PAYCOUNT) PAYCOUNT,
                    SUM(FGW.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100091_GENERAL_WEEK FGW
              WHERE FGW.DATATYPE = '2'
              GROUP BY FGW.STATDATE, FGW.CHANNELID, FGW.SERVERID, FGW.APPID) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID;

prompt
prompt Creating view V_FACT_100091_BACK_USER
prompt =====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_BACK_USER AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","LOST_DAYS","BACK_CONN","BACK_PAY","LOADDATE","DATA_SOURCE" FROM FACT_100091_BACK_USER;

prompt
prompt Creating view V_FACT_100091_CEVENT
prompt ==================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_CEVENT AS
SELECT T.STATDATE,
       T.CHANNELID,
       T.SERVERID,
       T.APPID,
       T.VERSIONID,
       T.EVENTKEY,
       T.EVENTCOUNT,
       T.EVENTNUM
  FROM FACT_100091_CEVENT T;

prompt
prompt Creating view V_FACT_100091_CEVENT_PAR
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_CEVENT_PAR AS
SELECT STATDATE,
       CHANNELID,
       SERVERID,
       APPID,
       VERSIONID,
       ILEVEL,
       EVENTKEY,
       EVENTPAR_KEY,
       EVENTPAR_VALUE,
       EVENTCOUNT,
       EVENTNUM
  FROM FACT_100091_CEVENT_PAR;

prompt
prompt Creating view V_FACT_100091_COMP_CEVENT
prompt =======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_COMP_CEVENT AS
SELECT STATDATE,
       APPID,
       CHANNELID,
       GAMEVERSION,
       SERVERID,
       ILEVEL,
       EVENTKEY,
       COMPID,
       CALTYPE,
       DIMPARS,
       COMP_DATA
  FROM FACT_100091_COMP_CEVENT;

prompt
prompt Creating view V_FACT_100091_CONNDAYS
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_CONNDAYS AS
SELECT TT.GAMEID APPID,
       TT.CHANNELID,
       TT.SERVERID,
       TT.CONNDAYS,
       TT.CONNCOUNT,
       DD.ALL_CONNCOUNT
  FROM (SELECT D.GAMEID,
               D.CONNDAYS,
               D.CHANNELID,
               D.SERVERID,
               COUNT(1) CONNCOUNT
          FROM (SELECT TC.GAMEID,
                       TC.CHANNELID,
                       TC.SERVERID,
                       TC.ACCOUNTID,
                       COUNT(TC.CONNDATE) CONNDAYS
                  FROM T_100091_CONN TC
                 GROUP BY TC.GAMEID, TC.CHANNELID, TC.SERVERID, TC.ACCOUNTID) D
         GROUP BY D.GAMEID, D.CONNDAYS, D.CHANNELID, D.SERVERID) TT
 INNER JOIN (SELECT T.GAMEID,
                    T.CHANNELID,
                    T.SERVERID,
                    COUNT(DISTINCT T.ACCOUNTID) ALL_CONNCOUNT
               FROM T_100091_CONN T
              GROUP BY T.GAMEID, T.CHANNELID, T.SERVERID) DD
    ON TT.GAMEID = DD.GAMEID
   AND TT.CHANNELID = DD.CHANNELID
   AND TT.SERVERID = DD.SERVERID;

prompt
prompt Creating view V_FACT_100091_CONN_CON
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_CONN_CON AS
SELECT T1.STATDATE,
       T1.CHANNELID,
       T1.SERVERID,
       T1.APPID,
       T1.NEWCOUNT,
       T1.CONNCOUNT,
       NVL(T2.BACK_CONN,0) BACK_CONN7,
			 T1.CONNCOUNT-T1.NEWCOUNT-NVL(T2.BACK_CONN,0) CONN7
  FROM (SELECT T.STATDATE,
               T.CHANNELID,
               T.SERVERID,
               T.APPID,
               SUM(T.NEWCOUNT) NEWCOUNT,
               SUM(T.CONNCOUNT) CONNCOUNT
          FROM FACT_100091_GENERAL_DAY T
         WHERE T.DATATYPE = '1'
         GROUP BY T.STATDATE, T.CHANNELID, T.SERVERID, T.APPID) T1
 LEFT JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    SUM(T.BACK_CONN) BACK_CONN
               FROM FACT_100091_BACK_USER T
              WHERE T.LOST_DAYS > 7
              GROUP BY T.STATDATE, T.CHANNELID, T.SERVERID, T.APPID) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID;

prompt
prompt Creating view V_FACT_100091_DAILY_REPORT
prompt ========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_DAILY_REPORT AS
SELECT "STATDATE","APPID","CHANNELID","SERVERID","INDEXID","INDTYPE","RPT_DATA","LOADDATE","DATA_SOURCE" FROM FACT_100091_DAILY_REPORT;

prompt
prompt Creating view V_FACT_100091_DVID
prompt ================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_DVID AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","DVID_MODEL","DVID_RES","DVID_OS","NEWCOUNT","CONNCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100091_DVID;

prompt
prompt Creating view V_FACT_100091_FIRSTPAY
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_FIRSTPAY AS
SELECT FF.STATDATE,
       FF.FIRSTPAYDATE,
       FF.CHANNELID,
       FF.SERVERID,
       FF.DATATYPE,
       FF.APPID,
       FF.FIRST_PAYFROMREG,
       FF.FIRST_PAYCOUNT,
       FF.PAYAMOUNT,
       FGD.NEWCOUNT
  FROM FACT_100091_FIRSTPAY FF
 INNER JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.DATATYPE,
                    T.APPID,
                    SUM(T.NEWCOUNT) NEWCOUNT
               FROM FACT_100091_GENERAL_DAY T
              GROUP BY T.STATDATE,
                       T.CHANNELID,
                       T.SERVERID,
                       T.DATATYPE,
                       T.APPID) FGD
    ON FF.STATDATE = FGD.STATDATE
   AND FF.CHANNELID = FGD.CHANNELID
   AND FF.SERVERID = FGD.SERVERID
   AND FF.DATATYPE = FGD.DATATYPE
   AND FF.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100091_FIRSTPAY_AMOUNT
prompt ===========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_FIRSTPAY_AMOUNT AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYAMOUNT","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100091_FIRSTPAY_AMOUNT T;

prompt
prompt Creating view V_FACT_100091_FIRSTPAY_ARPPU
prompt ==========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_FIRSTPAY_ARPPU AS
SELECT T1.STATDATE,
       T1.CHANNELID,
       T1.SERVERID,
       T1.APPID,
       T1.FIRST_PAYFROMREG,
       T1.FIRST_PAYCOUNT,
       T2.PAYAMOUNT
  FROM (SELECT * FROM FACT_100091_FIRSTPAY F WHERE F.DATATYPE = '1') T1
 INNER JOIN FACT_100091_LTV_USER T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID
   AND T1.FIRST_PAYFROMREG = T2.LTV_DAYS - 1;

prompt
prompt Creating view V_FACT_100091_GENERAL_DAY
prompt =======================================
prompt
create or replace force view v_fact_100091_general_day as
Select Statdate,
       Channelid,
       Serverid,
       Datatype,
       Appid,
       Versionid,
       Newcount,
       Conncount,
       Paycount,
       Payamount
  From Fact_100091_General_Day;

prompt
prompt Creating view V_FACT_100091_GENERAL_DAY_DVID
prompt ============================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_GENERAL_DAY_DVID AS
SELECT T2.STATDATE,
       T2.CHANNELID,
       '100091' APPID,
       NVL(NEWCOUNT, 0) NEWCOUNT,
       NVL(CONNCOUNT, 0) CONNCOUNT
  FROM FACT_100091_GENERAL_DAY_DVID T1
 RIGHT JOIN (SELECT DD.DAY_DES STATDATE, DAC.CHANNELID
               FROM DIM_DAY DD, V_DIM_APPCHANNEL DAC
              WHERE DAC.APPID = '100091'
                AND DD.DAY_DES <= TO_CHAR(SYSDATE, 'YYYY-MM-DD')) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
--WHERE T2.STATDATE BETWEEN '2014-09-25' AND '2014-09-29'
;

prompt
prompt Creating view V_FACT_100091_GENERAL_HOUR
prompt ========================================
prompt
create or replace force view v_fact_100091_general_hour as
Select T.STATDATE,
               T.CHANNELID,
               T.SERVERID,
               T.DATATYPE,
               T.APPID,
               T.VERSIONID,
               T.NEWCOUNT,
               T.CONNCOUNT,
               T.PAYCOUNT,
               T.PAYAMOUNT
          FROM FACT_100091_GENERAL_HOUR T;

prompt
prompt Creating view V_FACT_100091_GENERAL_LEVEL
prompt =========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_GENERAL_LEVEL AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","ROLELEVEL","NEWCOUNT","CONNCOUNT","PAYCOUNT","PAYAMOUNT","LOADDATE","DATA_SOURCE"
  FROM FACT_100091_GENERAL_LEVEL T;

prompt
prompt Creating view V_FACT_100091_GENERAL_MONTH
prompt =========================================
prompt
create or replace force view v_fact_100091_general_month as
Select Statdate,
       Channelid,
       Serverid,
       Datatype,
       Appid,
       Versionid,
       Newcount,
       Conncount,
       Paycount,
       Payamount
  From Fact_100091_General_month;

prompt
prompt Creating view V_FACT_100091_GENERAL_WEEK
prompt ========================================
prompt
create or replace force view v_fact_100091_general_week as
Select Statdate,
       Channelid,
       Serverid,
       Datatype,
       Appid,
       Versionid,
       Newcount,
       Conncount,
       Paycount,
       Payamount
  From Fact_100091_General_week;

prompt
prompt Creating view V_FACT_100091_HOUR_DVID
prompt =====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_HOUR_DVID AS
SELECT T2.DATE_HOUR STATDATE,
       T2.CHANNELID,
       '100091' APPID,
       NVL(NEWCOUNT, 0) NEWCOUNT,
       NVL(CONNCOUNT, 0) CONNCOUNT
  FROM FACT_100091_GENERAL_HOUR_DVID T1
 RIGHT JOIN (SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD') || ' ' || DD.HOUR_DES DATE_HOUR,
                    DAC.CHANNELID
               FROM DIM_HOUR DD, V_DIM_APPCHANNEL DAC
              WHERE DAC.APPID = '100091'
                AND DD.HOURID < TO_CHAR(SYSDATE, 'HH24')) T2
    ON T1.STATDATE = T2.DATE_HOUR
   AND T1.CHANNELID = T2.CHANNELID;

prompt
prompt Creating view V_FACT_100091_LEVELPAY
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_LEVELPAY AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","ROLELEVEL","PAYCOUNT","FIRST_PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100091_LEVELPAY;

prompt
prompt Creating view V_FACT_100091_LOST_MAC
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_LOST_MAC AS
SELECT T."STATDATE",
       T."LOSTDATE",
       T."CHANNELID",
       T."SERVERID",
       T."APPID",
       T."LOST_DAYS",
       T."LOST_CONN",
       T."LOST_PAY",
       FGL.CONNCOUNT,
       FGL.PAYCOUNT
  FROM (SELECT FLM.STATDATE,
               FLM.LOSTDATE,
               FLM.CHANNELID,
               FLM.SERVERID,
               FLM.APPID,
               FLM.LOST_DAYS,
               SUM(FLM.LOST_CONN) LOST_CONN,
               SUM(FLM.LOST_PAY) LOST_PAY
        --SUM(FGL.CONNCOUNT) CONNCOUNT,
        --SUM(FGL.PAYCOUNT) PAYCOUNT
          FROM FACT_100091_LOST_MAC FLM
         GROUP BY FLM.STATDATE,
                  FLM.LOSTDATE,
                  FLM.CHANNELID,
                  FLM.SERVERID,
                  FLM.APPID,
                  FLM.LOST_DAYS) T
 INNER JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    SUM(T.NEWCOUNT) NEWCOUNT,
                    SUM(T.CONNCOUNT) CONNCOUNT,
                    SUM(T.PAYCOUNT) PAYCOUNT,
                    SUM(T.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100091_GENERAL_DAY T
              WHERE T.DATATYPE = '2'
							GROUP BY T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID) FGL
    ON T.STATDATE = FGL.STATDATE
   AND T.CHANNELID = FGL.CHANNELID
   AND T.SERVERID = FGL.SERVERID
   AND T.APPID = FGL.APPID
;

prompt
prompt Creating view V_FACT_100091_LOST_MAC_LEVEL
prompt ==========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_LOST_MAC_LEVEL AS
SELECT FLM.STATDATE,
       FLM.LOSTDATE,
       FLM.CHANNELID,
       FLM.SERVERID,
       FLM.APPID,
       FLM.ROLELEVEL,
       FLM.LOST_DAYS,
       FLM.LOST_CONN,
       FLM.LOST_PAY,
       FGL.CONNCOUNT,
       FGL.PAYCOUNT
  FROM FACT_100091_LOST_MAC FLM
 INNER JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    T.ROLELEVEL,
                    SUM(T.NEWCOUNT) NEWCOUNT,
                    SUM(T.CONNCOUNT) CONNCOUNT,
                    SUM(T.PAYCOUNT) PAYCOUNT,
                    SUM(T.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100091_GENERAL_LEVEL T
              WHERE T.DATATYPE = '2'
              GROUP BY T.STATDATE,
                       T.CHANNELID,
                       T.SERVERID,
                       T.APPID,
                       T.ROLELEVEL) FGL
    ON FLM.STATDATE = FGL.STATDATE
   AND FLM.CHANNELID = FGL.CHANNELID
   AND FLM.SERVERID = FGL.SERVERID
   AND FLM.APPID = FGL.APPID
   AND FLM.ROLELEVEL = FGL.ROLELEVEL;

prompt
prompt Creating view V_FACT_100091_LOST_USER
prompt =====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_LOST_USER AS
SELECT "STATDATE","LOSTDATE","CHANNELID","SERVERID","APPID","ROLELEVEL","LOST_DAYS","LOST_CONN","LOST_PAY","LOADDATE","DATA_SOURCE" FROM FACT_100091_LOST_USER;

prompt
prompt Creating view V_FACT_100091_LTV_MAC
prompt ===================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_LTV_MAC AS
SELECT FLM.STATDATE,
       FLM.CHANNELID,
       FLM.SERVERID,
       FLM.APPID,
       FLM.LTV_DAYS,
       FGD.NEWCOUNT,
       FLM.PAYAMOUNT
  FROM FACT_100091_LTV_MAC FLM
  LEFT JOIN (SELECT D.STATDATE,
                    D.CHANNELID,
                    D.SERVERID,
                    D.APPID,
                    SUM(D.NEWCOUNT) NEWCOUNT
               FROM FACT_100091_GENERAL_DAY D
              WHERE D.DATATYPE = '2'
              GROUP BY D.STATDATE, D.CHANNELID, D.SERVERID, D.APPID) FGD
    ON FLM.STATDATE = FGD.STATDATE
   AND FLM.CHANNELID = FGD.CHANNELID
   AND FLM.SERVERID = FGD.SERVERID
   AND FLM.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100091_LTV_USER
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_LTV_USER AS
SELECT FLM.STATDATE,
       FLM.CHANNELID,
       FLM.SERVERID,
       FLM.APPID,
       FLM.LTV_DAYS,
       FGD.NEWCOUNT,
       FLM.PAYAMOUNT
  FROM FACT_100091_LTV_USER FLM
  LEFT JOIN (SELECT D.STATDATE,
                    D.CHANNELID,
                    D.SERVERID,
                    D.APPID,
                    SUM(D.NEWCOUNT) NEWCOUNT
               FROM FACT_100091_GENERAL_DAY D
              WHERE D.DATATYPE = '1'
              GROUP BY D.STATDATE, D.CHANNELID, D.SERVERID, D.APPID) FGD
    ON FLM.STATDATE = FGD.STATDATE
   AND FLM.CHANNELID = FGD.CHANNELID
   AND FLM.SERVERID = FGD.SERVERID
   AND FLM.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100091_LTV_USER_BAK
prompt ========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_LTV_USER_BAK AS
SELECT
    DISTINCT
      A.STATDATE,
      B.WORLDID,
      B.T_SERVER_ID,
      B.UR_PLATFORM as CHANNELID,
      A.NEWUSERS,
      B.LTV_DAYS,
      B.C_MONEY_RMB
  FROM
     FL_PPSG_REGPAY_INFO B
  INNER JOIN
     (SELECT
         B.STATDATE ,
         SUM( B.NEWUSERS) NEWUSERS
      FROM
         FL_PPSG_NEWUSERS B
       GROUP BY
           B.STATDATE
       ) A
  ON A.STATDATE = B.NEWDATE;

prompt
prompt Creating view V_FACT_100091_MISS_FIRST
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_MISS_FIRST AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","MISSIONID","ROLELEVEL","ROLEJOB","FIRSTENTER_SUCC","FIRSTENTER_FAIL","LOADDATE","DATA_SOURCE" FROM FACT_100091_MISS_FIRST;

prompt
prompt Creating view V_FACT_100091_MONTH_DVID
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_MONTH_DVID AS
SELECT "STATDATE","CHANNELID","APPID","NEWCOUNT","CONNCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100091_GENERAL_MONTH_DVID;

prompt
prompt Creating view V_FACT_100091_NET
prompt ===============================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_NET AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","DVID_NET","CONNCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100091_NET;

prompt
prompt Creating view V_FACT_100091_OPERATOR
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_OPERATOR AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","DVID_OPERATOR","CONNCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100091_OPERATOR;

prompt
prompt Creating view V_FACT_100091_ORDER
prompt =================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_ORDER AS
SELECT STATDATE,
        CHANNELID,
        SERVERID,
        DATATYPE,
        APPID,
        VERSIONID,
        SUM(PAYSUCCCOUNT) PAYSUCCCOUNT,
        SUM(PAYFAILCOUNT) PAYFAILCOUNT,
        SUM(PAYSUCCAMOUNT) PAYSUCCAMOUNT,
        SUM(PAYFAILAMOUNT) PAYFAILAMOUNT,
        SUM(PAYSUCCNUM) PAYSUCCNUM,
        SUM(PAYFAILNUM) PAYFAILNUM
   FROM FACT_100091_ORDER
  GROUP BY STATDATE, CHANNELID, SERVERID, DATATYPE, APPID, VERSIONID;

prompt
prompt Creating view V_FACT_100091_ORDER_HOUR
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_ORDER_HOUR AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYSUCCCOUNT","PAYFAILCOUNT","PAYSUCCAMOUNT","PAYFAILAMOUNT","PAYSUCCNUM","PAYFAILNUM","LOADDATE","DATA_SOURCE" FROM FACT_100091_ORDER_HOUR;

prompt
prompt Creating view V_FACT_100091_ORDER_MONTH
prompt =======================================
prompt
create or replace force view v_fact_100091_order_month as
Select "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYSUCCCOUNT","PAYFAILCOUNT","PAYSUCCAMOUNT","PAYFAILAMOUNT","PAYSUCCNUM","PAYFAILNUM","LOADDATE","DATA_SOURCE" From Fact_100091_Order_month;

prompt
prompt Creating view V_FACT_100091_ORDER_WEEK
prompt ======================================
prompt
create or replace force view v_fact_100091_order_week as
Select "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYSUCCCOUNT","PAYFAILCOUNT","PAYSUCCAMOUNT","PAYFAILAMOUNT","PAYSUCCNUM","PAYFAILNUM","LOADDATE","DATA_SOURCE" From Fact_100091_Order_week;

prompt
prompt Creating view V_FACT_100091_PAYAMOUNT_DAY
prompt =========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_PAYAMOUNT_DAY AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYAMOUNT","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100091_PAYAMOUNT_DAY;

prompt
prompt Creating view V_FACT_100091_PAYAMOUNT_MONTH
prompt ===========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_PAYAMOUNT_MONTH AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYAMOUNT","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100091_PAYAMOUNT_MONTH;

prompt
prompt Creating view V_FACT_100091_PAYAMOUNT_WEEK
prompt ==========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_PAYAMOUNT_WEEK AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYAMOUNT","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100091_PAYAMOUNT_WEEK;

prompt
prompt Creating view V_FACT_100091_PAYNUM_DAY
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_PAYNUM_DAY AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYNUM","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100091_PAYNUM_DAY;

prompt
prompt Creating view V_FACT_100091_PAYNUM_MONTH
prompt ========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_PAYNUM_MONTH AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYNUM","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100091_PAYNUM_MONTH;

prompt
prompt Creating view V_FACT_100091_PAYNUM_WEEK
prompt =======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_PAYNUM_WEEK AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYNUM","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100091_PAYNUM_WEEK;

prompt
prompt Creating view V_FACT_100091_PAYTYPE
prompt ===================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_PAYTYPE AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYTYPEID","PAYAMOUNT","PAYCOUNT","PAYNUM","LOADDATE","DATA_SOURCE" FROM FACT_100091_PAYTYPE;

prompt
prompt Creating view V_FACT_100091_PAYWAY
prompt ==================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_PAYWAY AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYWAYID","PAYAMOUNT","PAYCOUNT","PAYNUM","LOADDATE","DATA_SOURCE" FROM FACT_100091_PAYWAY;

prompt
prompt Creating view V_FACT_100091_QDTG
prompt ================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_QDTG AS
SELECT T2.STATDATE,
       T2.CHANNELID,
       T2.SERVERID,
       T2.APPID,
       T2.NEWCOUNT,
       T3.NEW_REMAIN,
       T1.FIRST_PAYCOUNT
  FROM (SELECT FF.STATDATE,
               FF.CHANNELID,
               FF.SERVERID,
               FF.APPID,
               SUM(FF.FIRST_PAYCOUNT) FIRST_PAYCOUNT
          FROM FACT_100091_FIRSTPAY FF
         WHERE FF.FIRST_PAYFROMREG < 7
           AND FF.DATATYPE = '1'
         GROUP BY FF.STATDATE, FF.CHANNELID, FF.SERVERID, FF.APPID) T1

 RIGHT JOIN (SELECT F.STATDATE,
                    F.CHANNELID,
                    F.SERVERID,
                    F.APPID,
                    SUM(F.NEWCOUNT) NEWCOUNT
               FROM FACT_100091_GENERAL_DAY F
              WHERE F.DATATYPE = '1'
              GROUP BY F.STATDATE, F.CHANNELID, F.SERVERID, F.APPID) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID
 LEFT JOIN (SELECT * FROM FACT_100091_REMAIN_USER F WHERE F.REMAIN_DAYS = 1) T3

    ON T3.STATDATE = T2.STATDATE
   AND T3.CHANNELID = T2.CHANNELID
   AND T3.SERVERID = T2.SERVERID
   AND T3.APPID = T2.APPID;

prompt
prompt Creating view V_FACT_100091_REGION
prompt ==================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_REGION AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","COUNTRY","PROVINCE","CITY","NEWCOUNT","CONNCOUNT","PAYCOUNT","PAYAMOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100091_REGION;

prompt
prompt Creating view V_FACT_100091_REMAIN_MAC
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_REMAIN_MAC AS
SELECT FRU.STATDATE,
       FRU.CONNDATE,
       FRU.CHANNELID,
       FRU.SERVERID,
       FRU.APPID,
       FRU.REMAIN_DAYS,
       FGD.NEWCOUNT,
       FGD.CONNCOUNT,
       FGD.PAYCOUNT,
       FRU.NEW_REMAIN,
       FRU.CONN_REMAIN,
       FRU.PAY_REMAIN
  FROM FACT_100091_REMAIN_MAC FRU
  LEFT JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    SUM(T.NEWCOUNT) NEWCOUNT,
                    SUM(T.CONNCOUNT) CONNCOUNT,
                    SUM(T.PAYCOUNT) PAYCOUNT,
                    SUM(T.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100091_GENERAL_DAY T
              WHERE T.DATATYPE = '2'
              GROUP BY T.STATDATE, T.CHANNELID, T.SERVERID, T.APPID) FGD
    ON FRU.STATDATE = FGD.STATDATE
   AND FRU.CHANNELID = FGD.CHANNELID
   AND FRU.SERVERID = FGD.SERVERID
   AND FRU.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100091_REMAIN_USER
prompt =======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_REMAIN_USER AS
SELECT FRU.STATDATE,
       FRU.CONNDATE,
       FRU.CHANNELID,
       FRU.SERVERID,
       FRU.APPID,
       FRU.REMAIN_DAYS,
       FGD.NEWCOUNT,
       FGD.CONNCOUNT,
       FGD.PAYCOUNT,
       FRU.NEW_REMAIN,
       FRU.CONN_REMAIN,
       FRU.PAY_REMAIN
  FROM FACT_100091_REMAIN_USER FRU
  LEFT JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    SUM(T.NEWCOUNT) NEWCOUNT,
                    SUM(T.CONNCOUNT) CONNCOUNT,
                    SUM(T.PAYCOUNT) PAYCOUNT,
                    SUM(T.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100091_GENERAL_DAY T
              WHERE T.DATATYPE = '1'
              GROUP BY T.STATDATE, T.CHANNELID, T.SERVERID, T.APPID) FGD
    ON FRU.STATDATE = FGD.STATDATE
   AND FRU.CHANNELID = FGD.CHANNELID
   AND FRU.SERVERID = FGD.SERVERID
   AND FRU.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100091_VC
prompt ==============================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_VC AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","VCTYPE","VCUSETYPE","VCUSEWAY","VCAMOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100091_VC T;

prompt
prompt Creating view V_FACT_100091_WEEK_DVID
prompt =====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100091_WEEK_DVID AS
SELECT T2.STATDATE,
       T2.CHANNELID,
       '100091' APPID,
       NVL(NEWCOUNT, 0) NEWCOUNT,
       NVL(CONNCOUNT, 0) CONNCOUNT
  FROM FACT_100091_GENERAL_WEEK_DVID T1
 RIGHT JOIN (SELECT DD.DAY_DES STATDATE, DAC.CHANNELID
               FROM DIM_DAY DD, V_DIM_APPCHANNEL DAC
              WHERE DAC.APPID = '100091'
                AND DD.WEEK_DAY_CAL = 1
                AND DD.DAY_DES <= TO_CHAR(SYSDATE, 'YYYY-MM-DD')) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
--WHERE T2.STATDATE BETWEEN '2014-09-20' AND '2014-09-30'
;

prompt
prompt Creating view V_FACT_100105_BACK_MAC
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_BACK_MAC AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","LOST_DAYS","BACK_CONN","BACK_PAY","LOADDATE","DATA_SOURCE" FROM FACT_100105_BACK_MAC;

prompt
prompt Creating view V_FACT_100105_BACK_MAC_MONTH
prompt ==========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_BACK_MAC_MONTH AS
SELECT T1.STATDATE,
       T1.CHANNELID,
       T1.SERVERID,
       T1.APPID,
       T2.CONNCOUNT,
       T2.PAYCOUNT,
       T1.BACK_CONN,
       T1.BACK_PAY
  FROM FACT_100105_BACK_MAC_MONTH T1
 INNER JOIN (SELECT FGW.STATDATE,
                    FGW.CHANNELID,
                    FGW.SERVERID,
                    FGW.APPID,
                    SUM(FGW.NEWCOUNT) NEWCOUNT,
                    SUM(FGW.CONNCOUNT) CONNCOUNT,
                    SUM(FGW.PAYCOUNT) PAYCOUNT,
                    SUM(FGW.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100105_GENERAL_MONTH FGW
              WHERE FGW.DATATYPE = '2'
              GROUP BY FGW.STATDATE, FGW.CHANNELID, FGW.SERVERID, FGW.APPID) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID;

prompt
prompt Creating view V_FACT_100105_BACK_MAC_WEEK
prompt =========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_BACK_MAC_WEEK AS
SELECT T1.STATDATE,
       T1.CHANNELID,
       T1.SERVERID,
       T1.APPID,
       T2.CONNCOUNT,
       T2.PAYCOUNT,
       T1.BACK_CONN,
       T1.BACK_PAY
  FROM FACT_100105_BACK_MAC_WEEK T1
 INNER JOIN (SELECT FGW.STATDATE,
                    FGW.CHANNELID,
                    FGW.SERVERID,
                    FGW.APPID,
                    SUM(FGW.NEWCOUNT) NEWCOUNT,
                    SUM(FGW.CONNCOUNT) CONNCOUNT,
                    SUM(FGW.PAYCOUNT) PAYCOUNT,
                    SUM(FGW.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100105_GENERAL_WEEK FGW
              WHERE FGW.DATATYPE = '2'
              GROUP BY FGW.STATDATE, FGW.CHANNELID, FGW.SERVERID, FGW.APPID) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID;

prompt
prompt Creating view V_FACT_100105_BACK_USER
prompt =====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_BACK_USER AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","LOST_DAYS","BACK_CONN","BACK_PAY","LOADDATE","DATA_SOURCE" FROM FACT_100105_BACK_USER;

prompt
prompt Creating view V_FACT_100105_CEVENT
prompt ==================================
prompt
create or replace force view v_fact_100105_cevent as
Select t.Statdate,
       t.Channelid,
       t.Serverid,
       t.Appid,
       t.Versionid,
       t.Eventkey,
       t.Eventcount,
       t.Eventnum
  From Fact_100105_Cevent t;

prompt
prompt Creating view V_FACT_100105_CEVENT_PAR
prompt ======================================
prompt
create or replace force view v_fact_100105_cevent_par as
Select Statdate,
       Channelid,
       Serverid,
       Appid,
       Versionid,
       Ilevel,
       Eventkey,
       Eventpar_Key,
       Eventpar_Value,
       Eventcount,
       Eventnum
  From Fact_100105_Cevent_Par;

prompt
prompt Creating view V_FACT_100105_COMP_CEVENT
prompt =======================================
prompt
create or replace force view v_fact_100105_comp_cevent as
Select Statdate,
       Appid,
       Channelid,
       Gameversion,
       Serverid,
       Ilevel,
       Eventkey,
       Compid,
       Caltype,
       Dimpars,
       Comp_Data
  From Fact_100105_Comp_Cevent;

prompt
prompt Creating view V_FACT_100105_CONNDAYS
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_CONNDAYS AS
SELECT TT.GAMEID APPID,
       TT.CHANNELID,
       TT.SERVERID,
       TT.CONNDAYS,
       TT.CONNCOUNT,
       DD.ALL_CONNCOUNT
  FROM (SELECT D.GAMEID,
               D.CONNDAYS,
               D.CHANNELID,
               D.SERVERID,
               COUNT(1) CONNCOUNT
          FROM (SELECT TC.GAMEID,
                       TC.CHANNELID,
                       TC.SERVERID,
                       TC.ACCOUNTID,
                       COUNT(TC.CONNDATE) CONNDAYS
                  FROM T_100105_CONN TC
                 GROUP BY TC.GAMEID, TC.CHANNELID, TC.SERVERID, TC.ACCOUNTID) D
         GROUP BY D.GAMEID, D.CONNDAYS, D.CHANNELID, D.SERVERID) TT
 INNER JOIN (SELECT T.GAMEID,
                    T.CHANNELID,
                    T.SERVERID,
                    COUNT(DISTINCT T.ACCOUNTID) ALL_CONNCOUNT
               FROM T_100105_CONN T
              GROUP BY T.GAMEID, T.CHANNELID, T.SERVERID) DD
    ON TT.GAMEID = DD.GAMEID
   AND TT.CHANNELID = DD.CHANNELID
   AND TT.SERVERID = DD.SERVERID;

prompt
prompt Creating view V_FACT_100105_CONN_CON
prompt ====================================
prompt
create or replace force view v_fact_100105_conn_con as
Select T1.Statdate,
       T1.Channelid,
       T1.Serverid,
       T1.Appid,
       T1.Newcount,
       T1.Conncount,
       nvl(T2.Back_Conn,0) Back_Conn7,
			 T1.Conncount-T1.Newcount-nvl(T2.Back_Conn,0) conn7
  From (Select t.Statdate,
               t.Channelid,
               t.Serverid,
               t.Appid,
               Sum(t.Newcount) Newcount,
               Sum(t.Conncount) Conncount
          From Fact_100105_General_Day t
         Where t.Datatype = '1'
         Group By t.Statdate, t.Channelid, t.Serverid, t.Appid) T1
 Left Join (Select t.Statdate,
                    t.Channelid,
                    t.Serverid,
                    t.Appid,
                    Sum(t.Back_Conn) Back_Conn
               From Fact_100105_Back_User t
              Where t.Lost_Days > 7
              Group By t.Statdate, t.Channelid, t.Serverid, t.Appid) T2
    On T1.Statdate = T2.Statdate
   And T1.Channelid = T2.Channelid
   And T1.Serverid = T2.Serverid
   And T1.Appid = T2.Appid;

prompt
prompt Creating view V_FACT_100105_DAILY_REPORT
prompt ========================================
prompt
create or replace force view v_fact_100105_daily_report as
Select "STATDATE","APPID","CHANNELID","SERVERID","INDEXID","INDTYPE","RPT_DATA","LOADDATE","DATA_SOURCE" From Fact_100105_Daily_Report;

prompt
prompt Creating view V_FACT_100105_DVID
prompt ================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_DVID AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","DVID_MODEL","DVID_RES","DVID_OS","NEWCOUNT","CONNCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100105_DVID;

prompt
prompt Creating view V_FACT_100105_FIRSTPAY
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_FIRSTPAY AS
SELECT FF.STATDATE,
       FF.FIRSTPAYDATE,
       FF.CHANNELID,
       FF.SERVERID,
       FF.DATATYPE,
       FF.APPID,
       FF.FIRST_PAYFROMREG,
       FF.FIRST_PAYCOUNT,
       FF.PAYAMOUNT,
       FGD.NEWCOUNT
  FROM FACT_100105_FIRSTPAY FF
 INNER JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.DATATYPE,
                    T.APPID,
                    SUM(T.NEWCOUNT) NEWCOUNT
               FROM FACT_100105_GENERAL_DAY T
              GROUP BY T.STATDATE,
                       T.CHANNELID,
                       T.SERVERID,
                       T.DATATYPE,
                       T.APPID) FGD
    ON FF.STATDATE = FGD.STATDATE
   AND FF.CHANNELID = FGD.CHANNELID
   AND FF.SERVERID = FGD.SERVERID
   AND FF.DATATYPE = FGD.DATATYPE
   AND FF.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100105_FIRSTPAY_AMOUNT
prompt ===========================================
prompt
create or replace force view v_fact_100105_firstpay_amount as
Select "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYAMOUNT","PAYCOUNT","LOADDATE","DATA_SOURCE" From Fact_100105_Firstpay_Amount;

prompt
prompt Creating view V_FACT_100105_FIRSTPAY_ARPPU
prompt ==========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_FIRSTPAY_ARPPU AS
SELECT T1.STATDATE,
       T1.CHANNELID,
       T1.SERVERID,
       T1.APPID,
       T1.FIRST_PAYFROMREG,
       T1.FIRST_PAYCOUNT,
       T2.PAYAMOUNT
  FROM (SELECT * FROM FACT_100105_FIRSTPAY F WHERE F.DATATYPE = '1') T1
 INNER JOIN FACT_100105_LTV_USER T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID
   AND T1.FIRST_PAYFROMREG = T2.LTV_DAYS - 1;

prompt
prompt Creating view V_FACT_100105_GENERAL_DAY
prompt =======================================
prompt
create or replace force view v_fact_100105_general_day as
Select Statdate,
       Channelid,
       Serverid,
       Datatype,
       Appid,
       Versionid,
       Newcount,
       Conncount,
       Paycount,
       Payamount
  From Fact_100105_General_Day;

prompt
prompt Creating view V_FACT_100105_GENERAL_DAY_DVID
prompt ============================================
prompt
create or replace force view v_fact_100105_general_day_dvid as
Select T2.Statdate,
       T2.Channelid,
       '100105' Appid,
       Nvl(Newcount, 0) Newcount,
       Nvl(Conncount, 0) Conncount
  From Fact_100105_General_Day_Dvid T1
 Right Join (Select Dd.Day_Des Statdate, Dac.Channelid
               From Dim_Day Dd, v_Dim_Appchannel Dac
              Where Dac.Appid = '100105'
                And Dd.Day_Des <= To_Char(Sysdate, 'yyyy-mm-dd')) T2
    On T1.Statdate = T2.Statdate
   And T1.Channelid = T2.Channelid
--Where t2.Statdate Between '2014-09-25' And '2014-09-29'
;

prompt
prompt Creating view V_FACT_100105_GENERAL_HOUR
prompt ========================================
prompt
create or replace force view v_fact_100105_general_hour as
Select T.STATDATE,
               T.CHANNELID,
               T.SERVERID,
               T.DATATYPE,
               T.APPID,
               T.VERSIONID,
               T.NEWCOUNT,
               T.CONNCOUNT,
               T.PAYCOUNT,
               T.PAYAMOUNT
          FROM FACT_100105_GENERAL_HOUR T;

prompt
prompt Creating view V_FACT_100105_GENERAL_LEVEL
prompt =========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_GENERAL_LEVEL AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","ROLELEVEL","NEWCOUNT","CONNCOUNT","PAYCOUNT","PAYAMOUNT","LOADDATE","DATA_SOURCE"
  FROM FACT_100105_GENERAL_LEVEL T;

prompt
prompt Creating view V_FACT_100105_GENERAL_MONTH
prompt =========================================
prompt
create or replace force view v_fact_100105_general_month as
Select Statdate,
       Channelid,
       Serverid,
       Datatype,
       Appid,
       Versionid,
       Newcount,
       Conncount,
       Paycount,
       Payamount
  From Fact_100105_General_month;

prompt
prompt Creating view V_FACT_100105_GENERAL_WEEK
prompt ========================================
prompt
create or replace force view v_fact_100105_general_week as
Select Statdate,
       Channelid,
       Serverid,
       Datatype,
       Appid,
       Versionid,
       Newcount,
       Conncount,
       Paycount,
       Payamount
  From Fact_100105_General_week;

prompt
prompt Creating view V_FACT_100105_HOUR_DVID
prompt =====================================
prompt
create or replace force view v_fact_100105_hour_dvid as
Select T2.Date_Hour Statdate,
       T2.Channelid,
       '100105' Appid,
       Nvl(Newcount, 0) Newcount,
       Nvl(Conncount, 0) Conncount
  From Fact_100105_General_Hour_Dvid T1
 Right Join (Select To_Char(Sysdate, 'yyyy-mm-dd') || ' ' || Dd.Hour_Des Date_Hour,
                    Dac.Channelid
               From Dim_Hour Dd, v_Dim_Appchannel Dac
              Where Dac.Appid = '100105'
                And Dd.Hourid < To_Char(Sysdate, 'hh24')) T2
    On T1.Statdate = T2.Date_Hour
   And T1.Channelid = T2.Channelid;

prompt
prompt Creating view V_FACT_100105_HOUR_REPORT
prompt =======================================
prompt
create or replace force view v_fact_100105_hour_report as
Select "STATDATE","APPID","CHANNELID","SERVERID","INDEXID","INDTYPE","RPT_DATA","LOADDATE","DATA_SOURCE" From fact_100105_hour_report;

prompt
prompt Creating view V_FACT_100105_LEVELPAY
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_LEVELPAY AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","ROLELEVEL","PAYCOUNT","FIRST_PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100105_LEVELPAY;

prompt
prompt Creating view V_FACT_100105_LOST_MAC
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_LOST_MAC AS
SELECT T."STATDATE",
       T."LOSTDATE",
       T."CHANNELID",
       T."SERVERID",
       T."APPID",
       T."LOST_DAYS",
       T."LOST_CONN",
       T."LOST_PAY",
       FGL.CONNCOUNT,
       FGL.PAYCOUNT
  FROM (SELECT FLM.STATDATE,
               FLM.LOSTDATE,
               FLM.CHANNELID,
               FLM.SERVERID,
               FLM.APPID,
               FLM.LOST_DAYS,
               SUM(FLM.LOST_CONN) LOST_CONN,
               SUM(FLM.LOST_PAY) LOST_PAY
        --SUM(FGL.CONNCOUNT) CONNCOUNT,
        --SUM(FGL.PAYCOUNT) PAYCOUNT
          FROM FACT_100105_LOST_MAC FLM
         GROUP BY FLM.STATDATE,
                  FLM.LOSTDATE,
                  FLM.CHANNELID,
                  FLM.SERVERID,
                  FLM.APPID,
                  FLM.LOST_DAYS) T
 INNER JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    SUM(T.NEWCOUNT) NEWCOUNT,
                    SUM(T.CONNCOUNT) CONNCOUNT,
                    SUM(T.PAYCOUNT) PAYCOUNT,
                    SUM(T.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100105_GENERAL_DAY T
              WHERE T.DATATYPE = '2'
							GROUP BY T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID) FGL
    ON T.STATDATE = FGL.STATDATE
   AND T.CHANNELID = FGL.CHANNELID
   AND T.SERVERID = FGL.SERVERID
   AND T.APPID = FGL.APPID
;

prompt
prompt Creating view V_FACT_100105_LOST_MAC_LEVEL
prompt ==========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_LOST_MAC_LEVEL AS
SELECT FLM.STATDATE,
       FLM.LOSTDATE,
       FLM.CHANNELID,
       FLM.SERVERID,
       FLM.APPID,
       FLM.ROLELEVEL,
       FLM.LOST_DAYS,
       FLM.LOST_CONN,
       FLM.LOST_PAY,
       FGL.CONNCOUNT,
       FGL.PAYCOUNT
  FROM FACT_100105_LOST_MAC FLM
 INNER JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    T.ROLELEVEL,
                    SUM(T.NEWCOUNT) NEWCOUNT,
                    SUM(T.CONNCOUNT) CONNCOUNT,
                    SUM(T.PAYCOUNT) PAYCOUNT,
                    SUM(T.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100105_GENERAL_LEVEL T
              WHERE T.DATATYPE = '2'
              GROUP BY T.STATDATE,
                       T.CHANNELID,
                       T.SERVERID,
                       T.APPID,
                       T.ROLELEVEL) FGL
    ON FLM.STATDATE = FGL.STATDATE
   AND FLM.CHANNELID = FGL.CHANNELID
   AND FLM.SERVERID = FGL.SERVERID
   AND FLM.APPID = FGL.APPID
   AND FLM.ROLELEVEL = FGL.ROLELEVEL;

prompt
prompt Creating view V_FACT_100105_LOST_USER
prompt =====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_LOST_USER AS
SELECT "STATDATE","LOSTDATE","CHANNELID","SERVERID","APPID","ROLELEVEL","LOST_DAYS","LOST_CONN","LOST_PAY","LOADDATE","DATA_SOURCE" FROM FACT_100105_LOST_USER;

prompt
prompt Creating view V_FACT_100105_LTV_MAC
prompt ===================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_LTV_MAC AS
SELECT FLM.STATDATE,
       FLM.CHANNELID,
       FLM.SERVERID,
       FLM.APPID,
       FLM.LTV_DAYS,
       FGD.NEWCOUNT,
       FLM.PAYAMOUNT
  FROM FACT_100105_LTV_MAC FLM
  LEFT JOIN (SELECT D.STATDATE,
                    D.CHANNELID,
                    D.SERVERID,
                    D.APPID,
                    SUM(D.NEWCOUNT) NEWCOUNT
               FROM FACT_100105_GENERAL_DAY D
              WHERE D.DATATYPE = '2'
              GROUP BY D.STATDATE, D.CHANNELID, D.SERVERID, D.APPID) FGD
    ON FLM.STATDATE = FGD.STATDATE
   AND FLM.CHANNELID = FGD.CHANNELID
   AND FLM.SERVERID = FGD.SERVERID
   AND FLM.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100105_LTV_USER
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_LTV_USER AS
SELECT FLM.STATDATE,
       FLM.CHANNELID,
       FLM.SERVERID,
       FLM.APPID,
       FLM.LTV_DAYS,
       FGD.NEWCOUNT,
       FLM.PAYAMOUNT
  FROM FACT_100105_LTV_USER FLM
  LEFT JOIN (SELECT D.STATDATE,
                    D.CHANNELID,
                    D.SERVERID,
                    D.APPID,
                    SUM(D.NEWCOUNT) NEWCOUNT
               FROM FACT_100105_GENERAL_DAY D
              WHERE D.DATATYPE = '1'
              GROUP BY D.STATDATE, D.CHANNELID, D.SERVERID, D.APPID) FGD
    ON FLM.STATDATE = FGD.STATDATE
   AND FLM.CHANNELID = FGD.CHANNELID
   AND FLM.SERVERID = FGD.SERVERID
   AND FLM.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100105_MISS_FIRST
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_MISS_FIRST AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","MISSIONID","ROLELEVEL","ROLEJOB","FIRSTENTER_SUCC","FIRSTENTER_FAIL","LOADDATE","DATA_SOURCE" FROM FACT_100105_MISS_FIRST;

prompt
prompt Creating view V_FACT_100105_MONTH_DVID
prompt ======================================
prompt
create or replace force view v_fact_100105_month_dvid as
Select "STATDATE","CHANNELID","APPID","NEWCOUNT","CONNCOUNT","LOADDATE","DATA_SOURCE" From Fact_100105_General_Month_Dvid;

prompt
prompt Creating view V_FACT_100105_NET
prompt ===============================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_NET AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","DVID_NET","CONNCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100105_NET;

prompt
prompt Creating view V_FACT_100105_OPERATOR
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_OPERATOR AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","DVID_OPERATOR","CONNCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100105_OPERATOR;

prompt
prompt Creating view V_FACT_100105_ORDER
prompt =================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_ORDER AS
SELECT STATDATE,
       CHANNELID,
       SERVERID,
       DATATYPE,
       APPID,
       VERSIONID,
       SUM(PAYSUCCCOUNT) PAYSUCCCOUNT,
       SUM(PAYFAILCOUNT) PAYFAILCOUNT,
       SUM(PAYSUCCAMOUNT) PAYSUCCAMOUNT,
       SUM(PAYFAILAMOUNT) PAYFAILAMOUNT,
       SUM(PAYSUCCNUM) PAYSUCCNUM,
       SUM(PAYFAILNUM) PAYFAILNUM
  FROM FACT_100105_ORDER
 GROUP BY STATDATE, CHANNELID, SERVERID, DATATYPE, APPID, VERSIONID;

prompt
prompt Creating view V_FACT_100105_ORDER_HOUR
prompt ======================================
prompt
create or replace force view v_fact_100105_order_hour as
Select "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYSUCCCOUNT","PAYFAILCOUNT","PAYSUCCAMOUNT","PAYFAILAMOUNT","PAYSUCCNUM","PAYFAILNUM","LOADDATE","DATA_SOURCE" From FACT_100105_ORDER_HOUR;

prompt
prompt Creating view V_FACT_100105_ORDER_MONTH
prompt =======================================
prompt
create or replace force view v_fact_100105_order_month as
Select "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYSUCCCOUNT","PAYFAILCOUNT","PAYSUCCAMOUNT","PAYFAILAMOUNT","PAYSUCCNUM","PAYFAILNUM","LOADDATE","DATA_SOURCE" From Fact_100105_Order_month;

prompt
prompt Creating view V_FACT_100105_ORDER_WEEK
prompt ======================================
prompt
create or replace force view v_fact_100105_order_week as
Select "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYSUCCCOUNT","PAYFAILCOUNT","PAYSUCCAMOUNT","PAYFAILAMOUNT","PAYSUCCNUM","PAYFAILNUM","LOADDATE","DATA_SOURCE" From Fact_100105_Order_week;

prompt
prompt Creating view V_FACT_100105_PAYAMOUNT_DAY
prompt =========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_PAYAMOUNT_DAY AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYAMOUNT","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100105_PAYAMOUNT_DAY;

prompt
prompt Creating view V_FACT_100105_PAYAMOUNT_MONTH
prompt ===========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_PAYAMOUNT_MONTH AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYAMOUNT","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100105_PAYAMOUNT_MONTH;

prompt
prompt Creating view V_FACT_100105_PAYAMOUNT_WEEK
prompt ==========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_PAYAMOUNT_WEEK AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYAMOUNT","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100105_PAYAMOUNT_WEEK;

prompt
prompt Creating view V_FACT_100105_PAYNUM_DAY
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_PAYNUM_DAY AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYNUM","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100105_PAYNUM_DAY;

prompt
prompt Creating view V_FACT_100105_PAYNUM_MONTH
prompt ========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_PAYNUM_MONTH AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYNUM","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100105_PAYNUM_MONTH;

prompt
prompt Creating view V_FACT_100105_PAYNUM_WEEK
prompt =======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_PAYNUM_WEEK AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYNUM","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100105_PAYNUM_WEEK;

prompt
prompt Creating view V_FACT_100105_PAYTYPE
prompt ===================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_PAYTYPE AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYTYPEID","PAYAMOUNT","PAYCOUNT","PAYNUM","LOADDATE","DATA_SOURCE" FROM FACT_100105_PAYTYPE;

prompt
prompt Creating view V_FACT_100105_PAYWAY
prompt ==================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_PAYWAY AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYWAYID","PAYAMOUNT","PAYCOUNT","PAYNUM","LOADDATE","DATA_SOURCE" FROM FACT_100105_PAYWAY;

prompt
prompt Creating view V_FACT_100105_QDTG
prompt ================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_QDTG AS
SELECT T1.STATDATE,
       T1.CHANNELID,
       T1.SERVERID,
       T1.APPID,
       T2.NEWCOUNT,
       T3.NEW_REMAIN,
       T1.FIRST_PAYCOUNT
  FROM (SELECT FF.STATDATE,
               FF.CHANNELID,
               FF.SERVERID,
               FF.APPID,
               SUM(FF.FIRST_PAYCOUNT) FIRST_PAYCOUNT
          FROM FACT_100105_FIRSTPAY FF
         WHERE FF.FIRST_PAYFROMREG < 7
           AND FF.DATATYPE = '1'
         GROUP BY FF.STATDATE, FF.CHANNELID, FF.SERVERID, FF.APPID) T1

 INNER JOIN (SELECT F.STATDATE,
                    F.CHANNELID,
                    F.SERVERID,
                    F.APPID,
                    SUM(F.NEWCOUNT) NEWCOUNT
               FROM FACT_100105_GENERAL_DAY F
              WHERE F.DATATYPE = '1'
              GROUP BY F.STATDATE, F.CHANNELID, F.SERVERID, F.APPID) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID
 INNER JOIN (SELECT * FROM FACT_100105_REMAIN_USER F WHERE F.REMAIN_DAYS = 1) T3

    ON T3.STATDATE = T2.STATDATE
   AND T3.CHANNELID = T2.CHANNELID
   AND T3.SERVERID = T2.SERVERID
   AND T3.APPID = T2.APPID;

prompt
prompt Creating view V_FACT_100105_REGION
prompt ==================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_REGION AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","COUNTRY","PROVINCE","CITY","NEWCOUNT","CONNCOUNT","PAYCOUNT","PAYAMOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100105_REGION;

prompt
prompt Creating view V_FACT_100105_REMAIN_MAC
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_REMAIN_MAC AS
SELECT FRU.STATDATE,
       FRU.CONNDATE,
       FRU.CHANNELID,
       FRU.SERVERID,
       FRU.APPID,
       FRU.REMAIN_DAYS,
       FGD.NEWCOUNT,
       FGD.CONNCOUNT,
       FGD.PAYCOUNT,
       FRU.NEW_REMAIN,
       FRU.CONN_REMAIN,
       FRU.PAY_REMAIN
  FROM FACT_100105_REMAIN_MAC FRU
  LEFT JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    SUM(T.NEWCOUNT) NEWCOUNT,
                    SUM(T.CONNCOUNT) CONNCOUNT,
                    SUM(T.PAYCOUNT) PAYCOUNT,
                    SUM(T.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100105_GENERAL_DAY T
              WHERE T.DATATYPE = '2'
              GROUP BY T.STATDATE, T.CHANNELID, T.SERVERID, T.APPID) FGD
    ON FRU.STATDATE = FGD.STATDATE
   AND FRU.CHANNELID = FGD.CHANNELID
   AND FRU.SERVERID = FGD.SERVERID
   AND FRU.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100105_REMAIN_USER
prompt =======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_REMAIN_USER AS
SELECT FRU.STATDATE,
       FRU.CONNDATE,
       FRU.CHANNELID,
       FRU.SERVERID,
       FRU.APPID,
       FRU.REMAIN_DAYS,
       FGD.NEWCOUNT,
       FGD.CONNCOUNT,
       FGD.PAYCOUNT,
       FRU.NEW_REMAIN,
       FRU.CONN_REMAIN,
       FRU.PAY_REMAIN
  FROM FACT_100105_REMAIN_USER FRU
  LEFT JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    SUM(T.NEWCOUNT) NEWCOUNT,
                    SUM(T.CONNCOUNT) CONNCOUNT,
                    SUM(T.PAYCOUNT) PAYCOUNT,
                    SUM(T.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100105_GENERAL_DAY T
              WHERE T.DATATYPE = '1'
              GROUP BY T.STATDATE, T.CHANNELID, T.SERVERID, T.APPID) FGD
    ON FRU.STATDATE = FGD.STATDATE
   AND FRU.CHANNELID = FGD.CHANNELID
   AND FRU.SERVERID = FGD.SERVERID
   AND FRU.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100105_VC
prompt ==============================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100105_VC AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","VCTYPE","VCUSETYPE","VCUSEWAY","VCAMOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100105_VC T;

prompt
prompt Creating view V_FACT_100105_WEEK_DVID
prompt =====================================
prompt
create or replace force view v_fact_100105_week_dvid as
Select T2.Statdate,
       T2.Channelid,
       '100105' Appid,
       Nvl(Newcount, 0) Newcount,
       Nvl(Conncount, 0) Conncount
  From Fact_100105_General_Week_Dvid T1
 Right Join (Select Dd.Day_Des Statdate, Dac.Channelid
               From Dim_Day Dd, v_Dim_Appchannel Dac
              Where Dac.Appid = '100105'
                And Dd.Week_Day_Cal = 1
                And Dd.Day_Des <= To_Char(Sysdate, 'yyyy-mm-dd')) T2
    On T1.Statdate = T2.Statdate
   And T1.Channelid = T2.Channelid
--Where t2.statdate Between '2014-09-20' And '2014-09-30'
;

prompt
prompt Creating view V_FACT_100131_BACK_MAC
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_BACK_MAC AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","LOST_DAYS","BACK_CONN","BACK_PAY","LOADDATE","DATA_SOURCE" FROM FACT_100131_BACK_MAC;

prompt
prompt Creating view V_FACT_100131_BACK_MAC_MONTH
prompt ==========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_BACK_MAC_MONTH AS
SELECT T1.STATDATE,
       T1.CHANNELID,
       T1.SERVERID,
       T1.APPID,
       T2.CONNCOUNT,
       T2.PAYCOUNT,
       T1.BACK_CONN,
       T1.BACK_PAY
  FROM FACT_100131_BACK_MAC_MONTH T1
 INNER JOIN (SELECT FGW.STATDATE,
                    FGW.CHANNELID,
                    FGW.SERVERID,
                    FGW.APPID,
                    SUM(FGW.NEWCOUNT) NEWCOUNT,
                    SUM(FGW.CONNCOUNT) CONNCOUNT,
                    SUM(FGW.PAYCOUNT) PAYCOUNT,
                    SUM(FGW.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100131_GENERAL_MONTH FGW
              WHERE FGW.DATATYPE = '2'
              GROUP BY FGW.STATDATE, FGW.CHANNELID, FGW.SERVERID, FGW.APPID) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID;

prompt
prompt Creating view V_FACT_100131_BACK_MAC_WEEK
prompt =========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_BACK_MAC_WEEK AS
SELECT T1.STATDATE,
       T1.CHANNELID,
       T1.SERVERID,
       T1.APPID,
       T2.CONNCOUNT,
       T2.PAYCOUNT,
       T1.BACK_CONN,
       T1.BACK_PAY
  FROM FACT_100131_BACK_MAC_WEEK T1
 INNER JOIN (SELECT FGW.STATDATE,
                    FGW.CHANNELID,
                    FGW.SERVERID,
                    FGW.APPID,
                    SUM(FGW.NEWCOUNT) NEWCOUNT,
                    SUM(FGW.CONNCOUNT) CONNCOUNT,
                    SUM(FGW.PAYCOUNT) PAYCOUNT,
                    SUM(FGW.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100131_GENERAL_WEEK FGW
              WHERE FGW.DATATYPE = '2'
              GROUP BY FGW.STATDATE, FGW.CHANNELID, FGW.SERVERID, FGW.APPID) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID;

prompt
prompt Creating view V_FACT_100131_BACK_USER
prompt =====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_BACK_USER AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","LOST_DAYS","BACK_CONN","BACK_PAY","LOADDATE","DATA_SOURCE" FROM FACT_100131_BACK_USER;

prompt
prompt Creating view V_FACT_100131_CEVENT
prompt ==================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_CEVENT AS
SELECT T.STATDATE,
       T.CHANNELID,
       T.SERVERID,
       T.APPID,
       T.VERSIONID,
       T.EVENTKEY,
       T.EVENTCOUNT,
       T.EVENTNUM
  FROM FACT_100131_CEVENT T;

prompt
prompt Creating view V_FACT_100131_CEVENT_PAR
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_CEVENT_PAR AS
SELECT STATDATE,
       CHANNELID,
       SERVERID,
       APPID,
       VERSIONID,
       ILEVEL,
       EVENTKEY,
       EVENTPAR_KEY,
       EVENTPAR_VALUE,
       EVENTCOUNT,
       EVENTNUM
  FROM FACT_100131_CEVENT_PAR;

prompt
prompt Creating view V_FACT_100131_COMP_CEVENT
prompt =======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_COMP_CEVENT AS
SELECT STATDATE,
       APPID,
       CHANNELID,
       GAMEVERSION,
       SERVERID,
       ILEVEL,
       EVENTKEY,
       COMPID,
       CALTYPE,
       DIMPARS,
       COMP_DATA
  FROM FACT_100131_COMP_CEVENT;

prompt
prompt Creating view V_FACT_100131_CONNDAYS
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_CONNDAYS AS
SELECT TT.GAMEID APPID,
       TT.CHANNELID,
       TT.SERVERID,
       TT.CONNDAYS,
       TT.CONNCOUNT,
       DD.ALL_CONNCOUNT
  FROM (SELECT D.GAMEID,
               D.CONNDAYS,
               D.CHANNELID,
               D.SERVERID,
               COUNT(1) CONNCOUNT
          FROM (SELECT TC.GAMEID,
                       TC.CHANNELID,
                       TC.SERVERID,
                       TC.ACCOUNTID,
                       COUNT(TC.CONNDATE) CONNDAYS
                  FROM T_100131_CONN TC
                 GROUP BY TC.GAMEID, TC.CHANNELID, TC.SERVERID, TC.ACCOUNTID) D
         GROUP BY D.GAMEID, D.CONNDAYS, D.CHANNELID, D.SERVERID) TT
 INNER JOIN (SELECT T.GAMEID,
                    T.CHANNELID,
                    T.SERVERID,
                    COUNT(DISTINCT T.ACCOUNTID) ALL_CONNCOUNT
               FROM T_100131_CONN T
              GROUP BY T.GAMEID, T.CHANNELID, T.SERVERID) DD
    ON TT.GAMEID = DD.GAMEID
   AND TT.CHANNELID = DD.CHANNELID
   AND TT.SERVERID = DD.SERVERID;

prompt
prompt Creating view V_FACT_100131_CONN_CON
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_CONN_CON AS
SELECT T1.STATDATE,
       T1.CHANNELID,
       T1.SERVERID,
       T1.APPID,
       T1.NEWCOUNT,
       T1.CONNCOUNT,
       NVL(T2.BACK_CONN,0) BACK_CONN7,
			 T1.CONNCOUNT-T1.NEWCOUNT-NVL(T2.BACK_CONN,0) CONN7
  FROM (SELECT T.STATDATE,
               T.CHANNELID,
               T.SERVERID,
               T.APPID,
               SUM(T.NEWCOUNT) NEWCOUNT,
               SUM(T.CONNCOUNT) CONNCOUNT
          FROM FACT_100131_GENERAL_DAY T
         WHERE T.DATATYPE = '1'
         GROUP BY T.STATDATE, T.CHANNELID, T.SERVERID, T.APPID) T1
 LEFT JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    SUM(T.BACK_CONN) BACK_CONN
               FROM FACT_100131_BACK_USER T
              WHERE T.LOST_DAYS > 7
              GROUP BY T.STATDATE, T.CHANNELID, T.SERVERID, T.APPID) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID;

prompt
prompt Creating view V_FACT_100131_DAILY_REPORT
prompt ========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_DAILY_REPORT AS
SELECT "STATDATE","APPID","CHANNELID","SERVERID","INDEXID","INDTYPE","RPT_DATA","LOADDATE","DATA_SOURCE" FROM FACT_100131_DAILY_REPORT;

prompt
prompt Creating view V_FACT_100131_DVID
prompt ================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_DVID AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","DVID_MODEL","DVID_RES","DVID_OS","NEWCOUNT","CONNCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100131_DVID;

prompt
prompt Creating view V_FACT_100131_FIRSTPAY
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_FIRSTPAY AS
SELECT FF.STATDATE,
       FF.FIRSTPAYDATE,
       FF.CHANNELID,
       FF.SERVERID,
       FF.DATATYPE,
       FF.APPID,
       FF.FIRST_PAYFROMREG,
       FF.FIRST_PAYCOUNT,
       FF.PAYAMOUNT,
       FGD.NEWCOUNT
  FROM FACT_100131_FIRSTPAY FF
 INNER JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.DATATYPE,
                    T.APPID,
                    SUM(T.NEWCOUNT) NEWCOUNT
               FROM FACT_100131_GENERAL_DAY T
              GROUP BY T.STATDATE,
                       T.CHANNELID,
                       T.SERVERID,
                       T.DATATYPE,
                       T.APPID) FGD
    ON FF.STATDATE = FGD.STATDATE
   AND FF.CHANNELID = FGD.CHANNELID
   AND FF.SERVERID = FGD.SERVERID
   AND FF.DATATYPE = FGD.DATATYPE
   AND FF.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100131_FIRSTPAY_AMOUNT
prompt ===========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_FIRSTPAY_AMOUNT AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYAMOUNT","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100131_FIRSTPAY_AMOUNT T;

prompt
prompt Creating view V_FACT_100131_FIRSTPAY_ARPPU
prompt ==========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_FIRSTPAY_ARPPU AS
SELECT T1.STATDATE,
       T1.CHANNELID,
       T1.SERVERID,
       T1.APPID,
       T1.FIRST_PAYFROMREG,
       T1.FIRST_PAYCOUNT,
       T2.PAYAMOUNT
  FROM (SELECT * FROM FACT_100131_FIRSTPAY F WHERE F.DATATYPE = '1') T1
 INNER JOIN FACT_100131_LTV_USER T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID
   AND T1.FIRST_PAYFROMREG = T2.LTV_DAYS - 1;

prompt
prompt Creating view V_FACT_100131_GENERAL_DAY
prompt =======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_GENERAL_DAY AS
SELECT STATDATE,
       CHANNELID,
       SERVERID,
       DATATYPE,
       APPID,
       VERSIONID,
       NEWCOUNT,
       CONNCOUNT,
       PAYCOUNT,
       PAYAMOUNT
  FROM FACT_100131_GENERAL_DAY;

prompt
prompt Creating view V_FACT_100131_GENERAL_DAY_DVID
prompt ============================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_GENERAL_DAY_DVID AS
SELECT T2.STATDATE,
       T2.CHANNELID,
       '100131' APPID,
       NVL(NEWCOUNT, 0) NEWCOUNT,
       NVL(CONNCOUNT, 0) CONNCOUNT
  FROM FACT_100131_GENERAL_DAY_DVID T1
 RIGHT JOIN (SELECT DD.DAY_DES STATDATE, DAC.CHANNELID
               FROM DIM_DAY DD, V_DIM_APPCHANNEL DAC
              WHERE DAC.APPID = '100131'
                AND DD.DAY_DES <= TO_CHAR(SYSDATE, 'YYYY-MM-DD')) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
--WHERE T2.STATDATE BETWEEN '2014-09-25' AND '2014-09-29'
;

prompt
prompt Creating view V_FACT_100131_GENERAL_HOUR
prompt ========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_GENERAL_HOUR AS
SELECT T.STATDATE,
               T.CHANNELID,
               T.SERVERID,
               T.DATATYPE,
               T.APPID,
               T.VERSIONID,
               T.NEWCOUNT,
               T.CONNCOUNT,
               T.PAYCOUNT,
               T.PAYAMOUNT
          FROM FACT_100131_GENERAL_HOUR T;

prompt
prompt Creating view V_FACT_100131_GENERAL_LEVEL
prompt =========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_GENERAL_LEVEL AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","ROLELEVEL","NEWCOUNT","CONNCOUNT","PAYCOUNT","PAYAMOUNT","LOADDATE","DATA_SOURCE"
  FROM FACT_100131_GENERAL_LEVEL T;

prompt
prompt Creating view V_FACT_100131_GENERAL_MONTH
prompt =========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_GENERAL_MONTH AS
SELECT STATDATE,
       CHANNELID,
       SERVERID,
       DATATYPE,
       APPID,
       VERSIONID,
       NEWCOUNT,
       CONNCOUNT,
       PAYCOUNT,
       PAYAMOUNT
  FROM FACT_100131_GENERAL_MONTH;

prompt
prompt Creating view V_FACT_100131_GENERAL_WEEK
prompt ========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_GENERAL_WEEK AS
SELECT STATDATE,
       CHANNELID,
       SERVERID,
       DATATYPE,
       APPID,
       VERSIONID,
       NEWCOUNT,
       CONNCOUNT,
       PAYCOUNT,
       PAYAMOUNT
  FROM FACT_100131_GENERAL_WEEK;

prompt
prompt Creating view V_FACT_100131_HOUR_DVID
prompt =====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_HOUR_DVID AS
SELECT T2.DATE_HOUR STATDATE,
       T2.CHANNELID,
       '100131' APPID,
       NVL(NEWCOUNT, 0) NEWCOUNT,
       NVL(CONNCOUNT, 0) CONNCOUNT
  FROM FACT_100131_GENERAL_HOUR_DVID T1
 RIGHT JOIN (SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD') || ' ' || DD.HOUR_DES DATE_HOUR,
                    DAC.CHANNELID
               FROM DIM_HOUR DD, V_DIM_APPCHANNEL DAC
              WHERE DAC.APPID = '100131'
                AND DD.HOURID < TO_CHAR(SYSDATE, 'HH24')) T2
    ON T1.STATDATE = T2.DATE_HOUR
   AND T1.CHANNELID = T2.CHANNELID;

prompt
prompt Creating view V_FACT_100131_LEVELPAY
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_LEVELPAY AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","ROLELEVEL","PAYCOUNT","FIRST_PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100131_LEVELPAY;

prompt
prompt Creating view V_FACT_100131_LOST_MAC
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_LOST_MAC AS
SELECT T."STATDATE",
       T."LOSTDATE",
       T."CHANNELID",
       T."SERVERID",
       T."APPID",
       T."LOST_DAYS",
       T."LOST_CONN",
       T."LOST_PAY",
       FGL.CONNCOUNT,
       FGL.PAYCOUNT
  FROM (SELECT FLM.STATDATE,
               FLM.LOSTDATE,
               FLM.CHANNELID,
               FLM.SERVERID,
               FLM.APPID,
               FLM.LOST_DAYS,
               SUM(FLM.LOST_CONN) LOST_CONN,
               SUM(FLM.LOST_PAY) LOST_PAY
        --SUM(FGL.CONNCOUNT) CONNCOUNT,
        --SUM(FGL.PAYCOUNT) PAYCOUNT
          FROM FACT_100131_LOST_MAC FLM
         GROUP BY FLM.STATDATE,
                  FLM.LOSTDATE,
                  FLM.CHANNELID,
                  FLM.SERVERID,
                  FLM.APPID,
                  FLM.LOST_DAYS) T
 INNER JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    SUM(T.NEWCOUNT) NEWCOUNT,
                    SUM(T.CONNCOUNT) CONNCOUNT,
                    SUM(T.PAYCOUNT) PAYCOUNT,
                    SUM(T.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100131_GENERAL_DAY T
              WHERE T.DATATYPE = '2'
							GROUP BY T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID) FGL
    ON T.STATDATE = FGL.STATDATE
   AND T.CHANNELID = FGL.CHANNELID
   AND T.SERVERID = FGL.SERVERID
   AND T.APPID = FGL.APPID
;

prompt
prompt Creating view V_FACT_100131_LOST_MAC_LEVEL
prompt ==========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_LOST_MAC_LEVEL AS
SELECT FLM.STATDATE,
       FLM.LOSTDATE,
       FLM.CHANNELID,
       FLM.SERVERID,
       FLM.APPID,
       FLM.ROLELEVEL,
       FLM.LOST_DAYS,
       FLM.LOST_CONN,
       FLM.LOST_PAY,
       FGL.CONNCOUNT,
       FGL.PAYCOUNT
  FROM FACT_100131_LOST_MAC FLM
 INNER JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    T.ROLELEVEL,
                    SUM(T.NEWCOUNT) NEWCOUNT,
                    SUM(T.CONNCOUNT) CONNCOUNT,
                    SUM(T.PAYCOUNT) PAYCOUNT,
                    SUM(T.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100131_GENERAL_LEVEL T
              WHERE T.DATATYPE = '2'
              GROUP BY T.STATDATE,
                       T.CHANNELID,
                       T.SERVERID,
                       T.APPID,
                       T.ROLELEVEL) FGL
    ON FLM.STATDATE = FGL.STATDATE
   AND FLM.CHANNELID = FGL.CHANNELID
   AND FLM.SERVERID = FGL.SERVERID
   AND FLM.APPID = FGL.APPID
   AND FLM.ROLELEVEL = FGL.ROLELEVEL;

prompt
prompt Creating view V_FACT_100131_LOST_USER
prompt =====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_LOST_USER AS
SELECT "STATDATE","LOSTDATE","CHANNELID","SERVERID","APPID","ROLELEVEL","LOST_DAYS","LOST_CONN","LOST_PAY","LOADDATE","DATA_SOURCE" FROM FACT_100131_LOST_USER;

prompt
prompt Creating view V_FACT_100131_LTV_MAC
prompt ===================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_LTV_MAC AS
SELECT FLM.STATDATE,
       FLM.CHANNELID,
       FLM.SERVERID,
       FLM.APPID,
       FLM.LTV_DAYS,
       FGD.NEWCOUNT,
       FLM.PAYAMOUNT
  FROM FACT_100131_LTV_MAC FLM
  LEFT JOIN (SELECT D.STATDATE,
                    D.CHANNELID,
                    D.SERVERID,
                    D.APPID,
                    SUM(D.NEWCOUNT) NEWCOUNT
               FROM FACT_100131_GENERAL_DAY D
              WHERE D.DATATYPE = '2'
              GROUP BY D.STATDATE, D.CHANNELID, D.SERVERID, D.APPID) FGD
    ON FLM.STATDATE = FGD.STATDATE
   AND FLM.CHANNELID = FGD.CHANNELID
   AND FLM.SERVERID = FGD.SERVERID
   AND FLM.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100131_LTV_USER
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_LTV_USER AS
SELECT FLM.STATDATE,
       FLM.CHANNELID,
       FLM.SERVERID,
       FLM.APPID,
       FLM.LTV_DAYS,
       FGD.NEWCOUNT,
       FLM.PAYAMOUNT
  FROM FACT_100131_LTV_USER FLM
  LEFT JOIN (SELECT D.STATDATE,
                    D.CHANNELID,
                    D.SERVERID,
                    D.APPID,
                    SUM(D.NEWCOUNT) NEWCOUNT
               FROM FACT_100131_GENERAL_DAY D
              WHERE D.DATATYPE = '1'
              GROUP BY D.STATDATE, D.CHANNELID, D.SERVERID, D.APPID) FGD
    ON FLM.STATDATE = FGD.STATDATE
   AND FLM.CHANNELID = FGD.CHANNELID
   AND FLM.SERVERID = FGD.SERVERID
   AND FLM.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100131_MISS_FIRST
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_MISS_FIRST AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","MISSIONID","ROLELEVEL","ROLEJOB","FIRSTENTER_SUCC","FIRSTENTER_FAIL","LOADDATE","DATA_SOURCE" FROM FACT_100131_MISS_FIRST;

prompt
prompt Creating view V_FACT_100131_MONTH_DVID
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_MONTH_DVID AS
SELECT "STATDATE","CHANNELID","APPID","NEWCOUNT","CONNCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100131_GENERAL_MONTH_DVID;

prompt
prompt Creating view V_FACT_100131_NET
prompt ===============================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_NET AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","DVID_NET","CONNCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100131_NET;

prompt
prompt Creating view V_FACT_100131_OPERATOR
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_OPERATOR AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","DVID_OPERATOR","CONNCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100131_OPERATOR;

prompt
prompt Creating view V_FACT_100131_ORDER
prompt =================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_ORDER AS
SELECT STATDATE,
       CHANNELID,
       SERVERID,
       DATATYPE,
       APPID,
       VERSIONID,
       SUM(PAYSUCCCOUNT) PAYSUCCCOUNT,
       SUM(PAYFAILCOUNT) PAYFAILCOUNT,
       SUM(PAYSUCCAMOUNT) PAYSUCCAMOUNT,
       SUM(PAYFAILAMOUNT) PAYFAILAMOUNT,
       SUM(PAYSUCCNUM) PAYSUCCNUM,
       SUM(PAYFAILNUM) PAYFAILNUM
  FROM FACT_100131_ORDER
 GROUP BY STATDATE, CHANNELID, SERVERID, DATATYPE, APPID, VERSIONID;

prompt
prompt Creating view V_FACT_100131_ORDER_HOUR
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_ORDER_HOUR AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYSUCCCOUNT","PAYFAILCOUNT","PAYSUCCAMOUNT","PAYFAILAMOUNT","PAYSUCCNUM","PAYFAILNUM","LOADDATE","DATA_SOURCE" FROM FACT_100131_ORDER_HOUR;

prompt
prompt Creating view V_FACT_100131_ORDER_MONTH
prompt =======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_ORDER_MONTH AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYSUCCCOUNT","PAYFAILCOUNT","PAYSUCCAMOUNT","PAYFAILAMOUNT","PAYSUCCNUM","PAYFAILNUM","LOADDATE","DATA_SOURCE" FROM FACT_100131_ORDER_MONTH;

prompt
prompt Creating view V_FACT_100131_ORDER_WEEK
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_ORDER_WEEK AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYSUCCCOUNT","PAYFAILCOUNT","PAYSUCCAMOUNT","PAYFAILAMOUNT","PAYSUCCNUM","PAYFAILNUM","LOADDATE","DATA_SOURCE" FROM FACT_100131_ORDER_WEEK;

prompt
prompt Creating view V_FACT_100131_PAYAMOUNT_DAY
prompt =========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_PAYAMOUNT_DAY AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYAMOUNT","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100131_PAYAMOUNT_DAY;

prompt
prompt Creating view V_FACT_100131_PAYAMOUNT_MONTH
prompt ===========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_PAYAMOUNT_MONTH AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYAMOUNT","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100131_PAYAMOUNT_MONTH;

prompt
prompt Creating view V_FACT_100131_PAYAMOUNT_WEEK
prompt ==========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_PAYAMOUNT_WEEK AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYAMOUNT","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100131_PAYAMOUNT_WEEK;

prompt
prompt Creating view V_FACT_100131_PAYNUM_DAY
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_PAYNUM_DAY AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYNUM","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100131_PAYNUM_DAY;

prompt
prompt Creating view V_FACT_100131_PAYNUM_MONTH
prompt ========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_PAYNUM_MONTH AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYNUM","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100131_PAYNUM_MONTH;

prompt
prompt Creating view V_FACT_100131_PAYNUM_WEEK
prompt =======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_PAYNUM_WEEK AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYNUM","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100131_PAYNUM_WEEK;

prompt
prompt Creating view V_FACT_100131_PAYTYPE
prompt ===================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_PAYTYPE AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYTYPEID","PAYAMOUNT","PAYCOUNT","PAYNUM","LOADDATE","DATA_SOURCE" FROM FACT_100131_PAYTYPE;

prompt
prompt Creating view V_FACT_100131_PAYWAY
prompt ==================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_PAYWAY AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYWAYID","PAYAMOUNT","PAYCOUNT","PAYNUM","LOADDATE","DATA_SOURCE" FROM FACT_100131_PAYWAY;

prompt
prompt Creating view V_FACT_100131_QDTG
prompt ================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_QDTG AS
SELECT T2.STATDATE,
       T2.CHANNELID,
       T2.SERVERID,
       T2.APPID,
       T2.NEWCOUNT,
       T3.NEW_REMAIN,
       T1.FIRST_PAYCOUNT
  FROM (SELECT FF.STATDATE,
               FF.CHANNELID,
               FF.SERVERID,
               FF.APPID,
               SUM(FF.FIRST_PAYCOUNT) FIRST_PAYCOUNT
          FROM FACT_100131_FIRSTPAY FF
         WHERE FF.FIRST_PAYFROMREG < 7
           AND FF.DATATYPE = '1'
         GROUP BY FF.STATDATE, FF.CHANNELID, FF.SERVERID, FF.APPID) T1

 RIGHT JOIN (SELECT F.STATDATE,
                    F.CHANNELID,
                    F.SERVERID,
                    F.APPID,
                    SUM(F.NEWCOUNT) NEWCOUNT
               FROM FACT_100131_GENERAL_DAY F
              WHERE F.DATATYPE = '1'
              GROUP BY F.STATDATE, F.CHANNELID, F.SERVERID, F.APPID) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID
 LEFT JOIN (SELECT * FROM FACT_100131_REMAIN_USER F WHERE F.REMAIN_DAYS = 1) T3

    ON T3.STATDATE = T2.STATDATE
   AND T3.CHANNELID = T2.CHANNELID
   AND T3.SERVERID = T2.SERVERID
   AND T3.APPID = T2.APPID;

prompt
prompt Creating view V_FACT_100131_REGION
prompt ==================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_REGION AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","COUNTRY","PROVINCE","CITY","NEWCOUNT","CONNCOUNT","PAYCOUNT","PAYAMOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100131_REGION;

prompt
prompt Creating view V_FACT_100131_REMAIN_MAC
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_REMAIN_MAC AS
SELECT FRU.STATDATE,
       FRU.CONNDATE,
       FRU.CHANNELID,
       FRU.SERVERID,
       FRU.APPID,
       FRU.REMAIN_DAYS,
       FGD.NEWCOUNT,
       FGD.CONNCOUNT,
       FGD.PAYCOUNT,
       FRU.NEW_REMAIN,
       FRU.CONN_REMAIN,
       FRU.PAY_REMAIN
  FROM FACT_100131_REMAIN_MAC FRU
  LEFT JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    SUM(T.NEWCOUNT) NEWCOUNT,
                    SUM(T.CONNCOUNT) CONNCOUNT,
                    SUM(T.PAYCOUNT) PAYCOUNT,
                    SUM(T.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100131_GENERAL_DAY T
              WHERE T.DATATYPE = '2'
              GROUP BY T.STATDATE, T.CHANNELID, T.SERVERID, T.APPID) FGD
    ON FRU.STATDATE = FGD.STATDATE
   AND FRU.CHANNELID = FGD.CHANNELID
   AND FRU.SERVERID = FGD.SERVERID
   AND FRU.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100131_REMAIN_USER
prompt =======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_REMAIN_USER AS
SELECT FRU.STATDATE,
       FRU.CONNDATE,
       FRU.CHANNELID,
       FRU.SERVERID,
       FRU.APPID,
       FRU.REMAIN_DAYS,
       FGD.NEWCOUNT,
       FGD.CONNCOUNT,
       FGD.PAYCOUNT,
       FRU.NEW_REMAIN,
       FRU.CONN_REMAIN,
       FRU.PAY_REMAIN
  FROM FACT_100131_REMAIN_USER FRU
  LEFT JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    SUM(T.NEWCOUNT) NEWCOUNT,
                    SUM(T.CONNCOUNT) CONNCOUNT,
                    SUM(T.PAYCOUNT) PAYCOUNT,
                    SUM(T.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100131_GENERAL_DAY T
              WHERE T.DATATYPE = '1'
              GROUP BY T.STATDATE, T.CHANNELID, T.SERVERID, T.APPID) FGD
    ON FRU.STATDATE = FGD.STATDATE
   AND FRU.CHANNELID = FGD.CHANNELID
   AND FRU.SERVERID = FGD.SERVERID
   AND FRU.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100131_VC
prompt ==============================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_VC AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","VCTYPE","VCUSETYPE","VCUSEWAY","VCAMOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100131_VC T;

prompt
prompt Creating view V_FACT_100131_WEEK_DVID
prompt =====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100131_WEEK_DVID AS
SELECT T2.STATDATE,
       T2.CHANNELID,
       '100131' APPID,
       NVL(NEWCOUNT, 0) NEWCOUNT,
       NVL(CONNCOUNT, 0) CONNCOUNT
  FROM FACT_100131_GENERAL_WEEK_DVID T1
 RIGHT JOIN (SELECT DD.DAY_DES STATDATE, DAC.CHANNELID
               FROM DIM_DAY DD, V_DIM_APPCHANNEL DAC
              WHERE DAC.APPID = '100131'
                AND DD.WEEK_DAY_CAL = 1
                AND DD.DAY_DES <= TO_CHAR(SYSDATE, 'YYYY-MM-DD')) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
--WHERE T2.STATDATE BETWEEN '2014-09-20' AND '2014-09-30'
;

prompt
prompt Creating view V_FACT_100132_BACK_MAC
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_BACK_MAC AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","LOST_DAYS","BACK_CONN","BACK_PAY","LOADDATE","DATA_SOURCE" FROM FACT_100132_BACK_MAC;

prompt
prompt Creating view V_FACT_100132_BACK_MAC_MONTH
prompt ==========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_BACK_MAC_MONTH AS
SELECT T1.STATDATE,
       T1.CHANNELID,
       T1.SERVERID,
       T1.APPID,
       T2.CONNCOUNT,
       T2.PAYCOUNT,
       T1.BACK_CONN,
       T1.BACK_PAY
  FROM FACT_100132_BACK_MAC_MONTH T1
 INNER JOIN (SELECT FGW.STATDATE,
                    FGW.CHANNELID,
                    FGW.SERVERID,
                    FGW.APPID,
                    SUM(FGW.NEWCOUNT) NEWCOUNT,
                    SUM(FGW.CONNCOUNT) CONNCOUNT,
                    SUM(FGW.PAYCOUNT) PAYCOUNT,
                    SUM(FGW.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100132_GENERAL_MONTH FGW
              WHERE FGW.DATATYPE = '2'
              GROUP BY FGW.STATDATE, FGW.CHANNELID, FGW.SERVERID, FGW.APPID) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID;

prompt
prompt Creating view V_FACT_100132_BACK_MAC_WEEK
prompt =========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_BACK_MAC_WEEK AS
SELECT T1.STATDATE,
       T1.CHANNELID,
       T1.SERVERID,
       T1.APPID,
       T2.CONNCOUNT,
       T2.PAYCOUNT,
       T1.BACK_CONN,
       T1.BACK_PAY
  FROM FACT_100132_BACK_MAC_WEEK T1
 INNER JOIN (SELECT FGW.STATDATE,
                    FGW.CHANNELID,
                    FGW.SERVERID,
                    FGW.APPID,
                    SUM(FGW.NEWCOUNT) NEWCOUNT,
                    SUM(FGW.CONNCOUNT) CONNCOUNT,
                    SUM(FGW.PAYCOUNT) PAYCOUNT,
                    SUM(FGW.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100132_GENERAL_WEEK FGW
              WHERE FGW.DATATYPE = '2'
              GROUP BY FGW.STATDATE, FGW.CHANNELID, FGW.SERVERID, FGW.APPID) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID;

prompt
prompt Creating view V_FACT_100132_BACK_USER
prompt =====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_BACK_USER AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","LOST_DAYS","BACK_CONN","BACK_PAY","LOADDATE","DATA_SOURCE" FROM FACT_100132_BACK_USER;

prompt
prompt Creating view V_FACT_100132_CEVENT
prompt ==================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_CEVENT AS
SELECT T.STATDATE,
       T.CHANNELID,
       T.SERVERID,
       T.APPID,
       T.VERSIONID,
       T.EVENTKEY,
       T.EVENTCOUNT,
       T.EVENTNUM
  FROM FACT_100132_CEVENT T;

prompt
prompt Creating view V_FACT_100132_CEVENT_PAR
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_CEVENT_PAR AS
SELECT STATDATE,
       CHANNELID,
       SERVERID,
       APPID,
       VERSIONID,
       ILEVEL,
       EVENTKEY,
       EVENTPAR_KEY,
       EVENTPAR_VALUE,
       EVENTCOUNT,
       EVENTNUM
  FROM FACT_100132_CEVENT_PAR;

prompt
prompt Creating view V_FACT_100132_COMP_CEVENT
prompt =======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_COMP_CEVENT AS
SELECT STATDATE,
       APPID,
       CHANNELID,
       GAMEVERSION,
       SERVERID,
       ILEVEL,
       EVENTKEY,
       COMPID,
       CALTYPE,
       DIMPARS,
       COMP_DATA
  FROM FACT_100132_COMP_CEVENT;

prompt
prompt Creating view V_FACT_100132_CONNDAYS
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_CONNDAYS AS
SELECT TT.GAMEID APPID,
       TT.CHANNELID,
       TT.SERVERID,
       TT.CONNDAYS,
       TT.CONNCOUNT,
       DD.ALL_CONNCOUNT
  FROM (SELECT D.GAMEID,
               D.CONNDAYS,
               D.CHANNELID,
               D.SERVERID,
               COUNT(1) CONNCOUNT
          FROM (SELECT TC.GAMEID,
                       TC.CHANNELID,
                       TC.SERVERID,
                       TC.ACCOUNTID,
                       COUNT(TC.CONNDATE) CONNDAYS
                  FROM T_100132_CONN TC
                 GROUP BY TC.GAMEID, TC.CHANNELID, TC.SERVERID, TC.ACCOUNTID) D
         GROUP BY D.GAMEID, D.CONNDAYS, D.CHANNELID, D.SERVERID) TT
 INNER JOIN (SELECT T.GAMEID,
                    T.CHANNELID,
                    T.SERVERID,
                    COUNT(DISTINCT T.ACCOUNTID) ALL_CONNCOUNT
               FROM T_100132_CONN T
              GROUP BY T.GAMEID, T.CHANNELID, T.SERVERID) DD
    ON TT.GAMEID = DD.GAMEID
   AND TT.CHANNELID = DD.CHANNELID
   AND TT.SERVERID = DD.SERVERID;

prompt
prompt Creating view V_FACT_100132_CONN_CON
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_CONN_CON AS
SELECT T1.STATDATE,
       T1.CHANNELID,
       T1.SERVERID,
       T1.APPID,
       T1.NEWCOUNT,
       T1.CONNCOUNT,
       NVL(T2.BACK_CONN,0) BACK_CONN7,
			 T1.CONNCOUNT-T1.NEWCOUNT-NVL(T2.BACK_CONN,0) CONN7
  FROM (SELECT T.STATDATE,
               T.CHANNELID,
               T.SERVERID,
               T.APPID,
               SUM(T.NEWCOUNT) NEWCOUNT,
               SUM(T.CONNCOUNT) CONNCOUNT
          FROM FACT_100132_GENERAL_DAY T
         WHERE T.DATATYPE = '1'
         GROUP BY T.STATDATE, T.CHANNELID, T.SERVERID, T.APPID) T1
 LEFT JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    SUM(T.BACK_CONN) BACK_CONN
               FROM FACT_100132_BACK_USER T
              WHERE T.LOST_DAYS > 7
              GROUP BY T.STATDATE, T.CHANNELID, T.SERVERID, T.APPID) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID;

prompt
prompt Creating view V_FACT_100132_DAILY_REPORT
prompt ========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_DAILY_REPORT AS
SELECT "STATDATE","APPID","CHANNELID","SERVERID","INDEXID","INDTYPE","RPT_DATA","LOADDATE","DATA_SOURCE" FROM FACT_100132_DAILY_REPORT;

prompt
prompt Creating view V_FACT_100132_DVID
prompt ================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_DVID AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","DVID_MODEL","DVID_RES","DVID_OS","NEWCOUNT","CONNCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100132_DVID;

prompt
prompt Creating view V_FACT_100132_FIRSTPAY
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_FIRSTPAY AS
SELECT FF.STATDATE,
       FF.FIRSTPAYDATE,
       FF.CHANNELID,
       FF.SERVERID,
       FF.DATATYPE,
       FF.APPID,
       FF.FIRST_PAYFROMREG,
       FF.FIRST_PAYCOUNT,
       FF.PAYAMOUNT,
       FGD.NEWCOUNT
  FROM FACT_100132_FIRSTPAY FF
 INNER JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.DATATYPE,
                    T.APPID,
                    SUM(T.NEWCOUNT) NEWCOUNT
               FROM FACT_100132_GENERAL_DAY T
              GROUP BY T.STATDATE,
                       T.CHANNELID,
                       T.SERVERID,
                       T.DATATYPE,
                       T.APPID) FGD
    ON FF.STATDATE = FGD.STATDATE
   AND FF.CHANNELID = FGD.CHANNELID
   AND FF.SERVERID = FGD.SERVERID
   AND FF.DATATYPE = FGD.DATATYPE
   AND FF.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100132_FIRSTPAY_AMOUNT
prompt ===========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_FIRSTPAY_AMOUNT AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYAMOUNT","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100132_FIRSTPAY_AMOUNT T;

prompt
prompt Creating view V_FACT_100132_FIRSTPAY_ARPPU
prompt ==========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_FIRSTPAY_ARPPU AS
SELECT T1.STATDATE,
       T1.CHANNELID,
       T1.SERVERID,
       T1.APPID,
       T1.FIRST_PAYFROMREG,
       T1.FIRST_PAYCOUNT,
       T2.PAYAMOUNT
  FROM (SELECT * FROM FACT_100132_FIRSTPAY F WHERE F.DATATYPE = '1') T1
 INNER JOIN FACT_100132_LTV_USER T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID
   AND T1.FIRST_PAYFROMREG = T2.LTV_DAYS - 1;

prompt
prompt Creating view V_FACT_100132_GENERAL_DAY
prompt =======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_GENERAL_DAY AS
SELECT STATDATE,
       CHANNELID,
       SERVERID,
       DATATYPE,
       APPID,
       VERSIONID,
       NEWCOUNT,
       CONNCOUNT,
       PAYCOUNT,
       PAYAMOUNT
  FROM FACT_100132_GENERAL_DAY;

prompt
prompt Creating view V_FACT_100132_GENERAL_DAY_DVID
prompt ============================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_GENERAL_DAY_DVID AS
SELECT T2.STATDATE,
       T2.CHANNELID,
       '100132' APPID,
       NVL(NEWCOUNT, 0) NEWCOUNT,
       NVL(CONNCOUNT, 0) CONNCOUNT
  FROM FACT_100132_GENERAL_DAY_DVID T1
 RIGHT JOIN (SELECT DD.DAY_DES STATDATE, DAC.CHANNELID
               FROM DIM_DAY DD, V_DIM_APPCHANNEL DAC
              WHERE DAC.APPID = '100132'
                AND DD.DAY_DES <= TO_CHAR(SYSDATE, 'YYYY-MM-DD')) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
--WHERE T2.STATDATE BETWEEN '2014-09-25' AND '2014-09-29'
;

prompt
prompt Creating view V_FACT_100132_GENERAL_HOUR
prompt ========================================
prompt
create or replace force view v_fact_100132_general_hour as
Select T.STATDATE,
               T.CHANNELID,
               T.SERVERID,
               T.DATATYPE,
               T.APPID,
               T.VERSIONID,
               T.NEWCOUNT,
               T.CONNCOUNT,
               T.PAYCOUNT,
               T.PAYAMOUNT
          FROM FACT_100132_GENERAL_HOUR T;

prompt
prompt Creating view V_FACT_100132_GENERAL_LEVEL
prompt =========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_GENERAL_LEVEL AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","ROLELEVEL","NEWCOUNT","CONNCOUNT","PAYCOUNT","PAYAMOUNT","LOADDATE","DATA_SOURCE"
  FROM FACT_100132_GENERAL_LEVEL T;

prompt
prompt Creating view V_FACT_100132_GENERAL_MONTH
prompt =========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_GENERAL_MONTH AS
SELECT STATDATE,
       CHANNELID,
       SERVERID,
       DATATYPE,
       APPID,
       VERSIONID,
       NEWCOUNT,
       CONNCOUNT,
       PAYCOUNT,
       PAYAMOUNT
  FROM FACT_100132_GENERAL_MONTH;

prompt
prompt Creating view V_FACT_100132_GENERAL_WEEK
prompt ========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_GENERAL_WEEK AS
SELECT STATDATE,
       CHANNELID,
       SERVERID,
       DATATYPE,
       APPID,
       VERSIONID,
       NEWCOUNT,
       CONNCOUNT,
       PAYCOUNT,
       PAYAMOUNT
  FROM FACT_100132_GENERAL_WEEK;

prompt
prompt Creating view V_FACT_100132_HOUR_DVID
prompt =====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_HOUR_DVID AS
SELECT T2.DATE_HOUR STATDATE,
       T2.CHANNELID,
       '100132' APPID,
       NVL(NEWCOUNT, 0) NEWCOUNT,
       NVL(CONNCOUNT, 0) CONNCOUNT
  FROM FACT_100132_GENERAL_HOUR_DVID T1
 RIGHT JOIN (SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD') || ' ' || DD.HOUR_DES DATE_HOUR,
                    DAC.CHANNELID
               FROM DIM_HOUR DD, V_DIM_APPCHANNEL DAC
              WHERE DAC.APPID = '100132'
                AND DD.HOURID < TO_CHAR(SYSDATE, 'HH24')) T2
    ON T1.STATDATE = T2.DATE_HOUR
   AND T1.CHANNELID = T2.CHANNELID;

prompt
prompt Creating view V_FACT_100132_LEVELPAY
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_LEVELPAY AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","ROLELEVEL","PAYCOUNT","FIRST_PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100132_LEVELPAY;

prompt
prompt Creating view V_FACT_100132_LOST_MAC
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_LOST_MAC AS
SELECT T."STATDATE",
       T."LOSTDATE",
       T."CHANNELID",
       T."SERVERID",
       T."APPID",
       T."LOST_DAYS",
       T."LOST_CONN",
       T."LOST_PAY",
       FGL.CONNCOUNT,
       FGL.PAYCOUNT
  FROM (SELECT FLM.STATDATE,
               FLM.LOSTDATE,
               FLM.CHANNELID,
               FLM.SERVERID,
               FLM.APPID,
               FLM.LOST_DAYS,
               SUM(FLM.LOST_CONN) LOST_CONN,
               SUM(FLM.LOST_PAY) LOST_PAY
        --SUM(FGL.CONNCOUNT) CONNCOUNT,
        --SUM(FGL.PAYCOUNT) PAYCOUNT
          FROM FACT_100132_LOST_MAC FLM
         GROUP BY FLM.STATDATE,
                  FLM.LOSTDATE,
                  FLM.CHANNELID,
                  FLM.SERVERID,
                  FLM.APPID,
                  FLM.LOST_DAYS) T
 INNER JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    SUM(T.NEWCOUNT) NEWCOUNT,
                    SUM(T.CONNCOUNT) CONNCOUNT,
                    SUM(T.PAYCOUNT) PAYCOUNT,
                    SUM(T.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100132_GENERAL_DAY T
              WHERE T.DATATYPE = '2'
							GROUP BY T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID) FGL
    ON T.STATDATE = FGL.STATDATE
   AND T.CHANNELID = FGL.CHANNELID
   AND T.SERVERID = FGL.SERVERID
   AND T.APPID = FGL.APPID
;

prompt
prompt Creating view V_FACT_100132_LOST_MAC_LEVEL
prompt ==========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_LOST_MAC_LEVEL AS
SELECT FLM.STATDATE,
       FLM.LOSTDATE,
       FLM.CHANNELID,
       FLM.SERVERID,
       FLM.APPID,
       FLM.ROLELEVEL,
       FLM.LOST_DAYS,
       FLM.LOST_CONN,
       FLM.LOST_PAY,
       FGL.CONNCOUNT,
       FGL.PAYCOUNT
  FROM FACT_100132_LOST_MAC FLM
 INNER JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    T.ROLELEVEL,
                    SUM(T.NEWCOUNT) NEWCOUNT,
                    SUM(T.CONNCOUNT) CONNCOUNT,
                    SUM(T.PAYCOUNT) PAYCOUNT,
                    SUM(T.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100132_GENERAL_LEVEL T
              WHERE T.DATATYPE = '2'
              GROUP BY T.STATDATE,
                       T.CHANNELID,
                       T.SERVERID,
                       T.APPID,
                       T.ROLELEVEL) FGL
    ON FLM.STATDATE = FGL.STATDATE
   AND FLM.CHANNELID = FGL.CHANNELID
   AND FLM.SERVERID = FGL.SERVERID
   AND FLM.APPID = FGL.APPID
   AND FLM.ROLELEVEL = FGL.ROLELEVEL;

prompt
prompt Creating view V_FACT_100132_LOST_USER
prompt =====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_LOST_USER AS
SELECT "STATDATE","LOSTDATE","CHANNELID","SERVERID","APPID","ROLELEVEL","LOST_DAYS","LOST_CONN","LOST_PAY","LOADDATE","DATA_SOURCE" FROM FACT_100132_LOST_USER;

prompt
prompt Creating view V_FACT_100132_LTV_MAC
prompt ===================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_LTV_MAC AS
SELECT FLM.STATDATE,
       FLM.CHANNELID,
       FLM.SERVERID,
       FLM.APPID,
       FLM.LTV_DAYS,
       FGD.NEWCOUNT,
       FLM.PAYAMOUNT
  FROM FACT_100132_LTV_MAC FLM
  LEFT JOIN (SELECT D.STATDATE,
                    D.CHANNELID,
                    D.SERVERID,
                    D.APPID,
                    SUM(D.NEWCOUNT) NEWCOUNT
               FROM FACT_100132_GENERAL_DAY D
              WHERE D.DATATYPE = '2'
              GROUP BY D.STATDATE, D.CHANNELID, D.SERVERID, D.APPID) FGD
    ON FLM.STATDATE = FGD.STATDATE
   AND FLM.CHANNELID = FGD.CHANNELID
   AND FLM.SERVERID = FGD.SERVERID
   AND FLM.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100132_LTV_USER
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_LTV_USER AS
SELECT FLM.STATDATE,
       FLM.CHANNELID,
       FLM.SERVERID,
       FLM.APPID,
       FLM.LTV_DAYS,
       FGD.NEWCOUNT,
       FLM.PAYAMOUNT
  FROM FACT_100132_LTV_USER FLM
  LEFT JOIN (SELECT D.STATDATE,
                    D.CHANNELID,
                    D.SERVERID,
                    D.APPID,
                    SUM(D.NEWCOUNT) NEWCOUNT
               FROM FACT_100132_GENERAL_DAY D
              WHERE D.DATATYPE = '1'
              GROUP BY D.STATDATE, D.CHANNELID, D.SERVERID, D.APPID) FGD
    ON FLM.STATDATE = FGD.STATDATE
   AND FLM.CHANNELID = FGD.CHANNELID
   AND FLM.SERVERID = FGD.SERVERID
   AND FLM.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100132_MISS_FIRST
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_MISS_FIRST AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","MISSIONID","ROLELEVEL","ROLEJOB","FIRSTENTER_SUCC","FIRSTENTER_FAIL","LOADDATE","DATA_SOURCE" FROM FACT_100132_MISS_FIRST;

prompt
prompt Creating view V_FACT_100132_MONTH_DVID
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_MONTH_DVID AS
SELECT "STATDATE","CHANNELID","APPID","NEWCOUNT","CONNCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100132_GENERAL_MONTH_DVID;

prompt
prompt Creating view V_FACT_100132_NET
prompt ===============================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_NET AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","DVID_NET","CONNCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100132_NET;

prompt
prompt Creating view V_FACT_100132_OPERATOR
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_OPERATOR AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","DVID_OPERATOR","CONNCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100132_OPERATOR;

prompt
prompt Creating view V_FACT_100132_ORDER
prompt =================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_ORDER AS
SELECT STATDATE,
       CHANNELID,
       SERVERID,
       DATATYPE,
       APPID,
       VERSIONID,
       SUM(PAYSUCCCOUNT) PAYSUCCCOUNT,
       SUM(PAYFAILCOUNT) PAYFAILCOUNT,
       SUM(PAYSUCCAMOUNT) PAYSUCCAMOUNT,
       SUM(PAYFAILAMOUNT) PAYFAILAMOUNT,
       SUM(PAYSUCCNUM) PAYSUCCNUM,
       SUM(PAYFAILNUM) PAYFAILNUM
  FROM FACT_100132_ORDER
 GROUP BY STATDATE, CHANNELID, SERVERID, DATATYPE, APPID, VERSIONID;

prompt
prompt Creating view V_FACT_100132_ORDER_HOUR
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_ORDER_HOUR AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYSUCCCOUNT","PAYFAILCOUNT","PAYSUCCAMOUNT","PAYFAILAMOUNT","PAYSUCCNUM","PAYFAILNUM","LOADDATE","DATA_SOURCE" FROM FACT_100132_ORDER_HOUR;

prompt
prompt Creating view V_FACT_100132_ORDER_MONTH
prompt =======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_ORDER_MONTH AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYSUCCCOUNT","PAYFAILCOUNT","PAYSUCCAMOUNT","PAYFAILAMOUNT","PAYSUCCNUM","PAYFAILNUM","LOADDATE","DATA_SOURCE" FROM FACT_100132_ORDER_MONTH;

prompt
prompt Creating view V_FACT_100132_ORDER_WEEK
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_ORDER_WEEK AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYSUCCCOUNT","PAYFAILCOUNT","PAYSUCCAMOUNT","PAYFAILAMOUNT","PAYSUCCNUM","PAYFAILNUM","LOADDATE","DATA_SOURCE" FROM FACT_100132_ORDER_WEEK;

prompt
prompt Creating view V_FACT_100132_PAYAMOUNT_DAY
prompt =========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_PAYAMOUNT_DAY AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYAMOUNT","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100132_PAYAMOUNT_DAY;

prompt
prompt Creating view V_FACT_100132_PAYAMOUNT_MONTH
prompt ===========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_PAYAMOUNT_MONTH AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYAMOUNT","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100132_PAYAMOUNT_MONTH;

prompt
prompt Creating view V_FACT_100132_PAYAMOUNT_WEEK
prompt ==========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_PAYAMOUNT_WEEK AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYAMOUNT","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100132_PAYAMOUNT_WEEK;

prompt
prompt Creating view V_FACT_100132_PAYNUM_DAY
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_PAYNUM_DAY AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYNUM","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100132_PAYNUM_DAY;

prompt
prompt Creating view V_FACT_100132_PAYNUM_MONTH
prompt ========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_PAYNUM_MONTH AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYNUM","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100132_PAYNUM_MONTH;

prompt
prompt Creating view V_FACT_100132_PAYNUM_WEEK
prompt =======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_PAYNUM_WEEK AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYNUM","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100132_PAYNUM_WEEK;

prompt
prompt Creating view V_FACT_100132_PAYTYPE
prompt ===================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_PAYTYPE AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYTYPEID","PAYAMOUNT","PAYCOUNT","PAYNUM","LOADDATE","DATA_SOURCE" FROM FACT_100132_PAYTYPE;

prompt
prompt Creating view V_FACT_100132_PAYWAY
prompt ==================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_PAYWAY AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYWAYID","PAYAMOUNT","PAYCOUNT","PAYNUM","LOADDATE","DATA_SOURCE" FROM FACT_100132_PAYWAY;

prompt
prompt Creating view V_FACT_100132_QDTG
prompt ================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_QDTG AS
SELECT T2.STATDATE,
       T2.CHANNELID,
       T2.SERVERID,
       T2.APPID,
       T2.NEWCOUNT,
       T3.NEW_REMAIN,
       T1.FIRST_PAYCOUNT
  FROM (SELECT FF.STATDATE,
               FF.CHANNELID,
               FF.SERVERID,
               FF.APPID,
               SUM(FF.FIRST_PAYCOUNT) FIRST_PAYCOUNT
          FROM FACT_100132_FIRSTPAY FF
         WHERE FF.FIRST_PAYFROMREG < 7
           AND FF.DATATYPE = '1'
         GROUP BY FF.STATDATE, FF.CHANNELID, FF.SERVERID, FF.APPID) T1

 RIGHT JOIN (SELECT F.STATDATE,
                    F.CHANNELID,
                    F.SERVERID,
                    F.APPID,
                    SUM(F.NEWCOUNT) NEWCOUNT
               FROM FACT_100132_GENERAL_DAY F
              WHERE F.DATATYPE = '1'
              GROUP BY F.STATDATE, F.CHANNELID, F.SERVERID, F.APPID) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID
 LEFT JOIN (SELECT * FROM FACT_100132_REMAIN_USER F WHERE F.REMAIN_DAYS = 1) T3

    ON T3.STATDATE = T2.STATDATE
   AND T3.CHANNELID = T2.CHANNELID
   AND T3.SERVERID = T2.SERVERID
   AND T3.APPID = T2.APPID;

prompt
prompt Creating view V_FACT_100132_REGION
prompt ==================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_REGION AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","COUNTRY","PROVINCE","CITY","NEWCOUNT","CONNCOUNT","PAYCOUNT","PAYAMOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100132_REGION;

prompt
prompt Creating view V_FACT_100132_REMAIN_MAC
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_REMAIN_MAC AS
SELECT FRU.STATDATE,
       FRU.CONNDATE,
       FRU.CHANNELID,
       FRU.SERVERID,
       FRU.APPID,
       FRU.REMAIN_DAYS,
       FGD.NEWCOUNT,
       FGD.CONNCOUNT,
       FGD.PAYCOUNT,
       FRU.NEW_REMAIN,
       FRU.CONN_REMAIN,
       FRU.PAY_REMAIN
  FROM FACT_100132_REMAIN_MAC FRU
  LEFT JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    SUM(T.NEWCOUNT) NEWCOUNT,
                    SUM(T.CONNCOUNT) CONNCOUNT,
                    SUM(T.PAYCOUNT) PAYCOUNT,
                    SUM(T.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100132_GENERAL_DAY T
              WHERE T.DATATYPE = '2'
              GROUP BY T.STATDATE, T.CHANNELID, T.SERVERID, T.APPID) FGD
    ON FRU.STATDATE = FGD.STATDATE
   AND FRU.CHANNELID = FGD.CHANNELID
   AND FRU.SERVERID = FGD.SERVERID
   AND FRU.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100132_REMAIN_USER
prompt =======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_REMAIN_USER AS
SELECT FRU.STATDATE,
       FRU.CONNDATE,
       FRU.CHANNELID,
       FRU.SERVERID,
       FRU.APPID,
       FRU.REMAIN_DAYS,
       FGD.NEWCOUNT,
       FGD.CONNCOUNT,
       FGD.PAYCOUNT,
       FRU.NEW_REMAIN,
       FRU.CONN_REMAIN,
       FRU.PAY_REMAIN
  FROM FACT_100132_REMAIN_USER FRU
  LEFT JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    SUM(T.NEWCOUNT) NEWCOUNT,
                    SUM(T.CONNCOUNT) CONNCOUNT,
                    SUM(T.PAYCOUNT) PAYCOUNT,
                    SUM(T.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100132_GENERAL_DAY T
              WHERE T.DATATYPE = '1'
              GROUP BY T.STATDATE, T.CHANNELID, T.SERVERID, T.APPID) FGD
    ON FRU.STATDATE = FGD.STATDATE
   AND FRU.CHANNELID = FGD.CHANNELID
   AND FRU.SERVERID = FGD.SERVERID
   AND FRU.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100132_VC
prompt ==============================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_VC AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","VCTYPE","VCUSETYPE","VCUSEWAY","VCAMOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100132_VC T;

prompt
prompt Creating view V_FACT_100132_WEEK_DVID
prompt =====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100132_WEEK_DVID AS
SELECT T2.STATDATE,
       T2.CHANNELID,
       '100132' APPID,
       NVL(NEWCOUNT, 0) NEWCOUNT,
       NVL(CONNCOUNT, 0) CONNCOUNT
  FROM FACT_100132_GENERAL_WEEK_DVID T1
 RIGHT JOIN (SELECT DD.DAY_DES STATDATE, DAC.CHANNELID
               FROM DIM_DAY DD, V_DIM_APPCHANNEL DAC
              WHERE DAC.APPID = '100132'
                AND DD.WEEK_DAY_CAL = 1
                AND DD.DAY_DES <= TO_CHAR(SYSDATE, 'YYYY-MM-DD')) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
--WHERE T2.STATDATE BETWEEN '2014-09-20' AND '2014-09-30'
;

prompt
prompt Creating view V_FACT_100138_BACK_MAC
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_BACK_MAC AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","LOST_DAYS","BACK_CONN","BACK_PAY","LOADDATE","DATA_SOURCE" FROM FACT_100138_BACK_MAC;

prompt
prompt Creating view V_FACT_100138_BACK_MAC_MONTH
prompt ==========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_BACK_MAC_MONTH AS
SELECT T1.STATDATE,
       T1.CHANNELID,
       T1.SERVERID,
       T1.APPID,
       T2.CONNCOUNT,
       T2.PAYCOUNT,
       T1.BACK_CONN,
       T1.BACK_PAY
  FROM FACT_100138_BACK_MAC_MONTH T1
 INNER JOIN (SELECT FGW.STATDATE,
                    FGW.CHANNELID,
                    FGW.SERVERID,
                    FGW.APPID,
                    SUM(FGW.NEWCOUNT) NEWCOUNT,
                    SUM(FGW.CONNCOUNT) CONNCOUNT,
                    SUM(FGW.PAYCOUNT) PAYCOUNT,
                    SUM(FGW.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100138_GENERAL_MONTH FGW
              WHERE FGW.DATATYPE = '2'
              GROUP BY FGW.STATDATE, FGW.CHANNELID, FGW.SERVERID, FGW.APPID) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID;

prompt
prompt Creating view V_FACT_100138_BACK_MAC_WEEK
prompt =========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_BACK_MAC_WEEK AS
SELECT T1.STATDATE,
       T1.CHANNELID,
       T1.SERVERID,
       T1.APPID,
       T2.CONNCOUNT,
       T2.PAYCOUNT,
       T1.BACK_CONN,
       T1.BACK_PAY
  FROM FACT_100138_BACK_MAC_WEEK T1
 INNER JOIN (SELECT FGW.STATDATE,
                    FGW.CHANNELID,
                    FGW.SERVERID,
                    FGW.APPID,
                    SUM(FGW.NEWCOUNT) NEWCOUNT,
                    SUM(FGW.CONNCOUNT) CONNCOUNT,
                    SUM(FGW.PAYCOUNT) PAYCOUNT,
                    SUM(FGW.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100138_GENERAL_WEEK FGW
              WHERE FGW.DATATYPE = '2'
              GROUP BY FGW.STATDATE, FGW.CHANNELID, FGW.SERVERID, FGW.APPID) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID;

prompt
prompt Creating view V_FACT_100138_BACK_USER
prompt =====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_BACK_USER AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","LOST_DAYS","BACK_CONN","BACK_PAY","LOADDATE","DATA_SOURCE" FROM FACT_100138_BACK_USER;

prompt
prompt Creating view V_FACT_100138_CEVENT
prompt ==================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_CEVENT AS
SELECT T.STATDATE,
       T.CHANNELID,
       T.SERVERID,
       T.APPID,
       T.VERSIONID,
       T.EVENTKEY,
       T.EVENTCOUNT,
       T.EVENTNUM
  FROM FACT_100138_CEVENT T;

prompt
prompt Creating view V_FACT_100138_CEVENT_PAR
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_CEVENT_PAR AS
SELECT STATDATE,
       CHANNELID,
       SERVERID,
       APPID,
       VERSIONID,
       ILEVEL,
       EVENTKEY,
       EVENTPAR_KEY,
       EVENTPAR_VALUE,
       EVENTCOUNT,
       EVENTNUM
  FROM FACT_100138_CEVENT_PAR;

prompt
prompt Creating view V_FACT_100138_COMP_CEVENT
prompt =======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_COMP_CEVENT AS
SELECT STATDATE,
       APPID,
       CHANNELID,
       GAMEVERSION,
       SERVERID,
       ILEVEL,
       EVENTKEY,
       COMPID,
       CALTYPE,
       DIMPARS,
       COMP_DATA
  FROM FACT_100138_COMP_CEVENT;

prompt
prompt Creating view V_FACT_100138_CONNDAYS
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_CONNDAYS AS
SELECT TT.GAMEID APPID,
       TT.CHANNELID,
       TT.SERVERID,
       TT.CONNDAYS,
       TT.CONNCOUNT,
       DD.ALL_CONNCOUNT
  FROM (SELECT D.GAMEID,
               D.CONNDAYS,
               D.CHANNELID,
               D.SERVERID,
               COUNT(1) CONNCOUNT
          FROM (SELECT TC.GAMEID,
                       TC.CHANNELID,
                       TC.SERVERID,
                       TC.ACCOUNTID,
                       COUNT(TC.CONNDATE) CONNDAYS
                  FROM T_100138_CONN TC
                 GROUP BY TC.GAMEID, TC.CHANNELID, TC.SERVERID, TC.ACCOUNTID) D
         GROUP BY D.GAMEID, D.CONNDAYS, D.CHANNELID, D.SERVERID) TT
 INNER JOIN (SELECT T.GAMEID,
                    T.CHANNELID,
                    T.SERVERID,
                    COUNT(DISTINCT T.ACCOUNTID) ALL_CONNCOUNT
               FROM T_100138_CONN T
              GROUP BY T.GAMEID, T.CHANNELID, T.SERVERID) DD
    ON TT.GAMEID = DD.GAMEID
   AND TT.CHANNELID = DD.CHANNELID
   AND TT.SERVERID = DD.SERVERID;

prompt
prompt Creating view V_FACT_100138_CONN_CON
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_CONN_CON AS
SELECT T1.STATDATE,
       T1.CHANNELID,
       T1.SERVERID,
       T1.APPID,
       T1.NEWCOUNT,
       T1.CONNCOUNT,
       NVL(T2.BACK_CONN,0) BACK_CONN7,
			 T1.CONNCOUNT-T1.NEWCOUNT-NVL(T2.BACK_CONN,0) CONN7
  FROM (SELECT T.STATDATE,
               T.CHANNELID,
               T.SERVERID,
               T.APPID,
               SUM(T.NEWCOUNT) NEWCOUNT,
               SUM(T.CONNCOUNT) CONNCOUNT
          FROM FACT_100138_GENERAL_DAY T
         WHERE T.DATATYPE = '1'
         GROUP BY T.STATDATE, T.CHANNELID, T.SERVERID, T.APPID) T1
 LEFT JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    SUM(T.BACK_CONN) BACK_CONN
               FROM FACT_100138_BACK_USER T
              WHERE T.LOST_DAYS > 7
              GROUP BY T.STATDATE, T.CHANNELID, T.SERVERID, T.APPID) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID;

prompt
prompt Creating view V_FACT_100138_DAILY_REPORT
prompt ========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_DAILY_REPORT AS
SELECT "STATDATE","APPID","CHANNELID","SERVERID","INDEXID","INDTYPE","RPT_DATA","LOADDATE","DATA_SOURCE" FROM FACT_100138_DAILY_REPORT;

prompt
prompt Creating view V_FACT_100138_DVID
prompt ================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_DVID AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","DVID_MODEL","DVID_RES","DVID_OS","NEWCOUNT","CONNCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100138_DVID;

prompt
prompt Creating view V_FACT_100138_FIRSTPAY
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_FIRSTPAY AS
SELECT FF.STATDATE,
       FF.FIRSTPAYDATE,
       FF.CHANNELID,
       FF.SERVERID,
       FF.DATATYPE,
       FF.APPID,
       FF.FIRST_PAYFROMREG,
       FF.FIRST_PAYCOUNT,
       FF.PAYAMOUNT,
       FGD.NEWCOUNT
  FROM FACT_100138_FIRSTPAY FF
 INNER JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.DATATYPE,
                    T.APPID,
                    SUM(T.NEWCOUNT) NEWCOUNT
               FROM FACT_100138_GENERAL_DAY T
              GROUP BY T.STATDATE,
                       T.CHANNELID,
                       T.SERVERID,
                       T.DATATYPE,
                       T.APPID) FGD
    ON FF.STATDATE = FGD.STATDATE
   AND FF.CHANNELID = FGD.CHANNELID
   AND FF.SERVERID = FGD.SERVERID
   AND FF.DATATYPE = FGD.DATATYPE
   AND FF.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100138_FIRSTPAY_AMOUNT
prompt ===========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_FIRSTPAY_AMOUNT AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYAMOUNT","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100138_FIRSTPAY_AMOUNT T;

prompt
prompt Creating view V_FACT_100138_FIRSTPAY_ARPPU
prompt ==========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_FIRSTPAY_ARPPU AS
SELECT T1.STATDATE,
       T1.CHANNELID,
       T1.SERVERID,
       T1.APPID,
       T1.FIRST_PAYFROMREG,
       T1.FIRST_PAYCOUNT,
       T2.PAYAMOUNT
  FROM (SELECT * FROM FACT_100138_FIRSTPAY F WHERE F.DATATYPE = '1') T1
 INNER JOIN FACT_100138_LTV_USER T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID
   AND T1.FIRST_PAYFROMREG = T2.LTV_DAYS - 1;

prompt
prompt Creating view V_FACT_100138_GENERAL_DAY
prompt =======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_GENERAL_DAY AS
SELECT DISTINCT  STATDATE,
       CHANNELID,
       SERVERID,
       DATATYPE,
       APPID,
       VERSIONID,
       NEWCOUNT,
       CONNCOUNT,
       PAYCOUNT,
       PAYAMOUNT
  FROM FACT_100138_GENERAL_DAY;

prompt
prompt Creating view V_FACT_100138_GENERAL_DAY_DVID
prompt ============================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_GENERAL_DAY_DVID AS
SELECT T2.STATDATE,
       T2.CHANNELID,
       '100138' APPID,
       NVL(NEWCOUNT, 0) NEWCOUNT,
       NVL(CONNCOUNT, 0) CONNCOUNT
  FROM FACT_100138_GENERAL_DAY_DVID T1
 RIGHT JOIN (SELECT DD.DAY_DES STATDATE, DAC.CHANNELID
               FROM DIM_DAY DD, V_DIM_APPCHANNEL DAC
              WHERE DAC.APPID = '100138'
                AND DD.DAY_DES <= TO_CHAR(SYSDATE, 'YYYY-MM-DD')) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
--WHERE T2.STATDATE BETWEEN '2014-09-25' AND '2014-09-29'
;

prompt
prompt Creating view V_FACT_100138_GENERAL_HOUR
prompt ========================================
prompt
create or replace force view v_fact_100138_general_hour as
Select T.STATDATE,
               T.CHANNELID,
               T.SERVERID,
               T.DATATYPE,
               T.APPID,
               T.VERSIONID,
               T.NEWCOUNT,
               T.CONNCOUNT,
               T.PAYCOUNT,
               T.PAYAMOUNT
          FROM FACT_100138_GENERAL_HOUR T;

prompt
prompt Creating view V_FACT_100138_GENERAL_LEVEL
prompt =========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_GENERAL_LEVEL AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","ROLELEVEL","NEWCOUNT","CONNCOUNT","PAYCOUNT","PAYAMOUNT","LOADDATE","DATA_SOURCE"
  FROM FACT_100138_GENERAL_LEVEL T;

prompt
prompt Creating view V_FACT_100138_GENERAL_MONTH
prompt =========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_GENERAL_MONTH AS
SELECT STATDATE,
       CHANNELID,
       SERVERID,
       DATATYPE,
       APPID,
       VERSIONID,
       NEWCOUNT,
       CONNCOUNT,
       PAYCOUNT,
       PAYAMOUNT
  FROM FACT_100138_GENERAL_MONTH;

prompt
prompt Creating view V_FACT_100138_GENERAL_WEEK
prompt ========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_GENERAL_WEEK AS
SELECT STATDATE,
       CHANNELID,
       SERVERID,
       DATATYPE,
       APPID,
       VERSIONID,
       NEWCOUNT,
       CONNCOUNT,
       PAYCOUNT,
       PAYAMOUNT
  FROM FACT_100138_GENERAL_WEEK;

prompt
prompt Creating view V_FACT_100138_HOUR_DVID
prompt =====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_HOUR_DVID AS
SELECT T2.DATE_HOUR STATDATE,
       T2.CHANNELID,
       '100138' APPID,
       NVL(NEWCOUNT, 0) NEWCOUNT,
       NVL(CONNCOUNT, 0) CONNCOUNT
  FROM FACT_100138_GENERAL_HOUR_DVID T1
 RIGHT JOIN (SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD') || ' ' || DD.HOUR_DES DATE_HOUR,
                    DAC.CHANNELID
               FROM DIM_HOUR DD, V_DIM_APPCHANNEL DAC
              WHERE DAC.APPID = '100138'
                AND DD.HOURID < TO_CHAR(SYSDATE, 'HH24')) T2
    ON T1.STATDATE = T2.DATE_HOUR
   AND T1.CHANNELID = T2.CHANNELID;

prompt
prompt Creating view V_FACT_100138_LEVELPAY
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_LEVELPAY AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","ROLELEVEL","PAYCOUNT","FIRST_PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100138_LEVELPAY;

prompt
prompt Creating view V_FACT_100138_LOST_MAC
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_LOST_MAC AS
SELECT T."STATDATE",
       T."LOSTDATE",
       T."CHANNELID",
       T."SERVERID",
       T."APPID",
       T."LOST_DAYS",
       T."LOST_CONN",
       T."LOST_PAY",
       FGL.CONNCOUNT,
       FGL.PAYCOUNT
  FROM (SELECT FLM.STATDATE,
               FLM.LOSTDATE,
               FLM.CHANNELID,
               FLM.SERVERID,
               FLM.APPID,
               FLM.LOST_DAYS,
               SUM(FLM.LOST_CONN) LOST_CONN,
               SUM(FLM.LOST_PAY) LOST_PAY
        --SUM(FGL.CONNCOUNT) CONNCOUNT,
        --SUM(FGL.PAYCOUNT) PAYCOUNT
          FROM FACT_100138_LOST_MAC FLM
         GROUP BY FLM.STATDATE,
                  FLM.LOSTDATE,
                  FLM.CHANNELID,
                  FLM.SERVERID,
                  FLM.APPID,
                  FLM.LOST_DAYS) T
 INNER JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    SUM(T.NEWCOUNT) NEWCOUNT,
                    SUM(T.CONNCOUNT) CONNCOUNT,
                    SUM(T.PAYCOUNT) PAYCOUNT,
                    SUM(T.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100138_GENERAL_DAY T
              WHERE T.DATATYPE = '2'
							GROUP BY T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID) FGL
    ON T.STATDATE = FGL.STATDATE
   AND T.CHANNELID = FGL.CHANNELID
   AND T.SERVERID = FGL.SERVERID
   AND T.APPID = FGL.APPID
;

prompt
prompt Creating view V_FACT_100138_LOST_MAC_LEVEL
prompt ==========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_LOST_MAC_LEVEL AS
SELECT FLM.STATDATE,
       FLM.LOSTDATE,
       FLM.CHANNELID,
       FLM.SERVERID,
       FLM.APPID,
       FLM.ROLELEVEL,
       FLM.LOST_DAYS,
       FLM.LOST_CONN,
       FLM.LOST_PAY,
       FGL.CONNCOUNT,
       FGL.PAYCOUNT
  FROM FACT_100138_LOST_MAC FLM
 INNER JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    T.ROLELEVEL,
                    SUM(T.NEWCOUNT) NEWCOUNT,
                    SUM(T.CONNCOUNT) CONNCOUNT,
                    SUM(T.PAYCOUNT) PAYCOUNT,
                    SUM(T.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100138_GENERAL_LEVEL T
              WHERE T.DATATYPE = '2'
              GROUP BY T.STATDATE,
                       T.CHANNELID,
                       T.SERVERID,
                       T.APPID,
                       T.ROLELEVEL) FGL
    ON FLM.STATDATE = FGL.STATDATE
   AND FLM.CHANNELID = FGL.CHANNELID
   AND FLM.SERVERID = FGL.SERVERID
   AND FLM.APPID = FGL.APPID
   AND FLM.ROLELEVEL = FGL.ROLELEVEL;

prompt
prompt Creating view V_FACT_100138_LOST_USER
prompt =====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_LOST_USER AS
SELECT "STATDATE","LOSTDATE","CHANNELID","SERVERID","APPID","ROLELEVEL","LOST_DAYS","LOST_CONN","LOST_PAY","LOADDATE","DATA_SOURCE" FROM FACT_100138_LOST_USER;

prompt
prompt Creating view V_FACT_100138_LTV_MAC
prompt ===================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_LTV_MAC AS
SELECT FLM.STATDATE,
       FLM.CHANNELID,
       FLM.SERVERID,
       FLM.APPID,
       FLM.LTV_DAYS,
       FGD.NEWCOUNT,
       FLM.PAYAMOUNT
  FROM FACT_100138_LTV_MAC FLM
  LEFT JOIN (SELECT D.STATDATE,
                    D.CHANNELID,
                    D.SERVERID,
                    D.APPID,
                    SUM(D.NEWCOUNT) NEWCOUNT
               FROM FACT_100138_GENERAL_DAY D
              WHERE D.DATATYPE = '2'
              GROUP BY D.STATDATE, D.CHANNELID, D.SERVERID, D.APPID) FGD
    ON FLM.STATDATE = FGD.STATDATE
   AND FLM.CHANNELID = FGD.CHANNELID
   AND FLM.SERVERID = FGD.SERVERID
   AND FLM.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100138_LTV_USER
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_LTV_USER AS
SELECT FLM.STATDATE,
       FLM.CHANNELID,
       FLM.SERVERID,
       FLM.APPID,
       FLM.LTV_DAYS,
       FGD.NEWCOUNT,
       FLM.PAYAMOUNT
  FROM FACT_100138_LTV_USER FLM
  LEFT JOIN (SELECT D.STATDATE,
                    D.CHANNELID,
                    D.SERVERID,
                    D.APPID,
                    SUM(D.NEWCOUNT) NEWCOUNT
               FROM FACT_100138_GENERAL_DAY D
              WHERE D.DATATYPE = '1'
              GROUP BY D.STATDATE, D.CHANNELID, D.SERVERID, D.APPID) FGD
    ON FLM.STATDATE = FGD.STATDATE
   AND FLM.CHANNELID = FGD.CHANNELID
   AND FLM.SERVERID = FGD.SERVERID
   AND FLM.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100138_MISS_FIRST
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_MISS_FIRST AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","MISSIONID","ROLELEVEL","ROLEJOB","FIRSTENTER_SUCC","FIRSTENTER_FAIL","LOADDATE","DATA_SOURCE" FROM FACT_100138_MISS_FIRST;

prompt
prompt Creating view V_FACT_100138_MONTH_DVID
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_MONTH_DVID AS
SELECT "STATDATE","CHANNELID","APPID","NEWCOUNT","CONNCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100138_GENERAL_MONTH_DVID;

prompt
prompt Creating view V_FACT_100138_NET
prompt ===============================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_NET AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","DVID_NET","CONNCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100138_NET;

prompt
prompt Creating view V_FACT_100138_OPERATOR
prompt ====================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_OPERATOR AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","DVID_OPERATOR","CONNCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100138_OPERATOR;

prompt
prompt Creating view V_FACT_100138_ORDER
prompt =================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_ORDER AS
SELECT STATDATE,
       CHANNELID,
       SERVERID,
       DATATYPE,
       APPID,
       VERSIONID,
       SUM(PAYSUCCCOUNT) PAYSUCCCOUNT,
       SUM(PAYFAILCOUNT) PAYFAILCOUNT,
       SUM(PAYSUCCAMOUNT) PAYSUCCAMOUNT,
       SUM(PAYFAILAMOUNT) PAYFAILAMOUNT,
       SUM(PAYSUCCNUM) PAYSUCCNUM,
       SUM(PAYFAILNUM) PAYFAILNUM
  FROM FACT_100138_ORDER
 GROUP BY STATDATE, CHANNELID, SERVERID, DATATYPE, APPID, VERSIONID;

prompt
prompt Creating view V_FACT_100138_ORDER_HOUR
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_ORDER_HOUR AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYSUCCCOUNT","PAYFAILCOUNT","PAYSUCCAMOUNT","PAYFAILAMOUNT","PAYSUCCNUM","PAYFAILNUM","LOADDATE","DATA_SOURCE" FROM FACT_100138_ORDER_HOUR;

prompt
prompt Creating view V_FACT_100138_ORDER_MONTH
prompt =======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_ORDER_MONTH AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYSUCCCOUNT","PAYFAILCOUNT","PAYSUCCAMOUNT","PAYFAILAMOUNT","PAYSUCCNUM","PAYFAILNUM","LOADDATE","DATA_SOURCE" FROM FACT_100138_ORDER_MONTH;

prompt
prompt Creating view V_FACT_100138_ORDER_WEEK
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_ORDER_WEEK AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYSUCCCOUNT","PAYFAILCOUNT","PAYSUCCAMOUNT","PAYFAILAMOUNT","PAYSUCCNUM","PAYFAILNUM","LOADDATE","DATA_SOURCE" FROM FACT_100138_ORDER_WEEK;

prompt
prompt Creating view V_FACT_100138_PAYAMOUNT_DAY
prompt =========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_PAYAMOUNT_DAY AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYAMOUNT","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100138_PAYAMOUNT_DAY;

prompt
prompt Creating view V_FACT_100138_PAYAMOUNT_MONTH
prompt ===========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_PAYAMOUNT_MONTH AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYAMOUNT","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100138_PAYAMOUNT_MONTH;

prompt
prompt Creating view V_FACT_100138_PAYAMOUNT_WEEK
prompt ==========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_PAYAMOUNT_WEEK AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYAMOUNT","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100138_PAYAMOUNT_WEEK;

prompt
prompt Creating view V_FACT_100138_PAYNUM_DAY
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_PAYNUM_DAY AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYNUM","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100138_PAYNUM_DAY;

prompt
prompt Creating view V_FACT_100138_PAYNUM_MONTH
prompt ========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_PAYNUM_MONTH AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYNUM","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100138_PAYNUM_MONTH;

prompt
prompt Creating view V_FACT_100138_PAYNUM_WEEK
prompt =======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_PAYNUM_WEEK AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYNUM","PAYCOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100138_PAYNUM_WEEK;

prompt
prompt Creating view V_FACT_100138_PAYTYPE
prompt ===================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_PAYTYPE AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYTYPEID","PAYAMOUNT","PAYCOUNT","PAYNUM","LOADDATE","DATA_SOURCE" FROM FACT_100138_PAYTYPE;

prompt
prompt Creating view V_FACT_100138_PAYWAY
prompt ==================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_PAYWAY AS
SELECT "STATDATE","CHANNELID","SERVERID","DATATYPE","APPID","VERSIONID","PAYWAYID","PAYAMOUNT","PAYCOUNT","PAYNUM","LOADDATE","DATA_SOURCE" FROM FACT_100138_PAYWAY;

prompt
prompt Creating view V_FACT_100138_QDTG
prompt ================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_QDTG AS
SELECT T2.STATDATE,
       T2.CHANNELID,
       T2.SERVERID,
       T2.APPID,
       T2.NEWCOUNT,
       T3.NEW_REMAIN,
       T1.FIRST_PAYCOUNT
  FROM (SELECT FF.STATDATE,
               FF.CHANNELID,
               FF.SERVERID,
               FF.APPID,
               SUM(FF.FIRST_PAYCOUNT) FIRST_PAYCOUNT
          FROM FACT_100138_FIRSTPAY FF
         WHERE FF.FIRST_PAYFROMREG < 7
           AND FF.DATATYPE = '1'
         GROUP BY FF.STATDATE, FF.CHANNELID, FF.SERVERID, FF.APPID) T1

 RIGHT JOIN (SELECT F.STATDATE,
                    F.CHANNELID,
                    F.SERVERID,
                    F.APPID,
                    SUM(F.NEWCOUNT) NEWCOUNT
               FROM FACT_100138_GENERAL_DAY F
              WHERE F.DATATYPE = '1'
              GROUP BY F.STATDATE, F.CHANNELID, F.SERVERID, F.APPID) T2
    ON T1.STATDATE = T2.STATDATE
   AND T1.CHANNELID = T2.CHANNELID
   AND T1.SERVERID = T2.SERVERID
   AND T1.APPID = T2.APPID
 LEFT JOIN (SELECT * FROM FACT_100138_REMAIN_USER F WHERE F.REMAIN_DAYS = 1) T3

    ON T3.STATDATE = T2.STATDATE
   AND T3.CHANNELID = T2.CHANNELID
   AND T3.SERVERID = T2.SERVERID
   AND T3.APPID = T2.APPID;

prompt
prompt Creating view V_FACT_100138_REGION
prompt ==================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_REGION AS
SELECT "STATDATE","CHANNELID","SERVERID","APPID","VERSIONID","COUNTRY","PROVINCE","CITY","NEWCOUNT","CONNCOUNT","PAYCOUNT","PAYAMOUNT","LOADDATE","DATA_SOURCE" FROM FACT_100138_REGION;

prompt
prompt Creating view V_FACT_100138_REMAIN_MAC
prompt ======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_REMAIN_MAC AS
SELECT FRU.STATDATE,
       FRU.CONNDATE,
       FRU.CHANNELID,
       FRU.SERVERID,
       FRU.APPID,
       FRU.REMAIN_DAYS,
       FGD.NEWCOUNT,
       FGD.CONNCOUNT,
       FGD.PAYCOUNT,
       FRU.NEW_REMAIN,
       FRU.CONN_REMAIN,
       FRU.PAY_REMAIN
  FROM FACT_100138_REMAIN_MAC FRU
  LEFT JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    SUM(T.NEWCOUNT) NEWCOUNT,
                    SUM(T.CONNCOUNT) CONNCOUNT,
                    SUM(T.PAYCOUNT) PAYCOUNT,
                    SUM(T.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100138_GENERAL_DAY T
              WHERE T.DATATYPE = '2'
              GROUP BY T.STATDATE, T.CHANNELID, T.SERVERID, T.APPID) FGD
    ON FRU.STATDATE = FGD.STATDATE
   AND FRU.CHANNELID = FGD.CHANNELID
   AND FRU.SERVERID = FGD.SERVERID
   AND FRU.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100138_REMAIN_USER
prompt =======================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_REMAIN_USER AS
SELECT FRU.STATDATE,
       FRU.CONNDATE,
       FRU.CHANNELID,
       FRU.SERVERID,
       FRU.APPID,
       FRU.REMAIN_DAYS,
       FGD.NEWCOUNT,
       FGD.CONNCOUNT,
       FGD.PAYCOUNT,
       FRU.NEW_REMAIN,
       FRU.CONN_REMAIN,
       FRU.PAY_REMAIN
       FROM
 (SELECT    DISTINCT
       FRU.STATDATE,
       FRU.CONNDATE,
       FRU.CHANNELID,
       FRU.SERVERID,
       FRU.APPID,
       FRU.REMAIN_DAYS,
       FRU.NEW_REMAIN,
       FRU.CONN_REMAIN,
       FRU.PAY_REMAIN
  FROM FACT_100138_REMAIN_USER FRU ) FRU
  LEFT JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    SUM(T.NEWCOUNT) NEWCOUNT,
                    SUM(T.CONNCOUNT) CONNCOUNT,
                    SUM(T.PAYCOUNT) PAYCOUNT,
                    SUM(T.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100138_GENERAL_DAY T
              WHERE T.DATATYPE = '1'
              GROUP BY T.STATDATE, T.CHANNELID, T.SERVERID, T.APPID) FGD
    ON FRU.STATDATE = FGD.STATDATE
   AND FRU.CHANNELID = FGD.CHANNELID
   AND FRU.SERVERID = FGD.SERVERID
   AND FRU.APPID = FGD.APPID;

prompt
prompt Creating view V_FACT_100138_REMAIN_USER_SUN
prompt ===========================================
prompt
CREATE OR REPLACE FORCE VIEW V_FACT_100138_REMAIN_USER_SUN AS
SELECT FRU.STATDATE,
       FRU.CONNDATE,
       FRU.CHANNELID,
       FRU.SERVERID,
       FRU.APPID,
       FRU.REMAIN_DAYS,
       FGD.NEWCOUNT,
       FGD.CONNCOUNT,
       FGD.PAYCOUNT,
       FRU.NEW_REMAIN,
       FRU.CONN_REMAIN,
       FRU.PAY_REMAIN
       FROM
 (SELECT    DISTINCT
       FRU.STATDATE,
       FRU.CONNDATE,
       FRU.CHANNELID,
       FRU.SERVERID,
       FRU.APPID,
       FRU.REMAIN_DAYS,
       FRU.NEW_REMAIN,
       FRU.CONN_REMAIN,
       FRU.PAY_REMAIN
  FROM FACT_100138_REMAIN_USER FRU ) FRU
  LEFT JOIN (SELECT T.STATDATE,
                    T.CHANNELID,
                    T.SERVERID,
                    T.APPID,
                    SUM(T.NEWCOUNT) NEWCOUNT,
                    SUM(T.CONNCOUNT) CONNCOUNT,
                    SUM(T.PAYCOUNT) PAYCOUNT,
                    SUM(T.PAYAMOUNT) PAYAMOUNT
               FROM FACT_100138_GENERAL_DAY T
              WHERE T.DATATYPE = '1'
              GROUP BY T.STATDATE, T.CHANNELID, T.SERVERID, T.APPID) FGD
    ON FRU.STATDATE = FGD.STATDATE
   AND FRU.CHANNELID = FGD.CHANNELID
   AND FRU.SERVERID = FGD.SERVERID
   AND FRU.APPID = FGD.APPID;

prompt
prompt Cr