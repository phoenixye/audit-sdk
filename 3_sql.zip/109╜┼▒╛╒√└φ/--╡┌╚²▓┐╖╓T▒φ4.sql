------------------------------------------------------------
-- Export file for user DEVELOPER@BI_RACDB1_111.13.20.109 --
-- Created by Administrator on 2015/5/26, 16:24:06 ---------
------------------------------------------------------------

set define off
spool --��������T��4.log

prompt
prompt Creating table T_100174_NU_MAC_ALLSERVER
prompt ========================================
prompt
create table T_100174_NU_MAC_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100174_NU_MAC_ALLSERVER
  is '�豸������ALLSERVER';
comment on column T_100174_NU_MAC_ALLSERVER.thedate
  is '����ʱ��';
comment on column T_100174_NU_MAC_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100174_NU_MAC_ALLSERVER.channelid
  is '����ID';
comment on column T_100174_NU_MAC_ALLSERVER.gameversion
  is '��Ϸ�汾';
comment on column T_100174_NU_MAC_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100174_NU_MAC_ALLSERVER.position
  is 'λ����Ϣ';
comment on column T_100174_NU_MAC_ALLSERVER.dvid
  is '�豸ID';
create index IDX196_100174 on T_100174_NU_MAC_ALLSERVER (CHANNELID);
create index IDX197_100174 on T_100174_NU_MAC_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100174_NU_PAY
prompt ==============================
prompt
create table T_100174_NU_PAY
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100174_NU_PAY
  is '�����û���';
comment on column T_100174_NU_PAY.thedate
  is '����ʱ��';
comment on column T_100174_NU_PAY.gameid
  is '��ϷID';
comment on column T_100174_NU_PAY.channelid
  is '����ID';
comment on column T_100174_NU_PAY.gameversion
  is '��Ϸ�汾';
comment on column T_100174_NU_PAY.serverid
  is '������Ϣ';
comment on column T_100174_NU_PAY.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100174_NU_PAY.position
  is 'λ����Ϣ';
comment on column T_100174_NU_PAY.accountid
  is '�˺�ID';
comment on column T_100174_NU_PAY.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100174_NU_PAY.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX151_100174 on T_100174_NU_PAY (CHANNELID);
create index IDX152_100174 on T_100174_NU_PAY (SERVERID);
create index IDX153_100174 on T_100174_NU_PAY (THEDATE);

prompt
prompt Creating table T_100174_NU_PAY_AS
prompt =================================
prompt
create table T_100174_NU_PAY_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100174_NU_PAY_AS
  is '�����û���allsever';
comment on column T_100174_NU_PAY_AS.thedate
  is '����ʱ��';
comment on column T_100174_NU_PAY_AS.gameid
  is '��ϷID';
comment on column T_100174_NU_PAY_AS.channelid
  is '����ID';
comment on column T_100174_NU_PAY_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100174_NU_PAY_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100174_NU_PAY_AS.position
  is 'λ����Ϣ';
comment on column T_100174_NU_PAY_AS.accountid
  is '�˺�ID';
comment on column T_100174_NU_PAY_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100174_NU_PAY_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX198_100174 on T_100174_NU_PAY_AS (CHANNELID);
create index IDX199_100174 on T_100174_NU_PAY_AS (THEDATE);

prompt
prompt Creating table T_100174_NU_PAY_MAC
prompt ==================================
prompt
create table T_100174_NU_PAY_MAC
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100174_NU_PAY_MAC
  is '�����û���';
comment on column T_100174_NU_PAY_MAC.thedate
  is '����ʱ��';
comment on column T_100174_NU_PAY_MAC.gameid
  is '��ϷID';
comment on column T_100174_NU_PAY_MAC.channelid
  is '����ID';
comment on column T_100174_NU_PAY_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100174_NU_PAY_MAC.serverid
  is '������Ϣ';
comment on column T_100174_NU_PAY_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100174_NU_PAY_MAC.position
  is 'λ����Ϣ';
comment on column T_100174_NU_PAY_MAC.dvid
  is '�豸ID';
comment on column T_100174_NU_PAY_MAC.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100174_NU_PAY_MAC.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX154_100174 on T_100174_NU_PAY_MAC (CHANNELID);
create index IDX155_100174 on T_100174_NU_PAY_MAC (SERVERID);
create index IDX156_100174 on T_100174_NU_PAY_MAC (THEDATE);

prompt
prompt Creating table T_100174_NU_PAY_MAC_AS
prompt =====================================
prompt
create table T_100174_NU_PAY_MAC_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100174_NU_PAY_MAC_AS
  is '�����û���ALLSERVER';
comment on column T_100174_NU_PAY_MAC_AS.thedate
  is '����ʱ��';
comment on column T_100174_NU_PAY_MAC_AS.gameid
  is '��ϷID';
comment on column T_100174_NU_PAY_MAC_AS.channelid
  is '����ID';
comment on column T_100174_NU_PAY_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100174_NU_PAY_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100174_NU_PAY_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100174_NU_PAY_MAC_AS.dvid
  is '�豸ID';
comment on column T_100174_NU_PAY_MAC_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100174_NU_PAY_MAC_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX200_100174 on T_100174_NU_PAY_MAC_AS (CHANNELID);
create index IDX201_100174 on T_100174_NU_PAY_MAC_AS (THEDATE);

prompt
prompt Creating table T_100174_ORDER_FAILURE
prompt =====================================
prompt
create table T_100174_ORDER_FAILURE
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100174_ORDER_FAILURE
  is '��ֵ�ɹ���¼��';
comment on column T_100174_ORDER_FAILURE.thedate
  is '��ֵʱ��';
comment on column T_100174_ORDER_FAILURE.gameid
  is '��ϷID';
comment on column T_100174_ORDER_FAILURE.channelid
  is '����ID';
comment on column T_100174_ORDER_FAILURE.gameversion
  is '��Ϸ�汾';
comment on column T_100174_ORDER_FAILURE.serverid
  is '��������';
comment on column T_100174_ORDER_FAILURE.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100174_ORDER_FAILURE.position
  is 'λ����Ϣ';
comment on column T_100174_ORDER_FAILURE.dvid
  is '�豸��';
comment on column T_100174_ORDER_FAILURE.accountid
  is '�˺�';
comment on column T_100174_ORDER_FAILURE.money
  is '��ֵ���';
comment on column T_100174_ORDER_FAILURE.vc
  is '��ֵ��õ����������';
comment on column T_100174_ORDER_FAILURE.orderid
  is '������';
comment on column T_100174_ORDER_FAILURE.paychannel
  is '֧������';
comment on column T_100174_ORDER_FAILURE.iapid
  is '��ֵ����  30  60';
create index IDX157_100174 on T_100174_ORDER_FAILURE (CHANNELID);
create index IDX158_100174 on T_100174_ORDER_FAILURE (SERVERID);
create index IDX159_100174 on T_100174_ORDER_FAILURE (THEDATE);

prompt
prompt Creating table T_100174_ORDER_SUCC
prompt ==================================
prompt
create table T_100174_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100174_ORDER_SUCC
  is '��ֵ�ɹ���¼��';
comment on column T_100174_ORDER_SUCC.thedate
  is '��ֵʱ��';
comment on column T_100174_ORDER_SUCC.gameid
  is '��ϷID';
comment on column T_100174_ORDER_SUCC.channelid
  is '����ID';
comment on column T_100174_ORDER_SUCC.gameversion
  is '��Ϸ�汾';
comment on column T_100174_ORDER_SUCC.serverid
  is '��������';
comment on column T_100174_ORDER_SUCC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100174_ORDER_SUCC.position
  is 'λ����Ϣ';
comment on column T_100174_ORDER_SUCC.dvid
  is '�豸��';
comment on column T_100174_ORDER_SUCC.accountid
  is '�˺�';
comment on column T_100174_ORDER_SUCC.money
  is '��ֵ���';
comment on column T_100174_ORDER_SUCC.vc
  is '��ֵ��õ����������';
comment on column T_100174_ORDER_SUCC.orderid
  is '������';
comment on column T_100174_ORDER_SUCC.paychannel
  is '֧������';
comment on column T_100174_ORDER_SUCC.iapid
  is '��ֵ����  30  60';
create index IDX160_100174 on T_100174_ORDER_SUCC (CHANNELID);
create index IDX161_100174 on T_100174_ORDER_SUCC (SERVERID);
create index IDX162_100174 on T_100174_ORDER_SUCC (THEDATE);

prompt
prompt Creating table T_100174_VC
prompt ==========================
prompt
create table T_100174_VC
(
  statdate    DATE,
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcchange    NUMBER,
  vcbefore    NUMBER,
  vcafter     NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100174_VC
  is '������ұ仯������';
comment on column T_100174_VC.statdate
  is 'ͳ������';
comment on column T_100174_VC.channelid
  is '����';
comment on column T_100174_VC.serverid
  is '����';
comment on column T_100174_VC.appid
  is '��Ʒid';
comment on column T_100174_VC.versionid
  is '��Ʒ�汾';
comment on column T_100174_VC.accountid
  is '�û�ID';
comment on column T_100174_VC.vctype
  is '�����������';
comment on column T_100174_VC.vcusetype
  is '�������ʹ������';
comment on column T_100174_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column T_100174_VC.vcchange
  is '������ұ仯���';
comment on column T_100174_VC.vcbefore
  is '������ұ仯ǰ���';
comment on column T_100174_VC.vcafter
  is '������ұ仯����';
comment on column T_100174_VC.data_source
  is '������Դ';
create index IDX163_100174 on T_100174_VC (CHANNELID);
create index IDX164_100174 on T_100174_VC (SERVERID);
create index IDX165_100174 on T_100174_VC (STATDATE);

prompt
prompt Creating table T_100176_CEVENT
prompt ==============================
prompt
create table T_100176_CEVENT
(
  thedate          VARCHAR2(10),
  datenum          NUMBER,
  appid            VARCHAR2(10),
  channelid        VARCHAR2(50),
  gameversion      VARCHAR2(50),
  dvid             VARCHAR2(50),
  accountid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  ilevel           NUMBER,
  roleid           VARCHAR2(50),
  eventkey         VARCHAR2(100),
  eventvalue_key   VARCHAR2(100),
  eventvalue_value VARCHAR2(100),
  ipaddr           VARCHAR2(50),
  prerowid         VARCHAR2(200)
)
;
comment on table T_100176_CEVENT
  is '�Զ����¼���ֱ�';
comment on column T_100176_CEVENT.thedate
  is '����';
comment on column T_100176_CEVENT.datenum
  is '�������ָ�ʽ';
comment on column T_100176_CEVENT.appid
  is '��Ϸ�� appid';
comment on column T_100176_CEVENT.channelid
  is '���� ID';
comment on column T_100176_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column T_100176_CEVENT.dvid
  is '�豸 ID��Ψһ�豸��';
comment on column T_100176_CEVENT.accountid
  is '�ʻ� id';
comment on column T_100176_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column T_100176_CEVENT.ilevel
  is '��ҵȼ�';
comment on column T_100176_CEVENT.roleid
  is '��ɫ id';
comment on column T_100176_CEVENT.eventkey
  is '�¼�����';
comment on column T_100176_CEVENT.eventvalue_key
  is '�¼�ֵ�е�key';
comment on column T_100176_CEVENT.eventvalue_value
  is '�¼�ֵ��key��Ӧ��ֵ';
comment on column T_100176_CEVENT.ipaddr
  is 'ip ��ַ';
comment on column T_100176_CEVENT.prerowid
  is 'ԭΨһ��ID';
create index IDX180_100176 on T_100176_CEVENT (THEDATE);

prompt
prompt Creating table T_100176_CONN
prompt ============================
prompt
create table T_100176_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100176_CONN
  is '����&��ʧ&������������������ע���˺ţ�ע���豸��';
comment on column T_100176_CONN.conndate
  is '����ʱ��';
comment on column T_100176_CONN.gameid
  is '��ϷID';
comment on column T_100176_CONN.channelid
  is '����ID';
comment on column T_100176_CONN.gameversion
  is '��Ϸ�汾';
comment on column T_100176_CONN.serverid
  is '����ID';
comment on column T_100176_CONN.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100176_CONN.position
  is 'λ����Ϣ';
comment on column T_100176_CONN.dvid
  is '�豸��';
comment on column T_100176_CONN.accountid
  is '�˺�ID';
comment on column T_100176_CONN.regdate
  is 'ע��ʱ��';
comment on column T_100176_CONN.ispay
  is '�Ƿ��Ǹ����û�';
create index IDX118_100176 on T_100176_CONN (CHANNELID);
create index IDX119_100176 on T_100176_CONN (SERVERID);
create index IDX120_100176 on T_100176_CONN (CONNDATE);

prompt
prompt Creating table T_100176_CONN_ACT
prompt ================================
prompt
create table T_100176_CONN_ACT
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100176_CONN_ACT
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100176_CONN_ACT.basedate
  is '����ʱ��';
comment on column T_100176_CONN_ACT.gameid
  is '��ϷID';
comment on column T_100176_CONN_ACT.channelid
  is '����ID';
comment on column T_100176_CONN_ACT.gameversion
  is '��Ϸ�汾';
comment on column T_100176_CONN_ACT.serverid
  is '����ID';
comment on column T_100176_CONN_ACT.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100176_CONN_ACT.position
  is 'λ����Ϣ';
comment on column T_100176_CONN_ACT.dvid
  is '�豸��';
comment on column T_100176_CONN_ACT.accountid
  is '�˺�';
comment on column T_100176_CONN_ACT.conndate
  is '��Ծʱ��';
comment on column T_100176_CONN_ACT.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_100176 on T_100176_CONN_ACT (CHANNELID);
create index IDX122_100176 on T_100176_CONN_ACT (SERVERID);
create index IDX123_100176 on T_100176_CONN_ACT (CONNDATE);
create index IDX124_100176 on T_100176_CONN_ACT (BASEDATE);

prompt
prompt Creating table T_100176_CONN_ACT_MAC
prompt ====================================
prompt
create table T_100176_CONN_ACT_MAC
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100176_CONN_ACT_MAC
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100176_CONN_ACT_MAC.basedate
  is '����ʱ��';
comment on column T_100176_CONN_ACT_MAC.gameid
  is '��ϷID';
comment on column T_100176_CONN_ACT_MAC.channelid
  is '����ID';
comment on column T_100176_CONN_ACT_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100176_CONN_ACT_MAC.serverid
  is '����ID';
comment on column T_100176_CONN_ACT_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100176_CONN_ACT_MAC.position
  is 'λ����Ϣ';
comment on column T_100176_CONN_ACT_MAC.dvid
  is '�豸��';
comment on column T_100176_CONN_ACT_MAC.accountid
  is '�˺�';
comment on column T_100176_CONN_ACT_MAC.conndate
  is '��Ծʱ��';
comment on column T_100176_CONN_ACT_MAC.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_100176 on T_100176_CONN_ACT_MAC (CHANNELID);
create index IDX126_100176 on T_100176_CONN_ACT_MAC (SERVERID);
create index IDX127_100176 on T_100176_CONN_ACT_MAC (CONNDATE);
create index IDX128_100176 on T_100176_CONN_ACT_MAC (BASEDATE);

prompt
prompt Creating table T_100176_CONN_DVID
prompt =================================
prompt
create table T_100176_CONN_DVID
(
  conndate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  dvid      VARCHAR2(50),
  regdate   VARCHAR2(10)
)
;
comment on table T_100176_CONN_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100176_CONN_DVID.conndate
  is '����ʱ��';
comment on column T_100176_CONN_DVID.gameid
  is '��ϷID';
comment on column T_100176_CONN_DVID.channelid
  is '����ID';
comment on column T_100176_CONN_DVID.dvid
  is '�豸��';
comment on column T_100176_CONN_DVID.regdate
  is 'ע��ʱ��';
create index IDX129_100176 on T_100176_CONN_DVID (CHANNELID);
create index IDX130_100176 on T_100176_CONN_DVID (CONNDATE);

prompt
prompt Creating table T_100176_CONN_MAC
prompt ================================
prompt
create table T_100176_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100176_CONN_MAC
  is '���� ��ʧ ������������������ע���˺ţ�ע���豸��';
comment on column T_100176_CONN_MAC.conndate
  is '����ʱ��';
comment on column T_100176_CONN_MAC.gameid
  is '��ϷID';
comment on column T_100176_CONN_MAC.channelid
  is '����ID';
comment on column T_100176_CONN_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100176_CONN_MAC.serverid
  is '����ID';
comment on column T_100176_CONN_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100176_CONN_MAC.position
  is 'λ����Ϣ';
comment on column T_100176_CONN_MAC.dvid
  is '�豸��';
comment on column T_100176_CONN_MAC.accountid
  is '�˺�ID';
comment on column T_100176_CONN_MAC.regdate
  is 'ע��ʱ��';
comment on column T_100176_CONN_MAC.ispay
  is '�Ƿ��Ǹ����û�';
create index IDX131_100176 on T_100176_CONN_MAC (CHANNELID);
create index IDX132_100176 on T_100176_CONN_MAC (SERVERID);
create index IDX133_100176 on T_100176_CONN_MAC (CONNDATE);

prompt
prompt Creating table T_100176_LOST_MAC
prompt ================================
prompt
create table T_100176_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100176_LOST_MAC
  is '�豸�ȼ���ʧ������';
comment on column T_100176_LOST_MAC.statdate
  is '�����������';
comment on column T_100176_LOST_MAC.lost_date
  is '��ʧ����';
comment on column T_100176_LOST_MAC.channelid
  is '����';
comment on column T_100176_LOST_MAC.serverid
  is '����';
comment on column T_100176_LOST_MAC.appid
  is '��Ʒid';
comment on column T_100176_LOST_MAC.macid
  is '�豸id';
comment on column T_100176_LOST_MAC.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100176_LOST_MAC.lost_days
  is '��ʧ����';
comment on column T_100176_LOST_MAC.data_source
  is '������Դ';
create index IDX134_100176 on T_100176_LOST_MAC (CHANNELID);
create index IDX135_100176 on T_100176_LOST_MAC (SERVERID);
create index IDX136_100176 on T_100176_LOST_MAC (STATDATE);

prompt
prompt Creating table T_100176_LOST_USER
prompt =================================
prompt
create table T_100176_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100176_LOST_USER
  is '�û��ȼ���ʧ������';
comment on column T_100176_LOST_USER.statdate
  is '�����������';
comment on column T_100176_LOST_USER.lost_date
  is '��ʧ����';
comment on column T_100176_LOST_USER.channelid
  is '����';
comment on column T_100176_LOST_USER.serverid
  is '����';
comment on column T_100176_LOST_USER.appid
  is '��Ʒid';
comment on column T_100176_LOST_USER.userid
  is '�û�id';
comment on column T_100176_LOST_USER.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100176_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100176_LOST_USER.lost_days
  is '��ʧ����';
comment on column T_100176_LOST_USER.data_source
  is '������Դ';
create index IDX137_100176 on T_100176_LOST_USER (CHANNELID);
create index IDX138_100176 on T_100176_LOST_USER (SERVERID);
create index IDX139_100176 on T_100176_LOST_USER (STATDATE);

prompt
prompt Creating table T_100176_MISS_FIRST
prompt ==================================
prompt
create table T_100176_MISS_FIRST
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50) default '0',
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100176_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column T_100176_MISS_FIRST.statdate
  is 'ͳ������';
comment on column T_100176_MISS_FIRST.channelid
  is '����';
comment on column T_100176_MISS_FIRST.serverid
  is '����';
comment on column T_100176_MISS_FIRST.appid
  is '��ƷID';
comment on column T_100176_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column T_100176_MISS_FIRST.accountid
  is '�û�ID';
comment on column T_100176_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100176_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column T_100176_MISS_FIRST.issucc
  is '�Ƿ���ͨ��';
comment on column T_100176_MISS_FIRST.data_source
  is '������Դ';
create index IDX140_100176 on T_100176_MISS_FIRST (CHANNELID);
create index IDX141_100176 on T_100176_MISS_FIRST (SERVERID);
create index IDX142_100176 on T_100176_MISS_FIRST (STATDATE);

prompt
prompt Creating table T_100176_NU
prompt ==========================
prompt
create table T_100176_NU
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100176_NU
  is '�����û���Ϣ��';
comment on column T_100176_NU.thedate
  is '��������';
comment on column T_100176_NU.gameid
  is '��ϷID';
comment on column T_100176_NU.channelid
  is '����ID';
comment on column T_100176_NU.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100176_NU.serverid
  is '���ڷ�ID';
comment on column T_100176_NU.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100176_NU.position
  is '����λ��';
comment on column T_100176_NU.accountid
  is '�˺�ID';
create index IDX143_100176 on T_100176_NU (CHANNELID);
create index IDX144_100176 on T_100176_NU (SERVERID);
create index IDX145_100176 on T_100176_NU (THEDATE);

prompt
prompt Creating table T_100176_NU_DVID
prompt ===============================
prompt
create table T_100176_NU_DVID
(
  thedate   DATE not null,
  gameid    VARCHAR2(20) not null,
  channelid VARCHAR2(20) not null,
  dvid      VARCHAR2(50) not null,
  ipaddr    VARCHAR2(50)
)
;
comment on table T_100176_NU_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100176_NU_DVID.thedate
  is '����ʱ��';
comment on column T_100176_NU_DVID.gameid
  is '��ϷID';
comment on column T_100176_NU_DVID.channelid
  is '����ID';
comment on column T_100176_NU_DVID.dvid
  is '�豸ID';
comment on column T_100176_NU_DVID.ipaddr
  is 'IP';
create index IDX146_100176 on T_100176_NU_DVID (CHANNELID);
create index IDX147_100176 on T_100176_NU_DVID (THEDATE);

prompt
prompt Creating table T_100176_NU_MAC
prompt ==============================
prompt
create table T_100176_NU_MAC
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100176_NU_MAC
  is '�豸������';
comment on column T_100176_NU_MAC.thedate
  is '����ʱ��';
comment on column T_100176_NU_MAC.gameid
  is '��ϷID';
comment on column T_100176_NU_MAC.channelid
  is '����ID';
comment on column T_100176_NU_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100176_NU_MAC.serverid
  is '��������ID';
comment on column T_100176_NU_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100176_NU_MAC.position
  is 'λ����Ϣ';
comment on column T_100176_NU_MAC.dvid
  is '�豸ID';
create index IDX148_100176 on T_100176_NU_MAC (CHANNELID);
create index IDX149_100176 on T_100176_NU_MAC (SERVERID);
create index IDX150_100176 on T_100176_NU_MAC (THEDATE);

prompt
prompt Creating table T_100176_NU_PAY
prompt ==============================
prompt
create table T_100176_NU_PAY
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100176_NU_PAY
  is '�����û���';
comment on column T_100176_NU_PAY.thedate
  is '����ʱ��';
comment on column T_100176_NU_PAY.gameid
  is '��ϷID';
comment on column T_100176_NU_PAY.channelid
  is '����ID';
comment on column T_100176_NU_PAY.gameversion
  is '��Ϸ�汾';
comment on column T_100176_NU_PAY.serverid
  is '������Ϣ';
comment on column T_100176_NU_PAY.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100176_NU_PAY.position
  is 'λ����Ϣ';
comment on column T_100176_NU_PAY.accountid
  is '�˺�ID';
comment on column T_100176_NU_PAY.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100176_NU_PAY.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX151_100176 on T_100176_NU_PAY (CHANNELID);
create index IDX152_100176 on T_100176_NU_PAY (SERVERID);
create index IDX153_100176 on T_100176_NU_PAY (THEDATE);

prompt
prompt Creating table T_100176_NU_PAY_MAC
prompt ==================================
prompt
create table T_100176_NU_PAY_MAC
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100176_NU_PAY_MAC
  is '�����û���';
comment on column T_100176_NU_PAY_MAC.thedate
  is '����ʱ��';
comment on column T_100176_NU_PAY_MAC.gameid
  is '��ϷID';
comment on column T_100176_NU_PAY_MAC.channelid
  is '����ID';
comment on column T_100176_NU_PAY_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100176_NU_PAY_MAC.serverid
  is '������Ϣ';
comment on column T_100176_NU_PAY_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100176_NU_PAY_MAC.position
  is 'λ����Ϣ';
comment on column T_100176_NU_PAY_MAC.dvid
  is '�豸ID';
comment on column T_100176_NU_PAY_MAC.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100176_NU_PAY_MAC.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX154_100176 on T_100176_NU_PAY_MAC (CHANNELID);
create index IDX155_100176 on T_100176_NU_PAY_MAC (SERVERID);
create index IDX156_100176 on T_100176_NU_PAY_MAC (THEDATE);

prompt
prompt Creating table T_100176_ORDER_FAILURE
prompt =====================================
prompt
create table T_100176_ORDER_FAILURE
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100176_ORDER_FAILURE
  is '��ֵ�ɹ���¼��';
comment on column T_100176_ORDER_FAILURE.thedate
  is '��ֵʱ��';
comment on column T_100176_ORDER_FAILURE.gameid
  is '��ϷID';
comment on column T_100176_ORDER_FAILURE.channelid
  is '����ID';
comment on column T_100176_ORDER_FAILURE.gameversion
  is '��Ϸ�汾';
comment on column T_100176_ORDER_FAILURE.serverid
  is '��������';
comment on column T_100176_ORDER_FAILURE.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100176_ORDER_FAILURE.position
  is 'λ����Ϣ';
comment on column T_100176_ORDER_FAILURE.dvid
  is '�豸��';
comment on column T_100176_ORDER_FAILURE.accountid
  is '�˺�';
comment on column T_100176_ORDER_FAILURE.money
  is '��ֵ���';
comment on column T_100176_ORDER_FAILURE.vc
  is '��ֵ��õ����������';
comment on column T_100176_ORDER_FAILURE.orderid
  is '������';
comment on column T_100176_ORDER_FAILURE.paychannel
  is '֧������';
comment on column T_100176_ORDER_FAILURE.iapid
  is '��ֵ����  30  60';
create index IDX157_100176 on T_100176_ORDER_FAILURE (CHANNELID);
create index IDX158_100176 on T_100176_ORDER_FAILURE (SERVERID);
create index IDX159_100176 on T_100176_ORDER_FAILURE (THEDATE);

prompt
prompt Creating table T_100176_ORDER_SUCC
prompt ==================================
prompt
create table T_100176_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100176_ORDER_SUCC
  is '��ֵ�ɹ���¼��';
comment on column T_100176_ORDER_SUCC.thedate
  is '��ֵʱ��';
comment on column T_100176_ORDER_SUCC.gameid
  is '��ϷID';
comment on column T_100176_ORDER_SUCC.channelid
  is '����ID';
comment on column T_100176_ORDER_SUCC.gameversion
  is '��Ϸ�汾';
comment on column T_100176_ORDER_SUCC.serverid
  is '��������';
comment on column T_100176_ORDER_SUCC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100176_ORDER_SUCC.position
  is 'λ����Ϣ';
comment on column T_100176_ORDER_SUCC.dvid
  is '�豸��';
comment on column T_100176_ORDER_SUCC.accountid
  is '�˺�';
comment on column T_100176_ORDER_SUCC.money
  is '��ֵ���';
comment on column T_100176_ORDER_SUCC.vc
  is '��ֵ��õ����������';
comment on column T_100176_ORDER_SUCC.orderid
  is '������';
comment on column T_100176_ORDER_SUCC.paychannel
  is '֧������';
comment on column T_100176_ORDER_SUCC.iapid
  is '��ֵ����  30  60';
create index IDX160_100176 on T_100176_ORDER_SUCC (CHANNELID);
create index IDX161_100176 on T_100176_ORDER_SUCC (SERVERID);
create index IDX162_100176 on T_100176_ORDER_SUCC (THEDATE);

prompt
prompt Creating table T_100176_VC
prompt ==========================
prompt
create table T_100176_VC
(
  statdate    DATE,
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcchange    NUMBER,
  vcbefore    NUMBER,
  vcafter     NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100176_VC
  is '������ұ仯������';
comment on column T_100176_VC.statdate
  is 'ͳ������';
comment on column T_100176_VC.channelid
  is '����';
comment on column T_100176_VC.serverid
  is '����';
comment on column T_100176_VC.appid
  is '��Ʒid';
comment on column T_100176_VC.versionid
  is '��Ʒ�汾';
comment on column T_100176_VC.accountid
  is '�û�ID';
comment on column T_100176_VC.vctype
  is '�����������';
comment on column T_100176_VC.vcusetype
  is '�������ʹ������';
comment on column T_100176_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column T_100176_VC.vcchange
  is '������ұ仯���';
comment on column T_100176_VC.vcbefore
  is '������ұ仯ǰ���';
comment on column T_100176_VC.vcafter
  is '������ұ仯����';
comment on column T_100176_VC.data_source
  is '������Դ';
create index IDX163_100176 on T_100176_VC (CHANNELID);
create index IDX164_100176 on T_100176_VC (SERVERID);
create index IDX165_100176 on T_100176_VC (STATDATE);

prompt
prompt Creating table T_100177_CEVENT
prompt ==============================
prompt
create table T_100177_CEVENT
(
  thedate          VARCHAR2(10),
  datenum          NUMBER,
  appid            VARCHAR2(10),
  channelid        VARCHAR2(50),
  gameversion      VARCHAR2(50),
  dvid             VARCHAR2(50),
  accountid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  ilevel           NUMBER,
  roleid           VARCHAR2(50),
  eventkey         VARCHAR2(100),
  eventvalue_key   VARCHAR2(100),
  eventvalue_value VARCHAR2(100),
  ipaddr           VARCHAR2(50),
  prerowid         VARCHAR2(200)
)
;
comment on table T_100177_CEVENT
  is '�Զ����¼���ֱ�';
comment on column T_100177_CEVENT.thedate
  is '����';
comment on column T_100177_CEVENT.datenum
  is '�������ָ�ʽ';
comment on column T_100177_CEVENT.appid
  is '��Ϸ�� appid';
comment on column T_100177_CEVENT.channelid
  is '���� ID';
comment on column T_100177_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column T_100177_CEVENT.dvid
  is '�豸 ID��Ψһ�豸��';
comment on column T_100177_CEVENT.accountid
  is '�ʻ� id';
comment on column T_100177_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column T_100177_CEVENT.ilevel
  is '��ҵȼ�';
comment on column T_100177_CEVENT.roleid
  is '��ɫ id';
comment on column T_100177_CEVENT.eventkey
  is '�¼�����';
comment on column T_100177_CEVENT.eventvalue_key
  is '�¼�ֵ�е�key';
comment on column T_100177_CEVENT.eventvalue_value
  is '�¼�ֵ��key��Ӧ��ֵ';
comment on column T_100177_CEVENT.ipaddr
  is 'ip ��ַ';
comment on column T_100177_CEVENT.prerowid
  is 'ԭΨһ��ID';
create index IDX180_100177 on T_100177_CEVENT (THEDATE);

prompt
prompt Creating table T_100177_CONN
prompt ============================
prompt
create table T_100177_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100177_CONN
  is '����&��ʧ&������������������ע���˺ţ�ע���豸��';
comment on column T_100177_CONN.conndate
  is '����ʱ��';
comment on column T_100177_CONN.gameid
  is '��ϷID';
comment on column T_100177_CONN.channelid
  is '����ID';
comment on column T_100177_CONN.gameversion
  is '��Ϸ�汾';
comment on column T_100177_CONN.serverid
  is '����ID';
comment on column T_100177_CONN.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100177_CONN.position
  is 'λ����Ϣ';
comment on column T_100177_CONN.dvid
  is '�豸��';
comment on column T_100177_CONN.accountid
  is '�˺�ID';
comment on column T_100177_CONN.regdate
  is 'ע��ʱ��';
comment on column T_100177_CONN.ispay
  is '�Ƿ��Ǹ����û�';
create index IDX118_100177 on T_100177_CONN (CHANNELID);
create index IDX119_100177 on T_100177_CONN (SERVERID);
create index IDX120_100177 on T_100177_CONN (CONNDATE);

prompt
prompt Creating table T_100177_CONN_ACT
prompt ================================
prompt
create table T_100177_CONN_ACT
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100177_CONN_ACT
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100177_CONN_ACT.basedate
  is '����ʱ��';
comment on column T_100177_CONN_ACT.gameid
  is '��ϷID';
comment on column T_100177_CONN_ACT.channelid
  is '����ID';
comment on column T_100177_CONN_ACT.gameversion
  is '��Ϸ�汾';
comment on column T_100177_CONN_ACT.serverid
  is '����ID';
comment on column T_100177_CONN_ACT.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100177_CONN_ACT.position
  is 'λ����Ϣ';
comment on column T_100177_CONN_ACT.dvid
  is '�豸��';
comment on column T_100177_CONN_ACT.accountid
  is '�˺�';
comment on column T_100177_CONN_ACT.conndate
  is '��Ծʱ��';
comment on column T_100177_CONN_ACT.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_100177 on T_100177_CONN_ACT (CHANNELID);
create index IDX122_100177 on T_100177_CONN_ACT (SERVERID);
create index IDX123_100177 on T_100177_CONN_ACT (CONNDATE);
create index IDX124_100177 on T_100177_CONN_ACT (BASEDATE);

prompt
prompt Creating table T_100177_CONN_ACT_DVID
prompt =====================================
prompt
create table T_100177_CONN_ACT_DVID
(
  basedate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  ipaddr    VARCHAR2(50),
  dvid      VARCHAR2(50),
  conndate  VARCHAR2(10),
  ispay     VARCHAR2(10)
)
;

prompt
prompt Creating table T_100177_CONN_ACT_MAC
prompt ====================================
prompt
create table T_100177_CONN_ACT_MAC
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100177_CONN_ACT_MAC
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100177_CONN_ACT_MAC.basedate
  is '����ʱ��';
comment on column T_100177_CONN_ACT_MAC.gameid
  is '��ϷID';
comment on column T_100177_CONN_ACT_MAC.channelid
  is '����ID';
comment on column T_100177_CONN_ACT_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100177_CONN_ACT_MAC.serverid
  is '����ID';
comment on column T_100177_CONN_ACT_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100177_CONN_ACT_MAC.position
  is 'λ����Ϣ';
comment on column T_100177_CONN_ACT_MAC.dvid
  is '�豸��';
comment on column T_100177_CONN_ACT_MAC.accountid
  is '�˺�';
comment on column T_100177_CONN_ACT_MAC.conndate
  is '��Ծʱ��';
comment on column T_100177_CONN_ACT_MAC.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_100177 on T_100177_CONN_ACT_MAC (CHANNELID);
create index IDX126_100177 on T_100177_CONN_ACT_MAC (SERVERID);
create index IDX127_100177 on T_100177_CONN_ACT_MAC (CONNDATE);
create index IDX128_100177 on T_100177_CONN_ACT_MAC (BASEDATE);

prompt
prompt Creating table T_100177_CONN_DVID
prompt =================================
prompt
create table T_100177_CONN_DVID
(
  conndate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  dvid      VARCHAR2(50),
  regdate   VARCHAR2(10),
  ipaddr    VARCHAR2(50),
  ispay     VARCHAR2(10)
)
;
comment on table T_100177_CONN_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100177_CONN_DVID.conndate
  is '����ʱ��';
comment on column T_100177_CONN_DVID.gameid
  is '��ϷID';
comment on column T_100177_CONN_DVID.channelid
  is '����ID';
comment on column T_100177_CONN_DVID.dvid
  is '�豸��';
comment on column T_100177_CONN_DVID.regdate
  is 'ע��ʱ��';
comment on column T_100177_CONN_DVID.ipaddr
  is 'IP';
comment on column T_100177_CONN_DVID.ispay
  is '�Ƿ񸶷�';
create index IDX129_100177 on T_100177_CONN_DVID (CHANNELID);
create index IDX130_100177 on T_100177_CONN_DVID (CONNDATE);

prompt
prompt Creating table T_100177_CONN_MAC
prompt ================================
prompt
create table T_100177_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100177_CONN_MAC
  is '���� ��ʧ ������������������ע���˺ţ�ע���豸��';
comment on column T_100177_CONN_MAC.conndate
  is '����ʱ��';
comment on column T_100177_CONN_MAC.gameid
  is '��ϷID';
comment on column T_100177_CONN_MAC.channelid
  is '����ID';
comment on column T_100177_CONN_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100177_CONN_MAC.serverid
  is '����ID';
comment on column T_100177_CONN_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100177_CONN_MAC.position
  is 'λ����Ϣ';
comment on column T_100177_CONN_MAC.dvid
  is '�豸��';
comment on column T_100177_CONN_MAC.accountid
  is '�˺�ID';
comment on column T_100177_CONN_MAC.regdate
  is 'ע��ʱ��';
comment on column T_100177_CONN_MAC.ispay
  is '�Ƿ��Ǹ����û�';
create index IDX131_100177 on T_100177_CONN_MAC (CHANNELID);
create index IDX132_100177 on T_100177_CONN_MAC (SERVERID);
create index IDX133_100177 on T_100177_CONN_MAC (CONNDATE);

prompt
prompt Creating table T_100177_LOST_MAC
prompt ================================
prompt
create table T_100177_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100177_LOST_MAC
  is '�豸�ȼ���ʧ������';
comment on column T_100177_LOST_MAC.statdate
  is '�����������';
comment on column T_100177_LOST_MAC.lost_date
  is '��ʧ����';
comment on column T_100177_LOST_MAC.channelid
  is '����';
comment on column T_100177_LOST_MAC.serverid
  is '����';
comment on column T_100177_LOST_MAC.appid
  is '��Ʒid';
comment on column T_100177_LOST_MAC.macid
  is '�豸id';
comment on column T_100177_LOST_MAC.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100177_LOST_MAC.lost_days
  is '��ʧ����';
comment on column T_100177_LOST_MAC.data_source
  is '������Դ';
create index IDX134_100177 on T_100177_LOST_MAC (CHANNELID);
create index IDX135_100177 on T_100177_LOST_MAC (SERVERID);
create index IDX136_100177 on T_100177_LOST_MAC (STATDATE);

prompt
prompt Creating table T_100177_LOST_USER
prompt =================================
prompt
create table T_100177_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100177_LOST_USER
  is '�û��ȼ���ʧ������';
comment on column T_100177_LOST_USER.statdate
  is '�����������';
comment on column T_100177_LOST_USER.lost_date
  is '��ʧ����';
comment on column T_100177_LOST_USER.channelid
  is '����';
comment on column T_100177_LOST_USER.serverid
  is '����';
comment on column T_100177_LOST_USER.appid
  is '��Ʒid';
comment on column T_100177_LOST_USER.userid
  is '�û�id';
comment on column T_100177_LOST_USER.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100177_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100177_LOST_USER.lost_days
  is '��ʧ����';
comment on column T_100177_LOST_USER.data_source
  is '������Դ';
create index IDX137_100177 on T_100177_LOST_USER (CHANNELID);
create index IDX138_100177 on T_100177_LOST_USER (SERVERID);
create index IDX139_100177 on T_100177_LOST_USER (STATDATE);

prompt
prompt Creating table T_100177_MISS_FIRST
prompt ==================================
prompt
create table T_100177_MISS_FIRST
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50) default '0',
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100177_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column T_100177_MISS_FIRST.statdate
  is 'ͳ������';
comment on column T_100177_MISS_FIRST.channelid
  is '����';
comment on column T_100177_MISS_FIRST.serverid
  is '����';
comment on column T_100177_MISS_FIRST.appid
  is '��ƷID';
comment on column T_100177_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column T_100177_MISS_FIRST.accountid
  is '�û�ID';
comment on column T_100177_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100177_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column T_100177_MISS_FIRST.issucc
  is '�Ƿ���ͨ��';
comment on column T_100177_MISS_FIRST.data_source
  is '������Դ';
create index IDX140_100177 on T_100177_MISS_FIRST (CHANNELID);
create index IDX141_100177 on T_100177_MISS_FIRST (SERVERID);
create index IDX142_100177 on T_100177_MISS_FIRST (STATDATE);

prompt
prompt Creating table T_100177_NU
prompt ==========================
prompt
create table T_100177_NU
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100177_NU
  is '�����û���Ϣ��';
comment on column T_100177_NU.thedate
  is '��������';
comment on column T_100177_NU.gameid
  is '��ϷID';
comment on column T_100177_NU.channelid
  is '����ID';
comment on column T_100177_NU.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100177_NU.serverid
  is '���ڷ�ID';
comment on column T_100177_NU.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100177_NU.position
  is '����λ��';
comment on column T_100177_NU.accountid
  is '�˺�ID';
create index IDX143_100177 on T_100177_NU (CHANNELID);
create index IDX144_100177 on T_100177_NU (SERVERID);
create index IDX145_100177 on T_100177_NU (THEDATE);

prompt
prompt Creating table T_100177_NU_DVID
prompt ===============================
prompt
create table T_100177_NU_DVID
(
  thedate   DATE not null,
  gameid    VARCHAR2(20) not null,
  channelid VARCHAR2(20) not null,
  dvid      VARCHAR2(50) not null,
  ipaddr    VARCHAR2(50)
)
;
comment on table T_100177_NU_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100177_NU_DVID.thedate
  is '����ʱ��';
comment on column T_100177_NU_DVID.gameid
  is '��ϷID';
comment on column T_100177_NU_DVID.channelid
  is '����ID';
comment on column T_100177_NU_DVID.dvid
  is '�豸ID';
comment on column T_100177_NU_DVID.ipaddr
  is 'IP';
create index IDX146_100177 on T_100177_NU_DVID (CHANNELID);
create index IDX147_100177 on T_100177_NU_DVID (THEDATE);

prompt
prompt Creating table T_100177_NU_MAC
prompt ==============================
prompt
create table T_100177_NU_MAC
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100177_NU_MAC
  is '�豸������';
comment on column T_100177_NU_MAC.thedate
  is '����ʱ��';
comment on column T_100177_NU_MAC.gameid
  is '��ϷID';
comment on column T_100177_NU_MAC.channelid
  is '����ID';
comment on column T_100177_NU_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100177_NU_MAC.serverid
  is '��������ID';
comment on column T_100177_NU_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100177_NU_MAC.position
  is 'λ����Ϣ';
comment on column T_100177_NU_MAC.dvid
  is '�豸ID';
create index IDX148_100177 on T_100177_NU_MAC (CHANNELID);
create index IDX149_100177 on T_100177_NU_MAC (SERVERID);
create index IDX150_100177 on T_100177_NU_MAC (THEDATE);

prompt
prompt Creating table T_100177_NU_PAY
prompt ==============================
prompt
create table T_100177_NU_PAY
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100177_NU_PAY
  is '�����û���';
comment on column T_100177_NU_PAY.thedate
  is '����ʱ��';
comment on column T_100177_NU_PAY.gameid
  is '��ϷID';
comment on column T_100177_NU_PAY.channelid
  is '����ID';
comment on column T_100177_NU_PAY.gameversion
  is '��Ϸ�汾';
comment on column T_100177_NU_PAY.serverid
  is '������Ϣ';
comment on column T_100177_NU_PAY.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100177_NU_PAY.position
  is 'λ����Ϣ';
comment on column T_100177_NU_PAY.accountid
  is '�˺�ID';
comment on column T_100177_NU_PAY.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100177_NU_PAY.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX151_100177 on T_100177_NU_PAY (CHANNELID);
create index IDX152_100177 on T_100177_NU_PAY (SERVERID);
create index IDX153_100177 on T_100177_NU_PAY (THEDATE);

prompt
prompt Creating table T_100177_NU_PAY_MAC
prompt ==================================
prompt
create table T_100177_NU_PAY_MAC
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100177_NU_PAY_MAC
  is '�����û���';
comment on column T_100177_NU_PAY_MAC.thedate
  is '����ʱ��';
comment on column T_100177_NU_PAY_MAC.gameid
  is '��ϷID';
comment on column T_100177_NU_PAY_MAC.channelid
  is '����ID';
comment on column T_100177_NU_PAY_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100177_NU_PAY_MAC.serverid
  is '������Ϣ';
comment on column T_100177_NU_PAY_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100177_NU_PAY_MAC.position
  is 'λ����Ϣ';
comment on column T_100177_NU_PAY_MAC.dvid
  is '�豸ID';
comment on column T_100177_NU_PAY_MAC.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100177_NU_PAY_MAC.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX154_100177 on T_100177_NU_PAY_MAC (CHANNELID);
create index IDX155_100177 on T_100177_NU_PAY_MAC (SERVERID);
create index IDX156_100177 on T_100177_NU_PAY_MAC (THEDATE);

prompt
prompt Creating table T_100177_ORDER_FAILURE
prompt =====================================
prompt
create table T_100177_ORDER_FAILURE
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100177_ORDER_FAILURE
  is '��ֵ�ɹ���¼��';
comment on column T_100177_ORDER_FAILURE.thedate
  is '��ֵʱ��';
comment on column T_100177_ORDER_FAILURE.gameid
  is '��ϷID';
comment on column T_100177_ORDER_FAILURE.channelid
  is '����ID';
comment on column T_100177_ORDER_FAILURE.gameversion
  is '��Ϸ�汾';
comment on column T_100177_ORDER_FAILURE.serverid
  is '��������';
comment on column T_100177_ORDER_FAILURE.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100177_ORDER_FAILURE.position
  is 'λ����Ϣ';
comment on column T_100177_ORDER_FAILURE.dvid
  is '�豸��';
comment on column T_100177_ORDER_FAILURE.accountid
  is '�˺�';
comment on column T_100177_ORDER_FAILURE.money
  is '��ֵ���';
comment on column T_100177_ORDER_FAILURE.vc
  is '��ֵ��õ����������';
comment on column T_100177_ORDER_FAILURE.orderid
  is '������';
comment on column T_100177_ORDER_FAILURE.paychannel
  is '֧������';
comment on column T_100177_ORDER_FAILURE.iapid
  is '��ֵ����  30  60';
create index IDX157_100177 on T_100177_ORDER_FAILURE (CHANNELID);
create index IDX158_100177 on T_100177_ORDER_FAILURE (SERVERID);
create index IDX159_100177 on T_100177_ORDER_FAILURE (THEDATE);

prompt
prompt Creating table T_100177_ORDER_SUCC
prompt ==================================
prompt
create table T_100177_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100177_ORDER_SUCC
  is '��ֵ�ɹ���¼��';
comment on column T_100177_ORDER_SUCC.thedate
  is '��ֵʱ��';
comment on column T_100177_ORDER_SUCC.gameid
  is '��ϷID';
comment on column T_100177_ORDER_SUCC.channelid
  is '����ID';
comment on column T_100177_ORDER_SUCC.gameversion
  is '��Ϸ�汾';
comment on column T_100177_ORDER_SUCC.serverid
  is '��������';
comment on column T_100177_ORDER_SUCC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100177_ORDER_SUCC.position
  is 'λ����Ϣ';
comment on column T_100177_ORDER_SUCC.dvid
  is '�豸��';
comment on column T_100177_ORDER_SUCC.accountid
  is '�˺�';
comment on column T_100177_ORDER_SUCC.money
  is '��ֵ���';
comment on column T_100177_ORDER_SUCC.vc
  is '��ֵ��õ����������';
comment on column T_100177_ORDER_SUCC.orderid
  is '������';
comment on column T_100177_ORDER_SUCC.paychannel
  is '֧������';
comment on column T_100177_ORDER_SUCC.iapid
  is '��ֵ����  30  60';
create index IDX160_100177 on T_100177_ORDER_SUCC (CHANNELID);
create index IDX161_100177 on T_100177_ORDER_SUCC (SERVERID);
create index IDX162_100177 on T_100177_ORDER_SUCC (THEDATE);

prompt
prompt Creating table T_100177_VC
prompt ==========================
prompt
create table T_100177_VC
(
  statdate    DATE,
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcchange    NUMBER,
  vcbefore    NUMBER,
  vcafter     NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100177_VC
  is '������ұ仯������';
comment on column T_100177_VC.statdate
  is 'ͳ������';
comment on column T_100177_VC.channelid
  is '����';
comment on column T_100177_VC.serverid
  is '����';
comment on column T_100177_VC.appid
  is '��Ʒid';
comment on column T_100177_VC.versionid
  is '��Ʒ�汾';
comment on column T_100177_VC.accountid
  is '�û�ID';
comment on column T_100177_VC.vctype
  is '�����������';
comment on column T_100177_VC.vcusetype
  is '�������ʹ������';
comment on column T_100177_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column T_100177_VC.vcchange
  is '������ұ仯���';
comment on column T_100177_VC.vcbefore
  is '������ұ仯ǰ���';
comment on column T_100177_VC.vcafter
  is '������ұ仯����';
comment on column T_100177_VC.data_source
  is '������Դ';
create index IDX163_100177 on T_100177_VC (CHANNELID);
create index IDX164_100177 on T_100177_VC (SERVERID);
create index IDX165_100177 on T_100177_VC (STATDATE);

prompt
prompt Creating table T_100178_CEVENT
prompt ==============================
prompt
create table T_100178_CEVENT
(
  thedate          VARCHAR2(10),
  datenum          NUMBER,
  appid            VARCHAR2(10),
  channelid        VARCHAR2(50),
  gameversion      VARCHAR2(50),
  dvid             VARCHAR2(50),
  accountid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  ilevel           NUMBER,
  roleid           VARCHAR2(50),
  eventkey         VARCHAR2(100),
  eventvalue_key   VARCHAR2(100),
  eventvalue_value VARCHAR2(100),
  ipaddr           VARCHAR2(50),
  prerowid         VARCHAR2(200)
)
;
comment on table T_100178_CEVENT
  is '�Զ����¼���ֱ�';
comment on column T_100178_CEVENT.thedate
  is '����';
comment on column T_100178_CEVENT.datenum
  is '�������ָ�ʽ';
comment on column T_100178_CEVENT.appid
  is '��Ϸ�� appid';
comment on column T_100178_CEVENT.channelid
  is '���� ID';
comment on column T_100178_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column T_100178_CEVENT.dvid
  is '�豸 ID��Ψһ�豸��';
comment on column T_100178_CEVENT.accountid
  is '�ʻ� id';
comment on column T_100178_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column T_100178_CEVENT.ilevel
  is '��ҵȼ�';
comment on column T_100178_CEVENT.roleid
  is '��ɫ id';
comment on column T_100178_CEVENT.eventkey
  is '�¼�����';
comment on column T_100178_CEVENT.eventvalue_key
  is '�¼�ֵ�е�key';
comment on column T_100178_CEVENT.eventvalue_value
  is '�¼�ֵ��key��Ӧ��ֵ';
comment on column T_100178_CEVENT.ipaddr
  is 'ip ��ַ';
comment on column T_100178_CEVENT.prerowid
  is 'ԭΨһ��ID';
create index IDX180_100178 on T_100178_CEVENT (THEDATE);

prompt
prompt Creating table T_100178_CONN
prompt ============================
prompt
create table T_100178_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100178_CONN
  is '����&��ʧ&������������������ע���˺ţ�ע���豸��';
comment on column T_100178_CONN.conndate
  is '����ʱ��';
comment on column T_100178_CONN.gameid
  is '��ϷID';
comment on column T_100178_CONN.channelid
  is '����ID';
comment on column T_100178_CONN.gameversion
  is '��Ϸ�汾';
comment on column T_100178_CONN.serverid
  is '����ID';
comment on column T_100178_CONN.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100178_CONN.position
  is 'λ����Ϣ';
comment on column T_100178_CONN.dvid
  is '�豸��';
comment on column T_100178_CONN.accountid
  is '�˺�ID';
comment on column T_100178_CONN.regdate
  is 'ע��ʱ��';
comment on column T_100178_CONN.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100178_CONN.regdate_as
  is '���з��������ע��ʱ��';
create index IDX118_100178 on T_100178_CONN (CHANNELID);
create index IDX119_100178 on T_100178_CONN (SERVERID);
create index IDX120_100178 on T_100178_CONN (CONNDATE);

prompt
prompt Creating table T_100178_CONN_ACT
prompt ================================
prompt
create table T_100178_CONN_ACT
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100178_CONN_ACT
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100178_CONN_ACT.basedate
  is '����ʱ��';
comment on column T_100178_CONN_ACT.gameid
  is '��ϷID';
comment on column T_100178_CONN_ACT.channelid
  is '����ID';
comment on column T_100178_CONN_ACT.gameversion
  is '��Ϸ�汾';
comment on column T_100178_CONN_ACT.serverid
  is '����ID';
comment on column T_100178_CONN_ACT.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100178_CONN_ACT.position
  is 'λ����Ϣ';
comment on column T_100178_CONN_ACT.dvid
  is '�豸��';
comment on column T_100178_CONN_ACT.accountid
  is '�˺�';
comment on column T_100178_CONN_ACT.conndate
  is '��Ծʱ��';
comment on column T_100178_CONN_ACT.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_100178 on T_100178_CONN_ACT (CHANNELID);
create index IDX122_100178 on T_100178_CONN_ACT (SERVERID);
create index IDX123_100178 on T_100178_CONN_ACT (CONNDATE);
create index IDX124_100178 on T_100178_CONN_ACT (BASEDATE);

prompt
prompt Creating table T_100178_CONN_ACT_AS
prompt ===================================
prompt
create table T_100178_CONN_ACT_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100178_CONN_ACT_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100178_CONN_ACT_AS.basedate
  is '����ʱ��';
comment on column T_100178_CONN_ACT_AS.gameid
  is '��ϷID';
comment on column T_100178_CONN_ACT_AS.channelid
  is '����ID';
comment on column T_100178_CONN_ACT_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100178_CONN_ACT_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100178_CONN_ACT_AS.position
  is 'λ����Ϣ';
comment on column T_100178_CONN_ACT_AS.dvid
  is '�豸��';
comment on column T_100178_CONN_ACT_AS.accountid
  is '�˺�';
comment on column T_100178_CONN_ACT_AS.conndate
  is '��Ծʱ��';
comment on column T_100178_CONN_ACT_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX205_100178 on T_100178_CONN_ACT_AS (CHANNELID);
create index IDX206_100178 on T_100178_CONN_ACT_AS (CONNDATE);
create index IDX207_100178 on T_100178_CONN_ACT_AS (BASEDATE);

prompt
prompt Creating table T_100178_CONN_ACT_MAC
prompt ====================================
prompt
create table T_100178_CONN_ACT_MAC
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100178_CONN_ACT_MAC
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100178_CONN_ACT_MAC.basedate
  is '����ʱ��';
comment on column T_100178_CONN_ACT_MAC.gameid
  is '��ϷID';
comment on column T_100178_CONN_ACT_MAC.channelid
  is '����ID';
comment on column T_100178_CONN_ACT_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100178_CONN_ACT_MAC.serverid
  is '����ID';
comment on column T_100178_CONN_ACT_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100178_CONN_ACT_MAC.position
  is 'λ����Ϣ';
comment on column T_100178_CONN_ACT_MAC.dvid
  is '�豸��';
comment on column T_100178_CONN_ACT_MAC.accountid
  is '�˺�';
comment on column T_100178_CONN_ACT_MAC.conndate
  is '��Ծʱ��';
comment on column T_100178_CONN_ACT_MAC.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_100178 on T_100178_CONN_ACT_MAC (CHANNELID);
create index IDX126_100178 on T_100178_CONN_ACT_MAC (SERVERID);
create index IDX127_100178 on T_100178_CONN_ACT_MAC (CONNDATE);
create index IDX128_100178 on T_100178_CONN_ACT_MAC (BASEDATE);

prompt
prompt Creating table T_100178_CONN_ACT_MAC_AS
prompt =======================================
prompt
create table T_100178_CONN_ACT_MAC_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100178_CONN_ACT_MAC_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100178_CONN_ACT_MAC_AS.basedate
  is '����ʱ��';
comment on column T_100178_CONN_ACT_MAC_AS.gameid
  is '��ϷID';
comment on column T_100178_CONN_ACT_MAC_AS.channelid
  is '����ID';
comment on column T_100178_CONN_ACT_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100178_CONN_ACT_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100178_CONN_ACT_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100178_CONN_ACT_MAC_AS.dvid
  is '�豸��';
comment on column T_100178_CONN_ACT_MAC_AS.accountid
  is '�˺�';
comment on column T_100178_CONN_ACT_MAC_AS.conndate
  is '��Ծʱ��';
comment on column T_100178_CONN_ACT_MAC_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX202_100178 on T_100178_CONN_ACT_MAC_AS (CHANNELID);
create index IDX203_100178 on T_100178_CONN_ACT_MAC_AS (CONNDATE);
create index IDX204_100178 on T_100178_CONN_ACT_MAC_AS (BASEDATE);

prompt
prompt Creating table T_100178_CONN_DVID
prompt =================================
prompt
create table T_100178_CONN_DVID
(
  conndate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  dvid      VARCHAR2(50),
  regdate   VARCHAR2(10)
)
;
comment on table T_100178_CONN_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100178_CONN_DVID.conndate
  is '����ʱ��';
comment on column T_100178_CONN_DVID.gameid
  is '��ϷID';
comment on column T_100178_CONN_DVID.channelid
  is '����ID';
comment on column T_100178_CONN_DVID.dvid
  is '�豸��';
comment on column T_100178_CONN_DVID.regdate
  is 'ע��ʱ��';
create index IDX129_100178 on T_100178_CONN_DVID (CHANNELID);
create index IDX130_100178 on T_100178_CONN_DVID (CONNDATE);

prompt
prompt Creating table T_100178_CONN_MAC
prompt ================================
prompt
create table T_100178_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100178_CONN_MAC
  is '���� ��ʧ ������������������ע���˺ţ�ע���豸��';
comment on column T_100178_CONN_MAC.conndate
  is '����ʱ��';
comment on column T_100178_CONN_MAC.gameid
  is '��ϷID';
comment on column T_100178_CONN_MAC.channelid
  is '����ID';
comment on column T_100178_CONN_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100178_CONN_MAC.serverid
  is '����ID';
comment on column T_100178_CONN_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100178_CONN_MAC.position
  is 'λ����Ϣ';
comment on column T_100178_CONN_MAC.dvid
  is '�豸��';
comment on column T_100178_CONN_MAC.accountid
  is '�˺�ID';
comment on column T_100178_CONN_MAC.regdate
  is 'ע��ʱ��';
comment on column T_100178_CONN_MAC.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100178_CONN_MAC.regdate_as
  is '���з��������ע��ʱ��';
create index IDX131_100178 on T_100178_CONN_MAC (CHANNELID);
create index IDX132_100178 on T_100178_CONN_MAC (SERVERID);
create index IDX133_100178 on T_100178_CONN_MAC (CONNDATE);

prompt
prompt Creating table T_100178_LOST_MAC
prompt ================================
prompt
create table T_100178_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100178_LOST_MAC
  is '�豸�ȼ���ʧ������';
comment on column T_100178_LOST_MAC.statdate
  is '�����������';
comment on column T_100178_LOST_MAC.lost_date
  is '��ʧ����';
comment on column T_100178_LOST_MAC.channelid
  is '����';
comment on column T_100178_LOST_MAC.serverid
  is '����';
comment on column T_100178_LOST_MAC.appid
  is '��Ʒid';
comment on column T_100178_LOST_MAC.macid
  is '�豸id';
comment on column T_100178_LOST_MAC.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100178_LOST_MAC.lost_days
  is '��ʧ����';
comment on column T_100178_LOST_MAC.data_source
  is '������Դ';
create index IDX134_100178 on T_100178_LOST_MAC (CHANNELID);
create index IDX135_100178 on T_100178_LOST_MAC (SERVERID);
create index IDX136_100178 on T_100178_LOST_MAC (STATDATE);

prompt
prompt Creating table T_100178_LOST_MAC_AS
prompt ===================================
prompt
create table T_100178_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100178_LOST_MAC_AS
  is '�豸�ȼ���ʧ������allserver';
comment on column T_100178_LOST_MAC_AS.statdate
  is '�����������';
comment on column T_100178_LOST_MAC_AS.lost_date
  is '��ʧ����';
comment on column T_100178_LOST_MAC_AS.channelid
  is '����';
comment on column T_100178_LOST_MAC_AS.appid
  is '��Ʒid';
comment on column T_100178_LOST_MAC_AS.macid
  is '�豸id';
comment on column T_100178_LOST_MAC_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100178_LOST_MAC_AS.lost_days
  is '��ʧ����';
comment on column T_100178_LOST_MAC_AS.data_source
  is '������Դ';
create index IDX210_100178 on T_100178_LOST_MAC_AS (CHANNELID);
create index IDX211_100178 on T_100178_LOST_MAC_AS (STATDATE);

prompt
prompt Creating table T_100178_LOST_USER
prompt =================================
prompt
create table T_100178_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100178_LOST_USER
  is '�û��ȼ���ʧ������';
comment on column T_100178_LOST_USER.statdate
  is '�����������';
comment on column T_100178_LOST_USER.lost_date
  is '��ʧ����';
comment on column T_100178_LOST_USER.channelid
  is '����';
comment on column T_100178_LOST_USER.serverid
  is '����';
comment on column T_100178_LOST_USER.appid
  is '��Ʒid';
comment on column T_100178_LOST_USER.userid
  is '�û�id';
comment on column T_100178_LOST_USER.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100178_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100178_LOST_USER.lost_days
  is '��ʧ����';
comment on column T_100178_LOST_USER.data_source
  is '������Դ';
create index IDX137_100178 on T_100178_LOST_USER (CHANNELID);
create index IDX138_100178 on T_100178_LOST_USER (SERVERID);
create index IDX139_100178 on T_100178_LOST_USER (STATDATE);

prompt
prompt Creating table T_100178_LOST_USER_AS
prompt ====================================
prompt
create table T_100178_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100178_LOST_USER_AS
  is '�û��ȼ���ʧ������allserver';
comment on column T_100178_LOST_USER_AS.statdate
  is '�����������';
comment on column T_100178_LOST_USER_AS.lost_date
  is '��ʧ����';
comment on column T_100178_LOST_USER_AS.channelid
  is '����';
comment on column T_100178_LOST_USER_AS.appid
  is '��Ʒid';
comment on column T_100178_LOST_USER_AS.userid
  is '�û�id';
comment on column T_100178_LOST_USER_AS.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100178_LOST_USER_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100178_LOST_USER_AS.lost_days
  is '��ʧ����';
comment on column T_100178_LOST_USER_AS.data_source
  is '������Դ';
create index IDX208_100178 on T_100178_LOST_USER_AS (CHANNELID);
create index IDX209_100178 on T_100178_LOST_USER_AS (STATDATE);

prompt
prompt Creating table T_100178_MISS_FIRST
prompt ==================================
prompt
create table T_100178_MISS_FIRST
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50) default '0',
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100178_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column T_100178_MISS_FIRST.statdate
  is 'ͳ������';
comment on column T_100178_MISS_FIRST.channelid
  is '����';
comment on column T_100178_MISS_FIRST.serverid
  is '����';
comment on column T_100178_MISS_FIRST.appid
  is '��ƷID';
comment on column T_100178_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column T_100178_MISS_FIRST.accountid
  is '�û�ID';
comment on column T_100178_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100178_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column T_100178_MISS_FIRST.issucc
  is '�Ƿ���ͨ��';
comment on column T_100178_MISS_FIRST.data_source
  is '������Դ';
create index IDX140_100178 on T_100178_MISS_FIRST (CHANNELID);
create index IDX141_100178 on T_100178_MISS_FIRST (SERVERID);
create index IDX142_100178 on T_100178_MISS_FIRST (STATDATE);

prompt
prompt Creating table T_100178_NU
prompt ==========================
prompt
create table T_100178_NU
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100178_NU
  is '�����û���Ϣ��';
comment on column T_100178_NU.thedate
  is '��������';
comment on column T_100178_NU.gameid
  is '��ϷID';
comment on column T_100178_NU.channelid
  is '����ID';
comment on column T_100178_NU.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100178_NU.serverid
  is '���ڷ�ID';
comment on column T_100178_NU.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100178_NU.position
  is '����λ��';
comment on column T_100178_NU.accountid
  is '�˺�ID';
create index IDX143_100178 on T_100178_NU (CHANNELID);
create index IDX144_100178 on T_100178_NU (SERVERID);
create index IDX145_100178 on T_100178_NU (THEDATE);

prompt
prompt Creating table T_100178_NU_ALLSERVER
prompt ====================================
prompt
create table T_100178_NU_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100178_NU_ALLSERVER
  is '�����û���Ϣ��ALLSERVER';
comment on column T_100178_NU_ALLSERVER.thedate
  is '��������';
comment on column T_100178_NU_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100178_NU_ALLSERVER.channelid
  is '����ID';
comment on column T_100178_NU_ALLSERVER.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100178_NU_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100178_NU_ALLSERVER.position
  is '����λ��';
comment on column T_100178_NU_ALLSERVER.accountid
  is '�˺�ID';
create index IDX194_100178 on T_100178_NU_ALLSERVER (CHANNELID);
create index IDX195_100178 on T_100178_NU_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100178_NU_DVID
prompt ===============================
prompt
create table T_100178_NU_DVID
(
  thedate   DATE not null,
  gameid    VARCHAR2(20) not null,
  channelid VARCHAR2(20) not null,
  dvid      VARCHAR2(50) not null,
  ipaddr    VARCHAR2(50)
)
;
comment on table T_100178_NU_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100178_NU_DVID.thedate
  is '����ʱ��';
comment on column T_100178_NU_DVID.gameid
  is '��ϷID';
comment on column T_100178_NU_DVID.channelid
  is '����ID';
comment on column T_100178_NU_DVID.dvid
  is '�豸ID';
comment on column T_100178_NU_DVID.ipaddr
  is 'IP';
create index IDX146_100178 on T_100178_NU_DVID (CHANNELID);
create index IDX147_100178 on T_100178_NU_DVID (THEDATE);

prompt
prompt Creating table T_100178_NU_MAC
prompt ==============================
prompt
create table T_100178_NU_MAC
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100178_NU_MAC
  is '�豸������';
comment on column T_100178_NU_MAC.thedate
  is '����ʱ��';
comment on column T_100178_NU_MAC.gameid
  is '��ϷID';
comment on column T_100178_NU_MAC.channelid
  is '����ID';
comment on column T_100178_NU_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100178_NU_MAC.serverid
  is '��������ID';
comment on column T_100178_NU_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100178_NU_MAC.position
  is 'λ����Ϣ';
comment on column T_100178_NU_MAC.dvid
  is '�豸ID';
create index IDX148_100178 on T_100178_NU_MAC (CHANNELID);
create index IDX149_100178 on T_100178_NU_MAC (SERVERID);
create index IDX150_100178 on T_100178_NU_MAC (THEDATE);

prompt
prompt Creating table T_100178_NU_MAC_ALLSERVER
prompt ========================================
prompt
create table T_100178_NU_MAC_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100178_NU_MAC_ALLSERVER
  is '�豸������ALLSERVER';
comment on column T_100178_NU_MAC_ALLSERVER.thedate
  is '����ʱ��';
comment on column T_100178_NU_MAC_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100178_NU_MAC_ALLSERVER.channelid
  is '����ID';
comment on column T_100178_NU_MAC_ALLSERVER.gameversion
  is '��Ϸ�汾';
comment on column T_100178_NU_MAC_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100178_NU_MAC_ALLSERVER.position
  is 'λ����Ϣ';
comment on column T_100178_NU_MAC_ALLSERVER.dvid
  is '�豸ID';
create index IDX196_100178 on T_100178_NU_MAC_ALLSERVER (CHANNELID);
create index IDX197_100178 on T_100178_NU_MAC_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100178_NU_PAY
prompt ==============================
prompt
create table T_100178_NU_PAY
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100178_NU_PAY
  is '�����û���';
comment on column T_100178_NU_PAY.thedate
  is '����ʱ��';
comment on column T_100178_NU_PAY.gameid
  is '��ϷID';
comment on column T_100178_NU_PAY.channelid
  is '����ID';
comment on column T_100178_NU_PAY.gameversion
  is '��Ϸ�汾';
comment on column T_100178_NU_PAY.serverid
  is '������Ϣ';
comment on column T_100178_NU_PAY.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100178_NU_PAY.position
  is 'λ����Ϣ';
comment on column T_100178_NU_PAY.accountid
  is '�˺�ID';
comment on column T_100178_NU_PAY.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100178_NU_PAY.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX151_100178 on T_100178_NU_PAY (CHANNELID);
create index IDX152_100178 on T_100178_NU_PAY (SERVERID);
create index IDX153_100178 on T_100178_NU_PAY (THEDATE);

prompt
prompt Creating table T_100178_NU_PAY_AS
prompt =================================
prompt
create table T_100178_NU_PAY_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100178_NU_PAY_AS
  is '�����û���allsever';
comment on column T_100178_NU_PAY_AS.thedate
  is '����ʱ��';
comment on column T_100178_NU_PAY_AS.gameid
  is '��ϷID';
comment on column T_100178_NU_PAY_AS.channelid
  is '����ID';
comment on column T_100178_NU_PAY_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100178_NU_PAY_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100178_NU_PAY_AS.position
  is 'λ����Ϣ';
comment on column T_100178_NU_PAY_AS.accountid
  is '�˺�ID';
comment on column T_100178_NU_PAY_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100178_NU_PAY_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX198_100178 on T_100178_NU_PAY_AS (CHANNELID);
create index IDX199_100178 on T_100178_NU_PAY_AS (THEDATE);

prompt
prompt Creating table T_100178_NU_PAY_MAC
prompt ==================================
prompt
create table T_100178_NU_PAY_MAC
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100178_NU_PAY_MAC
  is '�����û���';
comment on column T_100178_NU_PAY_MAC.thedate
  is '����ʱ��';
comment on column T_100178_NU_PAY_MAC.gameid
  is '��ϷID';
comment on column T_100178_NU_PAY_MAC.channelid
  is '����ID';
comment on column T_100178_NU_PAY_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100178_NU_PAY_MAC.serverid
  is '������Ϣ';
comment on column T_100178_NU_PAY_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100178_NU_PAY_MAC.position
  is 'λ����Ϣ';
comment on column T_100178_NU_PAY_MAC.dvid
  is '�豸ID';
comment on column T_100178_NU_PAY_MAC.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100178_NU_PAY_MAC.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX154_100178 on T_100178_NU_PAY_MAC (CHANNELID);
create index IDX155_100178 on T_100178_NU_PAY_MAC (SERVERID);
create index IDX156_100178 on T_100178_NU_PAY_MAC (THEDATE);

prompt
prompt Creating table T_100178_NU_PAY_MAC_AS
prompt =====================================
prompt
create table T_100178_NU_PAY_MAC_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100178_NU_PAY_MAC_AS
  is '�����û���ALLSERVER';
comment on column T_100178_NU_PAY_MAC_AS.thedate
  is '����ʱ��';
comment on column T_100178_NU_PAY_MAC_AS.gameid
  is '��ϷID';
comment on column T_100178_NU_PAY_MAC_AS.channelid
  is '����ID';
comment on column T_100178_NU_PAY_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100178_NU_PAY_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100178_NU_PAY_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100178_NU_PAY_MAC_AS.dvid
  is '�豸ID';
comment on column T_100178_NU_PAY_MAC_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100178_NU_PAY_MAC_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX200_100178 on T_100178_NU_PAY_MAC_AS (CHANNELID);
create index IDX201_100178 on T_100178_NU_PAY_MAC_AS (THEDATE);

prompt
prompt Creating table T_100178_ORDER_FAILURE
prompt =====================================
prompt
create table T_100178_ORDER_FAILURE
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100178_ORDER_FAILURE
  is '��ֵ�ɹ���¼��';
comment on column T_100178_ORDER_FAILURE.thedate
  is '��ֵʱ��';
comment on column T_100178_ORDER_FAILURE.gameid
  is '��ϷID';
comment on column T_100178_ORDER_FAILURE.channelid
  is '����ID';
comment on column T_100178_ORDER_FAILURE.gameversion
  is '��Ϸ�汾';
comment on column T_100178_ORDER_FAILURE.serverid
  is '��������';
comment on column T_100178_ORDER_FAILURE.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100178_ORDER_FAILURE.position
  is 'λ����Ϣ';
comment on column T_100178_ORDER_FAILURE.dvid
  is '�豸��';
comment on column T_100178_ORDER_FAILURE.accountid
  is '�˺�';
comment on column T_100178_ORDER_FAILURE.money
  is '��ֵ���';
comment on column T_100178_ORDER_FAILURE.vc
  is '��ֵ��õ����������';
comment on column T_100178_ORDER_FAILURE.orderid
  is '������';
comment on column T_100178_ORDER_FAILURE.paychannel
  is '֧������';
comment on column T_100178_ORDER_FAILURE.iapid
  is '��ֵ����  30  60';
create index IDX157_100178 on T_100178_ORDER_FAILURE (CHANNELID);
create index IDX158_100178 on T_100178_ORDER_FAILURE (SERVERID);
create index IDX159_100178 on T_100178_ORDER_FAILURE (THEDATE);

prompt
prompt Creating table T_100178_ORDER_SUCC
prompt ==================================
prompt
create table T_100178_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100178_ORDER_SUCC
  is '��ֵ�ɹ���¼��';
comment on column T_100178_ORDER_SUCC.thedate
  is '��ֵʱ��';
comment on column T_100178_ORDER_SUCC.gameid
  is '��ϷID';
comment on column T_100178_ORDER_SUCC.channelid
  is '����ID';
comment on column T_100178_ORDER_SUCC.gameversion
  is '��Ϸ�汾';
comment on column T_100178_ORDER_SUCC.serverid
  is '��������';
comment on column T_100178_ORDER_SUCC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100178_ORDER_SUCC.position
  is 'λ����Ϣ';
comment on column T_100178_ORDER_SUCC.dvid
  is '�豸��';
comment on column T_100178_ORDER_SUCC.accountid
  is '�˺�';
comment on column T_100178_ORDER_SUCC.money
  is '��ֵ���';
comment on column T_100178_ORDER_SUCC.vc
  is '��ֵ��õ����������';
comment on column T_100178_ORDER_SUCC.orderid
  is '������';
comment on column T_100178_ORDER_SUCC.paychannel
  is '֧������';
comment on column T_100178_ORDER_SUCC.iapid
  is '��ֵ����  30  60';
create index IDX160_100178 on T_100178_ORDER_SUCC (CHANNELID);
create index IDX161_100178 on T_100178_ORDER_SUCC (SERVERID);
create index IDX162_100178 on T_100178_ORDER_SUCC (THEDATE);

prompt
prompt Creating table T_100178_VC
prompt ==========================
prompt
create table T_100178_VC
(
  statdate    DATE,
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcchange    NUMBER,
  vcbefore    NUMBER,
  vcafter     NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100178_VC
  is '������ұ仯������';
comment on column T_100178_VC.statdate
  is 'ͳ������';
comment on column T_100178_VC.channelid
  is '����';
comment on column T_100178_VC.serverid
  is '����';
comment on column T_100178_VC.appid
  is '��Ʒid';
comment on column T_100178_VC.versionid
  is '��Ʒ�汾';
comment on column T_100178_VC.accountid
  is '�û�ID';
comment on column T_100178_VC.vctype
  is '�����������';
comment on column T_100178_VC.vcusetype
  is '�������ʹ������';
comment on column T_100178_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column T_100178_VC.vcchange
  is '������ұ仯���';
comment on column T_100178_VC.vcbefore
  is '������ұ仯ǰ���';
comment on column T_100178_VC.vcafter
  is '������ұ仯����';
comment on column T_100178_VC.data_source
  is '������Դ';
create index IDX163_100178 on T_100178_VC (CHANNELID);
create index IDX164_100178 on T_100178_VC (SERVERID);
create index IDX165_100178 on T_100178_VC (STATDATE);

prompt
prompt Creating table T_100179_CEVENT
prompt ==============================
prompt
create table T_100179_CEVENT
(
  thedate          VARCHAR2(10),
  datenum          NUMBER,
  appid            VARCHAR2(10),
  channelid        VARCHAR2(50),
  gameversion      VARCHAR2(50),
  dvid             VARCHAR2(50),
  accountid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  ilevel           NUMBER,
  roleid           VARCHAR2(50),
  eventkey         VARCHAR2(100),
  eventvalue_key   VARCHAR2(100),
  eventvalue_value VARCHAR2(100),
  ipaddr           VARCHAR2(50),
  prerowid         VARCHAR2(200)
)
;
comment on table T_100179_CEVENT
  is '�Զ����¼���ֱ�';
comment on column T_100179_CEVENT.thedate
  is '����';
comment on column T_100179_CEVENT.datenum
  is '�������ָ�ʽ';
comment on column T_100179_CEVENT.appid
  is '��Ϸ�� appid';
comment on column T_100179_CEVENT.channelid
  is '���� ID';
comment on column T_100179_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column T_100179_CEVENT.dvid
  is '�豸 ID��Ψһ�豸��';
comment on column T_100179_CEVENT.accountid
  is '�ʻ� id';
comment on column T_100179_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column T_100179_CEVENT.ilevel
  is '��ҵȼ�';
comment on column T_100179_CEVENT.roleid
  is '��ɫ id';
comment on column T_100179_CEVENT.eventkey
  is '�¼�����';
comment on column T_100179_CEVENT.eventvalue_key
  is '�¼�ֵ�е�key';
comment on column T_100179_CEVENT.eventvalue_value
  is '�¼�ֵ��key��Ӧ��ֵ';
comment on column T_100179_CEVENT.ipaddr
  is 'ip ��ַ';
comment on column T_100179_CEVENT.prerowid
  is 'ԭΨһ��ID';
create index IDX180_100179 on T_100179_CEVENT (THEDATE);

prompt
prompt Creating table T_100179_CONN
prompt ============================
prompt
create table T_100179_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100179_CONN
  is '����&��ʧ&������������������ע���˺ţ�ע���豸��';
comment on column T_100179_CONN.conndate
  is '����ʱ��';
comment on column T_100179_CONN.gameid
  is '��ϷID';
comment on column T_100179_CONN.channelid
  is '����ID';
comment on column T_100179_CONN.gameversion
  is '��Ϸ�汾';
comment on column T_100179_CONN.serverid
  is '����ID';
comment on column T_100179_CONN.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100179_CONN.position
  is 'λ����Ϣ';
comment on column T_100179_CONN.dvid
  is '�豸��';
comment on column T_100179_CONN.accountid
  is '�˺�ID';
comment on column T_100179_CONN.regdate
  is 'ע��ʱ��';
comment on column T_100179_CONN.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100179_CONN.regdate_as
  is '���з��������ע��ʱ��';
create index IDX118_100179 on T_100179_CONN (CHANNELID);
create index IDX119_100179 on T_100179_CONN (SERVERID);
create index IDX120_100179 on T_100179_CONN (CONNDATE);

prompt
prompt Creating table T_100179_CONN_ACT
prompt ================================
prompt
create table T_100179_CONN_ACT
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100179_CONN_ACT
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100179_CONN_ACT.basedate
  is '����ʱ��';
comment on column T_100179_CONN_ACT.gameid
  is '��ϷID';
comment on column T_100179_CONN_ACT.channelid
  is '����ID';
comment on column T_100179_CONN_ACT.gameversion
  is '��Ϸ�汾';
comment on column T_100179_CONN_ACT.serverid
  is '����ID';
comment on column T_100179_CONN_ACT.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100179_CONN_ACT.position
  is 'λ����Ϣ';
comment on column T_100179_CONN_ACT.dvid
  is '�豸��';
comment on column T_100179_CONN_ACT.accountid
  is '�˺�';
comment on column T_100179_CONN_ACT.conndate
  is '��Ծʱ��';
comment on column T_100179_CONN_ACT.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_100179 on T_100179_CONN_ACT (CHANNELID);
create index IDX122_100179 on T_100179_CONN_ACT (SERVERID);
create index IDX123_100179 on T_100179_CONN_ACT (CONNDATE);
create index IDX124_100179 on T_100179_CONN_ACT (BASEDATE);

prompt
prompt Creating table T_100179_CONN_ACT_AS
prompt ===================================
prompt
create table T_100179_CONN_ACT_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100179_CONN_ACT_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100179_CONN_ACT_AS.basedate
  is '����ʱ��';
comment on column T_100179_CONN_ACT_AS.gameid
  is '��ϷID';
comment on column T_100179_CONN_ACT_AS.channelid
  is '����ID';
comment on column T_100179_CONN_ACT_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100179_CONN_ACT_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100179_CONN_ACT_AS.position
  is 'λ����Ϣ';
comment on column T_100179_CONN_ACT_AS.dvid
  is '�豸��';
comment on column T_100179_CONN_ACT_AS.accountid
  is '�˺�';
comment on column T_100179_CONN_ACT_AS.conndate
  is '��Ծʱ��';
comment on column T_100179_CONN_ACT_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX205_100179 on T_100179_CONN_ACT_AS (CHANNELID);
create index IDX206_100179 on T_100179_CONN_ACT_AS (CONNDATE);
create index IDX207_100179 on T_100179_CONN_ACT_AS (BASEDATE);

prompt
prompt Creating table T_100179_CONN_ACT_MAC
prompt ====================================
prompt
create table T_100179_CONN_ACT_MAC
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100179_CONN_ACT_MAC
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100179_CONN_ACT_MAC.basedate
  is '����ʱ��';
comment on column T_100179_CONN_ACT_MAC.gameid
  is '��ϷID';
comment on column T_100179_CONN_ACT_MAC.channelid
  is '����ID';
comment on column T_100179_CONN_ACT_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100179_CONN_ACT_MAC.serverid
  is '����ID';
comment on column T_100179_CONN_ACT_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100179_CONN_ACT_MAC.position
  is 'λ����Ϣ';
comment on column T_100179_CONN_ACT_MAC.dvid
  is '�豸��';
comment on column T_100179_CONN_ACT_MAC.accountid
  is '�˺�';
comment on column T_100179_CONN_ACT_MAC.conndate
  is '��Ծʱ��';
comment on column T_100179_CONN_ACT_MAC.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_100179 on T_100179_CONN_ACT_MAC (CHANNELID);
create index IDX126_100179 on T_100179_CONN_ACT_MAC (SERVERID);
create index IDX127_100179 on T_100179_CONN_ACT_MAC (CONNDATE);
create index IDX128_100179 on T_100179_CONN_ACT_MAC (BASEDATE);

prompt
prompt Creating table T_100179_CONN_ACT_MAC_AS
prompt =======================================
prompt
create table T_100179_CONN_ACT_MAC_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100179_CONN_ACT_MAC_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100179_CONN_ACT_MAC_AS.basedate
  is '����ʱ��';
comment on column T_100179_CONN_ACT_MAC_AS.gameid
  is '��ϷID';
comment on column T_100179_CONN_ACT_MAC_AS.channelid
  is '����ID';
comment on column T_100179_CONN_ACT_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100179_CONN_ACT_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100179_CONN_ACT_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100179_CONN_ACT_MAC_AS.dvid
  is '�豸��';
comment on column T_100179_CONN_ACT_MAC_AS.accountid
  is '�˺�';
comment on column T_100179_CONN_ACT_MAC_AS.conndate
  is '��Ծʱ��';
comment on column T_100179_CONN_ACT_MAC_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX202_100179 on T_100179_CONN_ACT_MAC_AS (CHANNELID);
create index IDX203_100179 on T_100179_CONN_ACT_MAC_AS (CONNDATE);
create index IDX204_100179 on T_100179_CONN_ACT_MAC_AS (BASEDATE);

prompt
prompt Creating table T_100179_CONN_DVID
prompt =================================
prompt
create table T_100179_CONN_DVID
(
  conndate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  dvid      VARCHAR2(50),
  regdate   VARCHAR2(10)
)
;
comment on table T_100179_CONN_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100179_CONN_DVID.conndate
  is '����ʱ��';
comment on column T_100179_CONN_DVID.gameid
  is '��ϷID';
comment on column T_100179_CONN_DVID.channelid
  is '����ID';
comment on column T_100179_CONN_DVID.dvid
  is '�豸��';
comment on column T_100179_CONN_DVID.regdate
  is 'ע��ʱ��';
create index IDX129_100179 on T_100179_CONN_DVID (CHANNELID);
create index IDX130_100179 on T_100179_CONN_DVID (CONNDATE);

prompt
prompt Creating table T_100179_CONN_MAC
prompt ================================
prompt
create table T_100179_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100179_CONN_MAC
  is '���� ��ʧ ������������������ע���˺ţ�ע���豸��';
comment on column T_100179_CONN_MAC.conndate
  is '����ʱ��';
comment on column T_100179_CONN_MAC.gameid
  is '��ϷID';
comment on column T_100179_CONN_MAC.channelid
  is '����ID';
comment on column T_100179_CONN_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100179_CONN_MAC.serverid
  is '����ID';
comment on column T_100179_CONN_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100179_CONN_MAC.position
  is 'λ����Ϣ';
comment on column T_100179_CONN_MAC.dvid
  is '�豸��';
comment on column T_100179_CONN_MAC.accountid
  is '�˺�ID';
comment on column T_100179_CONN_MAC.regdate
  is 'ע��ʱ��';
comment on column T_100179_CONN_MAC.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100179_CONN_MAC.regdate_as
  is '���з��������ע��ʱ��';
create index IDX131_100179 on T_100179_CONN_MAC (CHANNELID);
create index IDX132_100179 on T_100179_CONN_MAC (SERVERID);
create index IDX133_100179 on T_100179_CONN_MAC (CONNDATE);

prompt
prompt Creating table T_100179_LOST_MAC
prompt ================================
prompt
create table T_100179_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100179_LOST_MAC
  is '�豸�ȼ���ʧ������';
comment on column T_100179_LOST_MAC.statdate
  is '�����������';
comment on column T_100179_LOST_MAC.lost_date
  is '��ʧ����';
comment on column T_100179_LOST_MAC.channelid
  is '����';
comment on column T_100179_LOST_MAC.serverid
  is '����';
comment on column T_100179_LOST_MAC.appid
  is '��Ʒid';
comment on column T_100179_LOST_MAC.macid
  is '�豸id';
comment on column T_100179_LOST_MAC.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100179_LOST_MAC.lost_days
  is '��ʧ����';
comment on column T_100179_LOST_MAC.data_source
  is '������Դ';
create index IDX134_100179 on T_100179_LOST_MAC (CHANNELID);
create index IDX135_100179 on T_100179_LOST_MAC (SERVERID);
create index IDX136_100179 on T_100179_LOST_MAC (STATDATE);

prompt
prompt Creating table T_100179_LOST_MAC_AS
prompt ===================================
prompt
create table T_100179_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100179_LOST_MAC_AS
  is '�豸�ȼ���ʧ������allserver';
comment on column T_100179_LOST_MAC_AS.statdate
  is '�����������';
comment on column T_100179_LOST_MAC_AS.lost_date
  is '��ʧ����';
comment on column T_100179_LOST_MAC_AS.channelid
  is '����';
comment on column T_100179_LOST_MAC_AS.appid
  is '��Ʒid';
comment on column T_100179_LOST_MAC_AS.macid
  is '�豸id';
comment on column T_100179_LOST_MAC_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100179_LOST_MAC_AS.lost_days
  is '��ʧ����';
comment on column T_100179_LOST_MAC_AS.data_source
  is '������Դ';
create index IDX210_100179 on T_100179_LOST_MAC_AS (CHANNELID);
create index IDX211_100179 on T_100179_LOST_MAC_AS (STATDATE);

prompt
prompt Creating table T_100179_LOST_USER
prompt =================================
prompt
create table T_100179_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100179_LOST_USER
  is '�û��ȼ���ʧ������';
comment on column T_100179_LOST_USER.statdate
  is '�����������';
comment on column T_100179_LOST_USER.lost_date
  is '��ʧ����';
comment on column T_100179_LOST_USER.channelid
  is '����';
comment on column T_100179_LOST_USER.serverid
  is '����';
comment on column T_100179_LOST_USER.appid
  is '��Ʒid';
comment on column T_100179_LOST_USER.userid
  is '�û�id';
comment on column T_100179_LOST_USER.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100179_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100179_LOST_USER.lost_days
  is '��ʧ����';
comment on column T_100179_LOST_USER.data_source
  is '������Դ';
create index IDX137_100179 on T_100179_LOST_USER (CHANNELID);
create index IDX138_100179 on T_100179_LOST_USER (SERVERID);
create index IDX139_100179 on T_100179_LOST_USER (STATDATE);

prompt
prompt Creating table T_100179_LOST_USER_AS
prompt ====================================
prompt
create table T_100179_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100179_LOST_USER_AS
  is '�û��ȼ���ʧ������allserver';
comment on column T_100179_LOST_USER_AS.statdate
  is '�����������';
comment on column T_100179_LOST_USER_AS.lost_date
  is '��ʧ����';
comment on column T_100179_LOST_USER_AS.channelid
  is '����';
comment on column T_100179_LOST_USER_AS.appid
  is '��Ʒid';
comment on column T_100179_LOST_USER_AS.userid
  is '�û�id';
comment on column T_100179_LOST_USER_AS.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100179_LOST_USER_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100179_LOST_USER_AS.lost_days
  is '��ʧ����';
comment on column T_100179_LOST_USER_AS.data_source
  is '������Դ';
create index IDX208_100179 on T_100179_LOST_USER_AS (CHANNELID);
create index IDX209_100179 on T_100179_LOST_USER_AS (STATDATE);

prompt
prompt Creating table T_100179_MISS_FIRST
prompt ==================================
prompt
create table T_100179_MISS_FIRST
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50) default '0',
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100179_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column T_100179_MISS_FIRST.statdate
  is 'ͳ������';
comment on column T_100179_MISS_FIRST.channelid
  is '����';
comment on column T_100179_MISS_FIRST.serverid
  is '����';
comment on column T_100179_MISS_FIRST.appid
  is '��ƷID';
comment on column T_100179_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column T_100179_MISS_FIRST.accountid
  is '�û�ID';
comment on column T_100179_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100179_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column T_100179_MISS_FIRST.issucc
  is '�Ƿ���ͨ��';
comment on column T_100179_MISS_FIRST.data_source
  is '������Դ';
create index IDX140_100179 on T_100179_MISS_FIRST (CHANNELID);
create index IDX141_100179 on T_100179_MISS_FIRST (SERVERID);
create index IDX142_100179 on T_100179_MISS_FIRST (STATDATE);

prompt
prompt Creating table T_100179_NU
prompt ==========================
prompt
create table T_100179_NU
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100179_NU
  is '�����û���Ϣ��';
comment on column T_100179_NU.thedate
  is '��������';
comment on column T_100179_NU.gameid
  is '��ϷID';
comment on column T_100179_NU.channelid
  is '����ID';
comment on column T_100179_NU.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100179_NU.serverid
  is '���ڷ�ID';
comment on column T_100179_NU.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100179_NU.position
  is '����λ��';
comment on column T_100179_NU.accountid
  is '�˺�ID';
create index IDX143_100179 on T_100179_NU (CHANNELID);
create index IDX144_100179 on T_100179_NU (SERVERID);
create index IDX145_100179 on T_100179_NU (THEDATE);

prompt
prompt Creating table T_100179_NU_ALLSERVER
prompt ====================================
prompt
create table T_100179_NU_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100179_NU_ALLSERVER
  is '�����û���Ϣ��ALLSERVER';
comment on column T_100179_NU_ALLSERVER.thedate
  is '��������';
comment on column T_100179_NU_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100179_NU_ALLSERVER.channelid
  is '����ID';
comment on column T_100179_NU_ALLSERVER.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100179_NU_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100179_NU_ALLSERVER.position
  is '����λ��';
comment on column T_100179_NU_ALLSERVER.accountid
  is '�˺�ID';
create index IDX194_100179 on T_100179_NU_ALLSERVER (CHANNELID);
create index IDX195_100179 on T_100179_NU_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100179_NU_DVID
prompt ===============================
prompt
create table T_100179_NU_DVID
(
  thedate   DATE not null,
  gameid    VARCHAR2(20) not null,
  channelid VARCHAR2(20) not null,
  dvid      VARCHAR2(50) not null,
  ipaddr    VARCHAR2(50)
)
;
comment on table T_100179_NU_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100179_NU_DVID.thedate
  is '����ʱ��';
comment on column T_100179_NU_DVID.gameid
  is '��ϷID';
comment on column T_100179_NU_DVID.channelid
  is '����ID';
comment on column T_100179_NU_DVID.dvid
  is '�豸ID';
comment on column T_100179_NU_DVID.ipaddr
  is 'IP';
create index IDX146_100179 on T_100179_NU_DVID (CHANNELID);
create index IDX147_100179 on T_100179_NU_DVID (THEDATE);

prompt
prompt Creating table T_100179_NU_MAC
prompt ==============================
prompt
create table T_100179_NU_MAC
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100179_NU_MAC
  is '�豸������';
comment on column T_100179_NU_MAC.thedate
  is '����ʱ��';
comment on column T_100179_NU_MAC.gameid
  is '��ϷID';
comment on column T_100179_NU_MAC.channelid
  is '����ID';
comment on column T_100179_NU_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100179_NU_MAC.serverid
  is '��������ID';
comment on column T_100179_NU_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100179_NU_MAC.position
  is 'λ����Ϣ';
comment on column T_100179_NU_MAC.dvid
  is '�豸ID';
create index IDX148_100179 on T_100179_NU_MAC (CHANNELID);
create index IDX149_100179 on T_100179_NU_MAC (SERVERID);
create index IDX150_100179 on T_100179_NU_MAC (THEDATE);

prompt
prompt Creating table T_100179_NU_MAC_ALLSERVER
prompt ========================================
prompt
create table T_100179_NU_MAC_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100179_NU_MAC_ALLSERVER
  is '�豸������ALLSERVER';
comment on column T_100179_NU_MAC_ALLSERVER.thedate
  is '����ʱ��';
comment on column T_100179_NU_MAC_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100179_NU_MAC_ALLSERVER.channelid
  is '����ID';
comment on column T_100179_NU_MAC_ALLSERVER.gameversion
  is '��Ϸ�汾';
comment on column T_100179_NU_MAC_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100179_NU_MAC_ALLSERVER.position
  is 'λ����Ϣ';
comment on column T_100179_NU_MAC_ALLSERVER.dvid
  is '�豸ID';
create index IDX196_100179 on T_100179_NU_MAC_ALLSERVER (CHANNELID);
create index IDX197_100179 on T_100179_NU_MAC_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100179_NU_PAY
prompt ==============================
prompt
create table T_100179_NU_PAY
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100179_NU_PAY
  is '�����û���';
comment on column T_100179_NU_PAY.thedate
  is '����ʱ��';
comment on column T_100179_NU_PAY.gameid
  is '��ϷID';
comment on column T_100179_NU_PAY.channelid
  is '����ID';
comment on column T_100179_NU_PAY.gameversion
  is '��Ϸ�汾';
comment on column T_100179_NU_PAY.serverid
  is '������Ϣ';
comment on column T_100179_NU_PAY.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100179_NU_PAY.position
  is 'λ����Ϣ';
comment on column T_100179_NU_PAY.accountid
  is '�˺�ID';
comment on column T_100179_NU_PAY.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100179_NU_PAY.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX151_100179 on T_100179_NU_PAY (CHANNELID);
create index IDX152_100179 on T_100179_NU_PAY (SERVERID);
create index IDX153_100179 on T_100179_NU_PAY (THEDATE);

prompt
prompt Creating table T_100179_NU_PAY_AS
prompt =================================
prompt
create table T_100179_NU_PAY_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100179_NU_PAY_AS
  is '�����û���allsever';
comment on column T_100179_NU_PAY_AS.thedate
  is '����ʱ��';
comment on column T_100179_NU_PAY_AS.gameid
  is '��ϷID';
comment on column T_100179_NU_PAY_AS.channelid
  is '����ID';
comment on column T_100179_NU_PAY_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100179_NU_PAY_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100179_NU_PAY_AS.position
  is 'λ����Ϣ';
comment on column T_100179_NU_PAY_AS.accountid
  is '�˺�ID';
comment on column T_100179_NU_PAY_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100179_NU_PAY_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX198_100179 on T_100179_NU_PAY_AS (CHANNELID);
create index IDX199_100179 on T_100179_NU_PAY_AS (THEDATE);

prompt
prompt Creating table T_100179_NU_PAY_MAC
prompt ==================================
prompt
create table T_100179_NU_PAY_MAC
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100179_NU_PAY_MAC
  is '�����û���';
comment on column T_100179_NU_PAY_MAC.thedate
  is '����ʱ��';
comment on column T_100179_NU_PAY_MAC.gameid
  is '��ϷID';
comment on column T_100179_NU_PAY_MAC.channelid
  is '����ID';
comment on column T_100179_NU_PAY_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100179_NU_PAY_MAC.serverid
  is '������Ϣ';
comment on column T_100179_NU_PAY_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100179_NU_PAY_MAC.position
  is 'λ����Ϣ';
comment on column T_100179_NU_PAY_MAC.dvid
  is '�豸ID';
comment on column T_100179_NU_PAY_MAC.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100179_NU_PAY_MAC.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX154_100179 on T_100179_NU_PAY_MAC (CHANNELID);
create index IDX155_100179 on T_100179_NU_PAY_MAC (SERVERID);
create index IDX156_100179 on T_100179_NU_PAY_MAC (THEDATE);

prompt
prompt Creating table T_100179_NU_PAY_MAC_AS
prompt =====================================
prompt
create table T_100179_NU_PAY_MAC_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100179_NU_PAY_MAC_AS
  is '�����û���ALLSERVER';
comment on column T_100179_NU_PAY_MAC_AS.thedate
  is '����ʱ��';
comment on column T_100179_NU_PAY_MAC_AS.gameid
  is '��ϷID';
comment on column T_100179_NU_PAY_MAC_AS.channelid
  is '����ID';
comment on column T_100179_NU_PAY_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100179_NU_PAY_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100179_NU_PAY_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100179_NU_PAY_MAC_AS.dvid
  is '�豸ID';
comment on column T_100179_NU_PAY_MAC_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100179_NU_PAY_MAC_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX200_100179 on T_100179_NU_PAY_MAC_AS (CHANNELID);
create index IDX201_100179 on T_100179_NU_PAY_MAC_AS (THEDATE);

prompt
prompt Creating table T_100179_ORDER_FAILURE
prompt =====================================
prompt
create table T_100179_ORDER_FAILURE
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100179_ORDER_FAILURE
  is '��ֵ�ɹ���¼��';
comment on column T_100179_ORDER_FAILURE.thedate
  is '��ֵʱ��';
comment on column T_100179_ORDER_FAILURE.gameid
  is '��ϷID';
comment on column T_100179_ORDER_FAILURE.channelid
  is '����ID';
comment on column T_100179_ORDER_FAILURE.gameversion
  is '��Ϸ�汾';
comment on column T_100179_ORDER_FAILURE.serverid
  is '��������';
comment on column T_100179_ORDER_FAILURE.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100179_ORDER_FAILURE.position
  is 'λ����Ϣ';
comment on column T_100179_ORDER_FAILURE.dvid
  is '�豸��';
comment on column T_100179_ORDER_FAILURE.accountid
  is '�˺�';
comment on column T_100179_ORDER_FAILURE.money
  is '��ֵ���';
comment on column T_100179_ORDER_FAILURE.vc
  is '��ֵ��õ����������';
comment on column T_100179_ORDER_FAILURE.orderid
  is '������';
comment on column T_100179_ORDER_FAILURE.paychannel
  is '֧������';
comment on column T_100179_ORDER_FAILURE.iapid
  is '��ֵ����  30  60';
create index IDX157_100179 on T_100179_ORDER_FAILURE (CHANNELID);
create index IDX158_100179 on T_100179_ORDER_FAILURE (SERVERID);
create index IDX159_100179 on T_100179_ORDER_FAILURE (THEDATE);

prompt
prompt Creating table T_100179_ORDER_SUCC
prompt ==================================
prompt
create table T_100179_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100179_ORDER_SUCC
  is '��ֵ�ɹ���¼��';
comment on column T_100179_ORDER_SUCC.thedate
  is '��ֵʱ��';
comment on column T_100179_ORDER_SUCC.gameid
  is '��ϷID';
comment on column T_100179_ORDER_SUCC.channelid
  is '����ID';
comment on column T_100179_ORDER_SUCC.gameversion
  is '��Ϸ�汾';
comment on column T_100179_ORDER_SUCC.serverid
  is '��������';
comment on column T_100179_ORDER_SUCC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100179_ORDER_SUCC.position
  is 'λ����Ϣ';
comment on column T_100179_ORDER_SUCC.dvid
  is '�豸��';
comment on column T_100179_ORDER_SUCC.accountid
  is '�˺�';
comment on column T_100179_ORDER_SUCC.money
  is '��ֵ���';
comment on column T_100179_ORDER_SUCC.vc
  is '��ֵ��õ����������';
comment on column T_100179_ORDER_SUCC.orderid
  is '������';
comment on column T_100179_ORDER_SUCC.paychannel
  is '֧������';
comment on column T_100179_ORDER_SUCC.iapid
  is '��ֵ����  30  60';
create index IDX160_100179 on T_100179_ORDER_SUCC (CHANNELID);
create index IDX161_100179 on T_100179_ORDER_SUCC (SERVERID);
create index IDX162_100179 on T_100179_ORDER_SUCC (THEDATE);

prompt
prompt Creating table T_100179_VC
prompt ==========================
prompt
create table T_100179_VC
(
  statdate    DATE,
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcchange    NUMBER,
  vcbefore    NUMBER,
  vcafter     NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100179_VC
  is '������ұ仯������';
comment on column T_100179_VC.statdate
  is 'ͳ������';
comment on column T_100179_VC.channelid
  is '����';
comment on column T_100179_VC.serverid
  is '����';
comment on column T_100179_VC.appid
  is '��Ʒid';
comment on column T_100179_VC.versionid
  is '��Ʒ�汾';
comment on column T_100179_VC.accountid
  is '�û�ID';
comment on column T_100179_VC.vctype
  is '�����������';
comment on column T_100179_VC.vcusetype
  is '�������ʹ������';
comment on column T_100179_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column T_100179_VC.vcchange
  is '������ұ仯���';
comment on column T_100179_VC.vcbefore
  is '������ұ仯ǰ���';
comment on column T_100179_VC.vcafter
  is '������ұ仯����';
comment on column T_100179_VC.data_source
  is '������Դ';
create index IDX163_100179 on T_100179_VC (CHANNELID);
create index IDX164_100179 on T_100179_VC (SERVERID);
create index IDX165_100179 on T_100179_VC (STATDATE);

prompt
prompt Creating table T_100181_CEVENT
prompt ==============================
prompt
create table T_100181_CEVENT
(
  thedate          VARCHAR2(10),
  datenum          NUMBER,
  appid            VARCHAR2(10),
  channelid        VARCHAR2(50),
  gameversion      VARCHAR2(50),
  dvid             VARCHAR2(50),
  accountid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  ilevel           NUMBER,
  roleid           VARCHAR2(50),
  eventkey         VARCHAR2(100),
  eventvalue_key   VARCHAR2(100),
  eventvalue_value VARCHAR2(100),
  ipaddr           VARCHAR2(50),
  prerowid         VARCHAR2(200)
)
;
comment on table T_100181_CEVENT
  is '�Զ����¼���ֱ�';
comment on column T_100181_CEVENT.thedate
  is '����';
comment on column T_100181_CEVENT.datenum
  is '�������ָ�ʽ';
comment on column T_100181_CEVENT.appid
  is '��Ϸ�� appid';
comment on column T_100181_CEVENT.channelid
  is '���� ID';
comment on column T_100181_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column T_100181_CEVENT.dvid
  is '�豸 ID��Ψһ�豸��';
comment on column T_100181_CEVENT.accountid
  is '�ʻ� id';
comment on column T_100181_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column T_100181_CEVENT.ilevel
  is '��ҵȼ�';
comment on column T_100181_CEVENT.roleid
  is '��ɫ id';
comment on column T_100181_CEVENT.eventkey
  is '�¼�����';
comment on column T_100181_CEVENT.eventvalue_key
  is '�¼�ֵ�е�key';
comment on column T_100181_CEVENT.eventvalue_value
  is '�¼�ֵ��key��Ӧ��ֵ';
comment on column T_100181_CEVENT.ipaddr
  is 'ip ��ַ';
comment on column T_100181_CEVENT.prerowid
  is 'ԭΨһ��ID';
create index IDX180_100181 on T_100181_CEVENT (THEDATE);

prompt
prompt Creating table T_100181_CONN
prompt ============================
prompt
create table T_100181_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100181_CONN
  is '����&��ʧ&������������������ע���˺ţ�ע���豸��';
comment on column T_100181_CONN.conndate
  is '����ʱ��';
comment on column T_100181_CONN.gameid
  is '��ϷID';
comment on column T_100181_CONN.channelid
  is '����ID';
comment on column T_100181_CONN.gameversion
  is '��Ϸ�汾';
comment on column T_100181_CONN.serverid
  is '����ID';
comment on column T_100181_CONN.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100181_CONN.position
  is 'λ����Ϣ';
comment on column T_100181_CONN.dvid
  is '�豸��';
comment on column T_100181_CONN.accountid
  is '�˺�ID';
comment on column T_100181_CONN.regdate
  is 'ע��ʱ��';
comment on column T_100181_CONN.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100181_CONN.regdate_as
  is '���з��������ע��ʱ��';
create index IDX118_100181 on T_100181_CONN (CHANNELID);
create index IDX119_100181 on T_100181_CONN (SERVERID);
create index IDX120_100181 on T_100181_CONN (CONNDATE);

prompt
prompt Creating table T_100181_CONN_ACT
prompt ================================
prompt
create table T_100181_CONN_ACT
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100181_CONN_ACT
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100181_CONN_ACT.basedate
  is '����ʱ��';
comment on column T_100181_CONN_ACT.gameid
  is '��ϷID';
comment on column T_100181_CONN_ACT.channelid
  is '����ID';
comment on column T_100181_CONN_ACT.gameversion
  is '��Ϸ�汾';
comment on column T_100181_CONN_ACT.serverid
  is '����ID';
comment on column T_100181_CONN_ACT.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100181_CONN_ACT.position
  is 'λ����Ϣ';
comment on column T_100181_CONN_ACT.dvid
  is '�豸��';
comment on column T_100181_CONN_ACT.accountid
  is '�˺�';
comment on column T_100181_CONN_ACT.conndate
  is '��Ծʱ��';
comment on column T_100181_CONN_ACT.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_100181 on T_100181_CONN_ACT (CHANNELID);
create index IDX122_100181 on T_100181_CONN_ACT (SERVERID);
create index IDX123_100181 on T_100181_CONN_ACT (CONNDATE);
create index IDX124_100181 on T_100181_CONN_ACT (BASEDATE);

prompt
prompt Creating table T_100181_CONN_ACT_AS
prompt ===================================
prompt
create table T_100181_CONN_ACT_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100181_CONN_ACT_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100181_CONN_ACT_AS.basedate
  is '����ʱ��';
comment on column T_100181_CONN_ACT_AS.gameid
  is '��ϷID';
comment on column T_100181_CONN_ACT_AS.channelid
  is '����ID';
comment on column T_100181_CONN_ACT_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100181_CONN_ACT_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100181_CONN_ACT_AS.position
  is 'λ����Ϣ';
comment on column T_100181_CONN_ACT_AS.dvid
  is '�豸��';
comment on column T_100181_CONN_ACT_AS.accountid
  is '�˺�';
comment on column T_100181_CONN_ACT_AS.conndate
  is '��Ծʱ��';
comment on column T_100181_CONN_ACT_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX205_100181 on T_100181_CONN_ACT_AS (CHANNELID);
create index IDX206_100181 on T_100181_CONN_ACT_AS (CONNDATE);
create index IDX207_100181 on T_100181_CONN_ACT_AS (BASEDATE);

prompt
prompt Creating table T_100181_CONN_ACT_MAC
prompt ====================================
prompt
create table T_100181_CONN_ACT_MAC
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100181_CONN_ACT_MAC
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100181_CONN_ACT_MAC.basedate
  is '����ʱ��';
comment on column T_100181_CONN_ACT_MAC.gameid
  is '��ϷID';
comment on column T_100181_CONN_ACT_MAC.channelid
  is '����ID';
comment on column T_100181_CONN_ACT_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100181_CONN_ACT_MAC.serverid
  is '����ID';
comment on column T_100181_CONN_ACT_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100181_CONN_ACT_MAC.position
  is 'λ����Ϣ';
comment on column T_100181_CONN_ACT_MAC.dvid
  is '�豸��';
comment on column T_100181_CONN_ACT_MAC.accountid
  is '�˺�';
comment on column T_100181_CONN_ACT_MAC.conndate
  is '��Ծʱ��';
comment on column T_100181_CONN_ACT_MAC.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_100181 on T_100181_CONN_ACT_MAC (CHANNELID);
create index IDX126_100181 on T_100181_CONN_ACT_MAC (SERVERID);
create index IDX127_100181 on T_100181_CONN_ACT_MAC (CONNDATE);
create index IDX128_100181 on T_100181_CONN_ACT_MAC (BASEDATE);

prompt
prompt Creating table T_100181_CONN_ACT_MAC_AS
prompt =======================================
prompt
create table T_100181_CONN_ACT_MAC_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100181_CONN_ACT_MAC_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100181_CONN_ACT_MAC_AS.basedate
  is '����ʱ��';
comment on column T_100181_CONN_ACT_MAC_AS.gameid
  is '��ϷID';
comment on column T_100181_CONN_ACT_MAC_AS.channelid
  is '����ID';
comment on column T_100181_CONN_ACT_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100181_CONN_ACT_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100181_CONN_ACT_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100181_CONN_ACT_MAC_AS.dvid
  is '�豸��';
comment on column T_100181_CONN_ACT_MAC_AS.accountid
  is '�˺�';
comment on column T_100181_CONN_ACT_MAC_AS.conndate
  is '��Ծʱ��';
comment on column T_100181_CONN_ACT_MAC_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX202_100181 on T_100181_CONN_ACT_MAC_AS (CHANNELID);
create index IDX203_100181 on T_100181_CONN_ACT_MAC_AS (CONNDATE);
create index IDX204_100181 on T_100181_CONN_ACT_MAC_AS (BASEDATE);

prompt
prompt Creating table T_100181_CONN_DVID
prompt =================================
prompt
create table T_100181_CONN_DVID
(
  conndate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  dvid      VARCHAR2(50),
  regdate   VARCHAR2(10)
)
;
comment on table T_100181_CONN_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100181_CONN_DVID.conndate
  is '����ʱ��';
comment on column T_100181_CONN_DVID.gameid
  is '��ϷID';
comment on column T_100181_CONN_DVID.channelid
  is '����ID';
comment on column T_100181_CONN_DVID.dvid
  is '�豸��';
comment on column T_100181_CONN_DVID.regdate
  is 'ע��ʱ��';
create index IDX129_100181 on T_100181_CONN_DVID (CHANNELID);
create index IDX130_100181 on T_100181_CONN_DVID (CONNDATE);

prompt
prompt Creating table T_100181_CONN_MAC
prompt ================================
prompt
create table T_100181_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100181_CONN_MAC
  is '���� ��ʧ ������������������ע���˺ţ�ע���豸��';
comment on column T_100181_CONN_MAC.conndate
  is '����ʱ��';
comment on column T_100181_CONN_MAC.gameid
  is '��ϷID';
comment on column T_100181_CONN_MAC.channelid
  is '����ID';
comment on column T_100181_CONN_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100181_CONN_MAC.serverid
  is '����ID';
comment on column T_100181_CONN_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100181_CONN_MAC.position
  is 'λ����Ϣ';
comment on column T_100181_CONN_MAC.dvid
  is '�豸��';
comment on column T_100181_CONN_MAC.accountid
  is '�˺�ID';
comment on column T_100181_CONN_MAC.regdate
  is 'ע��ʱ��';
comment on column T_100181_CONN_MAC.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100181_CONN_MAC.regdate_as
  is '���з��������ע��ʱ��';
create index IDX131_100181 on T_100181_CONN_MAC (CHANNELID);
create index IDX132_100181 on T_100181_CONN_MAC (SERVERID);
create index IDX133_100181 on T_100181_CONN_MAC (CONNDATE);

prompt
prompt Creating table T_100181_LOST_MAC
prompt ================================
prompt
create table T_100181_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100181_LOST_MAC
  is '�豸�ȼ���ʧ������';
comment on column T_100181_LOST_MAC.statdate
  is '�����������';
comment on column T_100181_LOST_MAC.lost_date
  is '��ʧ����';
comment on column T_100181_LOST_MAC.channelid
  is '����';
comment on column T_100181_LOST_MAC.serverid
  is '����';
comment on column T_100181_LOST_MAC.appid
  is '��Ʒid';
comment on column T_100181_LOST_MAC.macid
  is '�豸id';
comment on column T_100181_LOST_MAC.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100181_LOST_MAC.lost_days
  is '��ʧ����';
comment on column T_100181_LOST_MAC.data_source
  is '������Դ';
create index IDX134_100181 on T_100181_LOST_MAC (CHANNELID);
create index IDX135_100181 on T_100181_LOST_MAC (SERVERID);
create index IDX136_100181 on T_100181_LOST_MAC (STATDATE);

prompt
prompt Creating table T_100181_LOST_MAC_AS
prompt ===================================
prompt
create table T_100181_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100181_LOST_MAC_AS
  is '�豸�ȼ���ʧ������allserver';
comment on column T_100181_LOST_MAC_AS.statdate
  is '�����������';
comment on column T_100181_LOST_MAC_AS.lost_date
  is '��ʧ����';
comment on column T_100181_LOST_MAC_AS.channelid
  is '����';
comment on column T_100181_LOST_MAC_AS.appid
  is '��Ʒid';
comment on column T_100181_LOST_MAC_AS.macid
  is '�豸id';
comment on column T_100181_LOST_MAC_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100181_LOST_MAC_AS.lost_days
  is '��ʧ����';
comment on column T_100181_LOST_MAC_AS.data_source
  is '������Դ';
create index IDX210_100181 on T_100181_LOST_MAC_AS (CHANNELID);
create index IDX211_100181 on T_100181_LOST_MAC_AS (STATDATE);

prompt
prompt Creating table T_100181_LOST_USER
prompt =================================
prompt
create table T_100181_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100181_LOST_USER
  is '�û��ȼ���ʧ������';
comment on column T_100181_LOST_USER.statdate
  is '�����������';
comment on column T_100181_LOST_USER.lost_date
  is '��ʧ����';
comment on column T_100181_LOST_USER.channelid
  is '����';
comment on column T_100181_LOST_USER.serverid
  is '����';
comment on column T_100181_LOST_USER.appid
  is '��Ʒid';
comment on column T_100181_LOST_USER.userid
  is '�û�id';
comment on column T_100181_LOST_USER.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100181_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100181_LOST_USER.lost_days
  is '��ʧ����';
comment on column T_100181_LOST_USER.data_source
  is '������Դ';
create index IDX137_100181 on T_100181_LOST_USER (CHANNELID);
create index IDX138_100181 on T_100181_LOST_USER (SERVERID);
create index IDX139_100181 on T_100181_LOST_USER (STATDATE);

prompt
prompt Creating table T_100181_LOST_USER_AS
prompt ====================================
prompt
create table T_100181_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100181_LOST_USER_AS
  is '�û��ȼ���ʧ������allserver';
comment on column T_100181_LOST_USER_AS.statdate
  is '�����������';
comment on column T_100181_LOST_USER_AS.lost_date
  is '��ʧ����';
comment on column T_100181_LOST_USER_AS.channelid
  is '����';
comment on column T_100181_LOST_USER_AS.appid
  is '��Ʒid';
comment on column T_100181_LOST_USER_AS.userid
  is '�û�id';
comment on column T_100181_LOST_USER_AS.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100181_LOST_USER_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100181_LOST_USER_AS.lost_days
  is '��ʧ����';
comment on column T_100181_LOST_USER_AS.data_source
  is '������Դ';
create index IDX208_100181 on T_100181_LOST_USER_AS (CHANNELID);
create index IDX209_100181 on T_100181_LOST_USER_AS (STATDATE);

prompt
prompt Creating table T_100181_MISS_FIRST
prompt ==================================
prompt
create table T_100181_MISS_FIRST
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50) default '0',
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100181_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column T_100181_MISS_FIRST.statdate
  is 'ͳ������';
comment on column T_100181_MISS_FIRST.channelid
  is '����';
comment on column T_100181_MISS_FIRST.serverid
  is '����';
comment on column T_100181_MISS_FIRST.appid
  is '��ƷID';
comment on column T_100181_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column T_100181_MISS_FIRST.accountid
  is '�û�ID';
comment on column T_100181_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100181_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column T_100181_MISS_FIRST.issucc
  is '�Ƿ���ͨ��';
comment on column T_100181_MISS_FIRST.data_source
  is '������Դ';
create index IDX140_100181 on T_100181_MISS_FIRST (CHANNELID);
create index IDX141_100181 on T_100181_MISS_FIRST (SERVERID);
create index IDX142_100181 on T_100181_MISS_FIRST (STATDATE);

prompt
prompt Creating table T_100181_NU
prompt ==========================
prompt
create table T_100181_NU
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100181_NU
  is '�����û���Ϣ��';
comment on column T_100181_NU.thedate
  is '��������';
comment on column T_100181_NU.gameid
  is '��ϷID';
comment on column T_100181_NU.channelid
  is '����ID';
comment on column T_100181_NU.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100181_NU.serverid
  is '���ڷ�ID';
comment on column T_100181_NU.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100181_NU.position
  is '����λ��';
comment on column T_100181_NU.accountid
  is '�˺�ID';
create index IDX143_100181 on T_100181_NU (CHANNELID);
create index IDX144_100181 on T_100181_NU (SERVERID);
create index IDX145_100181 on T_100181_NU (THEDATE);

prompt
prompt Creating table T_100181_NU_ALLSERVER
prompt ====================================
prompt
create table T_100181_NU_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100181_NU_ALLSERVER
  is '�����û���Ϣ��ALLSERVER';
comment on column T_100181_NU_ALLSERVER.thedate
  is '��������';
comment on column T_100181_NU_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100181_NU_ALLSERVER.channelid
  is '����ID';
comment on column T_100181_NU_ALLSERVER.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100181_NU_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100181_NU_ALLSERVER.position
  is '����λ��';
comment on column T_100181_NU_ALLSERVER.accountid
  is '�˺�ID';
create index IDX194_100181 on T_100181_NU_ALLSERVER (CHANNELID);
create index IDX195_100181 on T_100181_NU_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100181_NU_DVID
prompt ===============================
prompt
create table T_100181_NU_DVID
(
  thedate   DATE not null,
  gameid    VARCHAR2(20) not null,
  channelid VARCHAR2(20) not null,
  dvid      VARCHAR2(50) not null,
  ipaddr    VARCHAR2(50)
)
;
comment on table T_100181_NU_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100181_NU_DVID.thedate
  is '����ʱ��';
comment on column T_100181_NU_DVID.gameid
  is '��ϷID';
comment on column T_100181_NU_DVID.channelid
  is '����ID';
comment on column T_100181_NU_DVID.dvid
  is '�豸ID';
comment on column T_100181_NU_DVID.ipaddr
  is 'IP';
create index IDX146_100181 on T_100181_NU_DVID (CHANNELID);
create index IDX147_100181 on T_100181_NU_DVID (THEDATE);

prompt
prompt Creating table T_100181_NU_MAC
prompt ==============================
prompt
create table T_100181_NU_MAC
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100181_NU_MAC
  is '�豸������';
comment on column T_100181_NU_MAC.thedate
  is '����ʱ��';
comment on column T_100181_NU_MAC.gameid
  is '��ϷID';
comment on column T_100181_NU_MAC.channelid
  is '����ID';
comment on column T_100181_NU_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100181_NU_MAC.serverid
  is '��������ID';
comment on column T_100181_NU_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100181_NU_MAC.position
  is 'λ����Ϣ';
comment on column T_100181_NU_MAC.dvid
  is '�豸ID';
create index IDX148_100181 on T_100181_NU_MAC (CHANNELID);
create index IDX149_100181 on T_100181_NU_MAC (SERVERID);
create index IDX150_100181 on T_100181_NU_MAC (THEDATE);

prompt
prompt Creating table T_100181_NU_MAC_ALLSERVER
prompt ========================================
prompt
create table T_100181_NU_MAC_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100181_NU_MAC_ALLSERVER
  is '�豸������ALLSERVER';
comment on column T_100181_NU_MAC_ALLSERVER.thedate
  is '����ʱ��';
comment on column T_100181_NU_MAC_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100181_NU_MAC_ALLSERVER.channelid
  is '����ID';
comment on column T_100181_NU_MAC_ALLSERVER.gameversion
  is '��Ϸ�汾';
comment on column T_100181_NU_MAC_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100181_NU_MAC_ALLSERVER.position
  is 'λ����Ϣ';
comment on column T_100181_NU_MAC_ALLSERVER.dvid
  is '�豸ID';
create index IDX196_100181 on T_100181_NU_MAC_ALLSERVER (CHANNELID);
create index IDX197_100181 on T_100181_NU_MAC_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100181_NU_PAY
prompt ==============================
prompt
create table T_100181_NU_PAY
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100181_NU_PAY
  is '�����û���';
comment on column T_100181_NU_PAY.thedate
  is '����ʱ��';
comment on column T_100181_NU_PAY.gameid
  is '��ϷID';
comment on column T_100181_NU_PAY.channelid
  is '����ID';
comment on column T_100181_NU_PAY.gameversion
  is '��Ϸ�汾';
comment on column T_100181_NU_PAY.serverid
  is '������Ϣ';
comment on column T_100181_NU_PAY.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100181_NU_PAY.position
  is 'λ����Ϣ';
comment on column T_100181_NU_PAY.accountid
  is '�˺�ID';
comment on column T_100181_NU_PAY.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100181_NU_PAY.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX151_100181 on T_100181_NU_PAY (CHANNELID);
create index IDX152_100181 on T_100181_NU_PAY (SERVERID);
create index IDX153_100181 on T_100181_NU_PAY (THEDATE);

prompt
prompt Creating table T_100181_NU_PAY_AS
prompt =================================
prompt
create table T_100181_NU_PAY_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100181_NU_PAY_AS
  is '�����û���allsever';
comment on column T_100181_NU_PAY_AS.thedate
  is '����ʱ��';
comment on column T_100181_NU_PAY_AS.gameid
  is '��ϷID';
comment on column T_100181_NU_PAY_AS.channelid
  is '����ID';
comment on column T_100181_NU_PAY_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100181_NU_PAY_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100181_NU_PAY_AS.position
  is 'λ����Ϣ';
comment on column T_100181_NU_PAY_AS.accountid
  is '�˺�ID';
comment on column T_100181_NU_PAY_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100181_NU_PAY_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX198_100181 on T_100181_NU_PAY_AS (CHANNELID);
create index IDX199_100181 on T_100181_NU_PAY_AS (THEDATE);

prompt
prompt Creating table T_100181_NU_PAY_MAC
prompt ==================================
prompt
create table T_100181_NU_PAY_MAC
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100181_NU_PAY_MAC
  is '�����û���';
comment on column T_100181_NU_PAY_MAC.thedate
  is '����ʱ��';
comment on column T_100181_NU_PAY_MAC.gameid
  is '��ϷID';
comment on column T_100181_NU_PAY_MAC.channelid
  is '����ID';
comment on column T_100181_NU_PAY_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100181_NU_PAY_MAC.serverid
  is '������Ϣ';
comment on column T_100181_NU_PAY_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100181_NU_PAY_MAC.position
  is 'λ����Ϣ';
comment on column T_100181_NU_PAY_MAC.dvid
  is '�豸ID';
comment on column T_100181_NU_PAY_MAC.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100181_NU_PAY_MAC.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX154_100181 on T_100181_NU_PAY_MAC (CHANNELID);
create index IDX155_100181 on T_100181_NU_PAY_MAC (SERVERID);
create index IDX156_100181 on T_100181_NU_PAY_MAC (THEDATE);

prompt
prompt Creating table T_100181_NU_PAY_MAC_AS
prompt =====================================
prompt
create table T_100181_NU_PAY_MAC_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100181_NU_PAY_MAC_AS
  is '�����û���ALLSERVER';
comment on column T_100181_NU_PAY_MAC_AS.thedate
  is '����ʱ��';
comment on column T_100181_NU_PAY_MAC_AS.gameid
  is '��ϷID';
comment on column T_100181_NU_PAY_MAC_AS.channelid
  is '����ID';
comment on column T_100181_NU_PAY_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100181_NU_PAY_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100181_NU_PAY_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100181_NU_PAY_MAC_AS.dvid
  is '�豸ID';
comment on column T_100181_NU_PAY_MAC_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100181_NU_PAY_MAC_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX200_100181 on T_100181_NU_PAY_MAC_AS (CHANNELID);
create index IDX201_100181 on T_100181_NU_PAY_MAC_AS (THEDATE);

prompt
prompt Creating table T_100181_ORDER_FAILURE
prompt =====================================
prompt
create table T_100181_ORDER_FAILURE
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100181_ORDER_FAILURE
  is '��ֵ�ɹ���¼��';
comment on column T_100181_ORDER_FAILURE.thedate
  is '��ֵʱ��';
comment on column T_100181_ORDER_FAILURE.gameid
  is '��ϷID';
comment on column T_100181_ORDER_FAILURE.channelid
  is '����ID';
comment on column T_100181_ORDER_FAILURE.gameversion
  is '��Ϸ�汾';
comment on column T_100181_ORDER_FAILURE.serverid
  is '��������';
comment on column T_100181_ORDER_FAILURE.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100181_ORDER_FAILURE.position
  is 'λ����Ϣ';
comment on column T_100181_ORDER_FAILURE.dvid
  is '�豸��';
comment on column T_100181_ORDER_FAILURE.accountid
  is '�˺�';
comment on column T_100181_ORDER_FAILURE.money
  is '��ֵ���';
comment on column T_100181_ORDER_FAILURE.vc
  is '��ֵ��õ����������';
comment on column T_100181_ORDER_FAILURE.orderid
  is '������';
comment on column T_100181_ORDER_FAILURE.paychannel
  is '֧������';
comment on column T_100181_ORDER_FAILURE.iapid
  is '��ֵ����  30  60';
create index IDX157_100181 on T_100181_ORDER_FAILURE (CHANNELID);
create index IDX158_100181 on T_100181_ORDER_FAILURE (SERVERID);
create index IDX159_100181 on T_100181_ORDER_FAILURE (THEDATE);

prompt
prompt Creating table T_100181_ORDER_SUCC
prompt ==================================
prompt
create table T_100181_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100181_ORDER_SUCC
  is '��ֵ�ɹ���¼��';
comment on column T_100181_ORDER_SUCC.thedate
  is '��ֵʱ��';
comment on column T_100181_ORDER_SUCC.gameid
  is '��ϷID';
comment on column T_100181_ORDER_SUCC.channelid
  is '����ID';
comment on column T_100181_ORDER_SUCC.gameversion
  is '��Ϸ�汾';
comment on column T_100181_ORDER_SUCC.serverid
  is '��������';
comment on column T_100181_ORDER_SUCC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100181_ORDER_SUCC.position
  is 'λ����Ϣ';
comment on column T_100181_ORDER_SUCC.dvid
  is '�豸��';
comment on column T_100181_ORDER_SUCC.accountid
  is '�˺�';
comment on column T_100181_ORDER_SUCC.money
  is '��ֵ���';
comment on column T_100181_ORDER_SUCC.vc
  is '��ֵ��õ����������';
comment on column T_100181_ORDER_SUCC.orderid
  is '������';
comment on column T_100181_ORDER_SUCC.paychannel
  is '֧������';
comment on column T_100181_ORDER_SUCC.iapid
  is '��ֵ����  30  60';
create index IDX160_100181 on T_100181_ORDER_SUCC (CHANNELID);
create index IDX161_100181 on T_100181_ORDER_SUCC (SERVERID);
create index IDX162_100181 on T_100181_ORDER_SUCC (THEDATE);

prompt
prompt Creating table T_100181_VC
prompt ==========================
prompt
create table T_100181_VC
(
  statdate    DATE,
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcchange    NUMBER,
  vcbefore    NUMBER,
  vcafter     NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100181_VC
  is '������ұ仯������';
comment on column T_100181_VC.statdate
  is 'ͳ������';
comment on column T_100181_VC.channelid
  is '����';
comment on column T_100181_VC.serverid
  is '����';
comment on column T_100181_VC.appid
  is '��Ʒid';
comment on column T_100181_VC.versionid
  is '��Ʒ�汾';
comment on column T_100181_VC.accountid
  is '�û�ID';
comment on column T_100181_VC.vctype
  is '�����������';
comment on column T_100181_VC.vcusetype
  is '�������ʹ������';
comment on column T_100181_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column T_100181_VC.vcchange
  is '������ұ仯���';
comment on column T_100181_VC.vcbefore
  is '������ұ仯ǰ���';
comment on column T_100181_VC.vcafter
  is '������ұ仯����';
comment on column T_100181_VC.data_source
  is '������Դ';
create index IDX163_100181 on T_100181_VC (CHANNELID);
create index IDX164_100181 on T_100181_VC (SERVERID);
create index IDX165_100181 on T_100181_VC (STATDATE);

prompt
prompt Creating table T_100190_CEVENT
prompt ==============================
prompt
create table T_100190_CEVENT
(
  thedate          VARCHAR2(10),
  datenum          NUMBER,
  appid            VARCHAR2(10),
  channelid        VARCHAR2(50),
  gameversion      VARCHAR2(50),
  dvid             VARCHAR2(50),
  accountid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  ilevel           NUMBER,
  roleid           VARCHAR2(50),
  eventkey         VARCHAR2(100),
  eventvalue_key   VARCHAR2(100),
  eventvalue_value VARCHAR2(100),
  ipaddr           VARCHAR2(50),
  prerowid         VARCHAR2(200)
)
;
comment on table T_100190_CEVENT
  is '�Զ����¼���ֱ�';
comment on column T_100190_CEVENT.thedate
  is '����';
comment on column T_100190_CEVENT.datenum
  is '�������ָ�ʽ';
comment on column T_100190_CEVENT.appid
  is '��Ϸ�� appid';
comment on column T_100190_CEVENT.channelid
  is '���� ID';
comment on column T_100190_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column T_100190_CEVENT.dvid
  is '�豸 ID��Ψһ�豸��';
comment on column T_100190_CEVENT.accountid
  is '�ʻ� id';
comment on column T_100190_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column T_100190_CEVENT.ilevel
  is '��ҵȼ�';
comment on column T_100190_CEVENT.roleid
  is '��ɫ id';
comment on column T_100190_CEVENT.eventkey
  is '�¼�����';
comment on column T_100190_CEVENT.eventvalue_key
  is '�¼�ֵ�е�key';
comment on column T_100190_CEVENT.eventvalue_value
  is '�¼�ֵ��key��Ӧ��ֵ';
comment on column T_100190_CEVENT.ipaddr
  is 'ip ��ַ';
comment on column T_100190_CEVENT.prerowid
  is 'ԭΨһ��ID';
create index IDX180_100190 on T_100190_CEVENT (THEDATE);

prompt
prompt Creating table T_100190_CEVENT20150414
prompt ======================================
prompt
create table T_100190_CEVENT20150414
(
  thedate          VARCHAR2(10),
  datenum          NUMBER,
  appid            VARCHAR2(10),
  channelid        VARCHAR2(50),
  gameversion      VARCHAR2(50),
  dvid             VARCHAR2(50),
  accountid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  ilevel           NUMBER,
  roleid           VARCHAR2(50),
  eventkey         VARCHAR2(100),
  eventvalue_key   VARCHAR2(100),
  eventvalue_value VARCHAR2(100),
  ipaddr           VARCHAR2(50),
  prerowid         VARCHAR2(200)
)
;

prompt
prompt Creating table T_100190_CONN
prompt ============================
prompt
create table T_100190_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100190_CONN
  is '����&��ʧ&������������������ע���˺ţ�ע���豸��';
comment on column T_100190_CONN.conndate
  is '����ʱ��';
comment on column T_100190_CONN.gameid
  is '��ϷID';
comment on column T_100190_CONN.channelid
  is '����ID';
comment on column T_100190_CONN.gameversion
  is '��Ϸ�汾';
comment on column T_100190_CONN.serverid
  is '����ID';
comment on column T_100190_CONN.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100190_CONN.position
  is 'λ����Ϣ';
comment on column T_100190_CONN.dvid
  is '�豸��';
comment on column T_100190_CONN.accountid
  is '�˺�ID';
comment on column T_100190_CONN.regdate
  is 'ע��ʱ��';
comment on column T_100190_CONN.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100190_CONN.regdate_as
  is '���з��������ע��ʱ��';
create index IDX118_100190 on T_100190_CONN (CHANNELID);
create index IDX119_100190 on T_100190_CONN (SERVERID);
create index IDX120_100190 on T_100190_CONN (CONNDATE);

prompt
prompt Creating table T_100190_CONN20150414
prompt ====================================
prompt
create table T_100190_CONN20150414
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;

prompt
prompt Creating table T_100190_CONN_ACT
prompt ================================
prompt
create table T_100190_CONN_ACT
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100190_CONN_ACT
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100190_CONN_ACT.basedate
  is '����ʱ��';
comment on column T_100190_CONN_ACT.gameid
  is '��ϷID';
comment on column T_100190_CONN_ACT.channelid
  is '����ID';
comment on column T_100190_CONN_ACT.gameversion
  is '��Ϸ�汾';
comment on column T_100190_CONN_ACT.serverid
  is '����ID';
comment on column T_100190_CONN_ACT.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100190_CONN_ACT.position
  is 'λ����Ϣ';
comment on column T_100190_CONN_ACT.dvid
  is '�豸��';
comment on column T_100190_CONN_ACT.accountid
  is '�˺�';
comment on column T_100190_CONN_ACT.conndate
  is '��Ծʱ��';
comment on column T_100190_CONN_ACT.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_100190 on T_100190_CONN_ACT (CHANNELID);
create index IDX122_100190 on T_100190_CONN_ACT (SERVERID);
create index IDX123_100190 on T_100190_CONN_ACT (CONNDATE);
create index IDX124_100190 on T_100190_CONN_ACT (BASEDATE);

prompt
prompt Creating table T_100190_CONN_ACT20150414
prompt ========================================
prompt
create table T_100190_CONN_ACT20150414
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;

prompt
prompt Creating table T_100190_CONN_ACT_AS
prompt ===================================
prompt
create table T_100190_CONN_ACT_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100190_CONN_ACT_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100190_CONN_ACT_AS.basedate
  is '����ʱ��';
comment on column T_100190_CONN_ACT_AS.gameid
  is '��ϷID';
comment on column T_100190_CONN_ACT_AS.channelid
  is '����ID';
comment on column T_100190_CONN_ACT_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100190_CONN_ACT_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100190_CONN_ACT_AS.position
  is 'λ����Ϣ';
comment on column T_100190_CONN_ACT_AS.dvid
  is '�豸��';
comment on column T_100190_CONN_ACT_AS.accountid
  is '�˺�';
comment on column T_100190_CONN_ACT_AS.conndate
  is '��Ծʱ��';
comment on column T_100190_CONN_ACT_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX205_100190 on T_100190_CONN_ACT_AS (CHANNELID);
create index IDX206_100190 on T_100190_CONN_ACT_AS (CONNDATE);
create index IDX207_100190 on T_100190_CONN_ACT_AS (BASEDATE);

prompt
prompt Creating table T_100190_CONN_ACT_MAC
prompt ====================================
prompt
create table T_100190_CONN_ACT_MAC
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100190_CONN_ACT_MAC
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100190_CONN_ACT_MAC.basedate
  is '����ʱ��';
comment on column T_100190_CONN_ACT_MAC.gameid
  is '��ϷID';
comment on column T_100190_CONN_ACT_MAC.channelid
  is '����ID';
comment on column T_100190_CONN_ACT_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100190_CONN_ACT_MAC.serverid
  is '����ID';
comment on column T_100190_CONN_ACT_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100190_CONN_ACT_MAC.position
  is 'λ����Ϣ';
comment on column T_100190_CONN_ACT_MAC.dvid
  is '�豸��';
comment on column T_100190_CONN_ACT_MAC.accountid
  is '�˺�';
comment on column T_100190_CONN_ACT_MAC.conndate
  is '��Ծʱ��';
comment on column T_100190_CONN_ACT_MAC.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_100190 on T_100190_CONN_ACT_MAC (CHANNELID);
create index IDX126_100190 on T_100190_CONN_ACT_MAC (SERVERID);
create index IDX127_100190 on T_100190_CONN_ACT_MAC (CONNDATE);
create index IDX128_100190 on T_100190_CONN_ACT_MAC (BASEDATE);

prompt
prompt Creating table T_100190_CONN_ACT_MAC20150414
prompt ============================================
prompt
create table T_100190_CONN_ACT_MAC20150414
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;

prompt
prompt Creating table T_100190_CONN_ACT_MAC_AS
prompt =======================================
prompt
create table T_100190_CONN_ACT_MAC_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100190_CONN_ACT_MAC_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100190_CONN_ACT_MAC_AS.basedate
  is '����ʱ��';
comment on column T_100190_CONN_ACT_MAC_AS.gameid
  is '��ϷID';
comment on column T_100190_CONN_ACT_MAC_AS.channelid
  is '����ID';
comment on column T_100190_CONN_ACT_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100190_CONN_ACT_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100190_CONN_ACT_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100190_CONN_ACT_MAC_AS.dvid
  is '�豸��';
comment on column T_100190_CONN_ACT_MAC_AS.accountid
  is '�˺�';
comment on column T_100190_CONN_ACT_MAC_AS.conndate
  is '��Ծʱ��';
comment on column T_100190_CONN_ACT_MAC_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX202_100190 on T_100190_CONN_ACT_MAC_AS (CHANNELID);
create index IDX203_100190 on T_100190_CONN_ACT_MAC_AS (CONNDATE);
create index IDX204_100190 on T_100190_CONN_ACT_MAC_AS (BASEDATE);

prompt
prompt Creating table T_100190_CONN_DVID
prompt =================================
prompt
create table T_100190_CONN_DVID
(
  conndate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  dvid      VARCHAR2(50),
  regdate   VARCHAR2(10)
)
;
comment on table T_100190_CONN_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100190_CONN_DVID.conndate
  is '����ʱ��';
comment on column T_100190_CONN_DVID.gameid
  is '��ϷID';
comment on column T_100190_CONN_DVID.channelid
  is '����ID';
comment on column T_100190_CONN_DVID.dvid
  is '�豸��';
comment on column T_100190_CONN_DVID.regdate
  is 'ע��ʱ��';
create index IDX129_100190 on T_100190_CONN_DVID (CHANNELID);
create index IDX130_100190 on T_100190_CONN_DVID (CONNDATE);

prompt
prompt Creating table T_100190_CONN_DVID20150414
prompt =========================================
prompt
create table T_100190_CONN_DVID20150414
(
  conndate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  dvid      VARCHAR2(50),
  regdate   VARCHAR2(10)
)
;

prompt
prompt Creating table T_100190_CONN_MAC
prompt ================================
prompt
create table T_100190_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100190_CONN_MAC
  is '���� ��ʧ ������������������ע���˺ţ�ע���豸��';
comment on column T_100190_CONN_MAC.conndate
  is '����ʱ��';
comment on column T_100190_CONN_MAC.gameid
  is '��ϷID';
comment on column T_100190_CONN_MAC.channelid
  is '����ID';
comment on column T_100190_CONN_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100190_CONN_MAC.serverid
  is '����ID';
comment on column T_100190_CONN_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100190_CONN_MAC.position
  is 'λ����Ϣ';
comment on column T_100190_CONN_MAC.dvid
  is '�豸��';
comment on column T_100190_CONN_MAC.accountid
  is '�˺�ID';
comment on column T_100190_CONN_MAC.regdate
  is 'ע��ʱ��';
comment on column T_100190_CONN_MAC.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100190_CONN_MAC.regdate_as
  is '���з��������ע��ʱ��';
create index IDX131_100190 on T_100190_CONN_MAC (CHANNELID);
create index IDX132_100190 on T_100190_CONN_MAC (SERVERID);
create index IDX133_100190 on T_100190_CONN_MAC (CONNDATE);

prompt
prompt Creating table T_100190_CONN_MAC20150414
prompt ========================================
prompt
create table T_100190_CONN_MAC20150414
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;

prompt
prompt Creating table T_100190_LOST_MAC
prompt ================================
prompt
create table T_100190_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100190_LOST_MAC
  is '�豸�ȼ���ʧ������';
comment on column T_100190_LOST_MAC.statdate
  is '�����������';
comment on column T_100190_LOST_MAC.lost_date
  is '��ʧ����';
comment on column T_100190_LOST_MAC.channelid
  is '����';
comment on column T_100190_LOST_MAC.serverid
  is '����';
comment on column T_100190_LOST_MAC.appid
  is '��Ʒid';
comment on column T_100190_LOST_MAC.macid
  is '�豸id';
comment on column T_100190_LOST_MAC.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100190_LOST_MAC.lost_days
  is '��ʧ����';
comment on column T_100190_LOST_MAC.data_source
  is '������Դ';
create index IDX134_100190 on T_100190_LOST_MAC (CHANNELID);
create index IDX135_100190 on T_100190_LOST_MAC (SERVERID);
create index IDX136_100190 on T_100190_LOST_MAC (STATDATE);

prompt
prompt Creating table T_100190_LOST_MAC20150414
prompt ========================================
prompt
create table T_100190_LOST_MAC20150414
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table T_100190_LOST_MAC_AS
prompt ===================================
prompt
create table T_100190_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100190_LOST_MAC_AS
  is '�豸�ȼ���ʧ������allserver';
comment on column T_100190_LOST_MAC_AS.statdate
  is '�����������';
comment on column T_100190_LOST_MAC_AS.lost_date
  is '��ʧ����';
comment on column T_100190_LOST_MAC_AS.channelid
  is '����';
comment on column T_100190_LOST_MAC_AS.appid
  is '��Ʒid';
comment on column T_100190_LOST_MAC_AS.macid
  is '�豸id';
comment on column T_100190_LOST_MAC_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100190_LOST_MAC_AS.lost_days
  is '��ʧ����';
comment on column T_100190_LOST_MAC_AS.data_source
  is '������Դ';
create index IDX210_100190 on T_100190_LOST_MAC_AS (CHANNELID);
create index IDX211_100190 on T_100190_LOST_MAC_AS (STATDATE);

prompt
prompt Creating table T_100190_LOST_USER
prompt =================================
prompt
create table T_100190_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100190_LOST_USER
  is '�û��ȼ���ʧ������';
comment on column T_100190_LOST_USER.statdate
  is '�����������';
comment on column T_100190_LOST_USER.lost_date
  is '��ʧ����';
comment on column T_100190_LOST_USER.channelid
  is '����';
comment on column T_100190_LOST_USER.serverid
  is '����';
comment on column T_100190_LOST_USER.appid
  is '��Ʒid';
comment on column T_100190_LOST_USER.userid
  is '�û�id';
comment on column T_100190_LOST_USER.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100190_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100190_LOST_USER.lost_days
  is '��ʧ����';
comment on column T_100190_LOST_USER.data_source
  is '������Դ';
create index IDX137_100190 on T_100190_LOST_USER (CHANNELID);
create index IDX138_100190 on T_100190_LOST_USER (SERVERID);
create index IDX139_100190 on T_100190_LOST_USER (STATDATE);

prompt
prompt Creating table T_100190_LOST_USER20150414
prompt =========================================
prompt
create table T_100190_LOST_USER20150414
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table T_100190_LOST_USER_AS
prompt ====================================
prompt
create table T_100190_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100190_LOST_USER_AS
  is '�û��ȼ���ʧ������allserver';
comment on column T_100190_LOST_USER_AS.statdate
  is '�����������';
comment on column T_100190_LOST_USER_AS.lost_date
  is '��ʧ����';
comment on column T_100190_LOST_USER_AS.channelid
  is '����';
comment on column T_100190_LOST_USER_AS.appid
  is '��Ʒid';
comment on column T_100190_LOST_USER_AS.userid
  is '�û�id';
comment on column T_100190_LOST_USER_AS.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100190_LOST_USER_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100190_LOST_USER_AS.lost_days
  is '��ʧ����';
comment on column T_100190_LOST_USER_AS.data_source
  is '������Դ';
create index IDX208_100190 on T_100190_LOST_USER_AS (CHANNELID);
create index IDX209_100190 on T_100190_LOST_USER_AS (STATDATE);

prompt
prompt Creating table T_100190_MISS_FIRST
prompt ==================================
prompt
create table T_100190_MISS_FIRST
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50) default '0',
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100190_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column T_100190_MISS_FIRST.statdate
  is 'ͳ������';
comment on column T_100190_MISS_FIRST.channelid
  is '����';
comment on column T_100190_MISS_FIRST.serverid
  is '����';
comment on column T_100190_MISS_FIRST.appid
  is '��ƷID';
comment on column T_100190_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column T_100190_MISS_FIRST.accountid
  is '�û�ID';
comment on column T_100190_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100190_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column T_100190_MISS_FIRST.issucc
  is '�Ƿ���ͨ��';
comment on column T_100190_MISS_FIRST.data_source
  is '������Դ';
create index IDX140_100190 on T_100190_MISS_FIRST (CHANNELID);
create index IDX141_100190 on T_100190_MISS_FIRST (SERVERID);
create index IDX142_100190 on T_100190_MISS_FIRST (STATDATE);

prompt
prompt Creating table T_100190_MISS_FIRST20150414
prompt ==========================================
prompt
create table T_100190_MISS_FIRST20150414
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50),
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table T_100190_NU
prompt ==========================
prompt
create table T_100190_NU
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100190_NU
  is '�����û���Ϣ��';
comment on column T_100190_NU.thedate
  is '��������';
comment on column T_100190_NU.gameid
  is '��ϷID';
comment on column T_100190_NU.channelid
  is '����ID';
comment on column T_100190_NU.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100190_NU.serverid
  is '���ڷ�ID';
comment on column T_100190_NU.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100190_NU.position
  is '����λ��';
comment on column T_100190_NU.accountid
  is '�˺�ID';
create index IDX143_100190 on T_100190_NU (CHANNELID);
create index IDX144_100190 on T_100190_NU (SERVERID);
create index IDX145_100190 on T_100190_NU (THEDATE);

prompt
prompt Creating table T_100190_NU20150414
prompt ==================================
prompt
create table T_100190_NU20150414
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;

prompt
prompt Creating table T_100190_NU_ALLSERVER
prompt ====================================
prompt
create table T_100190_NU_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100190_NU_ALLSERVER
  is '�����û���Ϣ��ALLSERVER';
comment on column T_100190_NU_ALLSERVER.thedate
  is '��������';
comment on column T_100190_NU_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100190_NU_ALLSERVER.channelid
  is '����ID';
comment on column T_100190_NU_ALLSERVER.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100190_NU_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100190_NU_ALLSERVER.position
  is '����λ��';
comment on column T_100190_NU_ALLSERVER.accountid
  is '�˺�ID';
create index IDX194_100190 on T_100190_NU_ALLSERVER (CHANNELID);
create index IDX195_100190 on T_100190_NU_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100190_NU_DVID
prompt ===============================
prompt
create table T_100190_NU_DVID
(
  thedate   DATE not null,
  gameid    VARCHAR2(20) not null,
  channelid VARCHAR2(20) not null,
  dvid      VARCHAR2(50) not null,
  ipaddr    VARCHAR2(50)
)
;
comment on table T_100190_NU_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100190_NU_DVID.thedate
  is '����ʱ��';
comment on column T_100190_NU_DVID.gameid
  is '��ϷID';
comment on column T_100190_NU_DVID.channelid
  is '����ID';
comment on column T_100190_NU_DVID.dvid
  is '�豸ID';
comment on column T_100190_NU_DVID.ipaddr
  is 'IP';
create index IDX146_100190 on T_100190_NU_DVID (CHANNELID);
create index IDX147_100190 on T_100190_NU_DVID (THEDATE);

prompt
prompt Creating table T_100190_NU_DVID20150414
prompt =======================================
prompt
create table T_100190_NU_DVID20150414
(
  thedate   DATE not null,
  gameid    VARCHAR2(20) not null,
  channelid VARCHAR2(20) not null,
  dvid      VARCHAR2(50) not null,
  ipaddr    VARCHAR2(50)
)
;

prompt
prompt Creating table T_100190_NU_MAC
prompt ==============================
prompt
create table T_100190_NU_MAC
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100190_NU_MAC
  is '�豸������';
comment on column T_100190_NU_MAC.thedate
  is '����ʱ��';
comment on column T_100190_NU_MAC.gameid
  is '��ϷID';
comment on column T_100190_NU_MAC.channelid
  is '����ID';
comment on column T_100190_NU_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100190_NU_MAC.serverid
  is '��������ID';
comment on column T_100190_NU_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100190_NU_MAC.position
  is 'λ����Ϣ';
comment on column T_100190_NU_MAC.dvid
  is '�豸ID';
create index IDX148_100190 on T_100190_NU_MAC (CHANNELID);
create index IDX149_100190 on T_100190_NU_MAC (SERVERID);
create index IDX150_100190 on T_100190_NU_MAC (THEDATE);

prompt
prompt Creating table T_100190_NU_MAC20150414
prompt ======================================
prompt
create table T_100190_NU_MAC20150414
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;

prompt
prompt Creating table T_100190_NU_MAC_ALLSERVER
prompt ========================================
prompt
create table T_100190_NU_MAC_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100190_NU_MAC_ALLSERVER
  is '�豸������ALLSERVER';
comment on column T_100190_NU_MAC_ALLSERVER.thedate
  is '����ʱ��';
comment on column T_100190_NU_MAC_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100190_NU_MAC_ALLSERVER.channelid
  is '����ID';
comment on column T_100190_NU_MAC_ALLSERVER.gameversion
  is '��Ϸ�汾';
comment on column T_100190_NU_MAC_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100190_NU_MAC_ALLSERVER.position
  is 'λ����Ϣ';
comment on column T_100190_NU_MAC_ALLSERVER.dvid
  is '�豸ID';
create index IDX196_100190 on T_100190_NU_MAC_ALLSERVER (CHANNELID);
create index IDX197_100190 on T_100190_NU_MAC_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100190_NU_PAY
prompt ==============================
prompt
create table T_100190_NU_PAY
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100190_NU_PAY
  is '�����û���';
comment on column T_100190_NU_PAY.thedate
  is '����ʱ��';
comment on column T_100190_NU_PAY.gameid
  is '��ϷID';
comment on column T_100190_NU_PAY.channelid
  is '����ID';
comment on column T_100190_NU_PAY.gameversion
  is '��Ϸ�汾';
comment on column T_100190_NU_PAY.serverid
  is '������Ϣ';
comment on column T_100190_NU_PAY.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100190_NU_PAY.position
  is 'λ����Ϣ';
comment on column T_100190_NU_PAY.accountid
  is '�˺�ID';
comment on column T_100190_NU_PAY.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100190_NU_PAY.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX151_100190 on T_100190_NU_PAY (CHANNELID);
create index IDX152_100190 on T_100190_NU_PAY (SERVERID);
create index IDX153_100190 on T_100190_NU_PAY (THEDATE);

prompt
prompt Creating table T_100190_NU_PAY20150414
prompt ======================================
prompt
create table T_100190_NU_PAY20150414
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;

prompt
prompt Creating table T_100190_NU_PAY_AS
prompt =================================
prompt
create table T_100190_NU_PAY_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100190_NU_PAY_AS
  is '�����û���allsever';
comment on column T_100190_NU_PAY_AS.thedate
  is '����ʱ��';
comment on column T_100190_NU_PAY_AS.gameid
  is '��ϷID';
comment on column T_100190_NU_PAY_AS.channelid
  is '����ID';
comment on column T_100190_NU_PAY_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100190_NU_PAY_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100190_NU_PAY_AS.position
  is 'λ����Ϣ';
comment on column T_100190_NU_PAY_AS.accountid
  is '�˺�ID';
comment on column T_100190_NU_PAY_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100190_NU_PAY_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX198_100190 on T_100190_NU_PAY_AS (CHANNELID);
create index IDX199_100190 on T_100190_NU_PAY_AS (THEDATE);

prompt
prompt Creating table T_100190_NU_PAY_MAC
prompt ==================================
prompt
create table T_100190_NU_PAY_MAC
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100190_NU_PAY_MAC
  is '�����û���';
comment on column T_100190_NU_PAY_MAC.thedate
  is '����ʱ��';
comment on column T_100190_NU_PAY_MAC.gameid
  is '��ϷID';
comment on column T_100190_NU_PAY_MAC.channelid
  is '����ID';
comment on column T_100190_NU_PAY_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100190_NU_PAY_MAC.serverid
  is '������Ϣ';
comment on column T_100190_NU_PAY_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100190_NU_PAY_MAC.position
  is 'λ����Ϣ';
comment on column T_100190_NU_PAY_MAC.dvid
  is '�豸ID';
comment on column T_100190_NU_PAY_MAC.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100190_NU_PAY_MAC.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX154_100190 on T_100190_NU_PAY_MAC (CHANNELID);
create index IDX155_100190 on T_100190_NU_PAY_MAC (SERVERID);
create index IDX156_100190 on T_100190_NU_PAY_MAC (THEDATE);

prompt
prompt Creating table T_100190_NU_PAY_MAC20150414
prompt ==========================================
prompt
create table T_100190_NU_PAY_MAC20150414
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;

prompt
prompt Creating table T_100190_NU_PAY_MAC_AS
prompt =====================================
prompt
create table T_100190_NU_PAY_MAC_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100190_NU_PAY_MAC_AS
  is '�����û���ALLSERVER';
comment on column T_100190_NU_PAY_MAC_AS.thedate
  is '����ʱ��';
comment on column T_100190_NU_PAY_MAC_AS.gameid
  is '��ϷID';
comment on column T_100190_NU_PAY_MAC_AS.channelid
  is '����ID';
comment on column T_100190_NU_PAY_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100190_NU_PAY_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100190_NU_PAY_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100190_NU_PAY_MAC_AS.dvid
  is '�豸ID';
comment on column T_100190_NU_PAY_MAC_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100190_NU_PAY_MAC_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX200_100190 on T_100190_NU_PAY_MAC_AS (CHANNELID);
create index IDX201_100190 on T_100190_NU_PAY_MAC_AS (THEDATE);

prompt
prompt Creating table T_100190_ORDER_FAILURE
prompt =====================================
prompt
create table T_100190_ORDER_FAILURE
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100190_ORDER_FAILURE
  is '��ֵ�ɹ���¼��';
comment on column T_100190_ORDER_FAILURE.thedate
  is '��ֵʱ��';
comment on column T_100190_ORDER_FAILURE.gameid
  is '��ϷID';
comment on column T_100190_ORDER_FAILURE.channelid
  is '����ID';
comment on column T_100190_ORDER_FAILURE.gameversion
  is '��Ϸ�汾';
comment on column T_100190_ORDER_FAILURE.serverid
  is '��������';
comment on column T_100190_ORDER_FAILURE.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100190_ORDER_FAILURE.position
  is 'λ����Ϣ';
comment on column T_100190_ORDER_FAILURE.dvid
  is '�豸��';
comment on column T_100190_ORDER_FAILURE.accountid
  is '�˺�';
comment on column T_100190_ORDER_FAILURE.money
  is '��ֵ���';
comment on column T_100190_ORDER_FAILURE.vc
  is '��ֵ��õ����������';
comment on column T_100190_ORDER_FAILURE.orderid
  is '������';
comment on column T_100190_ORDER_FAILURE.paychannel
  is '֧������';
comment on column T_100190_ORDER_FAILURE.iapid
  is '��ֵ����  30  60';
create index IDX157_100190 on T_100190_ORDER_FAILURE (CHANNELID);
create index IDX158_100190 on T_100190_ORDER_FAILURE (SERVERID);
create index IDX159_100190 on T_100190_ORDER_FAILURE (THEDATE);

prompt
prompt Creating table T_100190_ORDER_FAILURE20150414
prompt =============================================
prompt
create table T_100190_ORDER_FAILURE20150414
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;

prompt
prompt Creating table T_100190_ORDER_SUCC
prompt ==================================
prompt
create table T_100190_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100190_ORDER_SUCC
  is '��ֵ�ɹ���¼��';
comment on column T_100190_ORDER_SUCC.thedate
  is '��ֵʱ��';
comment on column T_100190_ORDER_SUCC.gameid
  is '��ϷID';
comment on column T_100190_ORDER_SUCC.channelid
  is '����ID';
comment on column T_100190_ORDER_SUCC.gameversion
  is '��Ϸ�汾';
comment on column T_100190_ORDER_SUCC.serverid
  is '��������';
comment on column T_100190_ORDER_SUCC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100190_ORDER_SUCC.position
  is 'λ����Ϣ';
comment on column T_100190_ORDER_SUCC.dvid
  is '�豸��';
comment on column T_100190_ORDER_SUCC.accountid
  is '�˺�';
comment on column T_100190_ORDER_SUCC.money
  is '��ֵ���';
comment on column T_100190_ORDER_SUCC.vc
  is '��ֵ��õ����������';
comment on column T_100190_ORDER_SUCC.orderid
  is '������';
comment on column T_100190_ORDER_SUCC.paychannel
  is '֧������';
comment on column T_100190_ORDER_SUCC.iapid
  is '��ֵ����  30  60';
create index IDX160_100190 on T_100190_ORDER_SUCC (CHANNELID);
create index IDX161_100190 on T_100190_ORDER_SUCC (SERVERID);
create index IDX162_100190 on T_100190_ORDER_SUCC (THEDATE);

prompt
prompt Creating table T_100190_ORDER_SUCC20150414
prompt ==========================================
prompt
create table T_100190_ORDER_SUCC20150414
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;

prompt
prompt Creating table T_100190_VC
prompt ==========================
prompt
create table T_100190_VC
(
  statdate    DATE,
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcchange    NUMBER,
  vcbefore    NUMBER,
  vcafter     NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100190_VC
  is '������ұ仯������';
comment on column T_100190_VC.statdate
  is 'ͳ������';
comment on column T_100190_VC.channelid
  is '����';
comment on column T_100190_VC.serverid
  is '����';
comment on column T_100190_VC.appid
  is '��Ʒid';
comment on column T_100190_VC.versionid
  is '��Ʒ�汾';
comment on column T_100190_VC.accountid
  is '�û�ID';
comment on column T_100190_VC.vctype
  is '�����������';
comment on column T_100190_VC.vcusetype
  is '�������ʹ������';
comment on column T_100190_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column T_100190_VC.vcchange
  is '������ұ仯���';
comment on column T_100190_VC.vcbefore
  is '������ұ仯ǰ���';
comment on column T_100190_VC.vcafter
  is '������ұ仯����';
comment on column T_100190_VC.data_source
  is '������Դ';
create index IDX163_100190 on T_100190_VC (CHANNELID);
create index IDX164_100190 on T_100190_VC (SERVERID);
create index IDX165_100190 on T_100190_VC (STATDATE);

prompt
prompt Creating table T_100190_VC20150414
prompt ==================================
prompt
create table T_100190_VC20150414
(
  statdate    DATE,
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcchange    NUMBER,
  vcbefore    NUMBER,
  vcafter     NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;

prompt
prompt Creating table T_100192_CEVENT
prompt ==============================
prompt
create table T_100192_CEVENT
(
  thedate          VARCHAR2(10),
  datenum          NUMBER,
  appid            VARCHAR2(10),
  channelid        VARCHAR2(50),
  gameversion      VARCHAR2(50),
  dvid             VARCHAR2(50),
  accountid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  ilevel           NUMBER,
  roleid           VARCHAR2(50),
  eventkey         VARCHAR2(100),
  eventvalue_key   VARCHAR2(100),
  eventvalue_value VARCHAR2(100),
  ipaddr           VARCHAR2(50),
  prerowid         VARCHAR2(200)
)
;
comment on table T_100192_CEVENT
  is '�Զ����¼���ֱ�';
comment on column T_100192_CEVENT.thedate
  is '����';
comment on column T_100192_CEVENT.datenum
  is '�������ָ�ʽ';
comment on column T_100192_CEVENT.appid
  is '��Ϸ�� appid';
comment on column T_100192_CEVENT.channelid
  is '���� ID';
comment on column T_100192_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column T_100192_CEVENT.dvid
  is '�豸 ID��Ψһ�豸��';
comment on column T_100192_CEVENT.accountid
  is '�ʻ� id';
comment on column T_100192_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column T_100192_CEVENT.ilevel
  is '��ҵȼ�';
comment on column T_100192_CEVENT.roleid
  is '��ɫ id';
comment on column T_100192_CEVENT.eventkey
  is '�¼�����';
comment on column T_100192_CEVENT.eventvalue_key
  is '�¼�ֵ�е�key';
comment on column T_100192_CEVENT.eventvalue_value
  is '�¼�ֵ��key��Ӧ��ֵ';
comment on column T_100192_CEVENT.ipaddr
  is 'ip ��ַ';
comment on column T_100192_CEVENT.prerowid
  is 'ԭΨһ��ID';
create index IDX180_100192 on T_100192_CEVENT (THEDATE);

prompt
prompt Creating table T_100192_CONN
prompt ============================
prompt
create table T_100192_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100192_CONN
  is '����&��ʧ&������������������ע���˺ţ�ע���豸��';
comment on column T_100192_CONN.conndate
  is '����ʱ��';
comment on column T_100192_CONN.gameid
  is '��ϷID';
comment on column T_100192_CONN.channelid
  is '����ID';
comment on column T_100192_CONN.gameversion
  is '��Ϸ�汾';
comment on column T_100192_CONN.serverid
  is '����ID';
comment on column T_100192_CONN.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100192_CONN.position
  is 'λ����Ϣ';
comment on column T_100192_CONN.dvid
  is '�豸��';
comment on column T_100192_CONN.accountid
  is '�˺�ID';
comment on column T_100192_CONN.regdate
  is 'ע��ʱ��';
comment on column T_100192_CONN.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100192_CONN.regdate_as
  is '���з��������ע��ʱ��';
create index IDX118_100192 on T_100192_CONN (CHANNELID);
create index IDX119_100192 on T_100192_CONN (SERVERID);
create index IDX120_100192 on T_100192_CONN (CONNDATE);

prompt
prompt Creating table T_100192_CONN_ACT
prompt ================================
prompt
create table T_100192_CONN_ACT
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100192_CONN_ACT
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100192_CONN_ACT.basedate
  is '����ʱ��';
comment on column T_100192_CONN_ACT.gameid
  is '��ϷID';
comment on column T_100192_CONN_ACT.channelid
  is '����ID';
comment on column T_100192_CONN_ACT.gameversion
  is '��Ϸ�汾';
comment on column T_100192_CONN_ACT.serverid
  is '����ID';
comment on column T_100192_CONN_ACT.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100192_CONN_ACT.position
  is 'λ����Ϣ';
comment on column T_100192_CONN_ACT.dvid
  is '�豸��';
comment on column T_100192_CONN_ACT.accountid
  is '�˺�';
comment on column T_100192_CONN_ACT.conndate
  is '��Ծʱ��';
comment on column T_100192_CONN_ACT.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_100192 on T_100192_CONN_ACT (CHANNELID);
create index IDX122_100192 on T_100192_CONN_ACT (SERVERID);
create index IDX123_100192 on T_100192_CONN_ACT (CONNDATE);
create index IDX124_100192 on T_100192_CONN_ACT (BASEDATE);

prompt
prompt Creating table T_100192_CONN_ACT_AS
prompt ===================================
prompt
create table T_100192_CONN_ACT_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100192_CONN_ACT_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100192_CONN_ACT_AS.basedate
  is '����ʱ��';
comment on column T_100192_CONN_ACT_AS.gameid
  is '��ϷID';
comment on column T_100192_CONN_ACT_AS.channelid
  is '����ID';
comment on column T_100192_CONN_ACT_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100192_CONN_ACT_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100192_CONN_ACT_AS.position
  is 'λ����Ϣ';
comment on column T_100192_CONN_ACT_AS.dvid
  is '�豸��';
comment on column T_100192_CONN_ACT_AS.accountid
  is '�˺�';
comment on column T_100192_CONN_ACT_AS.conndate
  is '��Ծʱ��';
comment on column T_100192_CONN_ACT_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX205_100192 on T_100192_CONN_ACT_AS (CHANNELID);
create index IDX206_100192 on T_100192_CONN_ACT_AS (CONNDATE);
create index IDX207_100192 on T_100192_CONN_ACT_AS (BASEDATE);

prompt
prompt Creating table T_100192_CONN_ACT_MAC
prompt ====================================
prompt
create table T_100192_CONN_ACT_MAC
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100192_CONN_ACT_MAC
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100192_CONN_ACT_MAC.basedate
  is '����ʱ��';
comment on column T_100192_CONN_ACT_MAC.gameid
  is '��ϷID';
comment on column T_100192_CONN_ACT_MAC.channelid
  is '����ID';
comment on column T_100192_CONN_ACT_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100192_CONN_ACT_MAC.serverid
  is '����ID';
comment on column T_100192_CONN_ACT_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100192_CONN_ACT_MAC.position
  is 'λ����Ϣ';
comment on column T_100192_CONN_ACT_MAC.dvid
  is '�豸��';
comment on column T_100192_CONN_ACT_MAC.accountid
  is '�˺�';
comment on column T_100192_CONN_ACT_MAC.conndate
  is '��Ծʱ��';
comment on column T_100192_CONN_ACT_MAC.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_100192 on T_100192_CONN_ACT_MAC (CHANNELID);
create index IDX126_100192 on T_100192_CONN_ACT_MAC (SERVERID);
create index IDX127_100192 on T_100192_CONN_ACT_MAC (CONNDATE);
create index IDX128_100192 on T_100192_CONN_ACT_MAC (BASEDATE);

prompt
prompt Creating table T_100192_CONN_ACT_MAC_AS
prompt =======================================
prompt
create table T_100192_CONN_ACT_MAC_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100192_CONN_ACT_MAC_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100192_CONN_ACT_MAC_AS.basedate
  is '����ʱ��';
comment on column T_100192_CONN_ACT_MAC_AS.gameid
  is '��ϷID';
comment on column T_100192_CONN_ACT_MAC_AS.channelid
  is '����ID';
comment on column T_100192_CONN_ACT_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100192_CONN_ACT_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100192_CONN_ACT_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100192_CONN_ACT_MAC_AS.dvid
  is '�豸��';
comment on column T_100192_CONN_ACT_MAC_AS.accountid
  is '�˺�';
comment on column T_100192_CONN_ACT_MAC_AS.conndate
  is '��Ծʱ��';
comment on column T_100192_CONN_ACT_MAC_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX202_100192 on T_100192_CONN_ACT_MAC_AS (CHANNELID);
create index IDX203_100192 on T_100192_CONN_ACT_MAC_AS (CONNDATE);
create index IDX204_100192 on T_100192_CONN_ACT_MAC_AS (BASEDATE);

prompt
prompt Creating table T_100192_CONN_DVID
prompt =================================
prompt
create table T_100192_CONN_DVID
(
  conndate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  dvid      VARCHAR2(50),
  regdate   VARCHAR2(10)
)
;
comment on table T_100192_CONN_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100192_CONN_DVID.conndate
  is '����ʱ��';
comment on column T_100192_CONN_DVID.gameid
  is '��ϷID';
comment on column T_100192_CONN_DVID.channelid
  is '����ID';
comment on column T_100192_CONN_DVID.dvid
  is '�豸��';
comment on column T_100192_CONN_DVID.regdate
  is 'ע��ʱ��';
create index IDX129_100192 on T_100192_CONN_DVID (CHANNELID);
create index IDX130_100192 on T_100192_CONN_DVID (CONNDATE);

prompt
prompt Creating table T_100192_CONN_MAC
prompt ================================
prompt
create table T_100192_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100192_CONN_MAC
  is '���� ��ʧ ������������������ע���˺ţ�ע���豸��';
comment on column T_100192_CONN_MAC.conndate
  is '����ʱ��';
comment on column T_100192_CONN_MAC.gameid
  is '��ϷID';
comment on column T_100192_CONN_MAC.channelid
  is '����ID';
comment on column T_100192_CONN_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100192_CONN_MAC.serverid
  is '����ID';
comment on column T_100192_CONN_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100192_CONN_MAC.position
  is 'λ����Ϣ';
comment on column T_100192_CONN_MAC.dvid
  is '�豸��';
comment on column T_100192_CONN_MAC.accountid
  is '�˺�ID';
comment on column T_100192_CONN_MAC.regdate
  is 'ע��ʱ��';
comment on column T_100192_CONN_MAC.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100192_CONN_MAC.regdate_as
  is '���з��������ע��ʱ��';
create index IDX131_100192 on T_100192_CONN_MAC (CHANNELID);
create index IDX132_100192 on T_100192_CONN_MAC (SERVERID);
create index IDX133_100192 on T_100192_CONN_MAC (CONNDATE);

prompt
prompt Creating table T_100192_LOST_MAC
prompt ================================
prompt
create table T_100192_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100192_LOST_MAC
  is '�豸�ȼ���ʧ������';
comment on column T_100192_LOST_MAC.statdate
  is '�����������';
comment on column T_100192_LOST_MAC.lost_date
  is '��ʧ����';
comment on column T_100192_LOST_MAC.channelid
  is '����';
comment on column T_100192_LOST_MAC.serverid
  is '����';
comment on column T_100192_LOST_MAC.appid
  is '��Ʒid';
comment on column T_100192_LOST_MAC.macid
  is '�豸id';
comment on column T_100192_LOST_MAC.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100192_LOST_MAC.lost_days
  is '��ʧ����';
comment on column T_100192_LOST_MAC.data_source
  is '������Դ';
create index IDX134_100192 on T_100192_LOST_MAC (CHANNELID);
create index IDX135_100192 on T_100192_LOST_MAC (SERVERID);
create index IDX136_100192 on T_100192_LOST_MAC (STATDATE);

prompt
prompt Creating table T_100192_LOST_MAC_AS
prompt ===================================
prompt
create table T_100192_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100192_LOST_MAC_AS
  is '�豸�ȼ���ʧ������allserver';
comment on column T_100192_LOST_MAC_AS.statdate
  is '�����������';
comment on column T_100192_LOST_MAC_AS.lost_date
  is '��ʧ����';
comment on column T_100192_LOST_MAC_AS.channelid
  is '����';
comment on column T_100192_LOST_MAC_AS.appid
  is '��Ʒid';
comment on column T_100192_LOST_MAC_AS.macid
  is '�豸id';
comment on column T_100192_LOST_MAC_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100192_LOST_MAC_AS.lost_days
  is '��ʧ����';
comment on column T_100192_LOST_MAC_AS.data_source
  is '������Դ';
create index IDX210_100192 on T_100192_LOST_MAC_AS (CHANNELID);
create index IDX211_100192 on T_100192_LOST_MAC_AS (STATDATE);

prompt
prompt Creating table T_100192_LOST_USER
prompt =================================
prompt
create table T_100192_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100192_LOST_USER
  is '�û��ȼ���ʧ������';
comment on column T_100192_LOST_USER.statdate
  is '�����������';
comment on column T_100192_LOST_USER.lost_date
  is '��ʧ����';
comment on column T_100192_LOST_USER.channelid
  is '����';
comment on column T_100192_LOST_USER.serverid
  is '����';
comment on column T_100192_LOST_USER.appid
  is '��Ʒid';
comment on column T_100192_LOST_USER.userid
  is '�û�id';
comment on column T_100192_LOST_USER.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100192_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100192_LOST_USER.lost_days
  is '��ʧ����';
comment on column T_100192_LOST_USER.data_source
  is '������Դ';
create index IDX137_100192 on T_100192_LOST_USER (CHANNELID);
create index IDX138_100192 on T_100192_LOST_USER (SERVERID);
create index IDX139_100192 on T_100192_LOST_USER (STATDATE);

prompt
prompt Creating table T_100192_LOST_USER_AS
prompt ====================================
prompt
create table T_100192_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100192_LOST_USER_AS
  is '�û��ȼ���ʧ������allserver';
comment on column T_100192_LOST_USER_AS.statdate
  is '�����������';
comment on column T_100192_LOST_USER_AS.lost_date
  is '��ʧ����';
comment on column T_100192_LOST_USER_AS.channelid
  is '����';
comment on column T_100192_LOST_USER_AS.appid
  is '��Ʒid';
comment on column T_100192_LOST_USER_AS.userid
  is '�û�id';
comment on column T_100192_LOST_USER_AS.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100192_LOST_USER_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100192_LOST_USER_AS.lost_days
  is '��ʧ����';
comment on column T_100192_LOST_USER_AS.data_source
  is '������Դ';
create index IDX208_100192 on T_100192_LOST_USER_AS (CHANNELID);
create index IDX209_100192 on T_100192_LOST_USER_AS (STATDATE);

prompt
prompt Creating table T_100192_MISS_FIRST
prompt ==================================
prompt
create table T_100192_MISS_FIRST
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50) default '0',
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100192_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column T_100192_MISS_FIRST.statdate
  is 'ͳ������';
comment on column T_100192_MISS_FIRST.channelid
  is '����';
comment on column T_100192_MISS_FIRST.serverid
  is '����';
comment on column T_100192_MISS_FIRST.appid
  is '��ƷID';
comment on column T_100192_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column T_100192_MISS_FIRST.accountid
  is '�û�ID';
comment on column T_100192_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100192_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column T_100192_MISS_FIRST.issucc
  is '�Ƿ���ͨ��';
comment on column T_100192_MISS_FIRST.data_source
  is '������Դ';
create index IDX140_100192 on T_100192_MISS_FIRST (CHANNELID);
create index IDX141_100192 on T_100192_MISS_FIRST (SERVERID);
create index IDX142_100192 on T_100192_MISS_FIRST (STATDATE);

prompt
prompt Creating table T_100192_NU
prompt ==========================
prompt
create table T_100192_NU
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100192_NU
  is '�����û���Ϣ��';
comment on column T_100192_NU.thedate
  is '��������';
comment on column T_100192_NU.gameid
  is '��ϷID';
comment on column T_100192_NU.channelid
  is '����ID';
comment on column T_100192_NU.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100192_NU.serverid
  is '���ڷ�ID';
comment on column T_100192_NU.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100192_NU.position
  is '����λ��';
comment on column T_100192_NU.accountid
  is '�˺�ID';
create index IDX143_100192 on T_100192_NU (CHANNELID);
create index IDX144_100192 on T_100192_NU (SERVERID);
create index IDX145_100192 on T_100192_NU (THEDATE);

prompt
prompt Creating table T_100192_NU_ALLSERVER
prompt ====================================
prompt
create table T_100192_NU_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100192_NU_ALLSERVER
  is '�����û���Ϣ��ALLSERVER';
comment on column T_100192_NU_ALLSERVER.thedate
  is '��������';
comment on column T_100192_NU_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100192_NU_ALLSERVER.channelid
  is '����ID';
comment on column T_100192_NU_ALLSERVER.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100192_NU_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100192_NU_ALLSERVER.position
  is '����λ��';
comment on column T_100192_NU_ALLSERVER.accountid
  is '�˺�ID';
create index IDX194_100192 on T_100192_NU_ALLSERVER (CHANNELID);
create index IDX195_100192 on T_100192_NU_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100192_NU_DVID
prompt ===============================
prompt
create table T_100192_NU_DVID
(
  thedate   DATE not null,
  gameid    VARCHAR2(20) not null,
  channelid VARCHAR2(20) not null,
  dvid      VARCHAR2(50) not null,
  ipaddr    VARCHAR2(50)
)
;
comment on table T_100192_NU_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100192_NU_DVID.thedate
  is '����ʱ��';
comment on column T_100192_NU_DVID.gameid
  is '��ϷID';
comment on column T_100192_NU_DVID.channelid
  is '����ID';
comment on column T_100192_NU_DVID.dvid
  is '�豸ID';
comment on column T_100192_NU_DVID.ipaddr
  is 'IP';
create index IDX146_100192 on T_100192_NU_DVID (CHANNELID);
create index IDX147_100192 on T_100192_NU_DVID (THEDATE);

prompt
prompt Creating table T_100192_NU_MAC
prompt ==============================
prompt
create table T_100192_NU_MAC
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100192_NU_MAC
  is '�豸������';
comment on column T_100192_NU_MAC.thedate
  is '����ʱ��';
comment on column T_100192_NU_MAC.gameid
  is '��ϷID';
comment on column T_100192_NU_MAC.channelid
  is '����ID';
comment on column T_100192_NU_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100192_NU_MAC.serverid
  is '��������ID';
comment on column T_100192_NU_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100192_NU_MAC.position
  is 'λ����Ϣ';
comment on column T_100192_NU_MAC.dvid
  is '�豸ID';
create index IDX148_100192 on T_100192_NU_MAC (CHANNELID);
create index IDX149_100192 on T_100192_NU_MAC (SERVERID);
create index IDX150_100192 on T_100192_NU_MAC (THEDATE);

prompt
prompt Creating table T_100192_NU_MAC_ALLSERVER
prompt ========================================
prompt
create table T_100192_NU_MAC_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100192_NU_MAC_ALLSERVER
  is '�豸������ALLSERVER';
comment on column T_100192_NU_MAC_ALLSERVER.thedate
  is '����ʱ��';
comment on column T_100192_NU_MAC_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100192_NU_MAC_ALLSERVER.channelid
  is '����ID';
comment on column T_100192_NU_MAC_ALLSERVER.gameversion
  is '��Ϸ�汾';
comment on column T_100192_NU_MAC_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100192_NU_MAC_ALLSERVER.position
  is 'λ����Ϣ';
comment on column T_100192_NU_MAC_ALLSERVER.dvid
  is '�豸ID';
create index IDX196_100192 on T_100192_NU_MAC_ALLSERVER (CHANNELID);
create index IDX197_100192 on T_100192_NU_MAC_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100192_NU_PAY
prompt ==============================
prompt
create table T_100192_NU_PAY
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100192_NU_PAY
  is '�����û���';
comment on column T_100192_NU_PAY.thedate
  is '����ʱ��';
comment on column T_100192_NU_PAY.gameid
  is '��ϷID';
comment on column T_100192_NU_PAY.channelid
  is '����ID';
comment on column T_100192_NU_PAY.gameversion
  is '��Ϸ�汾';
comment on column T_100192_NU_PAY.serverid
  is '������Ϣ';
comment on column T_100192_NU_PAY.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100192_NU_PAY.position
  is 'λ����Ϣ';
comment on column T_100192_NU_PAY.accountid
  is '�˺�ID';
comment on column T_100192_NU_PAY.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100192_NU_PAY.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX151_100192 on T_100192_NU_PAY (CHANNELID);
create index IDX152_100192 on T_100192_NU_PAY (SERVERID);
create index IDX153_100192 on T_100192_NU_PAY (THEDATE);

prompt
prompt Creating table T_100192_NU_PAY_AS
prompt =================================
prompt
create table T_100192_NU_PAY_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100192_NU_PAY_AS
  is '�����û���allsever';
comment on column T_100192_NU_PAY_AS.thedate
  is '����ʱ��';
comment on column T_100192_NU_PAY_AS.gameid
  is '��ϷID';
comment on column T_100192_NU_PAY_AS.channelid
  is '����ID';
comment on column T_100192_NU_PAY_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100192_NU_PAY_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100192_NU_PAY_AS.position
  is 'λ����Ϣ';
comment on column T_100192_NU_PAY_AS.accountid
  is '�˺�ID';
comment on column T_100192_NU_PAY_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100192_NU_PAY_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX198_100192 on T_100192_NU_PAY_AS (CHANNELID);
create index IDX199_100192 on T_100192_NU_PAY_AS (THEDATE);

prompt
prompt Creating table T_100192_NU_PAY_MAC
prompt ==================================
prompt
create table T_100192_NU_PAY_MAC
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100192_NU_PAY_MAC
  is '�����û���';
comment on column T_100192_NU_PAY_MAC.thedate
  is '����ʱ��';
comment on column T_100192_NU_PAY_MAC.gameid
  is '��ϷID';
comment on column T_100192_NU_PAY_MAC.channelid
  is '����ID';
comment on column T_100192_NU_PAY_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100192_NU_PAY_MAC.serverid
  is '������Ϣ';
comment on column T_100192_NU_PAY_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100192_NU_PAY_MAC.position
  is 'λ����Ϣ';
comment on column T_100192_NU_PAY_MAC.dvid
  is '�豸ID';
comment on column T_100192_NU_PAY_MAC.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100192_NU_PAY_MAC.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX154_100192 on T_100192_NU_PAY_MAC (CHANNELID);
create index IDX155_100192 on T_100192_NU_PAY_MAC (SERVERID);
create index IDX156_100192 on T_100192_NU_PAY_MAC (THEDATE);

prompt
prompt Creating table T_100192_NU_PAY_MAC_AS
prompt =====================================
prompt
create table T_100192_NU_PAY_MAC_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100192_NU_PAY_MAC_AS
  is '�����û���ALLSERVER';
comment on column T_100192_NU_PAY_MAC_AS.thedate
  is '����ʱ��';
comment on column T_100192_NU_PAY_MAC_AS.gameid
  is '��ϷID';
comment on column T_100192_NU_PAY_MAC_AS.channelid
  is '����ID';
comment on column T_100192_NU_PAY_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100192_NU_PAY_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100192_NU_PAY_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100192_NU_PAY_MAC_AS.dvid
  is '�豸ID';
comment on column T_100192_NU_PAY_MAC_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100192_NU_PAY_MAC_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX200_100192 on T_100192_NU_PAY_MAC_AS (CHANNELID);
create index IDX201_100192 on T_100192_NU_PAY_MAC_AS (THEDATE);

prompt
prompt Creating table T_100192_ORDER_FAILURE
prompt =====================================
prompt
create table T_100192_ORDER_FAILURE
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100192_ORDER_FAILURE
  is '��ֵ�ɹ���¼��';
comment on column T_100192_ORDER_FAILURE.thedate
  is '��ֵʱ��';
comment on column T_100192_ORDER_FAILURE.gameid
  is '��ϷID';
comment on column T_100192_ORDER_FAILURE.channelid
  is '����ID';
comment on column T_100192_ORDER_FAILURE.gameversion
  is '��Ϸ�汾';
comment on column T_100192_ORDER_FAILURE.serverid
  is '��������';
comment on column T_100192_ORDER_FAILURE.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100192_ORDER_FAILURE.position
  is 'λ����Ϣ';
comment on column T_100192_ORDER_FAILURE.dvid
  is '�豸��';
comment on column T_100192_ORDER_FAILURE.accountid
  is '�˺�';
comment on column T_100192_ORDER_FAILURE.money
  is '��ֵ���';
comment on column T_100192_ORDER_FAILURE.vc
  is '��ֵ��õ����������';
comment on column T_100192_ORDER_FAILURE.orderid
  is '������';
comment on column T_100192_ORDER_FAILURE.paychannel
  is '֧������';
comment on column T_100192_ORDER_FAILURE.iapid
  is '��ֵ����  30  60';
create index IDX157_100192 on T_100192_ORDER_FAILURE (CHANNELID);
create index IDX158_100192 on T_100192_ORDER_FAILURE (SERVERID);
create index IDX159_100192 on T_100192_ORDER_FAILURE (THEDATE);

prompt
prompt Creating table T_100192_ORDER_SUCC
prompt ==================================
prompt
create table T_100192_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100192_ORDER_SUCC
  is '��ֵ�ɹ���¼��';
comment on column T_100192_ORDER_SUCC.thedate
  is '��ֵʱ��';
comment on column T_100192_ORDER_SUCC.gameid
  is '��ϷID';
comment on column T_100192_ORDER_SUCC.channelid
  is '����ID';
comment on column T_100192_ORDER_SUCC.gameversion
  is '��Ϸ�汾';
comment on column T_100192_ORDER_SUCC.serverid
  is '��������';
comment on column T_100192_ORDER_SUCC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100192_ORDER_SUCC.position
  is 'λ����Ϣ';
comment on column T_100192_ORDER_SUCC.dvid
  is '�豸��';
comment on column T_100192_ORDER_SUCC.accountid
  is '�˺�';
comment on column T_100192_ORDER_SUCC.money
  is '��ֵ���';
comment on column T_100192_ORDER_SUCC.vc
  is '��ֵ��õ����������';
comment on column T_100192_ORDER_SUCC.orderid
  is '������';
comment on column T_100192_ORDER_SUCC.paychannel
  is '֧������';
comment on column T_100192_ORDER_SUCC.iapid
  is '��ֵ����  30  60';
create index IDX160_100192 on T_100192_ORDER_SUCC (CHANNELID);
create index IDX161_100192 on T_100192_ORDER_SUCC (SERVERID);
create index IDX162_100192 on T_100192_ORDER_SUCC (THEDATE);

prompt
prompt Creating table T_100192_VC
prompt ==========================
prompt
create table T_100192_VC
(
  statdate    DATE,
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcchange    NUMBER,
  vcbefore    NUMBER,
  vcafter     NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100192_VC
  is '������ұ仯������';
comment on column T_100192_VC.statdate
  is 'ͳ������';
comment on column T_100192_VC.channelid
  is '����';
comment on column T_100192_VC.serverid
  is '����';
comment on column T_100192_VC.appid
  is '��Ʒid';
comment on column T_100192_VC.versionid
  is '��Ʒ�汾';
comment on column T_100192_VC.accountid
  is '�û�ID';
comment on column T_100192_VC.vctype
  is '�����������';
comment on column T_100192_VC.vcusetype
  is '�������ʹ������';
comment on column T_100192_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column T_100192_VC.vcchange
  is '������ұ仯���';
comment on column T_100192_VC.vcbefore
  is '������ұ仯ǰ���';
comment on column T_100192_VC.vcafter
  is '������ұ仯����';
comment on column T_100192_VC.data_source
  is '������Դ';
create index IDX163_100192 on T_100192_VC (CHANNELID);
create index IDX164_100192 on T_100192_VC (SERVERID);
create index IDX165_100192 on T_100192_VC (STATDATE);

prompt
prompt Creating table T_100193_CEVENT
prompt ==============================
prompt
create table T_100193_CEVENT
(
  thedate          VARCHAR2(10),
  datenum          NUMBER,
  appid            VARCHAR2(10),
  channelid        VARCHAR2(50),
  gameversion      VARCHAR2(50),
  dvid             VARCHAR2(50),
  accountid        VARCHAR2(50),
  serverid         VARCHAR2(50),
  ilevel           NUMBER,
  roleid           VARCHAR2(50),
  eventkey         VARCHAR2(100),
  eventvalue_key   VARCHAR2(100),
  eventvalue_value VARCHAR2(100),
  ipaddr           VARCHAR2(50),
  prerowid         VARCHAR2(200)
)
;
comment on table T_100193_CEVENT
  is '�Զ����¼���ֱ�';
comment on column T_100193_CEVENT.thedate
  is '����';
comment on column T_100193_CEVENT.datenum
  is '�������ָ�ʽ';
comment on column T_100193_CEVENT.appid
  is '��Ϸ�� appid';
comment on column T_100193_CEVENT.channelid
  is '���� ID';
comment on column T_100193_CEVENT.gameversion
  is '��Ϸ�汾';
comment on column T_100193_CEVENT.dvid
  is '�豸 ID��Ψһ�豸��';
comment on column T_100193_CEVENT.accountid
  is '�ʻ� id';
comment on column T_100193_CEVENT.serverid
  is '��ҵ�½������ id';
comment on column T_100193_CEVENT.ilevel
  is '��ҵȼ�';
comment on column T_100193_CEVENT.roleid
  is '��ɫ id';
comment on column T_100193_CEVENT.eventkey
  is '�¼�����';
comment on column T_100193_CEVENT.eventvalue_key
  is '�¼�ֵ�е�key';
comment on column T_100193_CEVENT.eventvalue_value
  is '�¼�ֵ��key��Ӧ��ֵ';
comment on column T_100193_CEVENT.ipaddr
  is 'ip ��ַ';
comment on column T_100193_CEVENT.prerowid
  is 'ԭΨһ��ID';
create index IDX180_100193 on T_100193_CEVENT (THEDATE);

prompt
prompt Creating table T_100193_CONN
prompt ============================
prompt
create table T_100193_CONN
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100193_CONN
  is '����&��ʧ&������������������ע���˺ţ�ע���豸��';
comment on column T_100193_CONN.conndate
  is '����ʱ��';
comment on column T_100193_CONN.gameid
  is '��ϷID';
comment on column T_100193_CONN.channelid
  is '����ID';
comment on column T_100193_CONN.gameversion
  is '��Ϸ�汾';
comment on column T_100193_CONN.serverid
  is '����ID';
comment on column T_100193_CONN.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100193_CONN.position
  is 'λ����Ϣ';
comment on column T_100193_CONN.dvid
  is '�豸��';
comment on column T_100193_CONN.accountid
  is '�˺�ID';
comment on column T_100193_CONN.regdate
  is 'ע��ʱ��';
comment on column T_100193_CONN.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100193_CONN.regdate_as
  is '����ע��ʱ��';
create index IDX118_100193 on T_100193_CONN (CHANNELID);
create index IDX119_100193 on T_100193_CONN (SERVERID);
create index IDX120_100193 on T_100193_CONN (CONNDATE);

prompt
prompt Creating table T_100193_CONN_ACT
prompt ================================
prompt
create table T_100193_CONN_ACT
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100193_CONN_ACT
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100193_CONN_ACT.basedate
  is '����ʱ��';
comment on column T_100193_CONN_ACT.gameid
  is '��ϷID';
comment on column T_100193_CONN_ACT.channelid
  is '����ID';
comment on column T_100193_CONN_ACT.gameversion
  is '��Ϸ�汾';
comment on column T_100193_CONN_ACT.serverid
  is '����ID';
comment on column T_100193_CONN_ACT.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100193_CONN_ACT.position
  is 'λ����Ϣ';
comment on column T_100193_CONN_ACT.dvid
  is '�豸��';
comment on column T_100193_CONN_ACT.accountid
  is '�˺�';
comment on column T_100193_CONN_ACT.conndate
  is '��Ծʱ��';
comment on column T_100193_CONN_ACT.ispay
  is '�Ƿ񸶷��û�';
create index IDX121_100193 on T_100193_CONN_ACT (CHANNELID);
create index IDX122_100193 on T_100193_CONN_ACT (SERVERID);
create index IDX123_100193 on T_100193_CONN_ACT (CONNDATE);
create index IDX124_100193 on T_100193_CONN_ACT (BASEDATE);

prompt
prompt Creating table T_100193_CONN_ACT_AS
prompt ===================================
prompt
create table T_100193_CONN_ACT_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100193_CONN_ACT_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100193_CONN_ACT_AS.basedate
  is '����ʱ��';
comment on column T_100193_CONN_ACT_AS.gameid
  is '��ϷID';
comment on column T_100193_CONN_ACT_AS.channelid
  is '����ID';
comment on column T_100193_CONN_ACT_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100193_CONN_ACT_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100193_CONN_ACT_AS.position
  is 'λ����Ϣ';
comment on column T_100193_CONN_ACT_AS.dvid
  is '�豸��';
comment on column T_100193_CONN_ACT_AS.accountid
  is '�˺�';
comment on column T_100193_CONN_ACT_AS.conndate
  is '��Ծʱ��';
comment on column T_100193_CONN_ACT_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX205_100193 on T_100193_CONN_ACT_AS (CHANNELID);
create index IDX206_100193 on T_100193_CONN_ACT_AS (CONNDATE);
create index IDX207_100193 on T_100193_CONN_ACT_AS (BASEDATE);

prompt
prompt Creating table T_100193_CONN_ACT_MAC
prompt ====================================
prompt
create table T_100193_CONN_ACT_MAC
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100193_CONN_ACT_MAC
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)';
comment on column T_100193_CONN_ACT_MAC.basedate
  is '����ʱ��';
comment on column T_100193_CONN_ACT_MAC.gameid
  is '��ϷID';
comment on column T_100193_CONN_ACT_MAC.channelid
  is '����ID';
comment on column T_100193_CONN_ACT_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100193_CONN_ACT_MAC.serverid
  is '����ID';
comment on column T_100193_CONN_ACT_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100193_CONN_ACT_MAC.position
  is 'λ����Ϣ';
comment on column T_100193_CONN_ACT_MAC.dvid
  is '�豸��';
comment on column T_100193_CONN_ACT_MAC.accountid
  is '�˺�';
comment on column T_100193_CONN_ACT_MAC.conndate
  is '��Ծʱ��';
comment on column T_100193_CONN_ACT_MAC.ispay
  is '�Ƿ񸶷��û�';
create index IDX125_100193 on T_100193_CONN_ACT_MAC (CHANNELID);
create index IDX126_100193 on T_100193_CONN_ACT_MAC (SERVERID);
create index IDX127_100193 on T_100193_CONN_ACT_MAC (CONNDATE);
create index IDX128_100193 on T_100193_CONN_ACT_MAC (BASEDATE);

prompt
prompt Creating table T_100193_CONN_ACT_MAC_AS
prompt =======================================
prompt
create table T_100193_CONN_ACT_MAC_AS
(
  basedate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  conndate    VARCHAR2(10),
  ispay       NUMBER
)
;
comment on table T_100193_CONN_ACT_MAC_AS
  is '���� ��ʧ �������������(��Ի�Ծ�û� �豸��Ծ)ALLSERVER';
comment on column T_100193_CONN_ACT_MAC_AS.basedate
  is '����ʱ��';
comment on column T_100193_CONN_ACT_MAC_AS.gameid
  is '��ϷID';
comment on column T_100193_CONN_ACT_MAC_AS.channelid
  is '����ID';
comment on column T_100193_CONN_ACT_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100193_CONN_ACT_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100193_CONN_ACT_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100193_CONN_ACT_MAC_AS.dvid
  is '�豸��';
comment on column T_100193_CONN_ACT_MAC_AS.accountid
  is '�˺�';
comment on column T_100193_CONN_ACT_MAC_AS.conndate
  is '��Ծʱ��';
comment on column T_100193_CONN_ACT_MAC_AS.ispay
  is '�Ƿ񸶷��û�';
create index IDX202_100193 on T_100193_CONN_ACT_MAC_AS (CHANNELID);
create index IDX203_100193 on T_100193_CONN_ACT_MAC_AS (CONNDATE);
create index IDX204_100193 on T_100193_CONN_ACT_MAC_AS (BASEDATE);

prompt
prompt Creating table T_100193_CONN_DVID
prompt =================================
prompt
create table T_100193_CONN_DVID
(
  conndate  VARCHAR2(10),
  gameid    VARCHAR2(20),
  channelid VARCHAR2(20),
  dvid      VARCHAR2(50),
  regdate   VARCHAR2(10)
)
;
comment on table T_100193_CONN_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100193_CONN_DVID.conndate
  is '����ʱ��';
comment on column T_100193_CONN_DVID.gameid
  is '��ϷID';
comment on column T_100193_CONN_DVID.channelid
  is '����ID';
comment on column T_100193_CONN_DVID.dvid
  is '�豸��';
comment on column T_100193_CONN_DVID.regdate
  is 'ע��ʱ��';
create index IDX129_100193 on T_100193_CONN_DVID (CHANNELID);
create index IDX130_100193 on T_100193_CONN_DVID (CONNDATE);

prompt
prompt Creating table T_100193_CONN_MAC
prompt ================================
prompt
create table T_100193_CONN_MAC
(
  conndate    VARCHAR2(10),
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  regdate     VARCHAR2(10),
  ispay       NUMBER,
  regdate_as  VARCHAR2(10)
)
;
comment on table T_100193_CONN_MAC
  is '���� ��ʧ ������������������ע���˺ţ�ע���豸��';
comment on column T_100193_CONN_MAC.conndate
  is '����ʱ��';
comment on column T_100193_CONN_MAC.gameid
  is '��ϷID';
comment on column T_100193_CONN_MAC.channelid
  is '����ID';
comment on column T_100193_CONN_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100193_CONN_MAC.serverid
  is '����ID';
comment on column T_100193_CONN_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100193_CONN_MAC.position
  is 'λ����Ϣ';
comment on column T_100193_CONN_MAC.dvid
  is '�豸��';
comment on column T_100193_CONN_MAC.accountid
  is '�˺�ID';
comment on column T_100193_CONN_MAC.regdate
  is 'ע��ʱ��';
comment on column T_100193_CONN_MAC.ispay
  is '�Ƿ��Ǹ����û�';
comment on column T_100193_CONN_MAC.regdate_as
  is '����ע��ʱ��';
create index IDX131_100193 on T_100193_CONN_MAC (CHANNELID);
create index IDX132_100193 on T_100193_CONN_MAC (SERVERID);
create index IDX133_100193 on T_100193_CONN_MAC (CONNDATE);

prompt
prompt Creating table T_100193_LOST_MAC
prompt ================================
prompt
create table T_100193_LOST_MAC
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100193_LOST_MAC
  is '�豸�ȼ���ʧ������';
comment on column T_100193_LOST_MAC.statdate
  is '�����������';
comment on column T_100193_LOST_MAC.lost_date
  is '��ʧ����';
comment on column T_100193_LOST_MAC.channelid
  is '����';
comment on column T_100193_LOST_MAC.serverid
  is '����';
comment on column T_100193_LOST_MAC.appid
  is '��Ʒid';
comment on column T_100193_LOST_MAC.macid
  is '�豸id';
comment on column T_100193_LOST_MAC.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100193_LOST_MAC.lost_days
  is '��ʧ����';
comment on column T_100193_LOST_MAC.data_source
  is '������Դ';
create index IDX134_100193 on T_100193_LOST_MAC (CHANNELID);
create index IDX135_100193 on T_100193_LOST_MAC (SERVERID);
create index IDX136_100193 on T_100193_LOST_MAC (STATDATE);

prompt
prompt Creating table T_100193_LOST_MAC_AS
prompt ===================================
prompt
create table T_100193_LOST_MAC_AS
(
  statdate    VARCHAR2(10),
  lost_date   VARCHAR2(10),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  macid       VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table T_100193_LOST_MAC_AS
  is '�豸�ȼ���ʧ������allserver';
comment on column T_100193_LOST_MAC_AS.statdate
  is '�����������';
comment on column T_100193_LOST_MAC_AS.lost_date
  is '��ʧ����';
comment on column T_100193_LOST_MAC_AS.channelid
  is '����';
comment on column T_100193_LOST_MAC_AS.appid
  is '��Ʒid';
comment on column T_100193_LOST_MAC_AS.macid
  is '�豸id';
comment on column T_100193_LOST_MAC_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100193_LOST_MAC_AS.lost_days
  is '��ʧ����';
comment on column T_100193_LOST_MAC_AS.data_source
  is '������Դ';
create index IDX210_100193 on T_100193_LOST_MAC_AS (CHANNELID);
create index IDX211_100193 on T_100193_LOST_MAC_AS (STATDATE);

prompt
prompt Creating table T_100193_LOST_USER
prompt =================================
prompt
create table T_100193_LOST_USER
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100193_LOST_USER
  is '�û��ȼ���ʧ������';
comment on column T_100193_LOST_USER.statdate
  is '�����������';
comment on column T_100193_LOST_USER.lost_date
  is '��ʧ����';
comment on column T_100193_LOST_USER.channelid
  is '����';
comment on column T_100193_LOST_USER.serverid
  is '����';
comment on column T_100193_LOST_USER.appid
  is '��Ʒid';
comment on column T_100193_LOST_USER.userid
  is '�û�id';
comment on column T_100193_LOST_USER.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100193_LOST_USER.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100193_LOST_USER.lost_days
  is '��ʧ����';
comment on column T_100193_LOST_USER.data_source
  is '������Դ';
create index IDX137_100193 on T_100193_LOST_USER (CHANNELID);
create index IDX138_100193 on T_100193_LOST_USER (SERVERID);
create index IDX139_100193 on T_100193_LOST_USER (STATDATE);

prompt
prompt Creating table T_100193_LOST_USER_AS
prompt ====================================
prompt
create table T_100193_LOST_USER_AS
(
  statdate    VARCHAR2(20),
  lost_date   VARCHAR2(20),
  channelid   VARCHAR2(50),
  appid       VARCHAR2(50),
  userid      VARCHAR2(50),
  ispay       VARCHAR2(5),
  rolelevel   NUMBER,
  lost_days   NUMBER,
  loaddate    DATE default Sysdate,
  data_source VARCHAR2(100)
)
;
comment on table T_100193_LOST_USER_AS
  is '�û��ȼ���ʧ������allserver';
comment on column T_100193_LOST_USER_AS.statdate
  is '�����������';
comment on column T_100193_LOST_USER_AS.lost_date
  is '��ʧ����';
comment on column T_100193_LOST_USER_AS.channelid
  is '����';
comment on column T_100193_LOST_USER_AS.appid
  is '��Ʒid';
comment on column T_100193_LOST_USER_AS.userid
  is '�û�id';
comment on column T_100193_LOST_USER_AS.ispay
  is '�Ƿ��ֵ�豸';
comment on column T_100193_LOST_USER_AS.rolelevel
  is '��ʧǰ�ȼ�';
comment on column T_100193_LOST_USER_AS.lost_days
  is '��ʧ����';
comment on column T_100193_LOST_USER_AS.data_source
  is '������Դ';
create index IDX208_100193 on T_100193_LOST_USER_AS (CHANNELID);
create index IDX209_100193 on T_100193_LOST_USER_AS (STATDATE);

prompt
prompt Creating table T_100193_MISS_FIRST
prompt ==================================
prompt
create table T_100193_MISS_FIRST
(
  statdate    VARCHAR2(10),
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  missionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  rolelevel   NUMBER,
  rolejob     VARCHAR2(50) default '0',
  issucc      NUMBER,
  loaddate    DATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100193_MISS_FIRST
  is '�״ν�������ؿ�������';
comment on column T_100193_MISS_FIRST.statdate
  is 'ͳ������';
comment on column T_100193_MISS_FIRST.channelid
  is '����';
comment on column T_100193_MISS_FIRST.serverid
  is '����';
comment on column T_100193_MISS_FIRST.appid
  is '��ƷID';
comment on column T_100193_MISS_FIRST.versionid
  is '��Ʒ�汾';
comment on column T_100193_MISS_FIRST.accountid
  is '�û�ID';
comment on column T_100193_MISS_FIRST.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100193_MISS_FIRST.rolejob
  is '��ɫְҵ';
comment on column T_100193_MISS_FIRST.issucc
  is '�Ƿ���ͨ��';
comment on column T_100193_MISS_FIRST.data_source
  is '������Դ';
create index IDX140_100193 on T_100193_MISS_FIRST (CHANNELID);
create index IDX141_100193 on T_100193_MISS_FIRST (SERVERID);
create index IDX142_100193 on T_100193_MISS_FIRST (STATDATE);

prompt
prompt Creating table T_100193_NU
prompt ==========================
prompt
create table T_100193_NU
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100193_NU
  is '�����û���Ϣ��';
comment on column T_100193_NU.thedate
  is '��������';
comment on column T_100193_NU.gameid
  is '��ϷID';
comment on column T_100193_NU.channelid
  is '����ID';
comment on column T_100193_NU.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100193_NU.serverid
  is '���ڷ�ID';
comment on column T_100193_NU.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100193_NU.position
  is '����λ��';
comment on column T_100193_NU.accountid
  is '�˺�ID';
create index IDX143_100193 on T_100193_NU (CHANNELID);
create index IDX144_100193 on T_100193_NU (SERVERID);
create index IDX145_100193 on T_100193_NU (THEDATE);

prompt
prompt Creating table T_100193_NU_ALLSERVER
prompt ====================================
prompt
create table T_100193_NU_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  accountid   VARCHAR2(50) not null
)
;
comment on table T_100193_NU_ALLSERVER
  is '�����û���Ϣ��ALLSERVER';
comment on column T_100193_NU_ALLSERVER.thedate
  is '��������';
comment on column T_100193_NU_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100193_NU_ALLSERVER.channelid
  is '����ID';
comment on column T_100193_NU_ALLSERVER.gameversion
  is 'ע����Ϸ�汾';
comment on column T_100193_NU_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100193_NU_ALLSERVER.position
  is '����λ��';
comment on column T_100193_NU_ALLSERVER.accountid
  is '�˺�ID';
create index IDX194_100193 on T_100193_NU_ALLSERVER (CHANNELID);
create index IDX195_100193 on T_100193_NU_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100193_NU_DVID
prompt ===============================
prompt
create table T_100193_NU_DVID
(
  thedate   DATE not null,
  gameid    VARCHAR2(20) not null,
  channelid VARCHAR2(20) not null,
  dvid      VARCHAR2(50) not null,
  ipaddr    VARCHAR2(50)
)
;
comment on table T_100193_NU_DVID
  is '�豸������-DEVICEֱ�ӻ�ȡ��ʽ';
comment on column T_100193_NU_DVID.thedate
  is '����ʱ��';
comment on column T_100193_NU_DVID.gameid
  is '��ϷID';
comment on column T_100193_NU_DVID.channelid
  is '����ID';
comment on column T_100193_NU_DVID.dvid
  is '�豸ID';
comment on column T_100193_NU_DVID.ipaddr
  is 'IP';
create index IDX146_100193 on T_100193_NU_DVID (CHANNELID);
create index IDX147_100193 on T_100193_NU_DVID (THEDATE);

prompt
prompt Creating table T_100193_NU_MAC
prompt ==============================
prompt
create table T_100193_NU_MAC
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100193_NU_MAC
  is '�豸������';
comment on column T_100193_NU_MAC.thedate
  is '����ʱ��';
comment on column T_100193_NU_MAC.gameid
  is '��ϷID';
comment on column T_100193_NU_MAC.channelid
  is '����ID';
comment on column T_100193_NU_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100193_NU_MAC.serverid
  is '��������ID';
comment on column T_100193_NU_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100193_NU_MAC.position
  is 'λ����Ϣ';
comment on column T_100193_NU_MAC.dvid
  is '�豸ID';
create index IDX148_100193 on T_100193_NU_MAC (CHANNELID);
create index IDX149_100193 on T_100193_NU_MAC (SERVERID);
create index IDX150_100193 on T_100193_NU_MAC (THEDATE);

prompt
prompt Creating table T_100193_NU_MAC_ALLSERVER
prompt ========================================
prompt
create table T_100193_NU_MAC_ALLSERVER
(
  thedate     DATE not null,
  gameid      VARCHAR2(20) not null,
  channelid   VARCHAR2(20) not null,
  gameversion VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50) not null
)
;
comment on table T_100193_NU_MAC_ALLSERVER
  is '�豸������ALLSERVER';
comment on column T_100193_NU_MAC_ALLSERVER.thedate
  is '����ʱ��';
comment on column T_100193_NU_MAC_ALLSERVER.gameid
  is '��ϷID';
comment on column T_100193_NU_MAC_ALLSERVER.channelid
  is '����ID';
comment on column T_100193_NU_MAC_ALLSERVER.gameversion
  is '��Ϸ�汾';
comment on column T_100193_NU_MAC_ALLSERVER.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100193_NU_MAC_ALLSERVER.position
  is 'λ����Ϣ';
comment on column T_100193_NU_MAC_ALLSERVER.dvid
  is '�豸ID';
create index IDX196_100193 on T_100193_NU_MAC_ALLSERVER (CHANNELID);
create index IDX197_100193 on T_100193_NU_MAC_ALLSERVER (THEDATE);

prompt
prompt Creating table T_100193_NU_PAY
prompt ==============================
prompt
create table T_100193_NU_PAY
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100193_NU_PAY
  is '�����û���';
comment on column T_100193_NU_PAY.thedate
  is '����ʱ��';
comment on column T_100193_NU_PAY.gameid
  is '��ϷID';
comment on column T_100193_NU_PAY.channelid
  is '����ID';
comment on column T_100193_NU_PAY.gameversion
  is '��Ϸ�汾';
comment on column T_100193_NU_PAY.serverid
  is '������Ϣ';
comment on column T_100193_NU_PAY.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100193_NU_PAY.position
  is 'λ����Ϣ';
comment on column T_100193_NU_PAY.accountid
  is '�˺�ID';
comment on column T_100193_NU_PAY.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100193_NU_PAY.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX151_100193 on T_100193_NU_PAY (CHANNELID);
create index IDX152_100193 on T_100193_NU_PAY (SERVERID);
create index IDX153_100193 on T_100193_NU_PAY (THEDATE);

prompt
prompt Creating table T_100193_NU_PAY_AS
prompt =================================
prompt
create table T_100193_NU_PAY_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  accountid     VARCHAR2(50) not null,
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100193_NU_PAY_AS
  is '�����û���allsever';
comment on column T_100193_NU_PAY_AS.thedate
  is '����ʱ��';
comment on column T_100193_NU_PAY_AS.gameid
  is '��ϷID';
comment on column T_100193_NU_PAY_AS.channelid
  is '����ID';
comment on column T_100193_NU_PAY_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100193_NU_PAY_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100193_NU_PAY_AS.position
  is 'λ����Ϣ';
comment on column T_100193_NU_PAY_AS.accountid
  is '�˺�ID';
comment on column T_100193_NU_PAY_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100193_NU_PAY_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX198_100193 on T_100193_NU_PAY_AS (CHANNELID);
create index IDX199_100193 on T_100193_NU_PAY_AS (THEDATE);

prompt
prompt Creating table T_100193_NU_PAY_MAC
prompt ==================================
prompt
create table T_100193_NU_PAY_MAC
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  serverid      VARCHAR2(20) not null,
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100193_NU_PAY_MAC
  is '�����û���';
comment on column T_100193_NU_PAY_MAC.thedate
  is '����ʱ��';
comment on column T_100193_NU_PAY_MAC.gameid
  is '��ϷID';
comment on column T_100193_NU_PAY_MAC.channelid
  is '����ID';
comment on column T_100193_NU_PAY_MAC.gameversion
  is '��Ϸ�汾';
comment on column T_100193_NU_PAY_MAC.serverid
  is '������Ϣ';
comment on column T_100193_NU_PAY_MAC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100193_NU_PAY_MAC.position
  is 'λ����Ϣ';
comment on column T_100193_NU_PAY_MAC.dvid
  is '�豸ID';
comment on column T_100193_NU_PAY_MAC.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100193_NU_PAY_MAC.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX154_100193 on T_100193_NU_PAY_MAC (CHANNELID);
create index IDX155_100193 on T_100193_NU_PAY_MAC (SERVERID);
create index IDX156_100193 on T_100193_NU_PAY_MAC (THEDATE);

prompt
prompt Creating table T_100193_NU_PAY_MAC_AS
prompt =====================================
prompt
create table T_100193_NU_PAY_MAC_AS
(
  thedate       DATE not null,
  gameid        VARCHAR2(20) not null,
  channelid     VARCHAR2(20) not null,
  gameversion   VARCHAR2(20),
  rolelevel     NUMBER not null,
  position      VARCHAR2(50),
  dvid          VARCHAR2(50),
  firstpaydate  DATE not null,
  firstpaylevel NUMBER not null,
  firstpaymoney NUMBER
)
;
comment on table T_100193_NU_PAY_MAC_AS
  is '�����û���ALLSERVER';
comment on column T_100193_NU_PAY_MAC_AS.thedate
  is '����ʱ��';
comment on column T_100193_NU_PAY_MAC_AS.gameid
  is '��ϷID';
comment on column T_100193_NU_PAY_MAC_AS.channelid
  is '����ID';
comment on column T_100193_NU_PAY_MAC_AS.gameversion
  is '��Ϸ�汾';
comment on column T_100193_NU_PAY_MAC_AS.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100193_NU_PAY_MAC_AS.position
  is 'λ����Ϣ';
comment on column T_100193_NU_PAY_MAC_AS.dvid
  is '�豸ID';
comment on column T_100193_NU_PAY_MAC_AS.firstpaydate
  is '�״γ�ֵʱ��';
comment on column T_100193_NU_PAY_MAC_AS.firstpaylevel
  is '�״γ�ֵ�ȼ�';
create index IDX200_100193 on T_100193_NU_PAY_MAC_AS (CHANNELID);
create index IDX201_100193 on T_100193_NU_PAY_MAC_AS (THEDATE);

prompt
prompt Creating table T_100193_ORDER_FAILURE
prompt =====================================
prompt
create table T_100193_ORDER_FAILURE
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100193_ORDER_FAILURE
  is '��ֵ�ɹ���¼��';
comment on column T_100193_ORDER_FAILURE.thedate
  is '��ֵʱ��';
comment on column T_100193_ORDER_FAILURE.gameid
  is '��ϷID';
comment on column T_100193_ORDER_FAILURE.channelid
  is '����ID';
comment on column T_100193_ORDER_FAILURE.gameversion
  is '��Ϸ�汾';
comment on column T_100193_ORDER_FAILURE.serverid
  is '��������';
comment on column T_100193_ORDER_FAILURE.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100193_ORDER_FAILURE.position
  is 'λ����Ϣ';
comment on column T_100193_ORDER_FAILURE.dvid
  is '�豸��';
comment on column T_100193_ORDER_FAILURE.accountid
  is '�˺�';
comment on column T_100193_ORDER_FAILURE.money
  is '��ֵ���';
comment on column T_100193_ORDER_FAILURE.vc
  is '��ֵ��õ����������';
comment on column T_100193_ORDER_FAILURE.orderid
  is '������';
comment on column T_100193_ORDER_FAILURE.paychannel
  is '֧������';
comment on column T_100193_ORDER_FAILURE.iapid
  is '��ֵ����  30  60';
create index IDX157_100193 on T_100193_ORDER_FAILURE (CHANNELID);
create index IDX158_100193 on T_100193_ORDER_FAILURE (SERVERID);
create index IDX159_100193 on T_100193_ORDER_FAILURE (THEDATE);

prompt
prompt Creating table T_100193_ORDER_SUCC
prompt ==================================
prompt
create table T_100193_ORDER_SUCC
(
  thedate     DATE,
  gameid      VARCHAR2(20),
  channelid   VARCHAR2(20),
  gameversion VARCHAR2(20),
  serverid    VARCHAR2(20),
  rolelevel   NUMBER,
  position    VARCHAR2(50),
  dvid        VARCHAR2(50),
  accountid   VARCHAR2(50),
  money       NUMBER,
  vc          NUMBER,
  orderid     VARCHAR2(50),
  paychannel  VARCHAR2(50),
  iapid       VARCHAR2(50)
)
;
comment on table T_100193_ORDER_SUCC
  is '��ֵ�ɹ���¼��';
comment on column T_100193_ORDER_SUCC.thedate
  is '��ֵʱ��';
comment on column T_100193_ORDER_SUCC.gameid
  is '��ϷID';
comment on column T_100193_ORDER_SUCC.channelid
  is '����ID';
comment on column T_100193_ORDER_SUCC.gameversion
  is '��Ϸ�汾';
comment on column T_100193_ORDER_SUCC.serverid
  is '��������';
comment on column T_100193_ORDER_SUCC.rolelevel
  is '��ɫ�ȼ�';
comment on column T_100193_ORDER_SUCC.position
  is 'λ����Ϣ';
comment on column T_100193_ORDER_SUCC.dvid
  is '�豸��';
comment on column T_100193_ORDER_SUCC.accountid
  is '�˺�';
comment on column T_100193_ORDER_SUCC.money
  is '��ֵ���';
comment on column T_100193_ORDER_SUCC.vc
  is '��ֵ��õ����������';
comment on column T_100193_ORDER_SUCC.orderid
  is '������';
comment on column T_100193_ORDER_SUCC.paychannel
  is '֧������';
comment on column T_100193_ORDER_SUCC.iapid
  is '��ֵ����  30  60';
create index IDX160_100193 on T_100193_ORDER_SUCC (CHANNELID);
create index IDX161_100193 on T_100193_ORDER_SUCC (SERVERID);
create index IDX162_100193 on T_100193_ORDER_SUCC (THEDATE);

prompt
prompt Creating table T_100193_VC
prompt ==========================
prompt
create table T_100193_VC
(
  statdate    DATE,
  channelid   VARCHAR2(50),
  serverid    VARCHAR2(50),
  appid       VARCHAR2(50),
  versionid   VARCHAR2(50),
  accountid   VARCHAR2(50),
  vctype      VARCHAR2(50),
  vcusetype   VARCHAR2(50),
  vcuseway    VARCHAR2(50),
  vcchange    NUMBER,
  vcbefore    NUMBER,
  vcafter     NUMBER,
  loaddate    DATE default SYSDATE,
  data_source VARCHAR2(100)
)
;
comment on table T_100193_VC
  is '������ұ仯������';
comment on column T_100193_VC.statdate
  is 'ͳ������';
comment on column T_100193_VC.channelid
  is '����';
comment on column T_100193_VC.serverid
  is '����';
comment on column T_100193_VC.appid
  is '��Ʒid';
comment on column T_100193_VC.versionid
  is '��Ʒ�汾';
comment on column T_100193_VC.accountid
  is '�û�ID';
comment on column T_100193_VC.vctype
  is '�����������';
comment on column T_100193_VC.vcusetype
  is '�������ʹ������';
comment on column T_100193_VC.vcuseway
  is '�������ʹ�÷�ʽ';
comment on column T_100193_VC.vcchange
  is '������ұ仯���';
comment on column T_100193_VC.vcbefore
  is '������ұ仯ǰ���';
comment on column T_100193_VC.vcafter
  is '������ұ仯����';
comment on column T_100193_VC.data_source
  is '������Դ';
create index IDX163_100193 on T_100193_VC (CHANNELID);
create index IDX164_100193 on T_100193_VC (SERVERID);
create index IDX165_100193 on T_100193_VC (STATDATE);


spool off
